--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUtil.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/03   11:13
--  Contact     : lvsongxin@kingsoft.com
--  Comment     : 
--  *********************************************************************


KUtil = KUtil or {}

KUtil.FONT_PATH = "res/ui/ui_material/DFPLiJinHeiW8-GB.TTF"

local load = loadstring

local currencyPath = {
    [CURRENCY_TYPE.COIN]      = "res/images/item/material/diamond.png",
    [CURRENCY_TYPE.OIL]       = "res/images/item/material/oli.png",
    [CURRENCY_TYPE.AMMO]      = "res/images/item/material/ammo.png",
    [CURRENCY_TYPE.STEEL]     = "res/images/item/material/steel.png",
    [CURRENCY_TYPE.PEOPLE]    = "res/images/item/material/people.png",
    [CURRENCY_TYPE.FURNITURE] = "res/images/item/material/furniture.png",
}

local currencyName = {
    [CURRENCY_TYPE.COIN]      = "common.coin",
    [CURRENCY_TYPE.OIL]       = "common.oil",
    [CURRENCY_TYPE.AMMO]      = "common.ammo",
    [CURRENCY_TYPE.STEEL]     = "common.steel",
    [CURRENCY_TYPE.PEOPLE]    = "common.people",
    [CURRENCY_TYPE.FURNITURE] = "furniture.coin",
}

local cardCountryName = {
    [CARD_COUNTRY_TYPE.BASE]    = "base",
    [CARD_COUNTRY_TYPE.AMERICA] = "america",
    [CARD_COUNTRY_TYPE.BRITAIN] = "britain",
    [CARD_COUNTRY_TYPE.FRANCE]  = "france",
    [CARD_COUNTRY_TYPE.GERMANY] = "germany",
    [CARD_COUNTRY_TYPE.SOVIET]  = "soviet",
}

KUtil.IMAGE_CARD_TYPE  = {"Image_type_light", "Image_type_tanzania", "Image_type_heavy", "Image_type_fighter", "Image_type_artillery", "Image_type_all"}
KUtil.BUTTON_CARD_TYPE = {"Button_light", "Button_tanzania", "Button_heavy", "Button_fighter", "Button_artillery", "Button_all"}
KUtil.IMAGE_CARD_SORT  = {"Image_sort_name", "Image_sort_star", "Image_sort_level", "Image_sort_time"}
KUtil.BUTTON_CARD_SORT = {"Button_name", "Button_star", "Button_level", "Button_time"}

KUtil.ATTIBUTE_NAME = {
    {ATTRIBUTE.ATTACK,      "attribute.attack",},
    {ATTRIBUTE.PENETRATE,   "attribute.penetrate",},
    {ATTRIBUTE.FRONTARMOUR, "attribute.frontArmour",},
    {ATTRIBUTE.REARARMOUR,  "attribute.rearArmour",},
    {ATTRIBUTE.SCOUT,       "attribute.scout",},
    {ATTRIBUTE.HIDE,        "attribute.hide",},
}

KUtil.PERCENT_BASE          = 100
KUtil.KEEP_DOWN_SECOND      = 0.8
KUtil.MILLI_SECOND_RATE     = 1000
KUtil.SHOW_LIST_SIZE        = 30
KUtil.FRAME_PER_SECOND      = 60

KUtil.PIXEL_QUALITY = {
    HIGH        = "high",
    MEDIAN      = "median",
    LOW         = "low",
}

KUtil.MAX_STAR = 6 

KUtil.CHOOSE_TANK_TYPE = 
{
    LIGHT     = 1, 
    TANZANIA  = 2,
    HEAVY     = 3,
    FIGHTER   = 4,
    ARTILLERY = 5,
    ALL       = 6,
}

KUtil.CHOOSE_COMMON_TYPE = 
{
    NAME  = 1,
    STAR  = 2,
    LEVEL = 3,
    TIME  = 4,
}

KUtil.MAX_FEELING          = 100
KUtil.MAX_CARD_LEVEL       = 99
KUtil.MAX_MARRY_CARD_LEVEL = 150

KUtil.SpriteSupply = {
    {["upLimit"] = 101, ["downLimit"] = 99, ["spritName"] = "Sprite_supply_1"},
    {["upLimit"] = 99, ["downLimit"] = 75, ["spritName"] = "Sprite_supply_2"},
    {["upLimit"] = 75,  ["downLimit"] = 50, ["spritName"] = "Sprite_supply_3"},
    {["upLimit"] = 50,  ["downLimit"] = 25, ["spritName"] = "Sprite_supply_3"},
    {["upLimit"] = 25,  ["downLimit"] = 0 , ["spritName"] = "Sprite_supply_4"},
    {["upLimit"] = 0,   ["downLimit"] = -1, ["spritName"] = "Sprite_supply_4"}
}

function KUtil.getMaxLevel()
    local count = 1
    while true do
        if not KConfig.levelInfo[count] then
            break
        end
        count = count + 1
    end
    return count - 1
end

function KUtil.getCardMaxExp(tGrade)
    local tLevel = KConfig.levelInfo[tGrade]
    if tLevel then return tLevel.nCardExp end
    return 0
end

function KUtil.getRoleMaxExp(tGrade)
    local tLevel = KConfig.levelInfo[tGrade]
    if tLevel then return tLevel.nRoleExp end
    return 0
end

function KUtil.getPlayerLevelInfo(nLevel, id)
    local levelInfo = KConfig.playerLevelInfo[nLevel]
    if levelInfo then return levelInfo[id] end
    return 0
end

function KUtil.getCardList()
    return KPlayer.tCardData.tStoreHouse.tCardList
end

function KUtil.getCardCount()
    return table.getn(KPlayer.tCardData.tStoreHouse.tCardList)
end

function KUtil.getCardStoreSize()
    return KPlayer.tCardData.tStoreHouse.nMaxSize
end

function KUtil.CanAddCard(nTemplateID, nCount)
    if not nCount then
        nCount = 1
    end
    assert(nCount >= 0)
    local tCardConfig = KUtil.getCardConfig(nTemplateID)
    assert(tCardConfig)

    if KUtil.GetCardSpaceCount() < nCount then
        return "common.CardStoreFull"
    end

    local nEquipCount = 1
    while true do
        local nEquipCode = tCardConfig["nInitEquip"..nEquipCount]
        if nEquipCode and nEquipCode ~= 0 then
            nEquipCount = nEquipCount + 1
        else
            break
        end
    end
    nEquipCount = nEquipCount * nCount
    if KUtil.GetEquipSpaceCount() < nEquipCount then
        return "common.EquipStoreLess"
    end 

    return
end

function KUtil.getCardById(cardId)
    local tList = KPlayer.tCardData.tStoreHouse.tCardList
    return HArray.FindFirstByID(tList, cardId)
end

function KUtil.getCaptainCard(teamType)
    local oneTeamCardList = KUtil.getOneTeamCardList(teamType)
    return oneTeamCardList[1]
end

function KUtil.getEquipById(equipId)
    local tList = KPlayer.tItemData.tEquipStoreHouse.tEquipList
    return HArray.FindFirstByID(tList, equipId)
end

function KUtil.showCostItemComfirmation(confirmationInfo, itemID, confirmFunction, cancelFunction)
    local currentScene = cc.Director:getInstance():getRunningScene()

    local showNode = currentScene:getChildByName("showCostItemComfirmation")
    if showNode then return end 

    local showConfirmationNode = require("src/ui/common/KUIShowItemConfirmationNode").create(currentScene)
    showConfirmationNode:setConfirmationInfo(confirmationInfo)
    showConfirmationNode:setName("showCostItemComfirmation")
    showConfirmationNode:setCostItem(itemID)
    showConfirmationNode:setOnTouchEvent(confirmFunction, cancelFunction)
    currentScene:addChild(showConfirmationNode, 999) -- we must see this top
end

function KUtil.showItemChangeNameComfirmation(itemID, confirmFunction, cancelFunction)
    local currentScene = cc.Director:getInstance():getRunningScene()

    local showNode = currentScene:getChildByName("showCostItemChangeNameComfirmation")
    if showNode then return end 

    local showConfirmationNode = require("src/ui/common/KUIShowModifyNameNode").create(currentScene)
    showConfirmationNode:setName("showCostItemChangeNameComfirmation")

    showConfirmationNode:setOnTouchEvent(confirmFunction, cancelFunction)
    currentScene:addChild(showConfirmationNode, 999) -- we must see this top
end

function KUtil.showGotoBuyDiamondConfirmation(parent)
    local onConfirm = function ()
        parent:addNode("Shop")
    end

    local showString = KUtil.getStringByKey("common.gotoBuyDiamond")
    showConfirmation(showString, onConfirm)
end

function KUtil.showNoticeByErrorCode(errorCode)
    local errorKey = "errorCode" .. errorCode

    local stringConfig = KConfig:getLine("string", errorKey) or {}
    local errorString = stringConfig.szText or ("errorCode:" .. errorCode)
    local szType = stringConfig.szType or ""
    showNotice(errorString, szType)
end

function KUtil.getRecordTeamName(index)
    local teamName = KUtil.getStringByKey("common.team") .. index
    local teamList = KPlayer.tTeamData.tRecordTeamList
    local teamItem = HArray.FindFirst(teamList, "nIndex", index)
    if teamItem and teamItem.szName then 
        local stringLen = string.len(teamItem.szName)
        if stringLen > 0 then teamName = teamItem.szName end
    end
    return teamName
end

function KUtil.getRecordTeamCardList(index)
    local teamList = KPlayer.tTeamData.tRecordTeamList
    local cardTable = {}
    if not index then cclog("index is invalid") return end
    local teamItem = HArray.FindFirst(teamList, "nIndex", index)
    if not teamItem then return cardTable end

    for i,v in ipairs(teamItem.tCardIDList) do
        local card = KUtil.getCardById(v)
        if card then
            table.insert(cardTable, card)
        end
    end
    return cardTable
end

function KUtil.getOneTeamCardList(teamId)
    local teamList = KPlayer.tTeamData.tTeamList
    local cardTable = {}
    if not teamId then cclog("teamId is invalid") return end
    local teamItem = HArray.FindFirst(teamList, "nIndex", teamId)
    if not teamItem then return cardTable end

    for i,v in ipairs(teamItem.tCardIDList) do
        local card = KUtil.getCardById(v)
        if not card then 
            cclog("Card not exist, card_id is:"..v) 
        else
            table.insert(cardTable, card)
        end
    end
    return cardTable
end

function KUtil.getTeamLeaderCard(teamIndex)
    teamIndex = teamIndex or 1
    local oneTeam = HArray.FindFirst(KPlayer.tTeamData.tTeamList, "nIndex", teamIndex)
    assert(oneTeam, teamIndex)
    local cardID = oneTeam.tCardIDList[1]
    return KUtil.getCardById(cardID)
end

function KUtil.getEnterTeamId(cardId)
    local teamList = KPlayer.tTeamData.tTeamList
    for _, item in pairs(teamList) do
        for i, tCardID in ipairs(item.tCardIDList) do
            if tCardID == cardId then
                return item.nIndex
            end
        end
    end
    return 0
end

function KUtil.getPositionInTeam(teamIndex, cardId)
    local oneTeam = HArray.FindFirst(KPlayer.tTeamData.tTeamList, "nIndex", teamIndex)
    if not oneTeam then return 0 end
    for i, tCardID in ipairs(oneTeam.tCardIDList) do
        if tCardID == cardId then
            return i
        end
    end
    return 0
end

function KUtil.getCardInTeam(teamId, cardIndex)
    local teamList = KPlayer.tTeamData.tTeamList
    local returnID = 0
    for i, tItem in ipairs(teamList) do
        if tItem.nIndex == teamId then
            returnID = tItem.tCardIDList[cardIndex] or 0
            break
        end
    end
    return returnID
end

function KUtil.getTeamSize(teamId)
    local teamList = KPlayer.tTeamData.tTeamList
    local teamItem = HArray.FindFirst(teamList, "nIndex", teamId)
    if not teamItem then return 0 end
    return #teamItem.tCardIDList
end

function KUtil.getCardEquipByPosition(card, position)
    local equipList = card.tEquipList
    for _, equip in pairs(equipList) do
        if position == equip.nPos then
            local equip = KUtil.getEquipById(equip.nEquipID)
            if not equip then cclog("card equip can not found!") end
            return equip
        end
    end
    return nil
end

function KUtil.isHaveBrokenCard(teamID, nBrokenLevel)
    if not nBrokenLevel then nBrokenLevel = 3 end
    local cardList = KUtil.getOneTeamCardList(teamID)
    local teamCount = #cardList
    local tHPPercent = {0.75, 0.5, 0.25}
    local breakePercentage = tHPPercent[nBrokenLevel]

    local isBrokenCard = false
    for index = 1, teamCount do
        local oneCard    = cardList[index]
        local maxHP      = KUtil.getCardMaxHp(oneCard)
        local nHPPercent = oneCard.nCurrentHP / maxHP

        if nHPPercent <= breakePercentage then isBrokenCard = true break end
    end
    return isBrokenCard
end

function KUtil.isHaveBrokenCardInCardList(tCardList, nBrokenLevel)
    if not nBrokenLevel then nBrokenLevel = 3 end
    local tHPPercent = {0.75, 0.5, 0.25}
    local breakePercentage = tHPPercent[nBrokenLevel]

    local isBrokenCard = false
    for _, tCard in ipairs(tCardList) do
        local nHPPercent = tCard.nCurrentHP / tCard.nMaxHP
        if nHPPercent <= breakePercentage then 
            return true 
        end
    end
    return false
end

function KUtil.getMarriedCardIDList()
    local marriedList = {}
    local allCardList = KUtil.getCardList()
    for _, card in ipairs(allCardList) do
        if card.bRing then
            table.insert(marriedList, card.nTemplateID)
        end
    end

    local historicalMarriedList = KPlayer.tCardData.tHistoricalMarriedList
    for _, id in ipairs(historicalMarriedList) do
        HArray.UniqueInsertByValue(marriedList, id)
    end

    local resultList = {}
    for _, nTemplateID in ipairs(marriedList) do
        local cardConfig    = KConfig.cardInfo[nTemplateID]
        local preConvert    = cardConfig.nConvertIndex
        local nextConvert   = cardConfig.nConvertID
        while preConvert ~= cardConfig.nID do
            table.insert(resultList, preConvert)                

            cardConfig = KConfig.cardInfo[preConvert]
            preConvert = cardConfig.nConvertIndex
        end

        while nextConvert ~= 0 do
            table.insert(resultList, nextConvert) 

            cardConfig  = KConfig.cardInfo[nextConvert]
            nextConvert = cardConfig.nConvertID
        end

        table.insert(resultList, nTemplateID)
    end
    return resultList
end

function KUtil.getCardImagePathByConfigID(cardID, isDamaged, skinTemplateID)
    skinTemplateID = skinTemplateID or 0

    local resPath = KUtil.getCardConfigValue(cardID, "szResPath")
    if skinTemplateID > 0 then
        resPath = KUtil.getSkinConfigValue(skinTemplateID,"szResPath")
    end

    if isDamaged then
        return "res/images/cards/" .. resPath .. "/DamagedImage.png"
    else
        return "res/images/cards/" .. resPath .. "/NormalImage.png"
    end
end

function KUtil.getCardHeadPathByConfigID(cardID, isDamaged, skinTemplateID)

    skinTemplateID = skinTemplateID or 0

    local resPath = KUtil.getCardConfigValue(cardID, "szResPath")
    if skinTemplateID > 0 then
        resPath = KUtil.getSkinConfigValue(skinTemplateID,"szResPath")
    end

    if isDamaged then
        return "res/images/cards/" .. resPath .. "/Damagedhead.png"
    else
        return "res/images/cards/" .. resPath .. "/Normalhead.png"
    end
end

function KUtil.getScaleImagePathByConfigID(cardID, isDamaged, skinTemplateID)
    skinTemplateID = skinTemplateID or 0
    local cardConfig  = KConfig.cardInfo[cardID]
    local resPath

    if skinTemplateID > 0 then
        local skinConfig = KConfig.skin[skinTemplateID]
        resPath = skinConfig.szResPath
    else
        resPath = cardConfig.szResPath
    end

    local imageName   = "cards_normal"
    if isDamaged then
        imageName = "cards_damaged"
    end
    return "res/images/cards_thumbnail/".. imageName .. "/" .. resPath .. ".png"
end

function KUtil.getCardImagePath(card, isHead, isBreak)
    if not card.nID then
        return KUtil.getMonsterImagePathByConfigID(card.nTemplateID, isHead)
    end
    local cardConfig  = KConfig.cardInfo[card.nTemplateID]
    local resPath

    if card.nSkinTemplateID and card.nSkinTemplateID > 0 then
        local skinConfig  = KConfig.skin[card.nSkinTemplateID]
        resPath = skinConfig.szResPath
    else
        resPath = cardConfig.szResPath
    end

    local maxHP       = card.nMaxHP or KUtil.getCardMaxHp(card)
    local percentage  = card.nCurrentHP / maxHP
    local breakePercentage = 0.5
    local imageName = "/Normal"
    if percentage <= breakePercentage or isBreak then
        imageName = "/Damaged"
    end
    if isHead then
        imageName = imageName .. "head.png"
    else
        imageName = imageName .. "Image.png"
    end
    return "res/images/cards/".. resPath ..imageName
end

function KUtil.getPlayerCardImagePath(card, isHead, isBreak)
    local cardConfig  = KConfig.cardInfo[card.nTemplateID]
    local resPath

    if card.nSkinTemplateID and card.nSkinTemplateID > 0 then
        local skinConfig  = KConfig.skin[card.nSkinTemplateID]
        resPath = skinConfig.szResPath
    else
        resPath = cardConfig.szResPath
    end

    local maxHP       = card.nMaxHP or KUtil.getCardMaxHp(card)
    local percentage  = card.nCurrentHP / maxHP
    local breakePercentage = 0.5
    local imageName = "/Normal"
    if percentage <= breakePercentage or isBreak then
        imageName = "/Damaged"
    end
    if isHead then
        imageName = imageName .. "head.png"
    else
        imageName = imageName .. "Image.png"
    end
    return "res/images/cards/".. resPath ..imageName
end

function KUtil.getCardImageLightPath(card)
    local cardConfig = KConfig.cardInfo[card.nTemplateID]
    local resPath

    if card.nSkinTemplateID > 0 then
        local skinConfig = KConfig.skin[card.nSkinTemplateID]
        resPath = skinConfig.szResPath
    else
        resPath = cardConfig.szResPath
    end

    local maxHP      = card.nMaxHP or KUtil.getCardMaxHp(card)
    local imageName  = "/Normal" .. "Image_light.png"
    if card.nCurrentHP / maxHP <= BROKEN_LIMIT.MIDDLE then
        imageName = "/Damaged" .. "Image_light.png"
    end
    return "res/images/cards/" .. resPath .. imageName
end

function KUtil.getScaleCardImagePath(card)
    local cardConfig       = KConfig.cardInfo[card.nTemplateID]
    local maxHP            = card.nMaxHP or KUtil.getCardMaxHp(card)
    local percentage       = card.nCurrentHP / maxHP
    local breakePercentage = 0.5
    if percentage <= breakePercentage then
        return KUtil.getScaleImagePathByConfigID(card.nTemplateID, true, card.nSkinTemplateID)
    else
        return KUtil.getScaleImagePathByConfigID(card.nTemplateID, false, card.nSkinTemplateID)
    end
end

function KUtil.getMonsterImagePath(card, isHead)
    return KUtil.getMonsterImagePathByConfigID(card.nTemplateID, isHead)
end

function KUtil.getMonsterImagePathByConfigID(nMonsterTemplateID, bHead, nHP)
    local monsterConfig = KConfig.monster[nMonsterTemplateID]
    local nMaxHP       = monsterConfig.nMaxHP
    nHP = nHP or nMaxHP
    local nPercentage  = nHP / nMaxHP
    local nBreakePercentage = 0.5
    local szImageName = "/Normal"
    if nPercentage <= nBreakePercentage then
        szImageName = "/Damaged"
    end
    if bHead then
        szImageName = szImageName .. "head.png"
    else
        szImageName = szImageName .. "Image.png"
    end
    print("getMonsterImagePathByConfigID", "res/images/cards/" .. monsterConfig.szResPath .. szImageName)
    return "res/images/cards/" .. monsterConfig.szResPath .. szImageName
end

function KUtil.getMonsterImageLightPath(card)
    local monsterConfig = KConfig.monster[card.nTemplateID] 
    local imageName     = "/Normal" .. "Image_light.png"
    return "res/images/cards/" .. monsterConfig.szResPath .. imageName
end

function KUtil.drawCardState(imageHPBase, imageStateBase, hpName, stateName, nHPPercent)
    local m_tDamageSection = {
        {["upLimit"] = 100, ["downLimit"] = 75},
        {["upLimit"] = 75,  ["downLimit"] = 50},
        {["upLimit"] = 50,  ["downLimit"] = 25},
        {["upLimit"] = 25,  ["downLimit"] = 0 },
        {["upLimit"] = 0,   ["downLimit"] = -1}
    }
    
    for key, var in ipairs(m_tDamageSection) do
        local imageStateName = stateName[key]
        local hpStateName    = hpName[key]
        local condition      = false
        if nHPPercent <= var.upLimit and nHPPercent > var.downLimit then condition = true end

        if hpStateName ~= nil and imageHPBase ~= nil then
            local loadingBarHP  = imageHPBase:getChildByName(hpStateName)
            loadingBarHP:setVisible(condition)
            loadingBarHP:setPercent(nHPPercent)
        end

        if imageStateName ~= nil and imageStateBase ~= nil then
            local imageStateControl = imageStateBase:getChildByName(imageStateName)
            imageStateControl:setVisible(condition) 
        end
    end
end

function KUtil.charSize(char)
    if not char then
        return 0
    elseif char > 240 then
        return 4
    elseif char > 225 then
        return 3
    elseif char > 192 then
        return 2
    else
        return 1
    end
end

function KUtil.subString(szString, nLength)
    local nStartIndex = 1
    local nCurrentIndex = nStartIndex
    while nLength > 0 and nCurrentIndex <= #szString do
        local char = string.byte(szString, nCurrentIndex)
        nCurrentIndex = nCurrentIndex + KUtil.charSize(char)
        nLength = nLength -1
    end
    return string.sub(szString, nStartIndex, nCurrentIndex - 1)
end

function KUtil.shortString(szString, nLength)
    if string.len(szString) <= nLength then return szString end
    local shortString = KUtil.subString(szString, nLength)
    if shortString == szString then return shortString end
    return shortString .. ".."
end

-- only use short string
function KUtil.cutTextLength(text, name, textWidth)
    local defaultEndString = "…"
    text:setString(name)
    local size = text:getContentSize()
    if size.width > textWidth then
        local result    = KUtil.splitChinese(name)
        local oneWidth  = size.width / #result
        local num = math.floor(textWidth / oneWidth)
        local baseName  = ""
        for i=1,num - 1 do
            baseName = baseName .. result[i].word
        end

        local widthNeed = 12
        text:setString(baseName..defaultEndString)
        
        local size = text:getContentSize()
        if size.width > textWidth then
            for i=num - 1,1,-1 do
                baseName = string.sub(baseName, 1, -1 -KUtil.charSize(string.byte(result[i].word, 1)))
                text:setString(baseName..defaultEndString)
                local size1 = text:getContentSize()
                if size1.width < textWidth + 2 then
                    return
                end
            end
        else
            if size.width < textWidth - widthNeed then
                text:setString(defaultEndString)
                widthNeed = text:getContentSize().width

                for i=num,#result do
                    baseName = baseName .. result[i].word
                    text:setString(baseName..defaultEndString)
                    local size1 = text:getContentSize()
                    if size1.width > textWidth - widthNeed then
                        return
                    end
                end
            end
        end
    end
end

function KUtil.handleChineseWidth(szString, nLength)
    if string.len(szString) <= nLength then return szString end

    local nStartIndex = 1
    local nCurrentIndex = nStartIndex
    while nLength > 0 and nCurrentIndex <= #szString do
        local char = string.byte(szString, nCurrentIndex)
        local charSize = KUtil.charSize(char)
        nCurrentIndex = nCurrentIndex + charSize
        nLength = nLength - 1
        if charSize > 2 then
            nLength = nLength - 0.5
        end
    end
    local shortString = string.sub(szString, nStartIndex, nCurrentIndex - 1)
    if shortString == szString then return shortString end
    return shortString .. ".."
end

function KUtil.batchAddScrollView(tParam)
    tParam.scrollView:stopAllActions()
    if not tParam.funGetID then
        tParam.funGetID = function(tOneData)
            return tOneData.nID
        end
    end
    
    local tBarList      = tParam.scrollView:getChildren()
    local nViewCount    = #tParam.dataList
    local nOldCount     = #tBarList
    local nRemoveCount  = nOldCount - nViewCount
    local tBarMap       = {}
    local tFreeNodeBar  = {}
    for _, nodeBar in ipairs(tBarList) do
        nodeBar:stopAllActions()
        nodeBar:setVisible(false)
        if nodeBar.nID and HArray.FindFirstByFun(tParam.dataList, nodeBar.nID, tParam.funGetID) then
            tBarMap[nodeBar.nID] = nodeBar
        elseif nRemoveCount > 0 then
            tParam.scrollView:removeChild(nodeBar)
            nRemoveCount = nRemoveCount - 1
        else 
            table.insert(tFreeNodeBar, nodeBar)
        end
    end
    print("batchAddScrollView", nOldCount, nViewCount, #tFreeNodeBar, nRemoveCount)
    local nIndex        = 1
    local function addBar()
        print("addBar", nIndex, nViewCount)
        local bCutIn = tParam.isCutIn
        if nIndex ~= 1 then bCutIn = false end

        local tBarList  = {}
        local nCloneCount = 0
        local barClone
        for i = nIndex, nViewCount do
            local bAdd         = true
            local tOneData     = tParam.dataList[i]
            local nID          = tParam.funGetID(tOneData)
            local nodeBar      = tBarMap[nID]
            if not nodeBar then
                local nFreeCount = #tFreeNodeBar
                if barClone then
                    if not tolua.isnull(barClone) then
                        nodeBar =  barClone
                    end
                    barClone = nil
                elseif nFreeCount > 0 then
                    nodeBar = tFreeNodeBar[nFreeCount]
                    table.remove(tFreeNodeBar, nFreeCount)
                else
                    nodeBar = tParam.barBase:clone()
                    nCloneCount = nCloneCount + 1
                end
                bAdd = tParam.funInit(nodeBar, tOneData)
                nodeBar.nID = nID
            elseif tParam.funReInit then
                tParam.funReInit(nodeBar, tOneData)
            end
            assert(not tolua.isnull(nodeBar))
            -- nodeBar.nIndex = i
            if bAdd then
                table.insert(tBarList, nodeBar)
            elseif nodeBar:getParent() then
                table.insert(tFreeNodeBar, nodeBar)
            else
                barClone = nodeBar
            end
            nIndex = nIndex + 1
            if nCloneCount == tParam.oneBatchCount then break end
        end
        
        KUtil.addScrollView(tParam.scrollView, tBarList, bCutIn, tParam.slideView, false, false, nViewCount)
        if nIndex > nViewCount then
            tParam.scrollView:stopAllActions()
            if tParam.funEnd then tParam.funEnd() end
        end 
    end

    tParam.scrollView:runAction(
        cc.Sequence:create(
            cc.CallFunc:create(addBar), 
            cc.DelayTime:create(0.5), 
            cc.Repeat:create(cc.Sequence:create(cc.CallFunc:create(addBar), cc.DelayTime:create(0.1)), math.ceil(nViewCount/tParam.oneBatchCount)) ))
end

function KUtil.addScrollView(scrollView, barList, isCutIn, slideView, isAlignment, isHorizontal, nMaxCount)
    if isHorizontal then
        KUtil.addScrollViewHorizontal(scrollView, barList, isCutIn, slideView, isAlignment, nMaxCount)
    else
        KUtil.addScrollViewVertical(scrollView, barList, isCutIn, slideView, isAlignment, nMaxCount)
    end
end

function KUtil.addScrollViewVertical(scrollView, newBarList, isCutIn, slideView, isLeftAlignment, nMaxCount)
    if slideView then slideView:setPercent(0) end
    if not newBarList then return end
    local tOldBarList = scrollView:getChildren() 
    if #tOldBarList == 0 and #newBarList == 0 then return end
    local tBarList    = {}
    for _, bar in ipairs(tOldBarList) do
        bar:stopAllActions()
        if bar:isVisible() then
            table.insert(tBarList, bar)
        end
    end
    local function funSort(bar1, bar2)
        local positionY1 = bar1.positionY or bar1:getPositionY()
        local positionY2 = bar2.positionY or bar2:getPositionY()
        if positionY1 > positionY2 then return true end
        return false 
    end
    table.sort(tBarList, funSort)
    HArray.inserArray(tBarList, newBarList)
    assert(#tBarList > 0)

    local contentSize  = scrollView:getContentSize()
    local barSize      = tBarList[1]:getContentSize() --getSize
    local positionX
    if isLeftAlignment then
        positionX = 0
    else
        positionX     = (contentSize.width - barSize.width)/2
    end
    if not nMaxCount then nMaxCount = #tBarList end
    assert(nMaxCount >= #tBarList)
    local totalHeight = barSize.height * nMaxCount
    if totalHeight < contentSize.height then
        totalHeight = contentSize.height
    end
    scrollView:setInnerContainerSize(cc.size(contentSize.width,totalHeight))
    scrollView:jumpToTop()
    
    local moveStartPositionY = totalHeight-contentSize.height-barSize.height
    for index, bar in ipairs(tBarList) do
        bar:setVisible(true)
        bar:setAnchorPoint(0, 0)
        if not bar:getParent() then
            scrollView:addChild(bar)
        end
        local positionY = totalHeight - index * barSize.height
        bar:setPosition(cc.p(positionX, moveStartPositionY))
        if isCutIn and positionY > moveStartPositionY then
            bar.positionY = positionY
            bar:setPosition(cc.p(positionX, moveStartPositionY))
            local delayTime = 0.3 + index * 0.025
            bar:runAction(
                cc.Sequence:create(
                    cc.DelayTime:create(delayTime),
                    cc.MoveTo:create(0.0004 * (positionY - moveStartPositionY) , cc.p(positionX, positionY)) ) )
        else
            bar.positionY = nil
            bar:setPosition(cc.p(positionX, positionY))
        end
    end
end

function KUtil.addScrollViewHorizontal(scrollView, barList, isCutIn, slideView, isTopAlignment)
    if slideView then slideView:setPercent(0) end
    if not barList or #barList == 0 then return end
    
    local contentSize  = scrollView:getContentSize()
    local barSize      = barList[1]:getContentSize() --getSize
    local positionY
    if isTopAlignment then
        positionY = 0
    else
        positionY    = (contentSize.height - barSize.height)/2
    end
    local totalWidth  = barSize.width * #barList
    if totalWidth < contentSize.width then
        totalWidth = contentSize.width
    end
    scrollView:setInnerContainerSize(cc.size(totalWidth, contentSize.height))
    scrollView:jumpToLeft()
    
    local moveStartPositionX = contentSize.width+barSize.width
    for index, bar in ipairs(barList) do
        bar:setAnchorPoint(0, 0)
        scrollView:addChild(bar)
        local positionX = (index - 1)*barSize.width
        bar:setPosition(cc.p(moveStartPositionX, positionY))
        if isCutIn and positionX < moveStartPositionX then
            bar.positionX = positionX
            bar:setPosition(cc.p(moveStartPositionX, positionY))
            local delayTime = 0.3 + index * 0.025
            bar:runAction(
                cc.Sequence:create(
                    cc.DelayTime:create(delayTime),
                    cc.MoveTo:create(0.0004 * (moveStartPositionX - positionX) , cc.p(positionX, positionY)) ) )
        else
            bar.positionX = nil
            bar:setPosition(cc.p(positionX, positionY))
        end
    end
end

function KUtil.showScrollViewHorizontal(scrollView, barList, parameters)
    if not barList or #barList == 0 then return end
    assert(parameters ~= nil)

    local paddingLeft = parameters.paddingLeft or 0
    local paddingTop  = parameters.paddingTop or 0
    local barWidth    = parameters.barWidth or 0
    local barHeight   = parameters.barHeight or 0
    local offsetX     = parameters.offsetX or 0
    local offsetY     = parameters.offsetY or 0
    local isTopAlignment = parameters.isTopAlignment or false
    
    local contentSize = scrollView:getContentSize()
    local positionY   = paddingTop + offsetY
    if not isTopAlignment then
        positionY = (contentSize.height - barHeight)/2 + offsetY
    end
    
    local barListSize = #barList
    local totalWidth  = barWidth * barListSize + paddingLeft
    if totalWidth < contentSize.width then
        totalWidth = contentSize.width
    end

    scrollView:setInnerContainerSize(cc.size(totalWidth, contentSize.height))
    scrollView:jumpToLeft()
    
    local moveStartPositionX = contentSize.width + barWidth
    for index, bar in ipairs(barList) do
        local positionX = paddingLeft + (index - 1) * barWidth + offsetX
        bar.positionX = positionX
        bar:setPosition(positionX, positionY) 
    end
end

function KUtil.getBarFromScrollViewByID(scrollView, nID)
    local tChildren = scrollView:getChildren()
    for _, bar in ipairs(tChildren) do
        if bar.nID == nID then
            return bar
        end
    end
end

function KUtil.getBarIndexFromScrollViewByID(scrollView, nID)
    local tChildren = scrollView:getChildren()
    local function funSort(bar1, bar2)
        local positionY1 = bar1.positionY or bar1:getPositionY()
        local positionY2 = bar2.positionY or bar2:getPositionY()
        if positionY1 > positionY2 then return true end
        return false 
    end
    table.sort(tChildren, funSort)

    for i, bar in ipairs(tChildren) do
        if bar.nID == nID then
            return i
        end
    end
end

function KUtil.removeBarFromScrollView(scrollView, nIndex)
    local tChildren = scrollView:getChildren()
    local function funSort(bar1, bar2)
        local positionY1 = bar1.positionY or bar1:getPositionY()
        local positionY2 = bar2.positionY or bar2:getPositionY()
        if positionY1 > positionY2 then return true end
        return false 
    end
    table.sort(tChildren, funSort)

    local contentSize = scrollView:getContentSize()
    local barSize     = tChildren[1]:getContentSize()
    local barPositionX= tChildren[1]:getPositionX()
    local totalHeight = barSize.height * (#tChildren - 1)
    if totalHeight    < contentSize.height then
        totalHeight   = contentSize.height
    end

    local innerContainer = scrollView:getInnerContainer()
    local positionX      = innerContainer:getPositionX()
    local positionY      = innerContainer:getPositionY()
    local innerHeight    = innerContainer:getContentSize().height
    local nCutHeight     = innerHeight - totalHeight
    if positionY >= 0 then
        nCutHeight = 0
    elseif nCutHeight > -positionY then
        nCutHeight = math.floor((-positionY) / barSize.height) * barSize.height
    end
    positionY = positionY + nCutHeight

    scrollView:removeChild(tChildren[nIndex])
    table.remove(tChildren, nIndex)

    local oldY
    local nMaxShowIndex = #tChildren
    if positionY < 0 then
        local nHideHeight = -positionY - innerHeight + totalHeight
        if nHideHeight > 0 then
            nMaxShowIndex = #tChildren - math.floor(nHideHeight / barSize.height) 
        end
    end
    for i = 1, #tChildren do
        tChildren[i]:stopAllActions()
        if tChildren[i].positionY then
            tChildren[i]:setPosition(cc.p(barPositionX, tChildren[i].positionY))
            tChildren[i].positionY = nil
        end
        local newPositionY = tChildren[i]:getPositionY() - nCutHeight
        
        tChildren[i]:setPosition(cc.p(barPositionX, newPositionY))
        
        if i >= nIndex then
            newPositionY = newPositionY + barSize.height
            if i <= nMaxShowIndex then
                tChildren[i].positionY = newPositionY
                tChildren[i]:runAction(cc.Sequence:create( cc.MoveTo:create(0.3 , cc.p(barPositionX, newPositionY))))
            else
                tChildren[i]:setPosition(cc.p(barPositionX, newPositionY))
            end
        end
    end

    scrollView:setInnerContainerSize(cc.size(contentSize.width, innerHeight - nCutHeight))
    innerContainer:setPosition(positionX, positionY)
end

function KUtil.PlayClearScrollViewAnimation(scrollView)
    local CLOSE_FRAME      = 36
    local tChildren        = scrollView:getChildren()
    if #tChildren == 0 then return end
    local scrollViewHeight = scrollView:getContentSize().height
    local innerPositionY   = scrollView:getInnerContainer():getPositionY()
    local barHeight        = tChildren[1]:getContentSize().height      
    for _, cardBar in ipairs(tChildren) do
        local positionY = cardBar.positionY or cardBar:getPositionY() + innerPositionY
        if cardBar.nID ~= 0 and positionY > -barHeight and positionY < scrollViewHeight then
            local nodeBase                  = cc.Node:create()
            local nodeAnimationRemoveUnit   = cc.CSLoader:createNode("res/ui/animation_node/ani_break_machine.csb")
            local removeUnitAnimation       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_break_machine.csb")
            local panelRemove               = nodeAnimationRemoveUnit:getChildByName("Panel_break_machine")
            local panelRemoveLeft           = panelRemove:getChildByName("Panel_break_machine_left")
            local imageRemove               = panelRemoveLeft:getChildByName("Image_jt_empty_left")
            local sizeAnimation             = imageRemove:getContentSize()
            sizeAnimation.width = sizeAnimation.width * 2
            nodeBase:addChild(nodeAnimationRemoveUnit)
            cardBar:addChild(nodeBase)
            nodeAnimationRemoveUnit:stopAllActions()
            local sizeBase = cardBar:getContentSize()
            nodeAnimationRemoveUnit:setPosition(sizeBase.width / 2, sizeBase.height / 2)
            nodeAnimationRemoveUnit:setScaleX(sizeBase.width / sizeAnimation.width)
            nodeAnimationRemoveUnit:setScaleY(sizeBase.height / sizeAnimation.height)
            nodeAnimationRemoveUnit:runAction(removeUnitAnimation)
            removeUnitAnimation:gotoFrameAndPlay(0, CLOSE_FRAME, false)

            local function playEffect()
                for _, node in ipairs(cardBar:getChildren()) do
                    node:setVisible(node == nodeBase)
                end
                nodeAnimationLight   = cc.CSLoader:createNode("res/ui/animation_node/ani_break_machine_effert.csb")
                -- nodeAnimationLight:setPosition(sizeBase.width / 2, sizeBase.height / 2)
                nodeAnimationRemoveUnit:addChild(nodeAnimationLight)
            end

            delayExecute(nodeBase, playEffect, 14 / 60)
        end
    end
    return 14 / 60 + 1.6
end

function KUtil.addDynamicScrollView(parameters)
    local scrollView   = parameters.scrollView
    local slideView    = parameters.slideView
    local itemBase     = parameters.itemBase
    local column       = parameters.column or 1
    local row          = parameters.row or KUtil.SHOW_LIST_SIZE
    local spanX        = parameters.spanX or 0 
    local spanY        = parameters.spanY or 0 
    local dataList     = parameters.dataList
    local refreshCall  = parameters.refreshCall
    local isCutIn      = parameters.isCutIn
    local onScroll     = parameters.onScroll
    local isHorizontal = parameters.isHorizontal

    -- TODO cancel the event
    if slideView then
        local function onSlideChange(sender, type)
        end
        slideView:addEventListener(onSlideChange)
    end

    local function onScrollChange(sender, type)
    end
    scrollView:addEventListener(onScrollChange)

    local itemList   = {}
    local listSize   = #dataList
    local showSize   = column * row
    local children   = scrollView:getChildren()
    for index = 1, showSize do
        local control = children[index] 
        if not control and index <= listSize then
            control = itemBase:clone()
            scrollView:addChild(control)
        end
        if control then
            control:setName("0")
            control:setVisible(false)
            control:setAnchorPoint(0, 0)
            table.insert(itemList, control)
        end
    end

    if isHorizontal then
        scrollView:jumpToPercentHorizontal(0)
    else
    scrollView:jumpToPercentVertical(0)
    end
    if slideView then slideView:setPercent(0) end

    local contentSize  = scrollView:getContentSize()
    local itemSize     = itemBase:getContentSize() 
    itemSize.height    = itemSize.height * itemBase:getScaleY()
    itemSize.width     = itemSize.width * itemBase:getScaleX()

    local totalHeight  = 0
    local totalWidth   = 0
    local position     = {}

    if isHorizontal then
        local columnCount = math.ceil(listSize / row)
        totalWidth  = itemSize.width * columnCount + (columnCount - 1) * spanX
        if totalWidth < contentSize.width then
            totalWidth = contentSize.width
        end
        scrollView:setInnerContainerSize(cc.size(totalWidth, contentSize.height))

        contentSize    = scrollView:getContentSize()
        local middleY  = (contentSize.height - itemSize.height) / 2
        local startY   = middleY - math.floor(itemSize.height * (row - 1) / 2) - math.floor(spanY * (row - 1) / 2)
        for index = 1, listSize do
            local columnIndex = math.ceil(index / row)
            local rowIndex    = (index - 1) % row + 1
            local positionY   = startY + (rowIndex - 1) * (itemSize.height + spanY)
            local positionX   = (columnIndex - 1) * (itemSize.width + spanX)
            position[index]   = {x = positionX, y = positionY}
        end
    else
        local rowCount    = math.ceil(listSize / column)
        totalHeight       = itemSize.height * rowCount + (rowCount - 1) * spanY
    if totalHeight < contentSize.height then
        totalHeight = contentSize.height
    end
    scrollView:setInnerContainerSize(cc.size(contentSize.width, totalHeight))
    local contentSize    = scrollView:getContentSize()
    local middleX  = (contentSize.width - itemSize.width) / 2
    local startX   = middleX - math.floor(itemSize.width * (column - 1) / 2) - math.floor(spanX * (column - 1) / 2)
    for index = 1, listSize do
        local columnIndex = (index - 1) % column + 1
        local rowIndex    = math.ceil(index / column)
        local positionX   = startX + (columnIndex - 1) * (itemSize.width + spanX)
        local positionY   = totalHeight - rowIndex * (itemSize.height) - (rowIndex -1 ) * spanY
        position[index]   = {x = positionX, y = positionY}
    end
    end

    for index, control in ipairs(itemList) do
        local data         = dataList[index]
        local positionInfo = position[index]
        if not data then break end
        if refreshCall then refreshCall(control, data) end
        control:setName(tostring(data.nID))
        control:setPosition(positionInfo.x, positionInfo.y)
        control:setVisible(true)
    end

    local moveStartPositionX = totalWidth - contentSize.width - itemSize.width * 2
    local moveStartPositionY = totalHeight - contentSize.height - itemSize.height * 2

    for index, control in ipairs(itemList) do
        local data         = dataList[index]
        local positionInfo = position[index]
        if not data or not isCutIn then break end
        local positionX = positionInfo.x
        local positionY = positionInfo.y

        local movePositionX, movePositionY, distance = 0,0,0
        if isHorizontal then
            movePositionX, movePositionY = moveStartPositionX, positionY
            if positionX < moveStartPositionX then break end
            distance = math.abs(positionX - moveStartPositionX)
        else
            movePositionX, movePositionY = positionX, moveStartPositionY
        if positionY < moveStartPositionY then break end
            distance = math.abs(positionY - moveStartPositionY)
        end
        control:setPosition(movePositionX, movePositionY)

        local rowIndex  = math.ceil(index / column)
        local delayTime = 0.3 + rowIndex * 0.025
        control:runAction(
            cc.Sequence:create(
                cc.DelayTime:create(delayTime),
                cc.MoveTo:create(0.0004 * math.abs(distance) , cc.p(positionX, positionY))))
    end

    local innerContainer = scrollView:getInnerContainer()
    local innerPositionX = innerContainer:getPositionX()
    local innerPositionY = innerContainer:getPositionY()

    local dataInfo = {
        scrollView    = scrollView,
        itemBase      = itemBase,
        itemList      = itemList,
        position      = position,
        dataList      = dataList,
        refreshCall   = refreshCall,
        innerInitY    = innerPositionY,
        innerInitX    = innerPositionX,
        isHorizontal  = isHorizontal,
        firstIndex    = 1,
        column        = column,
        row           = row,
        spanX         = spanX,
        spanY         = spanY,
        itemSize      = itemSize,
        isRefresh     = false,
    }

    dataInfo.refreshList = function()
        dataInfo.isRefresh = true
        KUtil.refreshDynamicScrollView(dataInfo)
    end
    
    dataInfo.forceRefreshList = function()
        dataInfo.isRefresh   = true
        dataInfo.mustRefresh = true
        KUtil.refreshDynamicScrollView(dataInfo)
    end

    if slideView then
        local function onSlideChange(sender, type)
            if type == ccui.SliderEventType.percentChanged then
                if isHorizontal then
                    scrollView:jumpToPercentHorizontal(slideView:getPercent())
                else
                scrollView:jumpToPercentVertical(slideView:getPercent())
            end
            end
            dataInfo.isRefresh = true
            KUtil.refreshDynamicScrollView(dataInfo)
        end
        slideView:addEventListener(onSlideChange)
    end

    local function onScrollChange(sender, type)
        if onScroll then
            onScroll(sender, type)
        end
        if slideView then
            local percent = KUtil.getScrollViewPercent(scrollView)
            slideView:setPercent(percent)
        end
        dataInfo.isRefresh = true
        KUtil.refreshDynamicScrollView(dataInfo)
    end
    scrollView:addEventListener(onScrollChange)
    return dataInfo
end

function KUtil.refreshDynamicScrollView(dataInfo)
    if not dataInfo or not dataInfo.isRefresh then return end 
    dataInfo.isRefresh = false
    
    local scrollView   = dataInfo.scrollView
    local itemBase     = dataInfo.itemBase
    local isHorizontal = dataInfo.isHorizontal

    local innerContainer = scrollView:getInnerContainer()
    local innerPositionY = innerContainer:getPositionY()
    local innerPositionX = innerContainer:getPositionX()
    local itemSize       = dataInfo.itemSize

    local runningNode = {}
    local stratIndex, endIndex 
    if isHorizontal then
        local firstColumnPostion = math.floor((dataInfo.innerInitX - innerPositionX) / (itemSize.width + dataInfo.spanX)) + 1
        firstColumnPostion = math.max(firstColumnPostion, 1)
        if dataInfo.firstIndex == firstColumnPostion and not dataInfo.mustRefresh then return end

        dataInfo.mustRefresh  = false
        dataInfo.firstIndex   = firstColumnPostion

        local startColumeIndex  = firstColumnPostion - 1
        local endColumeIndex    = dataInfo.column + startColumeIndex - 1
        stratIndex     = (startColumeIndex - 1) * dataInfo.row + 1
        endIndex       = endColumeIndex * dataInfo.row
    else
    local firstRowPostion = math.floor((innerPositionY - dataInfo.innerInitY) / (itemSize.height + dataInfo.spanY)) + 1
    firstRowPostion = math.max(firstRowPostion, 1)
    if dataInfo.firstIndex == firstRowPostion and not dataInfo.mustRefresh then return end

    dataInfo.mustRefresh  = false
    dataInfo.firstIndex   = firstRowPostion

    local startRowIndex  = firstRowPostion - 1
    local endRowIndex    = dataInfo.row + startRowIndex - 1
        stratIndex     = (startRowIndex - 1) * dataInfo.column + 1
        endIndex       = endRowIndex * dataInfo.column
    end
    

    for index = stratIndex , endIndex do
        local data = dataInfo.dataList[index]
        if data then
            runningNode[tostring(data.nID)] = true
        end
    end 

    for index, control in ipairs(dataInfo.itemList) do
        local name = control:getName()
        if not runningNode[name] then
            control:setName("0")
            control:setVisible(false)
        end
    end

    for index = stratIndex , endIndex do
        local data         = dataInfo.dataList[index]
        local positionInfo = dataInfo.position[index]
        if data and positionInfo then
            local control = scrollView:getChildByName(tostring(data.nID))
            if not control then
                control = scrollView:getChildByName("0")
                if dataInfo.refreshCall then
                    dataInfo.refreshCall(control, data)
                    control:setName(tostring(data.nID))
                end
            end
            control:setPosition(positionInfo.x, positionInfo.y)
            control:setVisible(true)
        end
    end
end

function KUtil.playAnimation( projectNode,  szFileName, nStart, nEnd, fun)
    local unitAnimation = cc.CSLoader:createTimeline("res/ui/animation_node/"..szFileName..".csb")
    projectNode:stopAllActions()
    projectNode:runAction(unitAnimation)
    unitAnimation:gotoFrameAndPlay(nStart, nEnd, false)

    local function removeNode()
        unitAnimation:gotoFrameAndPause(nEnd)
        projectNode:stopAction(unitAnimation)
        if fun then
            fun()
        end
    end

    projectNode:stopActionByTag(10111)
    local delayAction = delayExecute(projectNode, removeNode, (nEnd - nStart) / KUtil.FRAME_PER_SECOND)
    delayAction:setTag(10111)
    return unitAnimation
end

function KUtil.playAnimationByAnimation(unitAnimation, nStart, nEnd, fun)
    local function callBack()
        unitAnimation:gotoFrameAndPause(nEnd)
        if fun then
            fun()
        end
    end

    unitAnimation:getTarget():stopActionByTag(10111)
    local delayAction = delayExecute(unitAnimation:getTarget(), callBack, (nEnd - nStart) / KUtil.FRAME_PER_SECOND)
    delayAction:setTag(10111)
    return KUtil.animationGotoFrameAndPlay(unitAnimation, nStart, nEnd, false)
end

function KUtil.getScrollViewPercent(scrollView)
    local contentSize      = scrollView:getContentSize()
    local innerContainer   = scrollView:getInnerContainer()
    local innerContentSize = innerContainer:getContentSize()
    local innerPositionY    = innerContainer:getPositionY()
    local minY = contentSize.height - innerContentSize.height
    local height = - minY
    local percert = (innerPositionY - minY)/height
    return percert * 100
end

function KUtil.getRingAttribute(card)
    local attribute = {} 
    if not card.bRing then return attribute end
    for _, info in pairs(card.tRingAttribute) do
        attribute[info.nIndex] = (attribute[info.nIndex] or 0) + info.nValue
    end
    return attribute
end

function KUtil.addRingAttribute(baseAttribute, addAttribute)
    local attribute = {}
    for nIndex, nValue in pairs(baseAttribute) do
        attribute[nIndex] = nValue + (addAttribute[nIndex] or 0)
    end
    return attribute
end

function KUtil.getRoleEquipFormat(card)
    local tList = KPlayer.tItemData.tEquipStoreHouse.tEquipList
    local equipMap = {}
    for k, v in pairs(tList) do
        equipMap[v.nID] = v
     end
    local cardEquipList = {}
    for i, item in pairs(card.tEquipList) do
        local equip = equipMap[item.nEquipID]
        if not equip then return cardEquipList end
        local oneEquip = {nPos = item.nPos, nTemplateID = equip.nTemplateID}
        table.insert(cardEquipList, oneEquip)
    end
    return cardEquipList
end

function KUtil.getCurrentAttribute(card, onlyCard, equipList)
    local maxLevel      = KUtil.getMaxLevel()
    local cardConfig    = KConfig.cardInfo[card.nTemplateID]
    local dodgeLevelAddtion  = math.ceil((cardConfig.nMaxDodge - cardConfig.nBaseDodge) / (maxLevel- 1) * (card.nLevel - 1))
    local attribute = {}
    attribute[ATTRIBUTE.HP]          = card.nCurrentHP            
    attribute[ATTRIBUTE.ATTACK]      = cardConfig.nBaseAttack      + card.nAddAttack  
    attribute[ATTRIBUTE.PENETRATE]   = cardConfig.nBasePenetrate   + card.nAddPenetrate   
    attribute[ATTRIBUTE.SPEED]       = cardConfig.nBaseSpeed       + card.nAddSpeed   
    attribute[ATTRIBUTE.FRONTARMOUR] = cardConfig.nBaseFrontArmour + card.nAddFrontArmour     
    attribute[ATTRIBUTE.REARARMOUR]  = cardConfig.nBaseRearArmour  + card.nAddRearArmour  
    attribute[ATTRIBUTE.SCOUT]       = cardConfig.nBaseScout       + card.nAddScout   
    attribute[ATTRIBUTE.DODGE]       = cardConfig.nBaseDodge       + card.nAddDodge + dodgeLevelAddtion
    attribute[ATTRIBUTE.HIDE]        = cardConfig.nBaseHide        + card.nAddHide    
    attribute[ATTRIBUTE.NIGHTBATTLE] = cardConfig.nBaseNightBattle + card.nAddNightBattle  
    attribute[ATTRIBUTE.MAX_HP]      = cardConfig.nBaseHP
    attribute[ATTRIBUTE.RANGE]       = cardConfig.nRange
    attribute[ATTRIBUTE.HITRATE]    = 0
    attribute[ATTRIBUTE.THUMPRATE]  = 0
    attribute[ATTRIBUTE.CRIT]       = 0

    local ringAttribute = KUtil.getRingAttribute(card)
    attribute = KUtil.addRingAttribute(attribute, ringAttribute)

    if onlyCard then return attribute end

    equipList = equipList or KUtil.getRoleEquipFormat(card)
    for i, item in pairs(equipList) do
        local equipConfig = KConfig.equipInfo[item.nTemplateID]

        attribute[ATTRIBUTE.HP]             = attribute[ATTRIBUTE.HP]          + equipConfig.nDuration          
        attribute[ATTRIBUTE.ATTACK]         = attribute[ATTRIBUTE.ATTACK]      + equipConfig.nAttack  
        attribute[ATTRIBUTE.PENETRATE]      = attribute[ATTRIBUTE.PENETRATE]   + equipConfig.nPenetrate   
        attribute[ATTRIBUTE.SPEED]          = attribute[ATTRIBUTE.SPEED]       + equipConfig.nSpeed   
        attribute[ATTRIBUTE.FRONTARMOUR]    = attribute[ATTRIBUTE.FRONTARMOUR] + equipConfig.nFrontArmour     
        attribute[ATTRIBUTE.REARARMOUR]     = attribute[ATTRIBUTE.REARARMOUR]  + equipConfig.nRearArmour  
        attribute[ATTRIBUTE.SCOUT]          = attribute[ATTRIBUTE.SCOUT]       + equipConfig.nScout   
        attribute[ATTRIBUTE.DODGE]          = attribute[ATTRIBUTE.DODGE]       + equipConfig.nDodge   
        attribute[ATTRIBUTE.HIDE]           = attribute[ATTRIBUTE.HIDE]        + equipConfig.nHide    
        attribute[ATTRIBUTE.NIGHTBATTLE]    = attribute[ATTRIBUTE.NIGHTBATTLE] + equipConfig.nNightBattle  
        attribute[ATTRIBUTE.CRIT]           = attribute[ATTRIBUTE.CRIT]        + equipConfig.nCrit
        attribute[ATTRIBUTE.HITRATE]        = attribute[ATTRIBUTE.HITRATE]     + equipConfig.nHitRate
        attribute[ATTRIBUTE.THUMPRATE]      = attribute[ATTRIBUTE.THUMPRATE]   + equipConfig.nThumpRate

        if item.nPos == 1 then
            attribute[ATTRIBUTE.RANGE]       = cardConfig.nRange
        end

    end
    return attribute
end

function KUtil.getMonsterAttribute(monsterID, onlyCard)
    local monsterSetting = KConfig:getLine("monster", monsterID)

    local attribute = {}
    attribute[ATTRIBUTE.HP]          = monsterSetting.nMaxHP            
    attribute[ATTRIBUTE.ATTACK]      = monsterSetting.nAttack
    attribute[ATTRIBUTE.PENETRATE]   = monsterSetting.nPenetrate   
    attribute[ATTRIBUTE.SPEED]       = monsterSetting.nSpeed
    attribute[ATTRIBUTE.FRONTARMOUR] = monsterSetting.nFrontArmour
    attribute[ATTRIBUTE.REARARMOUR]  = monsterSetting.nRearArmour
    attribute[ATTRIBUTE.SCOUT]       = monsterSetting.nScout
    attribute[ATTRIBUTE.DODGE]       = monsterSetting.nDodge
    attribute[ATTRIBUTE.HIDE]        = monsterSetting.nHide
    attribute[ATTRIBUTE.NIGHTBATTLE] = monsterSetting.nNightBattle
    attribute[ATTRIBUTE.MAX_HP]      = monsterSetting.nMaxHP
    attribute[ATTRIBUTE.RANGE]       = monsterSetting.nRange
    attribute[ATTRIBUTE.HITRATE]     = 0
    attribute[ATTRIBUTE.THUMPRATE]   = 0
    attribute[ATTRIBUTE.CRIT]        = 0

    if onlyCard then return attribute end

    local i = 0
    while true do
        i = i + 1
        local nEquipID = monsterSetting["nEquip" .. i]
        if not nEquipID then break end

        if nEquipID > 0 then
            local equipConfig = KConfig:getLine("equipInfo", nEquipID)

            attribute[ATTRIBUTE.CRIT]           = attribute[ATTRIBUTE.CRIT]        + equipConfig.nCrit
            attribute[ATTRIBUTE.HITRATE]        = attribute[ATTRIBUTE.HITRATE]     + equipConfig.nHitRate
            attribute[ATTRIBUTE.THUMPRATE]      = attribute[ATTRIBUTE.THUMPRATE]   + equipConfig.nThumpRate

            if i == 1 then
                attribute[ATTRIBUTE.RANGE] = equipConfig.nRange
            end
        end
    end

    return attribute
end

function KUtil.getTeamAttribute(teamIndex, onlyCard)
    local result = {}
    for _, v in pairs(ATTRIBUTE) do
        result[v] = 0
    end

    local cardList = KUtil.getOneTeamCardList(teamIndex)
    for _, card in ipairs(cardList) do
        local attribute = KUtil.getCurrentAttribute(card, onlyCard)
        for k, v in pairs(attribute) do
            result[k] = result[k] + v
        end
    end

    return result
end

function KUtil.getItemConfig(id)
    return KConfig:getLine("itemInfo", id)
end

function KUtil.getItemConfigValue(id1, id2)
    return KConfig:getValue("itemInfo", id1, id2)
end

function KUtil.getCardConfig(id)
    return KConfig:getLine("cardInfo",id)
end

function KUtil.getCardConfigValue(id1, id2)
    return KConfig:getValue("cardInfo", id1, id2)
end

function KUtil.getSkinConfigValue(id1, id2)
    return KConfig:getValue("skin", id1, id2)
end

function KUtil.getCardBreakConfig(id)
    return KConfig:getLine("cardbreakdowninfo", id)
end

function KUtil.getCardRepairPowerInfo(nTankType)
    return KConfig:getLine("cardrepairpowerinfo", nTankType)
end

function KUtil.getCardRepairRation(nCardLevel)
    local cardRepairRationList = KConfig.cardrepairratioinfo
    local ration = 1
    for _,v in ipairs(cardRepairRationList) do
        if nCardLevel >= v.nLevel then
            ration = v.nRatio
        end
    end
    
    return ration
end

function KUtil.getCardImageByTemplateID(templateID)  
    return "res/images/cards/"..KUtil.getCardConfigValue(templateID,"szResPath").."/NormalImage.png"
end

function KUtil.getProducingCardByIndex(index)
    return HArray.FindFirst(KPlayer.tCardData.tProducingList, "nIndex", index)
end

function KUtil.getProducingCardByID(nID)
    return HArray.FindFirstByID(KPlayer.tCardData.tProducingList, nID)
end

function KUtil.getProducingCardList()
    return KPlayer.tCardData.tProducingList
end

function KUtil.getRepairingCardList()
    return KPlayer.tCardData.tRepairingList
end

function KUtil.getRepairingCardByCradID(cardID)
    return HArray.FindFirst(KPlayer.tCardData.tRepairingList, "nCardID", cardID)
end

function KUtil.getProducingCardCount()
    return #KPlayer.tCardData.tProducingList
end

function KUtil.getBuildBarCount()
    return KPlayer.nBuildBarNum
end

function KUtil.getItemCount(nID)
    local count = 0
    for id,item in pairs(KPlayer.tItemData.tStoreHouse.tItemList) do
        if item.nTemplateID==nID then
            count = count+item.nCount
        end
    end
    return count
end

function KUtil.getGoodConfigByItem(itemID, count, itemType)
    count    = count or 1
    itemType = itemType or ITEM_TYPE.OTHER
    for _, v in pairs(KConfig["shop"]) do
        if v.nItemType == itemType and v.nItemID == itemID and v.nItemCount == count then
            return v
        end
    end
    return nil
end

function KUtil.getItemCountExceptCardMountItem(itemTemplateID)
    local count = KUtil.getItemCount(itemTemplateID)
    local cardList = KPlayer.tCardData.tStoreHouse.tCardList

    for _, oneCard in pairs(cardList) do
        if oneCard.nMountItemTemplateID == itemTemplateID then
            count = count - 1
        end
    end
    
    return count
end

function KUtil.getLeftTime(leftTime)
    if leftTime <= 0 then leftTime = 0 end

    local hour          = math.floor(leftTime / (60 * 60))
    local min           = math.floor(leftTime / 60 % 60)
    local sec           = math.floor(leftTime % 60)
    return string.format("%02d:%02d:%02d", hour, min, sec)
end

function KUtil.formatTime(leftTime)
    if leftTime <= 0 then leftTime = 0 end

    local Time          = leftTime + os.time()
    return os.date("%Y-%m-%d %H:%M:%S", Time)
end

function KUtil.getStringByKey(key)
    return KConfig:getValue("string", key, "szText")
end

function KUtil.formatStringByKey(key, ...)
    return string.format(KConfig:getValue("string", key, "szText"), ...)
end

function KUtil.getCurrencyNameByKey(key)
    return KConfig:getValue("string", currencyName[key], "szText")
end

function KUtil.getEquipDescriptionFormat(attributeList, format)
    local descriptionString = "" 
    for i, v in ipairs(attributeList) do
        local tempText = ""
        if v then
            if v[2] then
                tempText = v[1] .. v[2]
            else
                tempText = v[1]
            end
        end
        descriptionString = descriptionString .. format .. tempText
    end
    return descriptionString
end

function KUtil.getEquipDescription(equipTempletID)
    local tDescription = {}
    local equipConfig = KConfig.equipInfo[equipTempletID]
    local descriptionTable = 
    {
        {string = "duration",    value = equipConfig.nDuration},
        {string = "attack",      value = equipConfig.nAttack},
        {string = "penetrate",   value = equipConfig.nPenetrate},
        {string = "speed",       value = equipConfig.nSpeed},
        {string = "frontArmour", value = equipConfig.nFrontArmour},
        {string = "rearArmour",  value = equipConfig.nRearArmour},
        {string = "scout",       value = equipConfig.nScout},
        {string = "dodge",       value = equipConfig.nDodge},
        {string = "hide",        value = equipConfig.nHide},
        {string = "nightBattle", value = equipConfig.nNightBattle},
        {string = "rating",      value = equipConfig.nHitRate},
        {string = "crit",        value = equipConfig.nThumpRate},
    }
    for i,v in ipairs(descriptionTable) do
        if v.value and v.value > 0 then
            tDescription[#tDescription + 1] = {KUtil.getStringByKey("attribute."..v.string), "+" .. v.value}
        end
    end

    tDescription[#tDescription + 1] = {KUtil.getExtDescription(equipTempletID)}
    
    return tDescription
end

function KUtil.getExtDescription(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    return equipConfig.szParamDesc or ""
end

function KUtil.getSelectEquipList(cardTempletID, equipType)
    local usedMap = {}
    for _,card in ipairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        for _,item in ipairs(card.tEquipList) do
            usedMap[item.nEquipID] = true
        end
    end

    local showTable = {}
    local cardConfig = KConfig.cardInfo[cardTempletID]
    local tankType = cardConfig.nTankType
    for i,item in ipairs(KPlayer.tItemData.tEquipStoreHouse.tEquipList) do
        local equipConfig = KConfig.equipInfo[item.nTemplateID]
        if not usedMap[item.nID] then
            local canEnter = HArray.FindFirstByValue(equipConfig.lszTankType, tankType)
            if equipConfig.nEquipType == equipType and canEnter then
                table.insert(showTable, item)
            end
        end
    end
    return showTable
end

function KUtil.isSameTemplateCardInTeam(cardID, teamId, exceptIndex)
    local teamList = KPlayer.tTeamData.tTeamList
    local card = KUtil.getCardById(cardID)
    if not card then return false end
    local teamItem = HArray.FindFirst(teamList, "nIndex", teamId)
    if not teamItem then return false end
    for index, tCardID in pairs(teamItem.tCardIDList) do
        local tCard = KUtil.getCardById(tCardID)
        if not tCard then return false end
        local cardConfig1  = KConfig.cardInfo[tCard.nTemplateID]
        local cardConfig2  = KConfig.cardInfo[card.nTemplateID]
        if cardConfig1.nCardType == cardConfig2.nCardType and tCard.nID ~= card.nID and index ~= exceptIndex then
            return true
        end
    end
    return false
end

function KUtil.isFirstTeamChangeToEmpty(cardID, teamId, position)
    local teamList = KPlayer.tTeamData.tTeamList
    local teamItem = HArray.FindFirst(teamList, "nIndex", teamId)
    local isPositionEmpty = ((teamItem == nil or teamItem.tCardIDList[position] == nil) and teamId ~= 1)
    if isPositionEmpty then
        local firstTeamItem = HArray.FindFirst(teamList, "nIndex", 1)
        local isCardInFirstTeam = HArray.FindFirstByValue(firstTeamItem.tCardIDList, cardID)
        if isCardInFirstTeam and #firstTeamItem.tCardIDList == 1 then
            return true
        end
    end
    return false
end

function KUtil.getEquipAttributeByID(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    local attribute = {}
    attribute[ATTRIBUTE.HP]          = equipConfig.nDuration
    attribute[ATTRIBUTE.ATTACK]      = equipConfig.nAttack
    attribute[ATTRIBUTE.PENETRATE]   = equipConfig.nPenetrate
    attribute[ATTRIBUTE.SPEED]       = equipConfig.nSpeed
    attribute[ATTRIBUTE.FRONTARMOUR] = equipConfig.nFrontArmour
    attribute[ATTRIBUTE.REARARMOUR]  = equipConfig.nRearArmour 
    attribute[ATTRIBUTE.SCOUT]       = equipConfig.nScout
    attribute[ATTRIBUTE.DODGE]       = equipConfig.nDodge
    attribute[ATTRIBUTE.HIDE]        = equipConfig.nHide
    attribute[ATTRIBUTE.NIGHTBATTLE] = equipConfig.nNightBattle
    attribute[ATTRIBUTE.RANGE]       = equipConfig.nRange
    attribute[ATTRIBUTE.ACCURACY]    = equipConfig.nHitRate
    attribute[ATTRIBUTE.CRIT]        = equipConfig.nCrit
    return attribute
end

function KUtil.getEquipNameByID(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    local name = equipConfig.szName
    return name
end

function KUtil.getEquipGradeByID(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    local grade = equipConfig.nGrade
    return grade
end

function KUtil.getEquipTypeByID(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    local type = equipConfig.nEquipType
    return type
end

function KUtil.getEquipImagePathByID(equipID)
    local equipConfig = KConfig.equipInfo[equipID]
    if not equipConfig then cclog("equip info not found! equipID=:" .. equipID) end
    return "res/images/equip/" .. equipConfig.szResPath .. "/1.png"
end

function KUtil.getItemImagePathByID(itemID)
    local itemConfig = KConfig.itemInfo[itemID]
    if not itemConfig then cclog("item info not found! itemID=:" .. itemID) end
    return "res/images/item/" .. itemConfig.szResPath .. "/1.png"
end

function KUtil.getCurrencyImagePath(currencyID)
    return currencyPath[currencyID]
end

function KUtil.getMedalImagePath(config)
    return "res/images/medal/" .. config.szResPath .. ".png"
end

function KUtil.getSPSignImagePath(signIdx)
    local signConfig = KConfig.spSign[signIdx]
    assert(signConfig, "spSign info not found! signIdx:" .. signIdx)
    return "res/images/item/" .. signConfig.szResPath .. "/1.png"
end

function KUtil.getSkinImagePathByID(skinTemplateID, cardTempletID)
    local skinConfig = KConfig.skin[skinTemplateID]
    local resPath = ""

    if not skinConfig then
        local cardConfig = KConfig.cardInfo[cardTempletID]
        if cardConfig.szDefaultSkinImagePath == "" then
            resPath = "res/images/item/cloth/" .. cardConfig.szResPath .. ".png"
        else
            resPath = "res/images/item/cloth/" .. cardConfig.szDefaultSkinImagePath .. ".png"
        end
    else
        resPath = "res/images/item/cloth/" .. skinConfig.szImagePath .. ".png"
    end

    return resPath
end

function KUtil.getCurrentServerTime()
    local passTime = KUtil.getLocalTime() - KPlayer.syncClientTime
    local currentServerTime = KPlayer.currentServerTime + passTime
    return currentServerTime
end

function KUtil.getLocalTime()
    return os.time()
end

function KUtil.getServerTime(nowTime)
    return nowTime + KPlayer.currentServerTime - KPlayer.syncClientTime
end

local function getCardSupplyData(card)
    local maxCarryOil   = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]    
    local maxCarryAmmo  = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
    local needOil       = maxCarryOil - card.nCurrentOil 
    local needAmmo      = maxCarryAmmo - card.nCurrentAmmo

    return needOil, needAmmo
end

function KUtil.getSkillSupplyData()
    local tCost     =   {
        needOil     = 0, maxOil = 0,
        needAmmo    = 0, maxAmmo = 0,
        needSteel   = 0, maxSteel = 0,
        needSpammo  = 0, maxSpammo = 0,
    }

    for _, oneSkill in pairs(KPlayer.tSkillList) do
        local equipItem   = KUtil.getEquipById(oneSkill.nEquipID)  
        assert(equipItem, "equipItem is nil " .. oneSkill.nEquipID)

        local equipConfig = KConfig.equipInfo[equipItem.nTemplateID]
        assert(equipConfig, "equipConfig is nil " .. equipItem.nTemplateID)
        local nNeedAddNum = equipConfig.nUseTime - oneSkill.nLeftTimes
        if nNeedAddNum > 0 then
            tCost.needOil     = tCost.needOil       + equipConfig.nCostOil * nNeedAddNum
            tCost.needAmmo    = tCost.needAmmo      + equipConfig.nCostAmmo * nNeedAddNum
            tCost.needSteel   = tCost.needSteel     + equipConfig.nCostSteel * nNeedAddNum
            tCost.needSpammo  = tCost.needSpammo    + equipConfig.nCostPeople * nNeedAddNum
        end

        tCost.maxOil     = tCost.maxOil       + equipConfig.nCostOil * equipConfig.nUseTime
        tCost.maxAmmo    = tCost.maxAmmo      + equipConfig.nCostAmmo * equipConfig.nUseTime
        tCost.maxSteel   = tCost.maxSteel     + equipConfig.nCostSteel * equipConfig.nUseTime
        tCost.maxSpammo  = tCost.maxSpammo    + equipConfig.nCostPeople * equipConfig.nUseTime
    end

    return tCost
end

function KUtil.getTotalSupplyData(teamID, bSupplySkill)
    local needOil       =   0
    local needAmmo      =   0
    local needSteel     =   0
    local needSpammo    =   0
    local cardIDList    = KUtil.getOneTeamCardList(teamID)

    for _, card in pairs(cardIDList) do
        local cardNeedOil           =   0
        local cardNeedAmmo          =   0

        cardNeedOil, cardNeedAmmo   = getCardSupplyData(card)

        needOil     =   needOil  + cardNeedOil
        needAmmo    =   needAmmo + cardNeedAmmo
    end

    if bSupplySkill then
        local tSkillCost = KUtil.getSkillSupplyData()
        needOil     = needOil       + tSkillCost.needOil
        needAmmo    = needAmmo      + tSkillCost.needAmmo
        needSteel   = needSteel     + tSkillCost.needSteel
        needSpammo  = needSpammo    + tSkillCost.needSpammo
    end

    return needOil, needAmmo, needSteel, needSpammo
end

function KUtil.needRepairCardID()
    local oneCardList = KUtil.getCardList()
    for _, v in ipairs(oneCardList) do
        local cardMaxHP = KUtil.getCardMaxHp(v)
        if v.nCurrentHP < cardMaxHP and (not KUtil.getRepairingCardByCradID(v.nID)) then
            if not KUtil.isCardInExpedition(v.nID) then
                return v.nID
            end
        end
    end
    return 0
end

function KUtil.needSupplyTeamID()
    local teamCount    = KPlayer.tTeamData.nOpenCount
    for teamID = 1, teamCount do
        local needOil, needAmmo, needSteel, needSpammo = KUtil.getTotalSupplyData(teamID, true)
        if needAmmo > 0 or needOil > 0 or needSteel > 0 or needSpammo > 0 then
            if not KUtil.isTeamInExpedition(teamID) then
                return teamID
            end
        end
    end
    return 0
end

function KUtil.isNeedRescue()
    local deadList      = KPlayer.tCardData.tDeadList
    local deadListCount = #deadList
    
    --local setting = require("src/logic/KSetting")
    --local userDeadCount = setting.getInt(setting.Key.DEAD_COUND)

    return deadListCount > 0-- userDeadCount
end

function KUtil.refreshRepairRedPoint(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local panelLabelButton  = imageCommon:getChildByName("Panel_label_button")
    local imageLabelBase    = panelLabelButton:getChildByName("Image_label_base")

    --repair red point
    local isCardNeedRepair  = (KUtil.needRepairCardID() ~= 0)
    local buttonRepair      = imageLabelBase:getChildByName("Button_1")
    local projectNodeRepair = buttonRepair:getChildByName("ProjectNode_notice")
    projectNodeRepair:setVisible(isCardNeedRepair)

    --supply red point
    local isNeedSupply      = (KUtil.needSupplyTeamID() ~= 0)
    local buttonSupply      = imageLabelBase:getChildByName("Button_2")
    local projectNodeSupply = buttonSupply:getChildByName("ProjectNode_notice")
    projectNodeSupply:setVisible(isNeedSupply)

    --rescue red point
    local isNeedRescue      = KUtil.isNeedRescue()
    local buttonRescue      = imageLabelBase:getChildByName("Button_3")
    local projectNodeRescue = buttonRescue:getChildByName("ProjectNode_notice")
    projectNodeRescue:setVisible(isNeedRescue)
end

function KUtil.getOneExpeditionData(nType, nTemplateID)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    for i, oneExpedition in ipairs(expeditionList) do
        if oneExpedition.nTemplateID == nTemplateID and oneExpedition.nType == nType then
            return oneExpedition
        end
    end
end

function KUtil.removeExpedition(nType, nTemplateID)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    for i, oneExpedition in ipairs(expeditionList) do
        if oneExpedition.nTemplateID == nTemplateID and oneExpedition.nType == nType then
            table.remove(expeditionList, i)
            return oneExpedition
        end
    end
end

function KUtil.getExpeditionConfig(nType, nTemplateID)
    local nTemplateType = nType .. "-" .. nTemplateID
    return KConfig.expedition[nTemplateType]
end

function KUtil.getExpeditionTableKey(nType, nTemplateID)
    return nType .. "-" .. nTemplateID
end

function KUtil.getExpeditionMap()
    local showMapData = {}
    local areaLastIDList = KPlayer.tExpeditionData.tAreaLastIDList
    for _, lastIDInfo in pairs(areaLastIDList) do
        local nType = lastIDInfo.nType
        for nTemplateID = 1, lastIDInfo.nTemplateID do
            local key = KUtil.getExpeditionTableKey(nType, nTemplateID)
            local itemConfig = KUtil.getExpeditionConfig(nType, nTemplateID)
            showMapData[key] = itemConfig
        end
    end
    return showMapData
end

function KUtil.getExpeditionLeftTime(nType, nTemplateID)
    local configInfo = KUtil.getExpeditionConfig(nType, nTemplateID)
    local expedition = KUtil.getOneExpeditionData(nType, nTemplateID)
    if not expedition then return 0 end
    local serverTime = KUtil.getCurrentServerTime()
    local leftTime = expedition.nEndTime - serverTime
    local leftTime = math.max(leftTime, 0)
    return leftTime
end

function KUtil.getExpeditionStatus(tType, tTemplateID)
    local expedition = KUtil.getOneExpeditionData(tType, tTemplateID)
    if not expedition then
        return EXPEDITION_STATUS.NOTSTART
    end
    local leftTime = KUtil.getExpeditionLeftTime(tType, tTemplateID)
    if leftTime <= 0  then
        return EXPEDITION_STATUS.CANGET
    else
        return EXPEDITION_STATUS.RUNNING
    end
end

function KUtil.getExpeditionTankTypeString(configInfo)
    local conditionTable = configInfo.tCondition
    local tTankType, tTankCount, tTypeString
    local conditionString = ""
    if configInfo.nLeaderType ~= 0 then
        tTypeString     = CARD_TYPE_NAME[configInfo.nLeaderType]
        conditionString = "队长:" .. tTypeString .. " "
    end
    for _, typeInfo in ipairs(conditionTable) do
        tTankType       = typeInfo[1]
        tTankCount      = typeInfo[2]
        tTypeString     = CARD_TYPE_NAME[tTankType]
        conditionString = conditionString .. tTypeString .. "X" .. tTankCount .. " "
    end
    return conditionString
end

function KUtil.getRewardItemPathAndScale(nType, nID)
    if nType == ITEM_TYPE.CURRENCY then
        return currencyPath[nID], 0.5, true
    elseif nType == ITEM_TYPE.CARD then
        local cardConfig  = KConfig.cardInfo[nID]
        local filePath = "res/images/cards/"..cardConfig.szResPath.."/Icon.png"
        local nScale   = 1
        local clipping = true
        if not cc.FileUtils:getInstance():isFileExist(filePath) then
            filePath = "res/images/cards/"..cardConfig.szResPath.."/NormalImage.png"
            nScale   = 0.1
            clipping = false
        end
        return filePath, nScale, clipping
    elseif nType == ITEM_TYPE.EQUIP then
        local filePath = KUtil.getEquipImagePathByID(nID)
        return filePath, 0.18, true
    elseif nType == ITEM_TYPE.OTHER then
        local filePath = KUtil.getItemImagePathByID(nID)
        return filePath, 0.6, true
    elseif nType == ITEM_TYPE.FURNITURE then
        local tConfigInfo = KConfig.furniture[nID]
        local filePath = KUtil.getFurniturePath(nID, true)
        if tConfigInfo.nType == FURNITURE_TYPE.FURNITURE_LEFT then
            return filePath, 0.15, true
        end
        if tConfigInfo.nType == FURNITURE_TYPE.FURNITURE_RIGHT then
            return filePath, 0.15, true
        end
        return filePath, 0.2, true
    elseif nType == ITEM_TYPE.SKIN then
        local filePath = KUtil.getSkinImagePathByID(nID)
        return filePath, 0.6, true
    end
end

function KUtil.getItemName(nType, nID)
    if nType == ITEM_TYPE.CURRENCY then
        return KUtil.getStringByKey(currencyName[nID])
    elseif nType == ITEM_TYPE.CARD then
        local cardConfig  = KConfig.cardInfo[nID]
        local awardName = cardConfig["szName"]
        return awardName
    elseif nType == ITEM_TYPE.EQUIP then
        local awardName = KConfig.equipInfo[nID]["szName"]
        return awardName
    elseif nType == ITEM_TYPE.OTHER then
        local awardName = KConfig.itemInfo[nID]["szName"]
        return awardName
    elseif nType == ITEM_TYPE.FURNITURE then
        local awardName = KConfig.furniture[nID]["szName"]
        return awardName
    elseif nType == ITEM_TYPE.SKIN then
        local awardName = KConfig.skin[nID]["szName"]
        return awardName
    end
end

function KUtil.getRewardList(nID, nType)
    local rewardInfo     = KConfig.reward[nID]
    local rewardList     = {}
    if rewardInfo == nil then return rewardList end

    local rewardInfoList = rewardInfo.tList
    for i, v in ipairs(rewardInfoList) do
        if nType == nil or v.nType == nType then
            table.insert(rewardList, v)
        end
    end
    
    return rewardList
end

function KUtil.isTeamInExpedition(tTeamID)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    for i, oneExpedition in pairs(expeditionList) do
        if oneExpedition.nTeamID == tTeamID then
            return true
        end
    end
    return false
end

function KUtil.isCardInExpedition(tCardID)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    local teamList = KPlayer.tTeamData.tTeamList
    local enterTeam = {}
    for i, oneExpedition in pairs(expeditionList) do
        enterTeam[oneExpedition.nTeamID] = true
    end
    
    for tTeamID, isTrue in pairs(enterTeam) do
        local oneTeam = HArray.FindFirst(teamList, "nIndex", tTeamID)
        if oneTeam then 
            local oneCardID = HArray.FindFirstByValue(oneTeam.tCardIDList, tCardID)
            if oneCardID then return true end
        end
    end
    return false
end

function KUtil.isCardInRepairList(tCardID)
    local repairList    = KPlayer.tCardData.tRepairingList
    local repairFlag    = false

    for _, repairCard in ipairs(repairList) do
        if repairCard.nCardID == tCardID then
            repairFlag = true
            break 
        end
    end  
    return repairFlag  
end

function KUtil.isEnoughEquipStore(cardNum)
    local equipStoreSize  = KPlayer.tItemData.tEquipStoreHouse.nMaxSize
    local allEquipsCount  = #KPlayer.tItemData.tEquipStoreHouse.tEquipList
    local equipNeedNum    = 4 * cardNum
    local equipNum = allEquipsCount + equipNeedNum
    if equipNum > equipStoreSize then return false end
    return true
end

function KUtil.GetCardSpaceCount()
    local tStoreHouse = KPlayer.tCardData.tStoreHouse
    return tStoreHouse.nMaxSize - #tStoreHouse.tCardList
end

function KUtil.GetEquipSpaceCount()
    local tStoreHouse = KPlayer.tItemData.tEquipStoreHouse
    return tStoreHouse.nMaxSize - #tStoreHouse.tEquipList
end

function KUtil.GetItemSpaceCount()
    local tStoreHouse = KPlayer.tItemData.tStoreHouse
    return tStoreHouse.nMaxSize - #tStoreHouse.tItemList
end

function KUtil.ItemNeedSpaceCount(nTemplateID, nCount)
    local tTemplateInfo = KUtil.getItemConfig(nTemplateID)
    assert(tTemplateInfo, nTemplateID)

    assert(nCount >= 0)

    if nCount == 0 then
        return 0
    end

    local nStackCount = tTemplateInfo.nStackCount
    local tStoreHouse = KPlayer.tItemData.tStoreHouse
    local tItemList   = tStoreHouse.tItemList
    for i, tOneItem in ipairs(tItemList) do
        if tOneItem.nTemplateID == nTemplateID and tOneItem.nCount < nStackCount then
            nCount = nCount - (nStackCount - tOneItem.nCount)
            if nCount <= 0 then
                return 0
            end
        end
    end
    return math.ceil(nCount/nStackCount)
end

function KUtil.CanAddItems(tItemList)
    local nNeedCount = 0
    for nTemplateID, nCount in pairs(tItemList) do
        nNeedCount   = nNeedCount + KUtil.ItemNeedSpaceCount(nTemplateID, nCount)
    end
    local tStoreHouse = KPlayer.tItemData.tStoreHouse
    return nNeedCount + #tStoreHouse.tItemList <= tStoreHouse.nMaxSize 
end

function KUtil.GetOneCardInitEquipCount(nTemplateID)
    local tCardConfig = KUtil.getCardConfig(nTemplateID)
    assert(tCardConfig)
    local nInitEquipCount = 0
    local nIndex = 1
    while true do
        local szInitEquipKey = string.format("nInitEquip%d", nIndex)
        if not tCardConfig[szInitEquipKey] then break end
        if tCardConfig[szInitEquipKey] ~= 0 then
            nInitEquipCount  = nInitEquipCount + 1
        end
        nIndex = nIndex + 1
    end
    return nInitEquipCount
end

function KUtil.CanSuperAddItems(tItemList)
    local needCardSpace, needEquipSpace = 0, 0, 0
    local otherList = {}
    for _, info in ipairs(tItemList) do
        local nTemplateID = info["nID"]
        local nItemType   = info["nType"]
        local nCount      = info["nNum"]
        if nItemType == ITEM_TYPE.CARD then
            needCardSpace = needCardSpace + nCount
            if needCardSpace > KUtil.GetCardSpaceCount() then
                return "common.CardStoreFull"
            end 

            -- init equip
            local nInitEquipCount = KUtil.GetOneCardInitEquipCount(nTemplateID)
            nInitEquipCount = nInitEquipCount * nCount
            needEquipSpace = needEquipSpace + nInitEquipCount
            if needEquipSpace > KUtil.GetEquipSpaceCount() then
                return "common.EquipStoreFull"
            end  
        elseif nItemType == ITEM_TYPE.EQUIP then
            needEquipSpace = needEquipSpace + nCount
            if needEquipSpace > KUtil.GetEquipSpaceCount() then
                return "common.EquipStoreFull"
            end  
        elseif nItemType == ITEM_TYPE.OTHER then
            otherList[nTemplateID] = (otherList[nTemplateID] or 0) + nCount
        end
    end
    if not KUtil.CanAddItems(otherList) then
        return "common.ItemStoreFull"
    end 
end

function KUtil.getMissionConfig(id)
    return KConfig:getLine("mission",id)
end

function KUtil.addStrengthRingAttribute(card, attribute)
    if not card.bRing then return attribute end
    local ringAttribute = KUtil.getRingAttribute(card)
    attribute.attack      = attribute.attack      + (ringAttribute[ATTRIBUTE.ATTACK] or 0)
    attribute.penetrate   = attribute.penetrate   + (ringAttribute[ATTRIBUTE.PENETRATE] or 0)
    attribute.speed       = attribute.speed       + (ringAttribute[ATTRIBUTE.SPEED] or 0)
    attribute.frontArmour = attribute.frontArmour + (ringAttribute[ATTRIBUTE.FRONTARMOUR] or 0)
    attribute.rearArmour  = attribute.rearArmour  + (ringAttribute[ATTRIBUTE.REARARMOUR] or 0)
    attribute.scout       = attribute.scout       + (ringAttribute[ATTRIBUTE.SCOUT] or 0)
    attribute.hide        = attribute.hide        + (ringAttribute[ATTRIBUTE.HIDE] or 0)
    attribute.nightBattle = attribute.nightBattle + (ringAttribute[ATTRIBUTE.NIGHTBATTLE] or 0)
    return attribute
end

function KUtil.getBaseAttribute(card)
    local baseAtrribute = {
        attack          = KConfig["cardInfo"][card.nTemplateID]["nBaseAttack"],
        penetrate       = KConfig["cardInfo"][card.nTemplateID]["nBasePenetrate"],
        speed           = KConfig["cardInfo"][card.nTemplateID]["nBaseSpeed"],
        frontArmour     = KConfig["cardInfo"][card.nTemplateID]["nBaseFrontArmour"],
        rearArmour      = KConfig["cardInfo"][card.nTemplateID]["nBaseRearArmour"],
        scout           = KConfig["cardInfo"][card.nTemplateID]["nBaseScout"],
        hide            = KConfig["cardInfo"][card.nTemplateID]["nBaseHide"],
        nightBattle     = KConfig["cardInfo"][card.nTemplateID]["nBaseNightBattle"],
    }

    baseAtrribute = KUtil.addStrengthRingAttribute(card, baseAtrribute)
    return baseAtrribute
end

function KUtil.getMaxAttribute(card)
    local maxAtrribute  = {
        attack          = KConfig["cardInfo"][card.nTemplateID]["nMaxAttack"],
        penetrate       = KConfig["cardInfo"][card.nTemplateID]["nMaxPenetrate"],
        speed           = KConfig["cardInfo"][card.nTemplateID]["nMaxSpeed"],
        frontArmour     = KConfig["cardInfo"][card.nTemplateID]["nMaxFrontArmour"],
        rearArmour      = KConfig["cardInfo"][card.nTemplateID]["nMaxRearArmour"],
        scout           = KConfig["cardInfo"][card.nTemplateID]["nMaxScout"],
        hide            = KConfig["cardInfo"][card.nTemplateID]["nMaxHide"],
        nightBattle     = KConfig["cardInfo"][card.nTemplateID]["nMaxNightBattle"]
    }

    maxAtrribute = KUtil.addStrengthRingAttribute(card, maxAtrribute)
    return maxAtrribute
end

function KUtil.getCurrentAddtion(card)
    local currentAddtion    = {
        attack          = card.nAddAttack,
        penetrate       = card.nAddPenetrate,
        speed           = card.nAddSpeed,
        frontArmour     = card.nAddFrontArmour,
        rearArmour      = card.nAddRearArmour,
        scout           = card.nAddScout,
        hide            = card.nAddHide,
        nightBattle     = card.nAddNightBattle,
    }

    return currentAddtion
end

function KUtil.getCardAttribute(card)
    local tAtrribute = {
        attack          = KConfig["cardInfo"][card.nTemplateID]["nBaseAttack"]      + card.nAddAttack,
        penetrate       = KConfig["cardInfo"][card.nTemplateID]["nBasePenetrate"]   + card.nAddPenetrate,
        speed           = KConfig["cardInfo"][card.nTemplateID]["nBaseSpeed"]       + card.nAddSpeed,
        frontArmour     = KConfig["cardInfo"][card.nTemplateID]["nBaseFrontArmour"] + card.nAddFrontArmour,
        rearArmour      = KConfig["cardInfo"][card.nTemplateID]["nBaseRearArmour"]  + card.nAddRearArmour,
        scout           = KConfig["cardInfo"][card.nTemplateID]["nBaseScout"]       + card.nAddScout,
        hide            = KConfig["cardInfo"][card.nTemplateID]["nBaseHide"]        + card.nAddHide,
        nightBattle     = KConfig["cardInfo"][card.nTemplateID]["nBaseNightBattle"] + card.nAddNightBattle,
    }

    tAtrribute = KUtil.addStrengthRingAttribute(card, tAtrribute)
    return tAtrribute
end

function KUtil.delayShowList(nodeList, col, row)
    local pageSize = col * row
    local timeInterval = 0.1
    local baseTime = 0.2
    for index, node in ipairs(nodeList or {}) do
        if index <= pageSize then
            local currentRow = math.floor((index - 1)/col) + 1
            local time =  baseTime + timeInterval * (currentRow - 1)
            node:setScale(0.8)
            local scaleto = cc.ScaleTo:create(time, 1)
            node:runAction(scaleto)
        else
            break
        end
    end
end

function KUtil.getRandomOne(randomCollection)
    local totalWeights  = 0
    for k, v in ipairs(randomCollection) do
        totalWeights = totalWeights + v[2] * 100
    end
    
    if totalWeights < 1 then return randomCollection[1][1] end
    
    local randomValue = math.random(1, totalWeights)
    
    for _, v in ipairs(randomCollection) do 
         if randomValue <= (v[2] * 100) then 
            return v[1]
         end
         randomValue = randomValue - v[2] * 100
    end

    table.output(randomCollection, "randomCollection:")
    
    return randomCollection[1][1]
end

function KUtil.getBattleBackgroundImagePath(backgroundType, isNight)
    local imagePath = "res/images/fight/background/scene" .. backgroundType
    if isNight then imagePath = imagePath .. "_night" end
    imagePath = imagePath .. ".png"
    return imagePath
end

function KUtil.getBattleBackgroundType(zoneID, mapID, footholdID)
    local battleSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
    return battleSetting.nBackground
end

function KUtil.getBattleData()
    return KPlayer.tBattleData  
end

function KUtil.getBattleMapData(zoneID, mapID)
    local tBattleData = KUtil.getBattleData()
    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", zoneID)
    if not tOneBattleZoneData then
        return
    end

    return HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", mapID)
end

function KUtil.isNewCard(nTemplateID)
    local tHistoricalCardID = KPlayer.tCardData.tHistoricalCardID
    local isNew = true

    for index, cardID in ipairs(tHistoricalCardID) do
        if cardID == nTemplateID then
            isNew = false
            break
        end
    end
    return isNew
end

function KUtil.initAction(parentNode, uiName, actionPath)
    print("---------------->initAction", uiName, actionPath)

    local action    = cc.CSLoader:createTimeline(actionPath)
    local ui        = parentNode:getChildByName(uiName)

    ui:stopAllActions()
    ui:runAction(action)
    action:gotoFrameAndPause(0)

    return action
end

function KUtil.IsBigBroken(nCurrentHP, nMaxHP)
    return nCurrentHP / nMaxHP < BROKEN_LIMIT.BIG
end

function KUtil.IsMiddleBroken(nCurrentHP, nMaxHP)
    local hpPercent = nCurrentHP / nMaxHP 
    return  hpPercent < BROKEN_LIMIT.MIDDLE and hpPercent >= BROKEN_LIMIT.BIG
end

function KUtil.playRepairTalk(cardID)
    local card = KUtil.getCardById(cardID)
    if not card then return end
    local attribute     = KUtil.getCurrentAttribute(card, true)
    local currentHp     = attribute[ATTRIBUTE.HP]
    local maxHP         = KUtil.getCardMaxHp(card)
    local cardHPPercent = currentHp / maxHP
    if cardHPPercent <= BROKEN_LIMIT.MIDDLE then
        KSound.playTalk(KSound.TALK.MIDDLEREPAIR, card.nTemplateID)
    else
        KSound.playTalk(KSound.TALK.SMALLREPAIR, card.nTemplateID)
    end
end

function KUtil.playBrokenTalk(cardID, nNewHPPercent, nOldHPPercent, bIsRole)
    if nOldHPPercent > BROKEN_LIMIT.MIDDLE and nNewHPPercent <= BROKEN_LIMIT.MIDDLE and nNewHPPercent ~= 0 then
        KSound.playTalk(KSound.TALK.MIDDLEBREAK, cardID, not bIsRole)
    elseif nOldHPPercent > BROKEN_LIMIT.LITTLE and nNewHPPercent <= BROKEN_LIMIT.LITTLE and nNewHPPercent > BROKEN_LIMIT.MIDDLE then
        KSound.playTalk(KSound.TALK.SMALLBREAK1, cardID, not bIsRole)
    end
    if nNewHPPercent <= 0 then
        KSound.playTalk(KSound.TALK.BEWRECK, cardID, not bIsRole)
    end
end

function KUtil.makeInRange(nValue, tRange)
    if nValue < tRange[1] then
        return tRange[1]
    end

    if nValue > tRange[2] then
        return tRange[2]
    end

    return nValue
end

function KUtil.getMonsterData(monsterID, index)
    local monsterSetting = KConfig:getLine("monster", monsterID)
    local totolAtribute = KUtil.getMonsterAttribute(monsterID)

    local result = 
        {
            bLeftSide       = false,
            bIsRole         = false,
            nIndex          = index,
            nTemplateID     = monsterID,
            nNamedType      = monsterSetting.nType,
            tFuncTypeList   = monsterSetting.tFuncTypeList,
            bBrokenProtect  = false,
            nPos            = 1,
            nLevel          = monsterSetting.nLevel,  
            nCurrentHP      = totolAtribute[ATTRIBUTE.HP],
            nMaxHP          = totolAtribute[ATTRIBUTE.MAX_HP],
            nAttack         = totolAtribute[ATTRIBUTE.ATTACK],
            nPenetrate      = totolAtribute[ATTRIBUTE.PENETRATE],
            nSpeed          = totolAtribute[ATTRIBUTE.SPEED],
            nFrontArmour    = totolAtribute[ATTRIBUTE.FRONTARMOUR],
            nRearArmour     = totolAtribute[ATTRIBUTE.REARARMOUR],
            nScout          = totolAtribute[ATTRIBUTE.SCOUT],
            nDodge          = totolAtribute[ATTRIBUTE.DODGE],
            nHide           = totolAtribute[ATTRIBUTE.HIDE],
            nNightBattle    = totolAtribute[ATTRIBUTE.NIGHTBATTLE],
            nRange          = totolAtribute[ATTRIBUTE.RANGE],
            nCrit           = totolAtribute[ATTRIBUTE.CRIT],
            nHitRate        = totolAtribute[ATTRIBUTE.HITRATE],
            nThumpRate      = totolAtribute[ATTRIBUTE.THUMPRATE],
            nCarryAmmo      = 10,
            nCarryOil       = 10,
            nMaxAmmo        = 10,
            nMaxOil         = 10,
            bRing           = false,
            nEquip1         = monsterSetting.nEquip1,
            nEquip2         = monsterSetting.nEquip2,
            nEquip3         = monsterSetting.nEquip3,
            nEquip4         = monsterSetting.nEquip4,
            bScouted        = false,
            nMoral          = 49,
            nTotalDamage    = 0,
            tExtraProperty  = nil,
            tComboSkill     = nil,
            tLandmine       = nil,
        }

    return result
end

local function getSortedSkillList()
    local function sortByPosition(skill1, skill2)
        return skill1.nPos > skill2.nPos
    end

    local tNewSkillList = clone(KPlayer.tSkillList)
    table.sort(tNewSkillList, sortByPosition)

    for _, oneSkill in ipairs(tNewSkillList) do
        local equipData = KUtil.getEquipById(oneSkill.nEquipID)
        oneSkill.nEquipTemplateID = equipData.nTemplateID
        oneSkill.nState = SKILL_STATE.UNUSED
        oneSkill.nUsedTimes = 0
    end
    return tNewSkillList
end

function KUtil.createAbilityInstace(tTeammember)
    local nTemplateID       = tTeammember.nTemplateID
    local tAbilityList      = {}

    local tTrainingList = KPlayer.tTrainingList
    for _, oneTraining in pairs(tTrainingList) do
        if oneTraining.nTemplateID == nTemplateID then
            local tWarList = oneTraining.tWarList
            for _, warID in pairs(tWarList) do
                local configList    = KConfig.trainingCard[nTemplateID].tList
                local cardWardItem  = HArray.FindFirst(configList, "nWarID", warID)
                local nAbilityID    = cardWardItem.nSkill

                local tAbilityInfo  = KConfig.trainingSkill[nAbilityID]
                local szClassName   = "KAbility" .. tAbilityInfo.szClassName
                local szClassPath   = "src/battle/ability/cardAbility/" .. szClassName
                local oneAbilityInstance = require(szClassPath).new(nAbilityID, tTeammember)
                table.insert(tAbilityList, oneAbilityInstance)
            end
            break
        end
    end

    tTeammember.tAbilityList = tAbilityList
end

function KUtil.getCardBattleInfo(card, k)
    local totolAtribute     = KUtil.getCurrentAttribute(card, false)
    local equipList         = card.tEquipList

    local equipIDList       = {}
    for k, v in pairs(equipList) do
        local oneEquipData = KUtil.getEquipById(v.nEquipID)
        equipIDList[v.nPos]   = oneEquipData.nTemplateID
    end

    local tCardConfig = KConfig["cardInfo"][card.nTemplateID]
    local teammember = 
    {
        bLeftSide       = true,
        bIsRole         = true,
        nIndex          = k,
        nTemplateID     = card.nTemplateID,
        nNamedType      = tCardConfig["nTankType"],
        tFuncTypeList   = {tCardConfig["nTankType"]},
        bBrokenProtect  = true,
        nPos            = 1,
        nID             = card.nID,
        nLevel          = card.nLevel,
        nCurrentHP      = totolAtribute[ATTRIBUTE.HP],
        nMaxHP          = totolAtribute[ATTRIBUTE.MAX_HP],
        nAttack         = totolAtribute[ATTRIBUTE.ATTACK],
        nPenetrate      = totolAtribute[ATTRIBUTE.PENETRATE],
        nSpeed          = totolAtribute[ATTRIBUTE.SPEED],
        nFrontArmour    = totolAtribute[ATTRIBUTE.FRONTARMOUR],
        nRearArmour     = totolAtribute[ATTRIBUTE.REARARMOUR],
        nScout          = totolAtribute[ATTRIBUTE.SCOUT],
        nDodge          = totolAtribute[ATTRIBUTE.DODGE],
        nHide           = totolAtribute[ATTRIBUTE.HIDE],
        nNightBattle    = totolAtribute[ATTRIBUTE.NIGHTBATTLE],
        nRange          = totolAtribute[ATTRIBUTE.RANGE],
        nCrit           = totolAtribute[ATTRIBUTE.CRIT],
        nHitRate        = totolAtribute[ATTRIBUTE.HITRATE],
        nThumpRate      = totolAtribute[ATTRIBUTE.THUMPRATE],
        nCarryAmmo      = card.nCurrentAmmo,
        nCarryOil       = card.nCurrentOil,
        nMaxAmmo        = tCardConfig.nCarryAmmo,
        nMaxOil         = tCardConfig.nCarryOil,
        bRing           = card.bRing,
        nEquip1         = equipIDList[1] or 0,
        nEquip2         = equipIDList[2] or 0,
        nEquip3         = equipIDList[3] or 0,
        nEquip4         = equipIDList[4] or 0,
        bScouted        = false,
        nMoral          = 49,
        nTotalDamage    = 0,
    
        tExtraProperty  = nil,
        tComboSkill     = nil,
        tLandmine       = nil,

        nMiss           = 0,
        nBeHit          = 0,
        bBrokenAnimationPlayed  = false,
        nMountItemTemplateID    = card.nMountItemTemplateID,
        nSkinTemplateID = card.nSkinTemplateID or 0,
    }
    teammember.bBrokenProtect = (k == 1 and teamIndex == 1) or not KUtil.IsBigBroken(teammember.nCurrentHP, teammember.nMaxHP)

    KUtil.createAbilityInstace(teammember)

    return teammember
end

function KUtil.createLeftTeamInfo(teamIndex)
    local cardList   = KUtil.getOneTeamCardList(teamIndex)
    local tSkillList = getSortedSkillList()
    local leftTeam   =
    {
        playeID     = KPlayer.id,
        teamIndex   = teamIndex,
        szName      = KPlayer.name,
        canUseSkill = true,
        tSkillList  = tSkillList,
    }

    for k, card in ipairs(cardList) do
        leftTeam[k] = KUtil.getCardBattleInfo(card, k)
    end

    return leftTeam
end

function KUtil.createLeftMonsterInfo(nMonsterGroupID)
    local monsterGroupSetting = KConfig:getLine("monstergroup", nMonsterGroupID)
    local tSkillList = {}
    for nIndex = 1, MAX_SKILL_COUNT do
        local nEquipID = monsterGroupSetting["nEquip" .. nIndex]
        local tSkillUseRate = monsterGroupSetting["tSkillUseRate" .. nIndex]
        if nEquipID ~= 0 then
            local tEquipConfig = KConfig.equipInfo[nEquipID]
            if tEquipConfig then
                local oneSkill = {
                    ["nPos"]             = nIndex,
                    ["nLeftTimes"]       = 1,
                    ["nEquipTemplateID"] = nEquipID,
                    ["nState"]           = SKILL_STATE.UNUSED,
                    -- ["tSkillUseRate"]    = tSkillUseRate,
                    ["nUsedTimes"]       = 0,
                }
                table.insert(tSkillList, oneSkill)
            end
        end
    end

    if #tSkillList == 0 then
        tSkillList = getSortedSkillList()
    end

    local leftTeam   =
    {
        playeID     = KPlayer.id,
        -- teamIndex   = 1,
        nMonsterGroupID = nMonsterGroupID,
        szName      = KPlayer.name,
        canUseSkill = true,
        tSkillList  = tSkillList,
    }

    if #monsterGroupSetting.tMonsterList > 0 then
        for i, v in ipairs(monsterGroupSetting.tMonsterList) do
            leftTeam[i] = KUtil.getMonsterData(v, i)
            leftTeam[i].bLeftSide = true
            leftTeam[i].nMiss     = 0
            leftTeam[i].nBeHit    = 0
            leftTeam[i].nMountItemTemplateID = 0
            leftTeam[i].nSkinTemplateID      = 0
        end
        leftTeam[1].bBrokenProtect = true
    else
        local cardList  = KUtil.getOneTeamCardList(1)
        for k, card in ipairs(cardList) do
            leftTeam[k] = KUtil.getCardBattleInfo(card, k)
        end
    end
    return leftTeam
end

function KUtil.createRightRoleInfo(cardList, roleName, teamName, roleLevel)
    local rightTeam  =
    {
        name         = roleName,
        lineup       = KUtil.getRandomLineup(),
        currentLevel = roleLevel,
        teamName     = teamName,
    }

    for k, card in ipairs(cardList) do
        local totolAtribute     = KUtil.getCurrentAttribute(card, false, card.tEquipList)
        local equipList         = card.tEquipList

        local equipIDList       = {}
        for k, v in pairs(equipList) do
            equipIDList[v.nPos]   = v.nTemplateID
        end

        local tCardConfig = KConfig["cardInfo"][card.nTemplateID]
        local teammember = 
        {
            bLeftSide       = false,
            bIsRole         = true,
            nIndex          = k,
            nTemplateID     = card.nTemplateID,
            nNamedType      = tCardConfig["nTankType"],
            tFuncTypeList   = {tCardConfig["nTankType"]},
            bBrokenProtect  = false,
            nPos            = 1,
            nLevel          = card.nLevel,
            nCurrentHP      = totolAtribute[ATTRIBUTE.HP],
            nMaxHP          = totolAtribute[ATTRIBUTE.MAX_HP],
            nAttack         = totolAtribute[ATTRIBUTE.ATTACK],
            nPenetrate      = totolAtribute[ATTRIBUTE.PENETRATE],
            nSpeed          = totolAtribute[ATTRIBUTE.SPEED],
            nFrontArmour    = totolAtribute[ATTRIBUTE.FRONTARMOUR],
            nRearArmour     = totolAtribute[ATTRIBUTE.REARARMOUR],
            nScout          = totolAtribute[ATTRIBUTE.SCOUT],
            nDodge          = totolAtribute[ATTRIBUTE.DODGE],
            nHide           = totolAtribute[ATTRIBUTE.HIDE],
            nNightBattle    = totolAtribute[ATTRIBUTE.NIGHTBATTLE],
            nRange          = totolAtribute[ATTRIBUTE.RANGE],
            nCrit           = totolAtribute[ATTRIBUTE.CRIT],
            nHitRate        = totolAtribute[ATTRIBUTE.HITRATE],
            nThumpRate      = totolAtribute[ATTRIBUTE.THUMPRATE],
            nCarryAmmo      = card.nCurrentAmmo,
            nCarryOil       = card.nCurrentOil,
            nMaxAmmo        = tCardConfig.nCarryAmmo,
            nMaxOil         = tCardConfig.nCarryOil,
            bRing           = card.bRing,
            nEquip1         = equipIDList[1] or 0,
            nEquip2         = equipIDList[2] or 0,
            nEquip3         = equipIDList[3] or 0,
            nEquip4         = equipIDList[4] or 0,
            bScouted        = false,
            nMoral          = 49,
            nTotalDamage    = 0,
            tExtraProperty  = nil,
            tComboSkill     = nil,
            tLandmine       = nil,
	    nSkinTemplateID = card.nSkinTemplateID or 0,
        }
        rightTeam[k]         = teammember
    end

    return rightTeam
end

function KUtil.getBattleSetting(zoneID, mapID, footholdID)
    return KConfig:getLine("battle", zoneID, mapID, footholdID)
end

function KUtil.getRandomMonsterGroupID(zoneID, mapID, footholdID)
    local battleSetting = KUtil.getBattleSetting(zoneID, mapID, footholdID)
    local monsterGroupID = battleSetting.tEnemy[1][1]
    local totalWeight = 0
    local tValidEnemyGroups = {}
    local tMapSetting = KUtil.getBattleSetting(zoneID, mapID, 1)
    if tMapSetting.nMode == BATTLE_MAP_MODE.DIFFCULT2 then
        local battleMapSpecialData = KPlayer:GetBattleMapSpecialData(zoneID, mapID)
        for _, v in ipairs(battleSetting.tEnemy) do
            if v[3] == battleMapSpecialData.nDiffcult then
                table.insert(tValidEnemyGroups, v)
                totalWeight = totalWeight + v[2] * 100
            end
        end
    else
        local playerLevel = KPlayer.level
        for _, v in ipairs(battleSetting.tEnemy) do
           if playerLevel >= v[3] and playerLevel <= v[4] then
                table.insert(tValidEnemyGroups, v)
                totalWeight = totalWeight + v[2] * 100
           end 
        end
    end
    
    if #tValidEnemyGroups == 0 then
        return monsterGroupID
    end
    
    local randomValue = math.random(1, totalWeight)
    for _, v in ipairs(tValidEnemyGroups) do     
        if randomValue <= (v[2] * 100) then
            monsterGroupID = v[1]
            break
        end

        randomValue = randomValue - v[2] * 100       
    end

    return monsterGroupID
end

function KUtil.getRandomLineup()
    local validLineup = {}
    local i = 0
    while true do
        i = i + 1
        local lineupSetting = KConfig:getLine("lineup", i)
        if not lineupSetting then break end
        table.insert(validLineup, lineupSetting)
    end

    if #validLineup == 0 then
        return KConfig:getLine("lineup", 1)
    end

    local randomValue = math.random(#validLineup)
    return validLineup[randomValue]
end

function KUtil.getMonsterLineup(monsterGroupID)
    local monsterGroupSetting = KConfig:getLine("monstergroup", monsterGroupID)
    local monsterCount = #monsterGroupSetting.tMonsterList

    return KUtil.getRandomLineup()
end

function KUtil.createRightTeamInfo(zoneID, mapID, footholdID)
    local monsterGroupID = KUtil.getRandomMonsterGroupID(zoneID, mapID, footholdID)
    local monsterGroupSetting = KConfig:getLine("monstergroup", monsterGroupID)
    
    local battleSetting = KUtil.getBattleSetting(zoneID, mapID, footholdID)
    local footholdType = FOOTHOLD_TYPE[battleSetting.szFootholdType]

    local tSkillList = {}
    for nIndex = 1, MAX_SKILL_COUNT do
        local nEquipID = monsterGroupSetting["nEquip" .. nIndex]
        local tSkillUseRate = monsterGroupSetting["tSkillUseRate" .. nIndex]
        if nEquipID ~= 0 and #tSkillUseRate ~= 0 then
            local oneSkill = {
                ["nEquipTemplateID"] = nEquipID,
                ["tSkillUseRate"]    = tSkillUseRate,
                ["nUsedTimes"]       = 0,
            }
            table.insert(tSkillList, oneSkill)
        end
    end

    local rightTeam = 
    {
        monsterGroupID  = monsterGroupSetting.nID,
        name            = monsterGroupSetting.szName,
        lineup          = KUtil.getMonsterLineup(monsterGroupID),
        isBossFoothold  = (footholdType == FOOTHOLD_TYPE.BOSS),
        currentLevel    = 1,
        teamName        = KUtil.getStringByKey("exercise.enemyName"),
        tSkillList      = tSkillList,
    }

    for i, v in ipairs(monsterGroupSetting.tMonsterList) do
        rightTeam[i] = KUtil.getMonsterData(v, i)
    end

    return rightTeam
end

function KUtil.getBattleResultTeamData(leftTeam)

    local tResult = {}
    for _, v in ipairs(leftTeam) do
        local tOneCard = 
            {
                nID          = v.nID,
                nTemplateID  = v.nTemplateID,
                nCurrentHP   = v.nCurrentHP,
                nMiss        = v.nMiss,
                nBeHit       = v.nBeHit,
            }

        if not tOneCard.nCurrentHP then
            tOneCard.nCurrentHP = 1
        end

        table.insert(tResult, tOneCard)
    end

    tResult.nIndex = leftTeam.teamIndex

    return tResult
end

local function getAliveOrDeadCard(cardID)
    local currentCard = KUtil.getCardById(cardID)

    if not currentCard then
        local tDeadCardList = KPlayer.tCardData.tDeadList
        currentCard = HArray.FindFirstByID(tDeadCardList, cardID)
    end
    return currentCard
end

-- calculate card battleBefore level and exp
function KUtil.calculateCardList(cardList)
    local cardExpList = {}     
    for key, cardData in ipairs(cardList) do
        if cardData.nID then
            local currentCard  = getAliveOrDeadCard(cardData.nID)
            local currentExp   = currentCard.nCurrentExp
            local currentLevel = currentCard.nLevel
            
            local cardExp = currentExp - cardData.nAddExp
            while cardExp < 0 do
                currentLevel = currentLevel - 1
                cardExp      = cardExp + KConfig["levelInfo"][currentLevel]["nCardExp"]
            end

            local card = {nID = cardData.nID, batteBeforeExp = cardExp, batteBeforeLevel = currentLevel, upLevelExp = KConfig["levelInfo"][currentLevel]["nCardExp"]}
            table.insert(cardExpList, card)
        else
            local tMonsterConfig = KConfig.monster[cardData.nTemplateID]
            local card = {nTemplateID = cardData.nTemplateID, batteBeforeExp = 0, batteBeforeLevel = tMonsterConfig.nLevel, upLevelExp = 0}
            table.insert(cardExpList, card)
        end
    end
    return cardExpList
end

function KUtil.showBattleResult(zoneID, mapID, footholdID, battleResultData, leftTeam, isBigBroken)
    local tNewCardList = {}
    local function onGetCard(oneCardID, isNewCard)
        local cardData = {
            cardID = oneCardID,
            isNew  = isNewCard,
        }
        table.insert(tNewCardList, cardData)
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:registerEvent(eventDispatch.EventType.NET_NOTIFY_ADD_CARD, onGetCard)
    
    local tBattleResult = KUtil.requestFinishBattle(zoneID, mapID, footholdID, battleResultData, leftTeam)
    print("---------------->showBattleResult ")

    eventDispatch:unregisterEvent(eventDispatch.EventType.NET_NOTIFY_ADD_CARD, onGetCard)
    
    local nResultType       = tBattleResult.nResultType
    local nRoleExp          = tBattleResult.nRoleExp
    local tCardExpAward     = tBattleResult.tCardExpAward
    local tCardFeeling      = tBattleResult.tCardFeeling
    local tAwardList        = tBattleResult.tAwardList
    local nSrcDamagePercent = tBattleResult.nSrcDamagePercent
    local nDstDamagePercent = tBattleResult.nDstDamagePercent
    local tDstTeam          = battleResultData.nDstTeam
    local cardExpList       = KUtil.calculateCardList(tCardExpAward)
    local tMapPassAward     = tBattleResult.tMapPassAward 
    local tMapPassExtraAward = tBattleResult.tMapPassExtraAward

    local endCallback = createThreadResumeFunc()

    local battleSetting = KUtil.getBattleSetting(zoneID, mapID, footholdID)

    local showIfContinueFightUI = (#battleSetting.tBranches > 0 and isBigBroken == false)

    local currentScene = cc.Director:getInstance():getRunningScene()
    local battleNode   = currentScene:getNode("Battle")
    if battleNode then battleNode:setVisible(false) end
    local battlePrepareNode = currentScene:getNode("BattlePrepare")
    if battlePrepareNode then battlePrepareNode:setVisible(false) end

    local battleReportNode = currentScene:addNode("BattleReport")
    local reportData = 
    {
        zoneID                = zoneID,
        mapID                 = mapID,
        footholdID            = footholdID,
        -- teamIndex             = leftTeam.teamIndex,
        -- monsterGroupID        = leftTeam.nMonsterGroupID,
        endCallback           = endCallback,
        cardExpAward          = tCardExpAward,
        awardList             = tAwardList,
        tNewCardList          = tNewCardList,
        roleExp               = nRoleExp,
        resultType            = nResultType,
        srcDamagePercent      = nSrcDamagePercent,
        dstDamagePercent      = nDstDamagePercent,
        cardExpList           = cardExpList,
        srcTeam               = leftTeam,
        dstTeam               = tDstTeam,
        showIfContinueFightUI = showIfContinueFightUI,
        mapPassAward          = tMapPassAward,
        mapPassExtraAward     = tMapPassExtraAward,
        cardFeeling           = tCardFeeling,
        battleType            = battleNode._tBattleManager.tData.nbattleType
    }

    battleReportNode:setReportData(reportData)
    battleReportNode:refreshUI()

    local continueFight = coroutine.yield()
    currentScene:removeNode("BattleReport")
    KUtil.removeUnusedTextures()

    if battlePrepareNode then 
        battlePrepareNode:setVisible(true) 
        if continueFight then
            battlePrepareNode:playMapBackGroundMusic(false)
        end
    end

    return continueFight
end

function KUtil.requestFinishBattle(zoneID, mapID, footholdID, battleResultData, leftTeam)
    local nResultType   = battleResultData.nType
    local nProgress     = battleResultData.nProgress
    local nMVPCardID    = battleResultData.nMVPCardID
    local tTeamData     = KUtil.getBattleResultTeamData(leftTeam)
    local tKillMonsters = battleResultData.tKillMonsters
    local tSkillUsedData = battleResultData.tSkillUsedData
    local tDeadMonsters = battleResultData.tDeadMonsters
    local nRequestID = require("src/network/KC2SProtocolManager"):FinishBattle(zoneID, mapID, footholdID, nResultType, tTeamData, nMVPCardID, nProgress, tKillMonsters, tSkillUsedData, tDeadMonsters)

    local curThread = coroutine.running()

    local function cb(nResultType, nZoneID, nMapID, nFootholdID, nRoleExp, tCardExpAward, tCardFeeling, tAwardList, tMapPassAward, tMapPassExtraAward)
        local nRespondID = KPlayer:getRespondID()
        print("cb---------------------------------", nZoneID, nMapID, nFootholdID, nRequestID, nRespondID)
        -- if nRequestID ~= nRespondID then return end

        return coroutine.resume(curThread, nResultType, nRoleExp, tCardExpAward, tCardFeeling, tAwardList, tMapPassAward, tMapPassExtraAward)
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:registerEvent(eventDispatch.EventType.BATTLE_FINISHED, cb)

    local nResultType, nRoleExp, tCardExpAward, tCardFeeling, tAwardList, tMapPassAward, tMapPassExtraAward =  coroutine.yield()
    
    eventDispatch:unregisterEvent(eventDispatch.EventType.BATTLE_FINISHED, cb)

    local battleResult = 
        {
            nResultType       = nResultType,
            nRoleExp          = nRoleExp,
            tCardExpAward     = tCardExpAward,
            tCardFeeling      = tCardFeeling,
            tAwardList        = tAwardList,
            nSrcDamagePercent = battleResultData.nSrcDamagePercent,
            nDstDamagePercent = battleResultData.nDstDamagePercent,
            tMapPassAward     = tMapPassAward,
            tMapPassExtraAward= tMapPassExtraAward,
        }
    return battleResult
end

function KUtil.getRightListMaxLevel(rightTeam)
    local maxLevel = 0
    for index = 1, MAX_TEAM_CARD_COUNT do
        local cardInfo = rightTeam[index]
        if cardInfo then
            maxLevel = math.max(cardInfo.nLevel, maxLevel)
        end
    end
    return maxLevel
end

function KUtil.sensitiveWordHandle()
    local firstWordMap = {}

    for _, tOneLine in ipairs(KConfig.sensitiveword) do
        local name         = tOneLine.szText
        local wordList     = KUtil.splitChinese(name)
        local keyFirstWord = wordList[1].word

        if firstWordMap[keyFirstWord] == nil then
            firstWordMap[keyFirstWord] = {}
            table.insert(firstWordMap[keyFirstWord], name)
        else
            local exist   = false

            for _, value in ipairs(firstWordMap[keyFirstWord]) do
                if value == name then
                    exist = true
                    break
    end
            end

            if not exist then
                table.insert(firstWordMap[keyFirstWord], name)
            end
        end
    end

    KConfig.sensitiveword = firstWordMap
end

function KUtil.otherSettingHandle()
    local tOtherSetting = {}
    for _, tOneLine in pairs(KConfig.otherSetting) do
        local strKey  = tOneLine.szName
        local strValue = tOneLine.szValue

        local varValue = nil
        if string.startwith(strKey, "n") then
            if strValue == "" then
                varValue = 0
            else
                varValue = tonumber(strValue)
                assert(varValue, strValue)
            end
        elseif string.startwith(strKey, "sz") then
            varValue = strValue or ""
            varValue = string.gsub(varValue, "\\n", "\n")
        elseif string.startwith(strKey, "b") then
            if strValue == "" then
                varValue = false
            else
                varValue = tonumber(strValue)
                assert(varValue, strValue)
                varValue = varValue ~= 0
            end
        elseif string.startwith(strKey, "fun") then
            if strValue ~= "" then
                varValue = assert(load(strValue))
            end
        elseif string.startwith(strKey, "lsz") then
            if strValue ~= "" then
                varValue = assert(load("return ".. strValue))
                varValue = varValue()
            end
         elseif string.startwith(strKey, "an") then
            if strValue ~= "" then
                tValueList = string.split(strValue, "|")
                varValue = {}
                for _, v in ipairs(tValueList) do
                    table.insert(varValue, tonumber(v))
                end
            end
        elseif string.startwith(strKey, "t") then
            varValue = load("return {" .. strValue .. "}")()
        else
            assert(false, "Invalid Type of strKey " .. strKey)
        end
        tOtherSetting[strKey] = varValue
    end

     KConfig.otherSetting = tOtherSetting
end

function KUtil.rewardHandle()
    for nGroup, tInfo in pairs(KConfig.reward) do
        local tempInfo = {}
        tempInfo.nID   = tInfo.nID
        tempInfo.nType = tInfo.nType
        tempInfo.tList = {}
        for i = 0, 1000 do
            if not tInfo["nRate" .. i] then break end
            if tInfo["nRate" .. i] ~= 0 then
                local itemInfo = {}
                itemInfo.nType = tInfo["nType" .. i]
                itemInfo.nID   = tInfo["nID" .. i]
                itemInfo.nNum  = tInfo["nNum" .. i]
                itemInfo.nRate = tInfo["nRate" .. i]
                table.insert(tempInfo.tList, itemInfo)
            end
        end
        KConfig.reward[nGroup] = tempInfo
    end
end

function KUtil.trainingCardHandle()
    local nWarIndex, nWarID, nSkill, nCount
    local szWarID, szSkillID, szCount

    local configInfo = {}
    for k, v in pairs(KConfig.trainingCard) do
        configInfo[k] = configInfo[k] or {nID = k, szName = v.szName, tList = {}}
        nWarIndex = 1
        while(true) do
            szWarID   = string.format("nWar%d", nWarIndex)
            szSkillID = string.format("nSkill%d", nWarIndex)
            szCount   = string.format("nCount%d", nWarIndex)

            nWarID    = v[szWarID]
            nSkill    = v[szSkillID]
            nCount    = v[szCount]
            nWarIndex = nWarIndex + 1

            if not nWarID then break end
            if nWarID > 0 then
                table.insert(configInfo[k].tList, {nWarID = nWarID, nSkill = nSkill, nCount = nCount})
            end
        end
    end
    KConfig.trainingCard = configInfo
end

function KUtil.specialHandle(fileName)
    for _, tLine in pairs(KConfig[fileName]) do
        if tLine.otOpenTimes == nil then break end
        tLine.otOpenTimes = KUtil.openTimeProcessing(tLine.otOpenTimes)
    end
    if fileName == "sensitiveword" then KUtil.sensitiveWordHandle() end
    if fileName == "otherSetting"  then KUtil.otherSettingHandle() end
    if fileName == "reward"        then KUtil.rewardHandle() end
    if fileName == "trainingCard"  then KUtil.trainingCardHandle() end
end

function KUtil.getExpeditionItem(expeditionConfig)
    local rewardID = expeditionConfig.nRewardID
    local itemList = {}
    local resultList = {}
    local rewardInfo = KConfig.reward[rewardID]
    if rewardInfo then itemList = rewardInfo.tList end
    for _, item in ipairs(itemList) do
        if (item.nType == ITEM_TYPE.OTHER or item.nType == ITEM_TYPE.EQUIP) and item.nRate ~= 0 then
            table.insert(resultList, item)
            if #resultList == 2 then break end 
        end
    end
    return resultList
end

function KUtil.getExpeditionChooseTeam()
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    local teamMap        = {}
    for _, expedition in pairs(expeditionList) do
        teamMap[expedition.nTeamID] = true
    end

    local teamList = KPlayer.tTeamData.tTeamList
    for teamId = 2, MAX_TEAM_CARD_COUNT do
        local teamItem = HArray.FindFirst(teamList, "nIndex", teamId)
        if not teamMap[teamId] and teamItem and #teamItem.tCardIDList > 0 then
            return teamId
        end
    end
end

function KUtil.splitChinese(s)
    local result = {};
    local f = '[%z\1-\127\194-\244][\128-\191]*' --utf-8中文格式
    for v in s:gfind(f) do
        table.insert(result, {word = v,isChinese = (#v ~= 1)})
    end
    return result;
end

function KUtil.hasIllegalChar(name)
    local wordList = KUtil.splitChinese(name)
    for _, v in ipairs(wordList) do
        if not v.isChinese then
            if string.find(v.word, "[^%w]") then
                return true
            end
        end 
    end
    return false
end

function KUtil.hasSensitiveWord(str)
    local wordList     = KUtil.splitChinese(str) 
    local firstWordMap = KConfig.sensitiveword

    for _, tOneWord in ipairs(wordList) do
        local key = tOneWord.word

        if firstWordMap[key] ~= nil then
            for _, sensitiveword in ipairs(firstWordMap[key]) do
                if string.find(str, sensitiveword) then return true end
            end
        end 
    end

    return false
end

function KUtil.getExpeditionFinishArea() 
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    for _, expedition in pairs(expeditionList) do
        local configInfo = KUtil.getExpeditionConfig(expedition.nType, expedition.nTemplateID)
        if not expedition then return 0 end
        local serverTime = KUtil.getCurrentServerTime()
        local leftTime = expedition.nEndTime - serverTime
        local leftTime = math.max(leftTime, 0)
        if leftTime <= 0 then return configInfo.nType end
    end
    return 0
end

function KUtil.getMapLaunchCount(zoneID, mapID)
    local tSetting = KUtil.getBattleSetting(zoneID, mapID, 1)
    local tMapData = KUtil.getBattleMapData(zoneID, mapID)
    assert(tMapData)
    local nCount
    if tSetting.nDayCount and tSetting.nDayCount > 0 then
        if tMapData.nLastWinDay == GetDayIndex(KUtil.getCurrentServerTime()) then
            nCount = tSetting.nDayCount - tMapData.nWinCount
            if nCount < 0 then nCount = 0 end
        else
            nCount = tSetting.nDayCount
        end
    end
    return nCount
end

function KUtil.checkBattleRedPoint()
    local tBattleData = KPlayer.tBattleData
    for _, tOneBattleZoneData in pairs(tBattleData) do
        if tOneBattleZoneData.nZoneID ~= 0 then
            for _, tOneMapData in pairs(tOneBattleZoneData.tMaps) do
                if #tOneMapData.tFinishFoothold <= 1 then
                    return true
                end
            end
        end
    end

    return false
end

function KUtil.checkRankRedPoint()
    return (KPlayer.tRankData.tRoleRank and KPlayer.tRankData.tRoleRank.rewardid > 0)
end

function KUtil.isGuide()
    return KPlayer and ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_END > KPlayer.progressID
end

function KUtil.getAnnounceTodayShowTimes()
    local setting = require("src/logic/KSetting")
    local todayShowTimes  = setting.getInt(setting.Key.TODAY_SHOW_TIMES, 0)

    return todayShowTimes
end

function KUtil.getRankName(percert)
    local percertNum = percert * 100
    for _, item in ipairs(KConfig.rankinfo) do
        if item.nRankPercent >= percertNum then
            return item.szName
        end
    end
    return KUtil.getStringByKey("common.nothing")
end

function KUtil.getRoleRankName()
    local percert = 1
    if KPlayer.tRankData.tRoleRank and KPlayer.tRankData.tRoleRank.enter == 1 then
        percert = KPlayer.tRankData.tRoleRank.nRank / KPlayer.tRankData.nCount
    end
    return KUtil.getRankName(percert)
end

function KUtil.getRankImagePathByPercert(percert, index)
    local percertNum = percert * 100
    for _, item in ipairs(KConfig.rankinfo) do
        if item.nRankPercent >= percertNum then
            return "res/images/rank/" .. item.szImagePath .. "/".. index ..".png"
        end
    end
    return "res/images/rank/private/1.png"
end

function KUtil.getRankImagePath(index)
    local percert = 1
    if KPlayer.tRankData.tRoleRank and KPlayer.tRankData.tRoleRank.enter == 1 then
        percert = KPlayer.tRankData.tRoleRank.nRank / KPlayer.tRankData.nCount
    end
    return KUtil.getRankImagePathByPercert(percert, index)
end

function KUtil.isMapPass(nZoneID, nMapID)
    local tOneBattleMapData = KUtil.getBattleMapData(nZoneID, nMapID)
    if not tOneBattleMapData then return false end
    return tOneBattleMapData.bPass
end

function KUtil.getMission(nMissionID)
    return HArray.FindFirstByID(KPlayer.tMissionData.tMissionList, nMissionID)
end

function KUtil.isMissionView(tMissionConfig)
    local bView = true
    local bOpen = KUtil.isOpeningTime(KUtil.getCurrentServerTime(), tMissionConfig.otOpenTimes)
    if  not bOpen then return false end

    local tMissionData = KPlayer.tMissionData
    if HArray.FindFirstByValue(tMissionData.tHistoricalMissionList, tMissionConfig.nID) then
        return false 
    end

    local tOneMission  = KUtil.getMission(tMissionConfig.nID)
    if tOneMission then 
        return true
    end
    
    for _, v in ipairs(tMissionConfig.anFrontMission) do
        if HArray.FindFirstByValue(tMissionData.tHistoricalMissionList, v) == nil then
            return false 
        end
    end
    
    for _, v in ipairs(tMissionConfig.anNotFrontMission) do
        if HArray.FindFirstByValue(tMissionData.tHistoricalMissionList, v) then
            return false
        end
    end

    if KPlayer.level < tMissionConfig.nAccessLevel then
        return false
    end

    local tCondition     = tMissionConfig["lszFrontMap"]
    if tCondition then
        for _, v in ipairs(tCondition) do
            if not KUtil.isMapPass(v[1], v[2]) then
                return false
            end
        end 
    end
    return true
end

function KUtil.getMissionMap()
    local tBattleData = KUtil.getBattleData()
    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", MISSION_BATTLE_ZONE_ID)
    print("getMissionMap", tOneBattleZoneData)
    if not tOneBattleZoneData then return end
    for _, tMap in ipairs(tOneBattleZoneData.tMaps) do
        print("getMissionMap2", tMap.nMapID, tMap.bPass)
        if not tMap.bPass then
            for _, tOneMission in ipairs(KPlayer.tMissionData.tMissionList) do
                local tMissionConfig = KUtil.getMissionConfig(tOneMission.nID)
                assert(tMissionConfig)
                print("getMissionMap3", tMissionConfig.nID, tMissionConfig.nNumero)
                if tMissionConfig.nNumero > 0 then
                    return tMap.nMapID, tOneMission
                end
            end
            assert(false)
        end
    end
    return
end

function KUtil.getMissionPercentCompleted(tMissionConfig)
    local tOneMission      = KUtil.getMission(tMissionConfig.nID)
    if not tOneMission then return 0 end
    local percent = 0
    local nObjectivesCount = #tMissionConfig.anObjectiveCount
    local tObjectivesList  = tOneMission.tObjectivesList
    for i, v in ipairs(tObjectivesList) do
        local onePrcent = v.nCompletedCount / tMissionConfig.anObjectiveCount[v.nID] 
        if onePrcent > 1 then
            onePrcent = 1
        end
        percent = percent + onePrcent * 100
    end
    percent = percent / nObjectivesCount
    return percent
end

function KUtil.isMissionCompleted(tMissionConfig)
    if not tMissionConfig then return false end
    if not KUtil.isMissionView(tMissionConfig) then return false end
    return KUtil.getMissionPercentCompleted(tMissionConfig) >= 100
end

function KUtil.isCardRepair(nCardID)
    for _, repairCard in ipairs(KPlayer.tCardData.tRepairingList) do
        if repairCard.nCardID == nCardID then
            return true
        end
    end
    return false
end

function KUtil.getCanConsumeCardList(nExcludeID)
    local tCardList = {}
    for _, tOneCard in ipairs(KUtil.getCardList()) do
        if tOneCard.nID ~= nExcludeID
            and KUtil.getEnterTeamId(tOneCard.nID)==0 
            and not tOneCard.bLock 
            and not KUtil.isCardRepair(tOneCard.nID) then
            
            table.insert(tCardList, tOneCard)
        end
    end
    return tCardList
end

function KUtil.sortCardList(tCardList, nSortType)
    local funSort
    if nSortType     == "level"       then
        funSort = function(tOneCard1, tOneCard2)
            if tOneCard1.nLevel < tOneCard2.nLevel then  return true end
            return false 
        end 
    elseif nSortType == "star"       then
        funSort = function(tOneCard1, tOneCard2)
            local tCardConfig1 = KUtil.getCardConfig(tOneCard1.nTemplateID)
            local tCardConfig2 = KUtil.getCardConfig(tOneCard2.nTemplateID)
            if tCardConfig1.nQuality < tCardConfig2.nQuality then  return true end
            return false 
        end 
    elseif nSortType == "type"       then
        funSort = function(tOneCard1, tOneCard2)
            local tCardConfig1 = KUtil.getCardConfig(tOneCard1.nTemplateID)
            local tCardConfig2 = KUtil.getCardConfig(tOneCard2.nTemplateID)
            if tCardConfig1.nTankType < tCardConfig2.nTankType then  return true end
            return false 
        end 
    elseif nSortType == "createTime" then
        funSort = function(tOneCard1, tOneCard2)
            if tOneCard1.nCreateTime < tOneCard2.nCreateTime then  return true end
            return false 
        end 
    elseif nSortType == "name"       then
        funSort = function(tOneCard1, tOneCard2)
            local tCardConfig1 = KUtil.getCardConfig(tOneCard1.nTemplateID)
            local tCardConfig2 = KUtil.getCardConfig(tOneCard2.nTemplateID)
            if tCardConfig1.szName == tCardConfig2.szName then
                return tOneCard1.nLevel < tOneCard2.nLevel
            else
                return tCardConfig1.szName < tCardConfig2.szName
            end
            return false 
        end
    end
    if funSort then
        table.sort(tCardList, funSort)
    end
    return tCardList
end

function KUtil.getFormatCollectData(collect)
    local log = {
        nID    = collect.nID,
        id     = collect.nID,
        roleid = collect.nRoleID,
        name   = collect.szName,
        itemId = collect.nTemplateID,
        oil    = collect.nOil,
        ammo   = collect.nAmmo,
        steel  = collect.nSteel,
        people = collect.nPeople,
    }
    return log
end

function KUtil.getFormatResource(resource)
    resource = resource%1000
    local info = {}
    info[1] = math.floor(resource/100)
    info[2] = math.floor((resource%100)/10)
    info[3] = resource%10
    return info
end

function KUtil.getTeamName(teamIndex)
    local teamName = KUtil.getStringByKey("common.team") .. teamIndex
    local teamList = KPlayer.tTeamData.tTeamList
    local teamItem = HArray.FindFirst(teamList, "nIndex", teamIndex)
    if teamItem and teamItem.szName then 
        local stringLen = string.len(teamItem.szName)
        if stringLen > 0 then teamName = teamItem.szName end
    end
    return teamName
end

function KUtil.getPixelQuality()
    local pixelFormat = cc.Texture2D:getDefaultAlphaPixelFormat()
    local m_tPixelQuality = {
        [KUtil.PIXEL_QUALITY.HIGH]        = cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888,
        [KUtil.PIXEL_QUALITY.MEDIAN]      = cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A4444,
        [KUtil.PIXEL_QUALITY.LOW]         = cc.TEXTURE2_D_PIXEL_FORMAT_RGB5_A1,
    }

    for k, v in pairs(m_tPixelQuality) do
        if pixelFormat == v then
            return k
        end
    end

    return PIXEL_QUALITY.HIGH
end

function KUtil.setPixelQuality(pixelQuality)
    local m_tPixelQuality = {
        [KUtil.PIXEL_QUALITY.HIGH]        = cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888,
        [KUtil.PIXEL_QUALITY.MEDIAN]      = cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A4444,
        [KUtil.PIXEL_QUALITY.LOW]         = cc.TEXTURE2_D_PIXEL_FORMAT_RGB5_A1,
    }

    local qualityKey   = string.lower(pixelQuality)
    local pixelFormat  = m_tPixelQuality[qualityKey]
    assert(pixelFormat ~= nil, "undefine pixel format")
    cc.Texture2D:setDefaultAlphaPixelFormat(pixelFormat)
end

function KUtil.configPixelQuality(pixelQuality)
    if pixelQuality == nil then
        local setting       = require("src/logic/KSetting")
        local recordQuality = setting.getString(setting.Key.PIXEL_QUALITY, "")
        if recordQuality == nil or recordQuality == "" then
            --set default pixel quality
            recordQuality = KUtil.PIXEL_QUALITY.HIGH
        end
        pixelQuality = recordQuality
    end

    KUtil.setPixelQuality(pixelQuality)
    local setting = require("src/logic/KSetting")
    setting.setString(setting.Key.PIXEL_QUALITY, pixelQuality)
end

function KUtil.setRadioGroupEvent(checkBoxArray, selectedCallback)
    local function unSelcetedAllRadioButton(radioGroup)
        for _, v in pairs(radioGroup) do
            v:setSelected(false)
        end
    end

    local radioGroup = {}
    for _, v in pairs(checkBoxArray) do
        table.insert(radioGroup, v)
    end

    for index, radioButton in pairs(radioGroup) do
        local function onRadioButtonClick(sender, eventType)
            if eventType == ccui.CheckBoxEventType.selected then
                unSelcetedAllRadioButton(radioGroup)
                selectedCallback(radioGroup, index)
                sender:setSelected(true)
            elseif eventType == ccui.CheckBoxEventType.unselected then
                sender:setSelected(true)
            end
        end
        radioButton:addEventListener(onRadioButtonClick)
    end
end

function KUtil.setSelectionDifficultyEvent(checkBoxArray)
    for _, difficultyButton in ipairs(checkBoxArray) do
        local checkBoxUI = difficultyButton
        local function onClick(sender, eventType)
            if eventType == ccui.CheckBoxEventType.selected then
                for _, v in ipairs(checkBoxArray) do
                    if v ~= sender then
                        v:setTouchEnabled(true)
                        v:setSelected(false)
                    else
                        v:setTouchEnabled(false)
                    end
                end
            elseif eventType == ccui.CheckBoxEventType.unselected then
                sender:setSelected(true)
                sender:setTouchEnabled(false)
            end
        end

        checkBoxUI:setTouchEnabled(not checkBoxUI:isSelected())
        checkBoxUI:addEventListener(onClick)        
    end
end

function KUtil.replaceSceneAndRemoveAllTexture(newScene)
    local director = cc.Director:getInstance()
    local textureCache = director:getTextureCache()

    cclog("replaceSceneAndRemoveAllTexture begin ... ")
    require("src/logic/KLogGather").addLog("EventBug", "1replaceScene")
    director:replaceScene(newScene)
    textureCache:removeUnusedTextures()   

    cclog("replaceSceneAndRemoveAllTexture end ... ")
end

function KUtil.removeUnusedTextures()
    local textureCache = cc.Director:getInstance():getTextureCache()
   textureCache:removeUnusedTextures()
end

function KUtil.playGetCardAnimation(nCardID, bNewCard, onClickEvent, tEventParam)
   local runScene           = cc.Director:getInstance():getRunningScene()
   local uiAwardTankNode    = runScene:addNode("AwardTank", {nCardID = nCardID , bNewCard = bNewCard})

   if not uiAwardTankNode then return end

   uiAwardTankNode:setCallback(onClickEvent, tEventParam)

   return uiAwardTankNode
end

function KUtil.removeGetCardAnimation()
    local nodeType           = "AwardTank"
    local runScene           = cc.Director:getInstance():getRunningScene()
    local uiAwardTankNode    = runScene:getNode(nodeType)
    if uiAwardTankNode then
        runScene:removeNode(nodeType)
    end
end

function KUtil.playGetItemAnimation(parentScene, rewardList, onClickEvent, tEventParam)
    local userData = { tResultList = rewardList }
    local rewardUI = parentScene:addNode("Reward", userData)
    rewardUI:setCallback(onClickEvent, tEventParam)

    return rewardUI
end

function KUtil.getSignData()
    local tSignData = KPlayer.tSignData
    local nCurDay   = GetDayIndex(KUtil.getCurrentServerTime())
    tSignData.bSign = nil
    
    if nCurDay == tSignData.nLastDay then
        tSignData.bSign  = true
    elseif tSignData.nCleanDay ~= 0 and nCurDay >= tSignData.nCleanDay then
        tSignData.nCount = 0
    end 

    local tSignConfig    = KConfig:getLine("sign", tSignData.nCount + 1)
    if not tSignConfig then
        tSignData.bSign  = true
    end
    return tSignData
end

function KUtil.getRewardRandResult(nRewardID)
    local tRewardInfo = KConfig["reward"][nRewardID]
    local tRewardList, nRandomType = {}, 0
    assert(tRewardInfo) 
    if tRewardInfo then 
        tRewardList = tRewardInfo.tList
        nRandomType = tRewardInfo.nType
    end
    local tRandList = {}
    if RANDOM_TYPE.HITONE == nRandomType then
        local nAllRate = 0
        for i, tItem in pairs(tRewardList) do
            nAllRate = nAllRate + tItem.nRate
        end
        assert(nAllRate > 0)
        local nRate = math.random() * nAllRate
        local nCurrentRate = 0
        for _, tItem in pairs(tRewardList) do
            nCurrentRate = nCurrentRate + tItem.nRate
            if nCurrentRate > nRate then
                if tItem.nNum ~= 0 and tItem.nID > 0 then table.insert(tRandList, tItem) end
                break
            end
        end
    elseif RANDOM_TYPE.EACHRAND == nRandomType then
        for i, tItem in pairs(tRewardList) do
            local nRate = math.random()
            if nRate < tItem.nRate then
                if tItem.nNum ~= 0 and tItem.nID > 0 then table.insert(tRandList, tItem) end
            end
        end
    else
        Error("nRandomType=:%d Error", nRandomType)
    end
    return tRandList
end

function KUtil.setTouchEnabled(button, bEnabled)
    button:setBright(bEnabled)
    button:setTouchEnabled(bEnabled)
    if bEnabled then
        KUtil.setWidgetNormal(button)
    else
        KUtil.setWidgetGray(button)
    end
end

local m_tBreakBouttonTexture =
{
    ["normal"]   = "res/ui/ui_material/public/button_currency.png", 
    ["press"]    = "res/ui/ui_material/public/button_currency_active.png", 
    ["disable"]  = "res/ui/ui_material/public/button_currency_disable.png",
}
function KUtil.setTouchEnabledAndDisable(button, bEnabled)
    button:setTouchEnabled(bEnabled)
    if bEnabled then
        button:loadTextures(m_tBreakBouttonTexture["normal"], m_tBreakBouttonTexture["press"], m_tBreakBouttonTexture["disable"])
    else
        button:loadTextures(m_tBreakBouttonTexture["disable"], m_tBreakBouttonTexture["press"], m_tBreakBouttonTexture["disable"])
    end
end

function KUtil.getAnnounceString(tAnnounceList)
    local annouceString = ""
    local index = 0
    for _, info in pairs(tAnnounceList) do
        if info.nID ~= 0 then
            index = index + 1
            if index ~= 1 then
                annouceString = annouceString .. "#"
            end
            annouceString = annouceString .. info.nID .. "|" .. info.szName

            if info.tColor and info.tColor[1] then
                for _, colorItem in ipairs(info.tColor) do
                    annouceString = annouceString .. "|" .. colorItem
                end
            end
        end
    end
    return annouceString
end

function KUtil.getAnnounceTable(szAnnouceString)
    local tAnnounceList = {}
    local itemList = string.split(szAnnouceString, "#")
    for _, itemString in ipairs(itemList) do
        local announceArray = string.split(itemString, "|")
        local itemInfo  = {}
        itemInfo.nID    = tonumber(announceArray[1])
        itemInfo.szName = announceArray[2]
        itemInfo.tColor = {}
        if announceArray[3] then
            itemInfo.tColor[1] = tonumber(announceArray[3])
            itemInfo.tColor[2] = tonumber(announceArray[4])
            itemInfo.tColor[3] = tonumber(announceArray[5])
        end
        table.insert(tAnnounceList, itemInfo)
    end
    return tAnnounceList
end

function KUtil.getShowAnnounceList()
    local setting = require("src/logic/KSetting")
    local annouceString = setting.getString(setting.Key.ANNOUNCE_INFO, "")

    local setting = require("src/logic/KSetting")
    local version = setting.getInt(setting.Key.ANNOUNCE_VERSION, 0)

    if annouceString == "" then
        return KConfig.announce
    end
    --check config version
    local versionInfo = KConfig.announce[0]
    if versionInfo and (tonumber(versionInfo.szName) or 0) > version then
        return KConfig.announce
    end
    return KUtil.getAnnounceTable(annouceString)
end

local FOLDERNAME = {
    [FURNITURE_TYPE.CARPET]          = "carpet",
    [FURNITURE_TYPE.CHAIRS]          = "chairs",
    [FURNITURE_TYPE.FLOOR]           = "floor",
    [FURNITURE_TYPE.FURNITURE_LEFT]  = "furnitureleft",
    [FURNITURE_TYPE.FURNITURE_RIGHT] = "furnitureright",
    [FURNITURE_TYPE.HANGING]         = "hanging",
    [FURNITURE_TYPE.OBJECTS_FLOOR]   = "objectsfloor",
    [FURNITURE_TYPE.WALLPAPER]       = "wallpaper",
    [FURNITURE_TYPE.WINDOW]          = "window",
}
function KUtil.getFurnitureFolderByType(nType)
    return FOLDERNAME[nType]
end

function KUtil.getFurniturePath(nTemplateID)
    local furniture = KConfig.furniture[nTemplateID]
    if not furniture then return end 
    local folderName = KUtil.getFurnitureFolderByType(furniture.nType)
    if not folderName then return end
    local basePath = "res/images/furniture/"  .. folderName .. "/" .. furniture.szPath .. "/"
    local filePath =  basePath .. "normal.png"
    return filePath
end

function KUtil.getFurniturePosition(imageCommonProject)
    local furnitureInfo = {}
    local imageCommonBackground = imageCommonProject:getChildByName("Panel__furniture_background")
    for nType = 1, MAX_FURNITURE_INDEX do
        local folderName = KUtil.getFurnitureFolderByType(nType)
        local uiName = "Image_" .. folderName
        local imageFurniture = imageCommonBackground:getChildByName(uiName)
        local x = imageFurniture:getPositionX()
        local y = imageFurniture:getPositionY()
        furnitureInfo[nType] = {x = x, y = y}
    end
    return furnitureInfo
end

function KUtil.refreshFurnitures(imageCommonProject, furnitureInfo)
    local imageCommonBackground = imageCommonProject:getChildByName("Panel__furniture_background")
    for _, One in pairs(KPlayer.tFurnitureData.tRoleFurniture) do
        local nType          = One.nType
        local templateID     = One.nTemplateID

        local config         = KConfig.furniture[templateID]
        local filePath       = KUtil.getFurniturePath(templateID)

        local positionInfo   = furnitureInfo[nType] 
        local folderName     = KUtil.getFurnitureFolderByType(nType)
        local uiName = "Image_" .. folderName
        local imageFurniture = imageCommonBackground:getChildByName(uiName)

        local furnitureType = KConfig.furnitureType[nType]
        if positionInfo and imageFurniture and furnitureType then 
            local positionX = positionInfo.x + config.nOffX
            local positionY = positionInfo.y + config.nOffY
            imageFurniture:setVisible(true)
            imageFurniture:setPosition(positionX, positionY)
            imageFurniture:loadTexture(filePath)
            imageFurniture:setLocalZOrder(furnitureType.nOrder)
        end
    end
end

function KUtil.setWidgetGray(Widget)
    local effectUtil = require("src/base/KEffectUtil") 
    effectUtil.setWidgetStatus(Widget, effectUtil.WidgetStatus.gray)
end

function KUtil.setWidgetBright(Widget)
    local effectUtil = require("src/base/KEffectUtil") 
    effectUtil.setWidgetStatus(Widget, effectUtil.WidgetStatus.bright)
end

function KUtil.setWidgetNormal(Widget)
    local effectUtil = require("src/base/KEffectUtil") 
    effectUtil.setWidgetStatus(Widget, effectUtil.WidgetStatus.normal)
end

function KUtil.setWidgetDark(Widget)
    local effectUtil = require("src/base/KEffectUtil") 
    effectUtil.setWidgetStatus(Widget, effectUtil.WidgetStatus.dark)
end

function KUtil.setButtonTouch(Widget, Callback)
    local function onClick(sender, type)
        if type == ccui.TouchEventType.began then
            KUtil.setWidgetBright(Widget)
        elseif type == ccui.TouchEventType.ended then
            KUtil.setWidgetNormal(Widget)
            if Callback then Callback() end
        elseif type == ccui.TouchEventType.canceled then
            KUtil.setWidgetNormal(Widget)
        end
    end
    Widget:addTouchEventListener(onClick)
end

function KUtil.getOneMailByID(nID)
    local mailList = KPlayer.tMailData.tMailList
    for index, oneMail in ipairs(mailList) do
        if oneMail.nID == nID then
            return oneMail, index
        end
    end
    return nil, nil
end

function KUtil.sortOneMailList(oneMailList)
    local function sortOneMail(mailA, mailB)
        local oldA = mailA.bOpen and mailA.bAward
        local oldB = mailB.bOpen and mailB.bAward
        if oldA == oldB then
            return mailA.nID > mailB.nID
        elseif oldA then
            return false
        else
            return true
        end
    end
    table.sort(oneMailList, sortOneMail)
end

function KUtil.hasNewMail()
    local mailList = KPlayer.tMailData.tMailList
    local oneMail  = mailList[1]

    if not oneMail then
        return false
    end

    if oneMail.bOpen and oneMail.bAward then
        return false
    end

    return true
end

function KUtil.getMailRewardList(self, oneMail)
    if not oneMail then return end
    if oneMail.bAward then return end
    
    local rewardID   = oneMail.tMailData.nRewardID
    local rewardList = oneMail.tMailData.tRewardList
    if rewardList ~= nil then return rewardList end 
    if rewardID == 0 then return end
    
    local rewardList = KUtil.getRewardRandResult(rewardID)
    return rewardList
end

function KUtil.checkTeamRedPoint()
    local teamTipLevel   = 10
    local isTeamFull = false
    local nTeamCardCount = 0
    for i = 1, KPlayer.tTeamData.nOpenCount do
        nTeamCardCount = nTeamCardCount + KUtil.getTeamSize(i)
    end
    
    if KPlayer.level < teamTipLevel 
        and KUtil.getTeamSize(1) < MAX_TEAM_CARD_COUNT 
        and KUtil.getCardCount() > nTeamCardCount then

        local tCardList = KUtil.getCardList()
        for _, tCard in ipairs(tCardList) do
            if KUtil.getEnterTeamId(tCard.nID) == 0 then
                if not KUtil.isSameTemplateCardInTeam(tCard.nID, 1) then
                    isTeamFull = true
                    break
                end
            end
        end
    end
    return isTeamFull
end

function KUtil.hasNewPrivateMessage()
    return KPlayer.bHasNewPrivateMessage
end

function KUtil.setItemClippingEnabled(node, nType)
    node:setClippingEnabled(nType ~= ITEM_TYPE.CARD)
end

function KUtil.getExerciseBattleDetail(battleRoleID)
    local teamName    = "no name"
    local roleName    = "no name"
    local roleLevel   = "1"
    local cardList    = {}
    local tRoleList   = KPlayer.tExerciseData.tRoleList or {}
    local tRoleDetail = HArray.FindFirst(tRoleList, "nRoleID", battleRoleID)
    if tRoleDetail then
        teamName  = tRoleDetail.tExercise.szName
        cardList  = tRoleDetail.tExercise.tCardList
        roleName  = tRoleDetail.szName
        roleLevel = tRoleDetail.nLevel
        -- reset max hp
        for _, card in ipairs(cardList) do
            local cardConfig = KConfig.cardInfo[card.nTemplateID]
            local maxHP = KUtil.getCardMaxHp(card)
            if cardConfig then card.nCurrentHP = maxHP end
        end
    end
    return cardList, roleName, teamName, roleLevel
end

function KUtil.getExpeditionBattleDetail(battleData)
    local roleDetail   = battleData.tOne
    local teamData     = roleDetail.teamdata
    local teamName     = teamData.tOneTeam.szName
    local roleName     = battleData.szName
    local roleLevel    = roleDetail.level
    local cardList     = teamData.tCardList
    local equipList    = teamData.tEquipList

    local tempCardList = {}
    for _, cardID in ipairs(teamData.tOneTeam.tCardIDList) do
        local oneCard = HArray.FindFirstByID(cardList, cardID)
        for _, equipInfo in pairs(oneCard.tEquipList) do
            local oneEquip = HArray.FindFirstByID(equipList, equipInfo.nEquipID)
            equipInfo.nTemplateID = oneEquip.nTemplateID
        end
        table.insert(tempCardList, oneCard)
    end
    return tempCardList, roleName, teamName, roleLevel
end

function KUtil.getFurnitrureCount()
    local count = 0
    for _, furniture in pairs(KPlayer.tFurnitureData.tFurnitureList) do
        count = count + furniture.nCount
    end
    return count
end

function KUtil.setRichItemList(richText, list, fontSize)
    for i, item in ipairs(list) do
        local color           = item.color
        local text            = item.text
        local image           = item.image
        local font            = item.font or KUtil.FONT_PATH
        local fontSize        = item.fontSize or fontSize
        local newLine         = item.newline
        if text then
            local richElementText = ccui.RichElementText:create(i, color, 255, text, font, fontSize)
            richText:pushBackElement(richElementText)
        elseif image then
            color = color or cc.c3b(255, 255, 255)
            local richElementImage = ccui.RichElementImage:create(i, color, 255, image)
            richText:pushBackElement(richElementImage)
        elseif newLine then
            local node = cc.Node:create()
            node:setContentSize(cc.size(richText:getContentSize().width, 0));
            richText:pushBackElement(ccui.RichElementCustomNode:create(i, color, 255, node))
        end
    end
end

function KUtil.getCardsByKey(baseCards, key)
    local result = {}
    if key == KUtil.CHOOSE_TANK_TYPE.ALL then
        result = baseCards
    else
        for k,card in pairs(baseCards) do
            if KConfig.cardInfo[card.nTemplateID].nTankType == key then
                table.insert(result, card)
            end
        end
    end
    return result
end

function KUtil.showUiScale(ui, enterOrExit)
    local duration  = 0.2
    local actionEnter = cc.Sequence:create(
        cc.Spawn:create(
            cc.FadeTo:create(0, 0),
            cc.ScaleTo:create(0, 0, 0)
        ),
        cc.CallFunc:create(function()
            ui:setVisible(true)
        end),         
        cc.Spawn:create(
            cc.FadeTo:create(duration, 255),
            cc.ScaleTo:create(duration, 1.0, 1.0)
        )
    )

    local actionExit = cc.Sequence:create(
        cc.Spawn:create(
            cc.FadeTo:create(duration, 0),
            cc.ScaleTo:create(duration, 0.1, 0.1)
        ),
        cc.CallFunc:create(function()
            ui:setVisible(false)
        end)
    )

    if enterOrExit then
        ui:runAction(actionEnter)
    else
        ui:runAction(actionExit)
    end
end

function KUtil.isFirstRecharge()
    return (KPlayer.chargeCoin > 0)
end

function KUtil.playMarryAnimation(cardInfo, hideAttribute)
    local runScene           = cc.Director:getInstance():getRunningScene()
    runScene:addNode("TankWedding", {cardInfo = cardInfo , hideAttribute = hideAttribute})
end

function KUtil.getCardMaxHp(oneCard)
    assert(oneCard, "KUtil.getCardMaxHp oneCard is nil~~")
    local cardConfig = KConfig.cardInfo[oneCard.nTemplateID]
    local nMaxHP = cardConfig.nMaxHP + (oneCard.nAddHP or 0)
    if oneCard.bRing then
        local ringMaxHp = HArray.FindFirst(oneCard.tRingAttribute, "nIndex", ATTRIBUTE.MAX_HP)
        if ringMaxHp then
            nMaxHP = nMaxHP + ringMaxHp.nValue
        end
    end
    return nMaxHP
end

function KUtil.resetCardListCurrentHP(cardList)
    for _, card in ipairs(cardList) do
        card.nCurrentHP = KUtil.getCardMaxHp(card)
    end
end

function KUtil.getSkillByIndex(index)
    return HArray.FindFirst(KPlayer.tSkillList, "nPos", index)
end

function KUtil.getSkillID(oneSkill)
    -- local equipItem   = KUtil.getEquipById(oneSkill.nEquipID)
    -- assert(equipItem, "equipItem is nil " .. oneSkill.nEquipID)

    local equipConfig = KConfig.equipInfo[oneSkill.nEquipTemplateID]
    assert(equipConfig, "equipConfig is nil " .. oneSkill.nEquipTemplateID)

    return equipConfig.nSkill
end

function KUtil.getSkillType(oneSkill)
    local equipItem   = KUtil.getEquipById(oneSkill.nEquipID)  
    assert(equipItem, "equipItem is nil " .. oneSkill.nEquipID)

    local equipConfig = KConfig.equipInfo[equipItem.nTemplateID]
    assert(equipConfig, "equipConfig is nil " .. equipItem.nTemplateID)

    local skillConfig = KConfig.skill[equipConfig.nSkill]
    assert(skillConfig, "skillConfig is nil " .. equipConfig.nSkill)
    return skillConfig.szType
end

function KUtil.getSelectSkillList(position)
    local enterIDMap   = {}
    local enterTypeMap = {}
    for _, oneSkill in pairs(KPlayer.tSkillList) do
        enterIDMap[oneSkill.nEquipID] = true
        if position ~= oneSkill.nPos then
            local skillType = KUtil.getSkillType(oneSkill)
            enterTypeMap[skillType] = true
        end
    end

    local showList = {}
    for i, item in ipairs(KPlayer.tItemData.tEquipStoreHouse.tEquipList) do
        local equipConfig = KConfig.equipInfo[item.nTemplateID]
        assert(equipConfig, "equipConfig is nil " .. item.nTemplateID)
        if equipConfig.nEquipType == CARD_EQUIP_TYPE.SKILL and not enterIDMap[item.nID] then
            table.insert(showList, item)
        end
    end

    for i = #showList, 1, -1 do
        local equipItem   = showList[i]
        local equipConfig = KConfig.equipInfo[equipItem.nTemplateID]
        assert(equipConfig, "equipConfig is nil " .. equipItem.nTemplateID)

        local skillConfig = KConfig.skill[equipConfig.nSkill]
        assert(skillConfig, "skillConfig is nil " .. equipConfig.nSkill)
        if enterTypeMap[skillConfig.szType] then
            table.remove(showList, i)
        end
    end

    return showList
end

local splitCharArray = {"+", "-", "_"}
function KUtil.getSkillDescriptionList(equipTempletID)
    local equipConfig = KConfig.equipInfo[equipTempletID]
    local skillConfig = KConfig.skill[equipConfig.nSkill]
    local szAttribute = skillConfig.szAttribute

    local itemList = {}
    if szAttribute and string.len(szAttribute) > 0 then
        local stringList = string.split(szAttribute, "|")
        for _, oneString in ipairs(stringList) do
            for _, splitChar in ipairs(splitCharArray) do
                local oneAttribute = string.split(oneString, splitChar)
                if #oneAttribute > 1 then
                    oneAttribute[3] = splitChar
                    table.insert(itemList, oneAttribute)
                end
            end
        end
    end
    
    return itemList
end

function KUtil.skillAttributeListForamtValue(attributeList, nTemplateID)
    for index, attribute in ipairs(attributeList) do
        KUtil.skillAttributeForamtValue(attribute)
    end

    local equipConfig = KConfig.equipInfo[nTemplateID]
    assert(equipConfig, "addSkillNameToList equipConfig is nil " .. nTemplateID)

    local skillConfig = KConfig.skill[equipConfig.nSkill]
    assert(skillConfig, "skillConfig is nil " .. equipConfig.nSkill)

    table.insert(attributeList, 1, {skillConfig.szName})


    return attributeList
end

function KUtil.skillAttributeForamtValue(attribute)
    local name, value, char = attribute[1], attribute[2], attribute[3]
    if char == "_" then char = " " end
    attribute[2] = char .. value 
    return attribute
end

function KUtil.getCardMaxLevel(oneCard)
    local maxLevel = KUtil.MAX_CARD_LEVEL
    if oneCard.nFeeling >= KUtil.MAX_FEELING then
        maxLevel = KUtil.MAX_MARRY_CARD_LEVEL
    end
    return maxLevel
end

function KUtil.getCardCountryName(cardID)
    local oneCard = KUtil.getCardById(cardID)
    if not oneCard then return cardCountryName[CARD_COUNTRY_TYPE.BASE] end

    local cardConfig = KUtil.getCardConfig(oneCard.nTemplateID)
    assert(cardConfig)

    return cardCountryName[cardConfig.nCountryType] 
end

function KUtil.getCardCountryNameList()
    return cardCountryName
end

function KUtil.setCardHeadBack(baseNode, countryType, szNodeNameFormat)
    local node, nodeName
    for _,countryName in pairs(cardCountryName) do
        nodeName = string.format(szNodeNameFormat, countryName)
        node = baseNode:getChildByName(nodeName)
        node:setVisible(false)
    end
    
    nodeName        = string.format(szNodeNameFormat, cardCountryName[countryType])
    node            = baseNode:getChildByName(nodeName)
    node:setVisible(true)
end

-- {nID(nil, not show), nTemplateID, nCurrentHP, nLevel, nFeeling}
-- notLock, showAttribute, notShowTeamFlag can be nil value
function KUtil.updateCardBase(baseNode, oneCard, notLock, showAttribute, notShowTeamFlag, showHeartFlag)
    local cardConfig   = KUtil.getCardConfig(oneCard.nTemplateID)
    local countryType  = cardConfig.nCountryType
    -- update  card base
    local panelCardBase = baseNode:getChildByName("Panel_card_base")
    local cardRing = (oneCard.bRing == true)
    local qualityNum    = 0
    while true do
        qualityNum = qualityNum + 1
        local imageCardBase = panelCardBase:getChildByName("Image_card_base_" .. qualityNum)
        if not imageCardBase then break end
        local showImage = (qualityNum == cardConfig.nQuality) and (not cardRing)
        imageCardBase:setVisible(showImage)    
    end

    local imageRing = panelCardBase:getChildByName("Image_card_ring")
    imageRing:setVisible(cardRing)

    -- update star
    local panelStar = baseNode:getChildByName("Panel_star")
    local qualityNum = 0
    while true do
        qualityNum = qualityNum + 1
        local imageStar = panelStar:getChildByName("Image_common_star_" .. qualityNum)
        if not imageStar then break end
        imageStar:setVisible(qualityNum <= cardConfig.nQuality)    
    end
    
    -- update medal 
    local panelCardMedal = baseNode:getChildByName("Panel_card_meda")
    local qualityNum = 0
    while true do
        qualityNum = qualityNum + 1
        local imageMedal = panelCardMedal:getChildByName("Image_card_medal_" .. qualityNum)
        if not imageMedal then break end
        imageMedal:setVisible(qualityNum == cardConfig.nQuality)    
    end

    -- update card type
    local panelCardType = baseNode:getChildByName("Panel_card_type")
    local tankTypeNum = 0
    while true do
        tankTypeNum = tankTypeNum + 1
        local imageCardType = panelCardType:getChildByName("Image_card_type_" .. tankTypeNum)
        if not imageCardType then break end
        imageCardType:setVisible(tankTypeNum == cardConfig.nTankType)    
    end

    -- update character
    local panelCharacter = baseNode:getChildByName("Panel_card_chara")
    local imageCharacter = panelCharacter:getChildByName("Image_common_chara")
    local cardHeadPath   = KUtil.getScaleCardImagePath(oneCard)
    imageCharacter:setVisible(false)
    KUtil.asynLoadTexture(imageCharacter, cardHeadPath)
    -- update 
    local panelHP       = baseNode:getChildByName("Panel_HP")
    local panelDamage   = baseNode:getChildByName("Panel_damage")

    local imageHP, imageHPName
    for _,countryName in pairs(cardCountryName) do
        imageHPName = "Image_hp_"..countryName
        imageHP = panelHP:getChildByName(imageHPName)
        imageHP:setVisible(false)
    end

    imageHPName        = "Image_hp_"..cardCountryName[countryType]
    imageHP            = panelHP:getChildByName(imageHPName)
    imageHP:setVisible(true)

    local maxHP         = KUtil.getCardMaxHp(oneCard)
    local cardHPPercent = oneCard.nCurrentHP / maxHP * 100
    local hpName        = {"LoadingBar_kb_hp_green", "LoadingBar_kb_hp_yellow", "LoadingBar_kb_hp_orange", "LoadingBar_kb_hp_red", nil}
    local stateName     = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", "Image_common_damage_dead"}
    KUtil.drawCardState(panelHP, panelDamage, hpName, stateName, cardHPPercent)

    local labelHp   = panelHP:getChildByName("BitmapFontLabel_hp_value") 
    labelHp:setString(oneCard.nCurrentHP .. "/" .. maxHP)

    -- update lock 
    local imageLock = baseNode:getChildByName("Image_lock")
    if notLock then 
        imageLock:setVisible(false)
    else
        local showLock = (oneCard.bLock == true)
        imageLock:setVisible(showLock)
    end
    -- update level
    local textLevel = baseNode:getChildByName("BitmapFontLabel_common_level")
    textLevel:setString("lv." .. oneCard.nLevel)

    local textName = baseNode:getChildByName("Text_name")
    textName:setString(cardConfig.szName)

    local maxLevel = KUtil.getCardMaxLevel(oneCard)
    local imageMaxIcon = baseNode:getChildByName("Image_bd_max_icon")
    imageMaxIcon:setVisible(oneCard.nLevel >= maxLevel)

    -- update flag
    local panelTeamFlag = baseNode:getChildByName("Panel_team_flag")
    local imageTeamFlag = panelTeamFlag:getChildByName("Image_team_number")
    local isFlagShow    = (oneCard.nID ~= nil and not notShowTeamFlag)
    panelTeamFlag:setVisible(isFlagShow)
    if isFlagShow then
        local teamID = KUtil.getEnterTeamId(oneCard.nID)
        isFlagShow = teamID > 0
        panelTeamFlag:setVisible(isFlagShow)
        if isFlagShow then
            local teamFlagPath = string.format("res/ui/ui_material/cardbase/card_team_%d.png", teamID)
            imageTeamFlag:loadTexture(teamFlagPath)
        end
    end

    if oneCard.nID then
        local imageRepairing = panelDamage:getChildByName("Image_common_repairing")
        local isCardRepair   = KUtil.isCardRepair(oneCard.nID)
        imageRepairing:setVisible(isCardRepair)
        -- set status visible false
        if isCardRepair then
            local stateNameLen = #stateName
            for stateIndex = 2, stateNameLen do
                local imageState = panelDamage:getChildByName(stateName[stateIndex])
                imageState:setVisible(false)
            end
        end
    end

    local panelAttribute = baseNode:getChildByName("Image_attribute_base")
    if panelAttribute then
        KUtil.updateCardAttributePanel(panelAttribute, oneCard)
        panelAttribute:setVisible(showAttribute == true)
    end

    --update frame buttom
    local frameButtomFormat  = "Button_%s_frame_buttom"
    KUtil.setCardHeadBack(baseNode, countryType, frameButtomFormat)
   
    --secretary
    local imageGentlemanIcon            = baseNode:getChildByName("Image_gentleman_icon")
    local secretaryCard                 = KUtil.getSecretaryCard()
    local imageGentlemanIconVisable     = oneCard.nID == secretaryCard.nID
    imageGentlemanIcon:setVisible(imageGentlemanIconVisable)

    --firend degree
    local panelFirendDegree = baseNode:getChildByName("Panel_firend_degree")
    local progressValue     = oneCard.nFeeling / KUtil.MAX_FEELING * KUtil.PERCENT_BASE
    if panelFirendDegree then 
        local loadingBarFriendDegree = panelFirendDegree:getChildByName("LoadingBar_friend_degree")
        loadingBarFriendDegree:setPercent(progressValue)
        local bitmapFontLabelDegree  = panelFirendDegree:getChildByName("BitmapFontLabel_degree")
        bitmapFontLabelDegree:setString(oneCard.nFeeling .. "%")
    end

    --hert
    local panelHeart                    = baseNode:getChildByName("Panel_heart")
    if panelHeart then
        panelHeart:setVisible(false)

        local isShowHeart = showHeartFlag or false
        if isShowHeart and oneCard.nFeeling >= KUtil.MAX_FEELING and not oneCard.bRing then
            panelHeart:setVisible(true)
        end
    
        local function onHeartClick(sender, type)
            cclog("updateCardBase click onHeartClick~")
            KSound.playEffect("click")
            KUtil.requestMarryCard(oneCard.nID)
        end
        panelHeart:addTouchEventListener(onHeartClick)
    end
end

function KUtil.getCardBaseActiveFrameButtom(baseNode, cardID)
    local countryName = KUtil.getCardCountryName(cardID)
    local frameButtomName = "Button_"..countryName.."_frame_buttom"
    local frameButtom = baseNode:getChildByName(frameButtomName)

    return frameButtom
end

function KUtil.updateCardAttributePanel(panelAttribute, oneCard)
    local showIndex = 0
    local allAttribute = KUtil.getCurrentAttribute(oneCard)
    for index, attribute in ipairs(KUtil.ATTIBUTE_NAME) do
        local value = allAttribute[attribute[1]]
        if value and value ~= 0 then
            showIndex = showIndex + 1
            local textAttributeName = panelAttribute:getChildByName("Text_attribute_" .. showIndex)
            local textAttributeValue = panelAttribute:getChildByName("Text_attribute_value_" .. showIndex)
            if not textAttributeName or not textAttributeValue then break end
            textAttributeName:setString(KUtil.getStringByKey(attribute[2]))
            textAttributeValue:setString(tostring(value))
        end
    end
end

-- {nTemplateID, nCurrentHP, nLevel, nFeeling}
function KUtil.updateCardBig(baseNode, oneCard, bShowMount)
    local imageCardBase = baseNode:getChildByName("Image_card_base")
    local backPath  = KUtil.getCardBackImagePath(oneCard.nTemplateID, oneCard.bRing)
    imageCardBase:loadTexture(backPath)
    
    local cardConfig  = KUtil.getCardConfig(oneCard.nTemplateID)
    local panelDetail = baseNode:getChildByName("Panel_card_frame_buttom")
    -- update medal 
    local panelCardMedal = panelDetail:getChildByName("Panel__card_meda")
    local qualityNum = 0
    while true do
        qualityNum      = qualityNum + 1
        local imageMedal = panelCardMedal:getChildByName("Image_card_medal_" .. qualityNum)
        if not imageMedal then break end
        imageMedal:setVisible(qualityNum == cardConfig.nQuality)    
    end

    -- update card type
    local panelCardType = panelDetail:getChildByName("Panel__card_type")
    local tankTypeNum = 0
    while true do
        tankTypeNum = tankTypeNum + 1
        local imageCardType = panelCardType:getChildByName("Image_card_type_" .. tankTypeNum)
        if not imageCardType then break end
        imageCardType:setVisible(tankTypeNum == cardConfig.nTankType)    
    end

    -- update star
    local panelStar = panelDetail:getChildByName("Panel_card_star")
    local qualityNum = 0
    while true do
        qualityNum = qualityNum + 1
        local imageStar = panelStar:getChildByName("Image_common_star_" .. qualityNum)
        if not imageStar then break end
        imageStar:setVisible(qualityNum <= cardConfig.nQuality)    
    end
    -- update level
    local textLevel = panelDetail:getChildByName("BitmapFontLabel_tank_level")
    textLevel:setString(tostring(oneCard.nLevel))

    local textName = panelDetail:getChildByName("Text_tank_name")
    textName:setString(cardConfig.szName)

    local imageChange1 = panelDetail:getChildByName("Image_card_kai_1")
    imageChange1:setVisible(cardConfig.nChangeTimes == 1)

    local imageChange1 = panelDetail:getChildByName("Image_card_kai_2")
    imageChange1:setVisible(cardConfig.nChangeTimes == 2)

    -- update character
    local panelCharacter = baseNode:getChildByName("Panel_card_chara")
    local imageCharacter = panelCharacter:getChildByName("Image_card_chara")
    local cardHeadPath   = KUtil.getCardImagePath(oneCard, false)
    imageCharacter:loadTexture(cardHeadPath)

    local panelFriendDegree     = baseNode:getChildByName("Panel_friend_degree")
    local buttonFriendDegree    = panelFriendDegree:getChildByName("Button_friend_degree")
    local barFriendDegree       = buttonFriendDegree:getChildByName("LoadingBar_friend_degree")
    local textPercent           = buttonFriendDegree:getChildByName("BitmapFontLabel_1")
    local progressValue         = oneCard.nFeeling / KUtil.MAX_FEELING * KUtil.PERCENT_BASE
    barFriendDegree:setPercent(progressValue)
    textPercent:setString(oneCard.nFeeling .. "%")
    buttonFriendDegree:setVisible(not oneCard.bRing)

    local buttonPlayBack        = panelFriendDegree:getChildByName("Image_married")
    buttonPlayBack:setTouchEnabled(false)
    buttonPlayBack:setVisible(oneCard.bRing)

    --update mount
    local panelMount = baseNode:getChildByName("Panel_mount")
    panelMount:setVisible(bShowMount)

    if bShowMount then
        local panelUnload = panelMount:getChildByName("Panel_1")
        local panelAdd = panelMount:getChildByName("Panel_2")
        local imageWorker = panelUnload:getChildByName("Image_worker")
        local textDescrition = panelUnload:getChildByName("Text_descrition")

        if oneCard.nMountItemTemplateID == 0 then
            panelUnload:setVisible(false)
            panelAdd:setVisible(true)
        else
            panelUnload:setVisible(true)
            panelAdd:setVisible(false)

            local itemTemplateID = oneCard.nMountItemTemplateID
            local itemConfig = KUtil.getItemConfig(itemTemplateID)
            assert(itemConfig, " item config can`t find, item template id:"..itemTemplateID)
            local itemImagePath = KUtil.getItemImagePathByID(itemTemplateID)

            textDescrition:setString(itemConfig.szName)
            imageWorker:loadTexture(itemImagePath)
        end
    end
    
end

function KUtil.updateResourceInfo(panel, titlePath, closeFun)
    local mainNode          = panel._mainLayout
    local resourceBase      = mainNode:getChildByName("ProjectNode_resource_base")
    local resourceNode      = resourceBase:getChildByName("Panel_1")
    local panelResourceBase = resourceNode:getChildByName("Image_base")

    local function updateResource()
        local resourceName      = {"oil", "ammo", "steel", "special_bomb",} 
        local maxResourceName   = {"nMaxOil", "nMaxAmmo", "nMaxSteel", "nMaxPeople",}

        for i, name in ipairs(resourceName) do
            local resourceMaxCount        = KUtil.getPlayerLevelInfo(KPlayer.level, maxResourceName[i])
            local resourceCount           = KPlayer[CURRENCY_KEY[i]]
            local imageCommonMaterialName = "Image_common_material_base" .. i
            local imageCommonMaterial     = panelResourceBase:getChildByName(imageCommonMaterialName)
            local loadingBarControl       = imageCommonMaterial:getChildByName("LoadingBar_" .. name .. "_value")
            loadingBarControl:setPercent(resourceCount / resourceMaxCount * KUtil.PERCENT_BASE)
            
            local labelControl = imageCommonMaterial:getChildByName("Text_" .. name .. "_value")
            labelControl:setString(resourceCount)
        end
    end 
    updateResource()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    panel:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, updateResource)

    if titlePath then
        local titleBase                     = resourceNode:getChildByName("Image_title_base")
        titleBase:loadTexture("res/ui/ui_material/title/" .. titlePath)
    end

    if closeFun then
        local buttonControl = resourceNode:getChildByName("Button_close")
        local function onCloseClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onCloseButton~")
                KSound.playEffect("close")
                buttonControl:setEnabled(false)
                closeFun()
            end
        end
        buttonControl:addTouchEventListener(onCloseClick)
    end
end

function KUtil.playHomeAnimation(panel, isOpen)
    local mainNode     = panel._mainLayout
    local projectNode  = mainNode:getChildByName("ProjectNode_button_home")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_common_home"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

function KUtil.playResourceAnimation(panel, isOpen)
    local mainNode     = panel._mainLayout
    local projectNode  = mainNode:getChildByName("ProjectNode_resource_base")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_common_resource_base"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

function KUtil.stopCommonAnimation(panel)
    local mainNode        = panel._mainLayout
    local projectResource = mainNode:getChildByName("ProjectNode_resource_base")
    projectResource:stopAllActions()

    local projectHome     = mainNode:getChildByName("ProjectNode_button_home")
    projectHome:stopAllActions()
end

function KUtil.stopCommonToFrame(panel)
    local mainNode        = panel._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_resource_base")

    local stopFrame       = 20
    local animationName   = "ani_common_resource_base"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    local projectNode     = mainNode:getChildByName("ProjectNode_button_home")
    local stopFrame       = 20
    local animationName   = "ani_common_home"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)
end

function KUtil.refreshCardSortButton(panelSort, toSortType)
    for sortType, textName in ipairs(KUtil.IMAGE_CARD_SORT) do
        local textSort = panelSort:getChildByName(textName)
        local textVisible = (sortType == toSortType)
        textSort:setVisible(textVisible)
    end
end

function KUtil.refreshCardTypeButton(panelType, toCardType)
    for cardType, textName in ipairs(KUtil.IMAGE_CARD_TYPE) do
        local textSort = panelType:getChildByName(textName)
        local textVisible = (cardType == toCardType)
        textSort:setVisible(textVisible)
    end
end

function KUtil.getCardSortValue(card1, card2, sortType)
    local cardConfig1 = KConfig.cardInfo[card1.nTemplateID]
    local cardConfig2 = KConfig.cardInfo[card2.nTemplateID]
    local value1, value2 = 0, 0
    if KUtil.CHOOSE_COMMON_TYPE.LEVEL == sortType then
         value1 = card1.nLevel
         value2 = card2.nLevel
     elseif KUtil.CHOOSE_COMMON_TYPE.STAR == sortType then
         value1 = cardConfig1.nQuality
         value2 = cardConfig2.nQuality
     elseif KUtil.CHOOSE_COMMON_TYPE.NAME == sortType then
         value1 = cardConfig1.szName
         value2 = cardConfig2.szName
     elseif KUtil.CHOOSE_COMMON_TYPE.TIME == sortType then
         value1 = card1.nCreateTime
         value2 = card2.nCreateTime
     end
     return value1, value2
end

function KUtil.getUnitSelectSortList(list, sortType, opposite)
    local cardTeamMap = {}
    local teamList    = KPlayer.tTeamData.tTeamList
    --cardID teamID map, convenient for sort
    for _, oneTeam in pairs(teamList) do
        for _, cardID in pairs(oneTeam.tCardIDList) do
            cardTeamMap[cardID] = oneTeam.nIndex
        end
    end

    local onSort = function(card1, card2)
        local cardConfig1 = KConfig.cardInfo[card1.nTemplateID]
        local cardConfig2 = KConfig.cardInfo[card2.nTemplateID]
        local cardTeamID1 = cardTeamMap[card1.nID] or (MAX_TEAM_COUNT + 1)
        local cardTeamID2 = cardTeamMap[card2.nID] or (MAX_TEAM_COUNT + 1)
        local value1, value2 = KUtil.getCardSortValue(card1, card2, sortType)
        if cardTeamID1 == cardTeamID2 then
            if value1 == value2 then
                if cardConfig1.szName == cardConfig2.szName then
                    if opposite then
                        return card1.nLevel < card2.nLevel 
                    else
                        return card1.nLevel > card2.nLevel 
                    end
                end
                return cardConfig1.szName < cardConfig2.szName
            else
                if sortType == KUtil.CHOOSE_COMMON_TYPE.NAME then
                    return value1 < value2
                else
                    if opposite then
                        return value1 < value2
                    else
                        return value1 > value2
                    end
                end
            end
        elseif cardTeamID1 ~= cardTeamID2 then
            return cardTeamID1 < cardTeamID2
        end
        return card1.nID > card2.nID
    end
    table.sort(list,  onSort)
    return list
end

function KUtil.getCardBaseNode(projectNode)
    local panelBase   = projectNode:getChildByName("Panel_base")
    panelBase:setScaleX(projectNode:getScaleX())
    panelBase:setScaleY(projectNode:getScaleY())
    return panelBase
end

function KUtil.registerSortButtonList(panelButtonSort, onSortCall, settingKey)
    panelButtonSort:setVisible(false)
    local KSetting = require("src/logic/KSetting")
    local sortSettingKey = settingKey or KSetting.Key.COMMON_CHOOSE_TYPE
    for buttonIndex, buttonName in pairs(KUtil.BUTTON_CARD_SORT) do
        local buttonSort = panelButtonSort:getChildByName(buttonName)
        local sortType = buttonIndex
        local function onSortItemClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KUtil.showUiScale(panelButtonSort, false)
                KSound.playEffect("click")
                KSetting.setInt(sortSettingKey, sortType)
                if onSortCall then onSortCall(sortType) end
            end
        end
        buttonSort:addTouchEventListener(onSortItemClick)
    end
end

function KUtil.registerTypeButtonList(panelButtonType, onTypeCall, settingKey)
    panelButtonType:setVisible(false)
    local KSetting = require("src/logic/KSetting")
    local typeSettingKey = settingKey or KSetting.Key.TEAM_CHOOSE_TYPE
    for buttonIndex, buttonName in pairs(KUtil.BUTTON_CARD_TYPE) do
        local buttonType = panelButtonType:getChildByName(buttonName)
        local sortType = buttonIndex
        local function onSortItemClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KUtil.showUiScale(panelButtonType, false)
                KSound.playEffect("click")
                KSetting.setInt(typeSettingKey, sortType)
                if onTypeCall then onTypeCall(sortType) end
            end
        end
        buttonType:addTouchEventListener(onSortItemClick)
    end
end

function KUtil.getCardBackGround(tankType)
    local filePath = string.format("res/ui/ui_material/cardbase/card_type_%d.png", tankType)
    return filePath
end

function KUtil.getMaxDelayTime(framesList)
    local maxFrame = 0
    for i, frame in ipairs(framesList) do
        maxFrame = math.max(maxFrame, frame)
    end
    local delayTime = maxFrame / KUtil.FRAME_PER_SECOND
    return delayTime
end

function KUtil.removeNodeAllEventListeners(targetNode)
    if not targetNode then return end
    local eventDispatcher = targetNode:getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(targetNode, true)
end

function KUtil.closePanel(panelNode, panelName, isReturnOffice)
    if isReturnOffice then
        panelNode._parent:returnOffice()
    else
        panelNode._parent:removeNode(panelName)
    end
end

function KUtil.delayClosePanel(panelNode, panelName, callBacks, isReturnOffice)
    if panelNode.isClosing then return end
    panelNode.isClosing = true
    KUtil.removeNodeAllEventListeners(panelNode)
    local callLength = #callBacks
    if callLength == 0 then 
        KUtil.closePanel(panelNode, panelName, isReturnOffice)
        return
    end

    local callIndex = 0
    local  function delayFun()
        if callLength == callIndex then
            KUtil.closePanel(panelNode, panelName, isReturnOffice)
            return
        end
        callIndex = callIndex + 1
        local framesList = callBacks[callIndex]()
        local delayTime  = KUtil.getMaxDelayTime(framesList)
        delayExecute(panelNode, delayFun, delayTime)
    end
    delayFun()
end

function KUtil.getAnimationPath(animationName)
    local animationPath = string.format("res/ui/animation_node/%s.csb", animationName)
    return animationPath
end

function KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    projectNode:stopAllActions()
    local animationPath   = KUtil.getAnimationPath(animationName)
    local animationAction = cc.CSLoader:createTimeline(animationPath)
    projectNode:runAction(animationAction)

    local startFrame, endFrame = 0, 0
    if isOpen then
        startFrame, endFrame = 0, openEndFrame
    else
        startFrame, endFrame = closeStartFrame, animationAction:getDuration()
    end
    local delayFrame = endFrame - startFrame
    animationAction:gotoFrameAndPlay(startFrame, endFrame, false)

    -- add delay function to pause
    local function stopNode()
        if KUtil.isNodeExist(animationAction) then
            animationAction:gotoFrameAndPause(endFrame)
        end
    end 
    local delayTime = math.max(delayFrame / KUtil.FRAME_PER_SECOND, 0)
    delayExecute(projectNode, stopNode, delayTime)

    return delayFrame
end

function KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)
    projectNode:stopAllActions()

    local animationPath   = KUtil.getAnimationPath(animationName)
    local animationAction = cc.CSLoader:createTimeline(animationPath)
    projectNode:runAction(animationAction)

    animationAction:gotoFrameAndPause(stopFrame)
end

function KUtil.initPanelCommonNode(panel, callBack, titileName)
    local mainNode        = panel._mainLayout
    --Close Button
    local resourceProject = mainNode:getChildByName("ProjectNode_resource_base")
    local resourcePanel   = resourceProject:getChildByName("Panel_1")
    local buttonClose     = resourcePanel:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            callBack(false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    --Home Button
    local buttonProject = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome     = buttonProject:getChildByName("Panel_common_home")
    local buttonHome    = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")       
            callBack(true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    --resource bar
    KUtil.setTitleName(panel, titileName)
end

function  KUtil.initHomeAndResourceNode(panel, callBack, titileName)
    KUtil.initPanelCommonNode(panel, callBack, titileName)
    KUtil.updateResourceInfo(panel)
    local mainNode        = panel._mainLayout
    local buttonProject     = mainNode:getChildByName("ProjectNode_button_home")
    local animationHome     = KUtil.initAnimation(buttonProject, "res/ui/animation_node/ani_common_home.csb")
    local resourceProject   = mainNode:getChildByName("ProjectNode_resource_base")
    local animationResource = KUtil.initAnimation(resourceProject, "res/ui/animation_node/ani_common_resource_base.csb")
    return animationHome, animationResource
end

function KUtil.setTitleName(panel, titileName)
    if not titileName then
        cclog("not title name, please input the file name")
        return
    end
    local mainNode        = panel._mainLayout
    local resourceProject = mainNode:getChildByName("ProjectNode_resource_base")
    local resourcePanel   = resourceProject:getChildByName("Panel_1")
    local imageTile       = resourcePanel:getChildByName("Image_title_base")
    local titlePath       = string.format("res/ui/ui_material/title/%s.png", titileName)
    imageTile:loadTexture(titlePath)
end

function KUtil.initAnimation(node, szAnimationPath)
    node:stopAllActions()
    local animationAction = cc.CSLoader:createTimeline(szAnimationPath)
    node:runAction(animationAction)
    animationAction:gotoFrameAndPause(0)
    return animationAction
end

function KUtil.animationGotoFrameAndPlay(animation, beginFrame, endFrame, isLoop)
    -- print("animationGotoFrameAndPlay:", beginFrame, endFrame)
    animation:gotoFrameAndPlay(beginFrame, endFrame, isLoop)
    -- animation:gotoFrameAndPause(endFrame)
    return (endFrame - beginFrame) / KUtil.FRAME_PER_SECOND
end

function KUtil.playEnterAnimation(animation, beginFrame, endFrame)
    if not beginFrame then beginFrame = 0 end
    if not endFrame then endFrame = 15 end
    return KUtil.animationGotoFrameAndPlay(animation, beginFrame, endFrame, false)
end

function KUtil.playQuitAnimation(animation, beginFrame, endFrame)
    if not beginFrame then beginFrame = 49 end
    if not endFrame then endFrame = 65 end
    return KUtil.animationGotoFrameAndPlay(animation, beginFrame, endFrame, false)
end

function KUtil.checkActivationCode(szActivationCode)
    --print("checkActivationCode", string.match(szActivationCode, "^[%a%d]+$"))
    if string.len(szActivationCode) ~= ACTIVATION_CODE_LENGTH or not string.match(szActivationCode, "^[%a%d]+$") then
        return "common.register.activationCodeError"
    end
end

function KUtil.addDynamicPageView(pageData)
    local pageView     = pageData.pageView
    local onePage      = pageData.onePage
    local unitBase     = pageData.unitBase
    local moveCall     = pageData.moveCall
    local dataList     = pageData.dataList
    local pageSize     = pageData.pageSize
    local pageIndex    = pageData.pageIndex
    local showPageSize = 3 -- keep three page always
    for i = 2, showPageSize do
        local panelClone = onePage:clone()
        pageView:addPage(panelClone)
    end

    local movePageData = {
        uiPageIndex  = 1, -- keep page show on middle area always
        pageView     = pageView,
        onePage      = onePage,
        unitBase     = unitBase,
        moveCall     = moveCall,
        dataList     = dataList,
        pageSize     = pageSize,
        pageIndex    = pageIndex,
    }
    KUtil.refreshDynamicPageView(movePageData)
    -- register event
    pageView:setCustomScrollThreshold(100) -- 100 pixel
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then
            local curPageIndex = sender:getCurPageIndex()
            local uiPageIndex  = movePageData.uiPageIndex
            if curPageIndex == uiPageIndex then return end
            -- next page
            if uiPageIndex < curPageIndex then
                KUtil.nextDynamicPage(movePageData)
            else
                KUtil.preDynamicPage(movePageData)
            end
        end
    end
    pageView:addEventListener(onPageViewEvent)

    return movePageData
end

function KUtil.refreshDynamicPageView(pageData)
    local pageView     = pageData.pageView
    local onePage      = pageData.onePage
    local unitBase     = pageData.unitBase
    local moveCall     = pageData.moveCall
    local dataList     = pageData.dataList
    local pageSize     = pageData.pageSize
    local pageIndex    = pageData.pageIndex
    local listSize     = #dataList

    local pageCount = math.ceil(listSize / pageSize)
    -- get pre page index
    local prePageIndex = pageIndex - 1
    if prePageIndex <= 0 then
        prePageIndex = pageCount
    end
    -- get next page index
    local nextPageIndex = pageIndex + 1
    if nextPageIndex > pageCount then
        nextPageIndex = 1
    end

    local threePageIndex = {prePageIndex, pageIndex, nextPageIndex}
    local threePageData  = {}
    for index, tempIndex in ipairs(threePageIndex) do
        if not threePageData[index] then threePageData[index] = {} end
        local startIndex = (tempIndex - 1) * pageSize + 1
        local endIndex = startIndex + pageSize - 1
        for itemIndex = startIndex, endIndex do
            local itemData = dataList[itemIndex]
            if not itemData then break end
            table.insert(threePageData[index], itemData)
        end
    end

    for index, pageListData in ipairs(threePageData) do
        local uiPageIndex    = index - 1
        local pageUI         = pageView:getPage(uiPageIndex)
        moveCall(pageListData, pageUI)
    end

    pageData.uiPageIndex = 1
    pageView:scrollToPage(1)
    pageView:update(1)
end

function KUtil.nextDynamicPage(pageData)
    local pageView     = pageData.pageView
    local dataList     = pageData.dataList
    local pageSize     = pageData.pageSize
    local pageIndex    = pageData.pageIndex
    local listSize     = #dataList

    local pageUI = pageView:getPage(0)
    pageUI:retain()
    pageView:removePageAtIndex(0)
    pageView:insertPage(pageUI, 2)
    pageUI:release()

    local pageCount    = math.ceil(listSize / pageSize)
    pageIndex          = pageIndex + 1
    if pageIndex > pageCount then
        pageIndex = 1
    end

    pageData.pageIndex = pageIndex
    KUtil.refreshDynamicPageView(pageData)
end

function KUtil.preDynamicPage(pageData)
    local pageView     = pageData.pageView
    local dataList     = pageData.dataList
    local pageSize     = pageData.pageSize
    local pageIndex    = pageData.pageIndex
    local listSize     = #dataList

    local pageUI = pageView:getPage(2)
    pageUI:retain()
    pageView:removePageAtIndex(2)
    pageView:insertPage(pageUI, 0)
    pageUI:release()

    local pageCount    = math.ceil(listSize / pageSize)
    pageIndex          = pageIndex - 1
    if pageIndex <= 0 then
        pageIndex = pageCount
    end
    pageData.pageIndex = pageIndex
    KUtil.refreshDynamicPageView(pageData)
end

function KUtil.updateCardHeadBase(baseNode, oneCard)
    if not baseNode.projectCard then
        local cardBase = cc.CSLoader:createNode("res/ui/layout_cardbase_small.csb")
        baseNode:addChild(cardBase)
        baseNode.projectCard = cardBase
    end
    local projectCard = baseNode.projectCard
    KUtil.onlyUpdateCardHeadBase(projectCard, oneCard)
end

function KUtil.onlyUpdateCardHeadBase(projectCard, oneCard)
    assert(projectCard, oneCard)
    if not oneCard.nID then
        return KUtil.onlyUpdateCardHeadBaseByMonsterTemplateID(projectCard, oneCard.nTemplateID, oneCard.nCurrentHP)
    end
    local cardConfig     = KConfig.cardInfo[oneCard.nTemplateID]
    assert(cardConfig, "card template ID:" .. oneCard.nTemplateID)
    local cardHeadPath   = KUtil.getCardImagePath(oneCard, true)

    KUtil.onlyUpdateHeadBase(projectCard, cardHeadPath, oneCard.bRing, cardConfig.nQuality, cardConfig.nTankType, cardConfig.nCountryType)
end

function KUtil.onlyUpdatePlayerCardHeadBase(projectCard, oneCard)
    assert(projectCard, oneCard)
    local cardConfig     = KConfig.cardInfo[oneCard.nTemplateID]
    assert(cardConfig, "card template ID:" .. oneCard.nTemplateID)
    local cardHeadPath   = KUtil.getPlayerCardImagePath(oneCard, true)

    KUtil.onlyUpdateHeadBase(projectCard, cardHeadPath, oneCard.bRing, cardConfig.nQuality, cardConfig.nTankType, cardConfig.nCountryType)
end

function KUtil.onlyUpdateCardHeadBaseByMonsterTemplateID(projectCard, nMonsterTemplateID, nHP)
    local tMonsterConfig = KConfig.monster[nMonsterTemplateID]
    assert(tMonsterConfig)
    local szHeadPath     = KUtil.getMonsterImagePathByConfigID(nMonsterTemplateID, true, nHP)

    KUtil.onlyUpdateHeadBase(projectCard, szHeadPath, false, tMonsterConfig.nQuality, tMonsterConfig.nType, tMonsterConfig.nCountryType)
end

function KUtil.onlyUpdateHeadBase(projectCard, szCardHeadPath, bRing, nQuality, nTankType, nCountryType)
    local imageCardBase  = projectCard:getChildByName("Image_chara")
    local imageCardHead  = projectCard:getChildByName("Image_chara_head")
    local imageCardType  = projectCard:getChildByName("Image_chara_type")
    local imageCardMedal = projectCard:getChildByName("Image_card_medal")
    local projectHeart   = projectCard:getChildByName("ProjectNode_heart")
    
    local backgroundPath = string.format("res/images/cards/type/basemap-%d.png", nQuality)
    local medalPath      = string.format("res/ui/ui_material/cardbase/card_medal_%d.png", nQuality)
    local headTypePath   = KUtil.getCardBackGround(nTankType)
    if bRing then
        backgroundPath  = "res/images/cards/type/basemap-ring.png"
    end
    print("onlyUpdateHeadBase", szCardHeadPath)
    imageCardBase:loadTexture(backgroundPath)
    imageCardHead:loadTexture(szCardHeadPath)
    imageCardType:loadTexture(headTypePath)
    imageCardMedal:loadTexture(medalPath)
    projectHeart:setVisible(bRing)

    --update head back
    local countryType         = nCountryType
    local cardHeadBackFormat  = "Image_chara_%s"
    KUtil.setCardHeadBack(projectCard, countryType, cardHeadBackFormat)
end

function KUtil.updateMonsterHeadBase(baseNode, oneCard)
    local imageCardBase  = baseNode:getChildByName("Image_chara")
    local imageCardHead  = baseNode:getChildByName("Image_chara_head")
    local imageCardType  = baseNode:getChildByName("Image_chara_type")
    local imageCardMedal = baseNode:getChildByName("Image_card_medal")
    local projectHeart   = baseNode:getChildByName("ProjectNode_heart")

    local cardConfig     = KConfig.monster[oneCard.nTemplateID]
    local backgroundPath = string.format("res/images/cards/type/basemap-%d.png", cardConfig.nQuality + 6)
    local medalPath      = string.format("res/ui/ui_material/cardbase/card_medal_%d.png", cardConfig.nQuality)
    local headTypePath   = KUtil.getCardBackGround(cardConfig.nType)
    local cardHeadPath   = KUtil.getMonsterImagePath(oneCard, true)
    if oneCard.bRing then
        backgroundPath  = "res/images/cards/type/basemap-ring.png"
    end

    imageCardBase:loadTexture(backgroundPath)
    imageCardHead:loadTexture(cardHeadPath)
    imageCardType:loadTexture(headTypePath)
    imageCardMedal:loadTexture(medalPath)
    projectHeart:setVisible(oneCard.bRing)

    local imageCardBack = baseNode:getChildByName("Image_chara_base")
    imageCardBack:setFlippedX(true)
    local backPosX      = imageCardBack:getPositionX()
    local offsetX       = 6
    local newBackPosX   = backPosX + offsetX
    imageCardBack:setPositionX(newBackPosX)
    
    local typePosX    = imageCardType:getPositionX()
    local typePosY    = imageCardType:getPositionY()
    local newTypePosX = backPosX - typePosX + newBackPosX
    local newTypePosY = typePosY
    imageCardType:setPosition(cc.p(newTypePosX, newTypePosY))
    imageCardMedal:setPosition(cc.p(newTypePosX, newTypePosY))

    --update head back
    local countryType         = CARD_COUNTRY_TYPE.BASE
    local cardHeadBackFormat  = "Image_chara_%s"
    KUtil.setCardHeadBack(baseNode, countryType, cardHeadBackFormat)
end

function KUtil.updateRightTeamHeadBase(baseNode, oneCard, isMonster)
    if isMonster then
        KUtil.updateMonsterHeadBase(baseNode, oneCard)
    else
        KUtil.onlyUpdatePlayerCardHeadBase(baseNode, oneCard)
        --KUtil.onlyUpdateCardHeadBase(baseNode, oneCard)
    end
end

function KUtil.getCardBackImagePathByQuality(quality)
    local imagePath  = "res/ui/ui_material/award/jl_background" .. quality .. ".png"
    return imagePath
end

function KUtil.getCollectionCardBackImagePathByQuality(quality)
    local imagePath  = "res/ui/ui_material/award/jl_background_collection" .. quality .. ".png"
    return imagePath
end

function KUtil.getCollectionCardBackImagePath(cardID, isMarried)
    if isMarried then
        return "res/ui/ui_material/award/jl_background_ring1.png"
    end
    local cardConfig = KUtil.getCardConfig(cardID)
    assert(cardConfig)
    local quality    = cardConfig.nQuality
    return KUtil.getCollectionCardBackImagePathByQuality(quality)
end

function KUtil.getCardBackImagePath(cardID, isMarried)
    if isMarried then
        return "res/ui/ui_material/award/jl_background_ring.png"
    end
    local cardConfig = KUtil.getCardConfig(cardID)
    assert(cardConfig)
    local quality    = cardConfig.nQuality
    return KUtil.getCardBackImagePathByQuality(quality)
end

function KUtil.getCardMedalPath(cardID)
    local cardConfig = KUtil.getCardConfig(cardID)
    assert(cardConfig)
    local quality    = cardConfig.nQuality
    local imagePath  = string.format("res/ui/ui_material/cardbase/card_medal_%d.png", cardConfig.nQuality)
    return imagePath
end

function KUtil.getCardQualityBackgroundPath(quality)
    return string.format("res/images/cards/type/basemap-%d.png", quality)
end

function KUtil.asynLoadTexture(image, path)
    image.path = path
    local function imageLoaded()
        if image.path == path and KUtil.isNodeExist(image) then 
            image:loadTexture(path)
            image:setVisible(true)
        end
    end
    cc.Director:getInstance():getTextureCache():addImageAsync(path, imageLoaded)
end

function KUtil.supplyTeamCard(teamID)
    local fullSize = 0
    local cardList  = KUtil.getOneTeamCardList(teamID)
    local needOil, needAmmo, needSteel, needSpammo  = KUtil.getTotalSupplyData(teamID, true)

    if #cardList == 0 then
        showNoticeByID("expedition.teamEmpty")
        return false
    end

    if needOil == 0 and needAmmo == 0 and needSteel == 0 and needSpammo == 0 then
        showNoticeByID("expedition.supplyFull")
        return false
    end

    local oil, ammo, steel, people  = KPlayer.oil, KPlayer.ammo, KPlayer.steel, KPlayer.people
    if needOil > oil or needAmmo > ammo or needSteel > steel or needSpammo > people then
        showNoticeByID("expedition.notEnough")
        return false
    end
    require("src/network/KC2SProtocolManager"):supplyTeam(teamID, true)
    return true
end

function KUtil.isNodeExist(node)
    return not tolua.isnull(node)
end

function KUtil.getCardBaseBackGround(nTemplateID, isMarried)
    local cardConfig = KConfig.cardInfo[nTemplateID]
    if isMarried then
        return "res/ui/ui_material/cardbase/card_base_ring.png"
    end
    return "res/ui/ui_material/cardbase/card_base_" .. cardConfig.nQuality .. ".png"
end

function KUtil.getExpeditionBackGround(index)
    local mapNameList = {
        [1] = "epedition_map_1",
        [2] = "epedition_map_3",
        [3] = "epedition_map_2",
        [4] = "epedition_map_2", 
        [5] = "epedition_map_1",
        [6] = "epedition_map_1",
    }
    local mapName = mapNameList[index] or mapNameList[1]
    local filePath = string.format("res/ui/ui_material/expedition/%s.png", mapName)
    return filePath
end

-- the area code will be discarded
-- draw head
function KUtil.drawRoleHeadUi(headUI, card)
    local cardConfig    = KConfig.cardInfo[card.nTemplateID]
    local backgroundPath    = "basemap-"..cardConfig.nQuality..".png"
    local headLevelPath = "level-"..cardConfig.nQuality..".png"
    local headTypePath  = "type-"..cardConfig.nTankType..".png"
    local cardHeadPath  =  KUtil.getCardImagePath(card, true)
    backgroundPath    = "res/images/cards/type/"..backgroundPath
    headLevelPath = "res/images/cards/type/"..headLevelPath
    headTypePath  = "res/images/cards/type/"..headTypePath
    if card.bRing then
        backgroundPath  = "res/images/cards/type/basemap-ring.png"
    end

    headUI:loadTexture(backgroundPath)
     if not headUI.imageHead then
        headUI.imageHead = ccui.ImageView:create(cardHeadPath)
        headUI:addChild(headUI.imageHead)
        local size = headUI:getContentSize()
        local pos = {x = size.width/2, y = size.height/2 }
        headUI.imageHead:setPosition(pos)
    end
    headUI.imageHead:loadTexture(cardHeadPath)

    if not headUI.imageLeve then
        headUI.imageLeve = ccui.ImageView:create(headLevelPath)
        headUI:addChild(headUI.imageLeve)
        local size = headUI.imageLeve:getContentSize()
        local pos = {x = size.width/2, y = size.height/2 }
        headUI.imageLeve:setPosition(pos)
    end
    headUI.imageLeve:loadTexture(headLevelPath)

    if not headUI.imageType then
        headUI.imageType = ccui.ImageView:create(headTypePath)
        headUI:addChild(headUI.imageType)
        local size = headUI.imageType:getContentSize()
        local pos = {x = size.width/2, y = size.height/2 + 5}
        headUI.imageType:setPosition(pos)
    end
    headUI.imageType:loadTexture(headTypePath)

    if card.bRing then
        if not headUI.heart then
            headUI.heart = cc.CSLoader:createNode("res/ui/animation_node/ani_floating_heart.csb")
            local action = cc.CSLoader:createTimeline("res/ui/animation_node/ani_floating_heart.csb")
            headUI.heart:runAction(action)
            action:gotoFrameAndPlay(0, action:getDuration(), true)
            local size = headUI:getContentSize()
            local x = size.width * 11 / 12
            local y = size.height * 3 / 5
            local pos = {x = x, y = y}
            headUI.heart:setPosition(pos)
            headUI:addChild(headUI.heart)
        end
    else
        if headUI.heart then
            headUI:removeChild(headUI.heart)
            headUI.heart = nil
        end
    end
end

-- draw monster head
function KUtil.drawMonsterHeadUi(headUI, card)
    local cardConfig     = KConfig.monster[card.nTemplateID]
    local headTypePath   = "type-" .. cardConfig.nType .. ".png"
    local headLevelPath  = "level-" .. cardConfig.nQuality .. ".png"
    local backgroundPath = "basemap-" .. cardConfig.nQuality + 6 .. ".png"
    local cardHeadPath   = KUtil.getMonsterImagePath(card, true)
    headTypePath         = "res/images/cards/type/" .. headTypePath
    headLevelPath        = "res/images/cards/type/" .. headLevelPath
    backgroundPath       = "res/images/cards/type/" .. backgroundPath
    headUI:loadTexture(backgroundPath)

    if not headUI.imageHead then
        headUI.imageHead = ccui.ImageView:create(cardHeadPath)
        headUI:addChild(headUI.imageHead)
        local size = headUI:getContentSize()
        local pos  = {x = size.width / 2, y = size.height / 2}
        headUI.imageHead:setPosition(pos)
    end
    headUI.imageHead:loadTexture(cardHeadPath)

    if not headUI.imageLeve then
        headUI.imageLeve = ccui.ImageView:create(headLevelPath)
        headUI:addChild(headUI.imageLeve)
        local headSize  = headUI:getContentSize()
        local madelSize = headUI.imageLeve:getContentSize()
        local pos  = {x = headSize.width - madelSize.width / 2, y = madelSize.height / 2}
        headUI.imageLeve:setPosition(pos)
        headUI.imageLeve:setFlippedX(true)
    end
    headUI.imageLeve:loadTexture(headLevelPath)

    if not headUI.imageType then
        headUI.imageType = ccui.ImageView:create(headTypePath)
        headUI:addChild(headUI.imageType)
        local headSize = headUI:getContentSize()
        local typeSize = headUI.imageType:getContentSize()
        local pos = {x = headSize.width - typeSize.width / 2 + 5, y = typeSize.height / 2 + 5}
        headUI.imageType:setPosition(pos)
    end
    headUI.imageType:loadTexture(headTypePath)
end

function KUtil.drawRightHeadUi(headUI, card)
    if card.bIsRole then
        KUtil.drawRoleHeadUi(headUI, card)
    else
        KUtil.drawMonsterHeadUi(headUI, card)
    end
end

function KUtil.switchAccountClean(currentAccount)
    local setting      = require("src/logic/KSetting")
    local storeAccount = setting.getString(setting.Key.ACCOUNT)
    if not currentAccount or not storeAccount then return end

    -- reset to default value
    if currentAccount ~= storeAccount then
        setting.setInt(setting.Key.LAST_LAUNCH_ZONE_INDEX, 0)
        setting.setInt(setting.Key.LAST_LAUNCH_TEAM_INDEX, 0)
        setting.setInt(setting.Key.LAST_LAUNCH_PLAYER_ID, 0)

        setting.setInt(setting.Key.TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
        setting.setInt(setting.Key.COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
        setting.setInt(setting.Key.BREAK_TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
        setting.setInt(setting.Key.BREAK_COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
        setting.setInt(setting.Key.EQUIP_CHANGE_CHOOSE_COMMON, KUtil.CHOOSE_COMMON_TYPE.NAME)
        setting.setInt(setting.Key.EQUIP_BREAK_CHOOSE_COMMON, KUtil.CHOOSE_COMMON_TYPE.NAME)
        setting.setInt(setting.Key.SECRETARY_TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
        setting.setInt(setting.Key.SECRETARY_COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    end
end

function KUtil.getBattleMusicSetting(zoneID, mapID, footholdID)
    local mapSetting = KUtil.getBattleSetting(zoneID, mapID, 1)
    assert(mapSetting)

    local mapMusic, fightMusic, nightMusic = mapSetting.szMapMusic, mapSetting.szFightMusic, mapSetting.szNightMusic

    local footSetting = KUtil.getBattleSetting(zoneID, mapID, footholdID)
    assert(footSetting)

    if footSetting.szMapMusic and string.len(footSetting.szMapMusic) > 0 then
        mapMusic = footSetting.szMapMusic
    end

    if footSetting.szFightMusic and string.len(footSetting.szFightMusic) > 0 then
        fightMusic = footSetting.szFightMusic
    end

    if footSetting.szNightMusic and string.len(footSetting.szNightMusic) > 0 then
        nightMusic = footSetting.szNightMusic
    end
    
    return mapMusic, fightMusic, nightMusic
end

function KUtil.getCardCollectRate()
    local configCardCount = 0
    for _, card in pairs(KConfig.cardInfo) do
        if card then
            configCardCount = configCardCount + 1
        end
    end
    
    local historicalCardCount = #KPlayer.tCardData.tHistoricalCardID

    local rate = historicalCardCount / configCardCount * 100
    rate = math.min(rate, 100)

    return rate
end

function KUtil.getEquipCollectRate()
    local configEquipCount = 0
    for _, equip in pairs(KConfig.equipInfo) do
        if equip and equip.bCollectable then
            configEquipCount = configEquipCount + 1
        end
    end
    
    local historicalEquipCount = #KPlayer.tItemData.tHistoricalEquipID

    local rate = historicalEquipCount / configEquipCount * 100
    rate = math.min(rate, 100)

    return rate
end

function KUtil.getSecretaryCard()
    local teamLeaderCard    = KUtil.getTeamLeaderCard()
    local secretaryData     = KPlayer.tSecretaryData
    local secretaryCard     = KUtil.getCardById(secretaryData.nCardID)

    if secretaryData.nType == SECRETARY_TYPE.TEAM_LEADER then
        return teamLeaderCard
    elseif secretaryData.nType == SECRETARY_TYPE.DESIGNATE then
        return secretaryCard
    end

    assert(false)
end

function KUtil.checkSPSign(parent)
    local spSignData    = KPlayer.tSPSignData
    local lastSignIndex = GetDayIndex(spSignData.nLastSignTime)
    local nowTimeIndex  = GetDayIndex(KUtil.getServerTime(os.time()))
    local config        = KConfig.spSign[1]
    local isOpen        = KUtil.isOpeningTime(KUtil.getCurrentServerTime(), config.otOpenTimes)

    if not isOpen then return end
    if spSignData.nSignDay >= #KConfig.spSign then return end

    if lastSignIndex ~= nowTimeIndex then
        parent:addNode("SPSign")
    end
end

function KUtil.requestMarryCard(cardID)
    local oneCard   = KUtil.getCardById(cardID)
    if oneCard.bRing then
        showNoticeByID("marry.haveMarry")
        return 
    end

    local function getRingData()
        local ringList = {}
        for _, itemInfo in pairs(KConfig.itemInfo) do
            if itemInfo.nType == ITEM_SMALL_TYPE.RING then 
                table.insert(ringList, itemInfo) 
            end
        end
        local function funSort(item1, item2)
            return item1.nUseLevel < item2.nUseLevel 
        end
        table.sort(ringList, funSort)
        return ringList
    end

    local function getListData(itemType)
        local showListData = {}
        for _, itemInfo in pairs(KPlayer.tItemData.tStoreHouse.tItemList) do
            local itemConfig = KConfig.itemInfo[itemInfo.nTemplateID]
            if itemConfig.nType == itemType then
                table.insert(showListData, itemInfo)
            end
        end

        local function funSort(item1, item2)
            local itemConfig1 = KConfig.itemInfo[item1.nTemplateID]
            local itemConfig2 = KConfig.itemInfo[item2.nTemplateID]
            return itemConfig1.szName < itemConfig2.szName 
        end
        table.sort(showListData, funSort)

        return showListData
    end

    local ringList = getRingData()
    assert(#ringList >= 2)
    local ring1 = ringList[1]
    local ring2 = ringList[2]
    local ringTip1 = string.format(KUtil.getStringByKey("marry.ringTip1"), ring2.nUseLevel, ring1.szName)
    local ringTip2 = string.format(KUtil.getStringByKey("marry.ringTip2"), ring2.szName, ring2.szName, ring1.szName)
    local userLevel = ring2.nUseLevel
    local function onConfirm()
        local list = getListData(ITEM_SMALL_TYPE.RING)
        if #list <= 0 then showNoticeByID("marry.notAnyRing") return end
        require("src/network/KC2SProtocolManager"):wearMarriageRing(cardID)
    end
    local showString = ringTip1
    if oneCard.nLevel >= userLevel then
        showString = ringTip2
    end
    showConfirmation(showString, onConfirm)
end

function KUtil.isSkillEquip(nTemplateID)
    local equipConfig     = KConfig.equipInfo[nTemplateID]
    assert(equipConfig, string.format("nTemplateID = %d not found", nTemplateID))
    return equipConfig.nSkill > 0
end

function KUtil.addRegisterRecord(szName, cardID)
    if true then return end
    local playerProgress = KPlayer.progressID
    if playerProgress > ROLE_PROCESS_TYPE.ROLE_PROGRESS_CHOOSE_CARD then
        return
    end

    require("src/network/KC2SProtocolManager"):addRegisterStageReocrd(szName, cardID)
end

function KUtil.isOpenedBuildActicity()
    local buildActivityConfig = KConfig.buildactivity
    for _, v in ipairs(buildActivityConfig) do 
        if KUtil.isOpeningTime(KUtil.getCurrentServerTime(), v.otOpenTimes) then
            return true, v
        end
    end

    return false, nil
end
function KUtil.checkStoryReward()
    for storyID, storyConfig in ipairs(KConfig.story) do
        if KUtil.canGainStoryReward(storyID) then
            return storyID
        end
    end
end

function KUtil.canGainStoryReward(storyID)
    local storyConfig = KConfig.story[storyID]
    assert(storyConfig, "no story config:" .. storyID)

    local storyData = KPlayer.tStoryData
    local value = HArray.FindFirstByValue(storyData.tGainRewardList, storyID)
    if value then
        return false
    end

    if not KUtil.isOpeningTime(KUtil.getServerTime(os.time()), storyConfig.otOpenTimes) then
        return false
    end

    if storyConfig.nConditionPlayerLevel > KPlayer.level then
        return false
    end

    if storyConfig.nConditionFinishStory > 0 then
        local hasGain   = HArray.FindFirstByValue(storyData.tGainRewardList, storyConfig.nConditionFinishStory)
        if not hasGain then
            return false
        end
    end

    local condCardList = string.split(storyConfig.szConditionCard, "|")
    if #storyConfig.szConditionCard > 0 then
        local cardList = KPlayer.tCardData.tStoreHouse.tCardList
        local sum = {}
        for cardID, oneCard in ipairs(cardList) do
            local tempID  = oneCard.nTemplateID
            sum[tempID] = sum[tempID] or 0
            sum[tempID] = sum[tempID] + 1
        end

        for _, cardIDCountStr in ipairs(condCardList) do
            local idCountPair = string.split(cardIDCountStr, ":")
            local cardTemplateID, count = tonumber(idCountPair[1]), tonumber(idCountPair[2])
            if (not sum[cardTemplateID]) or sum[cardTemplateID] < count then
                return false
            end
        end
    end

    if storyConfig.szConditionCardLevel ~= "" then
        local paramList = string.split(storyConfig.szConditionCardLevel, "|")
        assert(#paramList == 2)
        local cardTemplateID, cardLevel = tonumber(paramList[1]), tonumber(paramList[2])

        local cardList = KPlayer.tCardData.tStoreHouse.tCardList
        local result = false
        for cardID, oneCard in ipairs(cardList) do
            if oneCard.nTemplateID == cardTemplateID and oneCard.nLevel >= cardLevel then
                result = true
                break
            end
        end

        if not result then
            return false
        end
    end

    if storyConfig.szMapPass ~= "" then
        local paramList = string.split(storyConfig.szMapPass, "-")
        local zoneID, mapID = tonumber(paramList[1]), tonumber(paramList[2])
        local oneBattleMapData = KUtil.getBattleMapData(zoneID, mapID)

        if (not oneBattleMapData) or (not oneBattleMapData.bPass) then
            return false
        end
    end

    return true
end

function KUtil.getCardWarItem(cardID, warID)
    local trainingInfo = KConfig.trainingCard[cardID]
    assert(trainingInfo, "trainingInfo not found! cardID=:" .. cardID)
    return HArray.FindFirst(trainingInfo.tList, "nWarID", warID)
end
