
local STATE_INVALID = "STATE_INVALID"
local STATE_INIT_BEGIN = "STATE_INIT_BEGIN"
local STATE_INIT_END = "STATE_INIT_END"
local STATE_SETUP_BEGIN = "STATE_SETUP_BEGIN"
local STATE_SETUP_END = "STATE_SETUP_END"
local STATE_QUERY_BEGIN = "STATE_QUERY_BEGIN"
local STATE_QUERY_END = "STATE_QUERY_END"
local STATE_READY = "STATE_READY"

AppBilling = {}

AppBilling.REQUEST_CODE                                = 10002
AppBilling.ITEM_TYPE_INAPP                             = "inapp"
AppBilling.ITEM_TYPE_subs                              = "subs"
AppBilling.BILLING_RESPONSE_RESULT_OK                  = 0;
AppBilling.BILLING_RESPONSE_RESULT_USER_CANCELED       = 1;
AppBilling.BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE = 3;
AppBilling.BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE    = 4;
AppBilling.BILLING_RESPONSE_RESULT_DEVELOPER_ERROR     = 5;
AppBilling.BILLING_RESPONSE_RESULT_ERROR               = 6;
AppBilling.BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED  = 7;
AppBilling.BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED      = 8;

AppBilling.tGoodsID2SkuName = 
{
    [2] = "com.capricegame.panzergirls.coin30.id2",
    [3] = "com.capricegame.panzergirls.coin98.id3",
    [4] = "com.capricegame.panzergirls.coin198.id4",
    [75] = "com.capricegame.panzergirls.coin6.id75",
    [80] = "com.capricegame.panzergirls.coin328.id80",
    [81] = "com.capricegame.panzergirls.coin648.id81",
}

AppBilling.nState = STATE_INVALID
AppBilling.bDebugLogging = true
AppBilling.tGoodsList = {}

function AppBilling.GetPublicKey()
    return [[MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzR43gkJsbvzCX0vPBNv2KCgSuYkWPWK59xTm3+/lpyBwUGIFIeaehAQUy1CSs9taW+7NxCEgNyw/8hW5uNu3eH2oD0AuKQFP4j649TH/iPaB2D6bq4SAwFxxaRxi1JcJp+/cj6/GklSLkwLDsDVaqTM/otCWM+8X/QTrBFvESTj3UykN40+MW0vk10I3Enmq0UTitKjht+vUHnYFQkeyZL2w6ZflYql9zm/maqapn07Qi/laq7royee2OiB24mXdoqA3IRcYqKXSHmZKreR3K4KhSBgQfgwCywc4aXgtwwlM1EStTcBK+xSXl6EbRiY0mN73WoJldwdJVmOCzf7XLQIDAQAB]]
end

function AppBilling.CallAppBillingApi(strFuncName, tArgs)
    local strResult = C_AppBilling(strFuncName, LuaValue2JsonString(tArgs) or "")
    assert(strResult)
    local tJsonResult = JsonString2LuaValue(strResult)
    assert(tJsonResult)
    if tJsonResult.status ~= "success" then
        C_Log("AppBilling.CallAppBillingApi " .. strFuncName .. " Error:" .. tJsonResult.result.description)
    end
    return tJsonResult
end

function AppBilling.CanBeginInit()
    local tJsonResult = AppBilling.CallAppBillingApi("can_begin_init")
    return tJsonResult.status == "success"
end

function AppBilling.Init()
    assert(AppBilling.nState == STATE_INVALID)
    if not AppBilling.CanBeginInit() then
        C_Log("AppBilling.CanBeginInit() false")
        return
    end

    C_Log("AppBilling.CanBeginInit() true")

    local tInitArgs = 
    {
       public_key = AppBilling.GetPublicKey(),
       is_debug_logging = AppBilling.bDebugLogging, 
    }

    local tJsonResult = AppBilling.CallAppBillingApi("init", tInitArgs)
    if tJsonResult.status == "success" then
        AppBilling.nState = STATE_INIT_BEGIN
        C_Log("AppBilling.Init EnterState STATE_INIT_BEGIN")
        return
    end
end

function AppBilling.Setup()
    assert(AppBilling.nState == STATE_INIT_END)
    local tJsonResult = AppBilling.CallAppBillingApi("setup")
    if tJsonResult.status == "success" then
        AppBilling.nState = STATE_SETUP_BEGIN
        C_Log("AppBilling.Setup, EnterState STATE_SETUP_BEGIN")
        return
    end

    C_Log("Error When AppBilling Setup:")
end

function AppBilling.Query()
    assert(AppBilling.nState == STATE_SETUP_END)
    local tJsonResult = AppBilling.CallAppBillingApi('query')
    if tJsonResult.status == "success" then
        AppBilling.nState = STATE_QUERY_BEGIN
        C_Log("AppBilling.Query, EnterState STATE_QUERY_BEGIN")
        return
    end

    C_Log("Error When AppBilling Query:")
end

function AppBilling.ConsumeGoods()
    assert(AppBilling.nState == STATE_READY)
    
    local tOneGoods = AppBilling.tGoodsList[1]
    if not tOneGoods then
        C_Log("AppBilling.ConsumeGoods, not tOneGoods")
        return
    end

    if tOneGoods.nLastRequestTime then
        C_Log("AppBilling.ConsumeGoods, Goods in Consuming")
        return
    end
    table.remove(AppBilling.tGoodsList, 1)
    table.insert(AppBilling.tGoodsList, tOneGoods)
    tOneGoods.nLastRequestTime = os.time()

    local tJsonResult = AppBilling.CallAppBillingApi('consume', tOneGoods)
    if tJsonResult.status == "success" then
        C_Log("AppBilling.ConsumeGoods, request success")
        return
    end
end

function AppBilling.ConsumeSpecifiedGoods(strJsonPurchaseData)
    local tOneGoods
    for _, v in ipairs(AppBilling.tGoodsList) do
        if v.json_info == strJsonPurchaseData then
            tOneGoods = v
            break
        end
    end
    if not tOneGoods then
        C_Log("AppBilling.ConsumeSpecifiedGoods, find not tOneGoods:" .. strJsonPurchaseData)
        return
    end

    tOneGoods.bConsuming = true

    local tJsonResult = AppBilling.CallAppBillingApi('consume', tOneGoods)
    if tJsonResult.status == "success" then
        C_Log("AppBilling.ConsumeGoods, request success")
        return
    end
    tOneGoods.bConsuming = nil
end

function AppBilling.GetNextVerifyGoods()
    if #AppBilling.tGoodsList == 0 then
        C_Log("AppBilling.tGoodsList is empty")
        return
    end

    local nCurrentTime = os.time()
    for i, v in ipairs(AppBilling.tGoodsList) do
        if not v.bConsuming then 
            if not v.nLastRequestTime or nCurrentTime - v.nLastRequestTime > 30 then
                table.remove(AppBilling.tGoodsList, i)
                table.insert(AppBilling.tGoodsList, v)
                return v
            end
        end
    end
   
    C_Log("AppBilling.GetNextVerifyGoods(), return nil, all goods in consuming or verifying")
end

function AppBilling.VerifyGoodsPurchase()
     assert(AppBilling.nState == STATE_READY)

     if not KGameServer then
         C_Log("AppBilling.VerifyGoodsPurchase, not KGameServer")
         return
     end
    
    if not KGameServer:IsReady() then
        C_Log("AppBilling.VerifyGoodsPurchase, not KGameServer:IsReady()")
        return
    end

    if KGameServer:HasPackageInSendingQueue("GooglePayVerify") then
        C_Log("AppBilling.VerifyGoodsPurchase, HasPackageInSendingQueue")
        return
    end

    local tOneGoods = AppBilling.GetNextVerifyGoods()
    if not tOneGoods then
        C_Log("AppBilling.VerifyGoodsPurchase, not tOneGoods")
        return
    end
    tOneGoods.nLastRequestTime = os.time()
    C_Log("SendToGS GooglePayVerify json_info:" .. tOneGoods.json_info .. " signature:" .. tOneGoods.signature)
    KGameServer:SendToGS("GooglePayVerify", tOneGoods.json_info, tOneGoods.signature)
end

function AppBilling.Activate()
    C_Log("AppBilling.Activate, Current State:" .. AppBilling.nState)
    if AppBilling.nState == STATE_INVALID then
        AppBilling.Init()
        return
    end
    
    if AppBilling.nState == STATE_INIT_END then
        AppBilling.Setup()
        return
    end

    if AppBilling.nState == STATE_SETUP_END then
        AppBilling.Query()
        return
    end

    if AppBilling.nState == STATE_READY then
        AppBilling.VerifyGoodsPurchase()
        return
    end
end

function AppBilling.CanBuyGoods()
    if AppBilling.nState ~= STATE_READY then
        C_Log("AppBilling.CanBuyGoods Failed State:" .. AppBilling.nState .. " not Ready:" .. STATE_READY)
        showNotice("Google Billing is setting up, please waiting...")
        return false
    end

    if #AppBilling.tGoodsList > 0 then
        C_Log("AppBilling.CanBuyGoods #AppBilling.tGoodsList > 0")
        showNotice("Some purchase is processing, please waiting...")
        return false
    end

    if AppBilling.bBuying then
        C_Log("AppBilling.CanBuyGoods AppBilling.bBuying")
        return false
    end

    return true
end

function AppBilling.BuyGoods(nGoodsID)
    if not AppBilling.CanBuyGoods() then
        C_Log("AppBilling.BuyGoods Failed , not CanBuyGoods, nGoodsID:" .. tostring(nGoodsID))
        return false
    end

    local strSkuName = AppBilling.tGoodsID2SkuName[nGoodsID]
    assert(strSkuName)

--    local strSkuName = "android.test.purchased"

    local strItemType = AppBilling.ITEM_TYPE_INAPP
    local nRequestCode = AppBilling.REQUEST_CODE
    local strOrderID = "ORDER_ID_" .. strSkuName
    local tArgs = 
    {
        sku_name = strSkuName,
        item_type = strItemType,
        request_code = nRequestCode,
        order_id =  strOrderID,
    }

    local tJsonResult = AppBilling.CallAppBillingApi('buy', tArgs)
    if tJsonResult.status ~= "success" then
        return false
    end

    AppBilling.bBuying = true
    C_Log("AppBilling.BuyGoods Request Success, nGoodsID:" .. tostring(nGoodsID))
    return true
end

function AppBilling.on_init_finished(tArgs)
    assert(AppBilling.nState == STATE_INIT_BEGIN)
    C_Log("AppBilling.on_init_finished:" .. tArgs.status)
    if tArgs.status == "success" then
        AppBilling.nState = STATE_INIT_END
        AppBilling.Setup()
        return
    end

    AppBilling.nState = STATE_INVALID
end

function AppBilling.on_uninit_finished(tArgs)
    if tArgs.status ~= "success" then
       return 
    end

    AppBilling.nState = STATE_INVALID
end

function AppBilling.on_setup_finished(tArgs)
    assert(AppBilling.nState == STATE_SETUP_BEGIN)
    if tArgs.status == "success" then
        AppBilling.nState = STATE_SETUP_END
        AppBilling.Query()
        return
    end

    AppBilling.nState = STATE_INIT_END
end

function AppBilling.on_query_finished(tArgs)
    assert(AppBilling.nState == STATE_QUERY_BEGIN)
    if tArgs.status == "success" then
        AppBilling.nState = STATE_QUERY_END
        for _, v in pairs(tArgs.result) do
            table.insert(AppBilling.tGoodsList, v)
        end
        AppBilling.nState = STATE_READY

        AppBilling.VerifyGoodsPurchase()
        return
    end

    AppBilling.nState = STATE_SETUP_END
end

function AppBilling.VerifyPurchaseJsonInfo()

end

function AppBilling.VerifyPurchaseSignature()
end


function AppBilling.on_consume_finished(tArgs)
    if tArgs.status ~= "success" then
        return 
    end
    
    for i, v in pairs(AppBilling.tGoodsList) do
        if v.item_type == tArgs.result.item_type and
            v.json_info == tArgs.result.json_info and
            v.signature == tArgs.result.signature then
            table.remove(AppBilling.tGoodsList, i)
            C_Log("AppBilling, on_consume_finished, Removed cached goods")
            break
        end
    end
end

function AppBilling.on_buy_finished(tArgs)
    AppBilling.bBuying = false
    if tArgs.status ~= "success" then
        return 
    end

    table.insert(AppBilling.tGoodsList, {item_type = tArgs.result.item_type, json_info = tArgs.result.json_info, signature = tArgs.result.signature})

    AppBilling.VerifyGoodsPurchase()
end

function AppBilling.OnServerVerifyRet(strJsonData, nStatus)
    assert(nStatus == 0)
    AppBilling.ConsumeSpecifiedGoods(strJsonData)
    AppBilling.VerifyGoodsPurchase()
end

function AppBilling.SafeCallFromCpp(strJsonData)
    C_Log("AppBilling CallFromCpp:" .. strJsonData)
    local tJsonData = JsonString2LuaValue(strJsonData) 
    local strFuncName = tJsonData.func_name
    local tArgs = tJsonData.func_args
    return AppBilling[strFuncName](tArgs) 
end

function AppBilling_CallFromCpp(strJsonData)
    local bSuccess, vData = pcall(AppBilling.SafeCallFromCpp, strJsonData)
    C_Log("AppBilling_CallFromCpp Result:" .. tostring(bSuccess) .. " RetData:" .. tostring(vData))

    if bSuccess then
        return vData
    end

    local tResult = 
    {
        status = "failed",
        result = 
        {
            description = tostring(vData),
        },
    }

    return LuaValue2JsonString(tResult)
end

local function tryActivate()
    local bSuccess, strErrorMessage = pcall(AppBilling.Activate)
    if strErrorMessage then
        C_Log("AppBilling.Activate, Error:" .. strErrorMessage)
        return
    end

    C_Log("AppBilling.Activate, Success")
end

cc.Director:getInstance():getScheduler():scheduleScriptFunc(tryActivate, 30, false)
tryActivate()

