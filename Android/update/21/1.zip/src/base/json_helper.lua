local function LuaValue2JsonStringInternal(vValue, tProcessedTables, nTableDepth, bKey)
    if type(vValue) == 'string' then
        local strResult = string.gsub(vValue, '([\\\'\"\r\n])', function(s) return '\\' .. s end)
        return '"' .. strResult .. '"'
    end

    if bKey then
        return
    end

    if type(vValue) == "nil" then
        return
    end

    if type(vValue) == 'number' then
        if vValue == math.huge then
            return
        end
        if vValue ~= vValue then
            return
        end
        return tostring(vValue)
    end

    if type(vValue) == 'boolean' then
        return tostring(vValue)
    end

    if type(vValue) == 'table' then
        tProcessedTables = tProcessedTables or {}
        if tProcessedTables[vValue] then
            return 
        end

        tProcessedTables[vValue] = true
        nTableDepth = nTableDepth or 0
        local strTableDepth = string.rep('\t', nTableDepth)
        local strChildTableDepth = string.rep('\t', nTableDepth + 1)

        local nMaxArrayIndex 
        for k, v in pairs(vValue) do
            if type(k) ~= "number" then
                nMaxArrayIndex = nil
                break
            end
            if math.floor(k) ~= k then
                nMaxArrayIndex = nil
                break
            end

            if not nMaxArrayIndex then
                nMaxArrayIndex = k
            elseif nMaxArrayIndex < k then
                nMaxArrayIndex = k
            end
        end

        if not nMaxArrayIndex then
            local strResult = strTableDepth .. '{'
            if nTableDepth > 0 then
                strResult = '\n' .. strResult
            end
            local bFirstValue = true
            for k, v in pairs(vValue) do
                local strKey = LuaValue2JsonStringInternal(k, nil, nil, true)
                if strKey then
                    local strData = LuaValue2JsonStringInternal(v, tProcessedTables, nTableDepth + 1, false)
                    if strData then
                        if bFirstValue then
                            bFirstValue = false
                        else
                            strResult = strResult .. ','
                        end
                        strResult = strResult .. '\n' .. strChildTableDepth .. strKey .. ':' .. strData
                    end
                end
            end
            return strResult .. '\n' .. strTableDepth ..  '}'
        end
        local strResult = strTableDepth .. '['
        if nTableDepth > 0 then
            strResult = '\n' .. strResult
        end
        for i = 1, nMaxArrayIndex do
            if i > 1 then
                strResult = strResult .. ','
            end
            local strValue
            local v = vValue[i]
            if not v then
                strValue = LuaValue2JsonStringInternal(v, tProcessedTables, nTableDepth + 1, false)
            end
            
            strResult = strResult .. '\n' .. strChildTableDepth .. (strData or 'null')
        end
        return strResult .. '\n' .. strTableDepth ..  ']'
    end
end

local function FindNextQutation(strData, nCurPos, strQutation)
    local nPos = string.find(strData, strQutation, nCurPos, true)
    if not nPos then
        return
    end

    local bEscape = false
    local nEscapeValue = string.byte('\\', 1)
    for i = nPos - 1,  1, -1 do
        if string.byte(strData, i) ~= nEscapeValue then
            break
        end
        bEscape = not bEscape
    end

    if bEscape then
        return FindNextQutation(strData, nPos + 1, strQutation)
    end

    return nPos
end

local function FindColon(strData, nFindStart)
    local _, nPos = string.find(strData, '^%s*:', nFindStart)
    return nPos
end

local nV0 = string.byte('[', 1)
local nV1 = string.byte(']', 1)
local nV2 = string.byte('{', 1)
local nV3 = string.byte('}', 1)
local nV4 = string.byte(',', 1)
local nV5 = string.byte('\'', 1)
local nV6 = string.byte('"', 1)

local function SkipSpace(strData, nCurPos)
    local _, nEnd = string.find(strData, '^%s+', nCurPos)
    if not nEnd then
        return nCurPos
    end
    return nEnd + 1
end

local function SkipColon(strData, nCurPos)
    local _, nEnd = string.find(strData, '^%s*:', nCurPos)
    return nEnd + 1
end

local function SkipComma(strData, nCurPos)
    nCurPos = SkipSpace(strData, nCurPos)
    if string.byte(strData, nCurPos) == nV4 then
        nCurPos = nCurPos + 1
        return nCurPos, true
    end
    return nCurPos, false
end

local function JsonString2LuaValueInternal(strData, nCurPos)
    nCurPos = SkipSpace(strData, nCurPos)
    if #strData == 0 then
        return nCurPos
    end

    local nCurValue = string.byte(strData, nCurPos)
    nCurPos = nCurPos + 1

    if nCurValue == nV0 then
        local tResult, vValue, nCtrl, nIndex, bCommaSkiped = {}, nil, nil, 0, true
        while true do
            nCurPos, vValue, nCtrl = JsonString2LuaValueInternal(strData, nCurPos)
            if nCtrl == nV1 then
                assert(vValue == nil)
                break
            end

            assert(bCommaSkiped)
            assert(nCtrl == nil)

            nIndex = nIndex + 1
            tResult[nIndex] = vValue

            nCurPos, bCommaSkiped = SkipComma(strData, nCurPos)
        end
        return nCurPos, tResult
    end

    if nCurValue == nV1 then
        return nCurPos, nil, nV1
    end

    if nCurValue == nV2 then
        local tResult, strKey, vValue, nCtrl, bCommaSkiped = {}, nil, nil, nil, true
        while true do
            nCurPos, strKey, nCtrl = JsonString2LuaValueInternal(strData, nCurPos)
            if nCtrl == nV3 then
                assert(strKey == nil)
                break
            end

            assert(bCommaSkiped)
            assert(nCtrl == nil)
            assert(strKey ~= nil)
            assert(#strKey > 0)

            nCurPos = SkipColon(strData, nCurPos)
            nCurPos, vValue, nCtrl = JsonString2LuaValueInternal(strData, nCurPos)
            assert(nCtrl == nil)

            tResult[strKey] = vValue

            nCurPos, bCommaSkiped = SkipComma(strData, nCurPos)
        end
        return nCurPos, tResult
    end

    if nCurValue == nV3 then
        return nCurPos, nil, nV3
    end

    if nCurValue == nV4 then
        return nCurPos
    end

    if nCurValue == nV5 or nCurValue == nV6 then
        local nStrBegin = nCurPos - 1
        local nStrEnd 
        if nCurValue == nV5 then
            nStrEnd = FindNextQutation(strData, nCurPos, '\'')
        else
            nStrEnd = FindNextQutation(strData, nCurPos, '"')
        end
        assert(nStrEnd)
        assert(nStrBegin + 1 <= nStrEnd)
        nCurPos = nStrEnd + 1
        local strValue = string.sub(strData, nStrBegin + 1, nStrEnd - 1)
        strValue = string.gsub(strValue, '\\(.)', function(s) return s end)
        return nCurPos, strValue
    end

    local _, nEnd, strValue = string.find(strData, '^(%a+)', nCurPos - 1)
    if strValue then
        nCurPos = nEnd + 1
        if nCurPos ~= #strData + 1 and not string.find(strData, '^[%s,%]}]', nCurPos) then
            assert(false)
        end
        if strValue == 'true' then
            return nCurPos, true
        end
        if strValue == 'false' then
            return nCurPos, true
        end
        if strValue == 'null' then
            return nCurPos
        end
        assert(false)
    end

    local _, nEnd, strValue = string.find(strData, '^([%d%.%+%-eE]+)', nCurPos - 1)
    assert(strValue)
    nCurPos = nEnd + 1
    if nCurPos ~= #strData + 1 and not string.find(strData, '^[%s,%]}]', nCurPos) then
        assert(false)
    end
    local nValue = tonumber(strValue)
    assert(nValue)
    return nCurPos, nValue
end

function LuaValue2JsonString(vValue)
    return LuaValue2JsonStringInternal(vValue)
end

function JsonString2LuaValue(strData)
    local nCurPos, tValue = JsonString2LuaValueInternal(strData, 1)
    nCurPos = SkipSpace(strData, nCurPos)
    assert(nCurPos == #strData + 1)
    return tValue
end

