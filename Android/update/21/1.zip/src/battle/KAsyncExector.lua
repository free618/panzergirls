local KAsyncExector = class("KAsyncExector")

function KAsyncExector:ctor(szOwnerName)
	self.nPreUsedID = 0
	self.szOwnerName = szOwnerName
	self.tExecutingList = {}
	self.tWaitingList = {}

end

function KAsyncExector:takeID()
	self.nPreUsedID = self.nPreUsedID + 1
	return self.nPreUsedID
end

function KAsyncExector:tryResumeWaiting()
	local k = 1
	while true do
		local tWaitingInfo = self.tWaitingList[k]
		if not tWaitingInfo then
			break
		end

		local hThread, tTaskIDList = unpack(tWaitingInfo, 1, table.maxn(tWaitingInfo))

		local bAllTaskFinished = true
		local k1 = 1
		while true do
			local nTaskID = tTaskIDList[k1]
			if not nTaskID then
				break
			end
			if self.tExecutingList[nTaskID] then
				bAllTaskFinished = false
				break
			end

			table.remove(tTaskIDList, k1)
		end
		
		if bAllTaskFinished then
			table.remove(self.tWaitingList, k)
			coroutine.resume(hThread)
		else
			k = k + 1
		end

	end
end

function KAsyncExector:exec(fnFunc, ...)
	local tArg = {...}
	local fnWrapper = function()
		fnFunc(unpack(tArg, 1, table.maxn(tArg)))
		local hCurThread = coroutine.running()
		assert(hCurThread ~= nil)

		for i, v in pairs(self.tExecutingList) do
			if v == hCurThread then
				self.tExecutingList[i] = nil
				self:tryResumeWaiting()
				return
			end
		end

		assert(false)
	end

	local hThread = coroutine.create(fnWrapper)
	local nTaskID = self:takeID()

	self.tExecutingList[nTaskID] = hThread
    local _, szError = coroutine.resume(hThread)
    if szError then print("---------> szError:", szError) end
    
    return nTaskID
end

function KAsyncExector:waiting(tTaskIDList)
	local hThread = coroutine.running()
	for _, nTaskID in pairs(tTaskIDList) do
		if self.tExecutingList[nTaskID] then
			table.insert(self.tWaitingList, {hThread, tTaskIDList})
			coroutine.yield()
			return
		end
	end
end

return KAsyncExector
