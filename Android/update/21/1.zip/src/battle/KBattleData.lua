
local KBattleData = class("KBattleData")

local function IsBroken(nCurrentHP, nMaxHP)
    return KUtil.IsBigBroken(nCurrentHP, nMaxHP)
end

function KBattleData:ctor(tSrcTeam, tDstTeam, bBeginAtNightFight, nbattleType)
    local tInitData = 
        {
            tSrcTeam = clone(tSrcTeam),
            tDstTeam =  clone(tDstTeam),
            nRandomSeed = os.time(),
        }

    math.randomseed(tInitData.nRandomSeed)

    self.tInitData              = tInitData

    self.tSrcTeam               = tSrcTeam
    self.tDstTeam               = tDstTeam
    self._bCostResouce          = tSrcTeam[1].bIsRole
    self.nRandomSeed            = tInitData.nRandomSeed
    self.tKillMonsters          = {}
    self.tSkillUsedData         = {}
    self.tDeadMonsters          = {}
    self.bNightBattle           = false
    self.nLandType              = 0
    self.nSrcLostHP             = 0
    self.nDstLostHP             = 0
    self.nbattleType            = nbattleType
    self.tEmergencyRepairCards  = {} 

    self.nSrcTotalHP            = 0
    self.nDstTotalHP            = 0
    self.bBeginAtNightFight     = bBeginAtNightFight
    self.tSkillChangeStateList  = {}
    self.tSkillChangeStateListIndex = {}

    for _, v in ipairs(self.tSrcTeam) do
        self.nSrcTotalHP = self.nSrcTotalHP + v.nCurrentHP
    end

    if self.nSrcTotalHP < 1 then self.nSrcTotalHP = 1 end

    for _, v in ipairs(self.tDstTeam) do
        self.nDstTotalHP = self.nDstTotalHP + v.nCurrentHP
    end
    if self.nDstTotalHP < 1 then self.nDstTotalHP = 1 end

    self.nCurrentStep         = nil
    self.tCanUseSkill         = {}
    for _, szType in pairs(SKILL_TYPE) do
        self.tCanUseSkill[szType] = true
    end
    self.tOnArtilleryActionBeforeFire = {}
    -- self.tBarrageSkill        = {}
    self.nExpMuti             = nil
end

function KBattleData:getConfig()
    return require("src/battle/KBattleConfig")
end

-- 需要消耗资源的战斗类型
local NEED_COST_RESOUCE_BATTLE_TYPE = 
{
    [BATTLE_TYPE.NORMAL] = true,
    [BATTLE_TYPE.GUIDE] = true,
}

function KBattleData:beginFight()
    for _, v in ipairs(self.tSrcTeam) do
        v.tExtraProperty  = nil
        v.tComboSkill     = nil
        v.tLandmine       = nil 
        if self._bCostResouce then
            local tCardSetting = KConfig:getLine("cardInfo", v.nTemplateID)

            v.nCarryOil = v.nCarryOil - math.floor(tCardSetting.nCarryOil * BATTLE_COST_RESOUCE.COST_OIL_PERCENT)
            if v.nCarryOil < 0 then v.nCarryOil = 0 end

            v.nCarryAmmo = v.nCarryAmmo - math.floor(tCardSetting.nCarryAmmo * BATTLE_COST_RESOUCE.COST_AMMO_PERCENT)
            if v.nCarryAmmo < 0 then v.nCarryAmmo = 0 end
        end
    end

    for _, v in ipairs(self.tDstTeam) do
        v.tExtraProperty  = nil
        v.tComboSkill     = nil
        v.tLandmine       = nil 
    end
    if self._bCostResouce and (not self.nbattleType or NEED_COST_RESOUCE_BATTLE_TYPE[self.nbattleType]) then
        require("src/network/KC2SProtocolManager"):StartBattleCostResouce(self.tSrcTeam.teamIndex)
    end
end

function KBattleData:costNightFightResouce()
    if not self._bCostResouce then return end
    for _, v in ipairs(self.tSrcTeam) do
        local tCardSetting = KConfig:getLine("cardInfo", v.nTemplateID)

        v.nCarryOil = v.nCarryOil - math.floor(tCardSetting.nCarryOil * BATTLE_COST_RESOUCE.COST_OIL_PERCENT_NIGHT)
        if v.nCarryOil < 0 then v.nCarryOil = 0 end

        v.nCarryAmmo = v.nCarryAmmo - math.floor(tCardSetting.nCarryAmmo * BATTLE_COST_RESOUCE.COST_AMMO_PERCENT_NIGHT)
        if v.nCarryAmmo < 0 then v.nCarryAmmo = 0 end
    end

    if not self.nbattleType or  NEED_COST_RESOUCE_BATTLE_TYPE[self.nbattleType] then
        require("src/network/KC2SProtocolManager"):StartNightBattleCostResouce(self.tSrcTeam.teamIndex)
    end
end

function KBattleData:getCard(bLeftTeam, nIndex)
    if bLeftTeam then
        return self.tSrcTeam[nIndex]
    end

    return self.tDstTeam[nIndex]
end

function KBattleData:costHP(tCard, nHP, tSrcCard)
    assert(nHP >= 0)

    local nOldHP = tCard.nCurrentHP
    tCard.nCurrentHP = tCard.nCurrentHP - nHP

    if tCard.bBrokenProtect then
        if tCard.nCurrentHP < 1 then
            tCard.nCurrentHP = 1
        end
    else
        if tCard.nCurrentHP < 0 then
            tCard.nCurrentHP = 0
        end
    end

    if tCard.bLeftSide and tCard.bIsRole and nOldHP > tCard.nCurrentHP and tCard.nCurrentHP > 0 and tCard.nCurrentHP / tCard.nMaxHP <= BROKEN_LIMIT.MIDDLE and self.nbattleType == BATTLE_TYPE.NORMAL then
        require("src/network/KC2SProtocolManager"):syncBattleCardLostHP(tCard.nID, tCard.nCurrentHP)
    end

    if nOldHP > 0 and tCard.nCurrentHP == 0 then
        -- if not tCard.bLeftSide and not tCard.bIsRole then
            -- require("src/network/KC2SProtocolManager"):dispatchEvent("KILL_MONSTER", tCard.nTemplateID)
        if tCard.bLeftSide and tCard.bIsRole then
            if not self.nbattleType or self.nbattleType == BATTLE_TYPE.NORMAL then
                if tCard.nMountItemTemplateID ~= 0 then 
                    table.insert(self.tEmergencyRepairCards, tCard)
                    tCard.nMountItemTemplateID = 0
                    tCard.bUseMountItem        = true
                    require("src/network/KC2SProtocolManager"):useCardMountItem(tCard.nID)
                else
                    require("src/network/KC2SProtocolManager"):BattleCardDead(self.tSrcTeam.teamIndex, tCard.nID)
                end
            end
        end

        if not tCard.bLeftSide then
            self.tDeadMonsters[tCard.nTemplateID] = (self.tDeadMonsters[tCard.nTemplateID] or 0) + 1
            if tSrcCard and tSrcCard.bIsRole and tCard then
                local srcTankType = tSrcCard.nNamedType
                local desTankType = tCard.nNamedType
                if srcTankType == desTankType then
                    local cardID   = tSrcCard.nID
                    local tankType = tCard.nNamedType
                    self.tKillMonsters[cardID] = self.tKillMonsters[cardID] or 0
                    self.tKillMonsters[cardID] = self.tKillMonsters[cardID] + 1
                end
            end
        end
    end

    if tCard.bLeftSide then
        self.nSrcLostHP = self.nSrcLostHP + nOldHP - tCard.nCurrentHP  
    else
        self.nDstLostHP = self.nDstLostHP + nOldHP - tCard.nCurrentHP
    end

    if tSrcCard then
        tSrcCard.nTotalDamage = tSrcCard.nTotalDamage + nOldHP - tCard.nCurrentHP
    end

    return nOldHP, tCard.nCurrentHP
end

function KBattleData:addHp(tCard, nHP)
    assert(nHP >= 0)

    if tCard.nCurrentHP == 0 then
        return 0, 0
    end

    local nOldHP = tCard.nCurrentHP
    tCard.nCurrentHP = tCard.nCurrentHP + nHP
    if tCard.nCurrentHP > tCard.nMaxHP then
        tCard.nCurrentHP = tCard.nMaxHP
    end

    return nOldHP, tCard.nCurrentHP
end

function KBattleData:isLeftTeamLeaderBroken()
    local tCard = self:getCard(true, 1)
    return IsBroken(tCard.nCurrentHP, tCard.nMaxHP)
end

function KBattleData:isTeamHasLivingCard(bLeftTeam)
    local tTeam = self.tSrcTeam
    if not bLeftTeam then
        tTeam = self.tDstTeam
    end

    for _, v in ipairs(tTeam) do
        if v.nCurrentHP > 0 then
            return true
        end
    end

    return false
end

function KBattleData:hasLivingCard(nCardType)
    for _, v in ipairs(self.tSrcTeam) do
        if v.nCurrentHP > 0 and HArray.FindFirstByValue(v.tFuncTypeList, nCardType) then
            return true
        end
    end

    for _, v in ipairs(self.tDstTeam) do
        if v.nCurrentHP > 0 and HArray.FindFirstByValue(v.tFuncTypeList, nCardType) then
            return true
        end
    end

    return false
end

function KBattleData:getFirstLivingAndNotBigBrokenCardIndexOf(bLeftTeam, nCardType)
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tTeam = self.tSrcTeam
    if not bLeftTeam then
        tTeam = self.tDstTeam
    end

    for _, v in ipairs(tTeam) do
        local nSrcCardState = KBattleConfig.getBrokenState(v)
        if HArray.FindFirstByValue(v.tFuncTypeList, nCardType) and nSrcCardState < CARD_BROKEN_STATE.BIG then  
            return v
        end
    end
end

function KBattleData:getAllLivingAndNotBigBrokenCard(nCardType)
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tResult = {}
    for _, v in ipairs(self.tSrcTeam) do 
        local nSrcCardState = KBattleConfig.getBrokenState(v)
        if HArray.FindFirstByValue(v.tFuncTypeList, nCardType) and nSrcCardState < CARD_BROKEN_STATE.BIG then 
            table.insert(tResult, v)
        end
    end

    for _, v in ipairs(self.tDstTeam) do
        local nDstCardState = KBattleConfig.getBrokenState(v)
        if HArray.FindFirstByValue(v.tFuncTypeList, nCardType) and nDstCardState < CARD_BROKEN_STATE.BIG then 
           table.insert(tResult, v) 
        end
    end

    return tResult
end

function KBattleData:getLivingCard(tTeam, nCardType)
    local tResult = {}
    for _, v in ipairs(tTeam) do
        if  v.nCurrentHP > 0 and HArray.FindFirstByValue(v.tFuncTypeList, nCardType) then 
           table.insert(tResult, v) 
        end
    end
    return tResult
end

local function randomOneCardWithWeight(tCardList)
    local nDefaultWeight    = 100
    local nTotalWeight      = 0
    local tList             = {}
    for nIndex, oneCard in ipairs(tCardList) do
        local nExtraWeight  = 0
        local nExtraProbability = oneCard.nExtraTargetProbability
        if nExtraProbability then
            nExtraWeight = nDefaultWeight * nExtraProbability
        end
        local nCardWeight   = nDefaultWeight + nExtraWeight
        nTotalWeight        = nTotalWeight + nCardWeight
        tList[nIndex]       = nTotalWeight
    end

    local nRandomValue = math.random(nTotalWeight)
    for nIndex, oneWeight in ipairs(tList) do
        if nRandomValue <= oneWeight then
            return tCardList[nIndex]
        end
    end
end

function KBattleData:getRandomCard(bLeftSide)
    local tTargetList = {}

    local tTeam = self.tSrcTeam
    if not bLeftSide then
        tTeam = self.tDstTeam
    end

    for _, v in ipairs(tTeam) do
        if v.nCurrentHP > 0 then
            table.insert(tTargetList, v)
        end
    end

    if #tTargetList == 0 then
        return
    end

    -- local nRadomIndex = math.random(#tTargetList)
    -- return tTargetList[nRadomIndex]
    local tRandomCard = randomOneCardWithWeight(tTargetList)
    return tRandomCard
end

function KBattleData:getArtilleryActionActiveTank()
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tActiveTank = {}
    local nHuoPaoTankType   = CARD_TYPE.SELF_PROPELLED_GUN

    for _, v in ipairs(self.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        local nSrcCardState = KBattleConfig.getBrokenState(v)
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType ~= nHuoPaoTankType and nSrcCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tActiveTank, v)
                break
            else
                if nSrcCardState < CARD_BROKEN_STATE.MIDDLE then
                    table.insert(tActiveTank, v)
                    break
                end
            end
        end
    end

    for _, v in ipairs(self.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        local nDstCardState = KBattleConfig.getBrokenState(v)
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType ~= nHuoPaoTankType and nDstCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tActiveTank, v)
                break
            else
                if nDstCardState < CARD_BROKEN_STATE.MIDDLE then
                    table.insert(tActiveTank, v)
                    break
                end
            end
        end
    end

    local function sortFunc(v1, v2)
        if v1.nRange == v2.nRange then
            return false
        else
            return v1.nRange > v2.nRange
        end
    end
    table.sort(tActiveTank, sortFunc)

    return tActiveTank
end

function KBattleData:getArtilleryAction2ActiveTank()
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tActiveTank = {}
    local nHuoPaoTankType   = CARD_TYPE.SELF_PROPELLED_GUN

    local tSrcActiveTank = {}
    for _, v in ipairs(self.tSrcTeam) do
        local nSrcCardState = KBattleConfig.getBrokenState(v)
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType ~= nHuoPaoTankType and nSrcCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tSrcActiveTank, v)
                break
            else
                if nSrcCardState < CARD_BROKEN_STATE.MIDDLE then
                    table.insert(tSrcActiveTank, v)
                    break
                end
            end
        end
    end

    local tDstActiveTank = {}
    for _, v in ipairs(self.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        local nDstCardState = KBattleConfig.getBrokenState(v)
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType ~= nHuoPaoTankType and nDstCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tDstActiveTank, v)
                break
            else
                if nDstCardState < CARD_BROKEN_STATE.MIDDLE then
                    table.insert(tDstActiveTank, v)
                    break
                end
            end
        end
    end
    
    local i = 0
    while true do
        i = i + 1
        local tSrcOne = tSrcActiveTank[i]
        if tSrcOne then
            table.insert(tActiveTank, tSrcOne)
        end
        
        local tDstOne = tDstActiveTank[i]
        if tDstOne then
            table.insert(tActiveTank, tDstOne)
        end
        
        if not tSrcOne and not tDstOne then
            break
        end
    end

    return tActiveTank
end

function KBattleData:getDogFightActiveTank()
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tActiveTank = {}
    local lightTankType  = CARD_TYPE.LIGHT_TANK
    local mediumTankType = CARD_TYPE.MEDIUM_TANK

    for _, v in ipairs(self.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        local nSrcCardState = KBattleConfig.getBrokenState(v)
        for _, nTankType in ipairs(tTankTypeList) do
            if (nTankType == lightTankType or nTankType == mediumTankType) and nSrcCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tActiveTank, v)
                break
            end
        end
    end

    for _, v in ipairs(self.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        local nDstCardState = KBattleConfig.getBrokenState(v)
        for _, nTankType in ipairs(tTankTypeList) do
            if (nTankType == lightTankType or nTankType == mediumTankType) and nDstCardState < CARD_BROKEN_STATE.BIG then
                table.insert(tActiveTank, v)
                break
            end
        end
    end

    local function sortFunc(v1, v2)
        if v1.nRange == v2.nRange then
            return false
        else
            return v1.nSpeed > v2.nSpeed
        end
    end
    table.sort(tActiveTank, sortFunc)

    return tActiveTank
end

function KBattleData:getNightFightActiveTank()
    local MAX_CARD_PER_COUNT = 6

    local tActiveTank = {}
    for i = 1, MAX_CARD_PER_COUNT do
        local tLeftTeamInfo     = self.tSrcTeam[i]
        local tRightTeamInfo    = self.tDstTeam[i]

        if tLeftTeamInfo and not IsBroken(tLeftTeamInfo.nCurrentHP, tLeftTeamInfo.nMaxHP) then table.insert(tActiveTank, tLeftTeamInfo) end
        if tRightTeamInfo and not IsBroken(tRightTeamInfo.nCurrentHP, tRightTeamInfo.nMaxHP)  then table.insert(tActiveTank, tRightTeamInfo) end
    end

    return tActiveTank
end

function KBattleData:setIfChooseNightFight(enterNightBattle)
    self.bNightBattle = enterNightBattle
end

function KBattleData:setSkillAble(useSkill)
    self.tSrcTeam.canUseSkill = useSkill 
end

function KBattleData:getSkillAble()
    return self.tSrcTeam.canUseSkill
end

function KBattleData:canUseSkill(tUseSkill, bIsLeftTeam)
    local bCanUse = (tUseSkill.nUsedTimes < 1)
    if not bCanUse then return false end
    
    if bIsLeftTeam then
        local bCanUse = (tUseSkill.nLeftTimes > 0)
        if not bCanUse then return false end
    end
    
    return true
end

function KBattleData:useSkill(tUseSkill, bIsLeftTeam)
    if bIsLeftTeam then
        local nLeftTimes = tUseSkill.nLeftTimes
        assert(nLeftTimes > 0, "skill left times less than 1")
        if tUseSkill.nEquipID then
            require("src/network/KC2SProtocolManager"):UseSkill(tUseSkill.nEquipID, 1)
        end

        tUseSkill.nLeftTimes = tUseSkill.nLeftTimes - 1
    end

    local nHasUsedTimes = tUseSkill.nUsedTimes
    assert(nHasUsedTimes <= 1, "skill has used more than 1 time")
    tUseSkill.nUsedTimes = tUseSkill.nUsedTimes + 1
end

function KBattleData:ifEnterNightFight()
    return self.bNightBattle
end

function KBattleData:getLeftTeamLineup()
    return self.tSrcTeam.lineup.nID
end

function KBattleData:getRightTeamLineup()
    return self.tDstTeam.lineup.nID
end

function KBattleData:getLeftTeamSkillList()
    return self.tSrcTeam.tSkillList
end

function KBattleData:getRightTeamSkillList()
    return self.tDstTeam.tSkillList
end

function KBattleData:getLeftTeamData()
    return self.tSrcTeam
end

function KBattleData:getRightTeamData()
    return self.tDstTeam
end

function KBattleData:getCardData(index, isLeft)
    if isLeft then
        return self.tSrcTeam[index]
    else
        return self.tDstTeam[index]
    end
end

function KBattleData:getLineup(tCard)
    if tCard.bLeftSide then
        return self.tSrcTeam.lineup
    end

    return self.tDstTeam.lineup
end

function KBattleData:randomLand()
    local KBattleConfig = self:getConfig()
    local nLandType = KBattleConfig.getRandomLand()
    self.nLandType = nLandType

    return nLandType
end

-- 获得油料百分比
function KBattleData:getOilPercent(tCard)
    if not tCard.bLeftSide then
        return 1
    end

    local nCurrentOil   = tCard.nCarryOil
    local nMaxOil       = tCard.nMaxOil

    print("*****nCurrentOil", nCurrentOil)
    print("*****nMaxOil", nMaxOil)
    if nMaxOil < 1 then return 1 end

    local nPercent = nCurrentOil / nMaxOil
    if nPercent < 0 then nPercent = 0 end
    if nPercent > 1 then nPercent = 1 end

    print("******nPercent", nPercent)
    return nPercent
end

-- 获得弹药百分比
function KBattleData:getAmmoPercent(tCard)
    if not tCard.bLeftSide then
        return 1
    end

    local nCurrentAmmo  = tCard.nCarryAmmo
    local nMaxAmmo      = tCard.nMaxOil

    print("******nCurrentAmmo", nCurrentAmmo)
    print("******nMaxAmmo", nMaxAmmo)
    if nMaxAmmo < 1 then return 1 end

    local nPercent = nCurrentAmmo / nMaxAmmo
    if nPercent < 0 then nPercent = 0 end
    if nPercent > 1 then nPercent = 1 end

    print("********nPercent", nPercent)
    return nPercent
end


-- 获得等级
function KBattleData:getLevel(tCard)
    return tCard.nLevel
end

--获得命中率
function KBattleData:getHitRate(tCard)
    return tCard.nHitRate
end

-- 回避受油料剩余百分比的影响系数
local OIL_DODGE_COE = 
{
	{0.6, 		1.0}, -- 百分之60以上 系数为1
	{0.2, 		0.9},
	{0.01, 		0.8},
	{0, 		0.3},
}

-- 获得回避
function KBattleData:getDodge(tCard, bIsExtra)
    local nPercent = self:getOilPercent(tCard)
    local nCoe = 1.0

    for _, v in ipairs(OIL_DODGE_COE) do
        if nPercent >= v[1] then
            nCoe = v[2]
            break
        end
    end

    local nDodge = tCard.nDodge
    if bIsExtra and tCard.tExtraProperty then
        for _, tProperty in ipairs(tCard.tExtraProperty) do
            if tProperty.step == self.nCurrentStep and tProperty.dodge then
                nDodge = nDodge + tProperty.dodge
            end
        end
    end

    if tCard.bLeftSide then
        cclog("卡牌:%d 回避值：%d %f, 最终值:%d", tCard.nIndex, nDodge, nCoe, nDodge * nCoe)
    end
    return nDodge * nCoe
end

-- 穿透收到弹药剩余百分比的影响系数
local AMMO_PENETRATE_COE = 
{
	{0.6, 		1.0}, -- 百分之60以上 系数为1
	{0.2, 		0.9},
	{0.01, 		0.7},
	{0, 		0.3},
}

-- 获得穿透
function KBattleData:getPenetrate(tCard)
    local nPercent = self:getAmmoPercent(tCard)
    local nCoe = 1.0

    for _, v in ipairs(AMMO_PENETRATE_COE) do
        if nPercent >= v[1] then
            nCoe = v[2]
            break
        end
    end
	
	if tCard.bLeftSide then
		cclog("卡牌:%d 穿透值：%d %f, 最终值:%d", tCard.nIndex, tCard.nPenetrate, nCoe, tCard.nPenetrate * nCoe)
	end
	
    return tCard.nPenetrate * nCoe
end

-- 火力收到弹药剩余百分比的影响系数
local AMMO_ATTACK_COE = 
{
	{0.6, 		1.0}, -- 百分之60以上 系数为1
	{0.2, 		0.9},
	{0.01, 		0.8},
	{0, 		0.3},
}
-- 获得火力值
function KBattleData:getAttack(tCard)
    local nPercent = self:getAmmoPercent(tCard)
    local nCoe = 1.0

    for _, v in ipairs(AMMO_ATTACK_COE) do
        if nPercent >= v[1] then
            nCoe = v[2]
            break
        end
    end

	if tCard.bLeftSide then
		cclog("卡牌:%d 火力值：%d %f, 最终值:%d", tCard.nIndex, tCard.nAttack, nCoe, tCard.nAttack * nCoe)
	end
    return tCard.nAttack * nCoe
end

-- 获得前装甲
function KBattleData:getFrontArmour(tCard)
    return tCard.nFrontArmour
end

-- 获得后装甲
function KBattleData:getRearArmour(tCard)
    return tCard.nRearArmour
end

-- 获得速度
function KBattleData:getSpeed(tCard)
    return tCard.nSpeed
end

-- 获得重击率
function KBattleData:getThump(tCard)
    return tCard.nThumpRate
end

-- 获得夜战值
function KBattleData:getNightBattle(tCard)
    return tCard.nNightBattle
end

-- 获得必杀几率
function KBattleData:getCrit(tCard)
    return tCard.nCrit
end

-- 获得装备火力
function KBattleData:getEquipAttack(tCard, nEquipPos)
    if not nEquipPos then return end
    local nEquipID      = tCard["nEquip" .. nEquipPos]
    local tEquipSetting = KConfig:getLine("equipInfo", nEquipID)
    return tEquipSetting.nAttack
end

-- 获得装备的弹药数量
function KBattleData:getEquipAmmoCount(tCard, nEquipPos)
    if tCard.bLeftSide and tCard.bIsRole then
        local tCardSetting = KConfig:getLine("cardInfo", tCard.nTemplateID)
        return tCardSetting["nWeaponAmmo" .. nEquipPos]
    end

    local tMonsterSetting = KConfig:getLine("monster", tCard.nTemplateID)
    return tMonsterSetting["nWeaponAmmo" .. nEquipPos]
end

-- 获得侦查命中补正
function KBattleData:getScoutHitRate(tSrcCard, tDstCard)
    if tDstCard.bScouted then
        return 0.1
    end

    if tSrcCard.nNamedType == CARD_TYPE.SELF_PROPELLED_GUN then
        return -0.25
    end

    return -0.15
end

-- 获得阵型攻击对方后甲的概率增加值
function KBattleData:getLineupAttackRearArmourRate(tSrcCard, tDstCard)
    local srcAttackRearArmourRate = 0
    if tSrcCard then
        local srcLineupInfo       = self:getLineup(tSrcCard)
        local srcCardType         = tSrcCard.nNamedType
        srcAttackRearArmourRate   = srcLineupInfo.tSrcAttackRearArmourRate[srcCardType]
    end

    local dstAttackRearArmourRate = 0
    if tDstCard then
        local dstLineupInfo       = self:getLineup(tDstCard)
        local dstCardType         = tDstCard.nNamedType
        dstAttackRearArmourRate   = dstLineupInfo.tDstAttackRearArmourRate[dstCardType]
    end

    return srcAttackRearArmourRate + dstAttackRearArmourRate
end

-- 获得阵型侦查加成
function KBattleData:getLineupScout(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tScout[cardType]
end

-- 获得阵型速度加成
function KBattleData:getLineupSpeed(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tSpeed[cardType]
end

-- 获得阵型闪避加成
function KBattleData:getLineupDodge(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tDodge[cardType]
end

-- 获得阵型隐蔽加成
function KBattleData:getLineupHide(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tHide[cardType]
end

-- 获得阵形命中加成
function KBattleData:getLineupHitRate(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tHitRate[cardType]

end

-- 获得阵形穿透加成
function KBattleData:getLineupPenetrate(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tPenetrate[cardType]
end

-- 获得阵形前护甲加成
function KBattleData:getLineupFrontArmour(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tFrontArmour[cardType]
end

-- 获得阵形后护甲加成
function KBattleData:getLineupRearArmour(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tRearArmour[cardType]
end

-- 获得阵形攻击加成
function KBattleData:getLineupAttack(tCard)
    local lineupInfo = self:getLineup(tCard)
    local cardType   = tCard.nNamedType
    return lineupInfo.tAttack[cardType]
end

-- 获得耐久和士气火力影响系数
function KBattleData:getStateAttackCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nAttack * tMoralStateCoe.nAttack
end

-- 获得耐久和士气穿透影响系数
function KBattleData:getStatePenetrateCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nPenetrate * tMoralStateCoe.nPenetrate
end

-- 获得耐久和士气速度影响系数
function KBattleData:getStateSpeedCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nSpeed * tMoralStateCoe.nSpeed
end

-- 获得耐久和士气护甲影响系数
function KBattleData:getStateArmorCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nArmor * tMoralStateCoe.nArmor
end

-- 获得耐久和士气侦查影响系数
function KBattleData:getStateScoutCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nScout * tMoralStateCoe.nScout
end

-- 获得耐久和士气回避影响系数
function KBattleData:getStateDodgeCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nDodge * tMoralStateCoe.nDodge
end

-- 获得耐久和士气隐蔽影响系数
function KBattleData:getStateHideCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nHide * tMoralStateCoe.nHide
end

-- 获得耐久和士气命中影响系数
function KBattleData:getStateHitRateCoe(tCard)
    local KBattleConfig = self:getConfig()
    local tBrokenStateCoe = KBattleConfig.getCardBrokenStateCoe(tCard)
    local tMoralStateCoe = KBattleConfig.getCardMoralStateCoe(tCard)

    return tBrokenStateCoe.nHitRate * tMoralStateCoe.nHitRate
end


-- 获得地形命中加成
function KBattleData:getLandHitRate(tCard)
    local nLandType = self.nLandType
    local KBattleConfig = self:getConfig()
    local tLandCoe = KBattleConfig.getLandCoe(nLandType, tCard.bLeftSide)
    if not tLandCoe then return end
    return tLandCoe.nHitRate
end

-- 获得地形火力加成
function KBattleData:getLandAttack(tCard)
    local nLandType = self.nLandType
    local KBattleConfig = self:getConfig()
    local tLandCoe = KBattleConfig.getLandCoe(nLandType, tCard.bLeftSide)
    if not tLandCoe then return end
    return tLandCoe.nAttack
end

-- 获得地形穿甲加成
function KBattleData:getLandPenetrate(tCard)
    local nLandType = self.nLandType
    local KBattleConfig = self:getConfig()
    local tLandCoe = KBattleConfig.getLandCoe(nLandType, tCard.bLeftSide)
    if not tLandCoe then return end
    return tLandCoe.nPenetrate
end

-- 获得最大侦查值
function KBattleData:getMaxScout(tTeam)
    local nMaxScout                     
    for _, tCard in ipairs(tTeam) do
        local nScout = tCard.nScout
        if not nMaxScout or nScout > nMaxScout then
            nMaxScout = nScout
        end
    end
    assert(nMaxScout)
    return nMaxScout
end

--火炮能否攻击(火炮阶段)
function KBattleData:canGunAttack(tCard)
    local i = 0
    while true do
        i = i + 1
        local equipID = tCard["nEquip" .. i]
        if not equipID then break end

        if equipID > 0 then
            local equipSetting = KConfig:getLine("equipInfo", equipID)
            if equipSetting.nArtilleryStrike_AddAttackCount > 0 then
                return true
            end
        end
    end

    return false
end

function KBattleData:getPierceEffectRate(tCard)
    local nPierceEffectRate = 0
    if tCard.tExtraProperty then
        for _, tProperty in ipairs(tCard.tExtraProperty) do
            if tProperty.step == self.nCurrentStep 
                and tProperty.pierceEffectRate 
                and tProperty.pierceEffectRate > nPierceEffectRate then
                    nPierceEffectRate = tProperty.pierceEffectRate
            end
        end
    end
    return nPierceEffectRate
end

-- 装备组合必杀倍率
local EQUIP_GROUP2CRIT_MUTI =
{
    {1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP, EQUIP_DETAIL_TYPE.MG}},
    {1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.HE, EQUIP_DETAIL_TYPE.MG}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER, EQUIP_DETAIL_TYPE.MG}},
    {1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP, EQUIP_DETAIL_TYPE.HE}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER, EQUIP_DETAIL_TYPE.AP}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.MG}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.HE}},
    {2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER}},
}

local function isTableValuesContain(t1, t2)
    if #t1 < #t2 then
        return false
    end

    for _, v in ipairs(t2) do
        if not HArray.FindFirstByValue(t1, v) then
            return false
        end
    end

    return true
end

function KBattleData:getComboMuti(tSrcCard)
    local tEquipDetailList = {}

    local i = 0
    while true do
        i = i + 1
        local nEquipID = tSrcCard["nEquip" .. i]
        if not nEquipID then break end
        if nEquipID > 0 then
            local tEquipSetting = KConfig:getLine("equipInfo", nEquipID)
            local nEquipDetailType = EQUIP_DETAIL_TYPE[tEquipSetting.szDetailType]
            table.insert(tEquipDetailList, nEquipDetailType)
        end
    end

    if #tEquipDetailList == 0 then
        return
    end

    for _, v in ipairs(EQUIP_GROUP2CRIT_MUTI) do
        if isTableValuesContain(tEquipDetailList, v[2]) then
            return v[1]
        end
    end
end

function KBattleData:addExtraProperty(tCard, nStep, szProperty, nProperty)
    if not tCard.tExtraProperty then 
        tCard.tExtraProperty = {}
    end
    table.insert(tCard.tExtraProperty, {step = nStep, [szProperty] = nProperty})
end

function KBattleData:deleteCardExtraProperty(tCard, nCurrentStep)
    assert(nCurrentStep)
    if tCard.tExtraProperty then
        local nIndex = 1
        while true do
            local tProperty = tCard.tExtraProperty[nIndex]
            if not tProperty then break end
            if tProperty.step <= nCurrentStep then
                print("删除额外属性：")
                for i, v in pairs(tCard.tExtraProperty[nIndex]) do
                    print(i, v)
                end
                table.remove(tCard.tExtraProperty, nIndex)
            else
                nIndex = nIndex + 1
            end
        end
    end
end

function KBattleData:deleteExtraProperty(nCurrentStep)
    for _, tCard in ipairs(self.tSrcTeam) do
        self:deleteCardExtraProperty(tCard, nCurrentStep)
    end

    for _, tCard in ipairs(self.tDstTeam) do
        self:deleteCardExtraProperty(tCard, nCurrentStep)
    end
end

function KBattleData:setSkillUseState(szType, bCanUse)
    self.tCanUseSkill[szType] = bCanUse
end

function KBattleData:getSkillUseState(szType)
    return self.tCanUseSkill[szType]
end

function KBattleData:addOnArtilleryActionBeforeFire(fun)
    table.insert(self.tOnArtilleryActionBeforeFire, fun)
end

function KBattleData:getSkillUsedData()
    local tSkillUsedData = {}
    local tSkillList = self:getLeftTeamSkillList()
    for _, oneSkill in ipairs(tSkillList) do
        if oneSkill.nUsedTimes > 0 then
            local tUsedSkill = {
                -- ["nEquipID"]   = oneSkill.nEquipID,
                ["nEquipTemplateID"]  = oneSkill.nEquipTemplateID,  
                ["nUsedTimes"] = oneSkill.nUsedTimes,
            }
            table.insert(tSkillUsedData, tUsedSkill)
        end
    end
    return tSkillUsedData
end

function KBattleData:getStepName()
    return table.getkey(BATTLE_STEP_TYPE, self.nCurrentStep)
end

function KBattleData:getCardTypeName(tCard)
    return table.getkey(CARD_TYPE, tCard.nNamedType)
end

function KBattleData:getHitCoe(tCard)
    local szCurrentStep = self:getStepName()
    local szCardType = self:getCardTypeName(tCard)
    local tConfig = KConfig:getLine("coefficient", szCurrentStep .. "_HIT")
    if not tConfig then return end
    return tConfig["n" .. szCardType]
end

function KBattleData:getPierceCoe(tCard)
    local szCurrentStep = self:getStepName()
    local szCardType = self:getCardTypeName(tCard)
    local tConfig = KConfig:getLine("coefficient", szCurrentStep .. "_PIERCE")
    if not tConfig then return end
    return tConfig["n" .. szCardType]
end

function KBattleData:getThumpCoe(tCard)
    local szCurrentStep = self:getStepName()
    local szCardType = self:getCardTypeName(tCard)
    local tConfig = KConfig:getLine("coefficient", szCurrentStep .. "_THUMP")
    if not tConfig then return end
    return tConfig["n" .. szCardType]
end

function KBattleData:getDamageCoe(tCard)
    local szCurrentStep = self:getStepName()
    local szCardType = self:getCardTypeName(tCard)
    local tConfig = KConfig:getLine("coefficient", szCurrentStep .. "_DAMAGE")
    if not tConfig then return end
    return tConfig["n" .. szCardType]
end

function KBattleData:getTankTypeScoutCoe(tSrcCard, tDstCard)
    local szCurrentStep = self:getStepName()
    local szSrcType = self:getCardTypeName(tSrcCard)
    local szDstType = self:getCardTypeName(tDstCard)
    local tConfig = KConfig:getLine("scoutcoefficient", szCurrentStep .. "_" .. szDstType)
    print("getTankTypeScoutCoe", self.nCurrentStep, szCurrentStep .. "_" .. szDstType, "n" .. szSrcType .. "_SCOUT", tConfig)
    if not tConfig then return end
    return tConfig["n" .. szSrcType .. "_SCOUT"]
end

function KBattleData:getTankTypeDamageCoe(tSrcCard, tDstCard)
    local szCurrentStep = self:getStepName()
    local szSrcType = self:getCardTypeName(tSrcCard)
    local szDstType = self:getCardTypeName(tDstCard)
    local tConfig = KConfig:getLine("scoutcoefficient", szCurrentStep .. "_" .. szDstType)
    if not tConfig then return end
    return tConfig["n" .. szSrcType .. "_DAMAGE"]
end

function KBattleData:getBrokenState(tCard)
    local nCurrentHP    = tCard.nCurrentHP
    local nMaxHP        = tCard.nMaxHP
    
    if nCurrentHP <= 0 then
        return CARD_BROKEN_STATE.DEAD
    end
    
    if nCurrentHP / nMaxHP <= BROKEN_LIMIT.BIG then
        return CARD_BROKEN_STATE.BIG
    end
    
    if nCurrentHP / nMaxHP <= BROKEN_LIMIT.MIDDLE then
        return CARD_BROKEN_STATE.MIDDLE
    end
    
    if nCurrentHP / nMaxHP <= BROKEN_LIMIT.LITTLE then
        return CARD_BROKEN_STATE.LITTLE
    end
    
    return CARD_BROKEN_STATE.NORMAL
end

 local BROKEN_COMBO_COE = 
        {
            [CARD_BROKEN_STATE.LITTLE] = 10,
            [CARD_BROKEN_STATE.MIDDLE] = 20,
        }

function KBattleData:getBrokenComboCoe(tCard)
    return BROKEN_COMBO_COE[self:getBrokenState(tCard)] or 0
end

local TEAM_LEADER_COE = 20 -- 队长必杀补正
local TEAM_MEMBER_COE = 10 -- 队员必杀补正
function KBattleData:getTeamPositionComboCoe(tCard)
    if tCard.nIndex == 1 then
        return TEAM_LEADER_COE
    end

    return TEAM_MEMBER_COE
end

local function getAbilityExtraProperty(tCard, szProperty)
    local nProperty = 0
    local tExtraPropertyList = tCard.tExtraPropertyByPercent
    if not tExtraPropertyList then 
        return nProperty
    end
    for _, oneProperty in pairs(tExtraPropertyList) do
        if oneProperty.szProperty == szProperty then
            nProperty = nProperty + oneProperty.nPercent
        end
    end

    return nProperty
end

function KBattleData:getAbilityDodge(tCard)
    return getAbilityExtraProperty(tCard, "nDodge")
end

function KBattleData:getAbilityHitRate(tCard)
    return getAbilityExtraProperty(tCard, "nHitRate")
end

return KBattleData

