local KStepAmbush = class("KStepAmbush", require("battle/KBattleStepBase").new)

function KStepAmbush:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.AMBUSH
    self.tLogic = require("src/battle/KStepAmbushLogic").new(tBattleData)
end

function KStepAmbush:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "Ambush")
end

function KStepAmbush:playSrcBeginAnimation()
    local tCard = self:getBattleData():getFirstLivingAndNotBigBrokenCardIndexOf(true, CARD_TYPE.TANK_DESTORYER)
    if not tCard then
        return
    end

    self:print("playSrcBeginAnimation", tCard.bLeftSide, tCard.nIndex)
    self:playAnimation("playCardRoleAttackAnimation", tCard)
end

function KStepAmbush:showDistanceRuler(szStep, nMoveDistance)
    print("[" .. self:getName() .. "] showDistanceRuler", szStep, nMoveDistance)
    self:playAnimation("playDistanceRuleAnimation", szStep, nMoveDistance)
end

function KStepAmbush:moveUnit()
    print("[" .. self:getName() .. "] moveUnit")
    local tBattleData    = self:getBattleData()
    local tAsyncExecList = {}

    local nLightTankType    = 1
    local nMiddleTankType   = 2
    local nHeavyTankType    = 3

    for k, v in ipairs(tBattleData.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
            
            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end        
        end
    end

    for k, v in ipairs(tBattleData.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end 
        end
    end

    local nID = self:asyncExec(self.showDistanceRuler, self, "Ambush", 800)
    table.insert(tAsyncExecList, nID)

    self:waitAsync(tAsyncExecList)
end

function KStepAmbush:playDstBeginAnimation()
    local tCard = self:getBattleData():getFirstLivingAndNotBigBrokenCardIndexOf(false, CARD_TYPE.TANK_DESTORYER)
    if not tCard then
        return
    end

    self:print("playDstBeginAnimation", tCard.bLeftSide, tCard.nIndex)
    self:playAnimation("playCardRoleAttackAnimation", tCard)
end

function KStepAmbush:calcDamage(tSrcCard, tDstCard)
    return self.tLogic:calcDamage(tSrcCard, tDstCard)
end

function KStepAmbush:processAttackOnce(tSrcCard)
    local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
    if not tDstCard then
        return
    end

    self:print("processAttackOnce", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex)

    local nType, nDamage = self:calcDamage(tSrcCard, tDstCard)

    -- 被动技能埋点
    local tParam = {tDstCard = tDstCard}
    self:checkPoint(ABILITY_CHECK_POINT.CARD_BEFORE_ATTACK, tSrcCard, tDstCard, nDamage, nType, tParam)
    tDstCard = tParam.tDstCard
    -- 

    self:playAnimation("playCardStandAttackAnimation", tSrcCard)
    KSound.playEffect("fire")
    local nBulletID = self:addBullet(tSrcCard, tDstCard, nType, nDamage)
    self:playAnimation("playBulletFireAnimation", tSrcCard, tDstCard)
     KSound.playEffect("boom")
    self:playAnimation("playBulletBlastAnimation", tDstCard)
   
    local KBattleConfig         = require("battle/KBattleConfig")
    local oldCardState          = KBattleConfig.getBrokenState(tDstCard)
    local bIsLeftTeam           = tDstCard.bLeftSide

    self:applyBulletDamage(nBulletID)

    -- 被动技能埋点
    self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_ATTACK, tSrcCard, tDstCard, nDamage, nType)
    -- 
    
    local newCardState = KBattleConfig.getBrokenState(tDstCard)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self:playBrokenAnimation(tDstCard)
    end
    
    if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        self:playFightDestroyAnimation(tDstCard)
    end
end

function KStepAmbush:fire()
    self:print("fire")

    local tTaskIDList = {}
    local tAttackerList = self:getBattleData():getAllLivingAndNotBigBrokenCard(CARD_TYPE.TANK_DESTORYER)
    for _, v in ipairs(tAttackerList) do
        local nID = self:asyncExec(self.processAttackOnce, self, v)
        table.insert(tTaskIDList, nID)
        end

    self:waitAsync(tTaskIDList)
end

function KStepAmbush:canEnter()
    local tBattleData   = self:getBattleData()

    local bLeftTeamHasAlive    = tBattleData:isTeamHasLivingCard(true)
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)
    local bHasTankType         = tBattleData:hasLivingCard(CARD_TYPE.TANK_DESTORYER)

    local bCanEnter = bLeftTeamHasAlive and bRightTeamHasAlive and bHasTankType
    return bCanEnter
end

function KStepAmbush:run(nStepIndex)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
    self:checkSkillButtonState()
    self:enableSkill(true)
    self:showBattleState()
    self:waitSubStepFinish()
    self:moveUnit()
    self:waitSubStepFinish()
    self:scout()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    self:playSrcBeginAnimation()
    self:playDstBeginAnimation()
    require("src/battle/KEquip").effectSmokeBomb(nStepIndex, self:getBattleData(), self:getBattleUI())
    self:fire()
    self:waitSubStepFinish()
    self:emergencyRepairHandle()
    self:enableSkill(false)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end

return KStepAmbush

