

local KStepArtillerySkillLogic = class("KStepArtillerySkillLogic")

local skillPower            = math.ceil(KPlayer.level * 0.2)                        -- 技能火力（待定）
local nDstCardState         = 1                                                     -- 目标卡牌破损
function KStepArtillerySkillLogic:ctor(tBattleData)
    self.tBattleData = tBattleData
end

local TANK_TYPE_COE = 
{
    [CARD_TYPE.LIGHT_TANK]          = 0.8,
    [CARD_TYPE.MEDIUM_TANK]         = 0.9,
    [CARD_TYPE.HEAVY_TANK]          = 1.1,
    [CARD_TYPE.TANK_DESTORYER]      = 1.0,
    [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
    [CARD_TYPE.TRANSPORT]           = 1.0,
    [CARD_TYPE.BOSS]                = 1.0,
}

local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

function KStepArtillerySkillLogic:getMaxScout()
    local tSrcTeam = self.tBattleData.tSrcTeam
    if not tSrcTeam then
        return 0;
    end
    
    local maxScout = 0

    for _, v in ipairs(tSrcTeam) do
        if v.nScout > maxScout then
            maxScout = v.nScout
        end
    end
    
    return maxScout
end

local HIT_RANGE = {0, 1} -- 命中限定区间
-- 命中
function KStepArtillerySkillLogic:callHitRate(tDstCard)
    local playerLevel       = KPlayer.level                                         -- 司令部 等级
    local nSrcScoutHitRate  = self.tBattleData:getScoutHitRate({}, tDstCard)        -- 攻击方 侦查命中补正
    local nDstDodge         = self.tBattleData:getDodge(tDstCard)                   -- 目标 闪避
    local nDstLineupDodge   = self.tBattleData:getLineup(tDstCard).nDodge           -- 目标 阵形闪避
    local nDstTankTypeCode  = getTankTypeCoe(tDstCard)                              -- 目标 坦克类型补正
    
    local nHitRate = ((1.0 + (playerLevel / 500) + nSrcScoutHitRate) - (nDstDodge / (nDstDodge + 32) + nDstLineupDodge)) * nDstTankTypeCode * nDstCardState
    nHitRate = KUtil.makeInRange(nHitRate, HIT_RANGE)

    local nRandomValue = random()
    local bHitted = nRandomValue < nHitRate

    print("----> [轰炸] 命中计算 [开始]")
    print("---------> 司令部等级：",       playerLevel)
    print("---------> 攻击方 侦查命中补正：",       nSrcScoutHitRate)
    print("---------> 目标   闪避：",               nDstDodge)
    print("---------> 目标   阵形补正：",           nDstLineupDodge)
    print("---------> 目标   坦克类型加成：",       nDstTankTypeCode)
    print("----> [轰炸] 命中计算 [结束], 命中率：", nHitRate, " 随机值：", nRandomValue, " 命中：", bHitted)

	return bHitted
end

local PIERCE_ADJUST_RANGE   = {0.6, 1.4}     -- 穿甲随机补正系数
local PIERCE_RESULT_RANGE1  = {0.05, 0.2}    -- 穿甲成功后的随机范围
local PIERCE_RESULT_RANGE2  = {0.01, 0.05}   -- 穿甲失败后的随机范围
-- 穿甲
function KStepArtillerySkillLogic:calcPierce(tDstCard)
    local nMaxScout             = self:getMaxScout()                                  -- 队伍侦查最大值
    local nFrontArmour          = tDstCard.nFrontArmour                              -- 敌方前装甲
    local nRearArmour           = tDstCard.nRearArmour                               -- 敌方后装甲
	local nDstLineupCode 		= self.tBattleData:getLineupArmour(tDstCard)         -- 目标方 阵形护甲加成
    
    local nRandRatio   = random(PIERCE_ADJUST_RANGE)             
    local nPierceValue = (skillPower + nMaxScout) * nRandRatio - ((nFrontArmour + nRearArmour) /  2 * nDstLineupCode)
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    if bPierced then
        nRandomValue = random(PIERCE_RESULT_RANGE1)
    else
        nRandomValue = random(PIERCE_RESULT_RANGE2)
    end

    print("----> [轰炸] 穿甲计算 [开始]")
    print("--------> 目标   阵形加成：", nDstLineupCode)
    print("----> [轰炸] 穿甲计算 [结束], 最终穿透值：", nPierceValue, "是否穿透：", bPierced, " 随机值：", nRandomValue)

    return bPierced, nRandomValue
end

local THUMP_ADJUST_RANGE    = {0.7, 1.3}   -- 随机家加成范围
local THUMP_RATE_RANGE      = {0.05, 0.8}  -- 重击率最小最大值
local THUMP_MUTI            = 1.5          -- 重击倍率
-- 重击
function KStepArtillerySkillLogic:calcThumpRate(tDstCard)
    -- nDstArmour 目标放 护甲

    local nSrcRandomCoe         = random(THUMP_ADJUST_RANGE)                        -- 攻击方 随机系数
    local nMaxScout             = self:getMaxScout()                                 -- 队伍侦查最大值
    local nFrontArmour          = tDstCard.nFrontArmour                              -- 敌方前装甲
    local nRearArmour           = tDstCard.nRearArmour                               -- 敌方后装甲
    
    local nThumpValue           = (skillPower + nMaxScout * 0.4) - ((nFrontArmour + nRearArmour) / 2 * nSrcRandomCoe)
    nThumpValue                 = KUtil.makeInRange(nThumpValue, THUMP_RATE_RANGE)

    local nRandomValue = random()
    local bThump = nRandomValue < nThumpValue
    local nThumpMutiValue = 1
    if bThump then
        nThumpMutiValue = THUMP_MUTI
    end

    print("----> [轰炸] 重击计算 [开始]")
    print("--------> 攻击方 随机系数：",  nSrcRandomCoe)
    print("----> [轰炸] 重击计算 [结束] 重击最终值：", nThumpValue, " 随机值：", nRandomValue, " 重击：", bThump, "重击倍率：", nThumpMutiValue)

    return bThump, nThumpMutiValue
end

local DAMAGE_ADJUST_RANGE   = {0.5, 1.5}    -- 伤害随机补正范围
-- 伤害
function KStepArtillerySkillLogic:calcDamage(tDstCard)
    local nSrcRandomCoe         = random(DAMAGE_ADJUST_RANGE)                       -- 攻击方 随机系数
    local nMaxScout             = self:getMaxScout()                                -- 队伍侦查最大值
    local nFrontArmour          = tDstCard.nFrontArmour                             -- 敌方前装甲
    local nRearArmour           = tDstCard.nRearArmour                              -- 敌方后装甲
    local nDstLineupCode        = self.tBattleData:getLineupArmour(tDstCard)        -- 目标方 阵形护甲加成
    
	local bHit = self:callHitRate(tDstCard)
	if not bHit then
        print("----> [轰炸] 伤害计算 [结束], 未命中!")
        return ATTACK_RESULT.MISS, 0
	end

    local bPierce, nMinDamagePercent = self:calcPierce(tDstCard)
    if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("----> [轰炸] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, nDamage
    end

	local bThump, nThumpCoe = self:calcThumpRate(tDstCard)  		--bThump 是否重击 nThumpCoe 重击倍率

    local nDamage = (skillPower + nMaxScout * 0.6) - ((nFrontArmour + nRearArmour) / 2 * nDstLineupCode) * nThumpCoe
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)

    print("---------> 穿透系数：",               nMinDamagePercent)
    print("---------> 重击倍率：",               nThumpCoe)
    print("----> [轰炸] 伤害计算 [结束] 最终伤害值：", nDamage)
	
    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage 
end

return KStepArtillerySkillLogic
