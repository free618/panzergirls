local KStepArtilleryStrike =  class("KStepArtilleryStrike", require("battle/KBattleStepBase").new)

function KStepArtilleryStrike:ctor()
	local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.ARTILLERY_STRIKE
    self.tLogic = require("src/battle/KStepArtilleryStrikeLogic").new(tBattleData)
end

function KStepArtilleryStrike:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "ArtilleryStrike")
end

function KStepArtilleryStrike:playSrcBeginAnimation()
	local tCard = self:getBattleData():getFirstLivingAndNotBigBrokenCardIndexOf(true, CARD_TYPE.SELF_PROPELLED_GUN)
	if not tCard then
		return
	end

	self:print("playSrcBeginAnimation", tCard.bLeftSide, tCard.nIndex)
	self:playAnimation("playCardRoleAttackAnimation", tCard)
end

function KStepArtilleryStrike:playDstBeginAnimation()
	local tCard = self:getBattleData():getFirstLivingAndNotBigBrokenCardIndexOf(false, CARD_TYPE.SELF_PROPELLED_GUN)
	if not tCard then
		return
	end

	self:print("playDstBeginAnimation", tCard.bLeftSide, tCard.nIndex)
	self:playAnimation("playCardRoleAttackAnimation", tCard)
end

function KStepArtilleryStrike:fireBulletOnce(tSrcCard, nEquipPos, attackIndex)
	local nEquipID = tSrcCard["nEquip" .. nEquipPos]

	local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
	if not tDstCard then
		return
	end

	self:print("fireBulletOnce", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, nEquipID)

	self:delay((attackIndex - 1) * 1.0)
    self:playAnimation("playArtilleryStrikeCardAttackAnimation", tSrcCard)
	self:print("real fireBulletOnce", tSrcCard.bLeftSide, tSrcCard.nIndex, nEquipPos, attackIndex)

    local nType, nDamage = self:calcDamage(tSrcCard, tDstCard, nEquipPos)

    -- 被动技能埋点
	local tParam = {tDstCard = tDstCard}
    self:checkPoint(ABILITY_CHECK_POINT.CARD_BEFORE_ATTACK, tSrcCard, tDstCard, nDamage, nType, tParam)
    tDstCard = tParam.tDstCard
    -- 

    local nBulletID = self:addBullet(tSrcCard, tDstCard, nType, nDamage)
    KSound.playEffect("howitzer")
    self:playAnimation("playArtilleryStrikeBulletFireAnimation", tSrcCard, tDstCard)
    self:playAnimation("playArtilleryStrikeBulletAnimation", tDstCard)
    KSound.playEffect("boom")

    local KBattleConfig         = require("battle/KBattleConfig")
    local oldCardState          = KBattleConfig.getBrokenState(tDstCard)
    local bIsLeftTeam           = tDstCard.bLeftSide

    self:applyBulletDamage(nBulletID)
    
    -- 被动技能埋点
    self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_ATTACK, tSrcCard, tDstCard, nDamage, nType)
    -- 

    local newCardState = KBattleConfig.getBrokenState(tDstCard)
	
	if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
		self:playBrokenAnimation(tDstCard)
	end
	
	if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
		self:playFightDestroyAnimation(tDstCard)
	end
end

function KStepArtilleryStrike:processAttackOnce(tSrcCard)
	self:print("processAttackOnce", tSrcCard.bLeftSide, tSrcCard.nIndex)	

    if not self:getBattleData():canGunAttack(tSrcCard) then
        return
    end

	local taskIDList = {}
	local attackIndex = 0
	local equipIndex = 1
	while true do 
		equipIndex = equipIndex + 1
		local equipID = tSrcCard["nEquip" .. equipIndex]
		if not equipID then break end
		if equipID > 0 then
			attackIndex = attackIndex + 1
			local taskID = self:asyncExec(self.fireBulletOnce, self, tSrcCard, equipIndex, attackIndex)
			table.insert(taskIDList, taskID)
		end
    end
	self:waitAsync(taskIDList)
end

function KStepArtilleryStrike:fire()
	self:print("fire")

	local tTaskIDList = {}	
	local tAttackerList = self.tLogic:getAttackerList()
	for _, v in ipairs(tAttackerList) do
		local nID = self:asyncExec(self.processAttackOnce, self, v)
		table.insert(tTaskIDList, nID)
	end

	self:waitAsync(tTaskIDList)
end

function KStepArtilleryStrike:canEnter()
    local tBattleData    = self:getBattleData()

    local bLeftTeamHasAlive    = tBattleData:isTeamHasLivingCard(true)
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)
    local bHasTankType         = tBattleData:hasLivingCard(CARD_TYPE.SELF_PROPELLED_GUN)

    local bCanEnter = bLeftTeamHasAlive and bRightTeamHasAlive and bHasTankType
	return bCanEnter
end

function KStepArtilleryStrike:run(nStepIndex)
	self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
	self:checkSkillButtonState()
	self:enableSkill(true)
    self:showBattleState()
    self:waitSubStepFinish()
    self:scout()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
	self:playSrcBeginAnimation()
	self:playDstBeginAnimation()
    local KEquip = require("src/battle/KEquip")
    KEquip.effectSmokeBomb(nStepIndex, self:getBattleData(), self:getBattleUI())
	self:fire()
	self:waitSubStepFinish()
	self:emergencyRepairHandle()
	self:enableSkill(false)
	self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end
function KStepArtilleryStrike:calcDamage(tSrcCard, tDstCard, nEquipPos)
	return self.tLogic:calcDamage(tSrcCard, tDstCard, nEquipPos)
end
return KStepArtilleryStrike

