
local KStepNightFightLogic = class("KStepNightFightLogic")

function KStepNightFightLogic:ctor(tBattleData)
	self.tBattleData = tBattleData
end

local TANK_TYPE_SCOUT_COE = 
    {
        [CARD_TYPE.LIGHT_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1, 1.1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1.1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1, 1.1}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.MEDIUM_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.9, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.9, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.9, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.9, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.9, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.9, 1}, 
            [CARD_TYPE.BOSS]                = {0.9, 1}, 
            [CARD_TYPE.TURRET]              = {0.9, 1},
        },

        [CARD_TYPE.HEAVY_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.8, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.8, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.8, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.8, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.8, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {0.8, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },

        [CARD_TYPE.TANK_DESTORYER] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.7, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.7, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.7, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.7, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.7, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.7, 1}, 
            [CARD_TYPE.BOSS]                = {0.7, 1}, 
            [CARD_TYPE.TURRET]              = {0.7, 1},
        },

        [CARD_TYPE.SELF_PROPELLED_GUN] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.5, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.5, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.5, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.5, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.5, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.5, 1}, 
            [CARD_TYPE.BOSS]                = {0.5, 1}, 
            [CARD_TYPE.TURRET]              = {0.5, 1},
        },

        [CARD_TYPE.TRANSPORT] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.8, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.8, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.8, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.8, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.8, 0.9}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {0.8, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },

        [CARD_TYPE.BOSS] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1, 1}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.TURRET] = 
        { 
            [CARD_TYPE.LIGHT_TANK]          = {0.9, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.9, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.9, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.9, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.9, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.9, 1}, 
            [CARD_TYPE.BOSS]                = {0.9, 1}, 
            [CARD_TYPE.TURRET]              = {0.9, 1},
        },
    }
    
function KStepNightFightLogic:getTankTypeScoutCoe(tSrcCard, tDstCard)
    return TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][1]
end

function KStepNightFightLogic:getConfig()
	return require("src/battle/KBattleConfig")
end

-- 破损状态 必杀补正
local BROKEN_COE = 
{
	[CARD_BROKEN_STATE.LITTLE] = 10,
	[CARD_BROKEN_STATE.MIDDLE] = 20,
}

function KStepNightFightLogic:getBrokenCoe(tCard)
	local KBattleConfig = self:getConfig()
	local nBrokenState = KBattleConfig.getBrokenState(tCard)
	return BROKEN_COE[nBrokenState] or 0
end

local TEAM_LEADER_COE = 20 -- 队长必杀补正
local TEAM_MEMBER_COE = 10 -- 队员必杀补正
function KStepNightFightLogic:getMemberTypeCoe(tCard)
	if tCard.nIndex == 1 then
		return TEAM_LEADER_COE
	end

	return TEAM_MEMBER_COE
end

-- -- 装备组合必杀倍率
-- local EQUIP_GROUP2CRIT_MUTI =
-- {
-- 	{1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP, EQUIP_DETAIL_TYPE.MG}},
-- 	{1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.HE, EQUIP_DETAIL_TYPE.MG}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER, EQUIP_DETAIL_TYPE.MG}},
-- 	{1.5, {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP, EQUIP_DETAIL_TYPE.HE}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER, EQUIP_DETAIL_TYPE.AP}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.MG}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.AP}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.HE}},
-- 	{2,   {EQUIP_DETAIL_TYPE.MTG, EQUIP_DETAIL_TYPE.TRACER}},
-- }

-- local function isTableValuesContain(t1, t2)
-- 	if #t1 < #t2 then
-- 		return false
-- 	end

-- 	for _, v in ipairs(t2) do
-- 		if not HArray.FindFirstByValue(t1, v) then
-- 			return false
-- 		end
-- 	end

-- 	return true
-- end

-- function KStepNightFightLogic:getComboMuti(tSrcCard)
-- 	local tEquipDetailList = {}

-- 	local i = 0
-- 	while true do
-- 		i = i + 1
-- 		local nEquipID = tSrcCard["nEquip" .. i]
-- 		if not nEquipID then break end
-- 		if nEquipID > 0 then
-- 			local tEquipSetting = KConfig:getLine("equipInfo", nEquipID)
-- 			local nEquipDetailType = EQUIP_DETAIL_TYPE[tEquipSetting.szDetailType]
-- 			table.insert(tEquipDetailList, nEquipDetailType)
-- 		end
-- 	end

-- 	if #tEquipDetailList == 0 then
-- 		return
-- 	end

-- 	for _, v in ipairs(EQUIP_GROUP2CRIT_MUTI) do
-- 		if isTableValuesContain(tEquipDetailList, v[2]) then
-- 			return v[1]
-- 		end
-- 	end
-- end

local COMBO_RATE_RANGE = {0.05, 0.9} -- 必杀概率的区间约束
-- 必杀
function KStepNightFightLogic:calcCombo(tSrcCard, tDstCard)
	print("----> [夜战] 必杀计算 [开始]")

	local nComboMuti = self.tBattleData:getComboMuti(tSrcCard)
	if not nComboMuti then
		print("----> [夜战] 必杀计算 [结束]， 无法触发必杀， 装备组合不匹配!")
		return false, 1
	end

	local nSrcNightBattle 	= self.tBattleData:getNightBattle(tSrcCard) 	
	local nBrokenCoe 		= self:getBrokenCoe(tSrcCard)
	local nMemberTypeCoe 	= self:getMemberTypeCoe(tSrcCard)
	local nCrit 			= self.tBattleData:getCrit(tSrcCard)

	local nComboRate = (0.85 * nSrcNightBattle + nBrokenCoe + nMemberTypeCoe + ( nCrit * 100 ) ) / 180
	nComboRate = KUtil.makeInRange(nComboRate, COMBO_RATE_RANGE)

	local nRandomValue = random()
	local bCommbo = nRandomValue < nComboRate

	print("---------> 攻击方 夜战值：", nSrcNightBattle)
	print("---------> 攻击方 破损补正：", nBrokenCoe)
	print("---------> 攻击方 队长队员补正：", nMemberTypeCoe)
	print("---------> 攻击方 必杀率", nCrit)
	print("---------> 攻击方 必杀倍率", nComboMuti)
	print("----> [夜战] 必杀计算 [结束], 最终必杀率：", nComboRate, "随机值：", nRandomValue, "必杀：", bCommbo, "必杀倍率：", nComboMuti)

	return bCommbo, nComboMuti
end

local HIT_RANGE = {0.05, 0.9} -- 命中限定区间
-- 命中
function KStepNightFightLogic:callHitRate(tSrcCard, tDstCard)
    if tDstCard.bBrokenProtect and tDstCard.nCurrentHP == 1 then
        print("----> [第二轮炮战] 命中计算 [结束], 未命中：因为大破保护 ")
        return false
    end
    local nSrcLevel         = self.tBattleData:getLevel(tSrcCard)                   -- 攻击方 等级
    local nSrcHitRate       = self.tBattleData:getHitRate(tSrcCard)                 -- 攻击方 命中
    local nSrcScoutHitRate  = self.tBattleData:getScoutHitRate(tSrcCard, tDstCard)  -- 攻击方 侦查命中补正
    local nSrcLineupHitRate = self.tBattleData:getLineupHitRate(tSrcCard)           -- 攻击方 阵法命中补正
    local nSrcStateHitRateCoe     = self.tBattleData:getStateHitRateCoe(tSrcCard)                -- 攻击方 耐久和士气影响系数
    local nSrcAbilityHitRate = self.tBattleData:getAbilityHitRate(tSrcCard)         -- 攻击方 被动技能命中率补正

    local nDstDodge         = self.tBattleData:getDodge(tDstCard, true)                   -- 目标 闪避
    local nDstLineupDodge   = self.tBattleData:getLineupDodge(tDstCard)             -- 目标 阵形闪避
    local nDstAbilityDodge  = self.tBattleData:getAbilityDodge(tDstCard)            -- 目标 坦克被动技能补正

 	local nHitRate = ((1.0 + (nSrcLevel / 500) + nSrcHitRate + nSrcScoutHitRate + nSrcLineupHitRate + nSrcAbilityHitRate) - (nDstDodge / (nDstDodge + 35) + nDstLineupDodge + nDstAbilityDodge)) * nSrcStateHitRateCoe
	nHitRate = KUtil.makeInRange(nHitRate, HIT_RANGE)

    local nRandomValue = random()
    local bHitted = nRandomValue < nHitRate

    print("----> [夜战] 命中计算 [开始]")
    print("---------> 攻击方 等级：",               nSrcLevel)
    print("---------> 攻击方 命中：",               nSrcHitRate)
    print("---------> 攻击方 侦查命中补正：",       nSrcScoutHitRate)
    print("---------> 攻击方 阵形加成：",           nSrcLineupHitRate)
    print("---------> 攻击方 耐久和士气补正：",     nSrcStateHitRateCoe)
    print("---------> 攻击方 被动技能命中补正：",   nSrcAbilityHitRate)
    print("---------> 目标   闪避：",               nDstDodge)
    print("---------> 目标   阵形补正：",           nDstLineupDodge)
    print("---------> 目标   坦克被动技能补正：",   nDstAbilityDodge)
    print("----> [夜战] 命中计算 [结束], 命中率：", nHitRate, " 随机值：", nRandomValue, " 命中：", bHitted)

    return bHitted
end

local PIERCE_ADJUST_RANGE   = {0.7, 1.3}     -- 穿甲随机补正系数
local PIERCE_RESULT_RANGE1  = {0.05, 0.2}    -- 穿甲成功后的随机范围
local PIERCE_RESULT_RANGE2  = {0.01, 0.05}   -- 穿甲失败后的随机范围
-- 穿甲
function KStepNightFightLogic:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstArmourLineupCoe)
	-- nDstArmour 目标放 护甲
    local nPierceEffectRate     = self.tBattleData:getPierceEffectRate(tDstCard)           -- 目标 穿透生效率
    local nRandomValue = random()
    print("----> [夜战] 穿甲计算 [开始], 穿甲生效概率：", nPierceEffectRate, "随机值：", nRandomValue)
    local bEffect = nRandomValue < nPierceEffectRate
    if bEffect then 
        print("----> [夜战] 穿甲计算 [结束], 未穿甲：穿甲未生效 ")
        return false, nRandomValue 
    end

	local TANK_TYPE_COE = 
    {
        [CARD_TYPE.LIGHT_TANK]          = 1.0,
        [CARD_TYPE.MEDIUM_TANK]         = 1.2,
        [CARD_TYPE.HEAVY_TANK]          = 1.0,
        [CARD_TYPE.TANK_DESTORYER]      = 1.0,
        [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
        [CARD_TYPE.TRANSPORT]           = 1.0,
        [CARD_TYPE.BOSS]                = 1.0,
    }

    local function getTankTypeCoe(tCard)
        return TANK_TYPE_COE[tCard.nNamedType]
    end

	local nSrcPenetrate            = tSrcCard.nPenetrate
	local nSrcPenetrateCoe         = random(PIERCE_ADJUST_RANGE)
	local nSrcLineupCoe            = self.tBattleData:getLineupPenetrate(tSrcCard)                     -- 阵型穿透加成
	local nSrcSpeed                = tSrcCard.nSpeed
	local nSrcTankTypeCode         = getTankTypeCoe(tSrcCard)                                          -- 攻击方 坦克类型补正
	local nSrcStatePenetrateCoe    = self.tBattleData:getStatePenetrateCoe(tSrcCard)                   -- 穿透影响系数
    local nAttackAddtion 	       = TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]  -- 距离衰减系数

	local nPierceValue  = (nSrcPenetrate + nSrcSpeed * 0.3 * nSrcTankTypeCode) * nSrcPenetrateCoe * nSrcLineupCoe * nSrcStatePenetrateCoe * nAttackAddtion - nDstArmour * nDstArmourLineupCoe
    local bPierced      = nPierceValue > 0
    local nRandomValue  = 0
    if bPierced then
        nRandomValue = random(PIERCE_RESULT_RANGE1)
    else
        nRandomValue = random(PIERCE_RESULT_RANGE2)
    end

    print("----> [夜战] 穿甲计算 [开始]")
    print("--------> 攻击方 穿透：",     nSrcPenetrate)
    print("--------> 攻击方 随机加成：", nSrcRandomAdjustCoe)
    print("--------> 攻击方 阵形加成：", nSrcLineupCoe)
    print("--------> 攻击方 速度：", 	 nSrcSpeed)
    print("--------> 目标   护甲：",     nDstArmour)
    print("--------> 目标   阵形加成：", nDstArmourLineupCoe)
    print("----> [夜战] 穿甲计算 [结束], 最终穿透值：", nPierceValue, "是否穿透：", bPierced, " 随机值：", nRandomValue)

    return bPierced, nRandomValue
end

local THUMP_ADJUST_RANGE    = {0.7, 1.3}   -- 随机家加成范围
local THUMP_RATE_RANGE      = {0.05, 0.8}  -- 重击率最小最大值
local THUMP_MUTI            = 2          -- 重击倍率
-- 重击
function KStepNightFightLogic:calcThumpRate(tSrcCard, tDstCard, nDstArmour)
    -- nDstArmour 目标放 护甲

	local TANK_TYPE_COE = 
    {
        [CARD_TYPE.LIGHT_TANK]          = 1.0,
        [CARD_TYPE.MEDIUM_TANK]         = 1.2,
        [CARD_TYPE.HEAVY_TANK]          = 1.0,
        [CARD_TYPE.TANK_DESTORYER]      = 1.0,
        [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
        [CARD_TYPE.TRANSPORT]           = 1.0,
        [CARD_TYPE.BOSS]                = 1.0,
    }

    local function getTankTypeCoe(tCard)
        return TANK_TYPE_COE[tCard.nNamedType]
    end

    local nSrcAttack 	= self.tBattleData:getAttack(tSrcCard)          -- 攻击方 火力
    local nSrcRandomCoe = random(THUMP_ADJUST_RANGE)                    -- 攻击方 随机系数
	local nSrcThump 	= self.tBattleData:getThump(tSrcCard)			-- 攻击方 重击率
	local nSrcSpeed		= self.tBattleData:getSpeed(tSrcCard)			-- 攻击方 速度
	local nSrcTankTypeCode  = getTankTypeCoe(tSrcCard)                              -- 攻击方 坦克类型补正
	local nSrcStateAttackCoe      = self.tBattleData:getStateAttackCoe(tSrcCard)          -- 火力影响系数

	local nThumpValue = (nSrcAttack + nSrcSpeed * 0.3 * nSrcTankTypeCode * nSrcStateAttackCoe - nDstArmour ) / 40.0 * nSrcRandomCoe + nSrcThump
	nThumpValue = KUtil.makeInRange(nThumpValue, THUMP_RATE_RANGE)

    local nRandomValue = random()
    local bThump = nRandomValue < nThumpValue
    local nThumpMutiValue = 1
    if bThump then
        nThumpMutiValue = THUMP_MUTI
    end

    print("----> [夜战] 重击计算 [开始]")
    print("--------> 攻击方 火力：",      nSrcAttack)
    print("--------> 攻击方 随机系数：",  nSrcRandomCoe)
    print("--------> 攻击方 重击率：",    nSrcThump)
    print("--------> 攻击方 速度：",  	  nSrcSpeed)
    print("--------> 目标   护甲：",      nDstArmour)
    print("----> [夜战] 重击计算 [结束] 重击最终值：", nThumpValue, " 随机值：", nRandomValue, " 重击：", bThump, "重击倍率：", nThumpMutiValue)

    return bThump, nThumpMutiValue
end

-- 擦伤
function KStepNightFightLogic:calcGraze(tSrcCard, tDstCard)
    local nRandomValue  = random()
    local KBattleConfig = require("src/battle/KBattleConfig")
    local nGrazeRate   = KBattleConfig.getGrazeRate(tDstCard)
    local tGrazeRange  = KBattleConfig.getGrazeRange(tDstCard)

    local bGrazed   = nRandomValue <= nGrazeRate and tGrazeRange ~= nil
    if not bGrazed then
        print("----> [夜战] 擦伤计算 [结束], 未擦伤：擦伤未生效 ")
        return false, 0
    end

    local nRandomValue = random(tGrazeRange)
    local nDstMaxHP    = tDstCard.nMaxHP
    local nGrazeValue  = math.max(1, math.floor(nDstMaxHP * nRandomValue))
    
    print("----> [夜战] 擦伤计算 [开始]")
    print("--------> 目标 随机擦伤率：", nRandomValue)
    print("--------> 目标 最大血量", nDstMaxHP)
    print("----> [夜战] 擦伤计算 [结束], 最终擦伤值：", nGrazeValue, "是否擦伤：", bGrazed, " 随机值：", nRandomValue)

    return bGrazed, nGrazeValue
end

local DAMAGE_ADJUST_RANGE   = {0.7, 1.3}    -- 伤害随机补正范围
local REAR_ARMOUR_RATE      = 0             -- 选择后装甲的概率

-- 伤害
function KStepNightFightLogic:calcDamage(tSrcCard, tDstCard)

    local TANK_TYPE_COE = 
    {
        [CARD_TYPE.LIGHT_TANK]          = 1.0,
        [CARD_TYPE.MEDIUM_TANK]         = 1.2,
        [CARD_TYPE.HEAVY_TANK]          = 1.0,
        [CARD_TYPE.TANK_DESTORYER]      = 1.0,
        [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
        [CARD_TYPE.TRANSPORT]           = 1.0,
        [CARD_TYPE.BOSS]                = 1.0,
    }

    local function getTankTypeCoe(tCard)
        return TANK_TYPE_COE[tCard.nNamedType]
    end

	print("----> [夜战] 伤害计算 [开始]", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex)

    local nSrcCardType  = tSrcCard.nNamedType
    local nDstArmour    = tDstCard.nFrontArmour
    local nDstLineupArmour  = self.tBattleData:getLineupFrontArmour(tSrcCard)             -- 目标 阵形前护甲加成
    if nSrcCardType == CARD_TYPE.LIGHT_TANK or nSrcCardType == CARD_TYPE.MEDIUM_TANK then
        nDstArmour          = tDstCard.nRearArmour
        nDstLineupArmour    = self.tBattleData:getLineupRearArmour(tSrcCard)              -- 目标 阵形后护甲加成
        print("--------> [夜战] 目标护甲选择, 攻击者类型：", nSrcCardType, " 选择后甲， 装甲值：", nDstArmour)
    else
        nDstArmour    = tDstCard.nFrontArmour
        nDstLineupArmour  = self.tBattleData:getLineupFrontArmour(tSrcCard)             -- 目标 阵形前护甲加成
        local nSrcLineupAttackRearArmourRate = self.tBattleData:getLineupAttackRearArmourRate(tSrcCard, tDstCard)
        local nAttackRearArmourRate      = REAR_ARMOUR_RATE + nSrcLineupAttackRearArmourRate
        local nRandomValueForArmour = random()
        if nRandomValueForArmour < nAttackRearArmourRate then
            nDstArmour = tDstCard.nRearArmour
            nDstLineupArmour = self.tBattleData:getLineupRearArmour(tSrcCard)            -- 目标 阵形后护甲加成
        end
        print("--------> [夜战] 目标护甲选择, 随机值：", nRandomValueForArmour, "后装甲概率：", nAttackRearArmourRate, " 装甲值：", nDstArmour)
    end

	local bCommbo, nComboCoe = self:calcCombo(tSrcCard, tDstCard)
	if not bCommbo then
		local bHit = self:callHitRate(tSrcCard, tDstCard)
        if not bHit then
            local bGrazed, nGrazeValue =  self:calcGraze(tSrcCard, tDstCard)
            if bGrazed then
                print("----> [夜战] 伤害计算 [结束], 擦伤! 擦伤值：", nGrazeValue)
                return ATTACK_RESULT.GRAZE, false, nGrazeValue
            else
               print("----> [夜战] 伤害计算 [结束], 未命中!")
               return ATTACK_RESULT.MISS, false, 0
            end
        end
	end

	local bPierce, nMinDamagePercent = self:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstLineupArmour) 				-- bPierce:是否穿甲, nMinDamagePercent ： 最小百分比
	if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("----> [夜战] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, bCommbo, nDamage
    end

	local bThump, nThumpCoe = self:calcThumpRate(tSrcCard, tDstCard, nDstArmour)			--bThump 是否重击 nThumpCoe 重击倍率

   	local nSrcAttack        = self.tBattleData:getAttack(tSrcCard)                      -- 攻击方 火力    
    local nSrcRandomCoe     = random(DAMAGE_ADJUST_RANGE)                               -- 攻击方 随机系数
    local nSrcLineupAttack  = self.tBattleData:getLineupAttack(tSrcCard)                -- 攻击方 阵形攻击加成
	local nSrcSpeed 		= self.tBattleData:getSpeed(tSrcCard)						-- 攻击方 速度
	local nSrcTankTypeCode  = getTankTypeCoe(tSrcCard)                                  -- 攻击方 坦克类型补正
	local nSrcStateAttackCoe      = self.tBattleData:getStateAttackCoe(tSrcCard)        -- 火力影响系数
    local nAttackAddtion 	= TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]				-- 距离衰减系数

	local nDamage = ((nSrcAttack + nSrcSpeed * 0.3 * nSrcTankTypeCode) * nSrcRandomCoe * nSrcLineupAttack * nSrcStateAttackCoe * nAttackAddtion - nDstArmour * nDstLineupArmour )*nThumpCoe * nComboCoe
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)

    print("---------> 穿透系数：",               nMinDamagePercent)
    print("---------> 重击倍率：",               nThumpCoe)
    print("---------> 攻击方 火力：",          	 nSrcAttack)
    print("---------> 攻击方 阵形攻击加成：",    nSrcLineupAttack)
    print("---------> 攻击方 随机系数：",        nSrcRandomCoe)
    print("---------> 攻击方 速度：",        	 nSrcSpeed)
    print("---------> 目标   护甲：",            nDstArmour)
    print("---------> 目标   阵形护甲加成：",    nDstLineupArmour)
    print("----> [缠斗] 伤害计算 [结束] 最终伤害值：", nDamage)

    if bThump then
        return ATTACK_RESULT.CRIT, bCommbo, nDamage
    end
    return ATTACK_RESULT.NORMAL, bCommbo, nDamage 
end

return KStepNightFightLogic
