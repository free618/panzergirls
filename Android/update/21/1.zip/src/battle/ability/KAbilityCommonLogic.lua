--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KAbilityCommonLogic.lua
--  Creator     : lvsongxin
--  Date        : 2016/07/29   22:13
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local KAbilityCommonLogic = class("KAbilityCommonLogic")

function KAbilityCommonLogic:ctor(tAbilityManager)
    self.tAbilityManager = tAbilityManager
end

-- 判断是否是队长
function KAbilityCommonLogic:bIsTeamLeader(tCard)
    return (tCard.nIndex == 1)
end

-- 检测概率
function KAbilityCommonLogic:checkProbability(nProbability)
    local randomValue = random()
    if randomValue < nProbability then
        return true
    end
    return false
end

-- 判断两张卡是否相同
function KAbilityCommonLogic:bIsSameCard(tCardA, tCardB)
    return (tCardA.bLeftSide == tCardB.bLeftSide and tCardA.nIndex == tCardB.nIndex)
end

-- 获取卡牌的左右相邻卡牌
function KAbilityCommonLogic:getAdjCard(tCard)
    local tBattleData = self.tAbilityManager:getBattleData()
    local tAdjCardList = {}

    local nIndex = tCard.nIndex
    local nLeftIndex = nIndex - 1
    local nRightIndex = nIndex + 1

    if nLeftIndex > 0 then
        local tOneCard = tBattleData:getCard(tCard.bLeftSide, nLeftIndex)
        if tOneCard then
            table.insert(tAdjCardList, tOneCard)
        end
    end

    if nRightIndex <= MAX_TEAM_CARD_COUNT then
        local tOneCard = tBattleData:getCard(tCard.bLeftSide, nRightIndex)
        if tOneCard then
            table.insert(tAdjCardList, tOneCard)
        end
    end
    return tAdjCardList
end

-- 获取对方所有卡牌
function KAbilityCommonLogic:getAllEmenyCard(tCard)
    local tBattleData = self.tAbilityManager:getBattleData()

    local bLeftSide = tCard.bLeftSide
    local tCardList 
    if not bLeftSide then
        tCardList = tBattleData:getLeftTeamData()
    else
        tCardList = tBattleData:getRightTeamData()
    end

    return tCardList
end

-- 获取我方所有卡牌
function KAbilityCommonLogic:getAllOwnCard(tCard)
    local tBattleData = self.tAbilityManager:getBattleData()

    local bLeftSide = tCard.bLeftSide
    local tCardList 
    if bLeftSide then
        tCardList = tBattleData:getLeftTeamData()
    else
        tCardList = tBattleData:getRightTeamData()
    end

    return tCardList
end

return KAbilityCommonLogic