-- II号
-- 不可靠的前辈
-- 闪电战中我方全体火力·穿透上升速度的15%

local nShanDianZhanID = 2

local KAbilityBuKeKaoDeQianBei = class("KAbilityBuKeKaoDeQianBei", require("src/battle/ability/KAbilityBase").new)

function KAbilityBuKeKaoDeQianBei:ctor()    
end

function KAbilityBuKeKaoDeQianBei:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    local tBattleData = self:getBattleData()
    local tLineupData = tBattleData:getLineup(tCard)
    local nLineupID = tLineupData.nID

    if nLineupID ~= nShanDianZhanID then
        return 
    end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tAllCard = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tAllCard) do
        local nSpeed = oneCard.nSpeed
        local nAddValue = math.floor(nSpeed * 0.15)
        self:changeCardProperty(oneCard, "nAttack", nAddValue)
        self:changeCardProperty(oneCard, "nPenetrate", nAddValue)
    end

    return 
end

function KAbilityBuKeKaoDeQianBei:batttleEnd()
    self:recoverCardProperty()

    self.nUseTime = 0
end

return KAbilityBuKeKaoDeQianBei
