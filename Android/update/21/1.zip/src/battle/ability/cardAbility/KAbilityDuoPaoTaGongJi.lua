-- T28
-- 多炮塔攻击
-- 攻击命中时40%几率再进行一次攻击，火力·穿透+10（最多4次）

local nProbability = 0.4

local KAbilityDuoPaoTaGongJi = class("KAbilityDuoPaoTaGongJi", require("src/battle/ability/KAbilityBase").new)

function KAbilityDuoPaoTaGongJi:ctor()
    self.bShowAnimation = true
end

local function resetData(self)
    self.bShowAnimation = true
    self:recoverCardProperty()
    self.nUseTime = 0 
end

function KAbilityDuoPaoTaGongJi:cardAfterAttack(tTriggerCard, tDstCard, nDamage, nType)
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end
    if tDstCard.nCurrentHP == 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if nType == ATTACK_RESULT.MISS then
        resetData(self)
        return
    end

    if not tCommonLogic:checkProbability(nProbability) then
        resetData(self)
        return 
    end

    if self.nUseTime >= 3 then
        resetData(self)
        return
    end

    self:changeCardProperty(tCard, "nAttack", 10)
    self:changeCardProperty(tCard, "nPenetrate", 10)
    self.nUseTime = self.nUseTime + 1

    self:processAttackTarget(tCard, tDstCard)
end

function KAbilityDuoPaoTaGongJi:processAttackTarget(tSrcCard, tDstCard)
    local tCurrentStep = self:getBattleManager().tCurrentStep

    local tTaskIDList   = {}

    if self.bShowAnimation then
        local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityAnimation", tSrcCard, self.nAbilityID)
        table.insert(tTaskIDList, nID)
        self.bShowAnimation = false
    end

    local crossStartFrame = 0
    local crossFireFrame  = 40
    tCurrentStep:delay((crossFireFrame - crossStartFrame) / 60)
    local tInfo         = {tDamageTaskIDList = {}}
    local nTaskID   = tCurrentStep:asyncExec(self.cardFireTarget, self, tSrcCard, tDstCard, tInfo)
    table.insert(tTaskIDList, nTaskID)
    tCurrentStep:waitAsync(tTaskIDList)
    tCurrentStep:waitAsync(tInfo.tDamageTaskIDList)

    local KBattleConfig = require("src/battle/KBattleConfig")
    local bIsLeftTeam  = tDstCard.bLeftSide
    local newCardState  = KBattleConfig.getBrokenState(tDstCard)
    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        tCurrentStep:playBrokenAnimation(tDstCard)
    end
    if bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        tCurrentStep:playFightDestroyAnimation(tDstCard)
    end
end

function KAbilityDuoPaoTaGongJi:cardFireTarget(tSrcCard, tDstCard, tInfo)
    local tCurrentStep = self:getBattleManager().tCurrentStep
    local nType, nDamage 
    nType, nDamage = tCurrentStep.tLogic:calcDamage(tSrcCard, tDstCard)

    local nBulletID      = tCurrentStep:addBullet(tSrcCard, tDstCard, nType, nDamage)
    tCurrentStep:playAnimation("playCardFireAnimation", tSrcCard)
    KSound.playEffect("fire")
    tCurrentStep:playAnimation("playBulletFireAnimation", tSrcCard, tDstCard)
    KSound.playEffect("boom")
    
    if nType ~= ATTACK_RESULT.GRAZE then
        tCurrentStep:playAnimation("playBulletBlastAnimation", tDstCard)
    end

    local nTaskID       = tCurrentStep:asyncExec(tCurrentStep.applyBulletDamage, tCurrentStep, nBulletID)
    table.insert(tInfo.tDamageTaskIDList, nTaskID)

    self:cardAfterAttack(tSrcCard, tDstCard, nType, nDamage)
end

function KAbilityDuoPaoTaGongJi:battleEnd()
    resetData(self)
end

return KAbilityDuoPaoTaGongJi
