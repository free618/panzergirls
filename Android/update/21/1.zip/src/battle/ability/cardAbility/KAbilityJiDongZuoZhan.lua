-- T-26
-- 机动作战
-- 作为队长时，二轮炮击，免疫大破伤害

local KAbilityJiDongZuoZhan = class("KAbilityJiDongZuoZhan", require("src/battle/ability/KAbilityBase").new)

function KAbilityJiDongZuoZhan:ctor()    
end

function KAbilityJiDongZuoZhan:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    local tCard = self.tCard

    if not self.tAbilityManager.tCommonLogic:bIsTeamLeader(tCard) then
        return
    end

    if not self.tAbilityManager.tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if tCard.nCurrentHP == 0 then return end

    local stepType = self:getBattleManager().tCurrentStep.nStepType
    if not (stepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION2) then
        return
    end

    local KBattleConfig = require("src/battle/KBattleConfig")
    local cardState     = KBattleConfig.getBrokenState(tCard)
    if cardState >= CARD_BROKEN_STATE.BIG then
        return 
    end

    local nDamage = tParam.tBulletInfo.nDamage
    local  mockCard = {
        nCurrentHP = tCard.nCurrentHP - nDamage,
        nMaxHP     = tCard.nMaxHP
    }
    local mockState = KBattleConfig.getBrokenState(mockCard)
    if mockState < CARD_BROKEN_STATE.BIG then
        return
    end

    local tCurrentStep = self:getBattleManager().tCurrentStep
    local tTaskIDList = tParam.tTaskIDList
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityLightAnimation", tCard)
    table.insert(tTaskIDList, nID)
    tParam.tBulletInfo.nDamage = 0
    return 
end

return KAbilityJiDongZuoZhan
