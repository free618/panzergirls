-- III-A
-- 紧急观测
-- 作为队长时，火炮打击·伏击战阶段，我方受到的所有伤害减少50%

local KAbilityJinjiGuanCe = class("KAbilityJinjiGuanCe", require("src/battle/ability/KAbilityBase").new)

function KAbilityJinjiGuanCe:ctor()    
end

function KAbilityJinjiGuanCe:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    if not self.tAbilityManager.tCommonLogic:bIsTeamLeader(tCard) then
        return
    end
    
    if not (tCard.bLeftSide == tTriggerCard.bLeftSide) then
        return 
    end

    local stepType = self:getBattleManager().tCurrentStep.nStepType
    if not (stepType == BATTLE_STEP_TYPE.ARTILLERY_STRIKE and stepType == BATTLE_STEP_TYPE.AMBUSH) then
        return
    end

    tParam.tBulletInfo.nDamage = math.floor(tParam.tBulletInfo.nDamage * 0.5)
    return 
end

return KAbilityJinjiGuanCe
