-- T34
-- T34冲击
-- 攻击未击穿时30%几率发动，固定造成目标当前HP*50%的伤害。（39.5伤害算39）


local nProbability = 0.3

local KAbilityT34ChongJi = class("KAbilityT34ChongJi", require("src/battle/ability/KAbilityBase").new)

function KAbilityT34ChongJi:ctor()
end

function KAbilityT34ChongJi:cardAfterAttack(tTriggerCard, tDstCard, nDamage, nType)
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if nType ~= ATTACK_RESULT.RICOCHET then
        return 
    end

    if not tCommonLogic:checkProbability(nProbability) then
        return
    end

    local nHurtDamage = math.floor(0.5 * tDstCard.nCurrentHP)
    local nHurtType   = ATTACK_RESULT.NORMAL

    local tCurrentStep = self:getBattleManager().tCurrentStep
    tCurrentStep:playAnimation("playCardAbilityAnimation", tCard, self.nAbilityID)

    nType = ATTACK_RESULT.NORMAL
    self:hurtCard(tDstCard, nType, nHurtDamage)

    self.nUseTime = self.nUseTime + 1
end

function KAbilityT34ChongJi:hurtCard(tCard, nType, nDamage)
    local tBattleData = self:getBattleData()
    local tBattleUI   = self:getBattleUI()
    local tCurrentStep = tBattleUI._tBattleManager.tCurrentStep

    local bIsLeftTeam        = tCard.bLeftSide
    local KBattleConfig      = require("src/battle/KBattleConfig")
    local KBattleUIHelper    = require("battle/KBattleUIHelper")
    local oldCardState       = KBattleConfig.getBrokenState(tCard)
    local nOldHP, nCurrentHP = tBattleData:costHP(tCard, nDamage)
    local newCardState       = KBattleConfig.getBrokenState(tCard)

    local tTaskIDList = {}
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCostHPAnimation", tCard, nOldHP, nCurrentHP)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playHurtAnimation", tCard, nType, nDamage)
    table.insert(tTaskIDList, nID)

    local playBrokenAnimation = 30 + 50 -- playCostHPAnimation and playHurtAnimation frame
    KBattleUIHelper.delay(tBattleUI, playBrokenAnimation / 60)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        tCurrentStep:playBrokenAnimation(tCard)
    end

    if bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tCard.bUseMountItem then
        tCurrentStep:playFightDestroyAnimation(tCard)
    end
    tCurrentStep:waitAsync(tTaskIDList)
end

return KAbilityT34ChongJi
