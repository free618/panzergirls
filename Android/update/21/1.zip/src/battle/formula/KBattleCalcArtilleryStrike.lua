--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleCalcArtilleryStrike.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleCalcBase = require("src/battle/formula/KBattleCalcBase")

local KBattleCalcArtilleryStrike = class( "KBattleCalcArtilleryStrike", KBattleCalcBase )

function KBattleCalcArtilleryStrike:ctor(tBattleData)
    KBattleCalcBase.ctor(self, tBattleData)
end

function KBattleCalcArtilleryStrike:doCalcDamage(tSrcCard, tDstCard, tFun, ...)
    local bHit = self:calcHitRate(tFun.hit, tSrcCard, tDstCard)
    if not bHit then
        print("----> 伤害计算 [结束], 未命中!")
        return ATTACK_RESULT.MISS, 0
    end
    local bPierce, nMinDamagePercent = self:calcPierce(tFun.pierce, tSrcCard, tDstCard)
    local bThump, nThumpCoe          = self:calcThumpRate(tFun.thump, tSrcCard, tDstCard)

    local nDamage = tFun.damage(bPierce, nMinDamagePercent, bThump, nThumpCoe)
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)
    print("----> 伤害计算 [结束] 最终伤害值：", nDamage)

    if bPierce then 
        return ATTACK_RESULT.RICOCHET, nDamage
    end

    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage
end

return KBattleCalcArtilleryStrike
