--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillAirSupportLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local UI_INTERVAL = 0.3  -- ui need
local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillAirSupportLogic = class( "KSkillAirSupportLogic", KSkillBase )

function KSkillAirSupportLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nAttack      = tSkillConfig.nParam1
    self.nHitRate     = tSkillConfig.nParam2
    self.nTargetCount = tSkillConfig.nParam3
    self.nEquipTemplateID = nEquipTemplateID
end

function KSkillAirSupportLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return true
end

function KSkillAirSupportLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.END)
    end

    local tDstList          = self:getDstList()
    local tTaskIDList       = {}

    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper   = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    local tCardCount        = nil 
    
    KBattleSkillAnimation.playAnimation("playSkillAirSupportAnimation", self.tBattleData, self.tBattleUI, isLeft, equipConfig, tSkillConfig)

    for _, tCard in ipairs(tDstList) do
        tCardCount = #tDstList
        local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillAirSupportPlayAnimation", self.tBattleData, self.tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
        table.insert(tTaskIDList, nID)

        KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
    end

    local bombBeginFrame = 100 
    KBattleUIHelper.delay(self.tBattleUI, bombBeginFrame / 60 - UI_INTERVAL * tCardCount)

    for _, tCard in ipairs(tDstList) do
        local nType, nDamage = self:calcDamage(nil, tCard)
        local nID = self:asyncExec(self.hurtCard, self, self.tBattleData, self.tBattleUI, tCard, nType, nDamage)
        table.insert(tTaskIDList, nID)
        KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
    end

    self:waitAsync(tTaskIDList)
end

function KSkillAirSupportLogic:getDstList()
    local tHighList = {}
    local tLowList = {}
    for _, tCard in ipairs(self.tDstTeam) do
        if tCard.bScouted and tCard.nCurrentHP > 0 then
            table.insert(tHighList, tCard)
        else
            table.insert(tLowList, tCard)
        end
    end

    local tDstList = {}
    for i = 1, self.nTargetCount do
        local nCartCount = #tHighList
        if nCartCount > 0 then
            local nIndex = math.random(nCartCount)
            table.insert(tDstList, tHighList[nIndex])
            table.remove(tHighList, nIndex)
        else
            local nCartCount = #tLowList
            if nCartCount == 0 then break end
            local nIndex = math.random(nCartCount)
            table.insert(tDstList, tLowList[nIndex])
            table.remove(tLowList, nIndex)
        end
    end
    return tDstList
end

return KSkillAirSupportLogic
