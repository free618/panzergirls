--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillBase.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = class("KSkillBase")

function KSkillBase:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.tBattleUI      = tBattleUI
    self.tBattleData    = tBattleData
    self.tSkillConfig   = tSkillConfig
    self.tSrcTeam       = tSrcTeam
    self.tDstTeam       = tDstTeam
    self.nSkillPosition = nSkillPosition
	self.tAsyncExector  = require("battle/KAsyncExector").new()
    self.tCalc = require("src/battle/formula/KBattleCalcBase").new(tBattleData)
end

function KSkillBase:getBattleData()
    return self.tBattleData
end

function KSkillBase:asyncExec(fnFunc, ...)
    return self.tAsyncExector:exec(fnFunc, ...)
end

function KSkillBase:waitAsync(tTaskIDList)
    self.tAsyncExector:waiting(tTaskIDList)
end

function KSkillBase:getHitCoe(tCard)
    local szSkillType = self.tSkillConfig.szType
    local szCardType  = self:getBattleData():getCardTypeName(tCard)
    local tConfig     = KConfig:getLine("coefficient", szSkillType .. "_HIT")
    if not tConfig then return end
    return tConfig["n" .. szCardType]
end

function KSkillBase:hurtCard(tBattleData, tBattleUI, tCard, nType, nDamage)
    print("-----> Call hurtCard~")
    local bIsLeftTeam        = tCard.bLeftSide
    local KBattleConfig      = require("src/battle/KBattleConfig")
    local KBattleUIHelper    = require("battle/KBattleUIHelper")
    local oldCardState       = KBattleConfig.getBrokenState(tCard)
    local nOldHP, nCurrentHP = tBattleData:costHP(tCard, nDamage)
    local newCardState       = KBattleConfig.getBrokenState(tCard)

    local tTaskIDList = {}
    local nID = self:asyncExec(self.playAnimation, self, "playCostHPAnimation", tBattleData, tBattleUI, tCard, nOldHP, nCurrentHP)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playHurtAnimation", tBattleData, tBattleUI, tCard, nType, nDamage)    
    table.insert(tTaskIDList, nID)

    local playBrokenAnimation = 30 + 50 -- playCostHPAnimation and playHurtAnimation frame
    KBattleUIHelper.delay(self.tBattleUI, playBrokenAnimation / 60)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self.tBattleUI._tBattleManager.tCurrentStep:playBrokenAnimation(tCard)
    end

    if tCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tCard.bUseMountItem then
        self.tBattleUI._tBattleManager.tCurrentStep:playFightDestroyAnimation(tCard)
    end
    self:waitAsync(tTaskIDList)
end

function KSkillBase:playAnimation(szFunc, tBattleData, tBattleUI, ...)
	print("playAnimation", szFunc, ... )

	local KBattleUIHelper   = require("battle/KBattleUIHelper")
	KBattleUIHelper.playAnimation(szFunc, tBattleData, tBattleUI,  ...)
end

function KSkillBase:playSkillAnimation(szFunc, tBattleData, tBattleUI, ...)
    print("playSkillAnimation", szFunc, tBattleData, tBattleUI, ...)
    local isLeft            = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName

    local KBattleSkillAnimation = require("battle/KBattleSkillAnimation")
    KBattleSkillAnimation.playAnimation(szFunc, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, ...)
end

function KSkillBase:calcDamage(tSrcCard, tDstCard, nEquipPos, ...)
    return self.tCalc:calcSkillDamage(self.tSkillConfig, tSrcCard, tDstCard, nEquipPos, ...)
end

function KSkillBase:changeSkillButtonState(nState)
    local nPosition  = self.nSkillPosition
    local tSkillList = self.tBattleData:getLeftTeamSkillList()
    local tOneSkill  = tSkillList[nPosition]

    if tOneSkill.nState >= nState then return end
    tOneSkill.nState = nState

    if nState == SKILL_STATE.READY then
        self.tBattleUI:readySkillButtonUI(nPosition)
    elseif nState == SKILL_STATE.BUFF then
        self.tBattleUI:buffSkillButtonUI(nPosition, nil)
    elseif nState == SKILL_STATE.END then
        self.tBattleUI:unabledSkillButtonUI(nPosition)
    end
end

function KSkillBase:changeSkillButtonStateInStepType(nBattleStep, nNewState)
    local stateInfo = {stepType=nBattleStep, skillPosition=self.nSkillPosition, state=nNewState}

    local tBattleData = self.tBattleData
    table.insert(tBattleData.tSkillChangeStateList, stateInfo)
end

function KSkillBase:changeSkillButtonStateInStepIndex(nBattleIndex, nNewState)
    local stateInfo = {stepIndex=nBattleIndex, skillPosition=self.nSkillPosition, state=nNewState}

    local tBattleData = self.tBattleData
    table.insert(tBattleData.tSkillChangeStateListIndex, stateInfo)
end

return KSkillBase
