--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillBunkerLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local UI_INTERVAL = 4.34  -- ui need
local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillBunkerLogic = class( "KSkillBunkerLogic", KSkillBase )

function KSkillBunkerLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nPierceEffectRate = tSkillConfig.nParam1
    self.nEquipTemplateID  = nEquipTemplateID
end

function KSkillBunkerLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return true
end

function KSkillBunkerLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.BUFF)
        self:changeSkillButtonStateInStepIndex(self.tBattleData.nCurrentStepIndex + 1, SKILL_STATE.END)
    end

    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper   = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    
    for _, tCard in ipairs(self.tSrcTeam) do
        self.tBattleData:addExtraProperty(tCard, self.tBattleData.nCurrentStep, CARD_EXTRA_PROPERTY.PIERCE_EFFECT_RATE, self.nPierceEffectRate)
    end

    local tTaskIDList = {}
    local nID = self:asyncExec(self.playSkillAnimation, self, "playSkillBunkerAnimation", self.tBattleData, self.tBattleUI)
    table.insert(tTaskIDList, nID)

    KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
    for _, tCard in ipairs(self.tSrcTeam)do
        local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillBunkerbuildBlinkAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tCard)
        table.insert(tTaskIDList, nID)
    end

    self:waitAsync(tTaskIDList)
end

function KSkillBunkerLogic:changeSkillButtonState(nState)
    local nPosition  = self.nSkillPosition
    local tSkillList = self.tBattleData:getLeftTeamSkillList()
    local tOneSkill  = tSkillList[nPosition]

    if tOneSkill.nState >= nState then return end
    tOneSkill.nState   = nState
    
    if nState == SKILL_STATE.READY then
        self.tBattleUI:readySkillButtonUI(nPosition)
    elseif nState == SKILL_STATE.BUFF then
        self.tBattleUI:buffSkillButtonUI(nPosition, "ricochet")
    elseif nState == SKILL_STATE.END then
        self.tBattleUI:unabledSkillButtonUI(nPosition)
    end
end

return KSkillBunkerLogic
