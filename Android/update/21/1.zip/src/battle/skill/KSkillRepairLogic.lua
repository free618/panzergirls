--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillRepairLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillRepairLogic = class( "KSkillRepairLogic", KSkillBase )

function KSkillRepairLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nSteel       = tSkillConfig.nParam1
    self.nPeople      = tSkillConfig.nParam2
    self.nEquipTemplateID = nEquipTemplateID
end

function KSkillRepairLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return tSrcTeam == tBattleData.tSrcTeam
end

function KSkillRepairLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.END)
    end

    local tRepairCard
    local nRepairHPRate
    local nRepairHP
    for _, tCard in ipairs(self.tSrcTeam) do
        if tCard.nCurrentHP > 0 then
            nHPRate = tCard.nCurrentHP / tCard.nMaxHP
            if not tRepairCard or nRepairHPRate > nHPRate then
                tRepairCard   = tCard
                nRepairHPRate = nHPRate
            end
        end
    end

    if not tRepairCard then return end

    print("[修理前]：", tRepairCard.nIndex, tRepairCard.nCurrentHP)
    if tRepairCard.bLeftSide then
        local nRepairCostPeople = tRepairCard.nMaxOil * 0.2 * 0.35
        local nRepairCostSteel  = tRepairCard.nMaxOil * 0.2 * 0.25
        local nRepairHP1 = self.nSteel / nRepairCostSteel
        local nRepairHP2 = self.nPeople / nRepairCostPeople
        nRepairHP  = math.min(nRepairHP1, nRepairHP2)
        nRepairHP  = math.ceil(nRepairHP)

        tRepairCard.nCurrentHP = tRepairCard.nCurrentHP + nRepairHP
        if tRepairCard.nCurrentHP > tRepairCard.nMaxHP then
            tRepairCard.nCurrentHP = tRepairCard.nMaxHP
        end

        require("src/network/KC2SProtocolManager"):RepairCardInBattle(tRepairCard.nID, tRepairCard.nCurrentHP)
    end
    print("[修理后]：", tRepairCard.nIndex, tRepairCard.nCurrentHP)

    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper       = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    local tTaskIDList = {}
    
    KBattleSkillAnimation.playAnimation("playSkillRepairAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig)
    table.insert(tTaskIDList, nID)

    local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillRepairAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tRepairCard, nRepairHP, nRepairHPRate)
    table.insert(tTaskIDList, nID)

    self:waitAsync(tTaskIDList)
end

return KSkillRepairLogic
