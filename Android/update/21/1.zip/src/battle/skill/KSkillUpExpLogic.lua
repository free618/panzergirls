--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillUpExpLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local UI_INTERVAL = 2.5  -- ui need
local KSkillBase  = require("src/battle/skill/KSkillBase")
local KSkillUpExpLogic = class( "KSkillUpExpLogic", KSkillBase )

function KSkillUpExpLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nExpMuti     		= tSkillConfig.nParam1
    self.nEquipTemplateID 	= nEquipTemplateID
end

function KSkillUpExpLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return tSrcTeam == tBattleData.tSrcTeam
end

function KSkillUpExpLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.BUFF)
    end

    self.tBattleData.nExpMuti = self.nExpMuti
    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper       = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    local tTaskIDList = {}
    local nID = self:asyncExec(self.playSkillAnimation, self, "playSkillUpExpAnimation", self.tBattleData, self.tBattleUI, self.nExpMuti)
    table.insert(tTaskIDList, nID)
    
    KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
    for _, tCard in ipairs(self.tSrcTeam)do
        local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillExperienceBlinkAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tCard)
        table.insert(tTaskIDList, nID)
    end

    self:waitAsync(tTaskIDList)
end

function KSkillUpExpLogic:changeSkillButtonState(nState)
    local nPosition  = self.nSkillPosition
    local tSkillList = self.tBattleData:getLeftTeamSkillList()
    local tOneSkill  = tSkillList[nPosition]

    if tOneSkill.nState >= nState then return end
    tOneSkill.nState = nState
    
    if nState == SKILL_STATE.READY then
        self.tBattleUI:readySkillButtonUI(nPosition)
    elseif nState == SKILL_STATE.BUFF then
        self.tBattleUI:buffSkillButtonUI(nPosition, "exp")
    elseif nState == SKILL_STATE.END then
        self.tBattleUI:unabledSkillButtonUI(nPosition)
    end
end

return KSkillUpExpLogic
