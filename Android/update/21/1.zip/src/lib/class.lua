 
tbClassUsedMetatable = tbClassUsedMetatable or {}

SHObj = SHObj or {}
SHObj.New = function() return true end
SHObj.Delete 	= SHObj.New
SHObj.Init 		= SHObj.New
SHObj.UnInit 	= SHObj.New

function Extend(BaseClass)
	local NewClass = {}
	BaseClass = BaseClass or SHObj
	local tbMetatable = tbClassUsedMetatable[BaseClass]
	
	if not tbMetatable then
		tbMetatable = {__index = BaseClass}
		tbClassUsedMetatable[BaseClass] = tbMetatable
	end

	NewClass.base = BaseClass
	setmetatable(NewClass, tbMetatable)
		
	return NewClass
end

function New(tbClass, ...)
	local Obj = {}
	
	assert(tbClass, debug.traceback())
		
	local tbMetatable = tbClassUsedMetatable[tbClass]	
	if not tbMetatable then
		tbMetatable = {__index = tbClass}
		tbClassUsedMetatable[tbClass] = tbMetatable
	end
	
	setmetatable(Obj, tbMetatable)
		
	Obj:New(...)
	
	return Obj
end

function Delete(Obj)
	Obj:Delete()
end