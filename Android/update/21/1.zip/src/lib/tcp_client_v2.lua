------------------------------------------
----- FileName:SHTcpClient.lua
----- Creator: Han Ruofei
----- CreateTime: 2013/6/20
-------------------------------------------

require "lib.class"
require "lib.event_dispatcher"

SHTcpClient = SHTcpClient or Extend()

local m_tAllTcpClient = {}

function SHTcpClient:New(strName, strAddress, nPort)
	assert(strName)

	strAddress = strAddress  or ""
	nPort = nPort or 0

	self.strName = strName
	self.dwID = C_TcpClient.Create(strName, strAddress, nPort)

	assert(self.dwID ~= 0)

	self.nLastRecvTime = 0
	self.nLastSendTime = 0

	m_tAllTcpClient[self.dwID] = self
end

function SHTcpClient:Init()
	return true
end

function SHTcpClient:Activate(nCurrentTime)

end

function SHTcpClient:Connect()
	return C_TcpClient.ASyncConnect(self.dwID)
end

function SHTcpClient:Disconnect()
	return C_TcpClient.Disconnect(self.dwID)
end

function SHTcpClient:Destory()
	local dwID = self.dwID
	if dwID == 0 then
		return
	end

	self.dwID = 0
	m_tAllTcpClient[dwID] = nil
	C_TcpClient.Destory(dwID)
end

function SHTcpClient:DoSend(...)
	assert(self.dwID ~= 0)

	local bResult = C_TcpClient.Send(self.dwID, ...)
	assert(bResult)

	self.nLastSendTime = os.time()
	self:SendLog(...)
end

function SHTcpClient:SendLog( ... )
end

function SHTcpClient:SetTarget(szIP, nPort)
	local bResult = C_TcpClient.SetTargetAddress(self.dwID, szIP, nPort)
	assert(bResult)
end

function SHTcpClient:IsConnected()
	return C_TcpClient.IsConnected(self.dwID)
end

function SHTcpClient:OnConnectFailed()
	self.nLastRecvTime = 0
	self.nLastSendTime = 0
end

function SHTcpClient:OnConnectSuccess()

end

function SHTcpClient:OnRecvPackage(szFunc, ...)
	self.nLastRecvTime = os.time()
end

function SHTcpClient:OnDisconnected(nErrorCode)
	self.nLastRecvTime = 0
	self.nLastSendTime = 0
end

function SHOnTCPClientConnectFailed(nClientID)
	print("SHOnTCPClientConnectFailed", nClientID)
	local tTcpClient = m_tAllTcpClient[nClientID]
	tTcpClient:OnConnectFailed()
end

function SHOnTCPClientConnectSuccess(nClientID)
	print("SHOnTCPClientConnectSuccess", nClientID)

	local tTcpClient = m_tAllTcpClient[nClientID]
	tTcpClient:OnConnectSuccess()
end

function SHOnTCPClientPackageReceived(nClientID, ...)
	-- print("SHOnTCPClientPackageReceived", nClientID, ...)
	local tTcpClient = m_tAllTcpClient[nClientID]
	tTcpClient:OnRecvPackage(...)
end

function SHOnTCPClientDisconnected(nClientID, nErrorCode)
	print("SHOnTCPClientDisconnected", nClientID, nErrorCode)
	local tTcpClient = m_tAllTcpClient[nClientID]
	tTcpClient:OnDisconnected(nErrorCode)
end

function SHOnSDKAgentMessage(...)
    --cclog("Call Global Function -----> OnSDKAgentEvent~ begin")
    --for k, v in pairs(package.loaded) do
        --cclog("-----> package.loaded k:%s\nv:%s", k, tostring(v))
    --end
    local bResult, KSDKAgent = pcall(require,"src/logic/KSDKAgent")
    --cclog("-----> KSDKAgent = %s", tostring(KSDKAgent))
    KSDKAgent:dispatchMessage(...)
    --cclog("Call Global Function -----> OnSDKAgentEvent~ end")
end
