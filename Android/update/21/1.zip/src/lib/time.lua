
local SECONDS_PERMINUTE = 60
local SECONDS_PERHOUR = 3600
local SECONDS_PERDAY = 3600 * 24
local TIME_ZONE =8 * 60 * 60

function GetDayIndex(nTime)
    if not nTime then nTime = os.time() end
    return math.floor((nTime + TIME_ZONE) / SECONDS_PERDAY)
end

function GetDeltaDay(nTimeA, nTimeB)
    local nDayA = GetDayIndex(nTimeA)
    local nDayB = GetDayIndex(nTimeB)
    return nDayB - nDayA
end

function IsSameDay(nTimeA, nTimeB)
    return GetDeltaDay(nTimeA, nTimeB) == 0
end

function GetDayBeginTimeOffset(nTime, nDayOffset)
    local nDayIndex = GetDayIndex(nTime) + nDayOffset
    return nDayIndex * SECONDS_PERDAY - TIME_ZONE
end

function GetDayBeginTime(nTime)
    return GetDayBeginTimeOffset(nTime, 0)
end

function GetDayEndTime(nTime)
    return GetDayBeginTimeOffset(nTime, 1)
end

function GetTodayStartTime()
    local tCurrentTimeInfo  = os.date("*t")
    tCurrentTimeInfo.hour   = 0
    tCurrentTimeInfo.min    = 0
    tCurrentTimeInfo.sec    = 0

    return os.time(tCurrentTimeInfo)
end

-- hh:mm:ss -> s
-- 30 -> 30
-- 14:30 -> 870
-- 0:14:30 -> 870
-- 15:14:30 -> 54870
-- 128:14:30 -> 461670
function HMS2Time(szString)
    local tStrs = split(szString, ":")
    local nSec = 0
    local nLoop = 1
    for i = #tStrs, 1, -1 do
        local szVal = tStrs[i]
        local nVal = tonumber(szVal)
        if nLoop == 1 then
            nSec = nSec + nVal
        elseif nLoop == 2 then
            nSec = nSec + nVal * SECONDS_PERMINUTE
        elseif nLoop == 3 then
            nSec = nSec + nVal * SECONDS_PERHOUR
        else
            break
        end
        nLoop = nLoop + 1
    end
    return nSec
end

function DailyTimeToSecondsOffset(nDailyTime)

    local nHour = math.floor(nDailyTime / 100)
    local nMinute = nDailyTime % 100

    return nHour * SECONDS_PERHOUR + nMinute * SECONDS_PERMINUTE
end

function TimeToDayOffset(nTime)
    return (nTime + TIME_ZONE) % SECONDS_PERDAY
end

function IsInDailyTimeRange(nTime, nSecondsOffsetMin, nSecondsOffsetMax)
    local nSecondsOffset = TimeToDayOffset(nTime)

    if nSecondsOffset < nSecondsOffsetMin then
        return false
    end

    if nSecondsOffset >= nSecondsOffsetMax then
        return false
    end

    return true
end

function GetWesternWeekDay(nEasternWeekDay)
    assert(nEasternWeekDay >= 1 and nEasternWeekDay <= 7)
    return (nEasternWeekDay % 7) + 1
end

function GetWeeHourTime(nTime)
    assert(nTime)
    -- the base timestamp hour is TIME_HOUR * 8, you can print(var2str(os.date("*t", 0))) to see that.
    local BASE_HOUR_TIME = TIME_HOUR * 8
    if nTime < BASE_HOUR_TIME then
        Warn(INVALID_ID, "nTime=%d < BASE_HOUR_TIME", nTime)
        nTime = os.time()
    end
    return nTime - ((nTime + BASE_HOUR_TIME) % GAME_REFRESH_INTERVAL)
end

--[[
-- test GetWeeHourTime
local tTime = {year = 2009, month = 10, day = 25, hour = 7, min = 49, sec = 41}
local nTime =  os.time(tTime)
print("nTime = " .. nTime)
print("tTime = " .. os.date(nil, nTime))
local nWeeTime = GetWeeHourTime(nTime)
print("nWeeTime = " .. nWeeTime)
local tWeeTime = os.date(nil, nWeeTime)
print("tWeeTime = " .. var2str(tWeeTime))
--]]

function GetNextDayTime(nTime)
    assert(nTime)
    return GetWeeHourTime(nTime) + GAME_REFRESH_INTERVAL
end

function GetNextGameRefreshTime(nTime)
    assert(nTime)
    return GetNextDayTime(nTime) + DAILY_GAME_REFRESH_TIME
end

function GetNextDayMidNightTime() 
    local tTime = os.date("*t") 
    tTime.hour    = 0
    tTime.min     = 0 
    tTime.sec     = 0
    return os.time(tTime) + PRE_DAY_SECONDS
end


function GetWeekDay()
    local nCurrentTime = os.time()
    return str2n(os.date("%w", nCurrentTime)) 
end

function GetWeekDayChina()
    local nCurrentTime = os.time()
    local nWeek = str2n(os.date("%w", nCurrentTime)) 
    if nWeek == 0 then 
        nWeek = 7
    end
    return nWeek
end

KTime = {}

-- parse string "201505011200" means year:2015 month:05 day:01 hour:12 minute:00 to timestamp 
function KTime.Parse(szTime) 

    local _, _, szYear, szMonth, szDay, szHour, szMinute = string.find(szTime, "^(%d%d%d%d)(%d%d)(%d%d)(%d%d)(%d%d)")
    if not szYear then
        return
    end

    local tTime = 
    {
        year    = tonumber(szYear),
        month   = tonumber(szMonth),
        day     = tonumber(szDay),
        hour    = tonumber(szHour),
        min     = tonumber(szMinute),
    }

    return os.time(tTime)
end
