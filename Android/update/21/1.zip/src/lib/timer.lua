
SHTimer =  SHTimer or Extend()

function SHTimer:New()
	self.tbTimers = {}
end

function SHTimer:Delete()
	for k, v in pairs(self.tbTimers) do
		self.tbTimers[k] = nil
	end
end

function SHTimer:Register(o)
	self.tbTimers[o] = 0
end

function SHTimer:UnRegister(o)
	self.tbTimers[o] = nil
end

function SHTimer:Activate()	
	for o, f in pairs(self.tbTimers) do
		o:OnTimer(f)
		self.tbTimers[o] = f + 1
	end	
end



