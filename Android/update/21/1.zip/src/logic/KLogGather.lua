--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSetting.lua
--  Creator     : liulingli
--  Date        : 2016/1/7   16:58
--  Contact     : liulingli@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KLogGather    = {}
KLogGather.tLogList = {}

function KLogGather.addLog(szLogType, ...)
    local tGlobalStatus = GlobalStatus
    local str = tostring(tGlobalStatus.nServerTime) .. " "
    for _, v in ipairs({...}) do
        str = str .. tostring(v) .. "  "
    end
    if not KLogGather.tLogList[szLogType] then
        KLogGather.tLogList[szLogType] = ""
    end
    KLogGather.tLogList[szLogType] = KLogGather.tLogList[szLogType] .. str .. "\n"
end

function KLogGather.deleteLog(szLogType, szSplits)
    if not szSplits then
        KLogGather.tLogList[szLogType] = ""
        return
    end

    local nPos
    local nFindPos = 1
    while true do
        local nBegin, nEnd = string.find(KLogGather.tLogList[szLogType], szSplits, nFindPos, true)
        if nBegin then 
            nPos     = nBegin 
            nFindPos = nEnd + 1
        else
            break
        end
    end 
    if nPos then
        KLogGather.tLogList[szLogType] = string.sub(KLogGather.tLogList[szLogType], nPos, -1)
    else
        KLogGather.tLogList[szLogType] = ""
    end
end

function KLogGather.sendLog(szLogType)
    if KLogGather.tLogList[szLogType] then
        sendInfoGatherServer(szLogType .. ":\n" .. KLogGather.tLogList[szLogType])
    end
end

return KLogGather
