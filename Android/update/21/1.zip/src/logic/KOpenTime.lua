--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KOpenTime.lua
--  Creator     : LiuLingLi
--  Date        : 2015/09/21   19:00
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************

KUtil = KUtil or {}

local function StringToTime(szTime, tOpenDate)
    local tTimeKey = {"year", "month", "day", "hour", "min", "sec"}
    local tDate = {}
    if tOpenDate then
        for key, value in pairs(tOpenDate) do
            tDate[key] = value
        end
    end
    local _, count = string.gsub(szTime, "-", "-")
    local nIndex = (count > 0) and 1 or 4
    for nOne in string.gmatch(szTime, "%d+") do
        tDate[tTimeKey[nIndex]] = nOne
        nIndex = nIndex + 1
    end

    local nTime = os.time(tDate)
    return nTime
end

-- {beginTime = '18:0:0', duration = 2*60, weekDay = 7}, openTime = '2015-9-26 0:0:0', closeTime = '2015-10-7 0:0:0'
function KUtil.openTimeProcessing(szOpenTime)
    local tOpenTimes
    if szOpenTime and string.len(szOpenTime) > 0 then
        tOpenTimes = {}
        if szOpenTime == "dayCycle" then
            szOpenTime = "{beginTime = '0:0:0', duration = 24*60}"
        elseif szOpenTime == "weekCycle" then
            szOpenTime = "{beginTime = '0:0:0', duration = 7*24*60, intervalTime = 7*24*60}"
        end

        tOpenTimes = loadstring("return {"..szOpenTime.."}")()

        if tOpenTimes.openTime then
            tOpenTimes.nOpenTime = StringToTime(tOpenTimes.openTime)
            tOpenTimes.openTime  = nil
        else
            tOpenTimes.nOpenTime = StringToTime('1990-1-1 0:0:0')
        end

        local tOpenDate = os.date("*t", tOpenTimes.nOpenTime)

        local nMaxEndTime = 0
        for _, tOneOpenTime in ipairs(tOpenTimes) do
            if tOneOpenTime.beginTime then
                tOneOpenTime.nBeginTime = StringToTime(tOneOpenTime.beginTime, tOpenDate)
                tOneOpenTime.beginTime  = nil
            end
            print(os.date("%c", tOneOpenTime.nBeginTime), os.date("%c", tOpenTimes.nOpenTime))
            if tOneOpenTime.weekDay then
                local tDate = os.date("*t", tOneOpenTime.nBeginTime)
                local wday = tDate.wday-1
                if wday == 0 then
                    wday = 7
                end
                local addDay = tOneOpenTime.weekDay - wday
                if addDay < 0 then
                    addDay = 7 + addDay
                end
                tOneOpenTime.nBeginTime = tOneOpenTime.nBeginTime + addDay * 24 * 60 * 60

                tOneOpenTime.intervalTime  = 7 * 24 * 60
                tOneOpenTime.weekDay       = nil
            end
            if not tOneOpenTime.intervalTime then
                tOneOpenTime.intervalTime  = 24 *60
            end
            tOneOpenTime.nIntervalTime  = tOneOpenTime.intervalTime * 60
            tOneOpenTime.intervalTime   = nil

            assert(tOneOpenTime.nBeginTime >= tOpenTimes.nOpenTime)

            assert(tOneOpenTime.duration > 0)
            tOneOpenTime.nDuration      = tOneOpenTime.duration * 60
            tOneOpenTime.duration      = nil
            assert(tOneOpenTime.nIntervalTime >= tOneOpenTime.nDuration)

            local nEndTime = tOneOpenTime.nBeginTime + tOneOpenTime.nIntervalTime
            if nMaxEndTime < nEndTime then
                nMaxEndTime = nEndTime
            end
        end 

        if tOpenTimes.closeTime then
            tOpenTimes.nCloseTime = StringToTime(tOpenTimes.closeTime)
            tOpenTimes.closeTime  = nil
            if nMaxEndTime then
                assert(tOpenTimes.nCloseTime >= nMaxEndTime)
            end
        end
    end
    return tOpenTimes
end

local function GetBeginAndEndTime(nTime, tOneOpenTime, nCloseTime)
    local bOpen, nBeginTime, nEndTime
    if not nCloseTime or nTime < nCloseTime then
        nBeginTime = tOneOpenTime.nBeginTime 
        nEndTime   = tOneOpenTime.nBeginTime + tOneOpenTime.nDuration
        if tOneOpenTime.nBeginTime <= nTime then
            local nCycleCount   = math.floor((nTime - tOneOpenTime.nBeginTime) / tOneOpenTime.nIntervalTime)
            nBeginTime          = tOneOpenTime.nBeginTime + nCycleCount * tOneOpenTime.nIntervalTime
            nEndTime            = nBeginTime + tOneOpenTime.nDuration
            if nTime < nEndTime then
                bOpen = true
            else 
                nBeginTime     = nBeginTime + tOneOpenTime.nIntervalTime
                if nCloseTime and nBeginTime >= nCloseTime then
                    nBeginTime = nil
                    nEndTime   = nil
                else
                    nEndTime   = nBeginTime + tOneOpenTime.nDuration
                end
            end
        end
        if nCloseTime and nEndTime > nCloseTime then
            nEndTime = nCloseTime
        end
    end
    return bOpen, nBeginTime, nEndTime
end

function KUtil.isOpeningTime(nTime, tOpenTimes)
    if not tOpenTimes then return true  end
    if tOpenTimes.nCloseTime and nTime >= tOpenTimes.nCloseTime then return false end
    
    local bOpen, nNextBeginTime, nNextEndTime = false
    if #tOpenTimes == 0 then
        bOpen, nNextBeginTime, nNextEndTime = false, tOpenTimes.nOpenTime, tOpenTimes.nCloseTime
        if (not tOpenTimes.nOpenTime or nTime >= tOpenTimes.nOpenTime) then
            bOpen = true
        end
        return bOpen, nNextBeginTime, nNextEndTime
    end

    for _, tOneOpenTime in ipairs(tOpenTimes) do
        local bOpen, nCurBeginTime, nCurEndTime = GetBeginAndEndTime(nTime, tOneOpenTime, tOpenTimes.nCloseTime)
        if bOpen then
            return bOpen, nCurBeginTime, nCurEndTime
        elseif nCurBeginTime and (not nNextBeginTime or nNextBeginTime > nCurBeginTime) then
            nNextBeginTime = nCurBeginTime
            nNextEndTime   = nCurEndTime
        end
    end

    return bOpen, nNextBeginTime, nNextEndTime
end

function KUtil.isInOpenTime(szOpenTime)
    local tOpenTimes = KUtil.openTimeProcessing(szOpenTime)
    return KUtil.isOpeningTime(GlobalStatus.nServerTime, tOpenTimes)
end 

function string.split(input, delimiter)
    input = tostring(input)
    delimiter = tostring(delimiter)
    if (delimiter=='') then return false end
    local pos,arr = 0, {}
    -- for each divider found
    for st,sp in function() return string.find(input, delimiter, pos, true) end do
        table.insert(arr, string.sub(input, pos, st - 1))
        pos = sp + 1
    end
    table.insert(arr, string.sub(input, pos))
    return arr
end

local function getTimeByFormat(szTime, nTime)
    local tab = os.date("*t")
    local strs = string.split(szTime, "%")
    for i = #strs, 1, -1 do
        if strs[i] == "Y" then
            tab.year    = nTime % 10000
            nTime       = math.floor(nTime / 10000)
        elseif strs[i] == "m" then
            tab.month   = nTime % 100
            nTime       = math.floor(nTime / 100)
        elseif strs[i] == "d" then
            tab.day     = nTime % 100
            nTime       = math.floor(nTime / 100)
        elseif strs[i] == "H" then
            tab.hour    = nTime % 100
            nTime       = math.floor(nTime / 100)
        elseif strs[i] == "M" then
            tab.min     = nTime % 100
            nTime       = math.floor(nTime / 100)
        elseif strs[i] == "S" then
            tab.sec     = nTime % 100
            nTime       = math.floor(nTime / 100)
        end
    end

    return os.time(tab)
end

function KUtil.isSysOpened(szSysName, button)
    local sys = KConfig.sysopen[szSysName]
    if sys then
        local nNowTime = tonumber(os.date(sys.szTime, KUtil.getLocalTime()))
        if nNowTime < sys.nStartTime then
            if button then
                if sys.nShowType == 2 then
                    KUtil.setTouchEnabled(button, false)

                    delayExecute(button, function()
                        KUtil.setTouchEnabled(button, true)
                    end, getTimeByFormat(sys.szTime, sys.nStartTime) - KUtil.getLocalTime())
                end
            end

            return false
        end

        local nEndTime = sys.nEndTime
        if nEndTime > 0 then
            if nNowTime >= nEndTime  then
                if button then
                    if sys.nShowType == 2 then
                        KUtil.setTouchEnabled(button, false)
                    end
                end
            
                return false
            else
                if button and sys.nShowType == 2 then
                    delayExecute(button, function()
                        KUtil.setTouchEnabled(button, false)
                    end, getTimeByFormat(sys.szTime, sys.nEndTime) - KUtil.getLocalTime())
                end
            end
        end
    end

    return true
end

function KUtil.onSysOpenClick(szSysName)
    if not KUtil.isSysOpened(szSysName) then
        local sys = KConfig.sysopen[szSysName]
        if sys then
            if sys.nShowType == 1 then
                local stringConfig = KConfig:getLine("string", sys.szShowID) or {}
                local szType = stringConfig.szType or ""
                showNotice(stringConfig.szText, szType)
            end
        end

        return false
    end

    return true
end

function KUtil.addTouchEventWithSysOpen(button, callBack, szSysName)
    KUtil.isSysOpened(szSysName, button)
    button:addTouchEventListener(function(sender, type)
        if type == ccui.TouchEventType.ended then
            if not KUtil.onSysOpenClick(szSysName) then
                return
            end
        end

        callBack(sender, type)
    end)
end