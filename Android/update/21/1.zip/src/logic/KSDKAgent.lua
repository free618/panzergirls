--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSDKAgent.lua
--  Creator     : SunXun
--  Date        : 2015/09/22   17:34
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KSDKAgent = {}

function KSDKAgent:init()
end

function KSDKAgent:unInit()
end

function KSDKAgent:onPayResult(result, identifier, quantity, receipt)
    cclog("-----> Lua SDKAgent:onPayResult ~ \nresult:%d \nidentifier:%s \nquantity:%d \nreceipt:%s", result, identifier, quantity, receipt)

    -- 1.Save the receipt
    local KSetting  = require("src/logic/KSetting")
    local roleId    = KPlayer.id

    for index = 1, 100 do -- we had reason enough for believe 100 is most limit.
        local payRoleIDKey  = KSetting.Key.PAY_ROLE_ID_KEY_INDEX .. "_" .. index
        local payReceiptKey = KSetting.Key.PAY_RECEIPT_KEY_INDEX .. "_" .. index

        roleIdInfo  = KSetting.getInt(payRoleIDKey, 0)
        rolePayInfo = KSetting.getString(payReceiptKey, "")
        cclog("-----> %s - %d \n%s - %s", payRoleIDKey, roleIdInfo, payReceiptKey, rolePayInfo)
        if roleIdInfo == 0 then
            KSetting.setInt(payRoleIDKey, roleId)
            KSetting.setString(payReceiptKey, receipt)
            cclog("-----> Save Receipt Success for ----->\n<%s : %d>\n<%s : %s>", payRoleIDKey, roleId, payReceiptKey, receipt)
            break
        end
    end
    
    -- 2.Notify server check the receipt;
    require("src/network/KC2SProtocolManager"):IOSPayVerify(receipt)
    --KPlayer:IOSPayVerifyRet(receipt, "0")
end

function KSDKAgent:onUpdateSinglePayInfo(productIdentifier, localizedTitle, localizedPrice, isValid, index)
    cclog(
        "-----> Lua SDKAgent:onUpdateSinglePayInfo ~ \nproductIdentifier:%s \nlocalizedTitle:%s \nlocalizedPrice:%s \nisValid:%d \nindex:%d",
        productIdentifier, localizedTitle, localizedPrice, isValid, index
    )

    local tSinglePayInfo = {
        ["productIdentifier"] = productIdentifier, 
        ["localizedTitle"] = localizedTitle, 
        ["localizedPrice"] = localizedPrice, 
        ["isValid"] = isValid, 
        ["index"] = index
    }

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()

    if not KPlayer.tPayInfo then
        KPlayer.tPayInfo = {}
    end
    if not KPlayer.tPayInfo[targetPlatform] then
        KPlayer.tPayInfo[targetPlatform] = {}
    end
    table.insert(KPlayer.tPayInfo[targetPlatform], tSinglePayInfo)
end

function KSDKAgent:dispatchMessage(messageType, ...)
    cclog("----------> Lua KSDKAgent:dispatchMessage() messageType:%s", messageType)
    
    local funcMessage = self[messageType]
    if not funcMessage then
        cclog("-----> can't find message function for type:%s", messageType)
        return
    end
    
    funcMessage(self, ...)
end

function KSDKAgent:getRoleInfo()
    cclog("----------> Lua SDKAgent:getRoleInfo~")

    local tRoleInfo = {}

    tRoleInfo.uid           = KPlayer.uid
    tRoleInfo.roleId        = KPlayer.id
    tRoleInfo.roleName      = KPlayer.name
    tRoleInfo.roleType      = 0
    tRoleInfo.roleLevel     = KPlayer.level
    tRoleInfo.roleVipLevel  = 0
    tRoleInfo.serverId      = cc.UserDefault:getInstance():getIntegerForKey("serverID")
    tRoleInfo.zoneId        = "1"
    tRoleInfo.serverName    = cc.UserDefault:getInstance():getStringForKey("serverName")
    tRoleInfo.zoneName      = "XiaoMi"
    tRoleInfo.partyName     = "NULL"
    tRoleInfo.gender        = "Man"

    return tRoleInfo
end

function KSDKAgent:requestPay(nGoodsID)
    cclog("----------> Lua SDKAgent:requestPay~ nGoodsID:%d", nGoodsID)

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform == cc.PLATFORM_OS_ANDROID  then
        return AppBilling.BuyGoods(nGoodsID)
    end

    local config = KConfig.shop[nGoodsID]
    if not config then 
        cclog("-----> Get Shop Config Failed~")
        return 
    end
    local number   = config.nItemCount
    local price    = config.nPrice
    local itemName = config.szName
    local tRoleInfo     = self:getRoleInfo()

    cclog("-----> tRoleInfo.uid = %s , %s, %s", tostring(tRoleInfo.uid), tostring(KPlayer.uid), tostring(KPlayer.id))
    local tPayInfo = {
        ["uid"]                     = KPlayer.id,
        ["productPrice"]            = price,
    }
    for k, v in pairs(tPayInfo) do
        cclog("-----> tPayInfo %s : %s\n", k, v)
    end
    C_SDKAgent.Pay(tPayInfo)
end

function KSDKAgent:applyPayInfo()
    cclog("----------> Lua SDKAgent:applyPayInfo~")

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform == cc.PLATFORM_OS_ANDROID  then
        cclog("-----> Android is not work now~")
        return nil
    end

    C_SDKAgent.ApplyPayInfo()
end

return KSDKAgent
