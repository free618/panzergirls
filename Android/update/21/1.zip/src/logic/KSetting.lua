--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSetting.lua
--  Creator     : lvsongxin
--  Date        : 2015/10/12   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KSetting = {}
KSetting.Key =
{
    MUSIC_VOLUME                   = "musicVolume",
    EFFECT_VOLUME                  = "effectVolume",
    DEAD_COUND                     = "deadCount",
    SERVERID                       = "serverID",
    ACCEPT_AGREEMENT               = "isAcceptAgreement",
    ACCOUNT                        = "account",
    PASSWORD                       = "password",
    SERVERNAME                     = "serverName",
    ROLE_ID                        = "roleID",
    TOKEN                          = "token",
    ROLE_NAME                      = "roleName",
    ROLE_LEVEL                     = "roleLevel",
    COIN_COUNT                     = "coinCount",
    PIXEL_QUALITY                  = "pixelQuality",
    LAST_SHOW_TIME                 = "lastShowTime",
    TODAY_SHOW_TIMES               = "todayShowTimes",
    ANNOUNCE_VERSION               = "announceVersion",
    ANNOUNCE_INFO                  = "announceInfo",
    LAST_LAUNCH_ZONE_INDEX         = "LastLaunchZoneIndex",
    LAST_LAUNCH_TEAM_INDEX         = "LastLaunchTeamIndex",
    LAST_LAUNCH_PLAYER_ID          = "LastLaunchPlayerId",
    VERSION                        = "srcversion",
    LOAD_FINISH_VERSION            = "loadFinishVersion",
    TALK_VERSION                   = "talkVersion",
    SERVER_VERSION                 = "srcServerVersion",
    LOAD_TALK                      = "isLoadTalk",
    RAIDERS_PAGE                   = "raidersPage",
    RAIDERS_INDEX                  = "raidersIndex",
    SHOW_USER_PROTOCOL             = "isShowUserProtocol",
    TEAM_CHOOSE_TYPE               = "teamChooseType",
    COMMON_CHOOSE_TYPE             = "commonChooseType",
    BREAK_TEAM_CHOOSE_TYPE         = "breakTeamChooseType",
    BREAK_COMMON_CHOOSE_TYPE       = "breakCommonChooseType",
    EQUIP_CHANGE_CHOOSE_COMMON     = "equipChangeChooseCommon",
    EQUIP_BREAK_CHOOSE_COMMON      = "equipBreakChooseCommon",
    MEDAL_USE_INFO                 = "medalUseInfo",
    SECRETARY_TEAM_CHOOSE_TYPE     = "secretaryTeamChooseType",
    SECRETARY_COMMON_CHOOSE_TYPE   = "secretaryCommonChooseType",
    PAY_ROLE_ID_KEY_INDEX          = "payRoleIDKeyIndex",
    PAY_RECEIPT_KEY_INDEX          = "payReceiptKeyIndex",
}

function KSetting.setString(key, value)
    cc.UserDefault:getInstance():setStringForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KSetting.getString(key, default)
    return cc.UserDefault:getInstance():getStringForKey(key, default)
end

function KSetting.setDouble(key, value)
    cc.UserDefault:getInstance():setDoubleForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KSetting.getDouble(key, default)
    return cc.UserDefault:getInstance():getDoubleForKey(key)
end

function KSetting.setInt(key, value)
    cc.UserDefault:getInstance():setIntegerForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KSetting.getInt(key, default)
    local _default = default or 0
    return cc.UserDefault:getInstance():getIntegerForKey(key, _default)
end

function KSetting.setFloat(key, value)
    cc.UserDefault:getInstance():setFloatForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KSetting.getFloat(key, default)
    local _default = default or 0
    return cc.UserDefault:getInstance():getFloatForKey(key, _default)
end

function KSetting.setBool(key, value)
    cc.UserDefault:getInstance():setBoolForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KSetting.getBool(key, default)
    local _default = default or false
    return cc.UserDefault:getInstance():getBoolForKey(key, _default)
end

return KSetting

