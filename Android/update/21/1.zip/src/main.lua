--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : main.lua
--  Creator     : SunXun
--  Date        : 2015/07/10   10:38
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


-- CC_USE_DEPRECATED_API = true
require "cocos.init"
require "src/base/KGlobalFunction"
require "src/base/json_helper"

math.randomseed(os.time())

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
	cclog("----------------------------------------")
	cclog("LUA ERROR: " .. tostring(msg) .. "\n")
	local stackInfo = getStackInfo(3)
	cclog("---------------------------------------")

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform == cc.PLATFORM_OS_WINDOWS or
        targetPlatform == cc.PLATFORM_OS_LINUX or
        targetPlatform == cc.PLATFORM_OS_MAC or 
        (KUtil and KUtil.isGuide()) then
        tryShowError(msg, stackInfo)
    end

    -- send error msg to server
    sendErrorMsg(msg, stackInfo)
    return msg
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    local director = cc.Director:getInstance()
    cc.Device:setKeepScreenOn(true)
    director:setDisplayStats(false)
    director:setAnimationInterval(1.0 / 60)
    cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(1280, 720, cc.ResolutionPolicy.EXACT_FIT)

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform == cc.PLATFORM_OS_ANDROID then
        local obbDownloader = require("src/ui/login/obbdownloader")
        obbDownloader:downloadObb()
	require "src/base/google_pay"
        return
    end

    local isAutoUpdate = false -- auto update flag
    if targetPlatform ~= cc.PLATFORM_OS_WINDOWS and 
    	targetPlatform ~= cc.PLATFORM_OS_LINUX and
	targetPlatform ~= cc.PLATFORM_OS_MAC then
	isAutoUpdate = true -- close auto updte for Full Client
    end 

    isAutoUpdate = true
    if not isAutoUpdate then
        local gameScene = require("src/ui/login/KUILoginScene").create()
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(gameScene)
        else
            cc.Director:getInstance():runWithScene(gameScene)
        end
    else
        require("src/ui/login/KUILoginUpdateNode")
        addUpdateScene()
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end

