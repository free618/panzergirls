--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KGameServer.lua
--  Creator     : SunXun
--  Date        : 2015/07/10   11:29
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


if C_TcpClient.SetTargetAddress ~= nil then
    return require "src/network/KGameServer_v2"
end

KGameServer = KGameServer or {}

local STATE_LS_CONNECTED = 1
local STATE_LS_VERIFYING = 2
local STATE_LS_VERIFIED = 3
local STATE_LS_REQUESTING_SERVERLIST = 4
local STATE_LS_WAIT_ACTIVATE = 5
local STATE_LS_ACTIVATEING = 6
local STATE_LS_SERVERLIST_READY = 7
local STATE_LS_REQUESTING_ENTERSERVER = 8
local STATE_LS_END = 9
local STATE_BS_CONNECTED = 10
local STATE_BS_VERIFYING = 11
local STATE_BS_VERIFIED = 12
local STATE_BS_PLALYING = 13

local BEGIN_SHOW_SENDING_UI_SECONDS = 2
local RE_REQUEST_INTERVAL = 2
local MAX_RE_REQUEST_SECONDS = 10

local m_nState = STATE_INVALID
local m_bFullLoginOnce = false
local m_szAccount, m_szPassword, m_nServerID, m_tServerList

local m_nLSLastRequestTime = 0
local MIN_REQUEST_INTERVAL = 3

local m_tLS2CLProcessor = {}
local m_tLSAgency       = New(SHTcpClient, "LSAgency")

local m_tBS2CLProcessor = {}
local m_tBSAgency       = New(SHTcpClient, "BSAgency")

local m_nRequestID      = 0
local m_nRespondID      = 0

local m_tSendingData    = nil
local m_tToSend2GS 		= {} 
local m_bReconnect      = false


local m_nLastFrameTime = 0

function m_tLSAgency:OnRecvPackage(szFunc, ...)
    print("LS2CL, fnProcessor, ", szFunc, ...)

    local fnProcessor       = m_tLS2CLProcessor[szFunc]
    if not fnProcessor then
        print("LS2CL, not fnProcessor, ", szFunc, ...)
        return
    end

    fnProcessor(m_tLS2CLProcessor, ...)
end

function m_tLSAgency:OnClientDisconnectCB()
    m_nState = STATE_INVALID
end

function m_tLS2CLProcessor:HandshakeRespond()
end

function m_tLS2CLProcessor:RegisterAccountRet(nRetCode)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_REGISTER_RESULT, nRetCode)
    if nRetCode ~= REG_ACCOUNT_RET.SUCCESS then
        return
    end

    --KGameServer:Login()
end

function m_tLS2CLProcessor:LoginRet(nRetCode, nAccountID)
    assert(m_nState == STATE_LS_VERIFYING)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_LOGIN_RESULT, nRetCode, nAccountID)
    print("-----> LoginRet dispatch event NET_LOGIN_RESULT")

    if nRetCode == LOGIN_RET.SUCCESS then
        m_nState = STATE_LS_VERIFIED
        KGameServer:RequestServerList()
        return
    end
    if nRetCode == LOGIN_RET.NOT_ACTIVE then
        m_nState = STATE_LS_WAIT_ACTIVATE
        return
    end
    m_tLSAgency:Disconnect()
    m_nState = STATE_INVALID
end

function m_tLS2CLProcessor:ActivateAccountRet(nRetCode)
    if m_nState ~= STATE_LS_ACTIVATEING then
        print("ActivateAccountRet, m_nState ~= STATE_LS_ACTIVATE", m_nState, STATE_LS_ACTIVATEING)
        return
    end

    if nRetCode == ACTIVATE_RET.SUCCESS then
        m_nState = STATE_LS_VERIFIED
        KGameServer:RequestServerList()
    else
        m_nState = STATE_LS_WAIT_ACTIVATE
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ACTIVATE_RESULT, nRetCode)
end

function m_tLS2CLProcessor:ChangePasswordRet(nRetCode)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CHANGE_PASSWORD_RESULT, nRetCode)
    print("-----> ChangePasswordRet dispatch event NET_CHANGE_PASSWORD_RESULT")
    
    if nRetCode == CHANGE_PASSWORD_RET.SUCCESS then
        return
    end
end

function m_tLS2CLProcessor:SyncServerList(tServerList)
    assert(m_nState == STATE_LS_REQUESTING_SERVERLIST)

    m_tServerList = tServerList

    m_nState = STATE_LS_SERVERLIST_READY

    if m_bReconnect then
        local setting = require("src/logic/KSetting")
        m_nServerID   = setting.getInt(setting.Key.SERVERID)
        KGameServer:EnterServer()
        return
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SYNC_SERVER_LIST, tServerList)
end

function m_tLS2CLProcessor:EnterServerRet(nRetCode, nRoleID, szIP, nPort, szToken)
    assert(m_nState == STATE_LS_REQUESTING_ENTERSERVER)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ENTER_SERVER_RESULT, nRetCode)

    if nRetCode ~= ENTER_SERVER_RET.SUCCESS then
        m_nState = STATE_INVALID
        m_tLSAgency:Disconnect()
        return
    end

    m_nState = STATE_LS_END

    m_tLSAgency:Disconnect()
    if not m_tBSAgency:Connect(szIP, nPort) then
        m_nState = STATE_INVALID
        cclog("connect BS(%s:%d) failed!", szIP, nPort)
        return
    end

    cclog("connect BS(%s:%d) success!", szIP, nPort)

    m_nState = STATE_BS_CONNECTED
    if m_tSendingData then
        if m_tSendingData[4] ~= "HandshakeRequest" then
            table.insert(m_tToSend2GS, 1, {unpack(m_tSendingData, 2, table.maxn(m_tSendingData))})
        end
        m_tSendingData = nil
    end
    local nCurrentTime = os.time()
    local nRequestID = KGameServer:TakeNextRequestID()
    table.insert(m_tToSend2GS, 1, {nCurrentTime, nRequestID, "HandshakeRequest", nRoleID, szToken})
    KGameServer:TrySendNext()
    m_nState = STATE_BS_VERIFYING
end

function m_tBSAgency:OnRecvPackage(szFunc, ...)
    print("BS2CL ", szFunc)
    
    local fnProcessor  = m_tBS2CLProcessor[szFunc]
    if fnProcessor then
        fnProcessor(m_tBS2CLProcessor, ...)    
        return
    end

    local fnProcessor = KPlayer[szFunc]
    if fnProcessor then
        fnProcessor(KPlayer, ...)
        return
    end
    
    print("BS2CL Unknown Protocal: ", szFunc)
end

function m_tBSAgency:OnClientDisconnectCB()
    m_nState  = STATE_INVALID
end

function m_tBS2CLProcessor:HandshakeRespond()
    assert(m_nState == STATE_BS_VERIFYING)

    m_nState = STATE_BS_VERIFIED
end

function m_tBS2CLProcessor:Respond(nRequestID, tData)
    assert(m_tSendingData and m_tSendingData[3] == nRequestID)

    m_nRespondID = nRequestID
    m_tSendingData = nil

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.RESPOND, nRequestID)

    for _, v in ipairs(tData) do
        local szFuncName = v[1]
        -- print("Recv Respond Sub: ", unpack(v))

        local fnProcessor  = m_tBS2CLProcessor[szFuncName]
        if fnProcessor then
            xpcall(fnProcessor, __G__TRACKBACK__, m_tBS2CLProcessor, unpack(v, 2, table.maxn(v)))    
        else
            local fnProcessor = KPlayer[szFuncName]
            xpcall(fnProcessor, __G__TRACKBACK__, KPlayer, unpack(v, 2, table.maxn(v)))
        end
    end

	KGameServer:TrySendNext()
end

function m_tBS2CLProcessor:SyncDataEnd(...)
    assert(m_nState == STATE_BS_VERIFIED)
    m_nState = STATE_BS_PLALYING

    print("--------------- SyncDataEnd End")
    m_bFullLoginOnce = true
    KPlayer:SyncDataEnd(...)

    KGameServer:TrySendNext()
end

function KGameServer:Activate(nCurrentTime)
    local nLastFrameTime = m_nLastFrameTime
    m_nLastFrameTime = nCurrentTime

    if not m_bFullLoginOnce then return end

    if m_nState == STATE_INVALID then
        m_bReconnect = true
        KGameServer:Login()
    end

	if not m_tSendingData then
		return 
	end

    local nFirstSendTime = m_tSendingData[2]
    if nLastFrameTime <= nFirstSendTime + BEGIN_SHOW_SENDING_UI_SECONDS and nCurrentTime > nFirstSendTime + BEGIN_SHOW_SENDING_UI_SECONDS then
        print("----> show sending ui")
        local currentScene = cc.Director:getInstance():getRunningScene()
        local sendingNode = require("src/ui/common/KUISendingNode").create(currentScene, m_tSendingData[3])
        currentScene:addChild(sendingNode, 200) -- we must see this top 
    end 

    if nFirstSendTime + MAX_RE_REQUEST_SECONDS < nCurrentTime then
        print("----> ************** Send timeout!")
        local nRequestID = m_tSendingData[3]
        m_tSendingData = nil
        m_tToSend2GS = {}
        local eventDispatch = require("src/logic/KEventDispatchCenter")
        eventDispatch:dispatchEvent(eventDispatch.EventType.SENDING_TIME_OUT, nRequestID)
        return
    end

    if m_nState ~= STATE_BS_PLALYING then
        return
    end

    local nLastSendTime = m_tSendingData[1]
	if nLastSendTime + RE_REQUEST_INTERVAL > nCurrentTime then
		return
	end

	m_tSendingData[1] = nCurrentTime
    m_tBSAgency:Send(unpack(m_tSendingData, 3, table.maxn(m_tSendingData)))
end

function KGameServer:SetAccount(szAccount, szPassword)
    if not (m_nState == STATE_INVALID) then return end

    m_szAccount = szAccount
    m_szPassword = szPassword
end

local function ConnectToLS()
    if m_tLSAgency:IsConnected() then
        return true
    end

    local szIP, nPort = unpack(require("src/network/KServerAddress"))

    if not m_tLSAgency:Connect(szIP, nPort) then
        cclog("connect to LS(%s:%d) failed!", szIP, nPort)
        return false
    end
    
    cclog("connect to LS(%s:%d) success!", szIP, nPort)
    return m_tLSAgency:Send("HandshakeRequest")
end

function KGameServer:Register(szAccount, szPassword, szActivationCode)
    KGameServer:SetAccount(szAccount, szPassword)

    if not ConnectToLS() then
        return false
    end

    return  m_tLSAgency:Send("Register", m_szAccount, m_szPassword, szActivationCode)
end

function KGameServer:Login(szAccount, szPassword)
    KGameServer:SetAccount(szAccount, szPassword)

    if not (m_nState == STATE_INVALID or m_nState == STATE_LS_CONNECTED) then return end

    if GlobalStatus.nCurrentTime - m_nLSLastRequestTime < MIN_REQUEST_INTERVAL then
        return
    end

    m_nLSLastRequestTime = GlobalStatus.nCurrentTime

    if not ConnectToLS() then
        return false
    end

    m_nState = STATE_LS_CONNECTED

    if not m_tLSAgency:Send("Login", m_szAccount, m_szPassword) then
        return false
    end

    m_nState = STATE_LS_VERIFYING
end

function KGameServer:ChangePassword(szAccount, szOldPassword, szNewPassword)
    if not ConnectToLS() then
        return false
    end
    
    return m_tLSAgency:Send("ChangePassword", szAccount, szOldPassword, szNewPassword)
end

function KGameServer:ActivateAccount(szActivationCode)
    if m_nState ~= STATE_LS_WAIT_ACTIVATE then
        print("ActivateAccount, m_nState ~= STATE_LS_WAIT_ACTIVATE", m_nState, STATE_LS_WAIT_ACTIVATE)
        return
    end

    if not m_tLSAgency:Send("ActivateAccount", szActivationCode) then
        return
    end
    
    m_nState = STATE_LS_ACTIVATEING
    return true
end

function KGameServer:RequestServerList()
    assert(m_nState == STATE_LS_VERIFIED)

    if not m_tLSAgency:Send("RequestServerList") then
        return
    end

    m_nState = STATE_LS_REQUESTING_SERVERLIST
end

function KGameServer:SetServerID(nServerID)
    m_nServerID = nServerID
end

function KGameServer:EnterServer(nServerID)
    KGameServer:SetServerID(nServerID)

    if not (m_nState == STATE_LS_SERVERLIST_READY) then return end

    m_tLSAgency:Send("EnterServer", m_nServerID)

    m_nState = STATE_LS_REQUESTING_ENTERSERVER
end

function KGameServer:TakeNextRequestID()
    m_nRequestID = m_nRequestID + 1
    return m_nRequestID
end

function KGameServer:SendToGS(...)
    local nRequestID = KGameServer:TakeNextRequestID()

    local nCurrentTime  = os.time()
	table.insert(m_tToSend2GS, {nCurrentTime, nRequestID, ...})

    print("Try Send:", unpack(m_tToSend2GS[1], 1, table.maxn(m_tToSend2GS[1])))

	KGameServer:TrySendNext()

    return nRequestID
end

function KGameServer:TrySendNext()
	if m_tSendingData then
		return
	end

	if #m_tToSend2GS == 0 then
		return
	end

    if m_nState ~= STATE_BS_PLALYING then
       if  m_tToSend2GS[1][3] ~= "HandshakeRequest" then
            return
        end
    end

    local currentScene = cc.Director:getInstance():getRunningScene()
    if currentScene.__cname == "KUIBattleScene" then
        MAX_RE_REQUEST_SECONDS = 9999
    else
        MAX_RE_REQUEST_SECONDS = 10
    end

	local tNextRequest = table.remove(m_tToSend2GS, 1)
	local nLastSendTime = os.time()
	m_tSendingData = {nLastSendTime, unpack(tNextRequest, 1, table.maxn(tNextRequest))}
    print("Real Send:", unpack(m_tSendingData, 1, table.maxn(m_tSendingData)))
	m_tBSAgency:Send(unpack(m_tSendingData, 3, table.maxn(m_tSendingData)))
end

function KGameServer:GetRespondID()
    return m_nRespondID
end

function KGameServer:BeKicked()
    m_bFullLoginOnce = false
end

function KGameServer:Logout()
    m_tBSAgency:Disconnect()
    m_tLSAgency:Disconnect()
    m_bFullLoginOnce = false
    m_bReconnect = false
    m_nState = STATE_INVALID
end