--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KNetLog.lua
--  Creator     : liulingli
--  Date        : 2016/2/22   11:29
--  Contact     : liulingli@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KNetLog      = {}
KNetLog.tSend      = {}
KNetLog.tRecv      = nil
KNetLog.nSendTime  = nil
KNetLog.nCheckTime = nil

local SEND_INTERVAL_TIME  = 60
local CHECK_INTERVAL_TIME = 300

function KNetLog.sendLog(szServer, szNetFun, nRequestID)
    local t = {}
    t["fun"] = szNetFun
    t["sendTime"] = C_GetTickCount()
    if szServer == "BS" then
        KNetLog.tSend[nRequestID] = t
    else
        KNetLog.tSend[szServer] = t
    end
end

function KNetLog.recvLog(szServer, nRequestID)
    local t
    if szServer == "BS" then
        t = KNetLog.tSend[nRequestID]
        KNetLog.tSend[nRequestID] = nil
    elseif szServer == "LS" then
        t = KNetLog.tSend[szServer]
        KNetLog.tSend[szServer] = nil
    end
    if not t then return end

    if not KNetLog.tRecv then
        KNetLog.tRecv = {}
    end
    local szFun = szServer..t["fun"]
    KNetLog.tRecv[szFun] = KNetLog.tRecv[szFun] or {}
    KNetLog.tRecv[szFun]["time"]  = (KNetLog.tRecv[szFun]["time"] or 0) + C_GetTickCount() - t["sendTime"]
    KNetLog.tRecv[szFun]["count"] = (KNetLog.tRecv[szFun]["count"] or 0) + 1
end

function KNetLog.send()
    if not KNetLog.tRecv then return end
    local szData  = tableToString(KNetLog.tRecv)
    KNetLog.tRecv = nil
    sendIGS("NetLog", szData)
end

function KNetLog.activate(nowTime)
    if not KNetLog.nSendTime then
        KNetLog.nSendTime = nowTime
    elseif nowTime - KNetLog.nSendTime >= SEND_INTERVAL_TIME then
        KNetLog.nSendTime = nowTime
        KNetLog.send()
    end

    if not KNetLog.nCheckTime then
        KNetLog.nCheckTime = nowTime
    elseif nowTime - KNetLog.nCheckTime >= CHECK_INTERVAL_TIME then
        KNetLog.nCheckTime = nowTime

        for k, v in pairs(KNetLog.tSend) do
            if v.isCheck then
                KNetLog[k] = nil
            else
                v.isCheck = true
            end
        end
    end
end

return KNetLog
