return 
{
	[1] = {['nTankType'] = 1,['nPower'] = 0.5,},
	[2] = {['nTankType'] = 2,['nPower'] = 1,},
	[3] = {['nTankType'] = 3,['nPower'] = 2,},
	[4] = {['nTankType'] = 4,['nPower'] = 1.5,},
	[5] = {['nTankType'] = 5,['nPower'] = 2,},
}