return 
{
	[1] = {['nID'] = 1,['szName'] = [[圣誕地獄貓]],['szCardID'] = [[90|200]],['szResPath'] = [[M18_15xmas]],['szImagePath'] = [[M18_15xmas]],},
	[2] = {['nID'] = 2,['szName'] = [[山貓-新春]],['szCardID'] = [[17|127]],['szResPath'] = [[II-Lynx_15newyear]],['szImagePath'] = [[II-Lynx_15newyear]],},
	[3] = {['nID'] = 3,['szName'] = [[M8A1-清明]],['szCardID'] = [[88|198]],['szResPath'] = [[M8A1_Qingming]],['szImagePath'] = [[M8A1_Qingming]],},
	[4] = {['nID'] = 4,['szName'] = [[T2（舊）]],['szCardID'] = [[20|130]],['szResPath'] = [[T2_old]],['szImagePath'] = [[T2_old]],},
	[5] = {['nID'] = 5,['szName'] = [[III/IV（舊）]],['szCardID'] = [[39|149]],['szResPath'] = [[III-IV_old]],['szImagePath'] = [[III-IV_old]],},
	[6] = {['nID'] = 6,['szName'] = [[犀牛(舊)]],['szCardID'] = [[84|194]],['szResPath'] = [[Nashorn_old]],['szImagePath'] = [[Nashorn_old]],},
	[7] = {['nID'] = 7,['szName'] = [[野蜂-夏日]],['szCardID'] = [[102|212|336]],['szResPath'] = [[Hummel_sw]],['szImagePath'] = [[Hummel_sw]],},
	[8] = {['nID'] = 8,['szName'] = [[虎走-夏日]],['szCardID'] = [[104|214]],['szResPath'] = [[tiger-WT_sw]],['szImagePath'] = [[tiger-WT_sw]],},
	[9] = {['nID'] = 9,['szName'] = [[黑豹-夏日]],['szCardID'] = [[42|152]],['szResPath'] = [[Panther_sw]],['szImagePath'] = [[Panther_sw]],},
	[10] = {['nID'] = 10,['szName'] = [[黑豹Ⅱ-夏日]],['szCardID'] = [[43|153]],['szResPath'] = [[Panther-II_sw]],['szImagePath'] = [[Panther-II_sw]],},
	[11] = {['nID'] = 11,['szName'] = [[公羊II(舊)]],['szCardID'] = [[50|160]],['szResPath'] = [[Ram-II_old]],['szImagePath'] = [[Ram-II_old]],},
	[12] = {['nID'] = 12,['szName'] = [[KV-1(舊)]],['szCardID'] = [[54|164]],['szResPath'] = [[KV-1_old]],['szImagePath'] = [[KV-1_old]],},
	[13] = {['nID'] = 13,['szName'] = [[KV-2(舊)]],['szCardID'] = [[55|165]],['szResPath'] = [[KV-2_old]],['szImagePath'] = [[KV-2_old]],},
	[14] = {['nID'] = 14,['szName'] = [[KV-3(舊)]],['szCardID'] = [[56|166]],['szResPath'] = [[KV-3_old]],['szImagePath'] = [[KV-3_old]],},
	[15] = {['nID'] = 15,['szName'] = [[KV-4(舊)]],['szCardID'] = [[57|167]],['szResPath'] = [[KV-4_old]],['szImagePath'] = [[KV-4_old]],},
}