PLAT_SELF = 1
PLAT_XG   = 3

PLAT_ID   = PLAT_SELF
IS_REGISTER_ACTIVATION = false
IS_BIND_ACCOUNT        = false
IS_EXCHANGE = false
ACTIVATION_CODE_LENGTH = 10
STRENGTHEN_LEVEL_COUNT = 5
MISSION_BATTLE_ZONE_ID = 12


CARD_BROKEN_STATE = 
{
    NORMAL  = 0,
    LITTLE  = 1,
    MIDDLE  = 2,
    BIG     = 3,
    DEAD    = 4,
}

ATTACK_RESULT = 
{
    MISS        = 0,
    RICOCHET    = 1,
    CRIT        = 2,
    NORMAL      = 3,
    GRAZE       = 4,
}

LS_HANDSHAKE_RESPOND_RET = 
{
    SUCCESS         = 0,
    VERSION_ERROR   = 1,
}
    
LOGIN_RET = 
{
    SUCCESS 		= 0,
    INVALID_ACCOUNT = 1,
    PASSWORD_ERROR 	= 2,
    LOGIN_CANCEL    = 3,
    LOGIN_FAILED    = 4,
    NOT_ACTIVE      = 5,
    AUTH_SERVER_BUSY = 6,
    ERROR_ACCOUNT_OR_PASSWORD = 7,
    GS_BUSY         = 8
}

ENTER_SERVER_RET = 
{
    SUCCESS 			= 0,
    SERVER_NOT_EXIST 	= 1,
    SERVER_OFFLINE		= 2,
    SERVER_BUSY 		= 3,
    TIME_OUT            = 4,
    FROZEN              = 5,
}

REG_ACCOUNT_RET = 
{
    SUCCESS = 0,
    EXISTED_ACCOUNT = 1,
    ACTIVATION_CODE_ERROR = 2,
    ACTIVATION_CODE_USED = 3,
}

ACTIVATE_RET = 
{
    SUCCESS = 0,
    ACCOUNT_NOT_EXIST   = 1,
    ACTIVATE_CODE_ERROR = 2,
    ACTIVATE_CODE_USED  = 3,
    HAS_ACTIVE          = 4,
}

CHANGE_PASSWORD_RET =
{
    SUCCESS = 0,
    NOT_EXISTED_ACCOUNT = 1,
    OLD_PASSWORD_ERROR = 2,
}

CHANGE_FROZEN_RET =
{
    SUCCESS = 0,
    NOT_EXISTED_ACCOUNT = 1,
}

RENAME_RET = 
{
	SUCCESS = 0,
	ILLEGA_NAME = 1,
	USED = 2,
	TOO_LONG = 3,
	TOO_SHORT = 4,
}

ROLE_PROCESS_TYPE = 
{
    ROLE_PROGRESS_NEW               = 0,
    ROLE_PROGRESS_RENAME_NAME       = 1000,
    ROLE_PROGRESS_OLD_RENAME_NAME   = 2000,
    ROLE_PROGRESS_CHOOSE_CARD       = 3000,
    ROLE_PROGRESS_READY             = 10000,
    ROLE_PROGRESS_GUIDE_BEGIN       = 20000,
    ROLE_PROGRESS_GUIDE_END         = 1000000,
}

ITEM_TYPE = 
{
	CURRENCY   = 1,
	CARD       = 2,
	EQUIP      = 3,
    OTHER      = 4,
    FURNITURE  = 5,
    SKIN       = 6,
}

CURRENCY_TYPE = 
{
	COIN = 1,
	OIL = 2,
	AMMO = 3,
	STEEL = 4,
	PEOPLE = 5,
    FURNITURE = 6,
}

CURRENCY_KEY =
{
    "oil",
    "ammo",
    "steel",
    "people",
}

AUTO_ADD_RESOURCES = 
{
    "autoAddOil",
    "autoAddAmmo",
    "autoAddSteel",
    "autoAddPeople",
}

CURRENCY_NAME = {
    "鉆石",
    "燃料",
    "彈藥",
    "鋼材",
    "器材",
    "家具幣",
}

ATTRIBUTE = 
{
    HP          = 1,
    ATTACK      = 2,
    PENETRATE   = 3,
    SPEED       = 4,
    FRONTARMOUR = 5,
    REARARMOUR  = 6,
    SCOUT       = 7,
    DODGE       = 8,
    HIDE        = 9,
    NIGHTBATTLE = 10,
    RANGE       = 11,
    ACCURACY    = 12,
    CRIT        = 13,
    MAX_HP      = 14,
    HITRATE     = 15,
    THUMPRATE   = 16,
}

CARD_SELECT_PANEL_TYPE = 
{
    ADD      = 1,
    CHANGE   = 2,
}

CARD_EQUIP_TYPE = 
{
    MAIN      = 1,
    GENERAL   = 2,
    SKILL     = 3,
}

EXPEDITION_STATUS = 
{
    NOTSTART   = 0,
    RUNNING    = 1,
    CANGET     = 2,
}

CARD_TYPE = 
{
    LIGHT_TANK          = 1,
    MEDIUM_TANK         = 2,
    HEAVY_TANK          = 3,
    TANK_DESTORYER      = 4,
    SELF_PROPELLED_GUN  = 5,
    TRANSPORT           = 6,
    BOSS                = 7,
    TURRET              = 8,
}

CARD_TYPE_NAME = 
{
    "輕型坦克",
    "中型坦克",
    "重型坦克",
    "坦克殲擊車",
    "自行火炮",
    "運輸車",
    "BOSS",
    "炮塔",
}

BROKEN_LIMIT = 
{
    BIG = 0.25,
    MIDDLE = 0.5,
    LITTLE = 0.75,
}

MAX_TEAM_COUNT                = 4 
MAX_TEAM_CARD_COUNT           = 6 
MAX_MISSION_CONDITION_COUNT   = 3 
MAX_MISSION_OBJECTIVE_COUNT   = 6 
MAX_TEAM_RECORD_COUNT         = 3

MAX_TEAM_ATTRIBUTE = 
{
    HP        = 750,
    ARMOUR    = 750,
    DODGE     = 750,
    SPEED     = 750,
    PENETRATE = 900,
    ATTACK    = 900,
}

FOOTHOLD_TYPE =
{
    START    = 1,
    ENEMY    = 2,
    BOSS     = 3,
    RESOURCE = 4,
    ACCIDENT = 5,
    NONE     = 6,
}

TIME_ADVANCE = 5

RANDOM_TYPE = 
{
    HITONE   = 1,
    EACHRAND = 2,
}

FIGHT_SCORE = 
{
    E  = 1,
    D  = 2,
    C  = 3,
    B  = 4,
    A  = 5,
    S  = 6,
    SS = 7,
}

MAX_TEAM_COUNT                = 4 
MAX_TEAM_CARD_COUNT           = 6 
MAX_MISSION_CONDITION_COUNT   = 3 
MAX_MISSION_OBJECTIVE_COUNT   = 6

FOOTHOLD_TYPE =
{
    START = 1,
    ENEMY = 2,
    BOSS = 3,
    RESOURCE = 4,
    ACCIDENT = 5,
    NONE = 6,
}

BATTLE_EXP_COE = 
{
    [FIGHT_SCORE.SS] = 1.2,
    [FIGHT_SCORE.S] = 1.2,
    [FIGHT_SCORE.A] = 1,
    [FIGHT_SCORE.B] = 1,
    [FIGHT_SCORE.C] = 0.8,
    [FIGHT_SCORE.D] = 0.7,
    [FIGHT_SCORE.E] = 0.5,
}

COIN_COST_TYPE =
{
    DONATE = 1,
    NORMAL = 2,
    RECHARGE = 3,
}

TRADE_TYPE =
{
    SHOP      = 1,
    FOODHOUSE = 2,
}

PASS_TYPE = 
{
    OPEN    = 1,
    FAIL    = 2,
    SUCCESS = 3,
}

MISSION_OPERATE_TYPE = 
{
    OPEN    = 1,
    FINISH  = 2,
}

EQUIP_DETAIL_TYPE = 
{
    MTG     = 0,
    AP      = 1,
    MG      = 2,
    HE      = 3,
    TRACER  = 4,
    SMOKE   = 5,
    OTHER   = 6,
}

EQUIP_STAR_RANGE = {
    LOW     = { START = 1, END = 2 },
    MIDDLE  = { START = 3, END = 4 },
    HIGH    = { START = 5, END = 6 },
}

CARD_STAR_RANGE = {
    LOW     = { START = 1, END = 2 },
    MIDDLE  = { START = 3, END = 4 },
    HIGH    = { START = 5, END = 6 },
}

PANEL_RECORD_TYPE =
{
    OPEN = 1,
    CLOSE = 2,
}

EXPAND_BAR_TYPE =
{
    REPAIR = 1,
    BUILD  = 2,
}

SYSTEM_TYPE = 
{
    RANK_UPDATE_DAY_TIME     = 1,
    RANK_UPDATE_MONTH_TIME   = 2,
    MAIL_LAST_ID             = 3,
}

RANK_REWARD_TYPE = 
{
    HIT_ALL = 1,
    HIT_ONE = 2,
}

BATTLE_STEP_TYPE = 
{ 
    SCOUT             = 1,
    ARTILLERY_STRIKE  = 2,
    AMBUSH            = 3,
    ARTILLERY_ACTION  = 4,
    ARTILLERY_ACTION2 = 5,
    DOG_FIGHT         = 6,
    NIGHT_FIGHT       = 7,
}

LOG_TYPE =
{
    CARD   = 1,
    EQUIP  = 2,
}

NET_ACTION_END_TYPE =
{
    CONNECTION_FAILED = 1,
    SUCCESS = 2,
    TIME_OUT = 3,
}

MAX_FURNITURE_INDEX = 9

FURNITURE_TYPE =
{
    WALLPAPER       = 1,
    FLOOR           = 2,
    HANGING         = 3,
    WINDOW          = 4,
    CARPET          = 5,
    OBJECTS_FLOOR   = 6,
    FURNITURE_LEFT  = 7,
    CHAIRS          = 8,
    FURNITURE_RIGHT = 9,
}

EXCHANGE_CODE_RET = 
{
    SUCCESS       = 0,
    CODE_ERROR    = 1,
    CODE_USED     = 2,
    BEEN_EXCHANGE = 3,
    USE_MUCH      = 4,
    OVERDUE       = 5,
}

BUY_RET = 
{
    SUCCESS       = 0,
    OVERDUE       = 1,
    COINNOTENOUGH = 2,
}

RING_ATTRIBUTE_TYPE = 
{
    ADD_RANGE   = 1,
    ADD_VALUE   = 2,
    ADD_PERCENT = 3,
}

ITEM_SMALL_TYPE = 
{
    OTHER   = 0,
    RING    = 1,
    FEELING = 2,
    CHANGENAME = 3,
    MOUNT      = 4,
}

SYNC_LIST = {
    {"SyncBaseData",           "基本"},
    {"SyncLastUpdateTime",     "最后刷新時間"},
    {"SyncItemData",           "物品"},
    {"SyncRepairBarData",      "修理欄"},
    {"SyncBuildBarData",       "建造欄"},
    {"SyncRecordData",         "記錄"},
    {"SyncCardData",           "卡片"},
    {"SyncTeamData",           "隊伍"},
    {"SyncExpeditionData",     "遠征"},
    {"SyncMissionData",        "任務"},
    {"SyncBattleData",         "戰斗"},
    {"SyncBattleSpecialData",  "戰斗特殊"},
    {"SyncSignData",           "簽到"}, 
    {"SyncShopData",           "商店"},
    {"SyncFurnitureData",      "家具"},
    {"SyncFoodHouseData",      "美食屋"},
    {"SyncExpBuffData",        "經驗Buff"},
    {"SyncMedalData",          "勛章"},
    {"SyncSecretaryData",      "秘書"},
    {"SyncSkinData",           "皮膚"},
    {"SyncSkillData",          "技能"},
    {"SyncSPSignData",         "特殊簽到"},
    {"SyncStoryData",          "小劇場"},
    {"SyncTrainData",          "訓練"},
    {"SyncDataEnd",},
}

CHAT_TYPE = 
{
    PRIVATE = "PRIVATE",
    GLOBAL = "GLOBAL",
    SEND_PRIVATE = "SEND_PRIVATE",
}

CHAT_CHANEL_TYPE = 
{
    PRIVATE = "PRIVATE",
    GLOBAL  = "GLOBAL",
}

CHAT_CHANEL_SETTINGS = 
{
    PRIVATE = 
    {
        FILTER = {CHAT_TYPE.PRIVATE, CHAT_TYPE.SEND_PRIVATE},
    },
    GLOBAL =
    {
        FILTER = {CHAT_TYPE.SEND_PRIVATE, CHAT_TYPE.GLOBAL},
    }
}

--define for database, don't change
MAIL_TYPE = 
{
    GLOBAL  = 0,
    GROUP   = 1,
}

GM_PRIVILEGE_LEVEL = 
{
    HIGHEST = 0,
    MIDDLE  = 1,
    LOWEST  = 2,
}

BATTLE_COST_RESOUCE =
{
    COST_OIL_PERCENT = 0.2,
    COST_AMMO_PERCENT = 0.2,
    COST_OIL_PERCENT_NIGHT = 0.1,
    COST_AMMO_PERCENT_NIGHT = 0.1,
}

DIFFCULT_LEVEL =
{
    LEVEL_EASY = 1,
    LEVEL_MID  = 2,
    LEVEL_HARD = 3,
}

BATTLE_MAP_MODE =
{
    LEVEL       = 0,
    DIFFCULT1   = 1,
    DIFFCULT2   = 2,     
}

BATTLE_TYPE =
{
    NORMAL       = 1,
    EXERCISE     = 2,
    EXPEDITION   = 3,
    GUIDE        = 4,
}

CARD_COUNTRY_TYPE = 
{
	BASE		= 1,
	AMERICA		= 2,
	BRITAIN		= 3,
	FRANCE		= 4,
	GERMANY     = 5,
	SOVIET      = 6,
}

OTHER_RANK_TYPE =
{
    MVP          = 1,
    BROKEN       = 2,
    FIGHTING     = 3,
    BEHIT        = 4,
    MISS         = 5,
    --DIE          = 3,
}

SECRETARY_TYPE =
{
    TEAM_LEADER     = 0,
    DESIGNATE       = 1,
}

SECRETARY_STATE =
{
    NORMAL          = 0,
    MID_BREAK       = 1,
}

SKIN_EXCHANGE_ITEM_ID = 91

MAX_SKILL_COUNT = 3

SKILL_TYPE = {
    "Guide", 
    "AirBomb",  
    "AirSupport",
    "Barrage",
    "Bunker", 
    "Combo",   
    "Landmine",          
    "Supply",          
    "Repair",         
    "UpExp",             
}

CARD_EXTRA_PROPERTY = 
{
    DODGE              = "dodge",
    PIERCE_EFFECT_RATE = "pierceEffectRate",
}

SKILL_STATE = {
    UNUSED  = 0,
    READY   = 1,
    BUFF    = 2,
    END     = 3,
}

MISSION_TYPE = {
    MAIN_LINE     = 1, 
    BRANCH_LINE   = 2,
    WEEKLY        = 3,
    EVERYDAY      = 4,
    EXTEND_JUNIOR = 5,
    EXTEND_MIDDLE = 6,
    EXTEND_SENIOR = 7,
}

RANK_MONTH_LEFT = 0.03

BIND_ACCOUNT_RET = {
    SUCCESS    = 0,
    SERVER_NOT_EXIST = 1,
    ACCOUNT_NOT_EXIST = 2,
    ROLE_NOT_EXIST    = 3,
    ACCOUNT_NAME_REPETITION = 4,
    BOUND      = 5,
    INFO_ERROR = 6,
}

ABILITY_CHECK_POINT = {
    BATTLE_BEGIN = 1,
    BATTLE_END = 2,
    CARD_BEFORE_COST_HP = 3,
    CARD_AFTER_COST_HP = 4,
    CARD_BEFORE_ATTACK = 5,
    CARD_AFTER_ATTACK = 6,
    CARD_BEFORE_DEAD = 7,
    CARD_AFTER_DEAD = 8,
    STEP_BEGIN = 9,
    STEP_END = 10,
}