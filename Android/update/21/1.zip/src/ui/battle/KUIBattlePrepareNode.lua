--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBattlePrepareNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/20   16:21
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIBattlePrepareNode = class(
    "KUIBattlePrepareNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

math.randomseed(os.time())

function KUIBattlePrepareNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._thread        = nil
    self._battleType    = BATTLE_TYPE.NORMAL
end

local footType2CSBFile = 
{
    [FOOTHOLD_TYPE.START]    = "res/ui/animation_node/ani_lanch_stronghold.csb",
    [FOOTHOLD_TYPE.ENEMY]    = "res/ui/animation_node/ani_lanch_node.csb",
    [FOOTHOLD_TYPE.BOSS]     = "res/ui/animation_node/ani_lanch_icon.csb",
    [FOOTHOLD_TYPE.RESOURCE] = "res/ui/animation_node/ani_lanch_node.csb",
    [FOOTHOLD_TYPE.ACCIDENT] = "res/ui/animation_node/ani_lanch_node.csb",
    [FOOTHOLD_TYPE.NONE]     = "res/ui/animation_node/ani_lanch_node.csb",
}

local INTO_CONDITION_ATTR_NAME =
{
    CURRENT_HP  = 1,
    MAX_HP      = 2,
    ATTACK      = 3,
    PENETRATE   = 4,
    SPEED       = 5,
    DODGE       = 6,
    FRONTARMOUR = 7,
    REARARMOUR  = 8,
}

local teamAttributeName = {
    [INTO_CONDITION_ATTR_NAME.CURRENT_HP]   = "nCurrentHP",
    [INTO_CONDITION_ATTR_NAME.MAX_HP]       = "nMaxHP",
    [INTO_CONDITION_ATTR_NAME.ATTACK]       = "nAttack",
    [INTO_CONDITION_ATTR_NAME.PENETRATE]    = "nPenetrate",
    [INTO_CONDITION_ATTR_NAME.SPEED]        = "nSpeed",
    [INTO_CONDITION_ATTR_NAME.DODGE]        = "nDodge",
    [INTO_CONDITION_ATTR_NAME.FRONTARMOUR]  = "nFrontArmour",
    [INTO_CONDITION_ATTR_NAME.REARARMOUR]   = "nRearArmour",
}

function KUIBattlePrepareNode.create(owner, userData)
    local currentNode = KUIBattlePrepareNode.new()

    currentNode._parent      = owner
    currentNode._uiPath      = "res/ui/battle_prepare.csb"
    currentNode._zoneID      = userData.zoneID
    currentNode._mapID       = userData.mapID
    currentNode._footholdID  = userData.footholdID or 1
    currentNode._enableTouch = false
    if userData.launchID then
        currentNode._leftTeam    = KUtil.createLeftMonsterInfo(userData.launchID)
    else
        currentNode._leftTeam    = KUtil.createLeftTeamInfo(userData.teamIndex)
    end
    currentNode._bFaceEast   = true
    currentNode._roundList   = userData.roundList
    currentNode._guideUseSkill = userData.guideUseSkill
    currentNode._battleType  = userData.battleType or currentNode._battleType
    currentNode._isUseSkill  = userData.isUseSkill

    currentNode:init()

    return currentNode
end

function KUIBattlePrepareNode:setRountList(roundList)
    self._roundList   = roundList
end

function KUIBattlePrepareNode:setIsUseSkill(bUseSkill)
    self._isUseSkill  = bUseSkill
end

function KUIBattlePrepareNode:playMapBackGroundMusic(isEnter)
    local mapMusic = KUtil.getBattleMusicSetting(self._zoneID, self._mapID, self._footholdID)
    KSound.playBattleMusic(mapMusic, isEnter)
end

function KUIBattlePrepareNode:hideFootholdRedLight(footholdID)
    local zoneID    = self._zoneID
    local mapID     = self._mapID
    local mapNode   = self.mapNode

    local footholdSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
    local footholdType    = FOOTHOLD_TYPE[footholdSetting.szFootholdType]

    if footholdType ~= FOOTHOLD_TYPE.START and footholdType ~= FOOTHOLD_TYPE.BOSS and footholdType ~= FOOTHOLD_TYPE.ENEMY then
        local footholdUI           = mapNode:getChildByName("ProjectNode_" .. footholdID)
        local footholdTypeNodeList = footholdUI:getChildren()

        local imageRedLight = footholdUI:getChildByName("Image_red_light1")
        imageRedLight:setVisible(false)
        local imageRedLight = footholdUI:getChildByName("Image_red_light2")
        imageRedLight:setVisible(false)
    end
end

function KUIBattlePrepareNode:showFootholdNode(footholdID)
    local zoneID    = self._zoneID
    local mapID     = self._mapID
    local mapNode   = self.mapNode

    local footholdSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
    local footholdType    = FOOTHOLD_TYPE[footholdSetting.szFootholdType]

    local tFootholdTypeNodeName = {
        [FOOTHOLD_TYPE.NONE]          = {"Image_node1"},
        [FOOTHOLD_TYPE.RESOURCE]      = {"Image_node2"},
        [FOOTHOLD_TYPE.ACCIDENT]      = {"Image_node3"},
        [FOOTHOLD_TYPE.ENEMY]         = {"Image_node4", "Image_red_light1", "Image_red_light2"},
        [FOOTHOLD_TYPE.BOSS]          = {"Image_node4", "Image_red_light1", "Image_red_light2"},
    }

    if footholdType ~= FOOTHOLD_TYPE.START and footholdType ~= FOOTHOLD_TYPE.BOSS then
        local footholdUI           = mapNode:getChildByName("ProjectNode_" .. footholdID)
        local footholdTypeNodeList = footholdUI:getChildren()

        for _, v in ipairs(footholdTypeNodeList) do
            v:setVisible(false)
        end
        
        if footholdType == FOOTHOLD_TYPE.ENEMY then
            local footholdTypeNode = footholdUI:getChildByName("Image_node4")
            local redPointPath     = "res/ui/ui_material/battle_prepare/enemy.png"
            footholdTypeNode:loadTexture(redPointPath)
        end

        local tNodeNameList = tFootholdTypeNodeName[footholdType]
        for _, v in ipairs(tNodeNameList) do
            local footholdTypeNode = footholdUI:getChildByName(v)
            footholdTypeNode:setVisible(true)
        end
    end
end

function KUIBattlePrepareNode:showLineupUI(visible)
    print("------------>showLineupUI", visible)

    local mainNode = self._mainLayout
    local i = 0
    while true do
        i = i + 1
        local lineupUI = mainNode:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end

        local lineupSetting = KConfig:getLine("lineup", i)
        if not self._leftTeam[lineupSetting.nMinMemberCount] then
            lineupUI:setVisible(false)
        else
            lineupUI:setVisible(visible)    
        end
    end    
end

function KUIBattlePrepareNode:getCanChooseLineupList()
    local tResult = {}
    local mainNode = self._mainLayout
    local i = 0
    while true do
        i = i + 1
        local lineupUI = mainNode:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end

        local lineupSetting = KConfig:getLine("lineup", i)
        if self._leftTeam[lineupSetting.nMinMemberCount] then
            table.insert(tResult, i)
        end
    end
    return tResult
end

function KUIBattlePrepareNode:playCharaAnimationCutIn(duration)
    local mainNode = self._mainLayout
    duration = duration or 0.3
    self:resetUIPos(mainNode, "Image_cj_dialog_chara")

    local ui            = mainNode:getChildByName("Image_cj_dialog_chara")
    local targetPosX    = ui:getPositionX()
    local targetPosY    = ui:getPositionY()
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    local moveDistance  = visibleSize.width * 0.54

    ui:setPositionX(targetPosX - moveDistance)
    ui:setPositionY(targetPosY)

    ui:runAction(cc.Sequence:create(
        cc.MoveBy:create(duration, cc.p(moveDistance, 0)),
        cc.FadeIn:create(duration)
        )
    )
    return duration
end

function KUIBattlePrepareNode:playCharaAnimationCutOff(duration)
    local mainNode = self._mainLayout
    self:showUI(mainNode, "Button_cj_dialog", false)
    self:showUI(mainNode, "Text_dialog", false)
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    local moveDistance  = visibleSize.width * 1.0
    duration = duration or 0.3
    self:fadeOut(mainNode, "Image_cj_dialog_chara", duration)
    self:move(mainNode, "Image_cj_dialog_chara", duration, -moveDistance, 0)
    return duration
end

function KUIBattlePrepareNode:playCharaAnimationOfChooseBranch()
    local ui  = self._mainLayout:getChildByName("Image_cj_dialog_chara")
    ui:setVisible(true)

    local oldPosX = ui:getPositionX()
    local oldPosY = ui:getPositionY()

    local function resetUI()
        ui:setVisible(false)
        ui:setPositionX(oldPosX)
        ui:setPositionX(oldPosY)
    end

    ui:runAction(cc.Sequence:create(
        cc.MoveTo:create(0.3, cc.p(oldPosX - 200, oldPosY)),
        cc.CallFunc:create(resetUI)
    ))
end

function KUIBattlePrepareNode:playAccidentAnimation(footholdID)
    local accidentUI        = self.accidentUI
    local accidentAction    = self.accidentAction

    local mapNode      = self.mapNode
    local footholdUI   = mapNode:getChildByName("ProjectNode_" .. footholdID)
    local posX         = footholdUI:getPositionX()
    local posY         = footholdUI:getPositionY()
    accidentUI:setPositionX(posX)
    accidentUI:setPositionY(posY)

    local startFrame   = 0
    local endFrame     = accidentAction:getDuration()
    accidentAction:gotoFrameAndPlay(startFrame, endFrame, false)
end

function KUIBattlePrepareNode:playAwardOneItemAnimation(ui, duration, delay)
    local mapNode       = self.mapNode

    local moveDistX  = 0
    local moveDistY  = 100  

    local function onStopAnimation()
        mapNode:removeChild(ui)
    end

    ui:setOpacity(0)
    ui:runAction( 
        cc.Sequence:create(
            cc.DelayTime:create(delay),
            cc.Spawn:create(
                cc.MoveBy:create(duration, cc.p(moveDistX, moveDistY)),
                cc.Sequence:create(
                    cc.FadeIn:create(duration / 2),
                    cc.FadeOut:create(duration / 2)
                )
            ),
            cc.CallFunc:create(onStopAnimation)
        )
    )

    return duration + delay
end

function KUIBattlePrepareNode:playItemAnimation(tItemList, duration, interval, fontColor, footholdID, isCost)
    local mapNode       = self.mapNode
    local footholdUI    = mapNode:getChildByName("ProjectNode_" .. footholdID)
    local startPosX     = footholdUI:getPositionX()
    local startPosY     = footholdUI:getPositionY()

    local delay      = 0
    local totalDelay = 0

    for _, v in ipairs(tItemList) do
        local itemID        = v.nID
        local itemType      = v.nType
        local itemCount     = v.nNum
        local itemName      = nil

        if itemType == ITEM_TYPE.CURRENCY then
            itemName = KUtil.getCurrencyNameByKey(itemID)
        elseif itemType == ITEM_TYPE.OTHER then
            itemName = KUtil.getItemConfigValue(itemID, "szName")
        elseif itemType == ITEM_TYPE.CARD then
            itemName = KUtil.getCardConfigValue(itemID, "szName")
        elseif itemType == ITEM_TYPE.EQUIP then
            itemName = KConfig.equipInfo[itemID]["szName"]
        else
            assert(false, string.format("unknow award item type: %d", itemType))        
        end

        local text = nil
        if isCost then
            text = string.format("%s: %d", itemName, itemCount)
        else
            text = string.format("%s: +%d", itemName, itemCount)
        end

        local label    = cc.Label:createWithTTF(text, KUtil.FONT_PATH, 26) 
        label:setColor(fontColor)       
        
        mapNode:addChild(label)
        label:setPositionX(startPosX)
        label:setPositionY(startPosY)

        delay = delay + interval
        totalDelay = self:playAwardOneItemAnimation(label, duration, delay)
    end

    return totalDelay
end

function KUIBattlePrepareNode:playAwardItemAnimation(tAwardList, duration, interval, footholdID)
    local fontColor     = cc.c3b(0, 255, 0)
    local isCostEffect  = false
    local scene         = self._parent    

    local curThread = coroutine.running()

    local function onRewardClick()
        coroutine.resume(curThread)
    end

    if tAwardList ~= nil and #tAwardList ~= 0 then
        KUtil.playGetItemAnimation(scene, tAwardList, onRewardClick)
        coroutine.yield()
    end
end

function KUIBattlePrepareNode:playCostItemAnimation(tCostList, duration, interval, footholdID)
    local fontColor     = cc.c3b(255, 0, 0)
    local isCostEffect  = true
    return self:playItemAnimation(tCostList, duration, interval, fontColor, footholdID, isCostEffect)
end

function KUIBattlePrepareNode:showWay(srcFootholdID, dstFootholdID, passed)
    print("---------------->showWay", srcFootholdID, dstFootholdID, passed)
    local mapNode = self.mapNode

    local imageInstanceMap  = mapNode:getChildByName("Image_instance_map")
    local wayUIName         = string.format("Node_way_%d_%d", srcFootholdID, dstFootholdID)
    local wayUI             = imageInstanceMap:getChildByName(wayUIName)
    if not wayUI then 
         wayUIName  = string.format("Node_way_%d_%d", dstFootholdID, srcFootholdID)
         wayUI      = imageInstanceMap:getChildByName(wayUIName)
    end

    self:setUIVisible(wayUI, "Image_way_1", passed)
    self:setUIVisible(wayUI, "Image_way_2", not passed)
end

function KUIBattlePrepareNode:playActionByName(actionName)
    print("---------------->playActionByName", actionName)

    local action = self[actionName]
    local frame = action:getDuration()
    action:gotoFrameAndPlay(0, frame, true)
end

function KUIBattlePrepareNode:stopActionByName(actionName)
    print("---------------->stopActionByName", actionName)

    local action = self[actionName]
    action:gotoFrameAndPause(0)
end

function KUIBattlePrepareNode:moveTank(srcFootholdID, dstFootholdID)
    print("---------------->moveTank", srcFootholdID, dstFootholdID)
    local moveSpeed = 170

    local dstUI = self.mapNode:getChildByName("ProjectNode_" .. dstFootholdID)
    local dstX = dstUI:getPositionX()
    local dstY = dstUI:getPositionY()

    local srcUI = self.mapNode:getChildByName("ProjectNode_" .. srcFootholdID)
    local srcX = srcUI:getPositionX()
    local srcY = srcUI:getPositionY()

    local distanceX = (srcX - dstX) * (srcX - dstX) 
    local distanceY = (srcY - dstY) * (srcY - dstY)
    local distance  = math.sqrt(distanceX + distanceY)

    local moveTime  = distance / moveSpeed

    local actionMove      = cc.MoveTo:create(moveTime, cc.p(dstX, dstY))
    local sequence        = cc.Sequence:create(actionMove)
    local battleSetting   = KUtil.getBattleSetting(self._zoneID, self._mapID, srcFootholdID)
    local tBattleBranches = battleSetting.tBranches
    local branchDirection = 0
    for _, tBranch in ipairs(tBattleBranches) do
        if tBranch[1] == dstFootholdID then
            branchDirection = tBranch[3]
            break
        end
    end
    if branchDirection > 180 and branchDirection <= 360 and self._bFaceEast then
        local actionTurn = cc.OrbitCamera:create(0.5, 1, 0, 0, 180, 0, 0)
        sequence         = cc.Sequence:create(actionTurn, actionMove)
        self._bFaceEast  = false
    elseif branchDirection < 180 and branchDirection > 0 and not self._bFaceEast then
        local actionTurn = cc.OrbitCamera:create(0.5, 1, 0, 180, -180, 0, 0)
        sequence         = cc.Sequence:create(actionTurn, actionMove)
        self._bFaceEast  = true
    end 

    local tankUI = self.mapNode:getChildByName("ProjectNode_tank")
    tankUI:runAction(sequence)

    local delayTime = 0.5 + moveTime
    self:delay(delayTime)
end

function KUIBattlePrepareNode:waitClickCompass(randomBranch)
    local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, self._footholdID)
    if #battleSetting.tBranches < 2 then
        return
    end

    print("---------------->waitClickCompass")

    local mainNode = self._mainLayout
    
    self:tipsActions()
    self._enableTouch = true
    self:setTouchEnabled(mainNode, "Button_global", true)
    self:playActionByName("compassPointerAction")
    if self._battleType == BATTLE_TYPE.GUIDE then
        require("src/logic/KGuideEnv").addNextGuideNode()
    end
    coroutine.yield() -- wait clock click
    self:setTouchEnabled(mainNode, "Button_global", false)
    self._enableTouch = false

    KSound.playEffect("compass")

    local tBattleBranches   = battleSetting.tBranches
    local branchesDirection = 0
    for _, v in pairs(tBattleBranches) do
        if v[1] == randomBranch then
            branchesDirection = v[3]
            break
        end
    end
    local compassDelayTime = 3.0
    local rotateRoundCount = 6
    local rotateOffSet     = 360 * rotateRoundCount + branchesDirection * -1

    local nodeCompass     = mainNode:getChildByName("ProjectNode_compass")
    local nodeCompassDial = nodeCompass:getChildByName("Image_cj_compass_dial")
    local rotateAction    = cc.RotateTo:create(compassDelayTime, rotateOffSet)
    local slowDownAction  = cc.EaseExponentialOut:create(rotateAction)
    nodeCompassDial:runAction(slowDownAction)
    self:delay(compassDelayTime) 

    self:setUIVisible(mainNode, "ProjectNode_compass", false)
    self:setUIVisible(mainNode, "ProjectNode_compass_pointer", false)
    nodeCompassDial:runAction(cc.RotateTo:create(0, 360))
end

local function getCardCountByType(team, cardType)
    local count = 0
    for k, v in ipairs(team) do
        if v.nNamedType == cardType then
            count = count + 1
        end
    end
    return count
end

local function getTeamAttrValue(team, attrName)
    local totalAttrValule = 0
    for _, tCard in ipairs(team) do
        totalAttrValule = totalAttrValule + tCard[attrName]
    end
    return totalAttrValule
end

local function hasCardInTeam(team, cardTemplateID, cardConvertIndex)
    for k, v in ipairs(team) do       
        local templateID   = v.nTemplateID
        local nCardType = KUtil.getCardConfig(templateID).nCardType
        if (cardTemplateID == 0 or cardTemplateID == templateID) and 
            (cardConvertIndex == 0 or cardConvertIndex == nCardType) then
            return true
        end
    end
    return false
end

function KUIBattlePrepareNode:getRandomTargetFoothold()
    print("----------------> getRandomTargetFoothold", self._zoneID, self._mapID, self._footholdID)
    local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, self._footholdID)
    local branchCount   = #battleSetting.tBranches
    local randomBranch  = battleSetting.tBranches[1][1]
    local leftTeam      = self._leftTeam
    if branchCount > 1 then
        randomBranch = nil
        local intoCondition = battleSetting.tIntoCondition 
        for k, v in ipairs(intoCondition) do 
            if v[1] == 1 then 
                local cardType      = v[2]
                local requiredCount = v[3]
                local actualCount = getCardCountByType(leftTeam, cardType)
                
                if actualCount >= requiredCount then 
                    randomBranch = battleSetting.tBranches[k][1]
                    break
                end
            elseif v[1] == 2 then 
                local cardProperty          = v[2]
                local cardPropertyTabMin    = v[3] 
                local cardPropertyTabMax    = v[4]
                local cardPropertyName = teamAttributeName[cardProperty]
                local totalPropertyValue =  getTeamAttrValue(leftTeam, cardPropertyName)
                if totalPropertyValue >= cardPropertyTabMin and totalPropertyValue <= cardPropertyTabMax then
                    randomBranch = battleSetting.tBranches[k][1]
                    break
                end
            elseif v[1] == 3 then
                local cardTabID            = v[2]
                local cardTabConvertIndex  = v[3]
                if hasCardInTeam(leftTeam, cardTabID, cardTabConvertIndex) then
                    randomBranch = battleSetting.tBranches[k][1]
                end
            end 
        end
        if not randomBranch then
            randomBranch = KUtil.getRandomOne(battleSetting.tBranches)
            assert(randomBranch)
        end
    end

    return randomBranch
end

function KUIBattlePrepareNode:randomTargetFoothold()
    local randomBranch = self:getRandomTargetFoothold()
    self:waitClickCompass(randomBranch)

    KSound.playEffect("tankForward")

    local footholdID = self._footholdID
    self._footholdID = randomBranch

    local mainNode   = self._mainLayout
    self:showUI(mainNode, "ProjectNode_compass_girl", false)
    
    self:hideFootholdRedLight(self._footholdID)

    self:moveTank(footholdID, self._footholdID)
    self:showWay(footholdID, self._footholdID, true)
    self:playActionByName("footholdAction" .. self._footholdID)

    self:delay(0.5)

    self:showFootholdNode(self._footholdID)
end

function KUIBattlePrepareNode:delay(seconds)
    print("---------------->delay", seconds)

    local mainNode = self._mainLayout

    local func = createThreadResumeFunc()
    delayExecute(mainNode, func, seconds)
    coroutine.yield()
end

function KUIBattlePrepareNode:fadeIn(parentNode, uiName, seconds)
    print("---------------->fadeIn", uiName, seconds)

    local ui = parentNode:getChildByName(uiName)
    ui:setOpacity(0)
    ui:runAction(cc.FadeIn:create(seconds))
end

function KUIBattlePrepareNode:fadeOut(parentNode, uiName, seconds)
    print("---------------->fadeOut", uiName, seconds)

    local ui = parentNode:getChildByName(uiName)
    ui:setOpacity(1)
    ui:runAction(cc.FadeIn:create(seconds))
end

function KUIBattlePrepareNode:rotate(parentNode, uiName, seconds, angle)
    print("---------------->rotate", uiName, seconds, angle)

    local ui  = parentNode:getChildByName(uiName)
    ui:runAction(cc.RotateTo:create(seconds, angle))
end

function KUIBattlePrepareNode:move(parentNode, uiName, seconds, deltaX, deltaY)
    print("---------------->move", uiName, seconds, deltaX, deltaY)

    deltaX = deltaX or 0
    deltaY = deltaY or 0

    local ui = parentNode:getChildByName(uiName)
    local dstX = ui:getPositionX() + deltaX
    local dstY = ui:getPositionY() + deltaY

    ui:runAction(cc.MoveTo:create(seconds, cc.p(dstX, dstY)))
end

function KUIBattlePrepareNode:scale(parentNode, uiName, seconds, from, to)
    print("---------------->scale", uiName, seconds, from, to)

    local ui = parentNode:getChildByName(uiName)
    ui:setScale(from)
    ui:runAction(cc.ScaleTo:create(seconds, to))
end

function KUIBattlePrepareNode:loadChara()
    local mainNode = self._mainLayout
    local ui = mainNode:getChildByName("Image_cj_dialog_chara")
    -- local displayCard = KUtil.getTeamLeaderCard(self._leftTeam.teamIndex)
    -- assert(displayCard, "can not find card for displaying")
    local cardImagePath = KUtil.getCardImagePath(self._leftTeam[1], false)
    ui:loadTexture(cardImagePath)
end

function KUIBattlePrepareNode:refreshMapProgress()
    print("---------------->refreshMapProgress")

    local uiBloodBase = self._mainLayout:getChildByName("Image_cj_boss_blood_base")
    
    local mapData =  KUtil.getBattleMapData(self._zoneID, self._mapID)
    local mapSetting = KConfig:getLine("battle", self._zoneID, self._mapID, 1)
    local nBossHP = mapSetting.nBossHP 
    if nBossHP == 0 then
        uiBloodBase:setVisible(false)
        return
    end
    uiBloodBase:setVisible(true)
    
    local percent = 100 - math.floor(mapData.nProgress / (nBossHP * 100) * 100)
    if percent < 0 then percent = 0 end 
    if percent > 100 then percent = 100 end
    local uiBlood = uiBloodBase:getChildByName("LoadingBar_cj_boss_blood")
    uiBlood:setPercent(percent)    
end

function KUIBattlePrepareNode:askIfContinueFight()
    local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, self._footholdID)
    if #battleSetting.tBranches < 1 then
        print("---------------->askIfContinueFight no next") 
        return false
    end

    print("---------------->askIfContinueFight, continue") 
    return true
end

function KUIBattlePrepareNode:updateLeftTeamData()
    local leftTeam  = self._leftTeam

    local i = 1
    while true do
        local tCard = leftTeam[i]
        if not tCard then break end

        if tCard.nCurrentHP < 1 then
            table.remove(leftTeam, i)
        else
            tCard.nTotalDamage = 0
            tCard.bBrokenProtect = false
            tCard.nIndex = i
            if i == 1 and leftTeam.teamIndex == 1 then
                tCard.bBrokenProtect = true
            elseif not KUtil.IsBigBroken(tCard.nCurrentHP, tCard.nMaxHP) then
                tCard.bBrokenProtect = true
            end

            i = i + 1
        end
    end

    local skillList = leftTeam.tSkillList
    for _, oneSkill in ipairs(skillList) do
        oneSkill.nUsedTimes = 0
        oneSkill.nState = SKILL_STATE.UNUSED
    end
end

function KUIBattlePrepareNode:processFightFoothold()
    print("---------------->processFightFoothold")

    local mainNode = self._mainLayout

    self:setUIVisible(mainNode, "Image_cj_shadow", true)
    self:setText(mainNode, "Text_dialog", KUtil.getStringByKey("battle.choose.lineup"))

    local tCanChooseLineupList = self:getCanChooseLineupList()
    if #tCanChooseLineupList == 0 then
        self._leftTeam.lineup    = KConfig:getLine("lineup", 1)
    elseif #tCanChooseLineupList == 1 then
        self._leftTeam.lineup    = KConfig:getLine("lineup", tCanChooseLineupList[1])
    else
        self:showLineupUI(true)
        self:playCharaAnimationCutIn(0.3)
        self:delay(0.3)

        self:showUI(mainNode, "Button_cj_dialog", true)
        self:showUI(mainNode, "Text_dialog", true)

        self._enableTouch = true
        if self._battleType == BATTLE_TYPE.GUIDE then
            require("src/logic/KGuideEnv").addNextGuideNode()
        end
        local lineupID    = coroutine.yield() -- wait select lineup
        assert(lineupID)
        self._enableTouch = false

        self._leftTeam.lineup    = KConfig:getLine("lineup", lineupID)
        assert(self._leftTeam.lineup, lineupID)

        self:playCharaAnimationCutOff()
        self:delay(0.3)
    end

    local zoneID            = self._zoneID
    local mapID             = self._mapID
    local footholdID        = self._footholdID
    local leftTeam          = self._leftTeam
    local rightTeam         = KUtil.createRightTeamInfo(zoneID, mapID, footholdID)
    local backgroundType    = KUtil.getBattleBackgroundType(zoneID, mapID, footholdID)

    local curThread = coroutine.running()
    local function endCallback(battleResultData)
        print("---------------->battlefinished callback 2 battle_prepare", battleResultData)

        coroutine.resume(curThread, battleResultData)
    end

    leftTeam.background = backgroundType
    local battleSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
    local bStartWithNightFight = battleSetting.bStartWithNightFight

    local mapMusic, fightMusic, nightMusic = KUtil.getBattleMusicSetting(zoneID, mapID, footholdID)
    local battleInfo = 
    {
        leftTeam          = leftTeam,
        rightTeam         = rightTeam,
        mapID             = mapID,
        endCallback       = endCallback,
        beginAtNightFight = bStartWithNightFight,
        fightMusic        = fightMusic,
        nightFightMusic   = nightMusic,
        battleType        = self._battleType,
        roundList         = self._roundList,
    }

    if self._battleType == BATTLE_TYPE.GUIDE then
        if self._isUseSkill then
            battleInfo.guideUseSkill = self._guideUseSkill
        end
        if footholdID <= 2 then
            for _, card in ipairs(leftTeam) do
                card.nCurrentHP = card.nMaxHP
            end
        end
    end

    local battleNode = self._parent:addNode("Battle", battleInfo) 
    if bStartWithNightFight then
        battleNode:setBattleBackground(backgroundType, true)
    else
        battleNode:setBattleBackground(backgroundType, false)
    end

    self._mainLayout:setVisible(false)
    local battleResultData =  coroutine.yield() -- wait battlefinished
    self._mainLayout:setVisible(true)

    --    local tBattleResult = self:requestFinishBattle(zoneID, mapID, footholdID, battleResultData, leftTeam)
    local leaderCurrentHP   = leftTeam[1].nCurrentHP
    local leaderMaxHP       = leftTeam[1].nMaxHP
    local isBigBroken       = KUtil.IsBigBroken(leaderCurrentHP, leaderMaxHP) 
    KUtil.showBattleResult(zoneID, mapID, footholdID, battleResultData, leftTeam, isBigBroken)

    if isBigBroken == true then 
        self._parent:addNode("BattleFail", leftTeam)        
        coroutine.yield()
    end

    self:updateLeftTeamData()

    return self:askIfContinueFight()
end

function KUIBattlePrepareNode:processResourceFoothold()
    print("---------------->processResourceFoothold")

    require("src/network/KC2SProtocolManager"):FinishBattle(self._zoneID, self._mapID, self._footholdID)

    local curThread = coroutine.running()

    local function cb(nZoneID, nMapID, nFootholdID, tAwardList)
        coroutine.resume(curThread, tAwardList)
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:registerEvent(eventDispatch.EventType.RESOURCE_FOOTHOLD, cb)

    local tAwardList = coroutine.yield()

    eventDispatch:unregisterEvent(eventDispatch.EventType.RESOURCE_FOOTHOLD, cb)

    KSound.playTalk(KSound.TALK.GETRESOURCE, self._leftTeam[1].nTemplateID, not self._leftTeam[1].bIsRole)
    self:playCharaAnimationCutIn(0.3)

    local duration    = 1.5
    local interval    = 0.5
    local actionDelay = self:playAwardItemAnimation(tAwardList, duration, interval, self._footholdID)
    --self:delay(actionDelay)

    return true
end

function KUIBattlePrepareNode:processAccidentFoothold()
    print("---------------->processAccidentFoothold")
    require("src/network/KC2SProtocolManager"):FinishBattle(self._zoneID, self._mapID, self._footholdID)

    local curThread = coroutine.running()
    local function cb(nZoneID, nMapID, nFootholdID, tAwardList)
        coroutine.resume(curThread, tAwardList)        
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:registerEvent(eventDispatch.EventType.ACCIDENT_FOOTHOLD, cb)

    local tAwardList = coroutine.yield()
    eventDispatch:unregisterEvent(eventDispatch.EventType.ACCIDENT_FOOTHOLD, cb)

    self:playAccidentAnimation(self._footholdID)

    local duration    = 1.5
    local interval    = 0.5
    local actionDelay = self:playCostItemAnimation(tAwardList, duration, interval, self._footholdID)
    self:delay(actionDelay)    

    return true
end

function KUIBattlePrepareNode:processNoneFoothold()
    print("---------------->processNoneFoothold")

    require("src/network/KC2SProtocolManager"):FinishBattle(self._zoneID, self._mapID, self._footholdID)

    local curThread = coroutine.running()
    local function cb()
        coroutine.resume(curThread)
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:registerEvent(eventDispatch.EventType.NONE_FOOTHOLD, cb)

    coroutine.yield()

    eventDispatch:unregisterEvent(eventDispatch.EventType.NONE_FOOTHOLD, cb)
    self:delay(2.0)
    return true
end

function KUIBattlePrepareNode:processFoothold()
    print("---------------->processFoothold")

    local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, self._footholdID)
    local footholdType = FOOTHOLD_TYPE[battleSetting.szFootholdType]
    
    if footholdType == FOOTHOLD_TYPE.ENEMY or footholdType == FOOTHOLD_TYPE.BOSS then
        return self:processFightFoothold()
    end

    if footholdType == FOOTHOLD_TYPE.RESOURCE then
        return self:processResourceFoothold()
    end

    if footholdType == FOOTHOLD_TYPE.ACCIDENT then
        KSound.playEffect("onPit")
        return self:processAccidentFoothold()
    end

    if footholdType == FOOTHOLD_TYPE.NONE then
        return self:processNoneFoothold()
    end

    assert(false, "invalie FOOTHOLD_TYPE " .. battleSetting.szFootholdType)
end

function KUIBattlePrepareNode:setUIVisible(parentNode, uiName, visible)
    print("---------------->setUIVisible", uiName, visible)

    local ui = parentNode:getChildByName(uiName)
    ui:setVisible(visible)
end

function KUIBattlePrepareNode:setTouchEnabled(parentNode, uiName, enabled)
    print("---------------->setTouchEnabled", uiName, enabled)

    local ui = parentNode:getChildByName(uiName)
    ui:setTouchEnabled(enabled)
end

function KUIBattlePrepareNode:showUI(parentNode, uiName, visible)
    print("---------------->showUI", uiName, visible)

    local ui = parentNode:getChildByName(uiName)
    ui:setVisible(visible)
end

function KUIBattlePrepareNode:setText(parentNode, uiName, text)
    print("---------------->setText", uiName, text)

    local ui = parentNode:getChildByName(uiName)
    ui:setString(text)
end

function KUIBattlePrepareNode:recordUIPos(parentNode, uiName)
    print("---------------->recordUIPos", uiName)    

    local ui = parentNode:getChildByName(uiName)
    local x = ui:getPositionX()
    local y = ui:getPositionY()

    ui["POS_" .. uiName] = {x, y}
end

function KUIBattlePrepareNode:resetUIPos(parentNode, uiName)
    print("---------------->resetUIPos", uiName)

    local ui = parentNode:getChildByName(uiName)
    local x, y = unpack(ui["POS_" .. uiName], 1, table.maxn(ui["POS_" .. uiName]))
    ui:setPositionX(x)
    ui:setPositionX(y)
end

function KUIBattlePrepareNode:recordUIRotation(parentNode, uiName)
    print("---------------->recordUIRotation", uiName)

    local ui = parentNode:getChildByName(uiName)
    local rotation = ui:getRotationSkewX()
    ui["ROT_" ..uiName] = rotation
end

function KUIBattlePrepareNode:resetUIRotation(parentNode, uiName)
    print("---------------->resetUIRotation", uiName)

    local ui = parentNode:getChildByName(uiName)
    local rotation = ui["ROT_" ..uiName]
    ui:setRotation(rotation)
end

function KUIBattlePrepareNode:recordUIScale(parentNode, uiName)
    print("---------------->recordUIScale", uiName)

    local ui = parentNode:getChildByName(uiName)
    local scale = ui:getScale()
    ui["SCA_" ..uiName] = scale
end

function KUIBattlePrepareNode:resetUIScale(parentNode, uiName)
    print("---------------->resetUIScale", uiName)

    local ui = parentNode:getChildByName(uiName)
    local scale = ui["SCA_" ..uiName]
    ui:setScale(scale)
end

function KUIBattlePrepareNode:recordUIAlpha(parentNode, uiName)
    print("---------------->recordUIAlpha", uiName)

    local ui = parentNode:getChildByName(uiName)
    local opacity = ui:getOpacity()
    ui["ALP_" ..uiName] = opacity
end

function KUIBattlePrepareNode:resetUIAlpha(parentNode, uiName)
    print("---------------->resetUIAlpha", uiName)

    local ui = parentNode:getChildByName(uiName)
    local opacity = ui["ALP_" ..uiName]
    ui:setOpacity(opacity)    
end

function KUIBattlePrepareNode:recordSomeUIData()
    print("---------------->recordSomeUIData")

    local mainNode  = self._mainLayout
    local mapNode   = self.mapNode

    self:recordUIPos(mainNode, "Image_cj_dialog_chara")
    self:recordUIAlpha(mainNode, "Image_cj_dialog_chara")

    self:recordUIScale(mainNode, "ProjectNode_compass")
    self:recordUIScale(mainNode, "ProjectNode_compass_pointer")
end

function KUIBattlePrepareNode:resetSomeUI()
    print("---------------->resetSomeUI")

    local mainNode  = self._mainLayout
    local mapNode   = self.mapNode

    self:resetUIPos(mainNode, "Image_cj_dialog_chara")
    self:resetUIAlpha(mainNode, "Image_cj_dialog_chara")

    self:resetUIScale(mainNode, "ProjectNode_compass")
    self:resetUIScale(mainNode, "ProjectNode_compass_pointer")

    self:showUI(mainNode, "ProjectNode_compass", false)
    self:showUI(mainNode, "ProjectNode_compass_pointer", false)

    self:setText(mainNode, "Text_dialog", "")
    self:showUI(mainNode, "Button_cj_dialog", false)

    self:stopActionByName("footholdAction" .. self._footholdID)

    self:setTouchEnabled(mainNode, "Button_global", false)
    self:showUI(mainNode, "ProjectNode_compass_girl", false)
end

function KUIBattlePrepareNode:actionThread()
    print("---------------->actionThread")

    local mainNode = self._mainLayout

    self:recordSomeUIData()

    while true do
        local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, self._footholdID)
        if #battleSetting.tBranches == 0 then
            print("---------------->actionThread break no next branch")
            break
        end

        self:resetSomeUI()

        self:loadChara()
        self:showLineupUI(false)

        self:refreshMapProgress()

        self:showUI(mainNode, "Image_cj_shadow", false)
        self:showUI(mainNode, "ProjectNode_compass", false)
        self:showUI(mainNode, "ProjectNode_compass_pointer", false)

        self:delay(1)

        self:playCharaAnimationCutOff()

        if #battleSetting.tBranches > 1 then
            self:setUIVisible(mainNode, "ProjectNode_compass", true)
            self:setUIVisible(mainNode, "ProjectNode_compass_pointer", true)

            self:scale(mainNode, "ProjectNode_compass", 0.3, 3, 1)
            self:scale(mainNode, "ProjectNode_compass_pointer", 0.3, 3, 1)

            self:fadeIn(mainNode, "ProjectNode_compass", 1)
            self:fadeIn(mainNode, "ProjectNode_compass_pointer", 1)
        end

        self:delay(0.3)

        self:randomTargetFoothold()

        if not self:processFoothold() then
            break
        end
    end

    local officeScene = require("src/ui/office/KUIOfficeScene").create("BattlePrepare")
    KUtil.replaceSceneAndRemoveAllTexture(officeScene)
end

function KUIBattlePrepareNode:checkFootholdUIExist(footholdID)
    local mapNode       = self.mapNode
    local footholdUI    = mapNode:getChildByName("ProjectNode_" .. footholdID)
    assert(footholdUI, "ProjectNode_" .. footholdID .. " not found~")
end

function KUIBattlePrepareNode:refreshMapWayAndFoothold()
    local zoneID    = self._zoneID
    local mapID     = self._mapID
    local mapData =  KUtil.getBattleMapData(self._zoneID, self._mapID)
    local finishFoothold = mapData.tFinishFoothold

    local processedFoothold = {}
    local toProcessFoothold = {1}
    while #toProcessFoothold > 0 do
        local footholdID = table.remove(toProcessFoothold, 1)
        processedFoothold[footholdID] = true
        local currentFootholdIsFinished = HArray.FindFirstByValue(finishFoothold, footholdID) ~= nil
        if currentFootholdIsFinished then 
            self:showFootholdNode(footholdID)
        else
            self:checkFootholdUIExist(footholdID)
        end

        local footholdSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)

        for _, v in ipairs(footholdSetting.tBranches) do
            local footholdFinished  = HArray.FindFirstByValue(finishFoothold, v[1]) ~= nil 
            local wayFinished       = currentFootholdIsFinished and footholdFinished 
            self:showWay(footholdID, v[1], wayFinished)

            if not processedFoothold[v[1]] and not HArray.FindFirstByValue(toProcessFoothold, v[1]) then
                table.insert(toProcessFoothold, v[1])
            end
        end
    end
end

function KUIBattlePrepareNode:refreshNodeAndWay()
    self:refreshMapWayAndFoothold()

    local mapNode = self.mapNode
    local tankUI = mapNode:getChildByName("ProjectNode_tank")
    local footholdUI = mapNode:getChildByName("ProjectNode_" .. self._footholdID)
    local posX = footholdUI:getPositionX()
    local posY = footholdUI:getPositionY()
    tankUI:setPositionX(posX)
    tankUI:setPositionY(posY)
end

function KUIBattlePrepareNode:initMapActions()
    local mapNode = self.mapNode
    local zoneID    = self._zoneID
    local mapID     = self._mapID

    local action, ui    = KUtil.initAction(mapNode, "ProjectNode_tank", "res/ui/animation_node/ani_lanch_tank.csb")
    self.tankAction     = action

    local accidentUI     = cc.CSLoader:createNode("res/ui/animation_node/ani_baozha.csb")
    local accidentAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_baozha.csb") 
    local accidentScale  = 0.5
    mapNode:addChild(accidentUI)
    accidentUI:stopAllActions()
    accidentUI:runAction(accidentAction)
    accidentUI:setScaleX(accidentScale)
    accidentUI:setScaleY(accidentScale)
    accidentAction:gotoFrameAndPause(accidentAction:getDuration())
    self.accidentUI     = accidentUI
    self.accidentAction = accidentAction

    local processedFoothold = {}
    local toProcessFoothold = {1}
    while #toProcessFoothold > 0 do
        local footholdID = table.remove(toProcessFoothold, 1)
        processedFoothold[footholdID] = true

        local footholdSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
        local footholdType = FOOTHOLD_TYPE[footholdSetting.szFootholdType]
        local csbFile = footType2CSBFile[footholdType]

        local action, ui = KUtil.initAction(mapNode, "ProjectNode_" .. footholdID, csbFile)
        self["footholdAction" .. footholdID]  = action

        for _, v in ipairs(footholdSetting.tBranches) do
            if not processedFoothold[v[1]] then
                HArray.UniqueInsertByValue(toProcessFoothold, v[1])
            end
        end
    end
end

function KUIBattlePrepareNode:initLineupUI()
    print("------------>initLineupUI", visible)

    local mainNode = self._mainLayout
    local i = 0
    while true do
        i = i + 1
        local lineupUI = mainNode:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end
        lineupUI:setVisible(false)
        local lineupSetting = KConfig:getLine("lineup", i)
        self:setText(lineupUI, "Text_lineup", lineupSetting.szName)
        self:setText(lineupUI, "Text_descrition", lineupSetting.szDescription)
    end    
end

function KUIBattlePrepareNode:initMap()
    print("---------------->initMap", self.mapNode)

    if self.mapNode then return end

    local mapSetting = KConfig:getLine("battle", self._zoneID, self._mapID, 1)
    local mapNode = cc.CSLoader:createNode("res/ui/animation_instance/ani_instance_node/" .. mapSetting.szMapPath)
    local curMap = self._mainLayout:getChildByName("Image_cj_prepare_map")

    curMap:addChild(mapNode)
    self.mapNode = mapNode

    self:refreshNodeAndWay()
    self:initLineupUI()
    self:initMapActions()
end

function KUIBattlePrepareNode:initActions()
    print("---------------->initActions")

    local mainNode = self._mainLayout

    local action = KUtil.initAction(mainNode, "ProjectNode_compass", "res/ui/battle_compass.csb")
    self.compassAction = action

    local action = KUtil.initAction(mainNode, "ProjectNode_compass_pointer", "res/ui/battle_compass_pointer.csb")
    self.compassPointerAction = action

    local action = KUtil.initAction(mainNode, "ProjectNode_compass_girl", "res/ui/animation_node/ani_compass_girl.csb")
    self.compassGirlAction = action
    assert(self.compassGirlAction)
end

function KUIBattlePrepareNode:tipsActions()
    local mainNode = self._mainLayout
    local footholdID                = self._footholdID
    local battleSetting             = KUtil.getBattleSetting(self._zoneID, self._mapID, footholdID)
    local szTips                    = battleSetting.szTips
    local projectNodeCompassGirl    = mainNode:getChildByName("ProjectNode_compass_girl")
    local panelCompassGirl          = projectNodeCompassGirl:getChildByName("Panel_compass_girl")
    if szTips == "" then 
        projectNodeCompassGirl:setVisible(false)
        return 
    end
    projectNodeCompassGirl:setVisible(true)
    self.compassGirlAction:gotoFrameAndPlay(0, 60, false)
    local imageSpriteDialog         = projectNodeCompassGirl:getChildByName("Image_sprite_dialog")
    local tipsText                  = imageSpriteDialog:getChildByName("Text_1")
    tipsText:setString(szTips)
        
    local randomValue = math.random(1, 3)
    for imageID = 1, 3 do
        local imageBase = panelCompassGirl:getChildByName("Image_compass_0" .. imageID)
        imageBase:setVisible(randomValue == imageID)
    end
end

function KUIBattlePrepareNode:onInitUI()
    self:initMap()
    self:initActions()
    self:playMapBackGroundMusic(true)
end

function KUIBattlePrepareNode:refreshUI()
    if self._thread then
        return
    end

    self._enableTouch = false
    self._thread = coroutine.create(self.actionThread)
    print("---------------->refreshUI resume thread", coroutine.resume(self._thread, self))
end

function KUIBattlePrepareNode:registerLineupTouchEvent()
    local i = 0
    while true do
        i = i + 1
        local lineupUI = self._mainLayout:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end

        local lineupID = i
        lineupUI:addTouchEventListener(function (sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("-----> buttonLineup" .. lineupID .. " clicked!")
            if not self._enableTouch then return end
            KSound.playEffect("click")
            coroutine.resume(self._thread, lineupID)
        end
        )
    end
end

function KUIBattlePrepareNode:registerAllTouchEvent()
    self:registerLineupTouchEvent()

    local mainNode = self._mainLayout
    local globalButton = mainNode:getChildByName("Button_global")
    local function cb(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> globalButtonClick!" .. tostring(self._enableTouch))
        if not self._enableTouch then return end
        coroutine.resume(self._thread)
    end
    globalButton:addTouchEventListener(cb)
end

function KUIBattlePrepareNode:resume(param)
    coroutine.resume(self._thread, param)
end

function KUIBattlePrepareNode:registerAllCustomEvent()
end

function KUIBattlePrepareNode:runEnterAction()
end

return KUIBattlePrepareNode
