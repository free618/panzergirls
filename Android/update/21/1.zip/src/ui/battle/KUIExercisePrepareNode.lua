--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExercisePrepareNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/9   16:21
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_MAP_INDEX = 6
local MAX_LOAD_TIME = 15
local KUIExercisePrepareNode = class(
    "KUIExercisePrepareNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExercisePrepareNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._teamIndex      = nil
    self._battleRoleID   = nil
    self._battleData     = nil
    self._isEnterBattle  = false
    self._playFinish     = false
    self._isClose        = false
    self._isLoadind      = false
    self._beginLoadTime  = 0
end

function KUIExercisePrepareNode.create(owner, userData)
    local currentNode = KUIExercisePrepareNode.new()

    currentNode._parent       = owner
    currentNode._uiPath       = "res/ui/battle_prepare.csb"
    currentNode._teamIndex    = userData.teamIndex
    currentNode._battleRoleID = userData.roleID
    currentNode:init()

    KSound.playMusic("fight")

    return currentNode
end

local function getRightListMaxLevel(rightTeam)
    local maxLevel = 0
    for _, cardInfo in pairs(rightTeam) do
        maxLevel = math.max(cardInfo.nLevel, maxLevel)
    end
    return maxLevel
end

function KUIExercisePrepareNode:refreshDisenableArea()
    local mainNode           = self._mainLayout 
    local projectNodeCompass = mainNode:getChildByName("ProjectNode_compass")
    projectNodeCompass:setVisible(false)

    local projectNodeCompassPiont = mainNode:getChildByName("ProjectNode_compass_pointer")
    projectNodeCompassPiont:setVisible(false)

    local projectNodeGirl = mainNode:getChildByName("ProjectNode_compass_girl")
    projectNodeGirl:setVisible(false)
    
    local panelBlood = mainNode:getChildByName("Image_cj_boss_blood_base")
    panelBlood:setVisible(false)

    local imageShadow = mainNode:getChildByName("Image_cj_shadow")
    imageShadow:setVisible(false)
end

function KUIExercisePrepareNode:refreshPanel()
    local mainNode   = self._mainLayout
    local imageChara = mainNode:getChildByName("Image_cj_dialog_chara")
    local displayCard = KUtil.getTeamLeaderCard(self._teamIndex)
    assert(displayCard, "can not find card for displaying")

    local cardImagePath = KUtil.getCardImagePath(displayCard, false)
    imageChara:loadTexture(cardImagePath)

    local textDialog   = mainNode:getChildByName("Text_dialog")
    textDialog:setString(KUtil.getStringByKey("battle.choose.lineup"))
end

local function showDialog(self, isShow)
    local mainNode     = self._mainLayout
    local textDialog   = mainNode:getChildByName("Text_dialog")
    textDialog:setVisible(isShow)

    local buttonDialog = mainNode:getChildByName("Button_cj_dialog")
    buttonDialog:setVisible(isShow)
end

function KUIExercisePrepareNode:playCharaAnimationCutIn(duration)
    local mainNode     = self._mainLayout
    local imageChara   = mainNode:getChildByName("Image_cj_dialog_chara")
    local targetPosX   = imageChara:getPositionX()
    local targetPosY   = imageChara:getPositionY()
    local visibleSize  = cc.Director:getInstance():getVisibleSize()
    local moveDistance = visibleSize.width * 0.54

    imageChara:setPositionX(targetPosX - moveDistance)
    imageChara:setPositionY(targetPosY)
    showDialog(self, false)

    local function delayShowDialog()
        showDialog(self, true)
    end

    imageChara:runAction(cc.Sequence:create(
        cc.MoveBy:create(duration, cc.p(moveDistance, 0)),
        cc.FadeIn:create(duration),
        cc.CallFunc:create(delayShowDialog)
    ))
    return duration
end

local function openReportPanel(self, nBattleRoleID, nResultType, tCardExpAward, tCardFeeling)
    if not self._battleData then return end

    local endCallback = function()
        self._playFinish = true
    end

    local clickPanelCall = function(nTemplateID)
        if not self._playFinish then return end
        if self._isClose then return end

        self._isClose = true
        KSound.playTalk(KSound.TALK.FINISHFIGHT, nTemplateID)
        local officeScene = require("src/ui/office/KUIOfficeScene").create("ExercisePrepareNode close")
        KUtil.replaceSceneAndRemoveAllTexture(officeScene)

        local userData = {oldPanel = true,}
        officeScene:addNode("ExerciseRoleList", userData)
    end

    local battleResultData = self._battleData
    local battleReportNode = self._parent:addNode("BattleReport")
    local reportData = 
    {
        zoneID                = 0,
        mapID                 = 0,
        footholdID            = 0,
        endCallback           = endCallback,
        cardExpAward          = tCardExpAward,
        awardList             = {},
        isNewCard             = false,
        roleExp               = 0,
        resultType            = nResultType,
        srcDamagePercent      = battleResultData.nSrcDamagePercent,
        dstDamagePercent      = battleResultData.nDstDamagePercent,
        cardExpList           = KUtil.calculateCardList(tCardExpAward),
        srcTeam               = KUtil.createLeftTeamInfo(self._teamIndex),
        dstTeam               = battleResultData.nDstTeam,
        showIfContinueFightUI = false,
        clickPanelCall        = clickPanelCall,
        cardFeeling           = tCardFeeling,
        battleType            = BATTLE_TYPE.EXERCISE
    }

    battleReportNode:setReportData(reportData)
    battleReportNode:refreshUI() 
end

local function enterBattle(self, lineupID)
    local mainNode = self._mainLayout
    local cardList, roleName, teamName, roleLevel = KUtil.getExerciseBattleDetail(self._battleRoleID)
    KUtil.resetCardListCurrentHP(cardList)
    
    if not (teamName and string.len(teamName) > 0) then 
        teamName = KUtil.getStringByKey("common.team") .. "1"
    end

    local leftTeam       = KUtil.createLeftTeamInfo(self._teamIndex)
    local rightTeam      = KUtil.createRightRoleInfo(cardList, roleName, teamName, roleLevel)
    local backgroundType = math.random(1, MAX_MAP_INDEX)
    leftTeam.lineup      = KConfig:getLine("lineup", lineupID)
    leftTeam.background  = backgroundType

    local function endCallback(battleResultData)
        self._battleData    = battleResultData
        local nResultType   = battleResultData.nType
        local nMVPCardID    = battleResultData.nMVPCardID
        local tKillMonsters = battleResultData.tKillMonsters
        local tTeamData     = KUtil.getBattleResultTeamData(leftTeam)
        local nMaxLevel     = KUtil.getRightListMaxLevel(rightTeam)
        require("src/network/KC2SProtocolManager"):finishExerciseBattle(self._battleRoleID, nResultType, tTeamData, nMVPCardID, nMaxLevel, tKillMonsters)

        self._beginLoadTime = KUtil.getLocalTime()
        self._isLoadind     = true
    end
    
    local battleInfo = 
    {
        leftTeam        = leftTeam,
        rightTeam       = rightTeam,
        endCallback     = endCallback,
        battleType      = BATTLE_TYPE.EXERCISE,
    }
    local battleNode = self._parent:addNode("Battle", battleInfo)
    battleNode:setBattleBackground(backgroundType, false)
    battleNode:refreshDisenableArea()
    mainNode:setVisible(false)
end

local function enterBattleAnimation(self, lineupID)
    if self._isEnterBattle then return end
    self._isEnterBattle = true

    local mainNode     = self._mainLayout
    local visibleSize  = cc.Director:getInstance():getVisibleSize()
    local moveDistance = visibleSize.width * 1.0 
    local duration = 0.3

    local imageChara = mainNode:getChildByName("Image_cj_dialog_chara")
    imageChara:setOpacity(1)
    imageChara:runAction(cc.FadeIn:create(duration))

    local targetPosX = imageChara:getPositionX() - moveDistance
    local targetPosY = imageChara:getPositionY()
    imageChara:runAction(cc.MoveTo:create(duration, cc.p(targetPosX, targetPosY)))

   showDialog(self, false)

    local function func()
         enterBattle(self, lineupID)
    end
    delayExecute(mainNode, func, duration)
end

function KUIExercisePrepareNode:initLineupUI()
    local mainNode = self._mainLayout
    local i = 0
    while true do
        i = i + 1
        local lineupUI = mainNode:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end
        local lineupSetting = KConfig:getLine("lineup", i)
        local textLineup    = lineupUI:getChildByName("Text_lineup")
        textLineup:setString(lineupSetting.szName)

        local textDescrition    = lineupUI:getChildByName("Text_descrition")
        textDescrition:setString(lineupSetting.szDescription)
    end    
end

function KUIExercisePrepareNode:activate(nowTime)
    if self._isLoadind then
        if nowTime - self._beginLoadTime > MAX_LOAD_TIME then
            local officeScene = require("src/ui/office/KUIOfficeScene").create("ExercisePrepareNode activate")
            KUtil.replaceSceneAndRemoveAllTexture(officeScene)
            self._isLoadind = false
        end
    end
end

function KUIExercisePrepareNode:refreshUI()
    self:refreshDisenableArea()
    self:refreshPanel()
    self:initLineupUI()
    self:playCharaAnimationCutIn(0.3)
end

function KUIExercisePrepareNode:registerLineupTouchEvent()
     local i = 0
    while true do
        i = i + 1
        local lineupUI = self._mainLayout:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end

        local lineupID = i
        lineupUI:addTouchEventListener(function (sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("-----> buttonLineup" .. lineupID .. " clicked!")
            KSound.playEffect("click")
            enterBattleAnimation(self, lineupID)
        end
        )
    end
end

function KUIExercisePrepareNode:registerAllTouchEvent()
    self:registerLineupTouchEvent()
end

function KUIExercisePrepareNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBattleFinish(nBattleRoleID, nResultType, tCardExpAward, tCardFeeling)
        cclog("onEvent ------------> onBattleFinish")
        self._isLoadind = false
        openReportPanel(self, nBattleRoleID, nResultType, tCardExpAward, tCardFeeling)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EXERCISE_BATTLE_FINISH, onBattleFinish)
    
end

function KUIExercisePrepareNode:getEnterAction()
end

return KUIExercisePrepareNode
