--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExpeditionPrepareNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/29   16:21
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_MAP_INDEX = 6
local MAX_LOAD_TIME = 15
local KUIExpeditionPrepareNode = class(
    "KUIExpeditionPrepareNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExpeditionPrepareNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._battleData     = nil
    self._battleResult   = nil
    self._isEnterBattle  = false
    self._playFinish     = false
    self._isClose        = false
    self._isLoadind      = false
    self._beginLoadTime  = 0
    self._teamIndex      = 1
end

function KUIExpeditionPrepareNode.create(owner, userData)
    local currentNode = KUIExpeditionPrepareNode.new()

    currentNode._parent       = owner
    currentNode._uiPath       = "res/ui/battle_prepare.csb"
    currentNode._battleData   = userData.battleData
    currentNode:init()

    KSound.playMusic("fight")

    return currentNode
end

local function refreshDisenableArea(self)
    local mainNode           = self._mainLayout 
    local projectNodeCompass = mainNode:getChildByName("ProjectNode_compass")
    projectNodeCompass:setVisible(false)

    local projectNodeCompassPiont = mainNode:getChildByName("ProjectNode_compass_pointer")
    projectNodeCompassPiont:setVisible(false)

    local projectNodeGirl = mainNode:getChildByName("ProjectNode_compass_girl")
    projectNodeGirl:setVisible(false)
    
    local panelBlood = mainNode:getChildByName("Image_cj_boss_blood_base")
    panelBlood:setVisible(false)

    local imageShadow = mainNode:getChildByName("Image_cj_shadow")
    imageShadow:setVisible(false)
end

local function refreshPanel(self)
    local mainNode    = self._mainLayout
    local imageChara  = mainNode:getChildByName("Image_cj_dialog_chara")
    local displayCard = KUtil.getTeamLeaderCard(1)
    assert(displayCard, "can not find card for displaying")

    local cardImagePath = KUtil.getCardImagePath(displayCard, false)
    imageChara:loadTexture(cardImagePath)

    local textDialog   = mainNode:getChildByName("Text_dialog")
    textDialog:setString(KUtil.getStringByKey("battle.choose.lineup"))
end

local function showDialog(self, isShow)
    local mainNode     = self._mainLayout
    local textDialog   = mainNode:getChildByName("Text_dialog")
    textDialog:setVisible(isShow)

    local buttonDialog = mainNode:getChildByName("Button_cj_dialog")
    buttonDialog:setVisible(isShow)
end

local function playCharaAnimationCutIn(self, duration)
    local mainNode     = self._mainLayout
    local imageChara   = mainNode:getChildByName("Image_cj_dialog_chara")
    local targetPosX   = imageChara:getPositionX()
    local targetPosY   = imageChara:getPositionY()
    local visibleSize  = cc.Director:getInstance():getVisibleSize()
    local moveDistance = visibleSize.width * 0.54

    imageChara:setPositionX(targetPosX - moveDistance)
    imageChara:setPositionY(targetPosY)
    showDialog(self, false)

    local function delayShowDialog()
        showDialog(self, true)
    end

    imageChara:runAction(cc.Sequence:create(
        cc.MoveBy:create(duration, cc.p(moveDistance, 0)),
        cc.FadeIn:create(duration),
        cc.CallFunc:create(delayShowDialog)
    ))
    return duration
end

local function openReportPanel(self, nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes, tCardExpAward, tCardFeeling)
    if not self._battleResult then return end

    local function closePanel(nTemplateID)
        if self._isClose then return end

        self._isClose = true
        KSound.playTalk(KSound.TALK.FINISHFIGHT, nTemplateID)
        local officeScene = require("src/ui/office/KUIOfficeScene").create()
        KUtil.replaceSceneAndRemoveAllTexture(officeScene)

        local function delayAddNode()
            local userData = {oldPanel = true,}
            officeScene:addNode("Plunder", userData)
        end
        delayExecute(officeScene, delayAddNode, 0)
    end

    local openRewardPanel = function(nTemplateID)
        local tDesciptionList = {}
        local white  = cc.c3b(60, 71, 114)
        local yellow = cc.c3b(255, 87, 87)
        local szRoleName = self._battleData.szName
        local text = KUtil.getStringByKey("expedition.fightTip1")
        table.insert(tDesciptionList, {text = text, color = white})
    
        table.insert(tDesciptionList, {text = szRoleName, color = yellow})

        local text = KUtil.getStringByKey("expedition.fightTip2")
        table.insert(tDesciptionList, {text = text, color = white})  

        local userData = {tResultList = tExtraResource, tDesciptionList = tDesciptionList}
        local rewardPanel = self._parent:addNode("PlunderReward", userData) 
        local callback = function()
            local card = KUtil.getTeamLeaderCard(self._teamIndex)
            closePanel(card.nTemplateID)
        end
        rewardPanel:setCallback(callback)
    end

    local endCallback = function(nTemplateID)
        local bWin = nResultType >= FIGHT_SCORE.B
        if bWin then
            openRewardPanel(nTemplateID)
        else
            self._playFinish = true
        end
    end

    local clickPanelCall = function(nTemplateID)
        if not self._playFinish then return end
        closePanel(nTemplateID)
    end

    local battleResultData = self._battleResult
    local battleReportNode = self._parent:addNode("BattleReport")
    local reportData = 
    {
        zoneID                = 0,
        mapID                 = 0,
        footholdID            = 0,
        endCallback           = endCallback,
        cardExpAward          = tCardExpAward,
        awardList             = {},
        isNewCard             = false,
        roleExp               = 0,
        resultType            = nResultType,
        srcDamagePercent      = battleResultData.nSrcDamagePercent,
        dstDamagePercent      = battleResultData.nDstDamagePercent,
        cardExpList           = KUtil.calculateCardList(tCardExpAward),
        srcTeam               = KUtil.createLeftTeamInfo(self._teamIndex),
        dstTeam               = battleResultData.nDstTeam,
        showIfContinueFightUI = false,
        clickPanelCall        = clickPanelCall,
        cardFeeling           = tCardFeeling,
        battleType            = BATTLE_TYPE.EXPEDITION
    }
    assert(reportData.srcTeam)
    battleReportNode:setReportData(reportData)
    battleReportNode:refreshUI() 
end

local function enterBattle(self, lineupID)
    local mainNode = self._mainLayout

    local cardList, roleName, teamName, roleLevel = KUtil.getExpeditionBattleDetail(self._battleData)
    KUtil.resetCardListCurrentHP(cardList)
    
    local teamData = self._battleData.tOne.teamdata
    if not (teamName and string.len(teamName) > 0) then 
        teamName = KUtil.getStringByKey("common.team") .. teamData.tOneTeam.nIndex
    end

    local leftTeam       = KUtil.createLeftTeamInfo(self._teamIndex)
    local rightTeam      = KUtil.createRightRoleInfo(cardList, roleName, teamName, roleLevel)
    local backgroundType = math.random(1, MAX_MAP_INDEX)
    leftTeam.lineup      = KConfig:getLine("lineup", lineupID)
    leftTeam.background  = backgroundType

    local function endCallback(battleResultData)
        self._battleResult   = battleResultData
        local nResultType    = battleResultData.nType
        local tKillMonsters  = battleResultData.tKillMonsters
        local roleDetail     = self._battleData.tOne
        local roleID         = roleDetail.roleid
        local expeditionType = roleDetail.expeditiontype
        local expeditionID   = roleDetail.expeditionid
        local tTeamData      = KUtil.getBattleResultTeamData(leftTeam)
        local nMVPCardID     = battleResultData.nMVPCardID
        require("src/network/KC2SProtocolManager"):requestExpeditionFinishBattle(nResultType, roleID, expeditionType, expeditionID, tTeamData, nMVPCardID, tKillMonsters)

        self._beginLoadTime = KUtil.getLocalTime()
        self._isLoadind     = true
    end

    local battleInfo = 
    {
        leftTeam        = leftTeam,
        rightTeam       = rightTeam,
        endCallback     = endCallback,
        battleType      = BATTLE_TYPE.EXPEDITION,
    }
    local battleNode = self._parent:addNode("Battle", battleInfo)
    battleNode:setBattleBackground(backgroundType, false)
    battleNode:refreshDisenableArea()
    mainNode:setVisible(false)
end

local function enterBattleAnimation(self, lineupID)
    if self._isEnterBattle then return end
    self._isEnterBattle = true

    local mainNode     = self._mainLayout
    local visibleSize  = cc.Director:getInstance():getVisibleSize()
    local moveDistance = visibleSize.width * 1.0
    local duration = 0.3

    local imageChara = mainNode:getChildByName("Image_cj_dialog_chara")
    imageChara:setOpacity(1)
    imageChara:runAction(cc.FadeIn:create(duration))

    local targetPosX = imageChara:getPositionX() - moveDistance
    local targetPosY = imageChara:getPositionY()
    imageChara:runAction(cc.MoveTo:create(duration, cc.p(targetPosX, targetPosY)))

    showDialog(self, false)
    
    local function func()
         enterBattle(self, lineupID)
    end
    delayExecute(mainNode, func, duration)
end

function KUIExpeditionPrepareNode:activate(nowTime)
    if self._isLoadind then
        if nowTime - self._beginLoadTime > MAX_LOAD_TIME then
            local officeScene = require("src/ui/office/KUIOfficeScene").create()
            KUtil.replaceSceneAndRemoveAllTexture(officeScene)
            self._isLoadind = false
        end
    end
end

function KUIExpeditionPrepareNode:initLineupUI()
    local mainNode = self._mainLayout
    local i = 0
    while true do
        i = i + 1
        local lineupUI = mainNode:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end
        local lineupSetting = KConfig:getLine("lineup", i)
        local textLineup    = lineupUI:getChildByName("Text_lineup")
        textLineup:setString(lineupSetting.szName)

        local textDescrition    = lineupUI:getChildByName("Text_descrition")
        textDescrition:setString(lineupSetting.szDescription)
    end    
end

function KUIExpeditionPrepareNode:refreshUI()
    refreshDisenableArea(self)
    refreshPanel(self)
    self:initLineupUI()
    playCharaAnimationCutIn(self, 0.3)
end

function KUIExpeditionPrepareNode:registerLineupTouchEvent()
     local i = 0
    while true do
        i = i + 1
        local lineupUI = self._mainLayout:getChildByName("Button_lineup_" .. i)
        if not lineupUI then break end

        local lineupID = i
        lineupUI:addTouchEventListener(function (sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("-----> buttonLineup" .. lineupID .. " clicked!")
            KSound.playEffect("click")
            enterBattleAnimation(self, lineupID)
        end
        )
    end
end

function KUIExpeditionPrepareNode:registerAllTouchEvent()
    self:registerLineupTouchEvent()
end

function KUIExpeditionPrepareNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBattleFinish(nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes, tCardExpAward, tCardFeeling)
        cclog("onEvent ------------> onBattleFinish")
        self._isLoadind = false
        openReportPanel(self, nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes, tCardExpAward, tCardFeeling)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_PLUNDER_BATTLE_FINISH, onBattleFinish)
    
end

function KUIExpeditionPrepareNode:getEnterAction()
end

return KUIExpeditionPrepareNode
