--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowConfirmationNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/08/21   16:23
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  *********************************************************************


local ENTER_ACTION_DURATION = 0.3
local CENTER_POSITION       = cc.p(0, 0)

local KUIShowConfirmationNode = class(
    "KUIShowConfirmationNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowConfirmationNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._confirmNum    = 0
end

function KUIShowConfirmationNode.create(owner)
    local currentNode = KUIShowConfirmationNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_confirm.csb"
    currentNode:init()

    return currentNode
end

function KUIShowConfirmationNode:setConfirmationInfo(confirmationInfo)
    cclog("--------------------> KUIShowConfirmationNode:setConfirmationInfo : %s", confirmationInfo)
    local mainNode        = self._mainLayout
    local imageConfirm    = mainNode:getChildByName("Image_confirm")
    local textInformation = imageConfirm:getChildByName("Text_information")

    textInformation:setString((string.gsub(confirmationInfo, "\\n", "\n")))
end

function KUIShowConfirmationNode:onConfirmClick()
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local buttonConfirm = imageConfirm:getChildByName("Button_confirm")
    local textInformation = imageConfirm:getChildByName("Text_information")
    buttonConfirm:setTouchEnabled(false)

    local text = textInformation:getString()
    self._confirmNum = self._confirmNum + 1
    local num  = self._confirmNum
    
    if self._fnConfirm then
        self._fnConfirm()
        self._fnConfirm = nil
    end

    if tolua.isnull(self) then
        assert(false, string.format("%s, %s, %d", type(self), text, num))
    end

    self:removeFromParent()
end

function KUIShowConfirmationNode:onCancelClick()
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local buttonCancel  = imageConfirm:getChildByName("Button_cancel")
    buttonCancel:setTouchEnabled(false)

    if self._fnCancel then
        self._fnCancel()
        self._fnCancel = nil
    end
    
    if tolua.isnull(self) then
        assert(false, string.format("%s, %d", type(self), self._confirmNum))
    end
    
    self:removeFromParent()
end

function KUIShowConfirmationNode:setOnTouchEvent(fnConfirm, fnCancel)
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local buttonConfirm = imageConfirm:getChildByName("Button_confirm")
    self._fnConfirm     = fnConfirm
    self._fnCancel      = fnCancel
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~")
            self:onConfirmClick()
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel = imageConfirm:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCancelClick~")
            self:onCancelClick()
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)
end

function KUIShowConfirmationNode:refreshUI()
    local mainNode      = self._mainLayout
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    mainNode:setPosition(cc.p(0, visibleSize.height))

    cclog("----------> KUIShowConfirmationNode:refreshUI")
end

function KUIShowConfirmationNode:runEnterAction()
    local mainNode           = self._mainLayout
    local actionMoveToCenter = cc.MoveTo:create(ENTER_ACTION_DURATION, CENTER_POSITION)
    mainNode:runAction(actionMoveToCenter)

    cclog("----------> KUIShowConfirmationNode:runEnterAction")
end

return KUIShowConfirmationNode
