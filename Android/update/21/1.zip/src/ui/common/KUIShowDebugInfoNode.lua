--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowDebugInfoNode.lua
--  Creator     : SunXun
--  Date        : 2015/08/31   16:23
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_DEBUG_INFO_COUNT  = 20

local KUIShowDebugInfoNode = class(
    "KUIShowErrorNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowDebugInfoNode:ctor()
    self._debugInfo = {}
end

function KUIShowDebugInfoNode.create(owner)
    local currentNode = KUIShowDebugInfoNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_debug_info.csb"
    currentNode:init()

    return currentNode
end

function KUIShowDebugInfoNode:addDebugInfo(debugInfo)
    local mainNode          = self._mainLayout
    local imageDebugInfo    = mainNode:getChildByName("Image_debug_information")
    local textDebugInfo     = imageDebugInfo:getChildByName("Text_debug_information")
    
    local singleDebugInfo = debugInfo .. "\n"
    table.insert(self._debugInfo, singleDebugInfo)
    
    if #self._debugInfo > MAX_DEBUG_INFO_COUNT then 
        table.remove(self._debugInfo, 1)
    end
    
    local currentDebugInfo = ""
    for k, v in ipairs(self._debugInfo) do
        currentDebugInfo = currentDebugInfo .. v
    end
    textDebugInfo:setString(currentDebugInfo)
    --cclog("----------> addDebugInfo : %s", debugInfo)
end

function KUIShowDebugInfoNode:refreshUI()
    local mainNode = self._mainLayout
    local imageDebugInfo    = mainNode:getChildByName("Image_debug_information")
    imageDebugInfo:setVisible(false)
end

function KUIShowDebugInfoNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local imageDebugInfo    = mainNode:getChildByName("Image_debug_information")
    
    local buttonDebugOpen = mainNode:getChildByName("Button_debug_open")
    local function onOpenDebugButtonClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("----- KUIShowDebugInfoNode:onOpenDebugButtonClick()")
        imageDebugInfo:setVisible(true)
    end
    buttonDebugOpen:addTouchEventListener(onOpenDebugButtonClick)
    
    local buttonDebugClose  = imageDebugInfo:getChildByName("Button_debug_close")
    local function onCloseDebugButtonClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("----- KUIShowDebugInfoNode:onCloseDebugButtonClick()")
        imageDebugInfo:setVisible(false)
    end
    buttonDebugClose:addTouchEventListener(onCloseDebugButtonClick)
end

function KUIShowDebugInfoNode:registerAllCustomEvent()
end

return KUIShowDebugInfoNode
