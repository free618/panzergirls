--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowQuitGameNode.lua
--  Creator     : Jiang Xufeng 
--  Date        : 2016/01/05 
--  Comment     :
--  *********************************************************************


local ENTER_ACTION_DURATION = 0.3
local CENTER_POSITION       = cc.p(0, 0)
local KUIShowQuitGameNode = class(
    "KUIShowQuitGameNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowQuitGameNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIShowQuitGameNode.create(owner)
    local currentNode = KUIShowQuitGameNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_confirm_quit.csb"
    currentNode:init()
    
    return currentNode
end

function KUIShowQuitGameNode:setConfirmationInfo(confirmationInfo)
    cclog("--------------------> KUIShowQuitGameNode:setConfirmationInfo : %s", confirmationInfo)
    local mainNode        = self._mainLayout
    local imageConfirm    = mainNode:getChildByName("Image_confirm")
    local textInformation = imageConfirm:getChildByName("Text_information")

    textInformation:setString(confirmationInfo)
end

function KUIShowQuitGameNode:setOnTouchEvent(fnConfirm, fnCancel, fnClose)
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local buttonConfirm = imageConfirm:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~")
            
            if fnConfirm ~= nil then
                fnConfirm()
            end 

            self:removeFromParent()
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel = imageConfirm:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCancelClick~")

            if fnCancel ~= nil then
                fnCancel()
            end
            
            self:removeFromParent()         
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local buttonClose = imageConfirm:getChildByName("Button_close")
    local function onCloseClick(sender, type)
    	if type == ccui.TouchEventType.ended then
    		cclog("click onCloseClick~")

    		if fnClose ~= nil then 
    			fnClose()
    		end

    		self:removeFromParent()
    	end
	end
	buttonClose:addTouchEventListener(onCloseClick)
end

function KUIShowQuitGameNode:refreshUI()
    local mainNode      = self._mainLayout
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    mainNode:setPosition(cc.p(0, visibleSize.height))

    cclog("----------> KUIShowQuitGameNode:refreshUI")
end

function KUIShowQuitGameNode:registerAllCustomEvent()

end

function KUIShowQuitGameNode:runEnterAction()
    local mainNode           = self._mainLayout
    local actionMoveToCenter = cc.MoveTo:create(ENTER_ACTION_DURATION, CENTER_POSITION)
    mainNode:runAction(actionMoveToCenter)

    cclog("----------> KUIShowQuitGameNode:runEnterAction")
end

return KUIShowQuitGameNode
