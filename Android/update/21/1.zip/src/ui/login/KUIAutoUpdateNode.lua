--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIAutoUpdateNode.lua
--  Creator     : SunXun
--  Date        : 2015/08/20   17:18
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIAutoUpdateNode = class(
    "KUIAutoUpdateNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local MAX_DOWNLOAD_INFO_COUNT       = 9
local MAX_FAIL_COUNT                = 10
local LOCAL_PROJECT_MANIFEST_PATH   = "res/manifest/project.manifest"

local m_nFailCount                  = 0

function KUIAutoUpdateNode:ctor()
    self._eventFuncList     = nil
    self._assetsManagerEx   = nil
    self._eventListener     = nil
    self._downloadCount     = nil

    -- save download info for ui update
    self._downloadInfo      = {}
end

function KUIAutoUpdateNode.create(owner)
    local currentNode = KUIAutoUpdateNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_updated.csb"
    currentNode:init()

    return currentNode
end

local function updateLoadingPercent(self, downloadPercent, totalPercent)
    local mainNode              = self._mainLayout
    local loadingBGImage        = mainNode:getChildByName("Image_dl_loading_base1")
    local loadingInfoText       = loadingBGImage:getChildByName("Text_update_file")
    local loadingUpLoadingBar   = loadingBGImage:getChildByName("LoadingBar_1")
    local loadingDownLoadingBar = loadingBGImage:getChildByName("LoadingBar_2")
    local textUpdatePercent     = loadingBGImage:getChildByName("Text_update_file_percent")

    loadingUpLoadingBar:setPercent(math.floor(downloadPercent))
    loadingDownLoadingBar:setPercent(math.floor(totalPercent))
    
    local currentPercent = string.format("%.3f%%", downloadPercent)
    textUpdatePercent:setString(currentPercent)
end

local function updateDownloadInfo(self, newInfo)
    local mainNode              = self._mainLayout
    local updateInfoBGImage     = mainNode:getChildByName("Image_dl_login_base")
    local updateInfoText        = updateInfoBGImage:getChildByName("Text_VersionUpdate")

    local singleDownloadInfo = newInfo .. "\n"
    table.insert(self._downloadInfo, singleDownloadInfo)

    if #self._downloadInfo >= MAX_DOWNLOAD_INFO_COUNT then
        table.remove(self._downloadInfo, 1)
    end

    local downloadInfo = ""
    for _, v in pairs(self._downloadInfo) do
        downloadInfo = downloadInfo .. v
    end
    updateInfoText:setString(downloadInfo)
end

local function updateDownloadState(self, downloadInfo)
    local mainNode              = self._mainLayout
    local loadingBGImage        = mainNode:getChildByName("Image_dl_loading_base1")
    local loadingInfoText       = loadingBGImage:getChildByName("Text_update_file")

    loadingInfoText:setString(downloadInfo)
end

local function initUpdateService(self)
    cclog("--------------------> InitUpdateService Start ~")
    local writeablePath = cc.FileUtils:getInstance():getWritablePath()
    local storagePath   = writeablePath .. "s1_update"
    cclog("----------> writeablePath : %s", writeablePath)
    cclog("----------> storagePath : %s", storagePath)

    local assetsManagerEx = cc.AssetsManagerEx:create(LOCAL_PROJECT_MANIFEST_PATH, storagePath)
    assetsManagerEx:retain()
    self._assetsManagerEx = assetsManagerEx

    local localManifest = assetsManagerEx:getLocalManifest()
    local isLocalManifestLoaded = localManifest:isLoaded()
    cclog("----------> isLocalManifestLoaded : %s", tostring(isLocalManifestLoaded))
    local localPackageUrl = localManifest:getPackageUrl()
    cclog("----------> localPackageUrl : %s", localPackageUrl)
    local localManifestFileUrl = localManifest:getManifestFileUrl()
    cclog("----------> localManifestFileUrl : %s", localManifestFileUrl)
    local localVersionFileUrl = localManifest:getVersionFileUrl()
    cclog("----------> localVersionFileUrl : %s", localVersionFileUrl)
    local localVersion = localManifest:getVersion()

    if not isLocalManifestLoaded then
        cclog("---------> Get Local ManifestLoaded Failed~")
        -- run old version
        assert(false, "Get Local ManifestLoaded Failed~")
        return
    end

    local function onUpdateEvent(event)
        local eventCode = event:getEventCode()
        local eventFunc = self._eventFuncList[eventCode]
        if not eventFunc then
            print("-----onUpdateEvent not eventFunc : ", eventCode)
        end
        assert(eventFunc ~= nil, "Get EventFunc Failed~")

        eventFunc(self, event)
    end
    local eventListener = cc.EventListenerAssetsManagerEx:create(assetsManagerEx, onUpdateEvent)
    self._eventListener = eventListener
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(eventListener, 1)

    cclog("--------------------> InitUpdateService Finish~")
end

local function startGame(self)
    require("src/logic/KMainLoop"):start()
    self._parent:addNode("ConfigLoading")
end

local function showUpdateFailedResult(self)
    local tipsInfo = "司令~ 此次有 " .. self._downloadCount .. " 个文件更新失败，可以点击确认按钮继续重试下载，或者点击取消按钮开始游戏，有问题请联系官方，官方QQ群：338455400"
    updateDownloadInfo(self, "You Can Contact To Development Team By QQ:338455400")
    local function onClickStartUpdate()
        cclog("-----> showUpdateFailedResult:onClickStartUpdate")
        if self._assetsManagerEx ~= nil then
            self._assetsManagerEx:release()
            self._assetsManagerEx = nil
        end

        if self._eventListener ~= nil then
            cc.Director:getInstance():getEventDispatcher():removeEventListener(self._eventListener)
            self._eventListener = nil
        end
        
        updateLoadingPercent(self, 0, 0)
        initUpdateService(self)
        self._assetsManagerEx:update()
    end
    
    local function onClickStopUpdate()
        cclog("-----> showUpdateFailedResult:onClickStopUpdate")
        startGame(self)
    end
    
    showConfirmation(tipsInfo, onClickStartUpdate, onClickStopUpdate)
end

function KUIAutoUpdateNode.onErrorLocalManifest(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ERROR_NO_LOCAL_MANIFEST")
    updateDownloadState(self, "Get Local Manifest Failed , Please Report This To: QQ:338455400")
end

function KUIAutoUpdateNode.onErrorDownloadManifest(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ERROE_DOWNLOAD_MANIFEST")
    updateDownloadState(self, "Download Manifest Failed , Please Report This To: QQ:338455400")
end

function KUIAutoUpdateNode.onErrorParseManifest(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ERROR_PARSE_MANIFEST")
    updateDownloadState(self, "Parse Manifest Failed , Please Report This To: QQ:338455400")
end

function KUIAutoUpdateNode.onNewVersionFound(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "NEW_VERSION_FOUND")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    --print("-----> assetsID", assetsID)
    --print("-----> message", message)
    --print("-----> percent", percent)
    print("-----> percentFile", percentFile)

    updateDownloadState(self, "Found New Version~ Please Waiting~")
    updateDownloadInfo(self, "Found New Version~ Please Waiting~")
end

function KUIAutoUpdateNode.onAlreadyUpToData(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ALREADY_UP_TO_DATE")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    print("-----> assetsID", assetsID)
    print("-----> message", message)
    print("-----> percent", percent)
    print("-----> percentFile", percentFile)

    cclog("-----> Client is the newest version. So we can play now.")
    updateLoadingPercent(self, 100, 100)
    updateDownloadState(self, "The Client Version Is Newest~")
    updateDownloadInfo(self, "The Client Version Is Newest~")

    local mainNode              = self._mainLayout
    local buttonControl         = mainNode:getChildByName("Button_start")
    buttonControl:setVisible(false)

    startGame(self)
end

function KUIAutoUpdateNode.onUpdateProgression(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "UPDATE_PROGRESSION")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    --print("-----> assetsID", assetsID)
    --print("-----> message", message)
    --print("-----> percent", percent)
    --print("-----> percentFile", percentFile)

    if assetsID == "@version" then
        cclog("-----> @version Get Version File Success!")
        --updateDownloadInfo(self, "Get Remote Version Success~")
        return
    end

    if assetsID == "@manifest" then
        cclog("-----> @manifest Get Project File Success!")
        --updateDownloadInfo(self, "Get Remote Manifest Success~")
        return
    end

    if message ~= nil then
        cclog("-----> recv message : %s", message)
        updateDownloadState(self, message)
        local _, _, szCount = string.find(message, "update (%d+)")
        if szCount then 
            local downloadNum = tonumber(szCount)
            updateDownloadInfo(self, "本次更新一共需要下载 " .. downloadNum .. " 文件")
            self._downloadCount = downloadNum
        end
    end

    updateLoadingPercent(self, percentFile, percent)
end

function KUIAutoUpdateNode.onAssetUpdated(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ASSET_UPDATED")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    --print("-----> assetsID", assetsID)
    --print("-----> message", message)
    --print("-----> percent", percent)
    print("-----> percentFile", percentFile)

    cclog("-----> download file : %s successed!", assetsID)
    local downloadInfo = string.format("Updated Completely : %s", assetsID)
    updateLoadingPercent(self, percentFile, percent)
    updateDownloadState(self, downloadInfo)
--    updateDownloadInfo(self, downloadInfo)
end

function KUIAutoUpdateNode.onErrorUpdating(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ERROR_UPDATING")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    print("-----> assetsID", assetsID)
    print("-----> message", message)
    print("-----> percent", percent)
    print("-----> percentFile", percentFile)
    local errorInfo = string.format(
        "Error Updating!\nassetsID:%s\nmessage:%s \nPlease Report This To: QQ:338455400",
        assetsID, message
    )
    updateDownloadState(self, errorInfo)
    --updateDownloadInfo(self, errorInfo)
end

function KUIAutoUpdateNode.onUpdateFinished(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "UPDATE_FINISHED")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    print("-----> assetsID", assetsID)
    print("-----> message", message)
    print("-----> percent", percent)
    print("-----> percentFile", percentFile)

    updateLoadingPercent(self, percentFile, percent)
    updateDownloadState(self, "All Updated Completely~")
    updateDownloadInfo(self, "All Updated Completely~")

    local mainNode      = self._mainLayout
    local buttonControl = mainNode:getChildByName("Button_start")
    buttonControl:setVisible(false)

    local loadingBGImage        = mainNode:getChildByName("Image_dl_loading_base1")
    local loadingUpLoadingBar   = loadingBGImage:getChildByName("LoadingBar_1")
    local loadingDownLoadingBar = loadingBGImage:getChildByName("LoadingBar_2")
    local textUpdateFilePercent = loadingBGImage:getChildByName("Text_update_file_percent")
    textUpdateFilePercent:setString("100.000%")

    loadingUpLoadingBar:setVisible(true)
    loadingDownLoadingBar:setVisible(true)

    startGame(self)
end

function KUIAutoUpdateNode.onUpdateFailed(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "UPDATE_FAILED")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    print("-----> assetsID", assetsID)
    print("-----> message", message)
    print("-----> percent", percent)
    print("-----> percentFile", percentFile)

    local errorInfo = string.format(
        "Update Failed!\nassetsID:%s\nmessage:%s \nPlease Report This To: QQ:338455400",
        assetsID, message
    )
    updateDownloadState(self, errorInfo)
    updateDownloadInfo(self, errorInfo)
    
    m_nFailCount = m_nFailCount + 1
    if m_nFailCount <= MAX_FAIL_COUNT + 1 then
        updateDownloadInfo(self, "本次更新失败，系统正在重新更新！~~请司令不要心急呦~~~" .. "重新下载第 " .. m_nFailCount .. " 次")
        self._assetsManagerEx:downloadFailedAssets()
    else
        m_nFailCount = 0
        showUpdateFailedResult(self)
    end
end

function KUIAutoUpdateNode.onErrorDecompress(self, event)
    cclog("----------> onUpdateEvent eventCode: %s", "ERROR_DECOMPRESS")

    local assetsID      = event:getAssetId()
    local message       = event:getMessage()
    local percent       = event:getPercent()
    local percentFile   = event:getPercentByFile()

    print("-----> assetsID", assetsID)
    print("-----> message", message)
    print("-----> percent", percent)
    print("-----> percentFile", percentFile)
    local errorInfo = string.format(
        "Decompress Failed!\nassetsID:%s\nmessage:%s \nPlease Report This To: QQ:338455400",
        assetsID, message
    )
    updateDownloadState(self, errorInfo)
    updateDownloadInfo(self, errorInfo)
end

local function refreshBaseInfo(self)
    local mainNode              = self._mainLayout
    local updateInfoBGImage     = mainNode:getChildByName("Image_dl_login_base")
    local updateInfoText        = updateInfoBGImage:getChildByName("Text_VersionUpdate")
    local loadingBGImage        = mainNode:getChildByName("Image_dl_loading_base1")
    local loadingInfoText       = loadingBGImage:getChildByName("Text_update_file")
    local loadingUpLoadingBar   = loadingBGImage:getChildByName("LoadingBar_1")
    local loadingDownLoadingBar = loadingBGImage:getChildByName("LoadingBar_2")
    local textUpdatePercent     = loadingBGImage:getChildByName("Text_update_file_percent")

    updateInfoText:setString("")
    loadingInfoText:setString("Version Checking ~~~")
    textUpdatePercent:setString("0.000%")
end

local function refreshUIState(self)
    local mainNode              = self._mainLayout
    local updateInfoBGImage     = mainNode:getChildByName("Image_dl_login_base")
    local updateInfoText        = updateInfoBGImage:getChildByName("Text_VersionUpdate")
    local loadingBGImage        = mainNode:getChildByName("Image_dl_loading_base1")
    local loadingInfoText       = loadingBGImage:getChildByName("Text_update_file")
    local loadingUpLoadingBar   = loadingBGImage:getChildByName("LoadingBar_1")
    local loadingDownLoadingBar = loadingBGImage:getChildByName("LoadingBar_2")
    local buttonControl         = mainNode:getChildByName("Button_start")

    loadingUpLoadingBar:setPercent(0)
    loadingDownLoadingBar:setPercent(0)
    buttonControl:setVisible(false)
end

function KUIAutoUpdateNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --start Button
    local buttonControl = mainNode:getChildByName("Button_start")
    local function onStartClick(sender, type)
        if type == ccui.TouchEventType.ended then
            --self._assetsManagerEx:update()
            startGame(self)
        end
    end
    buttonControl:addTouchEventListener(onStartClick)
end

function KUIAutoUpdateNode:registerAllCustomEvent()
end

function KUIAutoUpdateNode:registerEventFunc()
    print("---------->")
    for k, v in pairs(cc.EventAssetsManagerEx.EventCode) do
        print(k, v)
    end
    print("---------->")

    local eventFuncList = {}
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST] = KUIAutoUpdateNode.onErrorLocalManifest
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST] = KUIAutoUpdateNode.onErrorDownloadManifest
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST] = KUIAutoUpdateNode.onErrorParseManifest
    eventFuncList[cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND] = KUIAutoUpdateNode.onNewVersionFound
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE] = KUIAutoUpdateNode.onAlreadyUpToData
    eventFuncList[cc.EventAssetsManagerEx.EventCode.UPDATE_PROGRESSION] = KUIAutoUpdateNode.onUpdateProgression
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ASSET_UPDATED] = KUIAutoUpdateNode.onAssetUpdated
    eventFuncList[cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING] = KUIAutoUpdateNode.onErrorUpdating
    eventFuncList[cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED] = KUIAutoUpdateNode.onUpdateFinished
    eventFuncList[9] = KUIAutoUpdateNode.onUpdateFailed
    eventFuncList[10] = KUIAutoUpdateNode.onErrorDecompress
    -- below two enum is not in tolua++ for cocos2d-lua 3.3final
    --eventFuncList[cc.EventAssetsManagerEx.EventCode.UPDATE_FAILED] = KUIAutoUpdateNode.onUpdateFailed
    --eventFuncList[cc.EventAssetsManagerEx.EventCode.ERROR_DECOMPRESS] = KUIAutoUpdateNode.onErrorDecompress

    self._eventFuncList = eventFuncList
end

function KUIAutoUpdateNode:refreshUI()
    -- refresh base info
    refreshBaseInfo(self)
    -- refresh ui init state
    refreshUIState(self)
end

function KUIAutoUpdateNode:onEnter()
    local tipsInfo = "为了能顺利运行游戏，请务必接受下列霸王条款^_^\n1、我保证月最低充值23333元\n2、我保证每天最少运行游戏2333分钟\n一旦接受下次就不询问啦"
    self:registerEventFunc()
    initUpdateService(self)
    local function onClickStartUpdate()
        cclog("-----> KUIAutoUpdateNode:onClickStartUpdate")
        cc.UserDefault:getInstance():setBoolForKey("isAcceptAgreement", true)
        self._assetsManagerEx:update()
    end
    
    local function onClickStopUpdate()
        cclog("-----> KUIAutoUpdateNode:onClickStopUpdate")
        startGame(self)
    end
    
    -- we must delay excute this because first scene is not init now.
    delayExecute(
        self, 
        function() 
            local isAcceptAgreement = cc.UserDefault:getInstance():getBoolForKey("isAcceptAgreement")
            if not isAcceptAgreement then
                showConfirmation(tipsInfo, onClickStartUpdate, onClickStopUpdate)
            else
                onClickStartUpdate()
            end
        end, 0.5
   )
end

function KUIAutoUpdateNode:onExit()
    if self._assetsManagerEx ~= nil then
        self._assetsManagerEx:release()
        self._assetsManagerEx = nil
    end

    if self._eventListener ~= nil then
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._eventListener)
        self._eventListener = nil
    end
end

return KUIAutoUpdateNode
