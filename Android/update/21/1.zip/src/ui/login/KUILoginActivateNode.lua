--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginActivateNode.lua
--  Creator     : liulingli
--  Date        : 2016/03/14   20:00
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUILoginActivateNode = class(
    "KUILoginActivateNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILoginActivateNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._syncCount     = 0
end

function KUILoginActivateNode.create(owner)
    local currentNode = KUILoginActivateNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign_up_activation_code.csb"
    currentNode:init()
    
    return currentNode
end

function KUILoginActivateNode:refreshUI()
    local textVersion = mainNode:getChildByName("Text_version_number")
    textVersion:setString(VERSION)
end

function KUILoginActivateNode:registerAllTouchEvent()
    local imageBase       = self._mainLayout:getChildByName("Image_server_choose_base")
    local buttonCancel    = imageBase:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("onCancelClick ~")
        KSound.playEffect("click")
        KGameServer:Logout()
        self._parent:addNode("LoginAndRegister")
        self._parent:removeNode("Activate")
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local buttonConfirm   = imageBase:getChildByName("Button_conform")
    local function onConfirmClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("onConfirmClick ~")
        KSound.playEffect("click")
        local textActivationCode = imageBase:getChildByName("TextField_activation_code")
        szActivationCode = textActivationCode:getString()
        local errorMsgID = KUtil.checkActivationCode(szActivationCode)
        if errorMsgID then
            showConfirmation(KUtil.getStringByKey(errorMsgID))
            return
        end
        KGameServer:ActivateAccount(szActivationCode)
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)
end

function KUILoginActivateNode:registerAllCustomEvent()
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    local function onSyncServerList(serverList)
        cclog("----------> onEvent NET_SYNC_SERVER_LIST")
        local serverListNode = self._parent:addNode("ServerList")
        serverListNode:setServerList(serverList)
        self._parent:removeNode("Activate")
    end
    self:addCustomEvent(eventDispatch.EventType.NET_SYNC_SERVER_LIST, onSyncServerList)

    local function onActivate(nRetCode)
        cclog("----------> onEvent NET_ACTIVATE_RESULT %d", nRetCode)
        if nRetCode == ACTIVATE_RET.SUCCESS then
            showConfirmation(KUtil.getStringByKey("activate.success"))
        elseif nRetCode == ACTIVATE_RET.ACCOUNT_NOT_EXIST then
            showConfirmation(KUtil.getStringByKey("common.accountNotExist"))
        elseif nRetCode == ACTIVATE_RET.ACTIVATE_CODE_ERROR then
            showConfirmation(KUtil.getStringByKey("common.register.activationCodeError"))
        elseif nRetCode == ACTIVATE_RET.ACTIVATE_CODE_USED then
            showConfirmation(KUtil.getStringByKey("common.register.activationCodeUsed"))
        elseif nRetCode == ACTIVATE_RET.HAS_ACTIVE then
            showConfirmation(KUtil.getStringByKey("activate.hasActive"))
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_ACTIVATE_RESULT, onActivate)
end

return KUILoginActivateNode
