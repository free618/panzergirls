--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginAnnounceNode.lua
--  Creator     : liulingli
--  Date        : 2015/11/03   13:46
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUILoginAnnounceNode = class(
    "KUILoginAnnounceNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILoginAnnounceNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._baseControl    = nil
end

function KUILoginAnnounceNode.create(owner, szText)
    local currentNode = KUILoginAnnounceNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_notice.csb"
    currentNode._text   = szText
    currentNode:init()

    return currentNode
end

local function refreshScrollView(self, isCutIn)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_notice")
    local scrollControl = imageCommon:getChildByName("ScrollView_information")
    scrollControl:removeAllChildren()

    local listData = string.split(self._text, '\n')

    local showListUI = {}
    for _, szText in ipairs(listData) do
        local newControl = self._baseControl:clone()
        newControl:setString(szText)
        table.insert(showListUI, newControl)
    end
    KUtil.addScrollView(scrollControl, showListUI, isCutIn)
end

function KUILoginAnnounceNode:onInitUI()
    local mainNode      = self._mainLayout
    local baseControl   = mainNode:getChildByName("Image_notice")
    local scrollControl = baseControl:getChildByName("ScrollView_information")
    self._baseControl   = scrollControl:getChildByName("Text_information")
    self._baseControl:retain()

    scrollControl:removeAllChildren()
end

function KUILoginAnnounceNode:refreshUI()
    refreshScrollView(self)
end

function KUILoginAnnounceNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local baseControl = mainNode:getChildByName("Image_notice")
    local buttonControl = baseControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")   
            KSound.playEffect("close")         
            self._parent:removeNode("Announce")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUILoginAnnounceNode:onCleanup()
    self._baseControl:release() 
end

return KUILoginAnnounceNode
