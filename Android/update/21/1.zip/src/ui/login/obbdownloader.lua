
local function setSettingString(key, value)
    cc.UserDefault:getInstance():setStringForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

local function getSettingString(key, default)
    return cc.UserDefault:getInstance():getStringForKey(key, default)
end

local function callJava(strFuncName, tArgs)
    local strResult = C_AppBilling(strFuncName, LuaValue2JsonString(tArgs) or "")
    assert(strResult)
    local tJsonResult = JsonString2LuaValue(strResult)
    assert(tJsonResult)
    C_Log("callJava strFuncName:" .. strFuncName)
    C_Log("callJava Result:" .. tostring(strResult))
    return tJsonResult.status == "success", tJsonResult.result
end

local DOWNLOAD_STATE = 
{
    DOWNLOAD_BEGIN = -1,
    INVALID = 0,
    IDLE = 1,
    FETCHING_URL = 2,
    CONNECTING = 3,
    DOWNLOADING = 4,
    COMPLETED = 5,
    PAUSED_NETWORK_UNAVAILABLE = 6,
    PAUSED_BY_REQUEST = 7,
    PAUSED_WIFI_DISABLED_NEED_CELLULAR_PERMISSION = 8,
    PAUSED_NEED_CELLULAR_PERMISSION = 9,
    PAUSED_WIFI_DISABLED = 10,
    PAUSED_NEED_WIFI = 11,
    PAUSED_ROAMING = 12,
    PAUSED_NETWORK_SETUP_FAILURE = 13,
    PAUSED_SDCARD_UNAVAILABLE = 14,
    FAILED_UNLICENSED = 15,
    FAILED_FETCHING_URL = 16,
    FAILED_SDCARD_FULL = 17,
    FAILED_CANCELED = 18,
    FAILED = 19,
    DOWNLOAD_END = 15,

    CONFIRM_TO_START_DOWNLOAD = 100000,
    CONFIRM_ON_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED = 100001,
    CONFIRM_ON_UNZIPPING_ERROR = 100002,
    CONFIRM_CELLULAR_PERMISSION = 100003,

    UNZIPPING_BEGIN = 200000,
    UNZIPPING = 200001,
    FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED = 200002,
    FAILED_UNZIPPING_ERROR = 200003,
    UNZIPPING_COMPLETED = 200004,
    UNZIPPING_END = 200005,

    END_SUCCESS = 200100,

    END_FAILED_USER_REJECT_DOWNLOAD = 200201,
    END_FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED = 200202,
    END_FAILED_UNZIPPING_ERROR = 200203,

    EXITED = 300000,
}

local tDownloadStateDescription =
{
    [DOWNLOAD_STATE.INVALID] = "未開始",
    [DOWNLOAD_STATE.IDLE] = "下載器啟動中...",
    [DOWNLOAD_STATE.FETCHING_URL] = "正在獲取擴展包地址...",
    [DOWNLOAD_STATE.CONNECTING] = "正在連接資源服務器...",
    [DOWNLOAD_STATE.DOWNLOADING] = "下載中...",
    [DOWNLOAD_STATE.COMPLETED] = "下載完成",
    [DOWNLOAD_STATE.PAUSED_NETWORK_UNAVAILABLE] = "網絡不可用，暫停中",
    [DOWNLOAD_STATE.PAUSED_BY_REQUEST] = "用戶暫停中",
    [DOWNLOAD_STATE.PAUSED_WIFI_DISABLED_NEED_CELLULAR_PERMISSION] = "WIFI不可用，請求使用流量",
    [DOWNLOAD_STATE.PAUSED_NEED_CELLULAR_PERMISSION] = "請求使用流量",
    [DOWNLOAD_STATE.PAUSED_WIFI_DISABLED] = "WIFI不可用，暫停中",
    [DOWNLOAD_STATE.PAUSED_NEED_WIFI] = "需要WIFI，暫停中",
    [DOWNLOAD_STATE.PAUSED_ROAMING] = "正在漫遊，暫停中",
    [DOWNLOAD_STATE.PAUSED_NETWORK_SETUP_FAILURE] = "網絡啟動失敗，暫停中",
    [DOWNLOAD_STATE.PAUSED_SDCARD_UNAVAILABLE] = "SD卡不可用，暫停中",
    [DOWNLOAD_STATE.FAILED_UNLICENSED] = "下載失敗，FAILED_UNLICENSED",
    [DOWNLOAD_STATE.FAILED_FETCHING_URL] = "下載失敗，獲取擴展包地址失敗",
    [DOWNLOAD_STATE.FAILED_SDCARD_FULL] = "下載失敗，sd卡空間不足",
    [DOWNLOAD_STATE.FAILED_CANCELED] = "下載失敗，下載被取消了",
    [DOWNLOAD_STATE.FAILED] = "下載失敗",

    [DOWNLOAD_STATE.CONFIRM_TO_START_DOWNLOAD] = "確認下載請求中...",
    [DOWNLOAD_STATE.CONFIRM_ON_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED] = "擴展資源解壓失敗，目標文件夾不存在並且創建失敗，確認是否重新嘗試解壓",
    [DOWNLOAD_STATE.CONFIRM_ON_UNZIPPING_ERROR] = "擴展資源解壓失敗，確認是否重新嘗試解壓",

    [DOWNLOAD_STATE.UNZIPPING] = "正在解壓擴展資源包",
    [DOWNLOAD_STATE.FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED] = "擴展資源解壓失敗，目標文件夾不存在並且創建失敗",
    [DOWNLOAD_STATE.FAILED_UNZIPPING_ERROR] = "擴展資源解壓失敗",
    [DOWNLOAD_STATE.UNZIPPING_COMPLETED] = "擴展資源包解壓完成",

    [DOWNLOAD_STATE.END_SUCCESS] = "擴展資源下載解壓完成",
    [DOWNLOAD_STATE.END_FAILED_USER_REJECT_DOWNLOAD] = "擴展資源下載失敗",
    [DOWNLOAD_STATE.END_FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED] = "擴展資源解壓失敗",
    [DOWNLOAD_STATE.END_FAILED_UNZIPPING_ERROR] = "擴展資源解壓失敗",
    [DOWNLOAD_STATE.EXITED] = "界面退出",
}

local DIALOGS = 
{
    START = 
    {
        NAME = "START",
        VALID_STATE = 
        {
            [DOWNLOAD_STATE.INVALID] = DOWNLOAD_STATE.CONFIRM_TO_START_DOWNLOAD,
        },
        PRESHOW = function(self)
            return not self.bRequestingStartDownloadObb
        end,
        TITLE = "確認",
        CONTENT = "即將開始下載擴展資源，請確認",
        OK = function(self)
            self:StartDownloadObb()
        end,
        CANCEL = function(self)
            self.nState = DOWNLOAD_STATE.END_FAILED_USER_REJECT_DOWNLOAD  
            self:refreshUI()
        end,
    },
    CELL_PERMISSION = 
    {
        NAME = "CELL_PERMISSION",
        VALID_STATE = 
        {
           [DOWNLOAD_STATE.PAUSED_NEED_CELLULAR_PERMISSION] = DOWNLOAD_STATE.CONFIRM_CELLULAR_PERMISSION,
           [DOWNLOAD_STATE.PAUSED_WIFI_DISABLED_NEED_CELLULAR_PERMISSION] = DOWNLOAD_STATE.CONFIRM_CELLULAR_PERMISSION,
       },
        TITLE = "確認",
        CONTENT = "將使用蜂窩網絡下載擴展資源，請確認",
        PRESHOW = function(self)
            if self.bPermisionToUseCellular == true then 
                callJava("resume_obb_download_on_cell")
                return false
            end

            if self.bPermisionToUseCellular == false then
                return false
            end

            return true
        end,

        OK = function(self)
            assert(self.bPermisionToUseCellular == nil)
            self.bPermisionToUseCellular = true
            callJava("resume_obb_download_on_cell")
        end,
        CANCEL = function(self)
            assert(self.bPermisionToUseCellular == nil)
            self.bPermisionToUseCellular = false
        end,
    },

    UNZIP_DIR_ERROR = 
    {
        NAME = "UNZIP_DIR_ERROR",
        VALID_STATE = 
        {
            [DOWNLOAD_STATE.FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED] = DOWNLOAD_STATE.CONFIRM_ON_UNZIPPING_ERROR,
        },
        TITLE = "確認",
        CONTENT = "解壓縮擴展資源包的時候出錯了，解壓縮的目標目錄創建失敗，需要再試壹次嗎？",
        OK = function(self)
            self.nState = DOWNLOAD_STATE.COMPLETED
            self:refreshUI()
        end,
        CANCEL = function(self)
            self.nState = DOWNLOAD_STATE.END_FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED
            self:refreshUI()
        end,
    },

    UNZIP_ERROR = 
    {
        NAME = "UNZIP_ERROR",
        VALID_STATE = 
        {
            [DOWNLOAD_STATE.FAILED_UNZIPPING_ERROR] = DOWNLOAD_STATE.CONFIRM_ON_UNZIPPING_ERROR,
        },
        TITLE = "確認",
        CONTENT = "解壓縮擴展資源包的時候出錯了，需要再試壹次嗎？",
        OK = function(self)
            self.nState = DOWNLOAD_STATE.COMPLETED
            self:refreshUI()
        end,
        CANCEL = function(self)
            self.nState = DOWNLOAD_STATE.END_FAILED_UNZIPPING_ERROR
            self:refreshUI()
        end,
    },
}

local ObbDownloadNode = class(
"ObbDownloadNode", function () return cc.Node:create() end
)

function ObbDownloadNode:ctor()
end

function ObbDownloadNode.create(owner, nState)
    local self = ObbDownloadNode.new()

    ObbDownloadNode.instanceObject = self

    self.nState         = nState
    self._parent        = owner
    self._uiPath        = "res/ui/layout_obb_updated.csb"
    self.nSpeed          = 0 
    self.nTimeRemaining  = 0 
    self.nDownloadedSize = 0 
    self.nTotalSize       = 0 

    self:init()

    return self
end

function ObbDownloadNode:init()
    assert(self._uiPath ~= nil, "uiResPath is not config~")
    self._mainLayout = cc.CSLoader:createNode(self._uiPath)
    self:autoHandler()
end

function ObbDownloadNode:onEnter()
    local function activateWrapper()
        self:Activate()
    end

    self.activateShdulerID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(activateWrapper, 1, false)
end

function ObbDownloadNode:UnscheduleActivate()
    if not self.activateShdulerID then
        return
    end

    local schedulerID = self.activateShdulerID
    self.activateShdulerID = nil
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(schedulerID)
end

function ObbDownloadNode:onExit()
    self:UnscheduleActivate()
end

function ObbDownloadNode:onCleanup()
    self:UnscheduleActivate()
end

function ObbDownloadNode:autoHandler()
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        end
        if "exit" == event then
            self:onExit()
        end

        if "cleanup" == event then
            self:onCleanup()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    assert(self._mainLayout)
    self:addChild(self._mainLayout, 1)

    self:refreshUI()
    self:registerAllTouchEvent()
end

function ObbDownloadNode:GetInstanceOrClass()
    if not ObbDownloadNode.instanceObject then
        return ObbDownloadNode
    end 

    if tolua.isnull(ObbDownloadNode.instanceObject) then
        return ObbDownloadNode
    end

    return ObbDownloadNode.instanceObject
end

function ObbDownloadNode:Activate()
    if self.tDialogInfo then
        C_Log("Activate ****** STATE:" .. tDownloadStateDescription[self.nState] .. " " .. self.tDialogInfo.NAME)
        return
    end

    C_Log("Activate ****** STATE:" .. tDownloadStateDescription[self.nState] .. " DIALOG NONE")
    if self.nState > DOWNLOAD_STATE.DOWNLOAD_BEGIN and
        self.nState < DOWNLOAD_STATE.DOWNLOAD_END and
        self.nState ~= DOWNLOAD_STATE.COMPLETED then
        if self.bQueringStatus then
            return
        end
        self.bQueringStatus = callJava("get_obb_download_status")
        return
    end

    if self.nState == DOWNLOAD_STATE.COMPLETED then
        self:UnzipObbFile()
        return
    end

    if self.nState == DOWNLOAD_STATE.UNZIPPING_COMPLETED then
        self.nState = DOWNLOAD_STATE.END_SUCCESS
        self:refreshUI()
        return
    end

    if self.nState == DOWNLOAD_STATE.END_SUCCESS then
        self.nState = DOWNLOAD_STATE.EXITED
        self:startAutorefreshUI()
        return
    end

    if self.nState == DOWNLOAD_STATE.FAILED or
        self.nState == DOWNLOAD_STATE.FAILED_CANCELED or
        self.nState == DOWNLOAD_STATE.FAILED_FETCHING_URL or
        self.nState == DOWNLOAD_STATE.FAILED_SDCARD_FULL or 
        self.nState == DOWNLOAD_STATE.FAILED_UNLICENSED or
        self.nState == DOWNLOAD_STATE.END_FAILED_UNZIPPING_ERROR or
        self.nState == DOWNLOAD_STATE.END_FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED or
        self.nState == DOWNLOAD_STATE.END_FAILED_USER_REJECT_DOWNLOAD then

        self.nQutingCountDown = self.nQutingCountDown or 20
        self.nQutingCountDown = self.nQutingCountDown - 1

        local strStatus = tDownloadStateDescription[self.nState]
        strStatus = strStatus .. " " .. self.nQutingCountDown .. "秒後退出"

        local mainNode       = self._mainLayout
        local imageBase      = mainNode:getChildByName("Image_loading_base")
        local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")
        textLog:setString(strStatus)

        if self.nQutingCountDown <= 0 then
            cc.Director:getInstance():endToLua() 
        end
    end
end

function ObbDownloadNode:StartDownloadObb()
    assert(self.nState == DOWNLOAD_STATE.INVALID)

    if self.bRequestingStartDownloadObb then
        return
    end

    self.bRequestingStartDownloadObb = callJava("start_obb_download") 
    C_Log("StartDownloadObb result:" .. tostring(self.bRequestingStartDownloadObb))
    return self.bRequestingStartDownloadObb
end

function ObbDownloadNode:StopDownloadObb()
    assert(self.nState == DOWNLOAD_STATE.DOWNLOADING)

    local bResult = callJava("stop_obb_download") 
    C_Log("StopDownloadObb result:" .. tostring(bResult))
    return bResult 
end

function ObbDownloadNode:PauseDownloadObb()
    assert(self.nState == DOWNLOAD_STATE.DOWNLOADING)

    local bResult = callJava("pause_obb_download") 
    C_Log("PauseDownloadObb result:" .. tostring(bResult))
    return bResult
end

function ObbDownloadNode:ResumeDownloadObb()
    assert(self.nState == DOWNLOAD_STATE.PAUSED_BY_REQUEST)

    local bResult = callJava("resume_obb_download") 
    C_Log("ResumeDownloadObb result:" .. tostring(bResult))
    return bResult 
end

function ObbDownloadNode:IsMainObbFileExist(bDeleteIfMismatch)
    if not cc.FileUtils:getInstance():isFileExist(self.strMainObbFilePath) then
        C_Log("Main ObbFile not Exist!")
        return false
    end

    do return true end

    if cc.FileUtils:getInstance():getFileSize(self.strMainObbFilePath) ~= self.nMainObbFileSize then
        C_Log("Main ObbFile size mismatch")
        if bDeleteIfMismatch then
            local bSuccess = cc.FileUtils:getInstance():removeFile(self.strMainObbFilePath)
            if not bSuccess then
                C_Log("Remove main obbfile failed when filesize mismatch")
            end
        end
        return false
    end

    return true 
end

function ObbDownloadNode:UnzipObbFile()
    assert(self.nState == DOWNLOAD_STATE.COMPLETED)
    if cc.FileUtils:getInstance():isDirectoryExist(self.strLocalUnzipPath) then
    	cc.FileUtils:getInstance():removeDirectory(self.strLocalUnzipPath)
	end
    
    if cc.FileUtils:getInstance():isDirectoryExist(self.strLocalUnzipPath) then
		C_Log("clean obb unzip target dir failed!")
	end
    if not cc.FileUtils:getInstance():isDirectoryExist(self.strLocalUnzipPath) then
        if not cc.FileUtils:getInstance():createDirectory(self.strLocalUnzipPath) then
            self.nState = DOWNLOAD_STATE.FAILED_UNZIPPING_TARGET_DIR_NOT_EXIST_AND_CREATE_FAILED
            self:refreshUI()
            self:showConfirmation(DIALOGS.UNZIP_DIR_ERROR)
            return
        end
    end

    local function onUncompressProgress(storagePath, nFileCount, nUncompressCount)
        assert(self.nState == DOWNLOAD_STATE.UNZIPPING)

        self.nFileCountInZip = nFileCount
        self.nFileCountUncompressed = nUncompressCount
        C_Log("onUncompressProgress, nFileCount:" .. nFileCount .. " nUncompressCount:" .. nUncompressCount)
        self:refreshUI()
    end

    local function onUncompressFinished(strStragePath, bSuccess, strError)
        assert(self.nState == DOWNLOAD_STATE.UNZIPPING)
        if not bSuccess then
            C_Log("onUncompressFinished failed:" ..  tostring(strError))
            self.nState = DOWNLOAD_STATE.FAILED_UNZIPPING_ERROR
            self:refreshUI()
            self:showConfirmation(DIALOGS.UNZIP_ERROR)
            return
        end

        setSettingString("obb_unzipped", self.strMainObbFileName)
        self.nState = DOWNLOAD_STATE.UNZIPPING_COMPLETED
        self:refreshUI()
    end
    C_AsyncUncompress(self.strMainObbFilePath, self.strLocalUnzipPath, true, onUncompressFinished, onUncompressProgress)
    self.nState = DOWNLOAD_STATE.UNZIPPING
    self:refreshUI()
end

function ObbDownloadNode:IsUnzipped()
    return self.strMainObbFileName == self.strUnzipFileName  
end

function ObbDownloadNode:InitBaseInfo()
    local strWritablePath = cc.FileUtils:getInstance():getWritablePath()
    local bSuccess, strExternalStoragePath = callJava("get_external_storage_dir")
    if not bSuccess then
        C_Log("GetExternalStoragePath failed, ExternalStorage State Error:" .. tostring(strExternalStoragePath))
        return
    end

    local _, tPackageInfo = callJava("get_package_info")

    self.strPackageName         = tPackageInfo.package_name
    self.strVersionName         = tPackageInfo.version_name
    self.nVersionCode           = tPackageInfo.version_code
    self.strExternalStoragePath = strExternalStoragePath
    self.strMainObbFileName     = "main." .. self.nVersionCode .. "." .. self.strPackageName .. ".obb"
    self.strMainObbFilePath     = self.strExternalStoragePath .. "/Android/obb/" .. self.strPackageName .. "/" .. self.strMainObbFileName
    self.nMainObbFileSize       = 383919177

    --self.strLocalUnzipPath      = self.strExternalStoragePath .. "/Android/obb/" .. self.strPackageName .. "/unzipped/"
    self.strLocalUnzipPath      = strWritablePath .. "s1_update/"

    self.strUnzipFileName = getSettingString("obb_unzipped", "")

    C_Log("PrintBaseInfo:")
    C_Log("\tPackageName:" .. tostring(self.strPackageName))
    C_Log("\tVersionName:" .. tostring(self.strVersionName))
    C_Log("\tVersionCode:" .. tostring(self.nVersionCode))
    C_Log("\tExternalStoragePath:" .. tostring(self.strExternalStoragePath))
    C_Log("\tMainObbFileName:" .. tostring(self.strMainObbFileName))
    C_Log("\tMainObbFilePath:" .. tostring(self.strMainObbFilePath))
    C_Log("\tMainObbFileSize:" .. tostring(self.nMainObbFileSize))
end

function ObbDownloadNode:startAutorefreshUI()
    local isAutoUpdate = false -- auto update flag
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform ~= cc.PLATFORM_OS_WINDOWS and 
        targetPlatform ~= cc.PLATFORM_OS_LINUX and
        targetPlatform ~= cc.PLATFORM_OS_MAC then
        isAutoUpdate = true -- close auto updte for Full Client
    end 

    if not isAutoUpdate then
        local gameScene = require("src/ui/login/KUILoginScene").create()
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(gameScene)
        else
            cc.Director:getInstance():runWithScene(gameScene)
        end
    else
        require("src/ui/login/KUILoginUpdateNode")
        addUpdateScene()
    end
end

function ObbDownloadNode:OpenDownloadUI(nInitState)
    local updateScene = cc.Scene:create()
    assert(updateScene)
    local node = ObbDownloadNode.create(updateScene, nInitState)
    updateScene:addChild(node)
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(updateScene)
    else
        cc.Director:getInstance():runWithScene(updateScene)
    end

    C_Log("ObbDownloadNode, OpenDownloadUI")
end

function ObbDownloadNode:downloadObb()
    self:InitBaseInfo()
    if self:IsUnzipped() then
        self:startAutorefreshUI()
        return
    end

    if self:IsMainObbFileExist(true) then
        C_Log("IsMainObbFileExist, Ret true")
        self:OpenDownloadUI(DOWNLOAD_STATE.COMPLETED)
        return
    end

    C_Log("IsMainObbFileExist, Ret false")
    self:OpenDownloadUI(DOWNLOAD_STATE.INVALID)
end

function ObbDownloadNode:on_start_obb_download_finished(tArg)
    assert(self.bRequestingStartDownloadObb)
    self.bRequestingStartDownloadObb = false
end

function ObbDownloadNode:on_pause_obb_download_finished(tArg)
end

function ObbDownloadNode:on_resume_obb_download_finished(tArg)
end

function ObbDownloadNode:on_resume_obb_download_on_cell_finished(tArg)
end

function ObbDownloadNode:on_stop_obb_download_finished(tArg)
end

function ObbDownloadNode:getSizeString(nSize)
    local tUnit = {"KB", "MB", "GB"}
    local strSuffix = "B"
    for _, v in ipairs(tUnit) do
        if nSize < 1024 then
            break
        end

        nSize = nSize / 1024
        strSuffix = v
    end

    return string.format("%.2f", nSize) .. strSuffix
end

function ObbDownloadNode:getRemainingTimeString(nTime)
    local strTimeString
    local tUnit = {{60, "S"}, {60, "M"}, {24, "H"}}
    for _, v in ipairs(tUnit) do
        if not strTimeString then
            strTimeString = tostring(nTime % v[1]) .. v[2]
        else
            strTimeString = tostring(nTime % v[1]) .. v[2] .. strTimeString
        end
        nTime = math.floor(nTime / v[1])
        if nTime <= 0 then
            break
        end
    end
    return "剩余時間：" .. strTimeString
end

function ObbDownloadNode:refreshOnDownloading()
    local mainNode       = self._mainLayout
    local imageBase      = mainNode:getChildByName("Image_loading_base")
    local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")
    local textLoadSpeed  = imageBase:getChildByName("BitmapFontLabel_download_speed")
    local textTotalSize  = imageBase:getChildByName("BitmapFontLabel_total_number")
    local labelRemainingTime = imageBase:getChildByName("Text_remain_time")
    local textBMFont     = imageBase:getChildByName("BitmapFontLabel_2")
    local loadingBar     = imageBase:getChildByName("LoadingBar_loading")
    local textLoadSize   = imageBase:getChildByName("BitmapFontLabel_file_percent")
    local imageIconTank  = loadingBar:getChildByName("Image_icon_tank")
    local nBarWidth      = loadingBar:getContentSize().width
    local textVersionNumber  = mainNode:getChildByName("Text_version_number")

    local nTotalSize = self.nTotalSize
    local nDownloadedSize = self.nDownloadedSize
    local nTimeRemaining = self.nTimeRemaining
    local nPercent = 0

    if nTotalSize == 0 then
        nTotalSize = self.nMainObbFileSize
    end
    if nTotalSize > 0 then
        nPercent = self.nDownloadedSize / nTotalSize * 100
    end
    
    if self.nState == DOWNLOAD_STATE.COMPLETED then
        nDownloadedSize = nTotalSize
        nTimeRemaining = 0
    end

    textVersionNumber:setString(self.strVersionName)
    textLog:setString(tDownloadStateDescription[self.nState])
    textLoadSpeed:setString(string.format("%s/S", self:getSizeString(self.nSpeed * 1024)))
    textLoadSize:setString(self:getSizeString(nDownloadedSize))
    textTotalSize:setString(self:getSizeString(nTotalSize))
    labelRemainingTime:setString(self:getRemainingTimeString(math.floor(nTimeRemaining / 1000)))
    loadingBar:setPercent(nPercent)
    textBMFont:setString(string.format("%.2f%%", nPercent))
    imageIconTank:setPosition(nBarWidth * nPercent / 100, imageIconTank:getPositionY())
end

function ObbDownloadNode:refreshOnUnzipping()
    local mainNode       = self._mainLayout
    local imageBase      = mainNode:getChildByName("Image_loading_base")
    local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")
    local textLoadSpeed  = imageBase:getChildByName("BitmapFontLabel_download_speed")
    local textTotalSize  = imageBase:getChildByName("BitmapFontLabel_total_number")
    local labelRemainingTime = imageBase:getChildByName("Text_remain_time")
    local textBMFont     = imageBase:getChildByName("BitmapFontLabel_2")
    local loadingBar     = imageBase:getChildByName("LoadingBar_loading")
    local textLoadSize   = imageBase:getChildByName("BitmapFontLabel_file_percent")
    local imageIconTank  = loadingBar:getChildByName("Image_icon_tank")
    local nBarWidth      = loadingBar:getContentSize().width
    local textVersionNumber  = mainNode:getChildByName("Text_version_number")
    
    local nFileSize = self.nTotalSize 
    if nFileSize == 0 then
        nFileSize = self.nMainObbFileSize
    end
    local nSpeed = 0
    local nTimeRemaining = 0
    local nFileCountUncompressed = self.nFileCountUncompressed
    local nFileCountInZip = self.nFileCountInZip 

    loadingBar:setPercent(100)
    textBMFont:setString(string.format("%.2f%%", 100))
    imageIconTank:setPosition(nBarWidth * 100 / 100, imageIconTank:getPositionY())
    textVersionNumber:setString(self.strVersionName)
    labelRemainingTime:setString(self:getRemainingTimeString(nTimeRemaining))
    textTotalSize:setString(self:getSizeString(nFileSize))
    textLoadSize:setString(self:getSizeString(nFileSize))
    textLoadSpeed:setString(string.format("%s/S", self:getSizeString(self.nSpeed)))
    
    if not nFileCountUncompressed or not nFileCountInZip or nFileCountInZip == 0 then
        textLog:setString(tDownloadStateDescription[DOWNLOAD_STATE.UNZIPPING])
    else
        textLog:setString(string.format(tDownloadStateDescription[DOWNLOAD_STATE.UNZIPPING] .. "(%s/%s)", nFileCountUncompressed, nFileCountInZip))
    end
end

function ObbDownloadNode:refreshStatus()
    local mainNode       = self._mainLayout
    local imageBase      = mainNode:getChildByName("Image_loading_base")
    local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")

    textLog:setString(tDownloadStateDescription[self.nState])
end

function ObbDownloadNode:refreshUI()
    self:refreshConfirmation()
    self:refreshStatus()

    if self.nState > DOWNLOAD_STATE.DOWNLOAD_BEGIN and 
        self.nState < DOWNLOAD_STATE.DOWNLOAD_END then
        return self:refreshOnDownloading()
    end

    if self.nState > DOWNLOAD_STATE.UNZIPPING_BEGIN and
        self.nState < DOWNLOAD_STATE.UNZIPPING_END then
        return self:refreshOnUnzipping()
    end
end

function ObbDownloadNode:on_get_obb_download_status(tArgs)
    if not self.bQueringStatus then
        C_Log("on_get_obb_download_status not self.bQueringStatus")
        return
    end

    self.bQueringStatus = nil
    if tArgs.status ~= "success" then
        return
    end

    if self.nState <= DOWNLOAD_STATE.DOWNLOAD_BEGIN or self.nState >= DOWNLOAD_STATE.DOWNLOAD_END then
        C_Log("on_get_obb_download_status, not in download state:: " .. tostring(self.nState))
        return
    end

    local tResult = tArgs.result

    self.nLastState      = self.nState
    self.nState          = tResult.state
    self.nSpeed          = tResult.speed
    self.nTimeRemaining  = tResult.timeRemaining
    self.nDownloadedSize = tResult.downloadedSize
    self.nTotalSize      = tResult.totalSize
    
    self:refreshUI()

    if self.nState == DOWNLOAD_STATE.INVALID then
        self:StartDownloadObb()
        return
    end

    if self.nState == DOWNLOAD_STATE.PAUSED_WIFI_DISABLED_NEED_CELLULAR_PERMISSION or
        self.nState == DOWNLOAD_STATE.PAUSED_NEED_CELLULAR_PERMISSION then
        return self:showConfirmation(DIALOGS.CELL_PERMISSION)
    end
end

function ObbDownloadNode:showConfirmation(tDialogInfo)
    C_Log("Try show confirm UI: " .. tDialogInfo.NAME)
    if self.tDialogInfo then
        C_Log("Confirm UI: " .. self.tDialogInfo.NAME .. " showing")
        return false
    end

    if tDialogInfo.PRESHOW and not tDialogInfo.PRESHOW(self) then
        C_Log("PRESHOW Skipped!")
        return
    end

    local nNewState = nil
    for k, v in pairs(tDialogInfo.VALID_STATE) do
        if k == self.nState then
            C_Log("Confirm UI CheckState k:" .. tostring(k) .. " self.nState:" .. self.nState)
            nNewState = v
            break
        end
    end
    if not nNewState then
        C_Log("Confirm UI, not nNewState!")
        return false
    end

    self.nPreDialogState = self.nState
    self.nDialogState = nNewState 
    self.tDialogInfo = tDialogInfo
    self:refreshConfirmation()
    self.nState = nNewState
    C_Log("Confirm UI self.nDialogState:" .. tostring(self.nDialogState) .. " self.nState:" .. tostring(self.nState))
end

function ObbDownloadNode:refreshConfirmation()
    local mainNode      = self._mainLayout
    local confirmUI = mainNode:getChildByName("Image_update_information")
    if not self.tDialogInfo then
        confirmUI:setVisible(false)
        C_Log("Confirum UI visible false")
        return
    end

    local titleUI = confirmUI:getChildByName("Image_title_base"):getChildByName("Text_title")
    titleUI:setString(self.tDialogInfo.TITLE)
    
    local contentUI = confirmUI:getChildByName("ScrollView_update_information"):getChildByName("BitmapFontLabel_update_information")
    contentUI:setString(self.tDialogInfo.CONTENT)

    confirmUI:setVisible(true)
    C_Log("Confirum UI visible true")
end

function ObbDownloadNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local confirmUI     = mainNode:getChildByName("Image_update_information")
    local okButton = confirmUI:getChildByName("Button_update_confirm")

    local function onOK()
        C_Log("OnDialog onOk " .. tostring(self.tDialogInfo) .. " nDialogState:" .. tostring(self.nDialogState) .. " nState:" .. tostring(self.nState))
        confirmUI:setVisible(false)
        if not self.tDialogInfo then
            return
        end

        assert(self.nDialogState == self.nState)
        local tDialogInfo = self.tDialogInfo
        self.nState = self.nPreDialogState
        self.tDialogInfo = nil
        self.nDialogState = nil
        self.nPreDialogState = nil
        if tDialogInfo.OK then
            tDialogInfo.OK(self)
        end
    end
    okButton:addTouchEventListener(onOK)

    local function onCancel()
        C_Log("OnDialog onOk " .. tostring(self.tDialogInfo) .. " nDialogState:" .. tostring(self.nDialogState) .. " nState:" .. tostring(self.nState))
        confirmUI:setVisible(false)
        if not self.tDialogInfo then
            return
        end
        assert(self.nDialogState == self.nState)
        local tDialogInfo = self.tDialogInfo
        self.nState = self.nPreDialogState
        self.tDialogInfo = nil
        self.nDialogState = nil
        self.nPreDialogState = nil
        if tDialogInfo.CANCEL then
            tDialogInfo.CANCEL(self)
        end
    end
    local cancelButton = confirmUI:getChildByName("Button_update_cancel")
    cancelButton:addTouchEventListener(onCancel)
end

local function SafeCallFromCpp(strJsonData)
    C_Log("ObbDownloadNode CallFromCpp:" .. strJsonData)
    local tJsonData = JsonString2LuaValue(strJsonData) 
    local strFuncName = tJsonData.func_name
    local tArgs = tJsonData.func_args
    local tObjOrClass = ObbDownloadNode:GetInstanceOrClass()
    return tObjOrClass[strFuncName](tObjOrClass, tArgs)
end

function ObbDownloader_CallFromCpp(strJsonData)
    local bSuccess, vData = pcall(SafeCallFromCpp, strJsonData)
    C_Log("ObbDownloadNode_CallFromCpp Result:" .. tostring(bSuccess) .. " RetData:" .. tostring(vData))

    if bSuccess then
        return vData
    end

    local tResult = 
    {
        status = "failed",
        result = 
        {
            description = tostring(vData),
        },
    }

    return LuaValue2JsonString(tResult)
end

if not cc.FileUtils:getInstance():createDirectory([[/data/data/com.capricegame.bproject/files/s1_update/]]) then
    C_Log("Create Dir failed!")
end

return ObbDownloadNode

