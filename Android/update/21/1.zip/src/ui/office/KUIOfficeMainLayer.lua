--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIOfficeMainLayer.lua
--  Creator     : SunXun
--  Date        : 2015/03/31   20:15
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local ADD_RESOURCE_OFFSET = 180
local BLINK_EXP_BUFF_TIME = 5 * 60

local ACTION_TAG_REPEAT_BREATHE = 100
local RETURN_SPEED = 400
local ACTION_TAG_MOVE_DOWN = 10
local ACTION_TAG_BLINK_EXP_BUFF = 110

local m_nHour   = 0
local m_nLastReSendReceiptTime = 0

local m_bIsFirstTime = true
local m_bFirstClickStoryTip = true

local KUIOfficeMainLayer = class(
    "KUIOfficeMainLayer", function () return cc.Layer:create() end
)

local LOADING_BAR_PERCENT_BASE      = 100

local SECRETARY_STATE_ITEM_ID       = 90

function KUIOfficeMainLayer:ctor()
    self._parent                  = nil
    self._mainLayout              = nil
    self._nowTime                 = os.time()
    self._eventList               = {}
    self._furnitureInfo           = {}
    
    self._isFactoryFinish         = nil
    self._isTeamFull              = nil
    self._isCardRepairing         = nil
    self._isZoonOpen              = nil
    self._openSetting             = false
    self._openMessage             = false
    self._isGlobalPanel           = true
    self._messageInfo             = {}
    self._hideAllUI               = false
    self._isShowRecharge          = true
    self._openSecretary           = false
    self._hasShowSPSign           = false

    self._currentDisplayCardID    = nil
    self._currentDisplayCardImage = nil
    self._talkUpdate              = nil
    self._messagelist             = {}
    self._animationList           = {}
    self._isStoryRedPoint         = nil
end

function KUIOfficeMainLayer.create(owner)
    local currentLayer = KUIOfficeMainLayer.new()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office layer create")

    currentLayer._parent = owner
    currentLayer:init()

    return currentLayer
end

local function initFurniturePosiTion(self)
    local mainNode              = self._mainLayout
    local imageCommonProject    = mainNode:getChildByName("Project_furniture_base")
    self._furnitureInfo = KUtil.getFurniturePosition(imageCommonProject)
end

local function refreshFurnitures(self)
    local mainNode              = self._mainLayout
    local imageCommonProject    = mainNode:getChildByName("Project_furniture_base")
    KUtil.refreshFurnitures(imageCommonProject, self._furnitureInfo)
end

local function refreshBaseInfo(self)
    local textPlayerName = self._panelCommonUI:getChildByName("Text_player_name_main")
    textPlayerName:setString(KPlayer.name)

    local textLevelText  = self._panelCommonUI:getChildByName("Text_lv_text")
    textLevelText:setString(" " .. KPlayer.level)

    local resourceName   = {
        "oil", "ammo", "steel", "special_bomb",
    } 
    local maxResourceName = {
        "nMaxOil", "nMaxAmmo", "nMaxSteel", "nMaxPeople",
    }
    --Resource Info
    for i, name in ipairs(resourceName) do
        local resourceMaxCount      = KUtil.getPlayerLevelInfo(KPlayer.level, maxResourceName[i])
        local resourceCount         = KPlayer[CURRENCY_KEY[i]]
        local imageCommonMaterialName = "Image_common_material_base" .. i
        local imageCommonMaterial   = self._panelCommonUI:getChildByName(imageCommonMaterialName)
        local loadingBarControl     = imageCommonMaterial:getChildByName("LoadingBar_" .. name .. "_value")
        loadingBarControl:setPercent(resourceCount / resourceMaxCount * LOADING_BAR_PERCENT_BASE)
        
        local labelControl = imageCommonMaterial:getChildByName("Text_" .. name .. "_value")
        labelControl:setString(resourceCount)
    end 
end

local function refreshCoinCount(self)
    local textCoin       = self._panelCommonUI:getChildByName("Text_coin_value")
    textCoin:setString(KPlayer.coin)
end

local function refreshRankDetail(self)
    local imageMedal     = self._panelCommonUI:getChildByName("Image_medal_image")
    imageMedal:loadTexture(KUtil.getRankImagePath(2))
end

local function refreshTeamRedPoint(self)
    local isTeamFull        = KUtil.checkTeamRedPoint()
    if self._isTeamFull ~= nil and self._isTeamFull == isTeamFull then
        return
    end
    self._isTeamFull        = isTeamFull

    local panelMainbutton1  = self._panelMainBelow:getChildByName("Panel_main_button1")
    local buttonControl     = panelMainbutton1:getChildByName("Button_main_army")
    local imageControl      = buttonControl:getChildByName("ProjectNode_notice_2")
    --local projectNode       = buttonControl:getChildByName("ProjectNode_notice_1")
    imageControl:setVisible(isTeamFull)
    --projectNode:setVisible(isTeamFull)
end

local function refreshFactoryRedPoint(self)
    local panelMainbutton1  = self._panelMainBelow:getChildByName("Panel_main_button1")

    local buttonControl     = panelMainbutton1:getChildByName("Button_main_factory")
    local imageControl      = buttonControl:getChildByName("ProjectNode_notice_2")
    --local projectNode       = buttonControl:getChildByName("ProjectNode_notice_1")
    local isFactoryFinish = false
    for i,v in ipairs(KUtil.getProducingCardList()) do
        if v.nEndTime == 0 then
            isFactoryFinish = true
            break
        end
    end
    if self._isFactoryFinish ~= nil and self._isFactoryFinish == isFactoryFinish then
        return
    end
    self._isFactoryFinish = isFactoryFinish
    imageControl:setVisible(isFactoryFinish)
    --projectNode:setVisible(isFactoryFinish)
end

local function refreshMissionRedPoint(self)
    local panelMainbutton1  = self._panelMainBelow:getChildByName("Panel_main_button1")

    local buttonControl     = panelMainbutton1:getChildByName("Button_main_mission")
    local imageControl      = buttonControl:getChildByName("ProjectNode_notice_2")
    --local projectNode       = buttonControl:getChildByName("ProjectNode_notice_1")
    local isMissionFinish   = false
    for i, tOneMission in ipairs(KPlayer.tMissionData.tMissionList) do
        local tMissionConfig = KUtil.getMissionConfig(tOneMission.nID)
        local isCompleted    = KUtil.isMissionCompleted(tMissionConfig)
        --if isCompleted then
        if isCompleted and tMissionConfig.nNumero == 0 then -- todo by sunxun 2016/09/15 for 屏蔽紧急任务对红点的影响
            isMissionFinish  = true
            break
        end
    end
    
    if self._isMissionFinish ~= nil and self._isMissionFinish == isMissionFinish then
        return
    end
    self._isMissionFinish = isMissionFinish
    
    imageControl:setVisible(isMissionFinish)
    --projectNode:setVisible(isMissionFinish)
end

local function refreshRepairRedPoint(self)
    local panelMainbutton1      = self._panelMainBelow:getChildByName("Panel_main_button1")
    local buttonControl         = panelMainbutton1:getChildByName("Button_main_supply")
    local imageControl          = buttonControl:getChildByName("ProjectNode_notice_2")
    --local projectNode           = buttonControl:getChildByName("ProjectNode_notice_1")
    
    local isNeedRepair          = (KUtil.needRepairCardID() ~= 0)
    local isNeedSupply          = (KUtil.needSupplyTeamID() ~= 0)
    local isNeedRescue          = KUtil.isNeedRescue()
    
    local isShowRedPoint = false
    if isNeedRepair or isNeedSupply or isNeedRescue then isShowRedPoint = true end

    imageControl:setVisible(isShowRedPoint)
    --projectNode:setVisible(isShowRedPoint) 
end

local function refreshSignRedPoint(self)
    local bVisible      = false
    local tSignData     = KUtil.getSignData()
    if not tSignData.bSign then
        if KConfig:getLine("sign", tSignData.nCount + 1) ~= nil then
            bVisible    = true
        end
    end

    local mainNode      = self._mainLayout
    local buttonSign    = self._panelLeftButton:getChildByName("Button_sign")

    local imageControl  = buttonSign:getChildByName("ProjectNode_notice_2")
    --local projectNode = buttonSign:getChildByName("ProjectNode_notice_1")

    imageControl:setVisible(bVisible)
    --projectNode:setVisible(bVisible)
end

function KUIOfficeMainLayer:isAccessMissionaNotice()
    return KPlayer.bAccessMission
end

function KUIOfficeMainLayer:refreshAccessMissionaNotice(bInit)
    local mainNode          = self._mainLayout
    local nodeAccessMission = mainNode:getChildByName("ProjectNode_extend_mission")
    nodeAccessMission:setVisible(KPlayer.bAccessMission and (not self:isStoryRedPoint()))
    if bInit then
        local panel         = nodeAccessMission:getChildByName("Panel_1")
        local textTips      = panel:getChildByName("Text_lock_tips")
        textTips:setString(KUtil.getStringByKey("mission.accessTips"))
        local function onClick(sender, type)
            if ccui.TouchEventType.ended ~= type then return end
            KPlayer.bAccessMission      = false
            nodeAccessMission:setVisible(KPlayer.bAccessMission)
            self._parent:addNode("Mission", 5)
            self:refreshStoryRedPoint()
        end
        panel:addTouchEventListener(onClick)
    end
end

local function doReplaceOnce(oldStr, subStr, plain)
    local startIndex   = 1
    while true do 
        local i, j = string.find(oldStr, subStr, startIndex, plain)
        if not i then 
            return oldStr
        end
        local beforeSubStr = string.sub(oldStr, 1, i - 1)
        local afterSubStr  = string.sub(oldStr, j + 1, -1)
        oldStr             = beforeSubStr .. "*" .. afterSubStr
        startIndex         = j + 1 + (1 - #subStr)
    end
end
local function initOneMessage(self, control, dataInfo)
    control:setName(tostring(dataInfo.nID))
    local textName = control:getChildByName("Text_name")

    local messageData = dataInfo.message
    if messageData.nSrcRoleID == KPlayer.id then
        local selfSendMessageColor = KConfig.otherSetting["tSelfSendMessageColor"]
        textName:setColor(cc.c3b(unpack(selfSendMessageColor, 1, table.maxn(selfSendMessageColor))))
    else
        local otherSendMessageColor = KConfig.otherSetting["tOtherSendMessageColor"]
        textName:setColor(cc.c3b(unpack(otherSendMessageColor, 1, table.maxn(otherSendMessageColor))))
    end

    local messageInformation    = messageData.szMessage
    local imageErrorPattern     = string.char(0xED) .. ".."

    for k, v in pairs(KConfig.messageSensitiveword) do
        messageInformation = doReplaceOnce(messageInformation, v.szText, true)
    end

    messageInformation = doReplaceOnce(messageInformation, imageErrorPattern, false)

    if messageData.szType == CHAT_TYPE.SEND_PRIVATE then
        textName:setString(KUtil.formatStringByKey("message.private.send", messageData.szDstRoleName, messageInformation))
    elseif messageData.szType == CHAT_TYPE.PRIVATE then
        textName:setString(KUtil.formatStringByKey("message.private.recv", messageData.szSrcRoleName, messageInformation))
    elseif messageData.szType == CHAT_TYPE.GLOBAL then
        textName:setString(KUtil.formatStringByKey("message.global", messageData.szSrcRoleName, messageInformation))
    end

    control:setTouchEnabled(true)
    local function onTextTouched(sender, type)
        if type == ccui.TouchEventType.ended then
            local imageInputBox         = self._chatDialog:getChildByName("Image_input_box")
            local textFieldMessageInput = imageInputBox:getChildByName("TextField_message_input")

            local szDstRoleName = nil
            if messageData.szType == CHAT_TYPE.SEND_PRIVATE then
                szDstRoleName = messageData.szDstRoleName
            elseif messageData.szType == CHAT_TYPE.PRIVATE then
                szDstRoleName = messageData.szSrcRoleName
            elseif messageData.szType == CHAT_TYPE.GLOBAL then
                szDstRoleName = messageData.szSrcRoleName
            end

            if not szDstRoleName then
                return
            end

            textFieldMessageInput:setString("@" .. szDstRoleName .. " ")
        end
    end
    control:addTouchEventListener(onTextTouched)
end

local function addGlobalScrollPageView(self)
    local scrollView            = self._chatDialog:getChildByName("ScrollView_text_contant") 

    local showListData = {}

    for i, v in ipairs(KPlayer.tMessageData[CHAT_CHANEL_TYPE.GLOBAL]) do
        local itemData = {nID = i, message = v}
        table.insert(showListData, itemData)
    end  

    local refreshCall = function(control, dataInfo)
        initOneMessage(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        itemBase    = self._chatPanelMessageUI,
        dataList    = showListData,
        refreshCall = refreshCall,
        isCutIn     = false,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)

    scrollView:jumpToBottom()
    self._pageData.forceRefreshList()
end

local function refreshMessageRedPoint(self)
    local visible               = KUtil.hasNewPrivateMessage()
    local mainNode              = self._mainLayout
    local panelMessage          = mainNode:getChildByName("Panel_message")
    local projectMainMessage    = panelMessage:getChildByName("ProjectNode_main_message")

    local buttonMainMessage     = projectMainMessage:getChildByName("Button_main_message")
    local projectNode           = buttonMainMessage:getChildByName("ProjectNode_notice")

    local imageMainMessagePush  = projectNode:getChildByName("Panel_notice_ops")
    imageMainMessagePush:setVisible(visible)
end

local function addPrivateScrollPageView(self)
    local mainNode              = self._mainLayout
    local panelMessage          = mainNode:getChildByName("Panel_message")
    local projectNodeMessage    = panelMessage:getChildByName("ProjectNode_message")
    local scrollView            = projectNodeMessage:getChildByName("ScrollView_text_contant") 

    local showListData = {}
    for i, v in ipairs(KPlayer.tMessageData[CHAT_CHANEL_TYPE.PRIVATE]) do
        local itemData = {nID = i, message = v}
        table.insert(showListData, itemData)
    end  
    local refreshCall = function(control, dataInfo)
        initOneMessage(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        itemBase    = self._chatPanelMessageUI,
        dataList    = showListData,
        refreshCall = refreshCall,
        isCutIn     = false,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)

    scrollView:jumpToBottom()
    self._pageData.forceRefreshList()

    KPlayer.bHasNewPrivateMessage = false

    refreshMessageRedPoint(self)
end

function KUIOfficeMainLayer:showChatMessageRedPoint(bVisible)
    local mainNode              = self._mainLayout
    local panelMessage          = mainNode:getChildByName("Panel_message")
    local buttonMainMessage     = panelMessage:getChildByName("Button_main_message")
    local imageMainMessagePush  = buttonMainMessage:getChildByName("Image_main_message_push")
    imageMainMessagePush:setVisible(bVisible)
end

local function appendAllNewMessage(self)
    local tNewMessageList = {}
    local tMessageList = KPlayer.tMessageData.tMessageList
    for _, v in ipairs(tMessageList) do
        if not v.bRead then
            table.insert(tNewMessageList, v)
        end
    end

    if #tNewMessageList == 0 then
        return
    end

    local mainNode              = self._mainLayout
    local oneselfID             = KPlayer.id
    local panelMessage          = mainNode:getChildByName("Panel_message")
    local projectNodeMessage    = panelMessage:getChildByName("ProjectNode_message")
    local scrollViewTextContant = projectNodeMessage:getChildByName("ScrollView_text_contant") 
    local childrenMessageUIs    = scrollViewTextContant:getChildren()

    if #tNewMessageList >= CHAT_CONST.MAX_CHAT_MESSAGE_COUNT then
        scrollViewTextContant:removeAllChildren()
        while #tNewMessageList > CHAT_CONST.MAX_CHAT_MESSAGE_COUNT do
            table.remove(tNewMessageList, 1)
        end
    end

    local nOutOfCount = #tNewMessageList + #childrenMessageUIs - CHAT_CONST.MAX_CHAT_MESSAGE_COUNT
    for i = 1, nOutOfCount do
        KUtil.removeBarFromScrollView(scrollViewTextContant, 1)
    end

    for _, v in ipairs(tNewMessageList) do
        appendOneMessage(self, v)
    end
end

local function onNewMessageReceived(self, tOneMessageData)
    if self._openMessage then
        appendAllNewMessage(self)
        self:showChatMessageRedPoint(false)
        return
    end

    if tOneMessageData.nType ~= CHAT_CONST.CHAT_TYPE_PRIVATE then
        return
    end

    self:showChatMessageRedPoint(true)
end

local function refreshMailRedPoint(self)
    local visible       = KUtil.hasNewMail()
    local buttonMail    = self._panelLeftButton:getChildByName("Button_mail")
    local imageControl  = buttonMail:getChildByName("ProjectNode_notice_2")
    --local projectNode = buttonMail:getChildByName("ProjectNode_notice_1")
    imageControl:setVisible(visible)
    --projectNode:setVisible(visible)
end

local function refreshMessageButtonState(self)
    local imageClickBase        = self._chatDialog:getChildByName("Image_click_base")
    local buttonGlobal          = imageClickBase:getChildByName("Button_public")
    local buttonPrivate         = imageClickBase:getChildByName("Button_private")
    local m_tButtonStateTexture = 
    {
        ["buttonNormalTexture"]   = "res/ui/ui_material/message/xx_click_button_active.png",
        ["buttonPressTexture"]    = "res/ui/ui_material/message/xx_click_button_v1.png",
        ["buttonDisableTexture"]  = "res/ui/ui_material/message/xx_click_button_active.png"
    }
    if self._isGlobalPanel then 
        buttonGlobal:loadTextures(m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonPressTexture)
        buttonPrivate:loadTextures(m_tButtonStateTexture.buttonNormalTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonDisableTexture)
        buttonGlobal:setTouchEnabled(false)
        buttonPrivate:setTouchEnabled(true)
    else
        buttonGlobal:loadTextures(m_tButtonStateTexture.buttonNormalTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonDisableTexture)
        buttonPrivate:loadTextures(m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonPressTexture)
        buttonGlobal:setTouchEnabled(true)
        buttonPrivate:setTouchEnabled(false)
    end
end

local function setBreatheEffect(self, imageViewChara)
    local scaleShiftX       = 1.002
    local scaleShiftY       = 1.002
    local moveShiftX        = 0
    local moveShiftY        = 1
    local scaleDuration     = 0.8
    local moveDuration      = 0.8 
    local breathSpanTime    = 0.1
    local breathInterval    = 2.5
    
    local breatheRepeat = imageViewChara:getActionByTag(ACTION_TAG_REPEAT_BREATHE)
    if breatheRepeat == nil then
        local oneOutBreath = cc.Spawn:create(
            cc.ScaleBy:create(scaleDuration, scaleShiftX, scaleShiftY),
            cc.MoveBy:create(moveDuration, cc.p(moveShiftX, moveShiftY))
        )
        local oneInBreath           = oneOutBreath:reverse()
        local breathSpanDelay       = cc.DelayTime:create(breathSpanTime)
        local breathIntervalDelay   = cc.DelayTime:create(breathInterval)
        local oneBreath = cc.Sequence:create(oneOutBreath, breathSpanDelay, oneInBreath, breathIntervalDelay)
        
        breatheRepeat = cc.RepeatForever:create(oneBreath)
        breatheRepeat:setTag(ACTION_TAG_REPEAT_BREATHE)
        
        imageViewChara:runAction(breatheRepeat)
    end
end

local function setSecretaryButtonState(button, bSelect, bDisable)
    local m_tButtonStateTexture = {
        ["buttonNormalTexture"]      = "res/ui/ui_material/public/button_currency_small.png",
        ["buttonPressTexture"]       = "res/ui/ui_material/public/button_currency_small_active.png",
        ["buttonDisableTexture"]     = "res/ui/ui_material/public/button_currency_small_disable.png"
    }
    
    if bDisable then
        button:loadTextures(m_tButtonStateTexture.buttonDisableTexture, m_tButtonStateTexture.buttonDisableTexture, m_tButtonStateTexture.buttonDisableTexture)
    elseif bSelect then
        button:loadTextures(m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonNormalTexture, m_tButtonStateTexture.buttonDisableTexture)
    else
        button:loadTextures(m_tButtonStateTexture.buttonNormalTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonDisableTexture)
    end
    
end

local function isHaveSecretaryItem()
    local itemCount = KUtil.getItemCount(SECRETARY_STATE_ITEM_ID)
    return itemCount > 0
end

local function showSecretaryItemTip(self)
    local itemConfig = KUtil.getItemConfig(SECRETARY_STATE_ITEM_ID)
    assert(itemConfig)
    local tipStr = string.format(KUtil.getStringByKey("secretary.item"), itemConfig.szName)

    local function onShowShop()
        self._parent:addNode("Shop")
    end

    showConfirmation(tipStr, onShowShop)
end

local function refreshSecretaryPanel(self)
    local mainNode                  = self._mainLayout
    local projectNodeSecretary      = mainNode:getChildByName("ProjectNode_secretary")
    local panelSecretary           = projectNodeSecretary:getChildByName("Panel_secretary")
    local imageSecretaryBase        = panelSecretary:getChildByName("Image_secretary_base")
    local buttonShowCaptain         = imageSecretaryBase:getChildByName("Button_show_captain")
    local buttonShowGiven           = imageSecretaryBase:getChildByName("Button_show_given")
    local buttonShowRegular         = imageSecretaryBase:getChildByName("Button_show_regular")
    local buttonShowMiddle          = imageSecretaryBase:getChildByName("Button_show_middle")
    
    local secretaryData     = KPlayer.tSecretaryData
    local secretaryType     = secretaryData.nType
    local secretaryState    = secretaryData.nState

    if secretaryType == SECRETARY_TYPE.TEAM_LEADER then
        setSecretaryButtonState(buttonShowCaptain, true, false)
        setSecretaryButtonState(buttonShowGiven, false, false)
    elseif secretaryType == SECRETARY_TYPE.DESIGNATE then
        setSecretaryButtonState(buttonShowCaptain, false, false)
        setSecretaryButtonState(buttonShowGiven, true, false)
    end

    local isHaveItem =  isHaveSecretaryItem()
    if not isHaveItem then
        setSecretaryButtonState(buttonShowRegular, false, true)
        setSecretaryButtonState(buttonShowMiddle, false, true)
    elseif secretaryState == SECRETARY_STATE.NORMAL then
        setSecretaryButtonState(buttonShowRegular, true, false)
        setSecretaryButtonState(buttonShowMiddle, false, false)
    elseif secretaryState == SECRETARY_STATE.MID_BREAK then
        setSecretaryButtonState(buttonShowRegular, false, false)
        setSecretaryButtonState(buttonShowMiddle, true, false)
    end
end

local function refreshCharacterImage(self)
    local  displayCard = KUtil.getSecretaryCard()
    assert(displayCard, "can not find card for displaying")

    local secretaryData = KPlayer.tSecretaryData
    local secretaryState = secretaryData.nState
    local isBreak = false
    if isHaveSecretaryItem() and secretaryState == SECRETARY_STATE.MID_BREAK then isBreak = true end
    
    local cardImagePath = KUtil.getCardImagePath(displayCard, false, isBreak)
    if self._currentDisplayCardID == displayCard.nID and
        self._currentDisplayCardImage == cardImagePath then
        return
    end
    
    self._currentDisplayCardID    = displayCard.nID
    self._currentDisplayCardImage = cardImagePath
    
    local mainNode = self._mainLayout
    local imageCharacter = mainNode:getChildByName("Image_main_chara")
    imageCharacter:loadTexture(cardImagePath)
    
    setBreatheEffect(self, imageCharacter)
end

function KUIOfficeMainLayer:isStoryRedPoint()
    return self._isStoryRedPoint
end

function KUIOfficeMainLayer:refreshStoryRedPoint()
    self._isStoryRedPoint  = false
    if not self:isAccessMissionaNotice() and KUtil.isSysOpened("story") then
        if self._canGainStoryReward and KUtil.canGainStoryReward(self._canGainStoryReward) then
            self._isStoryRedPoint = true
        else
            local storyID     = KUtil.checkStoryReward() 
            if storyID then
                self._isStoryRedPoint = true
                self._canGainStoryReward = storyID
                return
            end
        end
    end
    local panelMainbutton2      = self._panelMainBelow:getChildByName("Panel_main_button2")
    local buttonControl         = panelMainbutton2:getChildByName("Button_main_collection")
    local imageControl          = buttonControl:getChildByName("ProjectNode_notice_2")
    imageControl:setVisible(self._isStoryRedPoint)

    local projectNode = self._mainLayout:getChildByName("ProjectNode_studio_studio_theatre")
    projectNode:setVisible(self._isStoryRedPoint)
end

local function refreshBattleRedPoint(self)
    local mainNode           = self._mainLayout
    local projectMain        = mainNode:getChildByName("ProjectNode_main")
    local panelMain          = projectMain:getChildByName("Panel_1")
    local panelCommonAttack  = panelMain:getChildByName("Panel_button_attack")
    local buttonBattle       = panelCommonAttack:getChildByName("Button_main_operation")
    local projectNode        = buttonBattle:getChildByName("ProjectNode_notice_ops")

    --check one time
    --if self._isZoonOpen == nil then
    --    local isBattlePoint = KUtil.checkBattleRedPoint()
    --    self._isZoonOpen = isBattlePoint
    --end

    local isExpeditionFinish = (KUtil.getExpeditionFinishArea() ~= 0)
    local isRedPoint = isExpeditionFinish-- or self._isZoonOpen

    projectNode:setVisible(isRedPoint)    
end

local function refreshRankRedPoint(self)
    local panelMainbutton2      = self._panelMainBelow:getChildByName("Panel_main_button2")
    local buttonControl         = panelMainbutton2:getChildByName("Button_main_rank")
    local imageControl          = buttonControl:getChildByName("ProjectNode_notice_2")
    --local projectNode         = projectNode:getChildByName("ProjectNode_notice_1")

    local isRedPoint = KUtil.checkRankRedPoint()

    imageControl:setVisible(isRedPoint)
    --projectNode:setVisible(isRedPoint)
end

local function showOpenSettingPanel(self, isOpen)
    local mainNode             = self._mainLayout
    local panelSetting         = mainNode:getChildByName("Panel_set_up")
    local projectNode          = panelSetting:getChildByName("ProjectNode_set_up")
    local buttonBase           = projectNode:getChildByName("Button_base")
    local projectButton        = mainNode:getChildByName("ProjectNode_left_button")
    local panelLeftButton      = projectButton:getChildByName("Panel_office_left_button")
    local buttonSetting        = panelLeftButton:getChildByName("Button_main_setup")

    buttonBase:setEnabled(isOpen)
    buttonSetting:setEnabled(not isOpen)

    if isOpen then
        self:refreshSettingPanel()
        self:playAnimation("ProjectNode_set_up", "start")
    else
        self:playAnimation("ProjectNode_set_up", "End")
    end
end

local function showOpenMessagePanel(self, isOpen)
    -- 打开聊天面板
    local mainNode              = self._mainLayout
    local panelMessage          = mainNode:getChildByName("Panel_message")
    local projectMessage        = panelMessage:getChildByName("ProjectNode_message")
    local panelMessageAni       = projectMessage:getChildByName("Panel_message")

    local buttonControl         = self._panelChat:getChildByName("Button_chat")
    panelMessageAni:setTouchEnabled(isOpen)
    buttonControl:setEnabled(not isOpen)

    if isOpen then
        self:playAnimation("ProjectNode_main_message", "start")
        self:playAnimation("ProjectNode_message", "End")

    else
        self:playAnimation("ProjectNode_main_message", "End")
        self:playAnimation("ProjectNode_message", "start")
    end
end

local function playSecretaryAnimation(self, isShow)
    if isShow then
        if self._openSecretary then
            self:playAnimation("secretary", "show2")
        else
            self:playAnimation("secretary", "show1")
        end
    else
        if self._openSecretary then
            self:playAnimation("secretary", "hide2")
        else
            self:playAnimation("secretary", "hide1")
        end
    end
end

local function checkOpenedActivity(self)
    --buidlactivity
    local buttonBuild    = self._build:getChildByName("Button_build")
    local isOpenedBuildActivity = KUtil.isOpenedBuildActicity()
    buttonBuild:setVisible(isOpenedBuildActivity)
end

function KUIOfficeMainLayer:uiCutOff(duration)
    self:playCloseAnimation()
end

function KUIOfficeMainLayer:uiCutIn(duration)
    self:playStartAnimation()
end

local function autoAddResources(self, addCounts)
    addCounts = addCounts or 1

    KPlayer.lastAddResourceTime = KPlayer.lastAddResourceTime + ADD_RESOURCE_OFFSET * addCounts
    cclog("lastAddResourceTime: " .. os.date("%Y-%m-%d %H:%M:%S", KPlayer.lastAddResourceTime))

    local addResourceName = {
        "oil", "ammo", "steel", "people",
    }

    local maxResourceName = {
        "nMaxOil", "nMaxAmmo", "nMaxSteel", "nMaxPeople",
    }

    for i, name in ipairs(addResourceName) do
        local resourceMaxCount = KUtil.getPlayerLevelInfo(KPlayer.level, maxResourceName[i])
        local resourceCount    = KPlayer[CURRENCY_KEY[i]]
        local resourceAdd      = KPlayer[AUTO_ADD_RESOURCES[i]] * addCounts
        if resourceCount < resourceMaxCount then
            if resourceCount + resourceAdd > resourceMaxCount then
                KPlayer[CURRENCY_KEY[i]] = resourceMaxCount
            else
                KPlayer[CURRENCY_KEY[i]] = KPlayer[CURRENCY_KEY[i]] + resourceAdd
            end
        end
    end
    refreshBaseInfo(self)
    cclog("currentResources: oil: %d, ammo: %d, steel: %d, people: %d", KPlayer.oil, KPlayer.ammo, KPlayer.steel, KPlayer.people)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_RESOURCE)
end

local function tryDoAutoAddResources(self)
    local currentServerTime = KUtil.getCurrentServerTime()
    if KPlayer.lastAddResourceTime == nil or KPlayer.lastAddResourceTime == 0 then
        KPlayer.lastAddResourceTime = currentServerTime
        return
    end

    if currentServerTime < KPlayer.lastAddResourceTime + ADD_RESOURCE_OFFSET then
        return
    end

    if currentServerTime > KPlayer.lastAddResourceTime + 2 * ADD_RESOURCE_OFFSET then
        local addCounts = math.ceil((currentServerTime - KPlayer.lastAddResourceTime) / ADD_RESOURCE_OFFSET)
        autoAddResources(self, addCounts)
        return
    end

    autoAddResources(self)
end

local function switchPixelQuality(pixelQuality)
    KUtil.configPixelQuality(pixelQuality)

    local director      = cc.Director:getInstance()
    local textureCache  = director:getTextureCache()
    textureCache:removeAllTextures()    

    local newOfficeScene = require("src/ui/office/KUIOfficeScene").create("switchPixelQuality")
    local newMainLayer   = newOfficeScene._mainLayer

    delayExecute(newMainLayer._mainLayout, function() newMainLayer:setSettingPanelOpenState(true) end, 0.01)
    
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "2replaceScene")
    director:replaceScene(newOfficeScene)
end

local function tryOpenNoticeNode(self)
    if KUtil.isGuide() then return end
    if not m_bIsFirstTime then return end
    m_bIsFirstTime = false

    local setting = require("src/logic/KSetting")
    local lastShowTime    = setting.getInt(setting.Key.LAST_SHOW_TIME, 0)
    --reset time
    if lastShowTime ~= 0 then
        local tLastDate    = os.date("*t", lastShowTime)
        local tCurrentDate = os.date("*t", KUtil.getLocalTime())
        if tLastDate.day ~= tCurrentDate.day then
            setting.setInt(setting.Key.TODAY_SHOW_TIMES, 0)
        end
    end
    local todayShowTimes  = setting.getInt(setting.Key.TODAY_SHOW_TIMES, 0)
    if todayShowTimes < 1 then
        setting.setInt(setting.Key.TODAY_SHOW_TIMES, todayShowTimes + 1)
        setting.setInt(setting.Key.LAST_SHOW_TIME, KUtil.getLocalTime())
        self._parent:addNode("Announce")
    end
end

local function refreshRechargeButton(self)
    local isRecharge = KUtil.isFirstRecharge()
    local isShowRecharge = not isRecharge
    if self._isShowRecharge == isShowRecharge then return end

    local mainNode            = self._mainLayout
    local buttonFristRecharge = mainNode:getChildByName("ProjectNode_first")

    buttonFristRecharge:setVisible(isShowRecharge)
    self._isShowRecharge = isShowRecharge
end

local function refreshLoadTalk(self)
    local mainNode             = self._mainLayout
    local panelSetting         = mainNode:getChildByName("Panel_set_up")
    local projectNode          = panelSetting:getChildByName("ProjectNode_set_up")
    local projectSetUp         = projectNode:getChildByName("ProjectNode_set_up")
    local anipanelSetting      = projectSetUp:getChildByName("Panel_set_up")

    local controlSettingBase   = anipanelSetting:getChildByName("Image_set_up_base")
    
    local buttonLoadTalk       = controlSettingBase:getChildByName("Button_2")
    local KSetting = require("src/logic/KSetting")
    if not C_AsyncDownloadFile or not UPDATE_V2_ENABLE or KSetting.getBool(KSetting.Key.LOAD_TALK) then 
        buttonLoadTalk:setTouchEnabled(false)
        KUtil.setWidgetGray(buttonLoadTalk)
    else
        buttonLoadTalk:setTouchEnabled(false)
    end

    local tInfo
    if self._talkUpdate then
        tInfo = self._talkUpdate.getUpdateInfo()
    end
    local imageTalk            = controlSettingBase:getChildByName("Image_loadingbar_base")
    local LoadingBarTalk       = controlSettingBase:getChildByName("LoadingBar_1")
    imageTalk:setVisible(false)
    LoadingBarTalk:setVisible(false)
    if tInfo then
        imageTalk:setVisible(true)
        LoadingBarTalk:setVisible(true)
        if tInfo.totalSize and tInfo.fileSize and tInfo.totalSize > 0 then
            LoadingBarTalk:setPercent(tInfo.fileSize * 100 / tInfo.totalSize)
        end
    end
    return tInfo
end

local function refreshExpBuff(self, nowTime)
    nowTime = nowTime or os.time()

    local mainNode      = self._mainLayout
    local buffIcon      = mainNode:getChildByName("ProjectNode_exp_buff")
    local panelExp      = buffIcon:getChildByName("Panel_exp_buff")

    local hasExpBuff       = false
    local expBuffData      = KPlayer.tExpBuffData
    local serverTime       = KUtil.getServerTime(nowTime)
    if expBuffData.nPercent > 0 and expBuffData.nExpireTime > serverTime then
        hasExpBuff    = true
    end

    buffIcon:setVisible(hasExpBuff)
    if hasExpBuff then
        local buttonExp     = panelExp:getChildByName("Button_exp")
        local percentText   = buttonExp:getChildByName("BitmapFontLabel_exp")
        percentText:setString(string.format(KUtil.getStringByKey("common.percent"), math.floor(expBuffData.nPercent)))

        if expBuffData.nExpireTime - serverTime <= BLINK_EXP_BUFF_TIME then
            self:blinkExpBuffImg(panelExp)
        elseif panelExp:getActionByTag(ACTION_TAG_BLINK_EXP_BUFF) then 
            panelExp:stopActionByTag(ACTION_TAG_BLINK_EXP_BUFF)
        end

        if self._refreshExpBuffTime then
            local nodeBuffTime  = buffIcon:getChildByName("ProjectNode_time")
            local panelBuffTime = nodeBuffTime:getChildByName("Panel_exp_buff_time")
            local imageBuffTime = panelBuffTime:getChildByName("Image_time_base")
            local labelBuffTime = imageBuffTime:getChildByName("BitmapFontLabel_time")
            labelBuffTime:setString(KUtil.getLeftTime(expBuffData.nExpireTime - serverTime))
        end
    elseif panelExp:getActionByTag(ACTION_TAG_BLINK_EXP_BUFF) then
        panelExp:stopActionByTag(ACTION_TAG_BLINK_EXP_BUFF)
    end
end

local function tryReSendReceiptInfo(self, nowTime)
    nowTime = nowTime or os.time()

    if not m_nLastReSendReceiptTime then m_nLastReSendReceiptTime = nowTime end

    if nowTime - m_nLastReSendReceiptTime <= 10 then return end

    -- resend receipt info to server
    -- send 1 receipt per 60s
    local KSetting  = require("src/logic/KSetting")
    local roleId    = KPlayer.id

    for index = 1, 100 do -- we had reason enough for believe 100 is most limit.
        local payRoleIDKey  = KSetting.Key.PAY_ROLE_ID_KEY_INDEX .. "_" .. index
        local payReceiptKey = KSetting.Key.PAY_RECEIPT_KEY_INDEX .. "_" .. index

        roleIdInfo  = KSetting.getInt(payRoleIDKey, 0)
        rolePayInfo = KSetting.getString(payReceiptKey, "")
        if roleIdInfo ~= 0 then
            -- send roleId and receiptInfo to server
            cclog(
                "-----> Find Existed Receipt And Send To Server ----->\n<%s : %d>\n<%s : %s>", 
                payRoleIDKey, roleIdInfo, payReceiptKey, rolePayInfo
            )
            require("src/network/KC2SProtocolManager"):IOSPayVerify(rolePayInfo)
            break
        end
    end

    --cclog("-----> tryReSendReceiptInfo Success~")
    m_nLastReSendReceiptTime = nowTime
end

function KUIOfficeMainLayer:activate(nowTime)
    if nowTime == self._nowTime then return end

    refreshFactoryRedPoint(self)
    refreshRepairRedPoint(self)
    refreshBattleRedPoint(self)
    refreshCharacterImage(self) 
    refreshRankRedPoint(self)
    refreshMailRedPoint(self)
    refreshExpBuff(self, nowTime)
    tryDoAutoAddResources(self)
    tryOpenNoticeNode(self)
    refreshRechargeButton(self)
    checkOpenedActivity(self)
    self:tryOpenSPSignNode()
    self:refreshStoryRedPoint()
    tryReSendReceiptInfo(self, nowTime)

    local nHour = math.floor(nowTime / 3600)
    if nHour ~= m_nHour then
        m_nHour = nHour
        refreshSignRedPoint(self)
    end

    if self._talkUpdate then
        local tInfo = refreshLoadTalk(self)
        local tInfo = self._talkUpdate.getUpdateInfo()
        if tInfo.loadState == "newest" then
            C_StopAllDownload()
            self._talkUpdate = nil
            KThreadManager.release()
        end
    end

    self._nowTime       = nowTime
end

function KUIOfficeMainLayer:addCustomEvent(eventType, callbackFunc)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    assert(eventDispatchCenter.EventType[eventType] ~= nil, "Add custom event but event is not exist in KEventDispatchCenter.EventType :" .. eventType)
    table.insert(self._eventList, 
        {
            ["eventType"]       = eventType,
            ["callbackFunc"]    = callbackFunc
        }
    )
    eventDispatchCenter:registerEvent(eventType, callbackFunc)
end

local function refreshDisableArea(self)
--[[    
    local mainNode       = self._mainLayout
    local panelMessage   = mainNode:getChildByName("Panel_message")
    local projectNode    = panelMessage:getChildByName("ProjectNode_message")

    local panelSetUp     = mainNode:getChildByName("Panel_set_up")
    local projectNode    = panelSetUp:getChildByName("ProjectNode_set_up")
    projectNode:setVisible(false)

    local buttonGM              = mainNode:getChildByName("Button_gm")   
    buttonGM:setVisible(KPlayer.bGM)
    local imageGm = buttonGM:getChildByName("Image_gm_base")  
    imageGm:setVisible(false)

    local nodeBG                = mainNode:getChildByName("Node_bg")
    local imageQQChat           = nodeBG:getChildByName("Image_qq_chat")
    imageQQChat:setVisible(false)

    local disableButtonLsit = 
    {
        "Button_main_decoration",
        "Button_main_friend",
        "Button_main_item",
        "Button_main_shop",
        "Button_main_rank",
        "Button_main_record",
        "Button_main_collection",
    }
    for _, buttonName in pairs(disableButtonLsit) do
        local buttonControl = self._panelMainBelow:getChildByName(buttonName)
        local imageRedPoint = buttonControl:getChildByName("ProjectNode_notice_2")
        imageRedPoint:setVisible(false)
    end
]]
    if not IS_EXCHANGE then
        local buttonExchange = self._panelLeftButton:getChildByName("Button_package")
        buttonExchange:setVisible(false)
    end

    local buttonMail = self._panelLeftButton:getChildByName("Button_mail")
    buttonMail:getChildByName("ProjectNode_notice_2"):setVisible(false)

    self._panelServiceActivity:setVisible(false)

    local mainNode              = self._mainLayout
    local panelSetting          = mainNode:getChildByName("Panel_set_up")
    local projectNode           = panelSetting:getChildByName("ProjectNode_set_up")
    local projectNodeSetUp      = projectNode:getChildByName("ProjectNode_set_up")
    local panelSetUp            = projectNodeSetUp:getChildByName("Panel_set_up")
    local controlSettingBase    = panelSetUp:getChildByName("Image_set_up_base")
    local button2               = controlSettingBase:getChildByName("Button_2")
    button2:setVisible(false) 
    button2:setTouchEnabled(false)
    local LoadingBar            = controlSettingBase:getChildByName("LoadingBar_1")
    LoadingBar:setVisible(false)

    local projectButton         = mainNode:getChildByName("ProjectNode_left_button")
    local panelLeftButton       = projectButton:getChildByName("Panel_office_left_button")
    local buttonPackage         = panelLeftButton:getChildByName("Button_package")
    buttonPackage:setVisible(false)
    button2:setTouchEnabled(false)
end

local function refreshSetting(self)
    local mainNode             = self._mainLayout
    local panelSetting         = mainNode:getChildByName("Panel_set_up")
    local projectNode          = panelSetting:getChildByName("ProjectNode_set_up")
    local buttonBase           = projectNode:getChildByName("Button_base")
    local projectSetUp         = projectNode:getChildByName("ProjectNode_set_up")
    local AnipanelSetting      = projectSetUp:getChildByName("Panel_set_up")

    local controlSettingBase   = AnipanelSetting:getChildByName("Image_set_up_base")
    local sliderMusic          = controlSettingBase:getChildByName("Slider_music")
    local sliderEffect         = controlSettingBase:getChildByName("Slider_sound")

    local checkBoxHigh   = controlSettingBase:getChildByName("CheckBox_picture_1")
    local checkBoxMedian = controlSettingBase:getChildByName("CheckBox_picture_2")
    local checkBoxLow    = controlSettingBase:getChildByName("CheckBox_picture_3")
    checkBoxHigh:setSelected(false)
    checkBoxMedian:setSelected(false)
    checkBoxLow:setSelected(false)

    local volume = KSound.getMusicVolume()
    sliderMusic:setPercent(volume * 100)

    local volume = KSound.getEffectVolume()
    sliderEffect:setPercent(volume * 100)

    local pixelQualitySelected = {
        [KUtil.PIXEL_QUALITY.HIGH]      = checkBoxHigh, 
        [KUtil.PIXEL_QUALITY.MEDIAN]    = checkBoxMedian,
        [KUtil.PIXEL_QUALITY.LOW]       = checkBoxLow,
    }
    local currentQuality = KUtil.getPixelQuality()
    local selectedRadio  = pixelQualitySelected[currentQuality]
    assert(selectedRadio ~= nil, "unknow pixel quality")
    selectedRadio:setSelected(true)

    refreshLoadTalk(self)

    buttonBase:setSwallowTouches(false)
    local function onButtonBaseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_SETTING)
        end
    end
    buttonBase:addTouchEventListener(onButtonBaseClick)
    buttonBase:setEnabled(false)
end

function KUIOfficeMainLayer:blinkExpBuffImg(panelExpBuff)
    local blinkAction = panelExpBuff:getActionByTag(ACTION_TAG_BLINK_EXP_BUFF)
    if not blinkAction then
        local seq = cc.Sequence:create(cc.FadeOut:create(0.5), cc.FadeIn:create(0.5));
        local repeatForever = cc.RepeatForever:create(seq)
        repeatForever:setTag(ACTION_TAG_BLINK_EXP_BUFF)
        panelExpBuff:runAction(repeatForever)
    end
end

function KUIOfficeMainLayer:quitGameOption()
    local function confirmQuitGameFunction()
        cc.Director:getInstance():endToLua()
    end

    local function cancelQuitGameFunction()
    end

    showConfirmation(KUtil.getStringByKey("exit.tip"), confirmQuitGameFunction, cancelQuitGameFunction)
end

function KUIOfficeMainLayer:returnLoginOption()
    local function confirmReturnLoginFunction()
        KPlayer:Logout()
        
        local gameScene = require("src/ui/login/KUILoginScene").create()
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(gameScene)
        else
            cc.Director:getInstance():runWithScene(gameScene)
        end
    end

    local function cancelReturnLoginFunction()
    end
    showConfirmation(KUtil.getStringByKey("backLogin.tip"), confirmReturnLoginFunction, cancelReturnLoginFunction)
end

function KUIOfficeMainLayer:showQuitGameConfirmation(confirmationInfo, confirmFunction, cancelFunction, closeFunction)
    local currentScene = cc.Director:getInstance():getRunningScene() 

    local showNode = currentScene:getChildByName("showQuitGameConfirmationNode")
    if showNode then return end

    local showQuitGameConfirmationNode = require("src/ui/common/KUIShowQuitGameNode").create(currentScene)
    showQuitGameConfirmationNode:setConfirmationInfo(confirmationInfo)
    showQuitGameConfirmationNode:setOnTouchEvent(confirmFunction, cancelFunction, closeFunction)
    showQuitGameConfirmationNode:setName("showQuitGameConfirmationNode")
    currentScene:addChild(showQuitGameConfirmationNode, 999)
end

function KUIOfficeMainLayer:onExitClick()
    local function quitGameFunction()
        self:quitGameOption()
    end

    local function returnLoginFunction()
        self:returnLoginOption()
    end

    local function closeFunction()
    end

   self:showQuitGameConfirmation(KUtil.getStringByKey("chooseexit.tip"), quitGameFunction, returnLoginFunction, closeFunction)
end

function KUIOfficeMainLayer:initChatUI()
    local scrollViewTextContant = self._chatDialog:getChildByName("ScrollView_text_contant")
    self._chatPanelMessageUI    = scrollViewTextContant:getChildByName("Panel_contant")
    self._chatPanelMessageUI:retain()
    scrollViewTextContant:removeAllChildren()
end

function KUIOfficeMainLayer:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local list = self._animationList
    local mainNode                  = self._mainLayout
    local node                      = mainNode:getChildByName("Node_bg")
    list.Node_bg                    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_function.csb"),
            start = {0, 20}, End = {50, 65},
            }

    local nodeFunction              = node:getChildByName("ProjectNode_function")
    list.nodeFunction               = {
            KUtil.initAnimation(nodeFunction, "res/ui/animation_node/ani_office_button_function_1.csb"),
            switch1 = {60, 121,}, switch2 = {180, 240},
            }

    local node                      = mainNode:getChildByName("ProjectNode_left_button")
    list.ProjectNode_left_button    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_left.csb"),
            start = {0, 25}, End = {70, 95},
            }

    local panel                     = mainNode:getChildByName("Panel_message")
    local node                      = panel:getChildByName("ProjectNode_main_message")
    list.ProjectNode_main_message    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_message.csb"),
            start = {0, 25}, End = {50, 70},
            }

    local projectMessage            = panel:getChildByName("ProjectNode_message")
    local panelMessage              = projectMessage:getChildByName("Panel_message")
    local node                      = panelMessage:getChildByName("ProjectNode_dialog")
    list.ProjectNode_dialog    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_message.csb"),
            start = {0, 25}, End = {60, 85},
            }

    local node                      = mainNode:getChildByName("ProjectNode_hide_button")
    list.ProjectNode_hide_button    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_hide.csb"),
            start = {0, 25}, showAll = {90, 100}, hideAll = {60, 70}, End = {120, 135},
            }
    
    local node                      = mainNode:getChildByName("ProjectNode_main")
    list.ProjectNode_main           = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_main.csb"),
            start = {0, 60}, End = {100, 130},
            }
    
    local panelSetting              = mainNode:getChildByName("Panel_set_up")
    local projectNode               = panelSetting:getChildByName("ProjectNode_set_up")
    local node                      = projectNode:getChildByName("ProjectNode_set_up")
    list.ProjectNode_set_up         = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_set_up.csb"),
            start = {0, 25}, End = {50, 65},
            }

    local node                      = mainNode:getChildByName("ProjectNode_first")
    list.first                      = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_main_first.csb"),
            start = {0, 30}, loop = {95, 130}, End = {170, 195},
            }

    local node                    = mainNode:getChildByName("ProjectNode_divination")
    list.food                     = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_food.csb"),
            start = {0, 44}, loop = {44, 50}, End = {50, 65},
            }

    local node                       = mainNode:getChildByName("ProjectNode_exp_buff")
    list.expBuff                     = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_exp_buff.csb"),
            start = {0, 26}, loop = {26, 50}, End = {50, 65},
            }

    local node                       = mainNode:getChildByName("ProjectNode_exp_buff")
    local nodeBuffTime               = node:getChildByName("ProjectNode_time")
    list.expBuffTime                 = {
            KUtil.initAnimation(nodeBuffTime, "res/ui/animation_node/ani_office_exp_buff_time.csb"),
            start = {0, 15}, loop = {15, 50}, End = {50, 65},
            }
    -- local node                    = mainNode:getChildByName("ProjectNode_service_activity")
    -- list.serviceactivity          = {
    --         KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_service_activity.csb"),
    --         start = {0, 25}, loop = {25, 50}, End = {50, 65},
    --         }
    local node                    = mainNode:getChildByName("ProjectNode_secretary")
    list.secretary                = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_secretary.csb"),
            show1 = {0, 4}, show2 = {0, 15}, open = {4, 15}, close = {50, 61}, hide1 = {61, 65}, hide2 = {50, 65},
            }

    local node                    = mainNode:getChildByName("ProjectNode_build")
    list.build                    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_button_build.csb"),
            start = {0, 15}, loop = {15, 50}, End = {50, 65},
            }

    local node                    = mainNode:getChildByName("ProjectNode_studio_studio_theatre")
    list.story                    = {
            KUtil.initAnimation(node, "res/ui/animation_node/ani_office_studio_theatre.csb"),
            start = {0, 35}, loop = {35, 35}, End = {50, 65},
            }

    self._startAndEndAnimationList = {
            "Node_bg",
            "ProjectNode_left_button",
            "ProjectNode_main_message",
            "ProjectNode_dialog",
            "ProjectNode_hide_button",
            "ProjectNode_main",
            "first",
            "food",
            "expBuff",
            -- "serviceactivity",
            "build",
            "story",
        }
end

function KUIOfficeMainLayer:playAnimation(nodeName, animationName)
    local animation = self._animationList[nodeName]
    if animation and animation[animationName] then
        return KUtil.playAnimationByAnimation(animation[1], animation[animationName][1], animation[animationName][2])
    end

    return 0
end

function KUIOfficeMainLayer:playStartAnimation()
    for k,v in pairs(self._startAndEndAnimationList) do
        self:playAnimation(v, "start")
    end
    playSecretaryAnimation(self, true)
end

function KUIOfficeMainLayer:playCloseAnimation(callBack)
	if not self._startAndEndAnimationList then return end
	local maxTime = 0
    for k,v in pairs(self._startAndEndAnimationList) do
        local time = self:playAnimation(v, "End")
        maxTime = math.max(time, maxTime)
    end

    if self._refreshExpBuffTime then
        self._refreshExpBuffTime = false
        local time = self:playAnimation("expBuffTime", "End")
        maxTime = math.max(time, maxTime)
    end

    playSecretaryAnimation(self, false)

    if callBack then
        delayExecute(self._mainLayout, callBack, maxTime)
    end
end

function KUIOfficeMainLayer:onInitUI()
    refreshExpBuff(self)
    refreshSecretaryPanel(self)
    self:onInitAnimation()
    self:saveSameNode()
end

function KUIOfficeMainLayer:saveSameNode()
    local mainNode              = self._mainLayout
    local nodeBg                = mainNode:getChildByName("Node_bg")
    local nodeBgAni             = nodeBg:getChildByName("ProjectNode_function")
    self._panelFunctionButton   = nodeBgAni:getChildByName("Panel_office_function_button")
    local panelMainMask         = self._panelFunctionButton:getChildByName("Panel_main_below_mask")
    self._panelMainBelow        = panelMainMask:getChildByName("Panel_main_below")
    local projectButton         = mainNode:getChildByName("ProjectNode_left_button")
    self._panelLeftButton       = projectButton:getChildByName("Panel_office_left_button")

    local panelMessage          = mainNode:getChildByName("Panel_message")
    panelMessage:setVisible(false)
    local projectNodeMessage    = panelMessage:getChildByName("ProjectNode_message")
    projectNodeMessage:setVisible(false)
    local panelNodeMessage      = projectNodeMessage:getChildByName("Panel_message")
    local projectNodeDialog     = panelNodeMessage:getChildByName("ProjectNode_dialog")
    self._panelChat             = projectNodeDialog:getChildByName("Panel_message")
    self._chatDialog            = self._panelChat:getChildByName("Image_dialog")

    local projectMain           = mainNode:getChildByName("ProjectNode_main")
    local panelMain             = projectMain:getChildByName("Panel_1")
    self._panelCommonUI         = panelMain:getChildByName("Panel_common_UI")

    self._panelFoodNode         = mainNode:getChildByName("ProjectNode_divination")
    self._expBuffNode           = mainNode:getChildByName("ProjectNode_exp_buff")
    self._panelServiceActivity  = mainNode:getChildByName("ProjectNode_service_activity")
    self._panelSecretary        = mainNode:getChildByName("ProjectNode_secretary")
    self._build                 = mainNode:getChildByName("ProjectNode_build")

    local projectNoticeBase     = mainNode:getChildByName("ProjectNode_notice_base")
    projectNoticeBase:setVisible(false)
end

function KUIOfficeMainLayer:refreshUI()
    self:initChatUI()
    addGlobalScrollPageView(self)
    initFurniturePosiTion(self)
    refreshFurnitures(self)
    refreshFactoryRedPoint(self)
    refreshTeamRedPoint(self)
    refreshMissionRedPoint(self)
    refreshRepairRedPoint(self)
    refreshBaseInfo(self)
    refreshCoinCount(self)
    refreshCharacterImage(self)
    refreshBattleRedPoint(self)
    refreshDisableArea(self)
    refreshSetting(self)
    refreshSignRedPoint(self)
    refreshMailRedPoint(self)
    refreshMessageRedPoint(self)
    refreshMessageButtonState(self)
    refreshRechargeButton(self)
    refreshRankDetail(self)
    self:refreshStoryRedPoint()
    self:refreshAccessMissionaNotice(false)
end

function KUIOfficeMainLayer:refreshSettingPanel()
    refreshSetting(self)
end

function KUIOfficeMainLayer:setSettingPanelOpenState(isOpen)
    self._openSetting = isOpen
    showOpenSettingPanel(self, self._openSetting)
end

function KUIOfficeMainLayer:setMessagePanelOpenState(isOpen)
    self._openMessage = isOpen
    showOpenMessagePanel(self, self._openMessage)
end

function KUIOfficeMainLayer:trySendChatMessage(szChatType, messageStr, ...)
    if #messageStr < 1 then
        showNoticeByID("message.emptyMessageError")
        return
    end

    local maxMessageChatLen = KConfig.otherSetting["nMaxChatMessageLen"]

    if #messageStr > maxMessageChatLen then
        showNoticeByID("message.messageWordNumError")
        return
    end

    local nLastSendTime = KPlayer.tLastSendChatMessageTime[szChatType]
    local nMinInterval = KConfig.otherSetting["nMaxChatInterval_" .. szChatType]
    local nCurrentTime = os.time()

    if nCurrentTime < nLastSendTime + nMinInterval then
        showNoticeByID("message.in.min_send_interval")
        return
    end

    if szChatType == CHAT_TYPE.PRIVATE then
        local dstName = select(1, ...)
        if dstName == KPlayer.name then
            showNoticeByID("message.cannot_private_self")
            return
        end

        require("src/network/KC2SProtocolManager"):SendPrivateMessage(dstName, messageStr)
        KPlayer:RecordSendMessage(szChatType, messageStr, dstName)
        if self._isGlobalPanel then
            addGlobalScrollPageView(self)
        else 
            addPrivateScrollPageView(self)    
        end

    elseif szChatType == CHAT_TYPE.GLOBAL then
        if KPlayer.banChat and KPlayer.banChat ~= 0 then
            if KPlayer.banChat < 0 or KPlayer.banChat > KUtil.getCurrentServerTime() then
                showNoticeByID("message.banChat")
                return
            end
        end

        -- here add ban chat mode,now only a simple method
        if string.len(messageStr) > 8 then
            self._messagelist[messageStr] = (self._messagelist[messageStr] or 0) + 1
            local num = self._messagelist[messageStr]
            num = (num > 4 and num or nil)
        end

        require("src/network/KC2SProtocolManager"):SendGlobalMessage(messageStr, num)
        KPlayer:RecordSendMessage(szChatType, messageStr)
    else
        assert(false)
    end
end

function KUIOfficeMainLayer:tryOpenSPSignNode()
    if KUtil.isGuide() then return end
    if KUtil.getAnnounceTodayShowTimes() < 1 then return end
    if self._hasShowSPSign then return end

    self._hasShowSPSign = true
    KUtil.checkSPSign(self._parent)
end

function KUIOfficeMainLayer:registerAllTouchEvent()
    local mainNode              = self._mainLayout
    local panelMainbutton1      = self._panelMainBelow:getChildByName("Panel_main_button1")
    local panelMainbutton2      = self._panelMainBelow:getChildByName("Panel_main_button2")

    --Mission Button
    local buttonControl         = panelMainbutton1:getChildByName("Button_main_mission")
    local function onMissionClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMissionButton~")
            KSound.playEffect("click")
            self._parent:addNode("Mission")
        end
    end
    buttonControl:addTouchEventListener(onMissionClick)

    --Operation Button
    local projectMain           = mainNode:getChildByName("ProjectNode_main")
    local panelMain             = projectMain:getChildByName("Panel_1")
    local panelCommonAttack     = panelMain:getChildByName("Panel_button_attack")
    local buttonControl         = panelCommonAttack:getChildByName("Button_main_operation")
    local function onOperationClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onOperationButton~")
            KSound.playEffect("click")
            self._parent:addNode("Launch")
        end
    end
    buttonControl:addTouchEventListener(onOperationClick)

    --Record Button
    local buttonControl         = self._panelCommonUI:getChildByName("Panel_record")
    local function onRecordClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onRecordButton~")
            KSound.playEffect("click")
            self._parent:addNode("Medal")
        end        
    end
    buttonControl:addTouchEventListener(onRecordClick)

    --Factory Button
    local buttonControl = panelMainbutton1:getChildByName("Button_main_factory")
    local function onFactoryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onFactoryButton~")
            KSound.playEffect("click")      
            self._parent:addNode("Factory")      
        end
    end
    KUtil.addTouchEventWithSysOpen(buttonControl, onFactoryClick, "factory")

    --Supply Button
    local buttonControl = panelMainbutton1:getChildByName("Button_main_supply")
    local function onSupplyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSupplyButton~")
            KSound.playEffect("click")
            self._parent:addNode("Repair")
        end
    end
    KUtil.addTouchEventWithSysOpen(buttonControl, onSupplyClick, "supply")

    --Team Button
    local buttonControl = panelMainbutton1:getChildByName("Button_main_army")
    local function onArmyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onTeamButton~")
            KSound.playEffect("click")
            self._parent:addNode("Team")           
        end        
    end
    buttonControl:addTouchEventListener(onArmyClick)

    --Message Button
    local panelMessage  = mainNode:getChildByName("Panel_message")
    local projectNodeMessage = panelMessage:getChildByName("ProjectNode_main_message")
    local buttonControl      = projectNodeMessage:getChildByName("Button_main_message")
    local function onMessageClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMessageButton~")
            KSound.playEffect("click")
            self._openMessage = not self._openMessage
            showOpenMessagePanel(self, self._openMessage)
            addGlobalScrollPageView(self)
        end
    end
    buttonControl:addTouchEventListener(onMessageClick)

    -- 关闭聊天面板
    local projectMessage      = panelMessage:getChildByName("ProjectNode_message")
    local buttonControl       = projectMessage:getChildByName("Panel_message")
    local function onCloseMessageClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMessageButton~")
            KSound.playEffect("click")
            self._openMessage = false
            showOpenMessagePanel(self, self._openMessage)
            addGlobalScrollPageView(self)
        end
    end
    buttonControl:addTouchEventListener(onCloseMessageClick)

    local buttonControl         = self._panelChat:getChildByName("Button_chat")
    buttonControl:addTouchEventListener(onCloseMessageClick)
    
    --Send Message Button
    local imageInputBox = self._chatDialog:getChildByName("Image_input_box")
    local buttonSend    = self._chatDialog:getChildByName("Button_send")
    local textFieldMessageInput = imageInputBox:getChildByName("TextField_message_input")
    local function onSendMessageClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSeedMessageClick~")
            KSound.playEffect("click")
            local messageInput = textFieldMessageInput:getString()

            local _, _, dstName, messageStr = string.find(messageInput, "^@(%S+)(.*)")
            if dstName then
                local dstNameMaxLen = 30
                if #dstName > dstNameMaxLen then 
                    showNoticeByID("message.messageTargetNotExist", dstName)
                    return
                end
                self:trySendChatMessage(CHAT_TYPE.PRIVATE, messageStr, dstName)
                textFieldMessageInput:setString("")
                return
            end
            self:trySendChatMessage(CHAT_TYPE.GLOBAL, messageInput)
            textFieldMessageInput:setString("")
        end
    end
    buttonSend:addTouchEventListener(onSendMessageClick)

    --Global Button
    local imageClickBase        = self._chatDialog:getChildByName("Image_click_base")
    local buttonClickGlobalChat = imageClickBase:getChildByName("Button_public") 
    local function onGlobalChatClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            cclog("click onGlobalChatClick~")
            KSound.playEffect("click")

            if self._isGlobalPanel then
                return
            end

            self._isGlobalPanel = true
            addGlobalScrollPageView(self)
            refreshMessageButtonState(self)
        end
    end
    buttonClickGlobalChat:addTouchEventListener(onGlobalChatClick)
    
    --Private Chat Button
    local buttonClickPrivateChat = imageClickBase:getChildByName("Button_private")
    local function onPrivateChatClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPrivateChatClick~")
            KSound.playEffect("click")

            if not self._isGlobalPanel then
                return
            end

            self._isGlobalPanel = false
            addPrivateScrollPageView(self)
            refreshMessageButtonState(self)
        end
    end
    buttonClickPrivateChat:addTouchEventListener(onPrivateChatClick)

    local nodeBackGround = mainNode:getChildByName("Node_bg")

    --Decoration Button
    local buttonControl = panelMainbutton2:getChildByName("Button_main_decoration")
    local projectNode   = buttonControl:getChildByName("ProjectNode_notice_2")
    projectNode:setVisible(false)
    local function onDecorationClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onDecorationButton~") 
            KSound.playEffect("click")           
            self._parent:addNode("Furniture")
        end
    end
    buttonControl:addTouchEventListener(onDecorationClick)

    --[[Friend Button
    local buttonControl = self._panelMainBelow:getChildByName("Button_main_friend")
    local function onFriendClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onFriendButton~")
            KSound.playEffect("click")
        end        
    end
    buttonControl:addTouchEventListener(onFriendClick)]]

    --Item Button
    local buttonControl = panelMainbutton2:getChildByName("Button_main_item")
    local projectNode   = buttonControl:getChildByName("ProjectNode_notice_2")
    projectNode:setVisible(false)
    local function onItemClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onItemButton~")
            KSound.playEffect("click")
            self._parent:addNode("Item")
        end        
    end
    buttonControl:addTouchEventListener(onItemClick)

    --Collection Button
    local buttonControl = panelMainbutton2:getChildByName("Button_main_collection")
    local projectNode   = buttonControl:getChildByName("ProjectNode_notice_2")
    projectNode:setVisible(false)
    local function onCollectionClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCollectionButton~")
            self._isStoryRedPoint = false
            KSound.playEffect("click")
            self._parent:addNode("Collection")
            self:refreshAccessMissionaNotice()
        end        
    end
    buttonControl:addTouchEventListener(onCollectionClick)

    --Rank Button
    local buttonControl = panelMainbutton2:getChildByName("Button_main_rank")
    local function onRankClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onRankButton~")
            KSound.playEffect("click")
            self._parent:addNode("Rank")
        end        
    end
    buttonControl:addTouchEventListener(onRankClick)

    --Shop Button
    local buttonControl = self._panelFunctionButton:getChildByName("Button_main_shop")
    local function onShopClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShopButton~")
            KSound.playEffect("click")
            self._parent:addNode("Shop")
        end        
    end
    buttonControl:addTouchEventListener(onShopClick)
    local buttonControl         = self._panelCommonUI:getChildByName("Panel_shop")
    buttonControl:addTouchEventListener(onShopClick)

    --click character
    local imageBackground   = mainNode:getChildByName("Image_main_chara")
    imageBackground:setTouchEnabled(true)

    local charactorHeight = imageBackground:getContentSize().height * imageBackground:getScaleY()
    local pastPosY = nil
    local function characterReturn(sender)
        if not pastPosY then
            return
        end

        pastPosY = nil
        sender:stopAllActions()
        local needMoveY = sender:getPositionY() - self.baseCharactorPosY
        if needMoveY <= 0 then
            return
        end

        local returnTime = needMoveY / RETURN_SPEED
        local action = cc.Sequence:create(
            cc.MoveTo:create(returnTime, cc.p(sender:getPositionX(), self.baseCharactorPosY)),
            cc.CallFunc:create(function()
                setBreatheEffect(self, sender)
            end)
            )
        action:setTag(ACTION_TAG_MOVE_DOWN)
        sender:runAction(action)
    end

    local function onCharacterClick(sender, type)
        if type == ccui.TouchEventType.moved then
            cclog("click onCharacterClick~")
            sender:stopActionByTag(ACTION_TAG_MOVE_DOWN)
            sender:stopActionByTag(ACTION_TAG_REPEAT_BREATHE)
            local resultPosY = nil
            if pastPosY == nil then
                pastPosY = sender:getTouchMovePosition().y
            else
                local currentPosY = sender:getTouchMovePosition().y
                resultPosY = sender:getPositionY() + currentPosY - pastPosY
                pastPosY = currentPosY
            end
            if resultPosY and not (resultPosY < self.baseCharactorPosY) and not (resultPosY > charactorHeight / 2) then
                sender:setPositionY(resultPosY)
            end
        elseif type == ccui.TouchEventType.canceled then
            characterReturn(sender)
        elseif type == ccui.TouchEventType.ended then
            -- unknow why refreshCharacterImage is not call, before to call this.
            if not self._currentDisplayCardID then
                return
            end

            characterReturn(sender)
            local card = KUtil.getCardById(self._currentDisplayCardID)
            KSound.playTalk(KSound.TALK.COMMAND1, card.nTemplateID)
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_SETTING)
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_MESSAGE)
        end
    end
    imageBackground:addTouchEventListener(onCharacterClick)

    --[[Diamond Button
    local buttonControl = nodeBackGround:getChildByName("Button_main_add_diamond")
    local function onDiamondClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onDiamondButton~") 
            KSound.playEffect("click")           
            --SHOfficeScene:switchMenu(SHOW_LOGIN)
            --Send protocol to server
            showNoticeByID("common.rechargeNotOpen")
        end
    end
    buttonControl:addTouchEventListener(onDiamondClick)]]
    
    --[[GM Button
    local buttonGM = mainNode:getChildByName("Button_gm")
    local function onGMClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onGMClick~") 
            KSound.playEffect("click") 
            local imageGM  = buttonGM:getChildByName("Image_gm_base")
            if imageGM:isVisible() then
                imageGM:setVisible(false)   
                local textGM    = imageGM:getChildByName("TextField_gm")  
                local szCommand = textGM:getString()
                if string.len(szCommand) > 0 then
                    require("src/network/KC2SProtocolManager"):GMCommand(szCommand)
                else
                    showNoticeByID("gm.commandError")
                end
            else
                imageGM:setVisible(true)
            end
        end
    end
    --buttonGM:addTouchEventListener(onGMClick)]]

    -- main
    local buttonMain = self._panelFunctionButton:getChildByName("Button_main_command")
    local function onUnFoldClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onUnFoldClick~") 
            KSound.playEffect("click")
            self._mainExtend = not self._mainExtend
            if self._mainExtend then
                self:playAnimation("nodeFunction", "switch1")
            else
                self:playAnimation("nodeFunction", "switch2")
            end
        end
    end
    buttonMain:addTouchEventListener(onUnFoldClick)

    --Setting
    local panelSetting      = mainNode:getChildByName("Panel_set_up")
    local buttonSetting     = self._panelLeftButton:getChildByName("Button_main_setup")
    local projectNode       = panelSetting:getChildByName("ProjectNode_set_up")
    local projectNodeAni    = projectNode:getChildByName("ProjectNode_set_up")
    
    local function onSettingClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSettingClick~") 
            KSound.playEffect("click")
            self._openSetting = not self._openSetting
            showOpenSettingPanel(self, self._openSetting)
        end
    end
    buttonSetting:addTouchEventListener(onSettingClick)

    --sign
    local buttonSign = self._panelLeftButton:getChildByName("Button_sign")
    local function onSignClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSignClick~") 
            KSound.playEffect("click")
            self._parent:addNode("Sign")
        end
    end
    buttonSign:addTouchEventListener(onSignClick)

    --mail
    local buttonMail = self._panelLeftButton:getChildByName("Button_mail")
    local function onMailClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMailClick~") 
            KSound.playEffect("click")
            local parent = self._parent
            if parent:getNode("MailList") then
                self._parent:removeNode("Mail")
                self._parent:removeNode("MailList")
            else
                self._parent:addNode("MailList")
            end
        end
    end
    buttonMail:addTouchEventListener(onMailClick)

    --exchange
    local buttonExchange = self._panelLeftButton:getChildByName("Button_package")
    local function onExchangeClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onExchangeClick~") 
        KSound.playEffect("click")
        self._parent:addNode("Exchange")
    end
    buttonExchange:addTouchEventListener(onExchangeClick)

    --Raiders
    local buttonRaiders = self._panelLeftButton:getChildByName("Button_raiders")
    local function onRaidersClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onRaidersClick~") 
        KSound.playEffect("click")
        self._parent:addNode("Raiders")
    end
    buttonRaiders:addTouchEventListener(onRaidersClick)

    -- recharge
    local buttonFrist         = mainNode:getChildByName("ProjectNode_first")
    local buttonFristRecharge = buttonFrist:getChildByName("Button_main_first")
    local function onRechargeClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onRechargeClick~") 
        KSound.playEffect("click")
        self._parent:addNode("FirstRecharge")
    end
    buttonFristRecharge:addTouchEventListener(onRechargeClick)

    local panelSetUpBase        = projectNodeAni:getChildByName("Panel_set_up")
    local controlSettingBase    = panelSetUpBase:getChildByName("Image_set_up_base")
    local sliderMusic           = controlSettingBase:getChildByName("Slider_music")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            local percent = math.floor(sliderMusic:getPercent())
            KSound.setMusicVolume(percent)
        end
    end
    sliderMusic:addEventListener(onSlideChange)

    local closeButton = controlSettingBase:getChildByName("Button_close")
    local function onSetUpClick(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_SETTING)
        end
    end
    closeButton:addTouchEventListener(onSetUpClick)

    local sliderSound = controlSettingBase:getChildByName("Slider_sound")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            local percent = math.floor(sliderSound:getPercent())
            KSound.setEffectVolume(percent)
        end
    end
    sliderSound:addEventListener(onSlideChange)

    local buttonExit = controlSettingBase:getChildByName("Button_1")
    local function onExit(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            self:onExitClick()
        end
    end
    buttonExit:addTouchEventListener(onExit)

    --foodhouse
    local panelButtonFood        = self._panelFoodNode:getChildByName("Panel_button_food")
    local buttonFood             = panelButtonFood:getChildByName("Button_divination")
    local function onFoodHouseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onFoodHouseClick~") 
            KSound.playEffect("click")
            self._parent:addNode("Food")
        end
    end
    buttonFood:addTouchEventListener(onFoodHouseClick)

    local panelExpBuff  = self._expBuffNode:getChildByName("Panel_exp_buff")
    local buttonExpBuff = panelExpBuff:getChildByName("Button_exp")
    local function onExpBuffClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onExpBuffClick~")

            if self._refreshExpBuffTime then
                self._refreshExpBuffTime = false
                self:playAnimation("expBuffTime", "End")
            else
                self._refreshExpBuffTime = true
                refreshExpBuff(self)
                self:playAnimation("expBuffTime", "start")
            end
        end
    end
    buttonExpBuff:addTouchEventListener(onExpBuffClick)

    local buttonLoadTalk = controlSettingBase:getChildByName("Button_2")
    local function confirmFunction() 
        if not C_AsyncDownloadFile or not UPDATE_V2_ENABLE then return end
        if self._talkUpdate then return end
        local KSetting = require("src/logic/KSetting")
        KSetting.setBool(KSetting.Key.LOAD_TALK, true)
        require("src/ui/login/KUILoginUpdateNode")
        szNewstVersionUrl = GetUrlList("talk") -- "http://172.18.69.110:21000/xiaomi/test/talk/"
        self._talkUpdate  = CreateUpdateManager("talk", 2, szNewstVersionUrl, "", true, true)
        self._talkUpdate.run()
    end
    local function cancelFunction() 
        buttonLoadTalk:setTouchEnabled(false)
    end       
    
    local function onLoadTalk(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            buttonLoadTalk:setTouchEnabled(false)
            showConfirmation(KUtil.getStringByKey("exit.loadTip"), confirmFunction, cancelFunction)
        end
    end
    buttonLoadTalk:addTouchEventListener(onLoadTalk)

    local checkBoxHigh   = controlSettingBase:getChildByName("CheckBox_picture_1")
    local checkBoxMedian = controlSettingBase:getChildByName("CheckBox_picture_2")
    local checkBoxLow    = controlSettingBase:getChildByName("CheckBox_picture_3")

    local pixelQualitySelected = {
        { ["ui"] = checkBoxHigh,    ["quality"]  = KUtil.PIXEL_QUALITY.HIGH      },
        { ["ui"] = checkBoxMedian,  ["quality"]  = KUtil.PIXEL_QUALITY.MEDIAN    },
        { ["ui"] = checkBoxLow,     ["quality"]  = KUtil.PIXEL_QUALITY.LOW       },
    }

    local function onRadioButtonSelected(radioGroup, index)
        local selectedRadio = radioGroup[index]
        assert(selectedRadio ~= nil, "setected unexisted radio button")
        for _, v in pairs(pixelQualitySelected) do
            if v["ui"] == selectedRadio then
                local selectedQuality = v["quality"]
                switchPixelQuality(selectedQuality)
            end
        end
    end

    local checkBoxArray = {
        checkBoxHigh,
        checkBoxMedian,
        checkBoxLow,
    }
    
    KUtil.setRadioGroupEvent(checkBoxArray, onRadioButtonSelected)

    local imageCommonProject = mainNode:getChildByName("Project_furniture_base")
    local imageCommonBackground = imageCommonProject:getChildByName("Panel__furniture_background")
    imageCommonBackground:setTouchEnabled(true)
    local function onBackClick(sender, type)
        if type == ccui.TouchEventType.ended then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_SETTING)
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_MESSAGE)
        end
    end
    imageCommonBackground:addTouchEventListener(onBackClick)

    local hideButtonProject = mainNode:getChildByName("ProjectNode_hide_button")
    local hideButtonPanel   = hideButtonProject:getChildByName("Panel_office_hide_button")
    local hideButton        = hideButtonPanel:getChildByName("Button_shrink_button")
    local function onBackClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._hideAllUI = not self._hideAllUI
            local needRunAnimatiosList = {"Node_bg",
                                          "ProjectNode_left_button",
                                          "ProjectNode_main_message",
                                          "ProjectNode_dialog", 
                                          "ProjectNode_main",
                                          "first",
                                          "food",
                                          "serviceactivity",
										  "expBuff",
                                          "build",
                                         }
                                         
            if self._refreshExpBuffTime then
                table.insert(needRunAnimatiosList, "expBuffTime")
            end

            if self._hideAllUI then
                self:playAnimation("ProjectNode_hide_button", "hideAll")
                for i,v in ipairs(needRunAnimatiosList) do
                    self:playAnimation(v, "End")
                end
                playSecretaryAnimation(self, false)
            else
                self:playAnimation("ProjectNode_hide_button", "showAll")
                for i,v in ipairs(needRunAnimatiosList) do
                    self:playAnimation(v, "start")
                end
                playSecretaryAnimation(self, true)
            end

            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_SETTING)
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_CLOSE_MESSAGE)
        end
    end
    hideButton:addTouchEventListener(onBackClick)

    --service activity
    -- local panelButtonServiceActivity    = self._panelServiceActivity:getChildByName("Panel_button_service_activity")
    -- local buttonServiceActivity         = panelButtonServiceActivity:getChildByName("Button_service_activity")
    -- local function onServiceActivityClick(sender, type)
    --     if type == ccui.TouchEventType.ended then
    --         cclog("click onServiceActivityClick~") 
    --         KSound.playEffect("click")
    --         self._parent:addNode("ServiceActivity")
    --     end
    -- end
    -- buttonServiceActivity:addTouchEventListener(onServiceActivityClick)

    --secretary
    local panelSecretary                = self._panelSecretary:getChildByName("Panel_secretary")
    local buttonSecretary               = panelSecretary:getChildByName("Button_secretary")
    local function onSecretaryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSecretaryClick~") 
            KSound.playEffect("click")
            if self._openSecretary then
                self:playAnimation("secretary", "close")
            else
                self:playAnimation("secretary", "open")
            end
            self._openSecretary = not self._openSecretary
        end
    end
    buttonSecretary:addTouchEventListener(onSecretaryClick)
    
    local imageSecretaryBase        = panelSecretary:getChildByName("Image_secretary_base")
    local buttonShowCaptain         = imageSecretaryBase:getChildByName("Button_show_captain")
    local function onShowCaptainClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShowCaptainClick~") 
            KSound.playEffect("click")
            
            local secretaryData     = KPlayer.tSecretaryData
            if secretaryData.nType ~= SECRETARY_TYPE.TEAM_LEADER then
                local teamLeaderCard    = KUtil.getTeamLeaderCard()
                require("src/network/KC2SProtocolManager"):changeSecretary(0, SECRETARY_TYPE.TEAM_LEADER, secretaryData.nState)
            end
        end
    end
    buttonShowCaptain:addTouchEventListener(onShowCaptainClick)

    local buttonShowGiven           = imageSecretaryBase:getChildByName("Button_show_given")
    local function onShowGivenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShowGivenClick~") 
            KSound.playEffect("click")
            self._parent:addNode("SecretaryChoose")
        end
    end
    buttonShowGiven:addTouchEventListener(onShowGivenClick)

    local buttonShowRegular         = imageSecretaryBase:getChildByName("Button_show_regular")
    local function onShowRegularClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShowRegularClick~") 
            KSound.playEffect("click")
            if not isHaveSecretaryItem() then
                showSecretaryItemTip(self)
                return
            end
            
            local secretaryData = KPlayer.tSecretaryData
            if secretaryData.nState ~= SECRETARY_STATE.NORMAL then
                require("src/network/KC2SProtocolManager"):changeSecretary(secretaryData.nCardID, secretaryData.nType, SECRETARY_STATE.NORMAL)
            end
        end
    end
    buttonShowRegular:addTouchEventListener(onShowRegularClick)

    local buttonShowMiddle          = imageSecretaryBase:getChildByName("Button_show_middle")
    local function onShowMiddleClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShowMiddleClick~") 
            KSound.playEffect("click")
            if not isHaveSecretaryItem() then
                showSecretaryItemTip(self)
                return
            end

            local secretaryData = KPlayer.tSecretaryData
            if secretaryData.nState ~= SECRETARY_STATE.MID_BREAK then
                require("src/network/KC2SProtocolManager"):changeSecretary(secretaryData.nCardID, secretaryData.nType, SECRETARY_STATE.MID_BREAK)
            end
        end
    end
    buttonShowMiddle:addTouchEventListener(onShowMiddleClick)

    --build
    local buttonBuild    = self._build:getChildByName("Button_build")
    local function onBuildClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onBuildClick~") 
            KSound.playEffect("click")
            self._parent:addNode("BuildActivityPoster")
        end
    end
    buttonBuild:addTouchEventListener(onBuildClick)

    local projectNode = self._mainLayout:getChildByName("ProjectNode_studio_studio_theatre")
    local storyPanel  = projectNode:getChildByName("Panel_1")
    local function onStoryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onStoryClick~") 
            KSound.playEffect("click")
            self._parent:addNode("Story")
            m_bFirstClickStoryTip = false
        end
    end
    if KUtil.isSysOpened("story") then
        storyPanel:addTouchEventListener(onStoryClick)
    end
end

function KUIOfficeMainLayer:registerAllCustomEvent()
    local function onUpdataMission()
        cclog("KUIOfficeMainLayer onEvent ---------->onMissionFinish")
        refreshMissionRedPoint(self)
    end
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    self:addCustomEvent(eventDispatchCenter.EventType.NET_GET_MISSION_REWARD, onUpdataMission)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MISSION, onUpdataMission)
    
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    
    local function onResourceUpdate()
        cclog("----------> onEvent onResourceUpdate")
        refreshBaseInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
    self:addCustomEvent(eventDispatchCenter.EventType.RENAME_SUCCESS, onResourceUpdate)

    local function onCoinUpdate()
        cclog("----------> onEvent onCoinUpdate")
        refreshCoinCount(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_COIN, onCoinUpdate) 

    local function onRankUpdate()
        cclog("----------> onEvent onRankUpdate")
        refreshRankDetail(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_ROLE_RANK, onRankUpdate) 

    local function onOpenPanel()
        cclog("----------> onEvent onOpenPanel")
        if self._openSetting then
            self._openSetting = false
            showOpenSettingPanel(self, self._openSetting)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_OPEN_PANEL, onOpenPanel) 
    self:addCustomEvent(eventDispatchCenter.EventType.UI_CLOSE_SETTING, onOpenPanel) 
    
    local function onOpenMessagePanel()
        cclog("----------> onEvent onOpenMessagePanel")
        if self._openMessage then
            self._openMessage = false
            showOpenMessagePanel(self, self._openMessage)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_OPEN_PANEL, onOpenMessagePanel) 
    self:addCustomEvent(eventDispatchCenter.EventType.UI_CLOSE_MESSAGE, onOpenMessagePanel)
    
    local function onSign()
        refreshSignRedPoint(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SIGN, onSign) 

    local function onChangeFurniture(tOne)
        refreshFurnitures(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CHANGE_FURNITURE, onChangeFurniture) 

    local function onRefreshTeamRedPoint()
        refreshTeamRedPoint(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onRefreshTeamRedPoint) 
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ADD_CARD, onRefreshTeamRedPoint) 
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_DEL_CARD, onRefreshTeamRedPoint) 
    
    local function onSendGlobalMessage()
        if self._isGlobalPanel then
            addGlobalScrollPageView(self)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_RECEIVE_GLOBAL_MESSAGE, onSendGlobalMessage)

    local function onSendPrivateMessage()
        if not self._isGlobalPanel then
            addPrivateScrollPageView(self)
        else
            refreshMessageRedPoint(self)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_RECEIVE_PRIVATE_MESSAGE, onSendPrivateMessage)

    local function onMessageTargetOffLine(szDstRoleName)
        showNoticeByID("message.messageTargetOffLine", szDstRoleName)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_TARGET_OFF_LINE, onMessageTargetOffLine)

    local function onMessageTargetNotExist(szDstRoleName)
        showNoticeByID("message.messageTargetNotExist", szDstRoleName)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_TARGET_NOT_EXIST, onMessageTargetNotExist)

    local function onUpdateExpBuff()
        refreshExpBuff(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_EXP_BUFF, onUpdateExpBuff) 

    local function onUpdateSecretary()
        refreshCharacterImage(self)
        refreshSecretaryPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_SECRETARY_DATA, onUpdateSecretary)
    
    local function onUpdeteItem()
        refreshSecretaryPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_ADD, onUpdeteItem)

    local function onAccessMission()
        self:refreshAccessMissionaNotice()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ACCESS_MISSION, onAccessMission)
end

function KUIOfficeMainLayer:unregisterAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    for _, v in pairs(self._eventList) do
        eventDispatchCenter:unregisterEvent(v["eventType"], v["callbackFunc"])
    end
    self._eventList = {}
end

function KUIOfficeMainLayer:init()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office layer init begin")
    local mainNode = cc.CSLoader:createNode("res/ui/layout_office.csb")
    self._mainLayout = mainNode

    local function onNodeEvent(event)
        
        if "enter" == event then
            KLogGather.addLog("EventBug", "office layer enter")
            self:onEnter()
        elseif "exit" == event then
            KLogGather.addLog("EventBug", "office layer exit")
            self:onExit()
        elseif "cleanup" == event then
            self:unregisterScriptHandler()
            KLogGather.addLog("EventBug", "office layer cleanup")
            self:onCleanup()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    KLogGather.addLog("EventBug", "office layer init end")
    
    self:addChild(mainNode)

    local imageBackground = mainNode:getChildByName("Image_main_chara")
    self.baseCharactorPosY = imageBackground:getPositionY()
end

function KUIOfficeMainLayer:onEnter()
    cclog("KUIOfficeMainLayer:onEnter")
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office layer onEnter begin")
    self:onInitUI()
    self:refreshUI()

    self:registerAllTouchEvent()
    self:registerAllCustomEvent()

    require("src/logic/KMainLoop"):addActivateObject(self)
    KLogGather.addLog("EventBug", "office layer onEnter end")

    self:playStartAnimation()
end

function KUIOfficeMainLayer:onExit()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office layer onExit begin")
    self:unregisterAllCustomEvent()
    require("src/logic/KMainLoop"):removeActivateObject(self)
    cclog("KUIOfficeMainLayer:onExit")
    KLogGather.addLog("EventBug", "office layer onExit end")
end

function KUIOfficeMainLayer:onCleanup()
    if #self._eventList ~= 0 then
        local KLogGather = require("src/logic/KLogGather")
        KLogGather.addLog("EventBug", "office layer event count error", #self._eventList)
        KLogGather.sendLog("EventBug")
        self:unregisterAllCustomEvent()
    end
end

function KUIOfficeMainLayer:onNodeExit()
    if self._chatPanelMessageUI then
        self._chatPanelMessageUI:release() 
        self._chatPanelMessageUI = nil
    end
end

return KUIOfficeMainLayer