--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIAnnounceNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/11/03   13:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIAnnounceNode = class(
    "KUIAnnounceNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIAnnounceNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._baseControl    = nil
end

function KUIAnnounceNode.create(owner)
    local currentNode = KUIAnnounceNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_notice.csb"
    currentNode:init()

    return currentNode
end

local function checkRequestData()
    local setting = require("src/logic/KSetting")
    local nVersionIndex = setting.getInt(setting.Key.ANNOUNCE_VERSION, 0)
    require("src/network/KC2SProtocolManager"):getAnnounceInfo(nVersionIndex)
end

local function refreshScrollView(self, isCutIn)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_notice")
    local scrollControl = imageCommon:getChildByName("ScrollView_information")
    scrollControl:removeAllChildren()

    local listData = {}
    local announceList = KUtil.getShowAnnounceList()
    for k, v in pairs(announceList) do
        if v.nID ~= 0 then
            table.insert(listData, v)
        end
    end
    local function sortFunc(v1, v2)
        return v1.nID < v2.nID
    end
    table.sort(listData, sortFunc)

    local showListUI = {}
    for index, item in ipairs(listData) do
        local newControl = self._baseControl:clone()
        newControl:setString(item.szName)
        table.insert(showListUI, newControl)
        local tColor = item.tColor
        if tColor and tColor[1] then
            tColor[1] = tColor[1] or 0
            tColor[2] = tColor[2] or 0
            tColor[3] = tColor[3] or 0
            newControl:setColor(cc.c3b(tColor[1], tColor[2], tColor[3]))
        end
    end
    KUtil.addScrollView(scrollControl, showListUI, isCutIn)
end

function KUIAnnounceNode:getExitAction()
    return nil, 0
end

function KUIAnnounceNode:onInitUI()
    local mainNode      = self._mainLayout
    local baseControl   = mainNode:getChildByName("Image_notice")
    local scrollControl = baseControl:getChildByName("ScrollView_information")
    self._baseControl   = scrollControl:getChildByName("Text_information")
    self._baseControl:retain()

    scrollControl:removeAllChildren()
end

function KUIAnnounceNode:refreshUI()
    checkRequestData()
end

function KUIAnnounceNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Home Button
    local baseControl = mainNode:getChildByName("Image_notice")
    local buttonControl = baseControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")         
            self._parent:removeNode("Announce")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUIAnnounceNode:registerAllCustomEvent()
    local function onRefreshAnnounce(isChange)
        cclog("onEvent ------------> onRefreshAnnounce")
        refreshScrollView(self, false)
    end
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ANNOUNCE, onRefreshAnnounce)
end

function KUIAnnounceNode:onCleanup()
    self._baseControl:release() 
end

return KUIAnnounceNode
