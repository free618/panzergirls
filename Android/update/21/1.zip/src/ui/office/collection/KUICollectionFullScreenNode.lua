--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUICollectionFullScreenNode.lua
--  Creator     : HuangYiXin
--  Date        : 2015/12/11   14:40
--  Contact     : huangyixin@kingsoft.com
--  *********************************************************************


local DRAG_RESPOND_MIN_LIMIT     = 8
local STRETCH_SHIFT_MIN_LIMIT    = 1
local STRETCH_RESPOND_MIN_LIMIT  = 30
local DOUBLE_CLICK_INTERVAL      = 0.6

local IMAGE_CARD_MIN_SCALE       = 0.8
local IMAGE_CARD_MAX_SCALE       = 1.5

local m_tCardStateName = {
    ["bigBreak"] = "大破",
    ["normal"]   = "正常"
}

local m_tEnumEventType = {
    ["BEGAN"]          = "BEGAN",
    ["MOVED"]          = "MOVED",
    ["ENDED"]          = "ENDED",
}

local m_tEnumTouchType = {
    ["NONE"]           = "NONE",
    ["CLICK"]          = "CLICK",
    ["DOUBLE_CLICK"]   = "DOUBLE_CLICK",
    ["DRAG"]           = "DRAG",
    ["STRETCH"]        = "STRETCH",
}

local KUICollectionFullScreenNode = class(
    "KUICollectionFullScreenNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUICollectionFullScreenNode:ctor()
    self._mainLayout      = nil
    self._parent          = nil
    self._uiPath          = nil

    self._cardID          = nil
    self._isMarried       = nil
    self._isBreak         = false
    self._initPosition    = false
end

function KUICollectionFullScreenNode.create(owner, userData)
    local currentNode      = KUICollectionFullScreenNode.new()

    currentNode._cardID    = userData.cardID
    currentNode._isMarried = userData.isMarried

    currentNode._parent    = owner
    currentNode._uiPath    = "res/ui/animation_node/ani_vertical_drawing.csb"
    currentNode:init()

    return currentNode
end

local function playCardPanelAnimation(self, isOpen)
    local projectNode        = self._mainLayout

    local openEndFrame    = 45
    local closeStartFrame = 55
    local animationName   = "ani_vertical_drawing"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function resetMoveNodePosition(self)
    local mainNode      = self._mainLayout
    local movePanel     = mainNode:getChildByName("Panel_card_base")
    local imageCard     = movePanel:getChildByName("Image_chara")

    local off  = movePanel:getAnchorPointInPoints()
    local posX = movePanel:getPositionX()
    local posY = movePanel:getPositionY()
    local x    = posX - off.x
    local y    = posY - off.y
    movePanel:setAnchorPoint(cc.p(0,0))
    movePanel:setPosition(cc.p(x, y))

    self._initPosition = cc.p(posX, posY)
end

local function resetUIAnchorPoint(self, ui, anchorX, anchorY)
    local oldPosX = ui:getPositionX()
    local oldPosY = ui:getPositionY()
    local oldOff  = ui:getAnchorPointInPoints()

    ui:setAnchorPoint(cc.p(anchorX, anchorY))

    local newOff  = ui:getAnchorPointInPoints()
    local newPosX = oldPosX + oldOff.x - newOff.x
    local newPosY = oldPosY + oldOff.y - newOff.y

    ui:setPosition(cc.p(newPosX, newPosY))
end

local function recordUIState(self, ui, key, value)
    ui[key] = value
end

local function getUIState(self, ui, key, default)
    return ui[key] or default
end

local function registerMutiTouchesEvent(self)
    local mainNode      = self._mainLayout
    local movePanel     = mainNode:getChildByName("Panel_card_base")
    local imageCard     = movePanel:getChildByName("Image_chara")

    local imageWidth    = self._imageWidth
    local imageHeight   = self._imageHeight 

    local curTouchType  = m_tEnumTouchType.NONE
    local curTouchCount = 0
    local touchIDList   = {}
    local touchIDMap    = {}

    local visibleSize    = cc.Director:getInstance():getVisibleSize()
    local screenBound = {
        x = 0,
        y = 0,
        w = visibleSize.width,
        h = visibleSize.height,
    }

    local minScaleF, maxScaleF = IMAGE_CARD_MIN_SCALE, IMAGE_CARD_MAX_SCALE
    local curScaleF = 1.0

    movePanel:setTouchEnabled(false)
    movePanel:setSwallowTouches(false)

    self:saveViewState()

    local function checkMoveImage(deltaX, deltaY)
        local oldPosX     = movePanel:getPositionX()
        local oldPosY     = movePanel:getPositionY()
        local width       = imageWidth * movePanel:getScaleY()
        local height      = imageHeight * movePanel:getScaleX()
        local imageBoundx = oldPosX + deltaX
        local imageBoundy = oldPosY + deltaY
        local imageBoundw = height
        local imageBoundh = width

        local fitDeltaX, fitDeltaY = deltaX, deltaY
        if imageBoundx > screenBound.x then
            fitDeltaX = screenBound.x - oldPosX
        elseif imageBoundx + imageBoundw < screenBound.w then
            fitDeltaX = screenBound.w - oldPosX - imageBoundw
        end

        if imageBoundy > screenBound.y then
            fitDeltaY = screenBound.y - oldPosY
        elseif imageBoundy + imageBoundh < screenBound.h then
            fitDeltaY = screenBound.h - oldPosY - imageBoundh
        end

        if fitDeltaX + oldPosX + imageBoundw < screenBound.w then
            --fix the image in center
            fitDeltaX = (screenBound.w - imageBoundw) / 2 - oldPosX
        end

        if fitDeltaY + oldPosY + imageBoundh < screenBound.h then
            --fix the image in center
            fitDeltaY = (screenBound.h - imageBoundh) / 2 - oldPosY
        end

        return fitDeltaX, fitDeltaY
    end

    local function checkScaleFactor(scaleFactor)
        if scaleFactor < minScaleF then
            return minScaleF
        elseif scaleFactor > maxScaleF then
            return maxScaleF
        else
            return scaleFactor
        end
    end

    local function moveImage(deltaX, deltaY)
        deltaX, deltaY = checkMoveImage(deltaX, deltaY)
        if deltaX == 0 and deltaY == 0 then return end

        local oldPosX = movePanel:getPositionX()
        local oldPosY = movePanel:getPositionY()
        movePanel:setPosition(cc.p(oldPosX + deltaX, oldPosY + deltaY))
    end

    local function scaleImage(anchorX, anchorY, scaleByF)
        local scaleFactor = curScaleF * scaleByF
        scaleFactor = checkScaleFactor(scaleFactor)
        if scaleFactor == curScaleF then return end

        movePanel:setScaleX(scaleFactor)
        movePanel:setScaleY(scaleFactor)

        local posX = movePanel:getPositionX()
        local posY = movePanel:getPositionY()
        anchorX = - posX + anchorX
        anchorY = - posY + anchorY

        local rax = anchorX * (scaleFactor / curScaleF)
        local ray = anchorY * (scaleFactor / curScaleF)
        local dax = anchorX - rax
        local day = anchorY - ray
        moveImage(dax, day)

        curScaleF = scaleFactor
    end

    local function touchEnded()
        if curTouchType == m_tEnumTouchType.CLICK then
            self:exitFullScreen()
        elseif curTouchType == m_tEnumTouchType.DOUBLE_CLICK then
            self:resetViewState()
        end
        curTouchType = m_tEnumTouchType.NONE
    end

    local function isDragEvent(touch)
        local start = touch:getStartLocation()
        local point = touch:getLocation()
        local dx    = point.x - start.x
        local dy    = point.y - start.y
        local limit = DRAG_RESPOND_MIN_LIMIT
        if dx * dx + dy * dy >= limit * limit then
            return true
        end
        return false
    end

    local function drag(touch)
        local delta = touch:getDelta()
        moveImage(delta.x, delta.y)
    end

    local function stretch(touch1, touch2)
        local pointA = touch1:getLocation()
        local pointB = touch2:getLocation()

        local preA = touch1:getPreviousLocation()
        local preB = touch2:getPreviousLocation()

        local ax = pointA.x - preA.x
        local ay = pointA.y - preA.y
        local bx = pointB.x - preB.x
        local by = pointB.y - preB.y

        local sx = preB.x - preA.x
        local sy = preB.y - preA.y
        local px = pointB.x - pointA.x
        local py = pointB.y - pointA.y

        local ls = math.sqrt(sx * sx + sy * sy)
        local lp = math.sqrt(px * px + py * py)
        local scale = (lp / ls)

        local la = math.sqrt(ax * ax + ay * ay)
        local lb = math.sqrt(bx * bx + by * by)

        if la + lb < STRETCH_SHIFT_MIN_LIMIT then
            return
        end

        local x  = (pointA.x * la + pointB.x * lb) / (la + lb)
        local y  = (pointA.y * la + pointB.y * lb) / (la + lb)

        scaleImage(x, y, scale)
    end

    local function dispatchTouchEvent(touchA, touchB, touchCount, eventType)
        if eventType == m_tEnumEventType.BEGAN then

        elseif eventType == m_tEnumEventType.MOVED then
            if touchCount == 1 and isDragEvent(touchA) then
                curTouchType = m_tEnumTouchType.DRAG
                drag(touchA)
            elseif touchCount >= 2 then
                curTouchType = m_tEnumTouchType.STRETCH
                stretch(touchA, touchB)
            end
        elseif eventType == m_tEnumEventType.ENDED then
            if touchCount == 0 and curTouchType == m_tEnumTouchType.NONE then
                curTouchType = m_tEnumTouchType.CLICK
                delayExecute(movePanel, touchEnded, DOUBLE_CLICK_INTERVAL)
            elseif touchCount == 0 and curTouchType == m_tEnumTouchType.CLICK then
                curTouchType = m_tEnumTouchType.DOUBLE_CLICK
            elseif touchCount == 0 and curTouchType == m_tEnumTouchType.DRAG then
                curTouchType = m_tEnumTouchType.NONE
            elseif touchCount == 1 then
                curTouchType = m_tEnumTouchType.DRAG
            end
        end
    end

    local function getTouches(touches)
        local touchIDs = touchIDList
        local touchMap = touchIDMap
        local touchA, touchB = nil, nil
        local touchIDA, touchIDB = touchIDs[1], touchIDs[2]
        for _, touch in pairs(touches) do
            touchMap[touch:getId()] = touch
        end

        if touchIDA then touchA = touchMap[touchIDA] end
        if touchIDB then touchB = touchMap[touchIDB] end
        return touchA, touchB
    end

    local function onTouchesBegan(touches, event)
        local touchIDs = touchIDList
        curTouchCount = curTouchCount + 1
        touchIDs[curTouchCount] = touches[1]:getId()

        local touchA, touchB = getTouches(touches)
        dispatchTouchEvent(touchA, touchB, curTouchCount, m_tEnumEventType.BEGAN)
    end

    local function onTouchesMoved(touches, event)
        local touchA, touchB = getTouches(touches)
        dispatchTouchEvent(touchA, touchB, curTouchCount, m_tEnumEventType.MOVED)
    end

    local function onTouchesEnded(touches, event)
        if curTouchCount == 0 then return end
        local touchIDs = touchIDList
        local touchId  = touches[1]:getId()
        local i = #touchIDs + 1
        while i > 0 do
            i = i - 1
            if touchIDs[i] == touchId then
                table.remove(touchIDs, i)
                break
            end
        end
        curTouchCount = curTouchCount - 1

        local touchA, touchB = getTouches(touches)
        dispatchTouchEvent(touchA, touchB, curTouchCount, m_tEnumEventType.ENDED)
    end

    local listener = cc.EventListenerTouchAllAtOnce:create()
    listener:registerScriptHandler(onTouchesEnded, cc.Handler.EVENT_TOUCHES_ENDED )
    listener:registerScriptHandler(onTouchesMoved, cc.Handler.EVENT_TOUCHES_MOVED )
    listener:registerScriptHandler(onTouchesBegan, cc.Handler.EVENT_TOUCHES_BEGAN )
    local eventDispatcher = movePanel:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, movePanel)
end

local function hideUnTouchUI(self)
    local officeScene  = self._parent
    local collectionUI = officeScene:getNode("Collection")
    if collectionUI then
        collectionUI:setVisible(false)
    end
    officeScene._mainLayer:setVisible(false)
end

local function playCardEnterAnimation(self)
    local delayFrame      = playCardPanelAnimation(self, true)
    local framesPerSecond = 60
    local duration        = delayFrame / framesPerSecond
    return duration
end

local function getCardImagePath(cardID, isBreak)
    return KUtil.getCardImagePathByConfigID(cardID, isBreak)
end

local function refreshCardStateButton(self)
    local mainNode     = self._mainLayout
    local buttonReload = mainNode:getChildByName("Button_reloading")
    local textReload   = buttonReload:getChildByName("Text_reloading")
    local stateName    = m_tCardStateName["normal"]
    if self._isBreak then
       stateName = m_tCardStateName["bigBreak"]
    end
    textReload:setString(stateName)
end

local function refreshCardUI(self)
    local mainNode  = self._mainLayout
    local cardID    = self._cardID
    local isMarried = self._isMarried
    local isBreak   = self._isBreak

    local cardPath  = getCardImagePath(cardID, isBreak)
    local backPath  = KUtil.getCollectionCardBackImagePath(cardID, isMarried)

    local imageBack = mainNode:getChildByName("Image_base")
    imageBack:loadTexture(backPath)
    imageBack:setTouchEnabled(false)

    local panelCard = mainNode:getChildByName("Panel_card_base")
    local imageCard = panelCard:getChildByName("Image_chara")
    imageCard:loadTexture(cardPath)
    imageCard:setTouchEnabled(false)

    panelCard:setTouchEnabled(true)
    panelCard:setSwallowTouches(true)
    panelCard:setClippingEnabled(true)

    local size = panelCard:getContentSize()
    self._imageWidth  = size.height
    self._imageHeight = size.width

    refreshCardStateButton(self)
end

function KUICollectionFullScreenNode:saveViewState()
    local mainNode  = self._mainLayout
    local movePanel = mainNode:getChildByName("Panel_card_base")
    local imageCard = movePanel:getChildByName("Image_Chara")

    local posX = movePanel:getPositionX()
    local posY = movePanel:getPositionY()
    recordUIState(self, movePanel, "posx", posX)
    recordUIState(self, movePanel, "posy", posY)

    local scaleX = movePanel:getScaleX()
    local scaleY = movePanel:getScaleY()
    recordUIState(self, movePanel, "scalex", scaleX)
    recordUIState(self, movePanel, "scaley", scaleY)
end

function KUICollectionFullScreenNode:resetViewState()
    local mainNode  = self._mainLayout
    local movePanel = mainNode:getChildByName("Panel_card_base")
    local imageCard = movePanel:getChildByName("Image_Chara")

    local posX = getUIState(self, movePanel, "posx", nil)
    local posY = getUIState(self, movePanel, "posy", nil)
    movePanel:setPositionX(posX)
    movePanel:setPositionY(posY)

    local scaleX = getUIState(self, movePanel, "scalex", nil)
    local scaleY = getUIState(self, movePanel, "scaley", nil)
    movePanel:setScaleX(scaleX)
    movePanel:setScaleY(scaleY)
end

function KUICollectionFullScreenNode:exitFullScreen()
    local officeScene = self._parent
    officeScene:removeNode("CollectionFullScreen")

    local collectionUI = officeScene:getNode("Collection")
    if collectionUI then
        collectionUI:setVisible(true)
    end
    officeScene._mainLayer:setVisible(true)
end

function KUICollectionFullScreenNode:switchCardState()
    local mainNode     = self._mainLayout
    local buttonReload = mainNode:getChildByName("Button_reloading")
    local panelCard    = mainNode:getChildByName("Panel_card_base")
    local imageCard    = panelCard:getChildByName("Image_chara")

    local cardID    = self._cardID
    local bNewState = not self._isBreak

    local imagePath = getCardImagePath(cardID, bNewState)
    imageCard:loadTexture(imagePath)
    self._isBreak = bNewState

    refreshCardStateButton(self)
end

function KUICollectionFullScreenNode:setDisplayCardID(userData)
    if self._cardID == userData.cardID then return end

    self._cardID    = userData.cardID
    self._isMarried = userData.isMarried

    self._isBreak = false
    self:refreshUI()
end

function KUICollectionFullScreenNode:onEnterActionFinished()
    hideUnTouchUI(self)
    resetMoveNodePosition(self)
    registerMutiTouchesEvent(self)
end

function KUICollectionFullScreenNode:onExitActionStart()
    local mainNode      = self._mainLayout
    local buttonReload  = mainNode:getChildByName("Button_reloading")
    local panelCard     = mainNode:getChildByName("Panel_card_base")
    local buttonReload  = mainNode:getChildByName("Button_reloading") 
    if self._initPosition then
        panelCard:setPosition(self._initPosition)
        panelCard:setAnchorPoint(cc.p(0, 0.5))
    end
    buttonReload:setVisible(false)
end

function KUICollectionFullScreenNode:refreshUI()
    refreshCardUI(self)
end

function KUICollectionFullScreenNode:registerAllTouchEvent()
    local mainNode     = self._mainLayout
    local buttonReload = mainNode:getChildByName("Button_reloading")
    local function onReloadClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onReload~")
            self:switchCardState()
        end
    end
    buttonReload:addTouchEventListener(onReloadClick)

    local buttonClose = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            self:exitFullScreen()
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

return KUICollectionFullScreenNode
