--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUICollectionNode.lua
--  Creator     : LiuZhen and HuangYiXin
--  Date        : 2015/08/11   11:30
--  Contact     : liuzhen4@kingsoft.com
--                huangyixin@kingsoft.com
--  Comment     : 1 sperate csb to layout_collection_card.csb and 
--                  layout_collection.gear.csb
--                2 use cardsbase_thumbnail
--  *********************************************************************


local SCROLL_THRESHOLD    = 200
local TANK_PANEL_CAPACITY = 10
local GEAR_PANEL_CAPACITY = 10
local MAX_TANK_TYPE_COUNT = 6
local MAX_TANK_STAR_LEVEL = 6
local MAX_GEAR_STAR_LEVEL = 6

local TANK_GRAPH_ATTRIBUTE_COUNT = 6
local MAX_TANK_GRAPH_RADIUS      = 80
local TANK_GRAPH_FILL_COLOR      = cc.c4f(0.9765, 0.9765, 0.7031, 0.8)
local DRAWNODE_TANK_GRAPH_POS_X  = 1052
local DRAWNODE_TANK_GRAPH_POS_Y  = 182

local MAX_PAGEVIEW_PAGE_COUNT    = 3
local MAX_CARD_TEXTURE_CAPACITY   = 80 
local MAX_GEAR_TEXTURE_CAPACITY   = 80

local REFRESH_PAGE_UNIT_DELAY    = 0.01
local OPEN_PAGEVIEW_DELAY        = 0.8
local PRELOAD_PAGE_DELAY         = 0.2
local FIRST_OPEN_PRELOAD_DELAY   = 0.1

local m_tTankAttributeTextName = {
    "Text_naijiu_value",
    "Text_huoli_value",
    "Text_chuantou_value",
    "Text_sudu_value",
    "Text_huibi_value",
    "Text_qianjia_value",
}

local m_tTankAttributeInfoName = {
    "nBaseHP",
    "nBaseAttack",
    "nBasePenetrate",
    "nBaseSpeed",
    "nBaseDodge",
    "nBaseFrontArmour",
}

local m_tTankGraphAttributeEnum = {
    ["nBaseHP"]          = 1,
    ["nBaseAttack"]      = 2,
    ["nBasePenetrate"]   = 3,
    ["nBaseSpeed"]       = 4,
    ["nBaseDodge"]       = 5,
    ["nBaseFrontArmour"] = 6,
}

local m_tTankAttributeMaxLimit = {
    100,
    150,
    150,
    100,
    100,
    100,
}

local m_szEquipSpecsName = {
    [ATTRIBUTE.HP]          = "耐久",
    [ATTRIBUTE.ATTACK]      = "火力",
    [ATTRIBUTE.PENETRATE]   = "穿透",
    [ATTRIBUTE.SPEED]       = "速度",
    [ATTRIBUTE.FRONTARMOUR] = "前装甲",
    [ATTRIBUTE.REARARMOUR]  = "后装甲",
    [ATTRIBUTE.SCOUT]       = "侦查",
    [ATTRIBUTE.DODGE]       = "回避",
    [ATTRIBUTE.HIDE]        = "隐藏",
    [ATTRIBUTE.NIGHTBATTLE] = "夜战",
    [ATTRIBUTE.RANGE]       = "射程",
    [ATTRIBUTE.ACCURACY]    = "命中率",
    [ATTRIBUTE.CRIT]        = "暴击",
}

local KUICollectionNode = class(
    "KUICollectionNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUICollectionNode:ctor()
    self._parent            = nil
    self._mainLayout        = nil
    self._uiPath            = nil 

    self.uiState = {
        ["UI_TANK_LIST"] = "UI_TANK_LIST",
        ["UI_GEAR_LIST"] = "UI_GEAR_LIST",
    }

    self._curUIState = nil

    self._pageViewTank = nil
    self._pageViewGear = nil

    self._preLoadPageDelay = FIRST_OPEN_PRELOAD_DELAY
end

function KUICollectionNode.create(owner)
    local currentNode = KUICollectionNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_collection_card.csb"
    currentNode:init()
    
    return currentNode
end

local function getCardTypeName(cardID)
    local tCardTypeName = {
        [1] = "轻型坦克",
        [2] = "中型坦克",
        [3] = "重型坦克",
        [4] = "坦克歼击车",
        [5] = "自行火炮",
    }
    return tCardTypeName[KUtil.getCardConfigValue(cardID, "nTankType")]
end

local function getGearTypeName(gearID)
    local tGearTypeName = {
        "武器类型：主武器",
        "武器类型：副武器",
    }
    return tGearTypeName[KUtil.getEquipTypeByID(gearID)]
end

local function getCardImagePath(cardID, thumb, showBroken)
    if thumb then
        return "res/images/cards_thumbnail/"..KUtil.getCardConfigValue(cardID,"szResPath").."_NormalImage.png"
    end
    return KUtil.getCardImagePathByConfigID(cardID, showBroken)
end

local function getGearImagePath(gearID)
    return KUtil.getEquipImagePathByID(gearID)
end
 
local function getHistoricalCardList()
    return KPlayer.tCardData.tHistoricalCardID
end

local function getHistoricalGearList()
    return KPlayer.tItemData.tHistoricalEquipID
end

local function getMaxTankCount()
    return #KConfig.cardInfo
end

local function getMaxGearCount()
    return #KConfig.equipInfo
end

local function getTankInfoByID(id)
    return KConfig:getLine("cardInfo", id)
end

local function getGearInfoByID(id)
    return KConfig:getLine("equipInfo", id)
end

local function hasTank(self, tankNumber)
    return self._tankInfo[tankNumber] ~= nil
end

local function hasGear(self, gearNumber)
    return self._gearInfo[gearNumber] ~= nil
end

local function getTankCollectedCount()
    return #KPlayer.tCardData.tHistoricalCardID
end

local function getTankCollectedCount()
    return #KPlayer.tCardData.tHistoricalGearID
end

local function initTankInfo(self)
    if self._tankInfo ~= nil then return end

    local historicalCardList = getHistoricalCardList()
    local tankInfo           = {}
    for _, cardID in ipairs(historicalCardList) do
        tankInfo[cardID] = { id = cardID, info = nil,}
    end
    self._tankInfo = tankInfo
end

local function initGearInfo(self)
    if self.gearInfo ~= nil then return end

    local historicalGearList = getHistoricalGearList()
    local gearInfo           = {}
    for _, equipID in ipairs(historicalGearList) do
        gearInfo[equipID] = { id = equipID, info = nil,}
    end
    self._gearInfo = gearInfo
end

local function hideUI(self)
    local mainNode            = self._mainLayout
    local imageTankDetail     = mainNode:getChildByName("Image_detail_base") 
    imageTankDetail:setVisible(false)
end

local function generateTankNodeBase(self)
    if self._tankNodeBase ~= nil then return end

    local mainNode            = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local pageViewTank        = imageCollectionBase:getChildByName("PageView_tank_list")
    local panelTankList       = pageViewTank:getChildByName("Panel_1")
    local imageCardUnit       = panelTankList:getChildByName("Image_card_unit_1")
    local projectNode         = imageCardUnit:getChildByName("ProjectNode_tank")
    
    local scaleX = projectNode :getScaleX()
    local scaleY = projectNode :getScaleY()

    local panelCardBase      = projectNode :getChildByName("Panel_card_base")
    panelCardBase:setScaleX(scaleX)
    panelCardBase:setScaleY(scaleY)
    panelCardBase:setSwallowTouches(false)

    panelCardBase:retain()
    self._tankNodeBase = panelCardBase
    
    projectNode :removeChild(panelCardBase)
    imageCardUnit:removeChild(projectNode)
end

local function getUIGearWidget(self, projectNodeGear)
    local imageNode      = projectNodeGear
    local newImageLayout = ccui.Layout:create()

    for _, subNode in pairs(imageNode:getChildren()) do
        imageNode:removeChild(subNode)
        newImageLayout:addChild(subNode)
    end

    newImageLayout:setSwallowTouches(false)
    return newImageLayout
end

local function generateGearNodeBase(self)
    if self._gearNodeBase ~= nil then return end

    local mainNode            = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local pageViewGear        = imageCollectionBase:getChildByName("PageView_gear_list")
    local panelGearList       = pageViewGear:getChildByName("Panel_1")
    local imageCardUnit       = panelGearList:getChildByName("Image_card_unit_1")
    local nodeGear            = imageCardUnit:getChildByName("ProjectNode_gear")

    local gearNodePosX   = nodeGear:getPositionX()
    local gearNodePosY   = nodeGear:getPositionY()
    local gearNodeScaleX = nodeGear:getScaleX()
    local gearNodeScaleY = nodeGear:getScaleY()
    local gearNodeTag    = nodeGear:getTag()
    local gearNodeZOrder = nodeGear:getLocalZOrder()

    local gearWidget = getUIGearWidget(self, nodeGear)
    gearWidget:setPosition(gearNodePosX, gearNodePosY)
    gearWidget:setScaleX(gearNodeScaleX)
    gearWidget:setScaleY(gearNodeScaleY)
    gearWidget:setName("Panel_card_base")
    gearWidget:setTag(gearNodeTag)
    gearWidget:setLocalZOrder(gearNodeZOrder)

    local panelGearBase  = gearWidget:getChildByName("Panel_gear_base")
    local panelGearMeda  = gearWidget:getChildByName("Panel_card_meda")
    local panelGearStars = gearWidget:getChildByName("Panel_stars")
    panelGearBase:setTouchEnabled(false)
    panelGearMeda:setTouchEnabled(false)
    panelGearStars:setTouchEnabled(false)

    self._gearNodeBase = gearWidget
    gearWidget:retain()
    imageCardUnit:removeChild(nodeGear)
end

local function getPanelCardBaseClone(self)
    return self._tankNodeBase:clone()
end

local function getGearNodeClone(self)
    return self._gearNodeBase:clone()
end

local function getTankInfoByTankIndex(self, index)
    if not hasTank(self, index) then return nil end
    local tank = self._tankInfo[index]
    local info = tank["info"]
    if info == nil then
        info = getTankInfoByID(tank["id"])
        tank["info"] = info
    end
    return info
end

local function getGearInfoByGearIndex(self, index)
    if not hasGear(self, index) then return nil end
    local gear = self._gearInfo[index]
    local info = gear["info"]
    if info == nil then
        info = getGearInfoByID(gear["id"])
        gear["info"] = info
    end
    return info
end

local function recordUIState(self, ui, type, value)
    ui["record_" .. type] = value
end

local function getUIState(self, ui, type, defaultValue)
    return ui["record_" .. type] or defaultValue
end

local function getDrawNodeTankAttributeGraph(self)
    local mainNode        = self._mainLayout
    local imageTankDetail = mainNode:getChildByName("Image_detail_base")
    local drawNodeGraph   = self._drawNodeTankGraph
    
    if drawNodeGraph == nil then
        drawNodeGraph = cc.DrawNode:create()
        drawNodeGraph:setName("draw_node_tank_graph")
        imageTankDetail:addChild(drawNodeGraph)
        drawNodeGraph:setPosition(DRAWNODE_TANK_GRAPH_POS_X, DRAWNODE_TANK_GRAPH_POS_Y)
        self._drawNodeTankGraph = drawNodeGraph
    end

    return drawNodeGraph
end

local function refreshDrawNodeTankAttributeGraph(self, attributeList)
    local drawNodeGraph     = getDrawNodeTankAttributeGraph(self)
    local attributeCount    = TANK_GRAPH_ATTRIBUTE_COUNT
    local spanAngleRadians  = math.pi * 2 / attributeCount
    local startAngleRadians = 0
    local pointArray        = {}

    for i = 1, attributeCount do
        local attribValue         = attributeList[i]
        local currentAngleRadians = startAngleRadians + ( i - 1 ) * spanAngleRadians
        local attributeWiegth     = math.min(1.0, attribValue / m_tTankAttributeMaxLimit[i] )
        local attribRadius        = attributeWiegth * MAX_TANK_GRAPH_RADIUS
        local attribPointX        = attribRadius * math.sin(currentAngleRadians)
        local attribPointY        = attribRadius * math.cos(currentAngleRadians)
        table.insert(pointArray, i, cc.p(attribPointX, attribPointY))
    end
    
    table.insert(pointArray, attributeCount + 1, pointArray[1])
    drawNodeGraph:stopAllActions()
    drawNodeGraph:clear()
    
    local tranglePoint  = {}
    local centerPoint   = cc.p(0, 0)
    
    for i = 1, attributeCount do
        tranglePoint[1] = centerPoint
        tranglePoint[2] = pointArray[i]
        tranglePoint[3] = pointArray[i + 1]
        drawNodeGraph:drawSolidPoly(tranglePoint, #tranglePoint, TANK_GRAPH_FILL_COLOR)
    end
end

local function getTexture(self, textureList, imagePath)
    for _, v in ipairs(textureList) do
        if v.imagePath == imagePath then
            return v.texture
        end
    end

    if textureList.top == nil then textureList.top = 1 end
    local top = textureList.top 
    local textureCache = cc.Director:getInstance():getTextureCache()
    local oldItem = textureList[top]
    if oldItem then
        print("*****************", oldItem.imagePath)
        textureCache:removeTexture(oldItem.texture)
    end

    local newItem = oldItem or { ["imagePath"] = nil, ["texture"] = nil, }
    local texture = textureCache:addImage(imagePath)
    newItem.imagePath = imagePath
    newItem.texture   = texture
    textureList[top] = newItem
    top = top % textureList.maxSize + 1
    textureList.top = top
end

local function getCardTexture(self, imagePath)
    if not self._cardTextureList then self._cardTextureList = {} end
    if not self._cardTextureList.maxSize then 
        self._cardTextureList.maxSize = MAX_CARD_TEXTURE_CAPACITY
    end

    return getTexture(self, self._cardTextureList, imagePath)
end

local function getGearTexture(self, imagePath)
    if not self._gearTextureList then self._gearTextureList = {} end
    if not self._gearTextureList.maxSize then 
        self._gearTextureList.maxSize = MAX_GEAR_TEXTURE_CAPACITY
    end

    return getTexture(self, self._gearTextureList, imagePath)   
end

local function releaseTextureCache(self, textureList)
    if not textureList then return end
    local textureCache = cc.Director:getInstance():getTextureCache()
    for _, v in ipairs(textureList) do
        textureCache:removeTexture(v.texture)
    end
end

local function releaseCardTexture(self)
    releaseTextureCache(self, self._cardTextureList)
    self._cardTextureList = {}
end

local function releaseGearTexture(self)
    releaseTextureCache(self, self._gearTextureList)
    self._gearTextureList = {}
end

local function releaseUnuseTexture(self)
    local textureCache = cc.Director:getInstance():getTextureCache()
    textureCache:removeUnusedTextures()
end

local function loadCardTexture(self, unitUI, cardImageView)
    local function loadTexture()
        local curTankNumber = getUIState(self, unitUI, "number", nil)
        local showBroken    = getUIState(self, unitUI, "broken", false)
        local isThumbnail   = getUIState(self, unitUI, "thumbnail", false)
        print("start load card texuteure, number = ", curTankNumber)
        local cardImagePath = getCardImagePath(curTankNumber, isThumbnail, showBroken)
        local cardTexture = getCardTexture(self, cardImagePath)
        cardImageView:loadTexture(cardImagePath)
        cardImageView:setVisible(true)
        recordUIState(self, unitUI, "updated", true)
    end

    local loadTextureDelay = getUIState(self, unitUI, "refreshDelay", 0)
    print("loadTextureDelay ", loadTextureDelay)
    local actionTag = 101 
    local sequence = cc.Sequence:create(
        cc.DelayTime:create(loadTextureDelay),
        cc.CallFunc:create(loadTexture)
    )
    sequence:setTag(actionTag)
    
    unitUI:stopAllActions()
    unitUI:runAction(sequence)
end

local function loadGearTexture(self, unitUI, gearImageView)
    local function loadTexture()
        local curGearNumber = getUIState(self, unitUI, "number", nil)
        print("start load gear texuteure, number = ", curGearNumber)
        local gearImagePath = getGearImagePath(curGearNumber)
        local gearTexture = getGearTexture(self, gearImagePath)
        gearImageView:loadTexture(gearImagePath)
        gearImageView:setVisible(true)
        recordUIState(self, unitUI, "updated", true)
    end

    local loadTextureDelay = getUIState(self, unitUI, "refreshDelay", 0)
    print("loadTextureDelay ", loadTextureDelay)
    local actionTag = 101 
    local sequence = cc.Sequence:create(
        cc.DelayTime:create(loadTextureDelay),
        cc.CallFunc:create(loadTexture)
    )
    sequence:setTag(actionTag)
    
    unitUI:stopAllActions()
    unitUI:runAction(sequence)
    gearImageView:setVisible(false)
end

local function refreshTankNode(self, unitUI, panelCardBase, tankNumber, tankInfo)
    local cardTemplateID = tankNumber
    local cardConfig     = tankInfo

    local tankRarity      = cardConfig.nQuality
    local imageBackGround = panelCardBase:getChildByName("Image_card_base_1")
    local resPathBackground = "res/ui/ui_material/cardbase_thumbnail/card_base_" .. tankRarity .. ".png"
    imageBackGround:loadTexture(resPathBackground)

    local imageWordCard  = panelCardBase:getChildByName("Image_card_kai_1")
    imageWordCard:setVisible(false)

    local imageMedal     = panelCardBase:getChildByName("Image_card_medal_1")
    local resPathMedal   = "res/ui/ui_material/cardbase_thumbnail/card_medal_" .. tankRarity .. ".png"
    imageMedal:loadTexture(resPathMedal)

    local tankType       = cardConfig.nTankType
    local imageCardType  = panelCardBase:getChildByName("Image_card_type_1")
    local resPathCardType = "res/ui/ui_material/cardbase_thumbnail/card_type_" .. tankType .. ".png"
    imageCardType:loadTexture(resPathCardType)

    local imageCharaCard = panelCardBase:getChildByName("Image_card_chara")
    imageCharaCard:setVisible(false)
    loadCardTexture(self, unitUI, imageCharaCard)
   
    local panelCompBase  = panelCardBase:getChildByName("Panel_comp_base_2")
    local textCardName   = panelCompBase:getChildByName("Text_2")
    textCardName:setString(cardConfig.szName)

    local panelStar = panelCompBase:getChildByName("Panel_13")
    for num = 1, MAX_TANK_STAR_LEVEL do
        local imageName = "Image_stars" .. num
        local imageStar = panelStar:getChildByName(imageName)
        imageStar:setVisible(num <= tankRarity)
    end   
end

local function switchImageTankDetailTexture(self, imageTankDetail)
    local panelCardBase       = imageTankDetail:getChildByName("Panel_card_base")
    local projectNodeTankCard = panelCardBase:getChildByName("ProjectNode_tank")

    local currentTankNumber = self._currentTankNumber
    local cardTemplateID    = currentTankNumber
    local showBroken        = getUIState(self, panelCardBase, "broken", false)
    local imagePath         = getCardImagePath(currentTankNumber, false, not showBroken)
    KUtil.drawCardImage(projectNodeTankCard, self._currentTankNumber, imagePath)
    recordUIState(self, panelCardBase, "broken", not showBroken)
end

local function refreshImageTankDetail(self, tankNumber)
    local mainNode         = self._mainLayout
    local imageTankDetail  = mainNode:getChildByName("Image_detail_base")
    local tankInfo         = getTankInfoByTankIndex(self, tankNumber)
    assert(tankInfo ~= nil, string.format("error:tank number %d not found", tankNumber))

    cclog("--------------------> start update tank detail panel, tank Number: %d", tankNumber)
    local panelTankBase       = imageTankDetail:getChildByName("Panel_card_base")
    local projectNodeTankCard = panelTankBase:getChildByName("ProjectNode_tank")
    recordUIState(self, panelTankBase, "number",  tankNumber)
    local imagePath = getCardImagePath(tankNumber)
    KUtil.drawCardImage(projectNodeTankCard, tankNumber, imagePath)

    local scrollVeiwDescription = imageTankDetail:getChildByName("ScrollView_descrition")
    local textDescription       = scrollVeiwDescription:getChildByName("Text_descrition")
    textDescription:setString(tankInfo["szOpeningDialogue"])
    
    local textTankNumber = imageTankDetail:getChildByName("Text_tank_number")
    textTankNumber:setString(string.format("%03d", tankNumber))

    local textTankName = imageTankDetail:getChildByName("Text_tank_name")
    textTankName:setString(tankInfo.szName)

    local textTankType = imageTankDetail:getChildByName("Text_tank_type")
    textTankType:setString(getCardTypeName(tankNumber))

    local tankAttributeList = {}
    for i = 1, #m_tTankAttributeTextName do
        local textAttributeValue = imageTankDetail:getChildByName(m_tTankAttributeTextName[i])
        local attributeName      = m_tTankAttributeInfoName[i]
        local attributeValue     = tankInfo[attributeName]
        tankAttributeList[m_tTankGraphAttributeEnum[attributeName]] = attributeValue
        textAttributeValue:setString(attributeValue)
    end
    refreshDrawNodeTankAttributeGraph(self, tankAttributeList)

    for starCount = 1, MAX_TANK_STAR_LEVEL do
        local imageStar = imageTankDetail:getChildByName("Image_star_" .. starCount)
        imageStar:setVisible(starCount <= tankInfo.nQuality)
    end

    imageTankDetail:setVisible(true)
    self._currentTankNumber = tankNumber
end

local function refreshGearNode(self, unitUI, gearNode, gearNumber, gearInfo)
    local gearTemplateID = gearNumber
    
    local textGearName = gearNode:getChildByName("Text_gear_name")
    textGearName:setString(gearInfo.szName)

    local imageGear = gearNode:getChildByName("Image_gear")
    local resPath   = getGearImagePath(gearTemplateID)
    imageGear:setVisible(false)
    loadGearTexture(self, unitUI, imageGear)

    local gearStarLevel = tonumber(gearInfo.nGrade)
    local panelGearBase = gearNode:getChildByName("Panel_gear_base")
    local panelMedal    = gearNode:getChildByName("Panel_card_meda")
    local panelStar     = gearNode:getChildByName("Panel_stars")
    for starLevel = 1, MAX_GEAR_STAR_LEVEL do
        local imageName       = "Image_gear_base_" .. starLevel
        local imageBackground = panelGearBase:getChildByName(imageName)
        imageBackground:setVisible(false)

        local imageStarControl = panelStar:getChildByName("Image_star_" .. starLevel)
        imageStarControl:setVisible(starLevel <= gearStarLevel)
        
        local imageMedalControl = panelMedal:getChildByName("Image_medal_" .. starLevel)
        imageMedalControl:setVisible(false)
    end
    local backgroundVisibleName = "Image_gear_base_" .. gearStarLevel
    local imageBackground       = panelGearBase:getChildByName(backgroundVisibleName)
    imageBackground:setVisible(true)
    
    local medalVisibleName  = "Image_medal_" .. gearStarLevel
    local imageMedalControl =  panelMedal:getChildByName(medalVisibleName)
    imageMedalControl:setVisible(true)
end

local function refreshImageGearDetail(self, gearNumber)
    local mainNode             = self._mainLayout
    local imageGearDetail      = mainNode:getChildByName("Image_gear_base")
    local gearInfo             = getGearInfoByGearIndex(self, gearNumber)
    local gearID               = gearNumber

    local projectNodeGear = imageGearDetail:getChildByName("ProjectNode_gear_card")
    recordUIState(self, projectNodeGear, "number", gearNumber)
    refreshGearNode(self, projectNodeGear, projectNodeGear, gearNumber, gearInfo)
    
    local scrollGearDescription = imageGearDetail:getChildByName("ScrollView_descrition")
    local textGearDescription   = scrollGearDescription:getChildByName("Text_descrition")
    local tableDescription      = {}
    local gearType              = KUtil.getEquipTypeByID(gearID)
    local gearAttribute         = KUtil.getEquipAttributeByID(gearID)
    table.insert(tableDescription, getGearTypeName(gearID) .. "\n")
    for k, attribute in ipairs(gearAttribute) do
        if attribute > 0 then
            local tmpAttribute = m_szEquipSpecsName[k] .. "+" .. attribute .. "\n"
            table.insert(tableDescription, tmpAttribute)
        end 
    end
    textGearDescription:setString(table.concat(tableDescription))

    local textGearName = imageGearDetail:getChildByName("Text_gear_name")
    local gearName     = gearInfo.szName
    textGearName:setString(gearName)

    imageGearDetail:setVisible(true)
    self._currentGearNumber = gearNumber
end

local function stopPageViewLoadTextureAction(self, pageView)
    local pageUIList = getUIState(self, pageView, "pageUIList", nil)
    for _, pageUI in ipairs(pageUIList) do
        local unitUIList = getUIState(self, pageUI, "unitUIList", nil)
        for _, unitUI in ipairs(unitUIList) do
            unitUI:stopAllActions()
        end
    end
end

local function refreshPageViewTankUnit(self, unitUI)
    local unitIndex      = getUIState(self, unitUI, "index", 1)
    local tankNumber     = getUIState(self, unitUI, "number", 1)

    local tankInfo       = getTankInfoByTankIndex(self, tankNumber)    
    local panelCardBase  = unitUI:getChildByName("Panel_card_base")
    
    if tankInfo == nil then
        if panelCardBase ~= nil then
            panelCardBase:setVisible(false)
        end
        return
    end

    cclog("-----> start refresh tank pageview unit, tank number:%d", tankNumber)
    if panelCardBase == nil then
        panelCardBase = getPanelCardBaseClone(self)
        unitUI:addChild(panelCardBase)
    end

    panelCardBase:setVisible(true)
    recordUIState(self, unitUI, "thumbnail", true)
    refreshTankNode(self, unitUI, panelCardBase, tankNumber, tankInfo)

    local panelNode = panelCardBase:getChildByName("Panel_comp_base_2")
    local function onTankUnitClick(sender, type)
        cclog("-----> onTankUnitClick, tankNumber: %d", tankNumber)
        self:onPageViewPanelClick(self._pageViewTank, sender, type)

        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onTankUnitClick, tankNumber: %d", tankNumber)
        KSound.playEffect("click")
        refreshImageTankDetail(self, tankNumber)
    end
    panelNode:addTouchEventListener(onTankUnitClick)
end

local function refreshPageViewGearUnit(self, unitUI)
    local unitIndex      = getUIState(self, unitUI, "index", 1)
    local gearNumber     = getUIState(self, unitUI, "number", 1)

    local textGearNumber = unitUI:getChildByName("Text_tank_number")
    textGearNumber:setString(string.format("%03d", gearNumber))

    local gearInfo       = getGearInfoByGearIndex(self, gearNumber)    
    local gearNode       = unitUI:getChildByName("Panel_card_base")
    
    if gearInfo == nil then
        if gearNode ~= nil then
            gearNode:setVisible(false)
        end
        return
    end

    cclog("-----> start refresh gear pageview unit, gear number:%d", gearNumber)
    if gearNode == nil then
        gearNode = getGearNodeClone(self)
        unitUI:addChild(gearNode)
    end

    gearNode:setVisible(true)
    refreshGearNode(self, unitUI, gearNode, gearNumber, gearInfo)

    local panelGearBase = gearNode:getChildByName("Panel_gear_base")
    panelGearBase:setTouchEnabled(true)
    local function onGearUnitClick(sender, type)
        self:onPageViewPanelClick(self._pageViewTank, sender, type)

        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onGearUnitClick, gearNumber: %d", gearNumber)
        KSound.playEffect("click")
        refreshImageGearDetail(self, gearNumber)
    end
    panelGearBase:addTouchEventListener(onGearUnitClick)    
end

local function refershPageViewPanel(self, pageView, pageUI)
    local pageLogicIndex = getUIState(self, pageUI, "logicIndex", 1)
    local pageCapacity   = getUIState(self, pageUI, "capacity", 1)
    local pageUnitCount  = getUIState(self, pageUI, "unitCount", 1)
    local unitUIList     = getUIState(self, pageUI, "unitUIList", nil)
    assert(unitUIList ~= nil , string.format("error: unit ui list can not be nil, logic page index %d", pageLogicIndex))
    local funcRefreshPageUnit = getUIState(self, pageView, "funcRefreshPageUnit", nil)
    assert(funcRefreshPageUnit ~= nil, "refresh page unit function can not be nil")
    local curLogicPageIndex = getUIState(self, pageView, "curLogicPageIndex", 1)
    
    local baseUnitUIRfreshDelay = 0
    if curLogicPageIndex ~= pageLogicIndex then
        baseUnitUIRfreshDelay = self._preLoadPageDelay
    end

    for i, unitUI in ipairs(unitUIList) do
        if i <= pageUnitCount then
            local number    = (pageLogicIndex - 1) * pageCapacity + i
            local oldNumber = getUIState(self, unitUI, "number", nil)
            local updated   = getUIState(self, unitUI, "updated", false)

            if number ~= oldNumber or not updated then
                local numberUI = getUIState(self, unitUI, "numberUI", nil)
                if numberUI then
                    numberUI:setString(string.format("%03d", number))
                end
                recordUIState(self, unitUI, "index", i)
                recordUIState(self, unitUI, "number", ( pageLogicIndex - 1 ) * pageCapacity + i)
                recordUIState(self, unitUI, "updated", false)
                local unitUIRefreshDelay = i * REFRESH_PAGE_UNIT_DELAY + baseUnitUIRfreshDelay
                recordUIState(self, unitUI, "refreshDelay", unitUIRefreshDelay)              
                funcRefreshPageUnit(self, unitUI)
            end
            unitUI:setVisible(true)
        else
            unitUI:setVisible(false)
        end
    end
end

local function refreshPageView(self, pageView, defaultPageCapacity, defaultMaxUnitCount)
    pageView:stopAllActions()

    local pageCapacity      = getUIState(self, pageView, "pageCapacity", defaultPageCapacity)
    assert(pageCapacity ~= nil, "page capacity can not  be nil")
    local maxUnitCount      = getUIState(self, pageView, "maxUnitCount", defaultMaxUnitCount)
    assert(maxUnitCount ~= nil, "max unit count can not be nil")

    local pageUIList        = getUIState(self, pageView, "pageUIList", nil)
    local pageCount         = getUIState(self, pageView, "logicPageCount", nil)

    local curLogicPageIndex = getUIState(self, pageView, "curLogicPageIndex", 1)
    local curRealPageIndex  = getUIState(self, pageView, "curPageIndex", 1)
    local logicPageIndex = curLogicPageIndex - curRealPageIndex
    if logicPageIndex <= 0 then 
        logicPageIndex = pageCount - logicPageIndex
    end

    for _, pageUI in ipairs(pageUIList) do
        recordUIState(self, pageUI, "logicIndex", logicPageIndex)
        logicPageIndex = logicPageIndex % pageCount + 1

        local logicPageIndex = getUIState(self, pageUI, "logicIndex", 1)
        local updated        = getUIState(self, pageUI, "updated", false)
        local isLastPage     = pageCapacity * logicPageIndex >= maxUnitCount
        if isLastPage then
            local unitCount = (maxUnitCount - 1) % pageCapacity + 1
            recordUIState(self, pageUI, "unitCount", unitCount)
        else
            recordUIState(self, pageUI, "unitCount", pageCapacity)
        end

        if not updated then
            recordUIState(self, pageUI, "unitUIList", pageUI:getChildren())
            refershPageViewPanel(self, pageView, pageUI)
        end

       -- local visible = curLogicPageIndex == logicPageIndex 
       -- pageUI:setVisible(visible)
    end
end

local function moveImageDetailTank(self, imageTankDetail, inc)
    local curIndex = self._currentTankNumber
    assert(curIndex ~= nil, "curIndex can not be nil")

    local nextIndex = curIndex
    local tankCount = getMaxTankCount()
    while true do
        nextIndex = (nextIndex - 1 + tankCount + inc) %  tankCount + 1
        if hasTank(self, nextIndex) then
            refreshImageTankDetail(self, nextIndex)
            break
        end
    end
end

local function moveImageDetailGear(self, imageTankDetail, inc)
    local curIndex = self._currentGearNumber
    assert(curIndex ~= nil, "curIndex can not be nil")

    local nextIndex = curIndex
    local gearCount = getMaxGearCount()
    while true do
        nextIndex = (nextIndex - 1 + gearCount + inc) %  gearCount + 1
        if hasGear(self, nextIndex) then
            refreshImageGearDetail(self, nextIndex)
            break
        end
    end
end

local function onMovePage(self, pageView)
    local curPageIndex          = pageView:getCurPageIndex()
    local logicPageCount        = getUIState(self, pageView, "logicPageCount", 1)
    local curLogicPageIndex     = getUIState(self, pageView, "curLogicPageIndex", 1)
    local nextLogicPageIndex    = nil
    if curPageIndex == 0 and logicPageCount > 1 then
        nextLogicPageIndex = (curLogicPageIndex - 2 + logicPageCount) % logicPageCount + 1
        local pageUIList = getUIState(self, pageView, "pageUIList", nil)
        local pageUI = pageUIList[3]
        pageUI:retain()
        pageView:removePageAtIndex(2)
        pageView:insertPage(pageUI, 0)
        pageUI:release()
        recordUIState(self, pageUI, "updated", false)
        table.remove(pageUIList, 3)
        table.insert(pageUIList, 1, pageUI)
    elseif curPageIndex == 2 then
        nextLogicPageIndex = curLogicPageIndex % logicPageCount + 1
        local pageUIList = getUIState(self, pageView, "pageUIList", nil)
        local pageUI = pageUIList[1]
        pageUI:retain()
        pageView:removePageAtIndex(0)
        pageView:insertPage(pageUI, 2)
        pageUI:release()
        recordUIState(self, pageUI, "updated", false)
        table.remove(pageUIList, 1)
        table.insert(pageUIList, 3, pageUI)
    end
    
    if nextLogicPageIndex == nil or nextLogicPageIndex == curLogicPageIndex then return end 
    recordUIState(self, pageView, "curLogicPageIndex", nextLogicPageIndex)
     
    refreshPageView(self, pageView)

    pageView:scrollToPage(1)
    pageView:update(1)
    self._preLoadPageDelay = PRELOAD_PAGE_DELAY
end

local function resetPageViewTankState(self, pageView)
    local maxTankCount    = getMaxTankCount()
    local pageCapacity    = TANK_PANEL_CAPACITY
    local pageView        = self._pageViewTank
    local pageCount       = math.ceil(maxTankCount / TANK_PANEL_CAPACITY)
    recordUIState(self, pageView, "pageCapacity", pageCapacity)
    recordUIState(self, pageView, "maxUnitCount", maxTankCount)
    recordUIState(self, pageView, "logicPageCount", pageCount) 
    recordUIState(self, pageView, "curPageIndex", 1)
    --recordUIState(self, pageView, "curLogicPageIndex", 1)
    recordUIState(self, pageView, "funcRefreshPageUnit", refreshPageViewTankUnit)
    
    local pageUIList = pageView:getPages()
    recordUIState(self, pageView, "pageUIList", pageUIList)

    for _, pageUI in ipairs(pageUIList) do
        recordUIState(self, pageUI, "logicIndex", startLogicPageIndex)
        recordUIState(self, pageUI, "capacity", pageCapacity)
        recordUIState(self, pageUI, "unitCount", pageCapacity)
        recordUIState(self, pageUI, "updated", false)

        local unitUIList = pageUI:getChildren()
        recordUIState(self, pageUI, "unitUIList", unitUIList)
        for _, unitUI in ipairs(unitUIList) do
            local numberUI = unitUI:getChildByName("Text_tank_number")
            recordUIState(self, unitUI, "numberUI", numberUI)
        end
    end
    
    pageView:setVisible(true)
    refreshPageView(self, pageView)
    pageView:scrollToPage(1)
    pageView:update(1)
end

local function resetPageViewGearState(self, pageView)
    local maxGearCount    = getMaxGearCount()
    local pageCapacity    = GEAR_PANEL_CAPACITY
    local pageView        = self._pageViewGear
    local pageCount       = math.ceil(maxGearCount / GEAR_PANEL_CAPACITY)
    recordUIState(self, pageView, "pageCapacity", pageCapacity)
    recordUIState(self, pageView, "maxUnitCount", maxGearCount)
    recordUIState(self, pageView, "logicPageCount", pageCount)
    recordUIState(self, pageView, "curPageIndex", 1) 
    --recordUIState(self, pageView, "curLogicPageIndex", 1)
    recordUIState(self, pageView, "funcRefreshPageUnit", refreshPageViewGearUnit)

    local pageUIList = pageView:getPages()
    recordUIState(self, pageView, "pageUIList", pageUIList)

    for _, pageUI in ipairs(pageUIList) do
        recordUIState(self, pageUI, "logicIndex", startLogicPageIndex)
        recordUIState(self, pageUI, "capacity", pageCapacity)
        recordUIState(self, pageUI, "unitCount", pageCapacity)
        recordUIState(self, pageUI, "updated", false)

        local unitUIList = pageUI:getChildren()
        recordUIState(self, pageUI, "unitUIList", unitUIList)
        for _, unitUI in ipairs(unitUIList) do
            local numberUI = unitUI:getChildByName("Text_gear_number")
            recordUIState(self, unitUI, "numberUI", numberUI)
        end
    end

    pageView:setVisible(true)
    refreshPageView(self, pageView)
    pageView:scrollToPage(1)
    pageView:update(1)
end

local function initPageViewPanel(self, pageView, basePanel, pageCount)
    basePanel:addTouchEventListener(function(sender, type)
        self:onPageViewPanelClick(pageView, sender, type)
    end)

    for i = 2, pageCount do
        print("add page, page index,", i)
        local panelClone = basePanel:clone()
        pageView:addPage(panelClone)
    end
end

local function initTankListUI(self)
    if self._pageViewTank ~= nil then return end
    print("init tank page view~")
    local mainNode            = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local pageViewTank        = imageCollectionBase:getChildByName("PageView_tank_list")
    local panelTank           = pageViewTank:getChildByName("Panel_1")

    self._pageViewTank = pageViewTank
    pageViewTank:setCustomScrollThreshold(SCROLL_THRESHOLD)
    pageViewTank:setVisible(true)
    initPageViewPanel(self, pageViewTank, panelTank, MAX_PAGEVIEW_PAGE_COUNT) 
    
    self:registerTankUITouchEvent()
    generateTankNodeBase(self)
end

local function initGearListUI(self)
    if self._pageViewGear ~= nil then return end
    print("init gear page view~")    
    local rootNode            = cc.CSLoader:createNode("res/ui/layout_collection_gear.csb")
    local imageCollectionBase = rootNode:getChildByName("Image_collection_base")
    local pageViewGear        = imageCollectionBase:getChildByName("PageView_gear_list")
    local imageGearBase       = rootNode:getChildByName("Image_gear_base")
    local panelGear           = pageViewGear:getChildByName("Panel_1")

    self._pageViewGear = pageViewGear
    pageViewGear:setCustomScrollThreshold(SCROLL_THRESHOLD)
    pageViewGear:setVisible(true)
    imageGearBase:setVisible(false)
    initPageViewPanel(self, pageViewGear, panelGear, MAX_PAGEVIEW_PAGE_COUNT)

    imageCollectionBase:removeChild(pageViewGear, false)
    rootNode:removeChild(imageGearBase, false)

    local mainNode            = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    mainNode:addChild(imageGearBase)
    imageCollectionBase:addChild(pageViewGear)
    
    self:registerGearUITouchEvent()
    generateGearNodeBase(self)
end

local function releaseGearUI(self)
    if self._pageViewGear then
        self._pageViewGear:setVisible(false)
    end
    releaseGearTexture(self)
end

local function releaseTankUI(self)
    if self._pageViewTank then
        self._pageViewTank:setVisible(false)
    end
    --releaseTankTexture(self)
end

local function switchToTankList(self)
    initTankInfo(self)
    initTankListUI(self)
    resetPageViewTankState(self)
    releaseGearUI(self)
end

local function switchToGearList(self)
    initGearInfo(self)
    initGearListUI(self)
    resetPageViewGearState(self)
    releaseTankUI(self)
end

local function refreshButtonSheet(self, fromState, toState)
    local mainNode            = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local buttonTankSheet     = imageCollectionBase:getChildByName("Button_tank_sheet")
    local buttonGearSheet     = imageCollectionBase:getChildByName("Button_gear_sheet")   
    
    local textureRootPath     = "res/ui/ui_material/collection/"
    if fromState == self.uiState.UI_TANK_LIST then
        buttonTankSheet:loadTextureNormal(textureRootPath .. "tj_tank_sheet.png")
    elseif fromState == self.uiState.UI_GEAR_LIST then
        buttonGearSheet:loadTextureNormal(textureRootPath .. "tj_gear_sheet.png")
    end

    if toState == self.uiState.UI_TANK_LIST then
        buttonTankSheet:loadTextureNormal(textureRootPath .. "tj_tank_sheet_active.png")
    elseif toState == self.uiState.UI_GEAR_LIST then
        buttonGearSheet:loadTextureNormal(textureRootPath .. "tj_gear_sheet_active.png")
    end
end

function KUICollectionNode:onPageViewPanelClick(pageView, sender, type)
    if type == ccui.TouchEventType.began then
        stopPageViewLoadTextureAction(self, pageView)
    end
    if type == ccui.TouchEventType.moved then
    end
    if type == ccui.TouchEventType.ended then
        refreshPageView(self, pageView)
    end
end

function KUICollectionNode:switchUI(fromState, toState)
    if toState == fromState then return end

    if toState == self.uiState.UI_TANK_LIST then
        switchToTankList(self)
    end

    if toState == self.uiState.UI_GEAR_LIST then
        switchToGearList(self)
    end

    refreshButtonSheet(self, fromState, toState)
    self._curUIState = toState
end

function KUICollectionNode:refreshUI()
    hideUI(self)
    self:switchUI(self._curUIState, self.uiState.UI_TANK_LIST)
end

function KUICollectionNode:registerTankUITouchEvent()
    local mainNode = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local pageTankList = imageCollectionBase:getChildByName("PageView_tank_list")
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then
            onMovePage(self, self._pageViewTank)
        end
    end
    pageTankList:addEventListener(onPageViewEvent)

    local imageTankDetailBase   = mainNode:getChildByName("Image_detail_base")
    local panelCardBase         = imageTankDetailBase:getChildByName("Panel_card_base")
    local projectNode           = panelCardBase:getChildByName("ProjectNode_tank")
    local panelNode             = projectNode:getChildByName("Panel_card_base")
    local panelNode             = projectNode:getChildByName("Panel_card_chara") 
    panelCardBase:setTouchEnabled(true)
   local function onImageTankDetailClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       cclog("-----> onImageTankDetailClick~")
       switchImageTankDetailTexture(self, imageTankDetailBase)
   end
   panelCardBase:addTouchEventListener(onImageTankDetailClick)
   
   local buttonCloseTankDetail = imageTankDetailBase:getChildByName("Button_close_detail")
   local function onCloseTankDetailClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       KSound.playEffect("close")
       cclog("-----> onCloseTankDetailClick~")
       imageTankDetailBase:setVisible(false)
   end
   buttonCloseTankDetail:addTouchEventListener(onCloseTankDetailClick)

   local buttonLeftTank = imageTankDetailBase:getChildByName("Button_left_detail")
   local function onLeftTankClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       KSound.playEffect("click")
       cclog("-----> onLeftTankClick~")
       local backward = -1
       moveImageDetailTank(self, imageTankDetailBase, backward)
   end
   buttonLeftTank:addTouchEventListener(onLeftTankClick)

   local buttonRightTank = imageTankDetailBase:getChildByName("Button_right_detail")
   local function onRightTankClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       KSound.playEffect("click")
       cclog("-----> onRightTankClick~")
       local forward = 1
       moveImageDetailTank(self, imageTankDetailBase, forward)
   end
   buttonRightTank:addTouchEventListener(onRightTankClick)

   local buttonTankSound = imageTankDetailBase:getChildByName("Button_sound")
   local function onTankSoundClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       KSound.playEffect("click")
       KSound.playTalk(KSound.TALK.GETCARD, self._currentTankNumber)
       cclog("-----> onTankSoundClick, current tank number : %d~", self._currentTankNumber)
   end
   buttonTankSound:addTouchEventListener(onTankSoundClick)
end

function KUICollectionNode:registerGearUITouchEvent()
    local mainNode = self._mainLayout
    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    local pageGearList = imageCollectionBase:getChildByName("PageView_gear_list")
    local function onPageViewEvent(sender, type)
       if type == ccui.PageViewEventType.turning then
           onMovePage(self, self._pageViewGear)
       end    
    end
    pageGearList:addEventListener(onPageViewEvent)


    local imageGearDetailBase   = mainNode:getChildByName("Image_gear_base")

    local buttonCloseGearDetail = imageGearDetailBase:getChildByName("Button_close_gear")
    local function onCloseGearDetailClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        cclog("-----> onCloseTankDetailClick~")
        imageGearDetailBase:setVisible(false)
    end
    buttonCloseGearDetail:addTouchEventListener(onCloseGearDetailClick)

    local buttonLeftGear = imageGearDetailBase:getChildByName("Button_left_gear")
    local function onLeftGearClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onLeftGearClick~")
        local backward = -1
        moveImageDetailGear(self, imageGearDetailBase, backward)
    end
    buttonLeftGear:addTouchEventListener(onLeftGearClick)

    local buttonRightGear = imageGearDetailBase:getChildByName("Button_right_gear")
    local function onRightGearClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRightGearClick~")
        local forward = 1
        moveImageDetailGear(self, imageGearDetailBase, forward)
    end
    buttonRightGear:addTouchEventListener(onRightGearClick)
end

function KUICollectionNode:registerAllTouchEvent()
    local mainNode = self._mainLayout    
    local buttonControl = mainNode:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            self._parent:returnOffice()
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    local imageCollectionBase = mainNode:getChildByName("Image_collection_base")
    
    local buttonControl = imageCollectionBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")
            cclog("click onCloseButton~")
            self._parent:removeNode("Collection")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local buttonControl = imageCollectionBase:getChildByName("Button_tank_sheet")
    local function onTankSheetClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("click onTankSheetClick")
            self:switchUI(self._curUIState, self.uiState.UI_TANK_LIST)
        end
    end
    buttonControl:addTouchEventListener(onTankSheetClick)

    local buttonControl = imageCollectionBase:getChildByName("Button_gear_sheet")
    local function onGearSheetClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("click onGearSheetClick")
            self:switchUI(self._curUIState, self.uiState.UI_GEAR_LIST)
        end
    end
    buttonControl:addTouchEventListener(onGearSheetClick)
end

function KUICollectionNode:onNodeExit()
    if self._tankNodeBase then
        self._tankNodeBase:release()
    end
    if self._gearNodeBase then
        self._gearNodeBase:release()
    end
    releaseCardTexture(self)
    releaseGearTexture(self)
    releaseUnuseTexture(self)
end

return KUICollectionNode
