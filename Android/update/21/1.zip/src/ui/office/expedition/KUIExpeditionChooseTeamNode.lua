--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExpeditionChooseTeamNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/28   9:20
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_szbuttonDisableTexture  = "res/ui/ui_material/public/common_team_button_disable.png"

local KUIExpeditionChooseTeamNode = class(
    "KUIExpeditionChooseTeamNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExpeditionChooseTeamNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._templateID     = nil
    self._areaType       = nil
    self._selectTeam     = 1
    self._isRunnin       = false
    self._lastUpdateTime = 0
end

function KUIExpeditionChooseTeamNode.create(owner, userData)
    local currentNode = KUIExpeditionChooseTeamNode.new()

    currentNode._parent       = owner
    currentNode._uiPath       = "res/ui/layout_expedition_team.csb"
    currentNode._templateID   = userData.nTemplateID
    currentNode._areaType     = userData.nAreaID
    --init expedition data
    local expeditionData = KUtil.getOneExpeditionData(userData.nAreaID, userData.nTemplateID)
    if expeditionData then 
        currentNode._selectTeam = expeditionData.nTeamID
        currentNode._isRunnin   = true
    else
        currentNode._selectTeam = KUtil.getExpeditionChooseTeam() or currentNode._selectTeam
    end
    currentNode:init()

    return currentNode
end

local function checkSupplyCard(self, teamCardList)
    local fullSize = 0
    for i, card in ipairs(teamCardList) do
        local cardConfig = KConfig.cardInfo[card.nTemplateID]
        local carryOil   = cardConfig.nCarryOil
        local carryAmmo  = cardConfig.nCarryAmmo
        if card.nCurrentOil >= carryOil and card.nCurrentAmmo >= carryAmmo then 
            fullSize = fullSize + 1
        end
    end
    return (fullSize == #teamCardList)
end

local function CheckExpeditionCondition(self, teamCardList)
    local cardList = KPlayer.tCardData.tStoreHouse.tCardList
    local config = KUtil.getExpeditionConfig(self._areaType, self._templateID)
    --check result
    local oneCard, cardConfig
    local tankTypeTable = {}
    assert(#teamCardList > 0)
    --check count
    if #teamCardList < config.nNeedCount then 
        return ERROR_CODE.EXPEDITION_COUNT_NOT_ENNOGH
    end

    local allLevel = 0
    for i, oneCard in ipairs(teamCardList) do
        cardConfig = KConfig.cardInfo[oneCard.nTemplateID]
        local tankType = cardConfig.nTankType
        allLevel = allLevel + oneCard.nLevel
        --check main card level
        if 1 == i then
            if  oneCard.nLevel < config.nLeaderLevel then 
                return ERROR_CODE.EXPEDITION_LEADER_LEVEL
            end
            if  config.nLeaderType ~= 0 and config.nLeaderType ~= tankType then 
                return ERROR_CODE.EXPEDITION_LEADER_TYPE
            end
            if config.nLeaderType == 0 then
                -- store tank type
                tankTypeTable[tankType] = tankTypeTable[tankType]  or 0 
                tankTypeTable[tankType] = tankTypeTable[tankType] + 1
            end
        else
            -- store tank type
            tankTypeTable[tankType] = tankTypeTable[tankType]  or 0 
            tankTypeTable[tankType] = tankTypeTable[tankType] + 1
        end
    end

    -- average level
    local averageLevel = math.floor(allLevel / #teamCardList)
    if config.nAverageLevel > averageLevel then
        return ERROR_CODE.EXPEDITION_AVERAGE_LEVEL, averageLevel
    end
    -- tank type 
    for _, item in ipairs(config.tCondition) do
        local tankType  = item[1]
        local tankCount = item[2]
        local count     = tankTypeTable[tankType] or 0
        if count < tankCount then 
            return ERROR_CODE.EXPEDITION_MENBER_TYPE
        end
    end

    return 0
end

local function handleExpeditionClick(self, areaType, templateID, teamID)
    if self._isRunnin then
        showNoticeByID("expedition.isRuning")
        return
    end
    if self._selectTeam == 1 then
        showNoticeByID("expedition.isFirstTeam")
        return
    end
    local cardList = KUtil.getOneTeamCardList(teamID)
    if #cardList == 0 then
        showNoticeByID("expedition.teamEmpty")
        return
    end
    local isTeamExpedition = KUtil.isTeamInExpedition(teamID)
    if isTeamExpedition then
        showNoticeByID("expedition.onExpedition")
        return
    end
    local errorCode, averageLevel = CheckExpeditionCondition(self, cardList)
    if errorCode ~= 0 then
        if errorCode == ERROR_CODE.EXPEDITION_AVERAGE_LEVEL then
            showNoticeByID("expedition.averageNotEnough", averageLevel)
            return
        end
        KPlayer:ErrorRespond(errorCode)
        return
    end

    local isFull = checkSupplyCard(self, cardList)
    if not isFull then
        showNoticeByID("expedition.shouldSupply")
        return
    end
    require("src/network/KC2SProtocolManager"):joinExpeditionMission(areaType, templateID, teamID)
end

local function handleCallBackClick(self, areaType, templateID)
    if not self._isRunnin then
        showNoticeByID("expedition.isFinish")
        return
    end
    require("src/network/KC2SProtocolManager"):cancelExpeditionMission(areaType, templateID)
end

local function getTeamPanelUI(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam   = imageBase:getChildByName("ProjectNode_team")
    local panelTeam         = projectNodeTeam:getChildByName("Panel_launch_team_left")
    return panelTeam
end

local function getRightPanelUI(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local projectRight     = imageCommon:getChildByName('ProjectNode_right')
    local panelRight       = projectRight:getChildByName("Panel_ani_launch_team_right")
    return panelRight
end

local function getBottomPanelUI(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local projectBottom    = imageCommon:getChildByName("ProjectNode_bottom_button")
    local panelBottom      = projectBottom:getChildByName("Panel_launch_team_bottom")
    return panelBottom
end

local function getTopPanelUI(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")
    return panelTop
end

local function refreshLeftTime(self)
    local panelRight       = getRightPanelUI(self)
    local imageRadar       = panelRight:getChildByName("Image_cj_radar_net")
    local expeditionStatus = KUtil.getExpeditionStatus(self._areaType, self._templateID)
    local leftTime         = KUtil.getExpeditionLeftTime(self._areaType, self._templateID)
    local expeditionConfig = KUtil.getExpeditionConfig(self._areaType, self._templateID)
    if expeditionStatus == EXPEDITION_STATUS.NOTSTART then
        leftTime = expeditionConfig.nTime * 60
    end

    local textTimeLeft   = imageRadar:getChildByName("Text_expedition_time")
    local leftTimeString = KUtil.getLeftTime(leftTime)
    textTimeLeft:setString(leftTimeString)
end

local function refreshRightAreaExpeditonInfo(self)
    local panelRight  = getRightPanelUI(self)

    --get data
    local expeditionData   = KUtil.getOneExpeditionData(self._templateID)
    local expeditionConfig = KUtil.getExpeditionConfig(self._areaType, self._templateID)
    
    --update name
    local imageExpeditionName = panelRight:getChildByName("Text_mission_name")
    imageExpeditionName:setString(expeditionConfig.szName)
    --update description
    local imageDescription = panelRight:getChildByName("Text_mission_description")
    imageDescription:setString(expeditionConfig.szDescription)
    
    local itemList   = KUtil.getExpeditionItem(expeditionConfig)
    local panelFrame = panelRight:getChildByName("Panel_article_frame")

    local imageQuality = panelFrame:getChildByName("Image_quality_1")
    local scaleX       = imageQuality:getScaleX()
    local panelWidth   = imageQuality:getContentSize().width * scaleX

    local i = 0
    while true do
        i = i + 1
        local imageQuality = panelFrame:getChildByName("Image_quality_" .. i)
        if not imageQuality then return end
        local itemInfo = itemList[i]
        if itemInfo then
            local panelIcon = imageQuality:getChildByName("Panel_icon")
            local imageIcon = panelIcon:getChildByName("Image_award_prop")
            local textName  = imageQuality:getChildByName("Text_name")

            local itemPath, scale = KUtil.getRewardItemPathAndScale(itemInfo.nType, itemInfo.nID)
            local itemName        = KUtil.getItemName(itemInfo.nType, itemInfo.nID)
            imageIcon:loadTexture(itemPath)

            local newWidth   = imageIcon:getContentSize().width
            local scaleRatio = panelWidth / newWidth
            imageIcon:setScale(scaleRatio)
            textName:setString(itemName)
        end

        imageQuality:setVisible(itemInfo ~= nil)
    end
end

local function refreshRightAreaExpedtionConfig(self)
    local panelRight  = getRightPanelUI(self)
    local conditionControl = panelRight:getChildByName("Image_cj_radar_net")
    local expeditionConfig = KUtil.getExpeditionConfig(self._areaType, self._templateID)

    local textAverageLevel = conditionControl:getChildByName("Text_grade")
    textAverageLevel:setString(string.format(KUtil.getStringByKey("expedition.averageLevel"), expeditionConfig.nAverageLevel)) 

    local textTankNumber = conditionControl:getChildByName("Text_number_tanks")
    textTankNumber:setString(expeditionConfig.nNeedCount .. "+")

    local conditionString = KUtil.getExpeditionTankTypeString(expeditionConfig)
    local textTankNeed     = conditionControl:getChildByName("Text_tank_need")
    textTankNeed:setString(conditionString)

    local rewardID     = expeditionConfig.nRewardID
    local itemList     = {}
    local resourceMap  = {}
    local rewardInfo = KConfig.reward[rewardID]
    if rewardInfo then itemList = rewardInfo.tList end
    for _, item in pairs(itemList) do
        if item.nType == ITEM_TYPE.CURRENCY and item.nRate ~= 0 and item.nNum ~= 0 then
            resourceMap[item.nID] = item.nNum
        end
    end

    local resourceIDs = {CURRENCY_TYPE.STEEL, CURRENCY_TYPE.AMMO, CURRENCY_TYPE.OIL, CURRENCY_TYPE.PEOPLE,}
    local speedNames  = {"nSteelSpeed", "nAmmoSpeed", "nOilSpeed", "nPeopleSpeed",}
    for index, resourceID in ipairs(resourceIDs) do
        local textResource = conditionControl:getChildByName("Text_resource_" .. index)
        local resourceNum = resourceMap[resourceID] or 0
        local resourceString = " "
        if resourceNum ~= 0 then
            resourceString = resourceNum .. "-" .. (resourceNum * 2)
        else
            resourceString = "0"
        end
        textResource:setString(resourceString)

        local textExtraResource = conditionControl:getChildByName("Text_additional_" .. index)
        local resourceName = speedNames[index]
        textExtraResource:setString("+" .. string.format(KUtil.getStringByKey("expedition.extraResource"), expeditionConfig[resourceName]))
    end
    refreshLeftTime(self)
end

local function refreshRightArea(self)
    refreshRightAreaExpeditonInfo(self)
    refreshRightAreaExpedtionConfig(self)
end

local function refreshCharacterImage(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeChara  = imageBase:getChildByName("ProjectNode_chara")
    local panelChara        = projectNodeChara:getChildByName("Panel_common_chara")
    local imageChara        = panelChara:getChildByName("Image_common_chara")

    local cardList = KUtil.getOneTeamCardList(self._selectTeam)
    local backgroundImagePath = "res/ui/ui_material/award/jl_background1.png"
    if #cardList == 0 then
        imageChara:setVisible(false)
        imageBase:loadTexture(backgroundImagePath)
        return 
    end
    imageChara:setVisible(true)
    local teamLeaderCard = KUtil.getTeamLeaderCard(self._selectTeam)
    assert(teamLeaderCard, "can not find team leader in team " .. self._selectTeam)

    local cardImagePath = KUtil.getCardImagePath(teamLeaderCard, false)
    imageChara:loadTexture(cardImagePath)

    local cardConfig   = KUtil.getCardConfig(teamLeaderCard.nTemplateID)
    local nQuality     = cardConfig.nQuality
    local bRing        = teamLeaderCard.bRing

    backgroundImagePath = "res/ui/ui_material/award/jl_background" .. nQuality .. ".png"
    -- if bRing then
    --     backgroundImagePath = "res/ui/ui_material/award/jl_background_ring.png"
    -- end
    imageBase:loadTexture(backgroundImagePath)
end

local function refreshLeftTeamResource(self)
    local panelTeam  = getTeamPanelUI(self)
    local cardList   = KUtil.getOneTeamCardList(self._selectTeam)
    local i = 0
    while true do
        i = i + 1
        local imageUnitBase   = panelTeam:getChildByName("Node_cj_team_unit_" .. i)
        if not imageUnitBase then break end

        local card            = cardList[i]
        if card then
            local headBaseControl = imageUnitBase:getChildByName("Image_common_chara_base")
            local imageAmmo       = headBaseControl:getChildByName("Image_cj_ammo_warning")
            local maxCarryAmmo    = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
            imageAmmo:setVisible(maxCarryAmmo > card.nCurrentAmmo)

            local imageOil      = headBaseControl:getChildByName("Image_cj_oil_warning")
            local maxCarryOil   = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
            imageOil:setVisible(maxCarryOil > card.nCurrentOil)
        end
    end
end

local function refreshOneCardUI(self, imageUnitBase, card)
    if not card then 
        imageUnitBase:setVisible(false)
        return
    end

    imageUnitBase:setVisible(true)
    local headBaseControl = imageUnitBase:getChildByName("Image_common_chara_base")
    local projectNodeCard = headBaseControl:getChildByName("ProjectNode_card")
    KUtil.onlyUpdateCardHeadBase(projectNodeCard, card)

    local imageOil      = headBaseControl:getChildByName("Image_cj_oil_warning")
    local maxCarryOil   = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
    imageOil:setVisible(maxCarryOil > card.nCurrentOil)

    local imageAmmo     = headBaseControl:getChildByName("Image_cj_ammo_warning")
    local maxCarryAmmo  = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
    imageAmmo:setVisible(maxCarryAmmo > card.nCurrentAmmo)

    local imageRepairing = headBaseControl:getChildByName("Image_common_repairing")
    local isCardRepair   = KUtil.isCardRepair(card.nID)
    imageRepairing:setVisible(isCardRepair)

    local cardConfig = KConfig.cardInfo[card.nTemplateID]
    local labelTankName = headBaseControl:getChildByName("Text_tank_name")
    labelTankName:setString(cardConfig.szName)

    local labelTankLevel = headBaseControl:getChildByName("BitmapFontLabel_series")
    labelTankLevel:setString("lv." .. card.nLevel)

    local maxHp     = KUtil.getCardMaxHp(card)
    local attribute = KUtil.getCurrentAttribute(card, true)
    local currentHP = attribute[ATTRIBUTE.HP]

    local cardHPPercent = currentHP / maxHp * 100
 
    local hpName    = {nil, nil, nil, nil, nil}
    local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
    KUtil.drawCardState(nil, headBaseControl, hpName, stateName, cardHPPercent)
end

local function refreshLeftTeam(self)
    local panelTeam  = getTeamPanelUI(self)
    local cardList   = KUtil.getOneTeamCardList(self._selectTeam)
    local i = 0
    while true do
        i = i + 1
        local imageUnitBase   = panelTeam:getChildByName("Node_cj_team_unit_" .. i)
        if not imageUnitBase then break end

        local card = cardList[i]
        refreshOneCardUI(self, imageUnitBase, card)
    end
end

local function refreshTeamInfoArea(self)
    -- refresh level
    local panelRight = getRightPanelUI(self)
    local imageRight = panelRight:getChildByName("Image_cj_radar_net")
    local textGrade  = imageRight:getChildByName("Text_grade_1")
    local cardList   = KUtil.getOneTeamCardList(self._selectTeam)

    local allLevel = 0
    for i, oneCard in ipairs(cardList) do
        allLevel = allLevel + oneCard.nLevel
    end
    -- average level
    local averageLevel = math.floor(allLevel / #cardList)
    local averageLevelStr = string.format(KUtil.getStringByKey("expedition.currentAverageLevel"), averageLevel)
    textGrade:setString("(" .. averageLevelStr .. ")")  
end

local function refreshTopButtonStatus(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")

    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end
        if i == self._selectTeam then
            teamSheetUI:setTouchEnabled(false)
            teamSheetUI:setBrightStyle(1)
        else
            teamSheetUI:setTouchEnabled(true)
            teamSheetUI:setBrightStyle(0)
        end
    end
end

local function refreshExpeditionStatus(self)
    local panelBottom      = getBottomPanelUI(self)
    local imageBottom      = panelBottom:getChildByName("Image_bottom_button")
    local buttonExpedition = imageBottom:getChildByName("Button_expedition")
    local buttonCallback   = imageBottom:getChildByName("Button_launch_button")
    
    buttonExpedition:setVisible(false)
    buttonCallback:setVisible(false)
    local expeditionStatus = KUtil.getExpeditionStatus(self._areaType, self._templateID)
    if expeditionStatus == EXPEDITION_STATUS.NOTSTART then
        buttonExpedition:setVisible(true)
        self._isRunnin = false
    elseif expeditionStatus == EXPEDITION_STATUS.RUNNING then
        buttonCallback:setVisible(true)
        self._isRunnin = true
    else
        self._isRunnin = false
    end
    refreshLeftTime(self)
end

local function refreshExpeditionTeam(self)
    local panelTop = getTopPanelUI(self)
    local i = 1
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end
        
        local projectNodeMark = teamSheetUI:getChildByName("ProjectNode_mark")
        local isExpedition    = KUtil.isTeamInExpedition(i)
        projectNodeMark:setVisible(isExpedition)
    end
end

local function handleQuickSupplyClick(self, selectTeam)
    local cardList = KUtil.getOneTeamCardList(selectTeam)
    if #cardList == 0 then
        showNoticeByID("expedition.teamEmpty")
        return false
    end
    KUtil.supplyTeamCard(selectTeam)
end

local function handleTeamClick(self, teamID)
    if self._isRunnin then
        showNoticeByID("expedition.canNotChangeTeam")
        return
    end
    self._selectTeam = teamID
    self:refreshTeamUI()
end

local function stopAllAnimation(self)
    local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam = imageBase:getChildByName("ProjectNode_team")
    projectNodeTeam:stopAllActions()

    local projectNodeBottom = imageBase:getChildByName("ProjectNode_bottom_button")
    projectNodeBottom:stopAllActions()

    local projectNodeTop = imageBase:getChildByName("ProjectNode_top")
    projectNodeTop:stopAllActions()

    local projectNodeRight = imageBase:getChildByName("ProjectNode_right")
    projectNodeRight:stopAllActions()

    local projectNodeChara = imageBase:getChildByName("ProjectNode_chara")
    projectNodeChara:stopAllActions()

    local projectHome = mainNode:getChildByName("ProjectNode_button_home")
    projectHome:stopAllActions()
end

local function playTeamLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam = imageCommon:getChildByName("ProjectNode_team")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_left"
    return KUtil.playPanelAnimation(projectNodeTeam, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeBottom = imageCommon:getChildByName("ProjectNode_bottom_button")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_expedition_team_bottom"
    return KUtil.playPanelAnimation(projectNodeBottom, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTopAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeTop  = imageCommon:getChildByName("ProjectNode_top")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_top"
    return KUtil.playPanelAnimation(projectNodeTop, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRightAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeRight = imageCommon:getChildByName("ProjectNode_right")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_expedition_team_right"
    return KUtil.playPanelAnimation(projectNodeRight, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playCharacterAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeChara = imageCommon:getChildByName("ProjectNode_chara")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_chara"
    return KUtil.playPanelAnimation(projectNodeChara, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function initTeamTopUI(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")

    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end

        local teamID = i
        if teamID > 1 then
            local teamSheetUI     = panelTop:getChildByName("Button_team_sheet_" .. teamID)
            local projectNodeMark = teamSheetUI:getChildByName("ProjectNode_mark")
            local isExpedition    = KUtil.isTeamInExpedition(teamID)
            projectNodeMark:setVisible(isExpedition)
        end

        if i > KPlayer.tTeamData.nOpenCount then
            teamSheetUI:loadTextures(m_szbuttonDisableTexture, m_szbuttonDisableTexture, m_szbuttonDisableTexture)
            teamSheetUI:setEnabled(false)
            local imageTeamIndex = teamSheetUI:getChildByName("Image_common_team" .. i)
            imageTeamIndex:setVisible(false)
        end
    end
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, playTeamLeftAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playRightAnimation(self, false))
        table.insert(framesList, playCharacterAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "ExpeditionChooseTeam", callBacks, isReturnOffice)
end

local function registerHomeTouchEvent(self)
    local mainNode      = self._mainLayout
    local buttonProject = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome     = buttonProject:getChildByName("Panel_common_home")
    local buttonHome    = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")       
            playPanelCloseAnimation(self, true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)
end

local function registerTopTouchEvent(self)
    local panelTop          = getTopPanelUI(self)
    local buttonClose       = panelTop:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")       
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end

        local teamIndex = i
        local function onTeamSheetClick(send, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("click")
            handleTeamClick(self, teamIndex)
        end
        teamSheetUI:addTouchEventListener(onTeamSheetClick)
    end
end

local function registerBottomTouchEvent(self)
    local panelButtom      = getBottomPanelUI(self)
    local imageButtom      = panelButtom:getChildByName("Image_bottom_button")
    local buttonExpedition = imageButtom:getChildByName("Button_expedition")
    local function onExpeditionClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("click onExpeditionClick~ teamID:%d ExpeditionID:%d, areaID:%d",self._selectTeam, self._templateID, self._areaType)
            handleExpeditionClick(self, self._areaType, self._templateID, self._selectTeam)
        end
    end
    buttonExpedition:addTouchEventListener(onExpeditionClick)
    --Callback Button
    local buttonCallback = imageButtom:getChildByName("Button_launch_button")
    local function onCallBackClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("click onCallBackClick~ ExpeditionID:%d, areaID:%d", self._templateID, self._areaType)
            handleCallBackClick(self, self._areaType, self._templateID)
        end
    end
    buttonCallback:addTouchEventListener(onCallBackClick)
    -- team button
    local buttonTeamChange = imageButtom:getChildByName("Button_team_adjustment")
    local function onCallBackClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local userData = {teamID = self._selectTeam}
            self._parent:addNode("Team", userData)
        end
    end
    buttonTeamChange:addTouchEventListener(onCallBackClick)

    --Quick supply button
    local buttonQuickSupply = imageButtom:getChildByName("Button_quick_supply")
    local function onQuickSupplyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("click onQuickSupplyClick~ teamID:%d", self._selectTeam)
            handleQuickSupplyClick(self, self._selectTeam)
        end
    end
    buttonQuickSupply:addTouchEventListener(onQuickSupplyClick)
end

function KUIExpeditionChooseTeamNode:activate(nowTime)
    if self._lastUpdateTime ~= nowTime then
        refreshExpeditionStatus(self)
    end
    self._lastUpdateTime = nowTime
end

function KUIExpeditionChooseTeamNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    playTeamLeftAnimation(self, true)
    playBottomAnimation(self, true)
    playTopAnimation(self, true)
    playRightAnimation(self, true)
    playCharacterAnimation(self, true)
end

function KUIExpeditionChooseTeamNode:onInitUI()
    stopAllAnimation(self)
    initTeamTopUI(self)
end

function KUIExpeditionChooseTeamNode:refreshTeamUI()
    refreshLeftTeam(self)
    refreshTeamInfoArea(self)
    refreshTopButtonStatus(self)
    refreshCharacterImage(self)
end

function KUIExpeditionChooseTeamNode:refreshUI()
    refreshExpeditionTeam(self)
    self:refreshTeamUI()
    refreshRightArea(self)
    refreshExpeditionStatus(self)
end

function KUIExpeditionChooseTeamNode:registerAllTouchEvent()
    registerBottomTouchEvent(self)
    registerTopTouchEvent(self)
    registerHomeTouchEvent(self)
end

function KUIExpeditionChooseTeamNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onExpeditionChange(nType, nTemplateID)
        cclog("onEvent ------------> KUIExpeditionChooseTeamNode onExpeditionChange")
        if self._templateID == nTemplateID then
            self._parent:removeNode("ExpeditionChooseTeam")
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ADD_EXPEDITION, onExpeditionChange)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_REMOVE_EXPEDITION, onExpeditionChange)

    local function onSupplyTeamFinish()
        showNoticeByID("supply.teamSuccess")
        refreshLeftTeamResource(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish) 

    local function onRefreshTeamChange()
        cclog("onEvent ------------> KUIExpeditionChooseTeamNode onRefreshTeamChange")
        self:refreshTeamUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onRefreshTeamChange)
end

return KUIExpeditionChooseTeamNode
