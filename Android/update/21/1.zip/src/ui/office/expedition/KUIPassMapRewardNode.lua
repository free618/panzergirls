--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIPassMapRewardNode.lua
--  Creator     : jiangxufeng
--  Date        : 2016/02/18   14:00
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_ITEM_COUNT = 5
local KUIPassMapRewardNode = class(
    "KUIPassMapRewardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIPassMapRewardNode:ctor()
    self._mainLayout  = nil
    self._parent      = nil
    self._uiPath      = nil
    self._resultList  = {}
    self._callback    = nil
    self._isCovered   = false    
end

function KUIPassMapRewardNode.create(owner, userData)
    local currentNode = KUIPassMapRewardNode.new()

    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_passmap_reward.csb"
    currentNode._resultList   = userData.tResultList

    currentNode:init()

    return currentNode
end

local function refeshReward(self)
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_passmap_reward")
    local tResultList = self._resultList
    
    local itemCount   = #tResultList
    if itemCount > MAX_ITEM_COUNT then 
        itemCount = MAX_ITEM_COUNT 
    end
    
    local panelMain       = projectNode:getChildByName("Panel_passmap_reward")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")
    local panelAwardList  = panelAwardList1
    local viewCount       = 0 
    if itemCount % 2 == 0 then
        panelAwardList1:setVisible(false)
        panelAwardList  = panelAwardList2
        viewCount = MAX_ITEM_COUNT - 1
    else
        panelAwardList2:setVisible(false)
        panelAwardList  = panelAwardList1
        viewCount = MAX_ITEM_COUNT
    end

    for i = 1, viewCount do
        local imageAward = panelAwardList:getChildByName("Image_award_gain_"..i)
        if i <= itemCount then
            local item = tResultList[i]
            imageAward:setVisible(true)
            local clippingPanel = imageAward:getChildByName("Panel_furniture_icon")
            local clippingIcon = clippingPanel:getChildByName("Panel_icon")
            local imageGain    = clippingIcon:getChildByName("Image_icon")

            local textGain  = imageAward:getChildByName("Text_gain")
            local textName  = imageAward:getChildByName("Text_gain_name")
                   
            local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, item.nID)
            clippingPanel:setClippingEnabled(clipping)
            clippingIcon:setClippingEnabled(clipping)

            local scale     = scaleRatio * 1.2 
            local awardName = KUtil.getItemName(item.nType, item.nID)
            imageGain:loadTexture(filePath)
            imageGain:setScale(scale)
            textName:setString(awardName)
            textGain:setString(tostring(item.nNum))
        else
            imageAward:setVisible(false)
        end
    end
end

function KUIPassMapRewardNode:onEnterActionFinished()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_passmap_reward")
    local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_passmap_reward.csb")
    projectNodeTransAction:stopAllActions()
    projectNodeTransAction:runAction(actionNormalFire)
    local startFrame = 60
    local endFrame   = 420
    actionNormalFire:gotoFrameAndPlay(startFrame, endFrame, true)

    local itemCount = #self._resultList
    local showCount = MAX_ITEM_COUNT
    if itemCount > showCount then
        local projectNode     = mainNode:getChildByName("ProjectNode_passmap_reward")
        local panelMain       = projectNode:getChildByName("Panel_passmap_reward")
        local panelAward      = panelMain:getChildByName("Panel_award_gain")
        local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")
        scrollViewGain:setTouchEnabled(true)

        local unitPerTime   = 0.8
        local duration      = (itemCount - showCount) * unitPerTime
        local scrollPercent = 100
        scrollViewGain:scrollToPercentHorizontal(scrollPercent, duration, false)
    end
end

function KUIPassMapRewardNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_passmap_reward")
    projectNodeTransAction:stopAllActions()
end

function KUIPassMapRewardNode:getEnterAction()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_passmap_reward")

    local function callEnterAction()
        local startFrame = 0
        local endedFrame = 60
        local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_passmap_reward.csb")
        projectNodeTransAction:runAction(actionNormalFire)
        actionNormalFire:gotoFrameAndPlay(startFrame, endedFrame, false)
    end

    local function playEffect()
        KSound.playEffect("gainReward")
    end
    delayExecute(mainNode, playEffect, 0.2)

    local callAction   = cc.CallFunc:create(callEnterAction)
    local actionDelay1 = cc.DelayTime:create(0.2)
    local callEffect   = cc.CallFunc:create(playEffect)
    local actionDelay2 = cc.DelayTime:create(0.8)
    local enterAction  = cc.Sequence:create(callAction, actionDelay1, callEffect, actionDelay2)
    return enterAction, 1.0
end

function KUIPassMapRewardNode:getExitAction()
    return nil, 0
end

function KUIPassMapRewardNode:refreshUI()
    refeshReward(self)
end

function KUIPassMapRewardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_passmap_reward")
    --Confirm Button
    local panelMain   = projectNode:getChildByName("Panel_passmap_reward")
    local buttonControl = panelMain:getChildByName("Button_confirm_button")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("click")
            local callback = self._callback  
            local cbParam  = self._callbackParam
            self._parent:removeNode("PassMapReward")
            if callback then
                if cbParam then
                    callback(unpack(cbParam, 1, table.maxn(cbParam)))
                else
                    callback()
                end
            end
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUIPassMapRewardNode:registerAllCustomEvent()
end

function KUIPassMapRewardNode:setCallback(callback, callbackParam)
    self._callback      = callback
    self._callbackParam = callbackParam
end

return KUIPassMapRewardNode
