--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIPlunderDetailNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/29   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIPlunderDetailNode = class(
    "KUIPlunderDetailNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIPlunderDetailNode:ctor()
    self._mainLayout   = nil
    self._parent       = nil
    self._uiPath       = nil
    self._battleData   = nil
    self._teamIndex    = 1
end

function KUIPlunderDetailNode.create(owner, userData)
    local currentNode = KUIPlunderDetailNode.new()

    currentNode._parent       = owner
    currentNode._uiPath       = "res/ui/layout_expedition_preparation.csb"
    currentNode._battleData   = userData.dataInfo
    currentNode:init()

    return currentNode
end

local function enterPreparePanel(self)
    local battleData = self._battleData

    local userData = 
    {
        battleType = BATTLE_TYPE.EXPEDITION,
        battleData = battleData,
    }
    
    local battleScene = require("src/ui/battle/KUIBattleScene").create(userData, "Plunder")
    KUtil.replaceSceneAndRemoveAllTexture(battleScene)
end

local function refreshLeftTeamPanel(self)
    local mainNode      =  self._mainLayout
    local panelLeft     = mainNode:getChildByName("Image_bg_ally_base")

    local textPlayName  = panelLeft:getChildByName("Text_player_name")
    local ourTeamName   = KUtil.getStringByKey("exercise.ourTeam")
    textPlayName:setString(ourTeamName)

    local textTeamName = panelLeft:getChildByName("Text_team_name")
    local teamName     = KUtil.getTeamName(self._teamIndex)
    textTeamName:setString(teamName)

    local textRoleLevel = panelLeft:getChildByName("Text_player_level")
    textRoleLevel:setString(KPlayer.level)

    local cardList = KUtil.getOneTeamCardList(self._teamIndex)
    for cardIndex = 1, MAX_TEAM_CARD_COUNT do
        local panelUnit   = panelLeft:getChildByName("Node_army_unit_" .. cardIndex)
        local card        = cardList[cardIndex] or {}
        local nTemplateID = card.nTemplateID or 0
        local cardConfig  = KConfig.cardInfo[nTemplateID]

        if cardConfig then
            panelUnit:setVisible(true) 
            local imageHead = panelUnit:getChildByName("ProjectNode_card")
            KUtil.onlyUpdateCardHeadBase(imageHead, card)

            local textCardLevel = panelUnit:getChildByName("Text_level_data")
            textCardLevel:setString(card.nLevel)

            local textTankName = panelUnit:getChildByName("Text_tank_name")
            textTankName:setString(cardConfig.szName)

            local imageOil        = panelUnit:getChildByName("Image_oil_warning")
            local maxCarryOil     = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
            imageOil:setVisible(maxCarryOil > card.nCurrentOil)

            local imageAmmo       = panelUnit:getChildByName("Image_ammo_warning")
            local maxCarryAmmo    = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
            imageAmmo:setVisible(maxCarryAmmo > card.nCurrentAmmo)

            local panelDamage     = panelUnit:getChildByName("Panel_common_damage")
            local imageRepairing  = panelDamage:getChildByName("Image_common_repairing")
            local isCardRepair    = KUtil.isCardRepair(card.nID)
            imageRepairing:setVisible(isCardRepair)

            local maxHp           = KUtil.getCardMaxHp(card)
            local currentHP       = card.nCurrentHP
            local cardHPPercent   = currentHP / maxHp * 100
         
            local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
            KUtil.drawCardState(nil, panelDamage, {}, stateName, cardHPPercent)
        else
            panelUnit:setVisible(false) 
        end
    end

    local panelVS      = mainNode:getChildByName("Image_vs_base")
    local textRoleName = panelVS:getChildByName("Text_vs_name_1")
    textRoleName:setString(KPlayer.name)
end

local function refreshRightTeamPanel(self)
    local mainNode   = self._mainLayout
    local panelRight = mainNode:getChildByName("Image_bg_enemy_base")
    local roleDetail = self._battleData
    if not roleDetail then panelRight:setVisible(false) return end

    local teamData = roleDetail.tOne.teamdata
    local textPlayName = panelRight:getChildByName("Text_enemy_name")
    local ourTeamName  = KUtil.getStringByKey("exercise.enemyTeam")
    textPlayName:setString(ourTeamName)

    local textTeamName     = panelRight:getChildByName("Text_enemy_team_name")
    local expeditionTeamName = teamData.tOneTeam.szName
    local teamName = KUtil.getStringByKey("common.team") .. teamData.tOneTeam.nIndex
    if expeditionTeamName and string.len(expeditionTeamName) > 0 then 
        teamName = expeditionTeamName
    end
    textTeamName:setString(teamName)

    local textRoleLevel = panelRight:getChildByName("Text_enemy_level")
    textRoleLevel:setString(roleDetail.tOne.level)

    local cardIDList = teamData.tOneTeam.tCardIDList
    local cardList   = teamData.tCardList
    for cardIndex = 1, MAX_TEAM_CARD_COUNT do
        local panelUnit   = panelRight:getChildByName("Node_enemy_unit_" .. cardIndex)
        local cardID      = cardIDList[cardIndex] or 0
        local cardData    = HArray.FindFirstByID(cardList, cardID) or {}
        local nTemplateID = cardData.nTemplateID or 0
        local cardConfig  = KConfig.cardInfo[nTemplateID]

        if cardConfig then
            panelUnit:setVisible(true) 
            local imageHead = panelUnit:getChildByName("ProjectNode_card")
            local maxHP     = KUtil.getCardMaxHp(cardData)
            local card      = {["nTemplateID"] = cardData.nTemplateID, ["nSkinTemplateID"] = cardData.nSkinTemplateID,
                                ["nCurrentHP"] = maxHP, ["bRing"] = cardData.bRing, ["nMaxHP"] = maxHP}
            KUtil.onlyUpdatePlayerCardHeadBase(imageHead, card)

            local textCardLevel = panelUnit:getChildByName("Text_level_data")
            textCardLevel:setString(cardData.nLevel)

            local textTankName = panelUnit:getChildByName("Text_tank_name")
            textTankName:setString(cardConfig.szName)
        else
            panelUnit:setVisible(false) 
        end
    end

    local panelVS      = mainNode:getChildByName("Image_vs_base")
    local textRoleName = panelVS:getChildByName("Text_vs_name_2")
    textRoleName:setString(roleDetail.szName)
end

local function refreshMiddleResource(self)
    local mainNode      = self._mainLayout
    local panelMiddle   = mainNode:getChildByName("Image_frequency_base")
    local tResourceType = {CURRENCY_TYPE.OIL, CURRENCY_TYPE.AMMO, CURRENCY_TYPE.STEEL, CURRENCY_TYPE.PEOPLE}
    local roleDetail    = self._battleData
    for nameIndex, resourceIndex in ipairs(tResourceType) do
        local panelResource = panelMiddle:getChildByName("Panel_icon_digital_" .. nameIndex)

        local textResource = panelResource:getChildByName("BitmapFontLabel_digital")
        local resourceNum = roleDetail.tResource[resourceIndex] or 0
        textResource:setString(tostring(resourceNum))

        local imageResource = panelResource:getChildByName("Image_icon")
        local itemPath = KUtil.getRewardItemPathAndScale(ITEM_TYPE.CURRENCY, resourceIndex)
        imageResource:loadTexture(itemPath)
    end
end

function KUIPlunderDetailNode:refreshUI()
    refreshLeftTeamPanel(self)
    refreshRightTeamPanel(self)
    refreshMiddleResource(self)
end

function KUIPlunderDetailNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local buttonControl = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("PlunderDetail")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local buttonStart = mainNode:getChildByName("Button_war")
    local function onStartClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onStartClick~")
            KSound.playEffect("click")
            local cardList = KUtil.getOneTeamCardList(self._teamIndex)
            if #cardList == 0 then
                showNoticeByID("common.empty_team")
                return
            end
            
            local isRepairCard = nil
            for key, card in ipairs(cardList) do
                if KUtil.isCardInRepairList(card.nID) then
                    isRepairCard = card 
                    break  
                end
            end
            if isRepairCard then
                local cardName = KConfig["cardInfo"][isRepairCard.nTemplateID]["szName"]
                showNoticeByID("repairecard.repairing", cardName)
                return
            end
            
            local isTeamExpedition = KUtil.isTeamInExpedition(self._teamIndex)
            if isTeamExpedition then
                showNoticeByID("common.team_in_expedition")
                return
            end

            local leftNumber = KPlayer.tPlunderData.nLeftTimes or 0
            if leftNumber <= 0 then
                showNoticeByID("expedition.timesLimit")
                return
            end

            if self._battleData.bBattle then
                showNoticeByID("expedition.fightOnce")
                return
            end
            
            enterPreparePanel(self)
        end
    end
    buttonStart:addTouchEventListener(onStartClick)

    local buttonSupply = mainNode:getChildByName("Button_quick_supply")
    local function onSupplyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSupplyClick~")
            KSound.playEffect("click")
            KUtil.supplyTeamCard(self._teamIndex)
        end
    end
    buttonSupply:addTouchEventListener(onSupplyClick)

    local buttonTeam = mainNode:getChildByName("Button_contingent_adjustment")
    local function onTeamClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onTeamClick~")
            KSound.playEffect("click")
            local userData = {teamID = self._teamIndex}
            self._parent:addNode("Team", userData)
        end
    end
    buttonTeam:addTouchEventListener(onTeamClick)
end

function KUIPlunderDetailNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRefreshLeftPanel()
        cclog("onEvent ------------> KUIPlunderDetailNode onRefreshLeftPanel")
        refreshLeftTeamPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onRefreshLeftPanel)

    local function onSupplyTeamFinish()
        showNoticeByID("supply.teamSuccess")
        refreshLeftTeamPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish)
end

return KUIPlunderDetailNode
