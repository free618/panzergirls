--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIPlunderRewardNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/07   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_ITEM_COUNT = 4
local KUIPlunderRewardNode = class(
    "KUIPlunderRewardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIPlunderRewardNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._resultList     = {}
    self._desciptionList = {}
    self._callback       = nil
    self._isCovered      = false
end

function KUIPlunderRewardNode.create(owner, userData)
    local currentNode = KUIPlunderRewardNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_war_reward.csb"
    currentNode._resultList     = userData.tResultList
    currentNode._desciptionList = userData.tDesciptionList
    currentNode:init()

    return currentNode
end

local function refeshReward(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")

    local funSort = function(item1, item2)
        return item1.nID < item2.nID
    end
    table.sort(self._resultList, funSort)
    local tResultList = self._resultList
    local itemCount   = #tResultList
    if itemCount > MAX_ITEM_COUNT then 
        itemCount = MAX_ITEM_COUNT 
    end
    
    local panelMain       = projectNode:getChildByName("Panel_mission_war")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")
    local panelScrollView = panelAward:getChildByName("ScrollView_gain")
    local panelAwardList  = panelAwardList1
    local viewCount       = 0 
    if itemCount % 2 == 0 then
        panelAwardList1:setVisible(false)
        panelAwardList  = panelAwardList2
        viewCount = MAX_ITEM_COUNT
    else
        panelAwardList2:setVisible(false)
        panelAwardList  = panelAwardList1
        viewCount = MAX_ITEM_COUNT - 1
    end
    panelScrollView:setVisible(false)

    for i = 1, viewCount do
        local imageAward = panelAwardList:getChildByName("Image_award_gain_"..i)
        if i <= itemCount then
            local item = tResultList[i]
            imageAward:setVisible(true)
            local clippingPanel = imageAward:getChildByName("Panel_furniture_icon")
            local clippingIcon = clippingPanel:getChildByName("Panel_icon")
            local imageGain    = clippingIcon:getChildByName("Image_icon")

            local textGain  = imageAward:getChildByName("Text_gain")
            local textName  = imageAward:getChildByName("Text_gain_name")
                   
            local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, item.nID)
            clippingPanel:setClippingEnabled(clipping)
            clippingIcon:setClippingEnabled(clipping)

            local scale     = scaleRatio * 1.2 
            local awardName = KUtil.getItemName(item.nType, item.nID)
            imageGain:loadTexture(filePath)
            imageGain:setScale(scale)
            textName:setString(awardName)
            textGain:setString(tostring(item.nNum))
        else
            imageAward:setVisible(false)
        end
    end

    local textInformation = panelMain:getChildByName("Text_information")
    local positionX = textInformation:getPositionX()
    local positionY = textInformation:getPositionY()
    local contentSize = textInformation:getContentSize()
    textInformation:setVisible(false)
    
    local textName = panelMain:getChildByName("Text_name")
    textName:setVisible(false)


    local richText = ccui.RichText:create()
    richText:setContentSize(contentSize.width, contentSize.height * 2)
    richText:setPosition(positionX, positionY - 100)
    
    KUtil.setRichItemList(richText, self._desciptionList, 25)
    panelMain:addChild(richText, 10)

    richText:setScaleY(0.01)
    richText:runAction(cc.ScaleTo:create(0.5, 1, 1))
    richText:runAction(cc.MoveTo:create(0.5 , cc.p(positionX, positionY)))
end

function KUIPlunderRewardNode:onEnterActionFinished()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_war.csb")
    projectNodeTransAction:stopAllActions()
    projectNodeTransAction:runAction(actionNormalFire)
    local startFrame = 60
    local endFrame   = 420
    actionNormalFire:gotoFrameAndPlay(startFrame, endFrame, true)

    local itemCount = #self._resultList
    local showCount = MAX_ITEM_COUNT
    if itemCount > showCount then
        local projectNode     = mainNode:getChildByName("ProjectNode_mission")
        local panelMain       = projectNode:getChildByName("Panel_mission_war")
        local panelAward      = panelMain:getChildByName("Panel_award_gain")
        local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")
        scrollViewGain:setTouchEnabled(true)

        local unitPerTime   = 0.8
        local duration      = (itemCount - showCount) * unitPerTime
        local scrollPercent = 100
        scrollViewGain:scrollToPercentHorizontal(scrollPercent, duration, false)
    end
end

function KUIPlunderRewardNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    projectNodeTransAction:stopAllActions()
end

function KUIPlunderRewardNode:getEnterAction()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")

    local function callEnterAction()
        local startFrame = 0
        local endedFrame = 60
        local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_war.csb")
        projectNodeTransAction:runAction(actionNormalFire)
        actionNormalFire:gotoFrameAndPlay(startFrame, endedFrame, false)
    end

    local function playEffect()
        KSound.playEffect("gainReward")
    end
    delayExecute(mainNode, playEffect, 0.2)

    local callAction   = cc.CallFunc:create(callEnterAction)
    local actionDelay1 = cc.DelayTime:create(0.2)
    local callEffect   = cc.CallFunc:create(playEffect)
    local actionDelay2 = cc.DelayTime:create(0.8)
    local enterAction  = cc.Sequence:create(callAction, actionDelay1, callEffect, actionDelay2)
    return enterAction, 1.0
end

function KUIPlunderRewardNode:getExitAction()
    return nil, 0
end

function KUIPlunderRewardNode:refreshUI()
    refeshReward(self)
end

function KUIPlunderRewardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")
    --Confirm Button
    local panelMain     = projectNode:getChildByName("Panel_mission_war")
    local buttonControl = panelMain:getChildByName("Button_confirm_button")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("click")
            local callback = self._callback  
            local cbParam  = self._callbackParam
            self._parent:removeNode("PlunderReward")
            if callback then
                if cbParam then
                    callback(unpack(cbParam, 1, table.maxn(cbParam)))
                else
                    callback()
                end
            end
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUIPlunderRewardNode:registerAllCustomEvent()
end

function KUIPlunderRewardNode:setCallback(callback, callbackParam)
    self._callback      = callback
    self._callbackParam = callbackParam
end

return KUIPlunderRewardNode
