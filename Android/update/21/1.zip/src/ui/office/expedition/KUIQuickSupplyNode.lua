--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIQuickSupplyNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/13   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local FULL_SUPPLY_PERCENT_FRAME = 45
local OIL_ACTION_START_FRAME    = 0
local OIL_ACTION_END_FRAME      = 70
local AMMO_ACTION_START_FRAME   = 0
local AMMO_ACTION_END_FRAME     = 70

local KUIQuickSupplyNode = class(
    "KUIQuickSupplyNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIQuickSupplyNode:ctor()
    self._mainLayout  = nil
    self._parent      = nil
    self._uiPath      = nil
    self._teamID      = 0
    self._cardList    = {}
end

function KUIQuickSupplyNode.create(owner, userData)
    local currentNode = KUIQuickSupplyNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_quick_recharge.csb"
    currentNode._teamID = userData.nTeamID
    currentNode:init()

    return currentNode
end

local function canSupplyCard(cardID)
    if not cardID then return false end
    local card = KUtil.getCardById(cardID)
    if not card then return false end
    local cardConfig = KConfig.cardInfo[card.nTemplateID]
    local carryOil   = cardConfig.nCarryOil
    local carryAmmo  = cardConfig.nCarryAmmo
    local oil, ammo  = KPlayer.oil, KPlayer.ammo
    if card.nCurrentOil >= carryOil and card.nCurrentAmmo >= carryAmmo then 
        return false
    end
    if carryOil - card.nCurrentOil <= oil and carryAmmo - card.nCurrentAmmo <= ammo then
        return true
    end
    return false
end

local function checkSupplyAllCard(self)
    local nNeedOil, nNeedAmmo = 0, 0
    local fullSize = 0
    for i, card in ipairs(self._cardList) do
        local cardConfig = KConfig.cardInfo[card.nTemplateID]
        local carryOil   = cardConfig.nCarryOil
        local carryAmmo  = cardConfig.nCarryAmmo
        if card.nCurrentOil >= carryOil and card.nCurrentAmmo >= carryAmmo then 
            fullSize = fullSize + 1
        end
        nNeedOil  = nNeedOil + carryOil - card.nCurrentOil
        nNeedAmmo = nNeedAmmo + carryAmmo - card.nCurrentAmmo
    end
    if #self._cardList == 0 then
        showNoticeByID("expedition.teamEmpty")
        return false
    end
    if fullSize == #self._cardList then
        showNoticeByID("expedition.supplyFull")
        return false
    end
    local oil, ammo  = KPlayer.oil, KPlayer.ammo
    if nNeedOil > oil or nNeedAmmo > ammo then
        showNoticeByID("expedition.notEnough")
        return false
    end
    return true
end

local function getCardPosition(self, cardID)
    for index, card in ipairs(self._cardList) do
        if card.nID == cardID then
            return index
        end
    end
    return 0
end

local function playSupplyAnimation(self)
    local mainNode        = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_recharge")

    for index, card in ipairs(self._cardList) do
        local unitNodeName = "Panel_echarg_unit_" .. index
        local unitNode     = imageBase:getChildByName(unitNodeName)
        --Play Oil Supply Animation
        local nodeProjectOil        = imageCommon:getChildByName("ProjectNode_supply_1")
        local oilAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_oil_drop.csb")
        assert(oilAnimationAction  ~= nil, "Get oilAnimationAction Failed~")

        nodeProjectOil:stopAllActions()
        nodeProjectOil:runAction(oilAnimationAction)
        oilAnimationAction:gotoFrameAndPlay(OIL_ACTION_START_FRAME, OIL_ACTION_END_FRAME, false)

        --Play Ammo Supply Animation
        local nodeProjectAmmo       = imageCommon:getChildByName("ProjectNode_supply_2")
        local ammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_ammo_drop.csb")
        assert(ammoAnimationAction ~= nil, "Get ammoAnimationAction Failed~")
       
        nodeProjectAmmo:stopAllActions()
        nodeProjectAmmo:runAction(ammoAnimationAction)
        ammoAnimationAction:gotoFrameAndPlay(AMMO_ACTION_START_FRAME,  AMMO_ACTION_END_FRAME, false)
    end
end

local function hideAllUnitNode(self)
    local mainNode          = self._mainLayout
    local imageSupplyBase   = mainNode:getChildByName("Image_recharge")
    for k = 1, MAX_TEAM_CARD_COUNT do
        local nodeName = "Panel_echarg_unit_" .. k
        imageSupplyBase:getChildByName(nodeName):setVisible(false)
    end
end

local function updateCardUnit(self, unitNode, card)
    if not card then
        unitNode:setVisible(false)
        return
    end
    unitNode:setVisible(true)

    local cardConfig = KConfig.cardInfo[card.nTemplateID]
    local unitButtonControl = unitNode:getChildByName("Button_recharg_unit")
    local imageHead = unitButtonControl:getChildByName("Image_common_chara")
    KUtil.drawRoleHeadUi(imageHead,card)

    -- update card name
    local textTankName  = unitNode:getChildByName("Text_qb_tank_name")
    textTankName:setString(cardConfig.szName)
    -- update oil and ammo animation
    local currentOil            = card.nCurrentOil 
    local currentAmmo           = card.nCurrentAmmo 
    local cardMaxCarryOil       = cardConfig.nCarryOil
    local cardMaxCarryAmmo      = cardConfig.nCarryAmmo
    local oilPercent            = math.floor(currentOil / cardMaxCarryOil * FULL_SUPPLY_PERCENT_FRAME)
    local ammoPercent           = math.floor(currentAmmo / cardMaxCarryAmmo * FULL_SUPPLY_PERCENT_FRAME)
    local projectNodeOil        = unitNode:getChildByName("ProjectNode_supply_1")
    local projectNodeAmmo       = unitNode:getChildByName("ProjectNode_supply_2")

    local oilAnimationAction    = cc.CSLoader:createTimeline("ui/animation_node/ani_supply_value.csb")
    assert(oilAnimationAction  ~= nil, "Get oilAnimationAction Failed~")
    local ammoAnimationAction   = cc.CSLoader:createTimeline("ui/animation_node/ani_supply_value.csb")
    assert(ammoAnimationAction ~= nil, "Get ammoAnimationAction Failed~")

    projectNodeOil:stopAllActions()
    projectNodeOil:runAction(oilAnimationAction)
    oilAnimationAction:gotoFrameAndPlay(0, oilPercent, false)

    projectNodeAmmo:stopAllActions()
    projectNodeAmmo:runAction(ammoAnimationAction)
    ammoAnimationAction:gotoFrameAndPlay(0, ammoPercent, false)
end

local function refreshAllNeedMaterial(self)
    local nNeedOil, nNeedAmmo = 0, 0
    for i, card in ipairs(self._cardList) do
        local cardConfig = KConfig.cardInfo[card.nTemplateID]
        local carryOil   = cardConfig.nCarryOil
        local carryAmmo  = cardConfig.nCarryAmmo
        nNeedOil  = nNeedOil + carryOil - card.nCurrentOil
        nNeedAmmo = nNeedAmmo + carryAmmo - card.nCurrentAmmo
    end
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_recharge")
    local textSupplyOil     = imageBase:getChildByName("Text_supply_oil_value")
    local textSupplyAmmo    = imageBase:getChildByName("Text_supply_ammo_value")
    textSupplyOil:setString(tostring(nNeedOil))
    textSupplyAmmo:setString(tostring(nNeedAmmo))
end

local function refreshCardArea(self)
    local mainNode  = self._mainLayout
    local imageBase = mainNode:getChildByName("Image_recharge")
    self._cardList  = KUtil.getOneTeamCardList(self._teamID)
    -- Max Card Count Of A Team Is 6
    for i, card in ipairs(self._cardList) do
        local unitNodeName = "Panel_echarg_unit_" .. i
        local unitNode     = imageBase:getChildByName(unitNodeName)
        unitNode:setVisible(true)
        updateCardUnit(self, unitNode, card)
        local nCardID = card.nID
        local function onUnitClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                if canSupplyCard(nCardID) then 
                    cclog("supplyCard(nCardID = %d)", nCardID)
                    require("src/network/KC2SProtocolManager"):supplyCard(nCardID)
                else
                    cclog("can not supplyCard(nCardID = %d)", nCardID)
                end
            end
        end    
        unitNode:getChildByName("Button_recharg_unit"):addTouchEventListener(onUnitClick)
    end
end

function KUIQuickSupplyNode:runEnterAction()
    return 0.0
end

function KUIQuickSupplyNode:runExitAction()
    return 0.0
end

function KUIQuickSupplyNode:refreshUI()
    hideAllUnitNode(self)
    refreshCardArea(self)
    refreshAllNeedMaterial(self)
end

function KUIQuickSupplyNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local imageBase = mainNode:getChildByName("Image_recharge")
    --Confirm Button
    local buttonControl = imageBase:getChildByName("Button_close_button")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("QuickSupply")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    --SupplyAllButton
    local buttonControl = imageBase:getChildByName("Button_all_supply_button")
    local function onSupplyAllButton(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog ("click onSupplyAllButton~")
            if checkSupplyAllCard(self) then
                local currentTeamID = self._teamID
                require("src/network/KC2SProtocolManager"):supplyTeam(currentTeamID)
            end
        end 
    end
    buttonControl:addTouchEventListener(onSupplyAllButton)  
end

function KUIQuickSupplyNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    
    local function onSupplyTeamFinish()
        cclog("onEvent ------------> KUIQuickSupplyNode onSuppplyTeamFinish")
        self:refreshUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish) 
    
    local function onSupplyCardFinish(cardID)
        cclog("onEvent ------------> KUIQuickSupplyNode onSuppplyCardFinish %d",cardID)
        local card = KUtil.getCardById(cardID)
        if not card then return end
        if not self._teamID then return end
        local imageBase   = self._mainLayout:getChildByName("Image_recharge")
        local cardPosition = getCardPosition(self, cardID)
        local unitNodeName = "Panel_echarg_unit_" .. cardPosition
        local nodeUnit    = imageBase:getChildByName(unitNodeName)
        updateCardUnit(self, nodeUnit, card)
        refreshAllNeedMaterial(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_CARD_FINISH, onSupplyCardFinish) 
end

return KUIQuickSupplyNode
