--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBuildCardNode.lua
--  Creator     : SunXun
--  Date        : 2015/04/21   23:10
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local MIN_RESOURCE_COUNT        = 30
local MAX_NUMBER_COUNT          = 9
local MIN_NUMBER_COUNT          = 0
local MAX_PANEL_RESOURCES_COUNT = 4
local MAX_PANEL_BUTTON_COUNT    = 6
local MAX_PANEL_NUMBER_COUNT    = 3
local TOTAL_NUMBER_COUNT        = 10
local BUILDING_MATERIAL         = 1

local m_tDestResourceCount = 
{
    [1]   = {0, 3, 0},
    [2]   = {0, 3, 0},
    [3]   = {0, 3, 0},
    [4]   = {0, 3, 0}
}

local KUIBuildCardNode = class(
    "KUIBuildCardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBuildCardNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._index             = nil
end

function KUIBuildCardNode.create(owner, nIndex)
    local currentNode = KUIBuildCardNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_build.csb"

    if not nIndex then nIndex = 1 end
    currentNode._index  = nIndex
    currentNode:init()
    
    return currentNode
end

function KUIBuildCardNode:changeResourceByKind(resourceType, resourceIndex, shouldAdd)
    local resourceInfo = m_tDestResourceCount[resourceType]
    assert(resourceInfo ~= nil, "Get resourceInfo Failed~")

    local resourceValue = resourceInfo[resourceIndex]
    assert(resourceValue ~= nil, "Get resourceValue Failed~")

    if not shouldAdd then    -- cut down
        resourceValue = resourceValue - 1
        if resourceValue < MIN_NUMBER_COUNT then resourceValue = MAX_NUMBER_COUNT end
    else                -- add
        resourceValue = resourceValue + 1
        if resourceValue > MAX_NUMBER_COUNT then resourceValue = MIN_NUMBER_COUNT end
    end
    resourceInfo[resourceIndex] = resourceValue

    self:refreshUI()
end


local function refreshDisenableArea(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInnerBase    = imageBase:getChildByName("Image_jz_base")

    -- log button visible
    local buttonLog         = imageInnerBase:getChildByName("Button_log_button")
    buttonLog:setVisible(false)    
    buttonLog:setTouchEnabled(false)
end

local function refreshMainInterface(self)
    local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_common_base")
    local imageInnerBase= imageBase:getChildByName("Image_jz_base")

    local constructValue     = imageInnerBase:getChildByName("Text_construct_value")
    local buildMaterialValue = KUtil.getItemCount(BUILDING_MATERIAL)
    constructValue:setString(buildMaterialValue)
    local labelContantValue  = imageInnerBase:getChildByName("Text_contant_value")
    local allCardsCount      = KUtil.getCardCount()
    labelContantValue:setString("".. allCardsCount .. "/" .. KUtil.getCardStoreSize())
end

local function refreshResourceArea(self)
    local mainNode              = self._mainLayout
    local baseImage             = mainNode:getChildByName("Image_common_base")
    local imageInnerBase        = baseImage:getChildByName("Image_jz_base")
    local buttonStartBuilding   = imageInnerBase:getChildByName("Button_start_build")
    local resourceValueArray    = {}

    -- calc current resource value
    for k, v in pairs(m_tDestResourceCount) do
        local currentResourceValue = v[1] * 100 + v[2] * 10 + v[3]
        resourceValueArray[k] = currentResourceValue
    end

    -- refresh resource image to ui
    for panelResouceIndex = 1, MAX_PANEL_RESOURCES_COUNT do
        local panelResourceName     = "Panel_resources_" .. panelResouceIndex
        local panelResource         = imageInnerBase:getChildByName(panelResourceName)
        local panelNumber           = panelResource:getChildByName("Panel_number")
        for panelNumberIndex = 1, MAX_PANEL_NUMBER_COUNT do
            local panelSingleNumberName     = "Panel_number_" .. panelNumberIndex
            local panelSingleNumber         = panelNumber:getChildByName(panelSingleNumberName)
            local currentResourceValue      = m_tDestResourceCount[panelResouceIndex][panelNumberIndex]
            for numberIndex = 1, TOTAL_NUMBER_COUNT do
                local imageRealIndex    = numberIndex - 1
                local imageNumberName   = "Image_number_" .. imageRealIndex
                local imageNumber       = panelSingleNumber:getChildByName(imageNumberName)
                local imageVisible      = false
                if imageRealIndex == currentResourceValue then imageVisible = true end
                imageNumber:setVisible(imageVisible)
            end
        end
    end

    -- refresh startBuilding button
    local startBuildingButtonFlag = true
    for _, v in pairs(resourceValueArray) do
        if v < MIN_RESOURCE_COUNT then startBuildingButtonFlag = false end
    end

    local tButtonTexturePath = 
    {
        ["buttonNormalTexture"]     = "res/ui/ui_material/build/jz_start_button.png", 
        ["buttonPressTexture"]      = "res/ui/ui_material/build/jz_start_button_active.png", 
        ["buttonDisableTexture"]    = "res/ui/ui_material/build/jz_start_button_disable.png"
    }

    buttonStartBuilding:setTouchEnabled(startBuildingButtonFlag)
    if not startBuildingButtonFlag then
        buttonStartBuilding:loadTextures(tButtonTexturePath.buttonDisableTexture, tButtonTexturePath.buttonDisableTexture, tButtonTexturePath.buttonDisableTexture)
    else
        buttonStartBuilding:loadTextures(tButtonTexturePath.buttonNormalTexture, tButtonTexturePath.buttonPressTexture, tButtonTexturePath.buttonDisableTexture)
    end
end

function KUIBuildCardNode:beganBuild()
    local isSuccess = true
    local consumeNum = {}
    for i = 1, MAX_PANEL_RESOURCES_COUNT do
        consumeNum[i] = m_tDestResourceCount[i][1] * 100 + m_tDestResourceCount[i][2] * 10 + m_tDestResourceCount[i][3]
        if consumeNum[i] > KPlayer[CURRENCY_KEY[i]] then
            isSuccess = false
            showNoticeByID("factory.lessResource", KUtil.getStringByKey("common."..CURRENCY_KEY[i]))
            break
        end
    end
    print("beganBuild:",KUtil.getItemConfigValue(BUILDING_MATERIAL, "szName"))
    if isSuccess and KUtil.getItemCount(BUILDING_MATERIAL) == 0 then
        isSuccess = false
        showNoticeByID("factory.lessResource", KUtil.getItemConfigValue(BUILDING_MATERIAL, "szName"))
    end
    
    local allCardsCount = KUtil.getCardCount()
    local cardStoreSize = KUtil.getCardStoreSize() 
    if isSuccess and allCardsCount >= cardStoreSize then
        isSuccess = false
        showNoticeByID("produce.CardStoreNotEnough")
    end
    
    if isSuccess and not KUtil.isEnoughEquipStore(1) then
        isSuccess = false
        showNoticeByID("produce.EquipStoreNotEnough")
    end
     
    if isSuccess then
        require("src/network/KC2SProtocolManager"):produceCard(self._index, consumeNum[1], consumeNum[2], consumeNum[3], consumeNum[4])
        cclog("-------------------->KUIBuildCardNode:beganBuild" )
    end
end

function KUIBuildCardNode:refreshUI()
    refreshDisenableArea(self)
    refreshMainInterface(self)
    refreshResourceArea(self)
end

function KUIBuildCardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Home Button
    local buttonControl = mainNode:getChildByName("Button_top")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")            
            self._parent:returnOffice()
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    local imageControl = mainNode:getChildByName("Image_common_base")

    --Close Button
    local buttonControl = imageControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("Build")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    imageControl = imageControl:getChildByName("Image_jz_base")

    --Log Button
    local buttonControl = imageControl:getChildByName("Button_log_button")
    local function onLogClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onLogButton~") 
            KSound.playEffect("click")           
        end
    end
    buttonControl:addTouchEventListener(onLogClick)

    --Start Build Button
    local buttonControl = imageControl:getChildByName("Button_start_build")
    local function onStartBuildClick(sender, type)
        if type == ccui.TouchEventType.ended and KUtil.getProducingCardCount() < KUtil.getBuildBarCount() then
            cclog("click onStartBuildButton~") 
            KSound.playEffect("click")           
            self:beganBuild()
        end
    end
    buttonControl:addTouchEventListener(onStartBuildClick)

    --Reset Button
    local buttonControl = imageControl:getChildByName("Button_reset")
    local function onResetClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            for k, v in pairs(m_tDestResourceCount) do 
                v[1] = 0
                v[2] = 3 
                v[3] = 0
            end   
            self:refreshUI()
            cclog("click onResetButton~")            
        end
    end
    buttonControl:addTouchEventListener(onResetClick)

    for panelResourcesID = 1, MAX_PANEL_RESOURCES_COUNT do
        local panelResourcesName    = "Panel_resources_" .. panelResourcesID
        local panelResource         = imageControl:getChildByName(panelResourcesName)
        for panelButtonID = 1, MAX_PANEL_BUTTON_COUNT do
            local panelButton       = panelResource:getChildByName("Panel_button")    
            local panelButtonName   = "Button_" .. panelButtonID
            local buttonControl     = panelButton:getChildByName(panelButtonName) 
            local function onButtonClick(sender, type)
                if type == ccui.TouchEventType.ended then
                    KSound.playEffect("click")
                    local resourceIndex = panelButtonID
                    local shouldAdd = true
                    if resourceIndex > MAX_PANEL_NUMBER_COUNT then
                        resourceIndex = resourceIndex - MAX_PANEL_NUMBER_COUNT
                        shouldAdd = false
                    end
                    self:changeResourceByKind(panelResourcesID, resourceIndex, shouldAdd)
                end
            end
            buttonControl:addTouchEventListener(onButtonClick)
        end
    end
end

function KUIBuildCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onbeganBuild()
        cclog("onEvent ------------> onUninstallWeaponsFinish")
        self._parent:removeNode("Build")

    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_BEGAN_BUILD, onbeganBuild)
end

return KUIBuildCardNode
