--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryAwardEquipNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/8/3  19:52
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  *********************************************************************


local GEAR_MAX_LEVEL  = 6
local ATTRIBUTE_COUNT = 13

local m_szEquipSpecsName = {
    [ATTRIBUTE.HP]          = "耐久",
    [ATTRIBUTE.ATTACK]      = "火力",
    [ATTRIBUTE.PENETRATE]   = "穿透",
    [ATTRIBUTE.SPEED]       = "速度",
    [ATTRIBUTE.FRONTARMOUR] = "前甲",
    [ATTRIBUTE.REARARMOUR]  = "后甲",
    [ATTRIBUTE.SCOUT]       = "侦查",
    [ATTRIBUTE.DODGE]       = "回避",
    [ATTRIBUTE.HIDE]        = "隐藏",
    [ATTRIBUTE.NIGHTBATTLE] = "夜战",
    [ATTRIBUTE.RANGE]       = "射程",
    [ATTRIBUTE.ACCURACY]    = "命中",
    [ATTRIBUTE.CRIT]        = "暴击",
}

local equipTypeName = "武器类型"
local m_szEquipType ={"主武器", "副武器"}

local KUIFactoryAwardEquipNode = class(
    "KUIFactoryAwardEquipNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryAwardEquipNode:ctor()
    self._parent        = nil
    self._mainLayout    = nil
    self._uiPath        = nil
    self._eventList     = {}
    self._equipID       = nil
end

function KUIFactoryAwardEquipNode.create(owner)
    local currentNode = KUIFactoryAwardEquipNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/award_gear.csb"
    currentNode:init()

    return currentNode
end

local function refreshAnimation(self)
    if not self._equipID then
        return
    end
    
    local mainNode                      = self._mainLayout
    local projectNodeTrans              = mainNode:getChildByName("ProjectNode_trans")
    local animationStartFrame           = 0
    local transActionAnimationEndFrame  = 117
    local actionProjectNodeTrans        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_award_trans.csb")
    projectNodeTrans:stopAllActions()
    projectNodeTrans:runAction(actionProjectNodeTrans)
    actionProjectNodeTrans:gotoFrameAndPlay(animationStartFrame, transActionAnimationEndFrame, false)

    local projectNodeCardLight              = mainNode:getChildByName("ProjectNode_cradlight")
    local actionProjectNodeCardLight        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_gear_cardlight.csb")
    local cardLightActionAnimationEndFrame  = 72
    projectNodeCardLight:stopAllActions()
    projectNodeCardLight:runAction(actionProjectNodeCardLight)
    actionProjectNodeCardLight:gotoFrameAndPlay(animationStartFrame, cardLightActionAnimationEndFrame, false)

    local projectNodeGear       = mainNode:getChildByName("ProjectNode_gear")
    local equipID               = self._equipID  
    
    local equipName             = KUtil.getEquipNameByID(equipID)
    local textGearName          = projectNodeGear:getChildByName("Text_gear_name")
    textGearName:setString(equipName) 
    
    local imageGear             = projectNodeGear:getChildByName("Image_gear")
    imageGear:loadTexture(KUtil.getEquipImagePathByID(equipID), ccui.TextureResType.localType)
    
    local panelGear         = mainNode:getChildByName("ProjectNode_gear")
    local panelGearBase     = panelGear:getChildByName("Panel_gear_base")
    local panelCardMeda     = panelGear:getChildByName("Panel_card_meda")
    for num = 1, GEAR_MAX_LEVEL do 
        local imageName       = "Image_gear_base_" .. num
        local imageBackground = panelGearBase:getChildByName(imageName)
        imageBackground:setVisible(false)
        
        imageName        = "card_medal_" .. num
        local imageMedal = panelCardMeda:getChildByName(imageName)
        imageMedal:setVisible(false)
    end
    
    local equipGrade = KUtil.getEquipGradeByID(equipID)
    local backgroundImageVisibleName = "Image_gear_base_" .. equipGrade
    local imageBackground            = panelGearBase:getChildByName(backgroundImageVisibleName)
    imageBackground:setVisible(true)

    backgroundImageVisibleName = "card_medal_" .. equipGrade
    local imageMedal           = panelCardMeda:getChildByName(backgroundImageVisibleName)
    imageMedal:setVisible(true)

    for starCount = 1, GEAR_MAX_LEVEL do -- max star is 6 
        local starVisible       = false
        local panelStar         = panelGear:getChildByName("Panel_stars")
        local starImageControl  = panelStar:getChildByName("Image_star_" .. starCount)
        if starCount <= tonumber(equipGrade) then starVisible = true end
        starImageControl:setVisible(starVisible)
    end
    
    local equipType   = KUtil.getEquipTypeByID(equipID)
    local tableString = {}
    tableString[#tableString + 1] = equipTypeName .. ": " .. m_szEquipType[equipType] .. "\n"

    local equipSpecs =  KUtil.getEquipAttributeByID(equipID)
    
    for k,v in ipairs(equipSpecs) do
        if k == 1 then cclog("ignore duration!") -- ignore duration( ATTRIBUTE.HP )
        elseif v > 0 then
            tableString[#tableString + 1] = m_szEquipSpecsName[k] .. "+" .. v .. "  "
        end 
    end
    local imageDialog = mainNode:getChildByName("Image_jl_dialog")
    local textDialog  = imageDialog:getChildByName("Text_dialog")
    tableString = table.concat(tableString) .. "\n" .. KUtil.getExtDescription(equipID)
    textDialog:setString(tableString)
end

function KUIFactoryAwardEquipNode:setWeaponInformation(equipID)
    cclog("-------------------->KUIFactoryAwardEquipNode:setWeaponInformation: equipID:%d", equipID)
    self._equipID = equipID
    
    refreshAnimation(self)
end

function KUIFactoryAwardEquipNode:refreshUI()
    refreshAnimation(self)
end

function KUIFactoryAwardEquipNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local buttonScreen  = mainNode:getChildByName("Button_screen")
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")
            self._parent:removeNode("AwardEquip")
            self._parent:removeNode("Develop")
            cclog("onScreenClick~")
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)
end

return KUIFactoryAwardEquipNode
