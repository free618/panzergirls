--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryBreakCardNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/04   14:40
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************

local REMOVE_UNIT_FRAME = 27
local m_KeyList         = {"nRecycleOil", "nRecycleAmmo", "nRecycleSteel", "nRecyclePeople"}
local m_LabelName       = {"Text_oil_data", "Text_ammo_data", "Text_steel_data", "Text_spammo_data"} 
local m_BouttonTexture  = 
{
    ["normal"]   = "res/ui/ui_material/public/jt_xxzb_button.png", 
    ["press"]    = "res/ui/ui_material/public/jt_xxzb_button_active.png", 
    ["disable"]  = "res/ui/ui_material/public/jt_xxzb_button.png",
}

local KUIFactoryBreakCardNode = class("KUIFactoryBreakCardNode")

function KUIFactoryBreakCardNode:ctor(owner, node)
    self._mainLayout            = node
    self._parent                = owner
    self._baseCardBar           = nil
    self._cardIDList            = {}
    self._isUnloadingEquipment  = false
    self._animationList         = {}
    self._isBreak               = false
    self:initData()
    self:refreshUI()
end

local function removeBar(self, nID)
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_break_right") 
    local imageBase      = panelRight:getChildByName("Image_abandon_base2")
    local scrollView     = panelRight:getChildByName("Scrollview_break_list")
    local nIndex = KUtil.getBarIndexFromScrollViewByID(scrollView, nID)
    KUtil.removeBarFromScrollView(scrollView, nIndex)

    local buttonBreak    = imageBase:getChildByName("Button_start_break")
    KUtil.setTouchEnabledAndDisable(buttonBreak, #self._cardIDList > 0)
end

local function initCardBar(self, cardBar, card)
    local imageBase     = cardBar:getChildByName("Image_jt_unit_base")
    imageBase:setVisible(true)
    local buttonAdd     = cardBar:getChildByName("Button_add_button")
    buttonAdd:setVisible(false)
    
    local imageHead     = imageBase:getChildByName("ImageProject_card")
    for _, node in ipairs(imageBase:getChildren()) do
        print(node:getName())
    end
    assert(imageHead)
    KUtil.updateCardHeadBase(imageHead, card)
    
    local maxExp        = KUtil.getCardMaxExp(card.nLevel)
    local barExpLoading = imageBase:getChildByName("LoadingBar_common_exp")
    barExpLoading:setPercent(card.nCurrentExp / maxExp * 100)
    
    local labelLevel    = imageBase:getChildByName("BitmapFontLabel_1")
    labelLevel:setString(card.nLevel)
    
    local cardConfig    = KUtil.getCardConfig(card.nTemplateID)
    local labelName     = imageBase:getChildByName("Text_tank_name")
    labelName:setString(cardConfig.szName)

    for i = 1, KUtil.MAX_STAR do
        local imageStar = imageBase:getChildByName("Image_common_star_"..i)
        imageStar:setVisible(i <= cardConfig.nQuality)
    end
    
    local buttonDelete  = imageBase:getChildByName("Button_jt_unit_unload")
    local function onDeleteClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._isBreak then return end
        if not HArray.FindFirstByValue(self._cardIDList, card.nID) then return end
        KSound.playEffect("click")
        -- local nIndex = HArray.FindFirstIndexByValue(self._cardIDList, card.nID)
        HArray.RemoveFirstByValue(self._cardIDList, card.nID)
        removeBar(self, card.nID)
        self:refreshResourcesNum()
        self:refreshStartButton()
    end
    buttonDelete:addTouchEventListener(onDeleteClick)
end

local function initEmptyBar(self, cardBar)
    local imageBase    = cardBar:getChildByName("Image_jt_unit_base")
    imageBase:setVisible(false)
    local buttonAdd    = cardBar:getChildByName("Button_add_button")
    buttonAdd:setVisible(true)
    
    --Add Button
    local function onAddClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._isBreak then return end
        KSound.playEffect("addMember")
        self._parent:addNode("CardChoose", KUtil.getCanConsumeCardList(), self._cardIDList)
    end
    buttonAdd:addTouchEventListener(onAddClick)
end

function KUIFactoryBreakCardNode:getCardBreakResources(card)
    local cardBreakConfig = KUtil.getCardBreakConfig(card.nTemplateID)
    assert(cardBreakConfig, card.nTemplateID)

    local resourcesList = {}
    for i = 1, #m_KeyList do
        resourcesList[i] = cardBreakConfig[m_KeyList[i]]
    end
    
    if not self._isUnloadingEquipment then
        for _, tEquip in ipairs(card.tEquipList) do
            local tOneEquip = KUtil.getEquipById(tEquip.nEquipID)
            assert(tOneEquip)
            if  not tOneEquip.bLock then
                local tEquipBreakDownConfig = KConfig.equipBreakDownInfo[tOneEquip.nTemplateID]
                assert(tEquipBreakDownConfig)
                for i = 1, #m_KeyList do
                    resourcesList[i] = resourcesList[i] + tEquipBreakDownConfig[m_KeyList[i]]
                end
            end
        end
    end
    return resourcesList
end

function KUIFactoryBreakCardNode:refreshStartButton()
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_break_right") 
    local imageBase      = panelRight:getChildByName("Image_abandon_base2")
    local buttonBreak    = imageBase:getChildByName("Button_start_break")
    KUtil.setTouchEnabledAndDisable(buttonBreak, #self._cardIDList > 0)
end

function KUIFactoryBreakCardNode:refreshScrollView(isCutIn)
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_break_right") 
    local imageBase      = panelRight:getChildByName("Image_abandon_base2")
    local scrollView     = panelRight:getChildByName("Scrollview_break_list")
    local slideControl   = panelRight:getChildByName("Slider_unit_list")

    local tCarList = {}
    for index, cardID in ipairs(self._cardIDList) do
        local card = KUtil.getCardById(cardID)
        if card ~= nil then
            table.insert(tCarList, card)
        end
    end
    table.insert(tCarList, {nID = 0})

    local function funInit(bar, card)
        if card.nID == 0 then
            initEmptyBar(self, bar)
            return true
        end
        initCardBar(self, bar, card)
        return true
    end  

    local tParam      = {
        scrollView    = scrollView,
        barBase       = self._baseCardBar,
        dataList      = tCarList,
        funInit       = funInit,
        oneBatchCount = 4,
        isCutIn       = isCutIn,
        slideControl  = slideControl}
    KUtil.batchAddScrollView(tParam)
    
    self:refreshStartButton()
end

function KUIFactoryBreakCardNode:refreshResourcesNum()
    local resourcesList = {}
    for index, cardID in ipairs(self._cardIDList) do
        local card = KUtil.getCardById(cardID)
        assert(card, cardID)
        resourcesList = HArray.numberAdd(resourcesList , self:getCardBreakResources(card))
    end
    
    for i, name in ipairs(m_LabelName) do
        local mainNode       = self._mainLayout
        local animationRight = mainNode:getChildByName("ProjectNode_left")
        local panelLeft      = animationRight:getChildByName("Panel_abandon_left") 
        local label          = panelLeft:getChildByName(name)
        label:setString(resourcesList[i] or "")
    end
end

local function refreshOther(self)
    local mainNode                 = self._mainLayout
    local animationRight           = mainNode:getChildByName("ProjectNode_right")
    local panelRight               = animationRight:getChildByName("Panel_break_right") 
    local imageBase                = panelRight:getChildByName("Image_abandon_base2")
    local buttonUnloadingEquipment = imageBase:getChildByName("Button_jt_xxzb_button")
    if self._isUnloadingEquipment then
        buttonUnloadingEquipment:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
    else
        buttonUnloadingEquipment:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
    end
end

function KUIFactoryBreakCardNode:initData()
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local nodeUnitBase   = animationRight:getChildByName("Node_unit")
    local imageCardBar   = nodeUnitBase:getChildByName("Image_jt_empty")
    self._baseCardBar    = imageCardBar

    local nodeBreakLeft         = self._mainLayout:getChildByName("ProjectNode_left")
    self._animationList.left    = KUtil.initAnimation(nodeBreakLeft, "res/ui/animation_node/ani_break_left.csb")
    local nodeBreakRight        = self._mainLayout:getChildByName("ProjectNode_right")
    self._animationList.right   = KUtil.initAnimation(nodeBreakRight, "res/ui/animation_node/ani_break_right.csb")
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    for _, animation in pairs(self._animationList) do
        KUtil.playEnterAnimation(animation)
    end
end

local function exitAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(false)

    local nDelayTime = 0
    for _, animation in pairs(self._animationList) do
        local nTime = KUtil.playQuitAnimation(animation)
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    return nDelayTime
end

function KUIFactoryBreakCardNode:enter()
    -- self:refreshStartButton()
    enterAnimation(self)
end

function KUIFactoryBreakCardNode:quit()
    return exitAnimation(self)
end

function KUIFactoryBreakCardNode:refreshUI()
    self:refreshScrollView(false)
    self:refreshResourcesNum()
    refreshOther(self)
end

function KUIFactoryBreakCardNode:registerAllTouchEvent()
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_break_right") 
    local imageBase      = panelRight:getChildByName("Image_abandon_base2")
    
    --Unloading equipment Button
    local buttonUnloadingEquipment = imageBase:getChildByName("Button_jt_xxzb_button")
    local function onUnloadingEquipmentClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            self._isUnloadingEquipment = not self._isUnloadingEquipment
            if self._isUnloadingEquipment then
                buttonUnloadingEquipment:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
            else
                buttonUnloadingEquipment:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
            end      
            self:refreshResourcesNum()
        end
    end
    buttonUnloadingEquipment:addTouchEventListener(onUnloadingEquipmentClick)
    
    --Start Break Button
    local buttonStart  = imageBase:getChildByName("Button_start_break")
    local function onStartBreakClick(sender, type)
        if type == ccui.TouchEventType.ended and #self._cardIDList>0 then
            self._isBreak = true
            KSound.playEffect("breakUp")
            require("src/network/KC2SProtocolManager"):breakDownCardList(self._cardIDList, self._isUnloadingEquipment)
            KUtil.setTouchEnabledAndDisable(buttonStart, false)
            cclog("click onStartBreakButton~")            
        end
    end
    buttonStart:addTouchEventListener(onStartBreakClick)

    local scrollView     = panelRight:getChildByName("Scrollview_break_list")
    local slideControl   = panelRight:getChildByName("Slider_unit_list")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollView:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollView)
        slideControl:setPercent(percent)
    end
    scrollView:addEventListener(onScrollChange)

end

function KUIFactoryBreakCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_break_right") 
    local imageBase      = panelRight:getChildByName("Image_abandon_base2")
    local scrollView     = panelRight:getChildByName("Scrollview_break_list")

    local function onCardBreak(cardIDList)
        cclog("onEvent ------------> onCardBreak")
        self._isBreak = false
        self._cardIDList = HArray.arraySub(self._cardIDList, cardIDList)

        local delayTime = KUtil.PlayClearScrollViewAnimation(scrollView)
        local function delayRemove()
            self:refreshScrollView()
            self:refreshResourcesNum()
            self:refreshStartButton()
        end
        delayExecute(self._mainLayout, delayRemove, delayTime)
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_CARDS_BREAK, onCardBreak)
    
    local function onChooseFinish(cardIDList)
        self._cardIDList = {}
        for index, cardID in ipairs(cardIDList) do
            local card = KUtil.getCardById(cardID)
            if card then
                table.insert(self._cardIDList, cardID)
            end
        end
        self:refreshScrollView(true)
        self:refreshResourcesNum()
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.UI_BREAK_CHOOSE_FINISH, onChooseFinish)
end

function KUIFactoryBreakCardNode:onCleanup()
end

return KUIFactoryBreakCardNode
