--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryCardLogNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/10/19  10:56
--  Contact     : lvsongxin@kingsoft.com
--  *********************************************************************


local PAGE_SIZE       = 30
local KEEP_SIZE       = 10
local CHECK_TIME      = 0.3
local LOADING_TIMEOUT = 10
local SHOW_SIZE       = 5
local NEXT_OFFSET     = 4.9  --下一页需要的滚动偏移
local PREVIEW_OFFSET  = 1.1    --上一页需要的滚动偏移

local m_tButtonNames  = {"Button_jz_favourite_sheet", "Button_jz_all_sheet", "Button_jz_sheet_1", "Button_jz_sheet_2",}
local m_tTabType      = {COLLECT = 1, ALL = 2, LOW = 3, HIGH = 4}

local m_tRange = {
    [m_tTabType.ALL]  = {START = 1, END = 6,},
    [m_tTabType.LOW]  = {START = 3, END = 4,},
    [m_tTabType.HIGH] = {START = 5, END = 6,},
}

local KUIFactoryCardLogNode = class(
    "KUIFactoryCardLogNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryCardLogNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._baseControl    = nil
    self._loadingBar     = nil
    self._isLoading      = false
    self._showListData   = {}
    self._tabType        = 0
    self._isNext         = false
    self._newPageInfo    = false
    self._isScrollTouch  = false
    self._beginTimes     = 0
    self._endTimes       = 0
    self._lastLoadintime = 0
    self._isResetTime    = false
    self._lastStartID    = 0
    self._lastEndID      = 0
    self._lastMarkID     = 0
    self._isCutInPage    = true
    self._isHaveData     = true
    self._lastShowListNum   = 0
end

function KUIFactoryCardLogNode.create(owner)
    local currentNode = KUIFactoryCardLogNode.new()

    currentNode._parent  = owner
    currentNode._uiPath  = "res/ui/layout_build_log.csb"
    currentNode._tabType = m_tTabType.ALL
    currentNode:init()

    return currentNode
end

local function setLoadingVisible(self, isVisible)
    if not self._loadingBar then return end
    self._isLoading = isVisible
    self._loadingBar:setVisible(isVisible)
    if isVisible then self._lastLoadintime = KUtil.getLocalTime() end
end

local function getOneId(self, isNext)
    local id = 0
    if isNext then
        id = self._lastEndID
    elseif (not isNext) then
        id = self._lastStartID
    end
    return id
end

local function getListByType(tabType)
    KPlayer.tLogData.tCardLogData = KPlayer.tLogData.tCardLogData or {}
    KPlayer.tLogData.tCardLogData[tabType] = KPlayer.tLogData.tCardLogData[tabType] or {}
    return KPlayer.tLogData.tCardLogData[tabType]
end

local function getListData(self, tabType)
    if m_tTabType.COLLECT == tabType then
        return KPlayer.tLogData.tCardLogCollect
    end

    return getListByType(tabType)
end

local function updateScrollLog(self, newControl, logInfo)
    if not logInfo.nID then
        logInfo.nID = logInfo.id
    end
    
    newControl:setName(tostring(logInfo.nID))
    --update name
    local textName = newControl:getChildByName("Text_player_name")
    textName:setString(logInfo.name)
    --update star
    local cardInfo = KConfig.cardInfo[logInfo.itemId]
    if not cardInfo then showNotice("log not exist id=:" .. logInfo.itemId) end

    local starNum = logInfo.star or cardInfo.nQuality
    for i = 1, KUtil.MAX_STAR do
        local imageStar = newControl:getChildByName("Image_common_star_"..i)
        if imageStar then imageStar:setVisible(i <= starNum) end
    end

    -- update card
    local imageHead     = newControl:getChildByName("Panel_project_card")
    local imageHeadProjectNode = imageHead:getChildByName("ProjectNode_card")
    if not imageHeadProjectNode then
        imageHeadProjectNode = cc.CSLoader:createNode("res/ui/layout_cardbase_small.csb")
        imageHead:addChild(imageHeadProjectNode)
    end

    local tHeadInfo     = {["nTemplateID"] = logInfo.itemId, ["nCurrentHP"] = cardInfo.nMaxHP, ["nMaxHP"] = cardInfo.nMaxHP}
    KUtil.onlyUpdatePlayerCardHeadBase(imageHeadProjectNode, tHeadInfo)
    -- update name
    local textName      = newControl:getChildByName("Text_tank_name")
    textName:setString(cardInfo.szName)
    -- update detail
    local textOil       = newControl:getChildByName("Text_oil_data")
    local textAmmo      = newControl:getChildByName("Text_ammo_data")
    local textSteel     = newControl:getChildByName("Text_steel_data")
    local textSpanmmo   = newControl:getChildByName("Text_spammo_data")
    textOil:setString(logInfo.oil)
    textAmmo:setString(logInfo.ammo)
    textSteel:setString(logInfo.steel)
    textSpanmmo:setString(logInfo.people)
    local isRemove = (m_tTabType.COLLECT == self._tabType)
    -- update button
    local buttonCollect = newControl:getChildByName("Button_fav_button")
    if isRemove then
        local stringConfig          = KConfig:getLine("string", "factorylog.delete")
        buttonCollect:setTitleText(stringConfig.szText)
    else
        local stringConfig          = KConfig:getLine("string", "factorylog.collect")
        buttonCollect:setTitleText(stringConfig.szText)
    end

    local function onCollectClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCollectClick~")
            KSound.playEffect("click")
            if isRemove then
                require("src/network/KC2SProtocolManager"):removeCardCollectLog(logInfo.id)
            else
                require("src/network/KC2SProtocolManager"):addCardCollectLog(logInfo.id, logInfo.itemId, logInfo.name, logInfo.roleid, logInfo.oil, logInfo.ammo, logInfo.steel, logInfo.people)
            end
        end
    end
    buttonCollect:addTouchEventListener(onCollectClick)

    local buttonUse = newControl:getChildByName("Button_use_button")
    local function onUseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onUseClick~")
            KSound.playEffect("click")
            local nodeData = {oil = logInfo.oil, ammo = logInfo.ammo, steel = logInfo.steel, people = logInfo.people}
            local factory  = self._parent:getNode("Factory")
            if factory then
                local buildNode = factory:getNode("ProjectNode_build")
                if buildNode then
                    buildNode:resetResourceArea(nodeData)
                    showNotice(KUtil.getStringByKey("log.apply"))
                    self._parent:removeNode("CardLog")
                end
            end
        end
    end
    buttonUse:addTouchEventListener(onUseClick)
end

local function addScrollPageView(self, sortType, isCutIn, tabType)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_jz_log_base")
    local slideControl     = controlLogBase:getChildByName("Slider_scroll")
    local scrollViewList   = controlLogBase:getChildByName("Scrollview_build_list")

    self._showListData     = getListData(self, tabType)

    local refreshCall = function(control, dataInfo)
        updateScrollLog(self, control, dataInfo)
    end

    local function onScrollChange(sender, type)
        if type == ccui.ScrollviewEventType.scrolling then
        elseif type == ccui.ScrollviewEventType.scrollToTop then
        elseif type == ccui.ScrollviewEventType.scrollToBottom then
            self._ScrollOutBottom = true
        end
    end

    local parameters = {
        scrollView  = scrollViewList,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        row         = 10,
        column      = 1,
        dataList    = self._showListData,
        refreshCall = refreshCall,
        onScroll    = onScrollChange,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function refreshPageList(self, tabType, isNext, currentPercent, isCutIn)
    addScrollPageView(self, sortType, isCutIn, tabType)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_jz_log_base")
    local slideControl     = controlLogBase:getChildByName("Slider_scroll")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    -- set scroll
    local function resetScroll(percert)
        local percertRadix = 100
        if percert < 0 then percert = 0 end
        if percert > percertRadix then percert = percertRadix end
        scrollControl:jumpToPercentVertical(percert)
        slideControl:setPercent(percert)
    end
    
    if currentPercent then
        local beforeNum = self._lastShowListNum
        local afterNum = #self._showListData
        beforeNum = beforeNum * currentPercent
        delayExecute(slideControl, function()
            resetScroll(beforeNum / afterNum)
            self._pageData.forceRefreshList()
        end, 0.05)
    end
    
    -- reset mark id
    self._lastStartID  = 0
    self._lastEndID    = 0
    if #self._showListData > 0 then
        self._lastStartID  = self._showListData[1].id
        self._lastEndID    = self._showListData[#self._showListData].id
    end
    self._lastShowListNum = #self._showListData
end

local function refreshUpdateCardLog(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_jz_log_base")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    local currentPercent   = KUtil.getScrollViewPercent(scrollControl)
    --need to set scroll percent
    if tostring(currentPercent) == "nan" then currentPercent = 0 end
    refreshPageList(self, self._tabType, true, currentPercent)
end

local function checkRequestNewData(self, tabType)
    if m_tTabType.COLLECT == tabType then
        local list = KPlayer.tLogData.tCardLogCollect
        if not list then return true end
    else
        local nextUpdateTime = KPlayer.tLogData.nCardNextUpdateTime
        local currentServerTime = KUtil.getCurrentServerTime()
        if not nextUpdateTime or nextUpdateTime < currentServerTime then
            self._isResetTime = true
            KPlayer.tLogData.tCardLogData = nil
            return true
        end
        if not (KPlayer.tLogData.tCardLogData and KPlayer.tLogData.tCardLogData[tabType]) then return true end
    end
    return false
end

local function openPanelRequest(self, tabType, isNext)
    local isRequestNewData = checkRequestNewData(self, tabType)
    if isRequestNewData then
        if m_tTabType.COLLECT == tabType then
            setLoadingVisible(self, true)
            require("src/network/KC2SProtocolManager"):getCardCollectLogList()
        else
            KPlayer.tLogData.tCardLogData = KPlayer.tLogData.tCardLogData or {}
            KPlayer.tLogData.tCardLogData[tabType] = nil
            local stratStar = m_tRange[tabType].START
            local endStar   = m_tRange[tabType].END
            self._isNext    = isNext
            setLoadingVisible(self, true)
            require("src/network/KC2SProtocolManager"):requestCardLogPageData(0, PAGE_SIZE, tabType, stratStar, endStar)
        end
    else
        refreshPageList(self, tabType, isNext)
    end
end

local function refreshSelectTab(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_jz_log_base")

    for tabType, buttonName in ipairs(m_tButtonNames) do
        local buttonControl = controlLogBase:getChildByName(buttonName) 
        if tabType == self._tabType then
            buttonControl:setBrightStyle(ccui.BrightStyle.highlight)
            buttonControl:setEnabled(false)
        else
            buttonControl:setBrightStyle(ccui.BrightStyle.normal)
            buttonControl:setEnabled(true)
        end
    end
end

local function scrollToNewPage(self, isNext)
    if self._isLoading then return end
    if self._isScrollTouch then return end
    if self._tabType == m_tTabType.COLLECT then return end
    local tabType   = self._tabType
    local id        = getOneId(self, isNext)
    -- never create again
    if self._lastMarkID ~= 0 and self._lastMarkID == id then 
        cclog("never create again") 
        return 
    end
    -- first page
    local list = getListByType(tabType)
    if #list > 0 and list[1].id == id then 
        cclog("first page") 
        return 
    end
    -- last page
    if #list > 0 and list[#list].id == id and (not self._isHaveData) then 
        cclog("last page") 
        return 
    end

    self._lastMarkID = id
    setLoadingVisible(self, true)
    if self._isHaveData then
        local stratStar = m_tRange[tabType].START
        local endStar   = m_tRange[tabType].END
        self._isNext    = isNext
        require("src/network/KC2SProtocolManager"):requestCardLogPageData(id, PAGE_SIZE, tabType, stratStar, endStar)
    else
        -- need to delay create
        self._newPageInfo = {tabType = tabType, isNext = isNext}
    end
end

local function selectNewTab(self, tabType)
    self._tabType = tabType
    self._showListData  = {}
    self._lastStartID   = 0
    self._lastEndID     = 0
    self._lastMarkID    = 0
    self._isHaveData    = true
    refreshSelectTab(self)
    openPanelRequest(self, self._tabType, true)
end

local function initUI(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_jz_log_base")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    self._baseControl      = scrollControl:getChildByName("Image_jz_log_unit_base")

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)
    self._baseControl:retain()
    self._baseControl:removeFromParent(false)
    node:addChild(self._baseControl)
    self._baseControl:release()

    self._loadingBar = cc.CSLoader:createNode("res/ui/animation_node/ani_loading.csb")
    mainNode:addChild(self._loadingBar)
    self._loadingBar:setVisible(false)
end

function KUIFactoryCardLogNode:activate(nowTime)
    if self._newPageInfo then
        local pageInfo    = self._newPageInfo
        self._newPageInfo = false
        setLoadingVisible(self, false)
        if self._tabType == pageInfo.tabType then
            refreshPageList(self, pageInfo.tabType, pageInfo.isNext)
        end
    end
    if nowTime - self._lastLoadintime > LOADING_TIMEOUT and self._isLoading then
        self._lastMarkID    = 0
        setLoadingVisible(self, false)
    end
end

local function playAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_log")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_build_log"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "CardLog", callBacks, isReturnOffice)
end

function KUIFactoryCardLogNode:onEnterActionFinished()
    playAnimation(self, true)
end

function KUIFactoryCardLogNode:onInitUI()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_log")
    projectNode:stopAllActions()
end

function KUIFactoryCardLogNode:getEnterAction()
    return nil, 0
end

function KUIFactoryCardLogNode:getExitAction()
    return nil, 0
end

function KUIFactoryCardLogNode:refreshUI()
    initUI(self)
    selectNewTab(self, m_tTabType.ALL)
end

function KUIFactoryCardLogNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    --Close Button
    local projectNode   = mainNode:getChildByName("ProjectNode_log")
    local baseControl   = projectNode:getChildByName("Image_common_base")
    local buttonControl = baseControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            buttonControl:setEnabled(false)
            playPanelCloseAnimation(self, false)
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local controlLogBase   = baseControl:getChildByName("Image_jz_log_base")
    for i, buttonName in ipairs(m_tButtonNames) do
        local tabType = i
        local buttonControl = controlLogBase:getChildByName(buttonName)
        local function onTabClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onTabClick~")
                KSound.playEffect("click")
                selectNewTab(self, tabType)
            end
        end
        buttonControl:addTouchEventListener(onTabClick)
    end
    
    local function tryScrollToNewPage()
        if self._ScrollOutBottom then
            if os.clock() - self._beginBottomTime >= CHECK_TIME then
                scrollToNewPage(self, true)
            end
            self._ScrollOutBottom = nil
        end
    end
    
    local slideControl     = controlLogBase:getChildByName("Slider_scroll")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    local function onScrollTouch(sender, type)
        if type == ccui.TouchEventType.began then
            self._isScrollTouch     = true
            self._beginBottomTime   = os.clock()
            self._ScrollOutBottom   = nil
        elseif type == ccui.TouchEventType.ended then
            self._isScrollTouch = false
            tryScrollToNewPage()
        elseif type == ccui.TouchEventType.canceled then
            self._isScrollTouch = false
            tryScrollToNewPage()
        end
    end
    scrollControl:addTouchEventListener(onScrollTouch)
end

function KUIFactoryCardLogNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onAddCardCollect(tOne)
        cclog("onEvent ------------> onAddCardCollect")
        showNotice(KUtil.getStringByKey("log.collect"))
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ADD_CARD_COLLECT, onAddCardCollect)

    local function onRemoveCardCollect(nID)
        cclog("onEvent ------------> onRemoveCardCollect")
        if m_tTabType.COLLECT ~= self._tabType then return end
        refreshUpdateCardLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_REMOVE_CARD_COLLECT, onRemoveCardCollect)

    local function onUpdateCardCollect(tLogList)
        cclog("onEvent ------------> onUpdateCardCollect")
        setLoadingVisible(self, false)
        if m_tTabType.COLLECT ~= self._tabType then return end
        refreshUpdateCardLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_CARD_COLLECT, onUpdateCardCollect)

    local function onUpdateCardLog(nID, nTabType, nNextUpdateTime, tLogList)
        cclog("onEvent ------------> onUpdateCardLog")
        setLoadingVisible(self, false)
        if self._isResetTime then 
            self._isResetTime = false
            KPlayer.tLogData.nCardNextUpdateTime = nNextUpdateTime 
        end
        if #tLogList < PAGE_SIZE then
            self._isHaveData = false
        end
        if nTabType ~= self._tabType then return end
        refreshUpdateCardLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_CARD_LOG, onUpdateCardLog)
end

function KUIFactoryCardLogNode:onCleanup()
    self._baseControl = nil
end

return KUIFactoryCardLogNode
