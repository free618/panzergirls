--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryEquipLogNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/10/19  10:56
--  Contact     : lvsongxin@kingsoft.com
--  *********************************************************************


local PAGE_SIZE       = 30
local KEEP_SIZE       = 10
local CHECK_TIME      = 0.3
local LOADING_TIMEOUT = 10
local SHOW_SIZE       = 5
local NEXT_OFFSET     = 4.9  --下一页需要的滚动偏移
local PREVIEW_OFFSET  = 1    --上一页需要的滚动偏移

local m_tItemLevelPath = "res/ui/ui_material/public/common_gear_level%d.png"
local m_tButtonNames   = {"Button_kf_favourite_sheet", "Button_kf_all_sheet", "Button_kf_sheet_1", "Button_kf_sheet_2",}
local m_tTabType       = {COLLECT = 1, ALL = 2, LOW = 3, HIGH = 4}

local m_tRange = {
    [m_tTabType.ALL]  = {START = 1, END = 6,},
    [m_tTabType.LOW]  = {START = 3, END = 4,},
    [m_tTabType.HIGH] = {START = 5, END = 6,},
}

local KUIFactoryEquipLogNode = class(
    "KUIFactoryEquipLogNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryEquipLogNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._baseControl       = nil
    self._loadingBar        = nil
    self._isLoading         = false
    self._showListData      = {}
    self._tabType           = 0
    self._isNext            = false
    self._newPageInfo       = false
    self._isScrollTouch     = false
    self._beginTimes        = 0
    self._endTimes          = 0
    self._lastLoadintime    = 0
    self._isResetTime       = false
    self._lastStartID       = 0
    self._lastEndID         = 0
    self._lastMarkID        = 0
    self._isCutInPage       = true
    self._isHaveData        = true
    self._lastShowListNum   = 0
end

function KUIFactoryEquipLogNode.create(owner)
    local currentNode = KUIFactoryEquipLogNode.new()

    currentNode._parent  = owner
    currentNode._uiPath  = "res/ui/layout_develop_log.csb"
    currentNode._tabType = m_tTabType.ALL
    currentNode:init()

    return currentNode
end

local function setLoadingVisible(self, isVisible)
    if not self._loadingBar then return end
    self._isLoading = isVisible
    self._loadingBar:setVisible(isVisible)
    if isVisible then self._lastLoadintime = KUtil.getLocalTime() end
end

local function getOneId(self, isNext)
    local id = 0
    if isNext then
        id = self._lastEndID
    elseif (not isNext) then
        id = self._lastStartID
    end
    return id
end

local function getListByType(tabType)
    KPlayer.tLogData.tEquipLogData = KPlayer.tLogData.tEquipLogData or {}
    KPlayer.tLogData.tEquipLogData[tabType] = KPlayer.tLogData.tEquipLogData[tabType] or {}
    return KPlayer.tLogData.tEquipLogData[tabType]
end

local function getListData(self, tabType)
    if m_tTabType.COLLECT == tabType then
        return KPlayer.tLogData.tEquipLogCollect
    end

    return getListByType(tabType)
end

local function updateScrollLog(self, newControl, logInfo)
    if not logInfo.nID then
        logInfo.nID = logInfo.id
    end
    newControl:setName(tostring(logInfo.nID))

    --update name
    local textName = newControl:getChildByName("Text_player_name")
    textName:setString(logInfo.name)
    --update star
    local equipInfo = KConfig.equipInfo[logInfo.itemId]
    if not equipInfo then showNotice("log not exist id=:" .. logInfo.itemId) end
    local starNum = logInfo.star or equipInfo.nGrade
    for i = 1, KUtil.MAX_STAR do
        local imageStar = newControl:getChildByName("Image_common_star_"..i)
        if imageStar then imageStar:setVisible(i <= starNum) end
    end
    --update item
    local panelEquip = newControl:getChildByName("Panel_gear_icon")
    local imageLevel = panelEquip:getChildByName("Image_common_gear_level1")
    imageLevel:loadTexture(string.format(m_tItemLevelPath, starNum))

    -- update name
    local textName     = newControl:getChildByName("Text_tank_name")
    textName:setString(equipInfo.szName)

    local equipPath = KUtil.getEquipImagePathByID(logInfo.itemId)
    local imageGear = panelEquip:getChildByName("Image_gear")
    imageGear:loadTexture(equipPath)
    -- update detail
    local textOil     = newControl:getChildByName("Text_oil_data")
    local textAmmo    = newControl:getChildByName("Text_ammo_data")
    local textSteel   = newControl:getChildByName("Text_steel_data")
    local textSpanmmo = newControl:getChildByName("Text_spammo_data")
    textOil:setString(logInfo.oil)
    textAmmo:setString(logInfo.ammo)
    textSteel:setString(logInfo.steel)
    textSpanmmo:setString(logInfo.people)
    -- update button
    local isRemove = (m_tTabType.COLLECT == self._tabType)
    local buttonCollect = newControl:getChildByName("Button_fav_button")
    if isRemove then
        local stringConfig          = KConfig:getLine("string", "factorylog.delete")
        buttonCollect:setTitleText(stringConfig.szText)
    else
        local stringConfig          = KConfig:getLine("string", "factorylog.collect")
        buttonCollect:setTitleText(stringConfig.szText)
    end
    local function onCollectClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCollectClick~")
            KSound.playEffect("click")
            if isRemove then
                require("src/network/KC2SProtocolManager"):removeEquipCollectLog(logInfo.id)
            else
                require("src/network/KC2SProtocolManager"):addEquipCollectLog(logInfo.id, logInfo.itemId, logInfo.name, logInfo.roleid, logInfo.oil, logInfo.ammo, logInfo.steel, logInfo.people)
            end
        end
    end
    buttonCollect:addTouchEventListener(onCollectClick)

    local buttonUse = newControl:getChildByName("Button_use_button")
    local function onUseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onUseClick~")
            KSound.playEffect("click")
            local nodeData = {oil = logInfo.oil, ammo = logInfo.ammo, steel = logInfo.steel, people = logInfo.people}
            local factory  = self._parent:getNode("Factory")
            if factory then
                local developNode = factory:getNode("ProjectNode_develop")
                if developNode then
                    developNode:resetResourceArea(nodeData)
                    showNotice(KUtil.getStringByKey("log.apply"))
                    self._parent:removeNode("EquipLog")
                end
            end
        end
    end
    buttonUse:addTouchEventListener(onUseClick)
end

local function addScrollPageView(self, sortType, isCutIn, tabType)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_kf_log_base")
    local slideControl     = controlLogBase:getChildByName("Slider_scroll")
    local scrollViewList   = controlLogBase:getChildByName("Scrollview_build_list")

    self._showListData     = getListData(self, tabType)

    local refreshCall = function(control, dataInfo)
        updateScrollLog(self, control, dataInfo)
    end

    local function onScrollChange(sender, type)
        if type == ccui.ScrollviewEventType.scrolling then
        elseif type == ccui.ScrollviewEventType.scrollToTop then
        elseif type == ccui.ScrollviewEventType.scrollToBottom then
            self._ScrollOutBottom = true
        end
    end

    local parameters = {
        scrollView  = scrollViewList,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        column      = 1,
        row         = 10,
        dataList    = self._showListData,
        refreshCall = refreshCall,
        onScroll    = onScrollChange,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function refreshPageList(self, tabType, currentPercent, isCutIn)
    addScrollPageView(self, sortType, isCutIn, tabType)

    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_kf_log_base")
    local slideControl     = controlLogBase:getChildByName("Slider_scroll")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")

    -- set scroll
    local function resetScroll(percert)
        local percertRadix = 100
        if percert < 0 then percert = 0 end
        if percert > percertRadix then percert = percertRadix end
        scrollControl:jumpToPercentVertical(percert)
        slideControl:setPercent(percert)
    end
    
    if currentPercent then
        local beforeNum = self._lastShowListNum
        local afterNum = #self._showListData
        beforeNum = beforeNum * currentPercent
        delayExecute(slideControl, function()
            resetScroll(beforeNum / afterNum)
            self._pageData.forceRefreshList()
        end, 0.05)
    end

    -- reset mark id
    self._lastStartID  = 0
    self._lastEndID    = 0
    if #self._showListData > 0 then
        self._lastStartID  = self._showListData[1].id
        self._lastEndID    = self._showListData[#self._showListData].id
    end
    self._lastShowListNum = #self._showListData
end

local function refreshUpdateEquipLog(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_kf_log_base")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    local currentPercent   = KUtil.getScrollViewPercent(scrollControl)
    --need to set scroll percent
    if tostring(currentPercent) == "nan" then currentPercent = 0 end
    refreshPageList(self, self._tabType, currentPercent)
end

local function checkRequestNewData(self, tabType)
    if m_tTabType.COLLECT == tabType then
        local list = KPlayer.tLogData.tEquipLogCollect
        if not list then return true end
    else
        local nextUpdateTime = KPlayer.tLogData.nEquipNextUpdateTime
        local currentServerTime = KUtil.getCurrentServerTime()
        if not nextUpdateTime or nextUpdateTime < currentServerTime then
            self._isResetTime = true
            KPlayer.tLogData.tEquipLogData = nil
            return true
        end
        if not (KPlayer.tLogData.tEquipLogData and KPlayer.tLogData.tEquipLogData[tabType]) then return true end
    end
    return false
end

local function openPanelRequest(self, tabType, isNext)
    local isRequestNewData = checkRequestNewData(self, tabType)
    if isRequestNewData then
        if m_tTabType.COLLECT == tabType then
            setLoadingVisible(self, true)
            require("src/network/KC2SProtocolManager"):getEquipCollectLogList()
        else
            KPlayer.tLogData.tEquipLogData = KPlayer.tLogData.tEquipLogData or {}
            KPlayer.tLogData.tEquipLogData[tabType] = nil
            local stratStar = m_tRange[tabType].START
            local endStar   = m_tRange[tabType].END
            self._isNext    = isNext
            setLoadingVisible(self, true)
            require("src/network/KC2SProtocolManager"):requestEquipLogPageData(0, PAGE_SIZE, tabType, stratStar, endStar)
        end
    else
        refreshPageList(self, tabType)
    end
end

local function refreshSelectTab(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_kf_log_base")

    for tabType, buttonName in ipairs(m_tButtonNames) do
        local buttonControl = controlLogBase:getChildByName(buttonName) 
        if tabType == self._tabType then
            buttonControl:setBrightStyle(ccui.BrightStyle.highlight)
            buttonControl:setEnabled(false)
        else
            buttonControl:setBrightStyle(ccui.BrightStyle.normal)
            buttonControl:setEnabled(true)
        end
    end
end

local function checkNewPageData(self, isNext)
    if isNext then
        local tabType    = self._tabType
        local list       = getListByType(tabType)
        local length     = #list
        local id         = getOneId(self, isNext)
        --get page data
        local stratStar = m_tRange[tabType].START
        local endStar   = m_tRange[tabType].END
        local listSize = 0
        -- current page
        for i = 1, length do
            local log = list[i]
            if log.star >= stratStar and log.star <= endStar and (log.id < id or id == 0) then
                listSize = listSize + 1
                if listSize == PAGE_SIZE then break end
            end
        end
        if (listSize < PAGE_SIZE) then return true end
    end
    return false
end

local function scrollToNewPage(self, isNext)
    if self._isLoading then return end
    if self._isScrollTouch then return end
    if self._tabType == m_tTabType.COLLECT then return end
    local tabType   = self._tabType
    --local isNewData = checkNewPageData(self, isNext)
    local id        = getOneId(self, isNext)
    -- never create again
    if self._lastMarkID ~= 0 and self._lastMarkID == id then 
        cclog("never create again") 
        return 
    end
    -- first page
    local list = getListByType(tabType)
    if #list > 0 and list[1].id == id then 
        cclog("first page") 
        return 
    end
    -- last page
    if #list > 0 and list[#list].id == id and (not self._isHaveData) then 
        cclog("last page") 
        return 
    end

    self._lastMarkID = id
    setLoadingVisible(self, true)
    if self._isHaveData then
        local stratStar = m_tRange[tabType].START
        local endStar   = m_tRange[tabType].END
        self._isNext    = isNext
        require("src/network/KC2SProtocolManager"):requestEquipLogPageData(id, PAGE_SIZE, tabType, stratStar, endStar)
    else
        -- need to delay create
        self._newPageInfo = {tabType = tabType, isNext = isNext}
    end
end

local function selectNewTab(self, tabType)
    self._tabType = tabType
    self._showListData  = {}
    self._lastStartID   = 0
    self._lastEndID     = 0
    self._lastMarkID    = 0
    self._isHaveData    = true
    refreshSelectTab(self)
    openPanelRequest(self, self._tabType, true)
end

local function initUI(self)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_log")
    local imageBaseControl = projectNode:getChildByName("Image_common_base")
    local controlLogBase   = imageBaseControl:getChildByName("Image_kf_log_base")
    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    self._baseControl      = scrollControl:getChildByName("Image_kf_log_unit_base")

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)
    self._baseControl:removeFromParent(false)
    node:addChild(self._baseControl)

    self._loadingBar = cc.CSLoader:createNode("res/ui/animation_node/ani_loading.csb")
    mainNode:addChild(self._loadingBar)
    self._loadingBar:setVisible(false)
end

function KUIFactoryEquipLogNode:activate(nowTime)
    if self._newPageInfo then
        local pageInfo    = self._newPageInfo
        self._newPageInfo = false
        setLoadingVisible(self, false)
        if self._tabType == pageInfo.tabType then
            refreshPageList(self, pageInfo.tabType)
        end
    end
    if nowTime - self._lastLoadintime > LOADING_TIMEOUT and self._isLoading then
        self._lastMarkID    = 0
        setLoadingVisible(self, false)
    end
end

local function playAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_log")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_develop_log"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "EquipLog", callBacks, isReturnOffice)
end

function KUIFactoryEquipLogNode:onEnterActionFinished()
    playAnimation(self, true)
end

function KUIFactoryEquipLogNode:onInitUI()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_log")
    projectNode:stopAllActions()
end

function KUIFactoryEquipLogNode:getEnterAction()
    return nil, 0
end

function KUIFactoryEquipLogNode:getExitAction()
    return nil, 0
end

function KUIFactoryEquipLogNode:refreshUI()
    initUI(self)
    selectNewTab(self, m_tTabType.ALL)
end

function KUIFactoryEquipLogNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    --Close Button
    local projectNode   = mainNode:getChildByName("ProjectNode_log")
    local baseControl   = projectNode:getChildByName("Image_common_base")
    local buttonControl = baseControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            buttonControl:setEnabled(false)
            playPanelCloseAnimation(self, false)
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local controlLogBase   = baseControl:getChildByName("Image_kf_log_base")
    for i, buttonName in ipairs(m_tButtonNames) do
        local tabType = i
        local buttonControl = controlLogBase:getChildByName(buttonName)
        local function onTabClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onTabClick~")
                KSound.playEffect("click")
                selectNewTab(self, tabType)
            end
        end
        buttonControl:addTouchEventListener(onTabClick)
    end

    local function tryScrollToNewPage()
        if self._ScrollOutBottom then
            if os.clock() - self._beginBottomTime >= CHECK_TIME then
                scrollToNewPage(self, true)
            end
            self._ScrollOutBottom = nil
        end
    end

    local scrollControl    = controlLogBase:getChildByName("Scrollview_build_list")
    local function onScrollTouch(sender, type)
        if type == ccui.TouchEventType.began then
            self._isScrollTouch     = true
            self._beginBottomTime   = os.clock()
            self._ScrollOutBottom   = nil
        elseif type == ccui.TouchEventType.ended then
            self._isScrollTouch = false
            tryScrollToNewPage()
        elseif type == ccui.TouchEventType.canceled then
            self._isScrollTouch = false
            tryScrollToNewPage()
        end
    end
    scrollControl:addTouchEventListener(onScrollTouch)
end

function KUIFactoryEquipLogNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onAddEquipCollect(tOne)
        cclog("onEvent ------------> onAddEquipCollect")
        showNotice(KUtil.getStringByKey("log.collect"))
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ADD_EQUIP_COLLECT, onAddEquipCollect)

    local function onRemoveEquipCollect(nID)
        cclog("onEvent ------------> onRemoveEquipCollect")
        if m_tTabType.COLLECT ~= self._tabType then return end
        refreshUpdateEquipLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_REMOVE_EQUIP_COLLECT, onRemoveEquipCollect)

    local function onUpdateEquipCollect(tLogList)
        cclog("onEvent ------------> onUpdateEquipCollect")
        setLoadingVisible(self, false)
        if m_tTabType.COLLECT ~= self._tabType then return end
        refreshUpdateEquipLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_EQUIP_COLLECT, onUpdateEquipCollect)

    local function onUpdateEquipLog(nID, nTabType, nNextUpdateTime, tLogList)
        cclog("onEvent ------------> onUpdateEquipLog")
        setLoadingVisible(self, false)
        if self._isResetTime then 
            self._isResetTime = false
            KPlayer.tLogData.nEquipNextUpdateTime = nNextUpdateTime 
        end
        if #tLogList < PAGE_SIZE then
            self._isHaveData = false
        end
        if nTabType ~= self._tabType then return end
        refreshUpdateEquipLog(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_EQUIP_LOG, onUpdateEquipLog)
end

function KUIFactoryEquipLogNode:onCleanup()
    self._baseControl = nil
end

return KUIFactoryEquipLogNode
