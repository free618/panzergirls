--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFoodMedalNode.lua
--  Creator     : ChenJiaLiang
--  Date        : 2016/04/25   19:20
--  Contact     : chenjialiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local FOOD_COUNT = 5
local FOOD_MEDAL_COUNT = 5
local COOKING_ANIMATION_TAG = 100

local KSetting = require("src/logic/KSetting")

local KUIFoodMedalNode = class(
    "KUIFoodMedalNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFoodMedalNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._animationList         = {}
    self._imagePathBase         = "res/ui/ui_material/food_house/"
end

function KUIFoodMedalNode.create(owner, isFree, cookResultIdx, itemList)
    local currentNode   = KUIFoodMedalNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_food_medal.csb"
    currentNode._tasteInfo = {isFree = isFree, cookResultIdx = cookResultIdx, itemList = itemList}
    currentNode:init()

    return currentNode
end

local function initData(self)
    local mainNode                  = self._mainLayout
    local imageBase                 = mainNode:getChildByName("Image_base")
    self._imageBase                 = imageBase
    self._nodeTitle                 = imageBase:getChildByName("ProjectNode_title")

    local panelFood                 = imageBase:getChildByName("Panel_food")
    self._panelFood                 = panelFood
    self._nodeDialog                = panelFood:getChildByName("ProjectNode_dialog")
    self._vicker                    = panelFood:getChildByName("ProjectNode_vicker")
    self._vickerDialog              = panelFood:getChildByName("ProjectNode_vicker_dialog")
    self._vickerCooking             = self._vicker:getChildByName("ProjectNode_cooking")
    self._nodeFinish                = panelFood:getChildByName("ProjectNode_finish")

    local foodNode                  = panelFood:getChildByName("ProjectNode_vicker")
    local dishPenelFood             = self._nodeFinish:getChildByName("Panel_food")
    local foodImage                 = dishPenelFood:getChildByName("Image_food_name_base")
    self._foodName                  = foodImage:getChildByName("Text_food_name")
    self._dishImage                 = dishPenelFood:getChildByName("Image_food_dish")

    local medalNode                 = panelFood:getChildByName("ProjectNode_medal")
    self._panelMedal                = medalNode:getChildByName("Panel_medal")

    local buttonNode                = panelFood:getChildByName("ProjectNode_button_taste")
    local tasteButton               = buttonNode:getChildByName("Button_taste")
    self._tasteButton               = tasteButton
    self._tasteBtnAnimation         = {ani = KUtil.initAnimation(buttonNode, "res/ui/animation_node/ani_food_medal_button.csb"), 
                                       start = {},
                                   }

    self._animationList.title       = {ani = KUtil.initAnimation(self._nodeTitle, "res/ui/animation_node/ani_food_house_title.csb")}

    local markNode                  = panelFood:getChildByName("ProjectNode_mark")
    self._markAnimation             = {ani    = KUtil.initAnimation(markNode, "res/ui/animation_node/ani_food_medal_mark.csb"),
                                       start = {},
                                    }

    self._vickerDialogAnimation     = {ani    = KUtil.initAnimation(self._vickerDialog, "res/ui/animation_node/ani_food_house_dialog.csb"),
                                       start = {0, 26},
                                    }

    self._dialogAnimation           = {ani   = KUtil.initAnimation(self._nodeDialog, "res/ui/animation_node/ani_food_house_dialog.csb"),
                                       start = {0, 26},
                                    }
    self._vickerAnimation           = {ani   = KUtil.initAnimation(self._vicker, "res/ui/animation_node/ani_food_cooking_vicker.csb"),
                                       start = {0, 50},
                                    }
    self._cookFinishAnimation       = {ani = KUtil.initAnimation(self._nodeFinish, "res/ui/animation_node/ani_food_cooking_finish.csb"),
                                       start = {0, 50},
                                    }
    self._medalAnimation            = {ani = KUtil.initAnimation(medalNode, "res/ui/animation_node/ani_food_medal.csb"), 
                                       start = {},
                                    }

    local titleBase         = self._nodeTitle:getChildByName("Image_title_base")
    local buttonClose       = titleBase:getChildByName("Button_close")
    KUtil.setTouchEnabled(buttonClose, false)

    panelFood:getChildByName("ProjectNode_vicker_dialog"):setVisible(false)
    markNode:setVisible(false)
    self._nodeFinish:setVisible(false)
    self._nodeDialog:setVisible(false)
    self._vickerDialog:setVisible(true)
    tasteButton:setVisible(true)
end

function KUIFoodMedalNode:activate(nowTime)
end

function KUIFoodMedalNode:onInitUI()
    initData(self)
    self:initFoodContent()
end

function KUIFoodMedalNode:refreshUI()
    self:refreshResource()
end

function KUIFoodMedalNode:onEnterActionFinished()
    self:enterAnimation()
end

function KUIFoodMedalNode:refreshResource()
    local topNode           = self._nodeTitle:getChildByName("Image_title_base")
    local diamondNumText    = topNode:getChildByName("BitmapFontLabel_diamond")
    local ticketNumText     = topNode:getChildByName("BitmapFontLabel_food")
    local cookNumText       = topNode:getChildByName("BitmapFontLabel_number")
    local freeItemCount     = KUtil.getItemCount(KConfig.foodsys.nFreeItemID.nValue)
    local maxCookTimes      = KConfig.foodsys.nDailyCookTimes.nValue

    diamondNumText:setString(tostring(KPlayer.coin))
    ticketNumText:setString(tostring(freeItemCount))
    cookNumText:setString(string.format(KUtil.getStringByKey("common.rate"), maxCookTimes - KPlayer.tFoodHouseData.nCookTimes, maxCookTimes))
end


function KUIFoodMedalNode:registerAllTouchEvent()
    local tasteButton  = self._tasteButton

    local function onTasteClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onTasteClick~")
            local function onClose(  )
                KSound.playEffect("close")
                self:playPanelCloseAnimation(false)
                self._parent:removeNode("FoodMedal") 
            end
            KUtil.playGetItemAnimation(self._parent, self._tasteInfo.itemList, onClose)
            --self._parent:addNode("Reward", {tResultList = self._tasteInfo.itemList})
        end
    end
    tasteButton:addTouchEventListener(onTasteClick)

    local titleBase         = self._nodeTitle:getChildByName("Image_title_base")
    local buttonClose       = titleBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self:playPanelCloseAnimation(false)
            self._parent:removeNode("FoodMedal") 
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local vickerNode        = self._panelFood:getChildByName("ProjectNode_vicker")
    local vickerButton      = vickerNode:getChildByName("Panel_click")
    local function onCookingClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCookingClick~")
            if self._vickerDialog:getActionByTag(COOKING_ANIMATION_TAG) then
                self._vickerDialog:stopActionByTag(COOKING_ANIMATION_TAG)
                if self._onSkipCookingAnimate then
                    local onAnimateDone = self._onSkipCookingAnimate
                    self._onSkipCookingAnimate = nil
                    onAnimateDone()
                end
            end
        end
    end
    vickerButton:addTouchEventListener(onCookingClick)
end

function KUIFoodMedalNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onCoinUpdate()
        cclog("onEvent ---------->KUIFoodMedalNode onCoinUpdate")
        self:refreshResource()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_COIN, onCoinUpdate)
end

function KUIFoodMedalNode:onNodeEnter()
    
end

function KUIFoodMedalNode:enterAnimation()
    for _, aniConfig in pairs(self._animationList) do
        KUtil.playEnterAnimation(aniConfig.ani, aniConfig.beginFrame, aniConfig.endFrame)
    end
end

function KUIFoodMedalNode:playPanelCloseAnimation(isReturnOffice)
    local function animationFun()
        local framesList = {}
        table.insert(framesList, self:exitAnimation())
        return framesList
    end

    local callBacks = {animationFun}
    KUtil.delayClosePanel(self, "Cook", callBacks, isReturnOffice)
end

function KUIFoodMedalNode:exitAnimation()
    local delayTime = 0
    for _, aniConfig in pairs(self._animationList) do
        local aniTime = KUtil.playQuitAnimation(aniConfig.ani)
        if aniTime > delayTime then
            delayTime = aniTime
        end
    end

    return delayTime
end

function KUIFoodMedalNode:initFoodContent()
    local foodConfig   = KConfig.food[self._tasteInfo.cookResultIdx]
    self._foodName:setString(foodConfig.szFoodName)

    local nFoodType = foodConfig.nCardType
    for i = 1, FOOD_MEDAL_COUNT do
        local medalIcon = self._panelMedal:getChildByName("Image_food_medal_" .. i)
        medalIcon:setVisible(i == nFoodType)
    end
    self._panelMedal:setVisible(false)

    local dishImage = foodConfig.szDishImage
    local imagePath = self._imagePathBase .. dishImage
    self._dishImage:loadTexture(imagePath)

    self:playCookingAnimation(foodConfig)
end

function KUIFoodMedalNode:showDialog(text)
    local dialog        = self._nodeDialog:getChildByName("Image_dialog") 
    local dialogText    = dialog:getChildByName("Text_dialog")
    local mark          = self._panelFood:getChildByName("ProjectNode_mark")
    local dialogTitle   = dialog:getChildByName("Text_title")
    local duration = 0.3

    KUtil.playEnterAnimation(self._markAnimation.ani, self._markAnimation.start[1], self._markAnimation.start[2])
    KUtil.playEnterAnimation(self._dialogAnimation.ani, self._dialogAnimation.start[1], self._dialogAnimation.start[2])
    mark:setVisible(true)
    dialog:setVisible(isShow)
    dialogText:setString(text)
    dialogTitle:setString("")

    dialog:runAction(cc.Sequence:create(
        cc.FadeIn:create(duration)
        )
    )
end

function KUIFoodMedalNode:hideDialog()
    local dialog        = self._nodeDialog:getChildByName("Image_dialog") 
    dialog:setVisible(false)
end

function KUIFoodMedalNode:playSmokeEffect( )
    local completeNode              = self._panelFood:getChildByName("ProjectNode_complete_effect")
    self._completeNode              = completeNode

    local smokeNode                 = cc.CSLoader:createNode("res/ui/animation_node/ani_food_completion_effect.csb")
    local posX, posY                = 640, 360
    self._mainLayout:addChild(smokeNode, 100)
    smokeNode:stopAllActions()
    smokeNode:setPosition(cc.p(posX, posY))
    local function onSmokeEnd(  )
        smokeNode:removeFromParent()
    end
    delayExecute(self._panelFood, onSmokeEnd, 6)
end

function KUIFoodMedalNode:playCookingAnimation(foodConfig)
    local text          = foodConfig.szCookDialog
    local dialog        = self._vickerDialog:getChildByName("Image_dialog") 
    local dialogText    = dialog:getChildByName("Text_dialog")
    local dialogTitle   = dialog:getChildByName("Text_title")

    dialog:setVisible(true)
    KUtil.playEnterAnimation(self._vickerDialogAnimation.ani, self._vickerDialogAnimation.start[1], self._vickerDialogAnimation.start[2])
    KUtil.playEnterAnimation(self._vickerAnimation.ani, self._vickerAnimation.start[1], self._vickerAnimation.start[2])
    dialogText:setString(text)
    dialogTitle:setString("")

    local function onAnimateDone()
        cclog("KUIFoodMedalNode onAnimateDone")
        self._tasteButton:setVisible(true)
        KUtil.playEnterAnimation(self._tasteBtnAnimation.ani, self._tasteBtnAnimation.start[1], self._tasteBtnAnimation.start[2])
        KUtil.playEnterAnimation(self._cookFinishAnimation.ani, self._cookFinishAnimation.start[1], self._cookFinishAnimation.start[2])
        -- self._panelMedal:setVisible(true)
        -- KUtil.playEnterAnimation(self._medalAnimation.ani, self._medalAnimation.start[1], self._medalAnimation.start[2])
        KUtil.playQuitAnimation(self._vickerDialogAnimation.ani)

        self._nodeDialog:setVisible(true)
        self._vickerDialog:setVisible(false)

        self._nodeFinish:setVisible(true)
        self._vickerCooking:setVisible(false)
        self:showDialog(foodConfig.szDialog, true)
    end

    local function onCookingComplete()
        self:playSmokeEffect()
        KUtil.playQuitAnimation(self._vickerAnimation.ani)
        delayExecute(self._vickerDialog, function () onAnimateDone() end, 0.8)
    end

    dialog:runAction(cc.FadeIn:create(0.3))
    local delayAction = delayExecute(self._vickerDialog, onCookingComplete, 3)
    delayAction:setTag(COOKING_ANIMATION_TAG)
    self._onSkipCookingAnimate = onCookingComplete
end

return KUIFoodMedalNode