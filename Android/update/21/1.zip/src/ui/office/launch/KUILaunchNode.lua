--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILaunchNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/28   12:30
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUILaunchNode = class(
    "KUILaunchNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILaunchNode:ctor()
    self._mainLayout         = nil
    self._parent             = nil
    self._uiPath             = nil
    self._lastUpdateTime     = 0
end

function KUILaunchNode.create(owner)
    local currentNode = KUILaunchNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_launch.csb"
    currentNode:init()

    return currentNode
end

local function stopAllAnimation(self)
    KUtil.stopCommonAnimation(self)
end

local function refreshDisableRedPoint(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local buttonLaunch      = imageBase:getChildByName("Button_cj_launch")
    local projectNode       = buttonLaunch:getChildByName("ProjectNode_notice")
    projectNode:setVisible(false)

    local buttonExercise    = imageBase:getChildByName("Button_cj_exercise")
    local projectNode       = buttonExercise:getChildByName("ProjectNode_notice")
    projectNode:setVisible(false)

    local buttonExpedition  = imageBase:getChildByName("Button_cj_expedition")
    local projectNode       = buttonExpedition:getChildByName("ProjectNode_notice")
    projectNode:setVisible(false)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Launch", callBacks, isReturnOffice)
end

local function refreshRedPoint(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local buttonExpedition  = imageBase:getChildByName("Button_cj_expedition")
    local projectNode       = buttonExpedition:getChildByName("ProjectNode_notice")
    local isExpeditionFinish = (KUtil.getExpeditionFinishArea() ~= 0)
    projectNode:setVisible(isExpeditionFinish) 

    local buttonLaunch  = imageBase:getChildByName("Button_cj_launch")
    local projectNode   = buttonLaunch:getChildByName("ProjectNode_notice")
    local isBattlePoint = KUtil.checkBattleRedPoint()
    projectNode:setVisible(isBattlePoint)
end

function KUILaunchNode:activate(nowTime)
    if self._lastUpdateTime ~= nowTime then
        refreshRedPoint(self)
    end
    self._lastUpdateTime = nowTime
end

function KUILaunchNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    refreshDisableRedPoint(self)
end

function KUILaunchNode:refreshUI()
end

function KUILaunchNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
end

function KUILaunchNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "cj_base")
    
    local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_common_base")
    local buttonLaunch  = imageBase:getChildByName("Button_cj_launch")
    local function onLaunchClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        cclog("-----> onLaunchClick~")
        self._parent:addNode("LaunchMaps")
    end
    buttonLaunch:addTouchEventListener(onLaunchClick)
    
    local buttonExercise = imageBase:getChildByName("Button_cj_exercise")
    local function onExerciseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        cclog("-----> onExerciseClick~")
        self._parent:addNode("ExerciseRoleList")
    end
    buttonExercise:addTouchEventListener(onExerciseClick)
    
    local buttonExpedition = imageBase:getChildByName("Button_cj_expedition")
    local function onExpeditionClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end 
        KSound.playEffect("click")
        cclog("-----> onExpeditionClick~")
        self._parent:addNode("Expedition")
    end
    buttonExpedition:addTouchEventListener(onExpeditionClick)

    local panelTrain    = mainNode:getChildByName("Panel_train")
    panelTrain:setVisible(false)
    panelTrain:setTouchEnabled(false)
    -- local buttonTrain   = panelTrain:getChildByName("Button_train")
    -- local imageMaskBase = panelTrain:getChildByName("Image_mask_base")
    -- imageMaskBase:setTouchEnabled(true)
    -- local function onTrainingClick(sender, type)
    --     if type ~= ccui.TouchEventType.ended then return end 
    --     KSound.playEffect("click")
    --     cclog("-----> onTrainingClick~")
    --     self._parent:addNode("Training")
    -- end
    -- imageMaskBase:addTouchEventListener(onTrainingClick)
    -- buttonTrain:addTouchEventListener(onTrainingClick)
end

function KUILaunchNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onResourceUpdate()
        cclog("----------> onEvent KUILaunchNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

return KUILaunchNode
