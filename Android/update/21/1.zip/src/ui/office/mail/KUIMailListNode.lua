--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMailListNode.lua
--  Creator     : huangyixin
--  Date        : 2015/11/24   12:00
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIMailListNode = class(
    "KUIMailListNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMailListNode:ctor()
    self._mainLayout      = nil
    self._parent          = nil
    self._uiPath          = nil

    self._scrollController = nil
    self._requestIDList    = {}
    self._waittingRequest  = false
    self._lastRequestTime  = 0
    self._mailIDList       = nil
end

function KUIMailListNode.create(owner)
    local currentNode   = KUIMailListNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/mailbox_list.csb"
    currentNode:init()
    return currentNode
end

local function createScrollController(parameters)
    local scrollView         = parameters.scrollView
    local uiBarBase          = parameters.uiBarBase
    local funcInit           = parameters.funcInit
    local funcRefreshUIBar   = parameters.funcRefreshUIBar
    local funcOnScrollToBottom = parameters.funcOnScrollToBottom

    local innerContainer   = scrollView:getInnerContainer()
    local scrollController = {}
    local scrollInfo       = {}
    local barInfoList      = {}
    local recordArray      = {}
    local dataInfoList     = {}
    local startPos         = 1
    local endedPos         = 0
    local isReSize         = false

    local function recordCopy(key, data)
        recordArray[key] = clone(data)
    end

    local function getCopy(key, default)
        local value = recordArray[key]
        return value or default
    end

    local function createBarInfo(uniqueID, tData)
        local barInfo = {
            id      = uniqueID,
            ui      = uiBarBase:clone(),
            data    = tData,
            dirty   = true,
        }
        scrollView:addChild(barInfo.ui)
        return barInfo 
    end

    local function insertUIBar(index, uniqueID, data)
        local barInfo = createBarInfo(uniqueID, data)
        table.insert(barInfoList, index - startPos + 1, barInfo)
        endedPos = endedPos + 1
        return barInfo
    end

    local function removeUIBar(uniqueID)
        local barInfo = HArray.RemoveFirst(barInfoList, "id", uniqueID)
        if not barInfo then return end

        local ui = barInfo.ui
        endedPos = endedPos - 1
        scrollView:removeChild(ui)
    end

    local function onScrollChange(sender, eventType)
        if isReSize then return end
        if eventType == ccui.ScrollviewEventType.scrolling then
            local innerContainer = scrollView:getInnerContainer()
            local posY = innerContainer:getPositionY()
            local isBottom = posY > -1
            if isBottom then
                scrollController:onScrollToBottomBar(endedPos + 1)
                return
            end
        end
    end
    scrollView:addEventListener(onScrollChange)

    local function compulateScrollInfo()
        scrollInfo.barWidth     = uiBarBase:getContentSize().width
        scrollInfo.barHeight    = uiBarBase:getContentSize().height
        scrollInfo.scrollWidth  = innerContainer:getContentSize().width
        scrollInfo.scrollHeight = innerContainer:getContentSize().height
        scrollInfo.width        = scrollView:getContentSize().width
        scrollInfo.height       = scrollView:getContentSize().height
        scrollInfo.scrollY      = innerContainer:getPositionY()
        scrollInfo.scrollX      = innerContainer:getPositionX()
        scrollInfo.barX         = (scrollInfo.width - scrollInfo.barWidth) / 2
    end

    local function resetScrollInfo()
        local barSize = #barInfoList
        local newScrollHeight = barSize * scrollInfo.barHeight
        newScrollHeight = math.max(newScrollHeight, scrollInfo.height)
        local newScrollSize = cc.size(scrollInfo.barWidth, newScrollHeight)
        isReSize = true
        scrollView:setInnerContainerSize(newScrollSize)
        isReSize = false
        compulateScrollInfo()
    end

    local function init()
        recordCopy("startPos", startPos)
        recordCopy("endedPos", endedPos)

        uiBarBase:retain()
        scrollView:removeChild(uiBarBase)
        uiBarBase:setAnchorPoint(cc.p(0,0))

        compulateScrollInfo()
        scrollController:onInit()
    end

    function scrollController:reset()
        startPos     = 1
        endedPos     = 0
        isReSize     = false
        barInfoList  = {}
        dataInfoList = {}
        scrollView:removeAllChildren()
        compulateScrollInfo()
        resetScrollInfo()

        recordCopy("startPos", startPos)
        recordCopy("endedPos", endedPos)
        self:onInit()
    end

    function scrollController:removeData(uniqueID)
        HArray.RemoveFirst(dataInfoList, "id", uniqueID)
        removeUIBar(uniqueID)
    end

    function scrollController:insertData(index, uniqueID, data)
        table.insert(dataInfoList, index, { id = uniqueID, data = data})
        insertUIBar(index, uniqueID, data)
    end

    function scrollController:pushData(uniqueID, data)
        local position = #dataInfoList + 1
        self:insertData(position, uniqueID, data)
    end

    function scrollController:getDataByIndex(index)
        local dataInfo = dataInfoList[index]
        if not dataInfo then return nil end
        return dataInfo.data
    end

    function scrollController:getUniqueIDByIndex(index)
        local dataInfo = dataInfoList[index]
        if not dataInfo then return nil end
        return dataInfo.id
    end

    function scrollController:getUIBarByID(uniqueID)
        return HArray.FindFirst(barInfoList, "id", uniqueID)
    end

    function scrollController:getScrollInfo()
        return scrollInfo
    end

    function scrollController:refreshUIBar(uniqueID, newData)
        local barInfo = HArray.FindFirst(barInfoList, "id", uniqueID)
        if barInfo then
            local data = newData or barInfo.data
            self:onRefreshUIBar(barInfo.ui, uniqueID, data)
        end
    end 

    function scrollController:refresh()
        compulateScrollInfo()
        recordCopy("scrollInfo", scrollInfo)
        resetScrollInfo()
        
        local barX = scrollInfo.barX
        local barW = scrollInfo.barWidth
        local barH = scrollInfo.barHeight
        local scrH = scrollInfo.scrollHeight
        local viewH = scrollInfo.height

        for index, barInfo in ipairs(barInfoList) do
            if barInfo.dirty then
                local id   = barInfo.id
                local ui   = barInfo.ui
                local data = barInfo.data
                scrollController:onRefreshUIBar(ui, id, data)
                barInfo.dirty = false
            end

            local uiBar = barInfo.ui
            local barY  = scrH - index * barH
            uiBar:setPosition(cc.p(barX, barY))
        end

        local oldScrollInfo = getCopy("scrollInfo", nil)
        local oldstartPos = getCopy("startPos", 1)
        local oldendedPos = getCopy("endedPos", 0)

        assert(oldScrollInfo)
        local oldScrH   = oldScrollInfo.scrollHeight
        local oldScrY   = oldScrollInfo.scrollY
        local addRearH  = (endedPos - oldendedPos) * barH
        local newScrY   = oldScrY - addRearH
        local headH     = scrH - viewH + newScrY
        local headP     = math.min(100, math.max(0, headH / (scrH - viewH) * 100))

        scrollView:jumpToPercentVertical(headP)

        recordCopy("startPos", startPos)
        recordCopy("endedPos", endedPos)
    end

    function scrollController:forceRefresh()
        for _, barInfo in ipairs(barInfoList) do
            barInfo.dirty = true
        end
        self:refresh()
    end

    function scrollController:release()
        uiBarBase:release()
    end

    function scrollController:onRefreshUIBar(uiBar, id, data)
        if funcRefreshUIBar then
            funcRefreshUIBar(uiBar, id, data)
        end
    end

    function scrollController:onScrollToBottomBar(index)
        if funcOnScrollToBottom then
            funcOnScrollToBottom(self, index)
        end
    end

    function scrollController:onInit()
        if funcInit then
            funcInit(self)
        end
    end

    init()
    return scrollController
end

local function requestUpdateMailData(self, mailID)
    local requestIDList   = self._requestIDList
    local waittingRequest = self._waittingRequest
    local lastRequestTime = self._lastRequestTime
    local nowTime         = os.time()
    local requestInterval = 0 
    local function onRequest()
        if #requestIDList == 0 then return end
        self._waittingRequest = true
        require("src/network/KC2SProtocolManager"):requestMailData(requestIDList)
    end

    HArray.UniqueInsertByValue(requestIDList, mailID)
    if requestInterval < nowTime - lastRequestTime then
        delayExecute(self._mainLayout, onRequest, requestInterval)
        self._lastRequestTime = nowTime
    end
end

local function refreshScrollUIBar(self, uiBar, mailID)
    local oneMail   = HArray.FindFirstByID(KPlayer.tMailData.tMailList, mailID)
    if oneMail == nil then return end
    
    local unOpen    = oneMail.bOpen == false
    local award     = oneMail.bAward == true

    local imageIcon = uiBar:getChildByName("Image_icon_mailbox")
    imageIcon:setVisible(unOpen and award)

    local imageIcon = uiBar:getChildByName("Image_icon_mailbox_active")
    imageIcon:setVisible(not unOpen and award)

    local ImageIcon = uiBar:getChildByName("Image_icon_package")
    ImageIcon:setVisible(not award)

    if not oneMail.tMailData then
        requestUpdateMailData(self, oneMail.nID)
        return
    end

    local textTitle = uiBar:getChildByName("Text_title")
    textTitle:setString(oneMail.tMailData.szTitle)

    local textDate   = uiBar:getChildByName("Text_date")
    local date       = os.date("*t", oneMail.tMailData.nSendTime)
    local formatDate = string.format("%s/%s/%s %02d:%02d", date.year, date.month, date.day, tonumber(date.hour), tonumber(date.min))
    textDate:setString(formatDate) 

    local function onBarUnitClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        assert(oneMail.tMailData ~= nil, "oneMail.nID:" .. oneMail.nID .. " mailID:" .. mailID)
        if oneMail.tMailData == nil then return end
        local barWidth    = self._scrollController:getScrollInfo().barWidth
        local nodeData = {
            oneMailID  = mailID,
        }
        self._parent:addNode("Mail", nodeData)
        if not oneMail.bOpen then
            require("src/network/KC2SProtocolManager"):requestOpenMail(mailID)
        end
    end
    uiBar:addTouchEventListener(onBarUnitClick)
end

local function notifyUpdateMailData(self, mailIDList)
    local requestIDList = self._requestIDList
    local scrollController = self._scrollController
    for _, mailID in ipairs(mailIDList) do
        scrollController:pushData(mailID)
        HArray.RemoveFirstByValue(requestIDList, mailID)
    end

    scrollController:refresh()
    self._waittingRequest = false
end

local function getOneMailByIndex(self, index)
    local mailID = self._mailIDList[index]
    if not mailID then
        return
    end

    local allMailList = KPlayer.tMailData.tMailList
    return HArray.FindFirstByID(allMailList, mailID)
end

local function initMailIDList(self)
    local allMailList = KPlayer.tMailData.tMailList
    local mailIDList  = {}
    for i, v in ipairs(allMailList) do
        table.insert(mailIDList, v.nID)
    end
    self._mailIDList = mailIDList
end

local function initScrollViewUI(self, scrollController)
    local count = 10
    local index = 0
    local allMailList = KPlayer.tMailData.tMailList

    while count > 0 do
        count = count - 1
        index = index + 1

        local oneMail = allMailList[index]
        if not oneMail then
            break
        end

        if not oneMail.tMailData then
            requestUpdateMailData(self, oneMail.nID)
        else
            scrollController:pushData(oneMail.nID)
        end
    end
end

local function initUI(self)
    assert(self._scrollController == nil, "init ui twice")

    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_mailbox")
    local imageMailBase = projectNode:getChildByName("Image_mailbox_base")
    local scrollView    = imageMailBase:getChildByName("ScrollView_mailbox_list")
    local uiBarBase     = scrollView:getChildByName("Button_mailbox_list")
    local textDate      = uiBarBase:getChildByName("Text_date")
    textDate:setAnchorPoint(cc.p(1.0, 0.5))

    local parameters = {}
    parameters.scrollView = scrollView
    parameters.uiBarBase = uiBarBase
    parameters.funcRefreshUIBar = function(uiBar, mailID, data)
        refreshScrollUIBar(self, uiBar, mailID)
    end

    parameters.funcOnScrollToBottom = function(scrollController, index)
        if self._waittingRequest then return end
        if index > #self._mailIDList then return end
        local count = 10
        local nextIndex = index - 1
        local needRefresh = false

        for i = 1, count do
            nextIndex = nextIndex + 1
            count = count - 1

            local oneMail = getOneMailByIndex(self, nextIndex)
            if not oneMail then
                break
            end

            if not oneMail.tMailData then
                requestUpdateMailData(self, oneMail.nID)
            else
                scrollController:insertData(nextIndex, oneMail.nID)
                needRefresh = true
            end
        end

        if needRefresh then
            scrollController:refresh()
        end
    end

    parameters.funcInit = function(scrollController)
        initMailIDList(self)
        initScrollViewUI(self, scrollController)
    end

    self._scrollController = createScrollController(parameters)
end

local function getCanRemoveMailIDList(self)
    local allMailList = KPlayer.tMailData.tMailList
    local selectedMailIDList = {}
    for _, oneMail in ipairs(allMailList) do
        if oneMail.bOpen and oneMail.bAward then
            table.insert(selectedMailIDList, oneMail.nID)
        end
    end
    return selectedMailIDList
end

local function deleteUnuseMail(self)
    self._scrollController:reset()
    self:refreshUI()
    self._waitDelete = false
end

local function getFrameAction(self, startFrame, endedFrame)
    local duration   = (endedFrame - startFrame) / 60

    local function callAnimation()
        local mainNode = self._mainLayout
        local projectNode = mainNode:getChildByName("ProjectNode_mailbox")
        local actionName = "ani_mailbox_list"
        KUtil.playAnimation(projectNode,  actionName, startFrame, endedFrame)
    end
    
    local callAction  = cc.CallFunc:create(callAnimation)
    local frameDelay  = cc.DelayTime:create(duration)
    local frameAction = cc.Sequence:create(callAction, frameDelay)

    return frameAction, duration
end

function KUIMailListNode:updateMailState(mailID)
    if mailID == nil then return end
    self._scrollController:refreshUIBar(mailID)
end

function KUIMailListNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mailbox")
    projectNode:stopAllActions()
end

function KUIMailListNode:getEnterAction()
    local startFrame = 0
    local endedFrame = 26
    local enterAction, duration = getFrameAction(self, startFrame, endedFrame)
    return enterAction, duration
end

function KUIMailListNode:getExitAction()
    local startFrame = 50
    local endedFrame = 65
    local exitAction, duration = getFrameAction(self, startFrame, endedFrame)
    return exitAction, duration
end

function KUIMailListNode:refreshUI()
    if not self._scrollController then
        initUI(self)
    end
    self._scrollController:forceRefresh()
end

function KUIMailListNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_mailbox")
    local imageMailBase = projectNode:getChildByName("Image_mailbox_base")
    local scrollView      = imageMailBase:getChildByName("ScrollView_mailbox_list")
    local buttonClose     = imageMailBase:getChildByName("Button_close")

    local function onCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onHomeButton~")   
        KSound.playEffect("close") 
        self._parent:removeNode("MailList")
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonDelete = imageMailBase:getChildByName("Button_delete_read")
    local function onDeleteClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onDeleteButton~")
        if self._waitDelete then return end
        local mailIDList = getCanRemoveMailIDList(self)
        if #mailIDList == 0 then return end

        local function onConfirm()
            self._waitDelete = true
            require("src/network/KC2SProtocolManager"):requestRemoveMailList(mailIDList)
        end

        local confirmMessage = KUtil.getStringByKey("mail.requireDelete")
        showConfirmation(confirmMessage, onConfirm)
    end
    buttonDelete:addTouchEventListener(onDeleteClick)
end

function KUIMailListNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onUpdateMailList(mailIDList)
        cclog("onEvent ---------->onUdpateMailList, mailIDList:%s", mailIDList)
        notifyUpdateMailData(self, mailIDList)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MAIL_DATA, onUpdateMailList)

    local function onUpdateNewMail(nID)
        cclog("onEvent ---------->onUpdateNewMail, mailID:%s", nID)
        table.insert(self._mailIDList, 1, nID)
        local scrollController = self._scrollController
        if scrollController then
            scrollController:insertData(1, nID)
            scrollController:refresh()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_RECEIVE_NEW_MAIL, onUpdateNewMail)

    local function onRemoveMail()
        deleteUnuseMail(self)
        cclog("onEvent ---------->onRemoveMail")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_REMOVE_MAIL, onRemoveMail)

    local function onRefreshMailList()
        cclog("onEvent ---------->onRefreshMailList")
        self:refreshUI() 
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SYNC_MAIL_LIST, onRefreshMailList)
end

function KUIMailListNode:onCleanup()
    if self._scrollController then
        self._scrollController:release()
    end 
end

return KUIMailListNode
