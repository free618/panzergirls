--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRaidersNode.lua
--  Creator     : liulingli
--  Date        : 2015/11/25   16:36
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_KSetting
local m_DefaultContentSize  = 22
local m_DefaultContentColor = cc.c3b(104, 72, 43)
local m_FontFilePath        = KUtil.FONT_PATH
local m_RowSpacing          = 13

local KUIRaidersNode = class(
    "KUIRaidersNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRaidersNode:ctor()
    self._mainLayout         = nil
    self._parent             = nil
    self._currentLeftIndex   = nil
    self._currentBottomIndex = nil
end

function KUIRaidersNode.create(owner)
    local currentNode   = KUIRaidersNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_raiders.csb"
    currentNode:init()

    return currentNode
end

local function playRaiderAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_1")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_raiders_window"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_1")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playRaiderAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Raiders", callBacks, isReturnOffice)
end

function KUIRaidersNode:getEnterAction()
end

function KUIRaidersNode:getExitAction()
end

local function initPageData(self)
    m_KSetting = require("src/logic/KSetting")
    self._currentLeftIndex   = m_KSetting.getInt(m_KSetting.Key.RAIDERS_PAGE, 1)
    self._currentBottomIndex = m_KSetting.getInt(m_KSetting.Key.RAIDERS_INDEX, 1)
end

local function initLeftLabelUI(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelLeft    = imageBase:getChildByName("Panel_label_big")
    local panelBase         = panelLabelLeft:getChildByName("Panel_label_big")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel  = panelBase:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end
        local textSelect   = buttonLabel:getChildByName("Text_label_2")
        textSelect:setVisible(false)

        local textLabel = buttonLabel:getChildByName("Text_label_1")

        local tPageConfig = KConfig:getLine("raiderspage", i)
        if tPageConfig then
            buttonLabel:setVisible(true)
            textLabel:setString(tPageConfig.szName)
            textSelect:setString(tPageConfig.szName)
        else
            buttonLabel:setVisible(false)
        end
    end
end

local function refreshBottomLabelTitle(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelBottom  = imageBase:getChildByName("Panel_label_small")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel = panelLabelBottom:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end

        local textLabel = buttonLabel:getChildByName("Text_label")

        local labelIndex = i
        local tTextConfig = KConfig:getLine("raiders", self._currentLeftIndex, labelIndex)
        if tTextConfig then
            buttonLabel:setVisible(true)
            textLabel:setString(tTextConfig.szName)
        else
            buttonLabel:setVisible(false)
        end
    end
end

function KUIRaidersNode:onInitUI()
    stopAllAnimation(self)
    initPageData(self)
    initLeftLabelUI(self)
end

function KUIRaidersNode:onEnterActionFinished()
    playRaiderAnimation(self, true)
end

local function refreshLeftLabelUI(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelLeft    = imageBase:getChildByName("Panel_label_big")
    local panelBase         = panelLabelLeft:getChildByName("Panel_label_big")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel  = panelBase:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end

        local textLabel = buttonLabel:getChildByName("Text_label_1")
        local textSelect   = buttonLabel:getChildByName("Text_label_2")

        local labelIndex = i
        if labelIndex == self._currentLeftIndex then
            buttonLabel:setBrightStyle(1)
            buttonLabel:setTouchEnabled(false)
            textLabel:setVisible(false)
            textSelect:setVisible(true)
        else
            buttonLabel:setBrightStyle(0)
            buttonLabel:setTouchEnabled(true)
            textLabel:setVisible(true)
            textSelect:setVisible(false)
        end
    end
end

local function refreshBottomLabelUI(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelBottom  = imageBase:getChildByName("Panel_label_small")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel = panelLabelBottom:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end

        if i == self._currentBottomIndex then
            buttonLabel:setTouchEnabled(false)
            buttonLabel:setBrightStyle(1)
        else
            buttonLabel:setTouchEnabled(true)
            buttonLabel:setBrightStyle(0)
        end
    end
end

local function refreshPageContent(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local scrollViewText    = imageBase:getChildByName("ScrollView_1")
    local tTextConfig       = KConfig:getLine("raiders", self._currentLeftIndex, self._currentBottomIndex)
    if not tTextConfig then return end

    local sizeScrollView  = scrollViewText:getContentSize()
    local nHeight         = tTextConfig.nHeight
    if nHeight < sizeScrollView.height then
        nHeight = sizeScrollView.height
    end
    local nWidth          = sizeScrollView.width
    local richText        = ccui.RichText:create()
    richText:ignoreContentAdaptWithSize(false)
    richText:setContentSize(nWidth, nHeight)
    richText:setVerticalSpace(m_RowSpacing)

    for i, tText in ipairs(tTextConfig.lszText) do
        local szText    = tText
        local color     = m_DefaultContentColor
        local nFontSize = m_DefaultContentSize
	if type(tText) == "table" then
            szText      = tText[1]
            if tText[2] then nFontSize = tText[2] end
            if tText[3] then color     = cc.c3b(unpack(tText[3], 1, table.maxn(tText[3]))) end
        end
        local richElementText = ccui.RichElementText:create(i, color, 255, szText, m_FontFilePath, nFontSize)
        richText:pushBackElement(richElementText)
    end

    scrollViewText:removeAllChildren()
    scrollViewText:setInnerContainerSize(cc.size(nWidth, nHeight))
    scrollViewText:addChild(richText)
    richText:setPosition(cc.p(nWidth/2, nHeight/2))
    scrollViewText:jumpToTop()

    local sliderControl   = imageBase:getChildByName("Slider_1")
    sliderControl:setPercent(0)
end

function KUIRaidersNode:refreshUI()
    refreshLeftLabelUI(self)
    refreshBottomLabelTitle(self)
    refreshBottomLabelUI(self)
    refreshPageContent(self)
end

function KUIRaidersNode:refreshPage(nShowPage)
    self._currentLeftIndex   = nShowPage
    self._currentBottomIndex = 1
    m_KSetting.setInt(m_KSetting.Key.RAIDERS_PAGE, self._currentLeftIndex)
    m_KSetting.setInt(m_KSetting.Key.RAIDERS_INDEX, self._currentBottomIndex)
    self:refreshUI()
end

function KUIRaidersNode:refreshText(nShowTextIndex)
    self._currentBottomIndex = nShowTextIndex
    m_KSetting.setInt(m_KSetting.Key.RAIDERS_INDEX, self._currentBottomIndex)

    refreshBottomLabelUI(self)
    refreshPageContent(self)
end

local function registerLeftLabelEvent(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelLeft    = imageBase:getChildByName("Panel_label_big")
    local panelBase         = panelLabelLeft:getChildByName("Panel_label_big")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel  = panelBase:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end

        local labelIndex = i
        local function onLeftLabelClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")

                self._currentLeftIndex   = labelIndex
                self._currentBottomIndex = 1
                m_KSetting.setInt(m_KSetting.Key.RAIDERS_PAGE, labelIndex)
                m_KSetting.setInt(m_KSetting.Key.RAIDERS_INDEX, self._currentBottomIndex)

                self:refreshUI()
            end
        end
        buttonLabel:addTouchEventListener(onLeftLabelClick)
    end
end

local function registerBottomLabelEvent(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local panelLabelBottom  = imageBase:getChildByName("Panel_label_small")

    local i = 0
    while true do
        i = i + 1
        local buttonLabel = panelLabelBottom:getChildByName("Button_label_" .. i)
        if not buttonLabel then break end

        local labelIndex = i
        local function onBottomLabelClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")

                self._currentBottomIndex = labelIndex
                m_KSetting.setInt(m_KSetting.Key.RAIDERS_INDEX, labelIndex)

                refreshBottomLabelUI(self)
                refreshPageContent(self)
            end
        end
        buttonLabel:addTouchEventListener(onBottomLabelClick)
    end
end

function KUIRaidersNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")
    local imageBase     = projectNode:getChildByName("Image_base")

    -- close button
    local buttonClose   = imageBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("close")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local scrollControl   = imageBase:getChildByName("ScrollView_1")
    local sliderControl   = imageBase:getChildByName("Slider_1")
    local function onSliderChanged(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(sliderControl:getPercent())

            local percent = KUtil.getScrollViewPercent(scrollControl)
            sliderControl:setPercent(percent)
        end
    end
    sliderControl:addEventListener(onSliderChanged)

    local function onScrollChanged(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        sliderControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChanged)

    registerLeftLabelEvent(self)
    registerBottomLabelEvent(self)
end

return KUIRaidersNode
