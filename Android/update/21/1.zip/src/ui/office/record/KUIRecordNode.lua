--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRecordNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/09/14   16:23
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  ********************************************************************


local KUIRecordNode = class(
    "KUIRecordNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRecordNode:ctor()
    self._parent                = nil
    self._mainLayout            = nil
    self._uiPath                = nil
end

function KUIRecordNode.create(owner)
    local currentNode   = KUIRecordNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_record.csb"
    currentNode:init()

    return currentNode
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Record", callBacks, isReturnOffice)
end

local function getMaxPlayerExp(level)
    local tLevel = KConfig.levelInfo[level]
    if tLevel then return tLevel.nRoleExp end
    return 0
end

local function refreshBaseInformation(self)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local imageMainBase   = imageCommonBase:getChildByName("Image_zj_base")
    
    local playerName      = KPlayer.name
    local playerLevel     = KPlayer.level
    local playerExp       = KPlayer.exp
    local rankImagePath   = KUtil.getRankImagePath(1)
    local displayCard     = KUtil.getTeamLeaderCard(1)
    assert(displayCard, "Can not find card for displaying !")
    local cardImagePath   = KUtil.getScaleCardImagePath(displayCard)

    local imageCharacter = imageMainBase:getChildByName("Image_common_chara")
    imageCharacter:loadTexture(cardImagePath)
    
    local imageInfoBase   = imageMainBase:getChildByName("Image_info_base")
    local textPlayerName  = imageInfoBase:getChildByName("Text_name")
    textPlayerName:setString(playerName)
    
    local imageRankIcon   = imageMainBase:getChildByName("Image_rank_icon")
    imageRankIcon:loadTexture(rankImagePath)
    
    local textLevelValue  = imageInfoBase:getChildByName("Text_level_value")
    textLevelValue:setString(playerLevel)
     
    local textExpValue    = imageInfoBase:getChildByName("Text_exp_value")
    textExpValue:setString(playerExp .. "/" .. getMaxPlayerExp(playerLevel))
    
    local textFieldSign   = mainNode:getChildByName("TextField_sign")
    if KPlayer.tRankData.tRoleRank then
        local signature   = KPlayer.tRankData.tRoleRank.message
        textFieldSign:setString(signature)
    end
end

local function refreshBattleInformation(self)
    local mainNode         = self._mainLayout
    local imageCommonBase  = mainNode:getChildByName("Image_common_base")
    local imageMainBase    = imageCommonBase:getChildByName("Image_zj_base")

    local totalLaunchCount = KPlayer.tRecordData.tLaunchData.nLaunchCount
    local launchWinCount   = KPlayer.tRecordData.tLaunchData.nLaunchWinCount
    local launchLoseCount  = totalLaunchCount - launchWinCount
    local launchWinRate    = 0
    if totalLaunchCount ~= 0 then
        launchWinRate      = launchWinCount * 100 / totalLaunchCount 
    end

    local textLaunchWinValue  = imageMainBase:getChildByName("Text_launch_win_value")
    textLaunchWinValue:setString(launchWinCount)
    
    local textLaunchLoseValue = imageMainBase:getChildByName("Text_launch_lose_value")
    textLaunchLoseValue:setString(launchLoseCount)
    
    local cardCollectRate     = KUtil.getCardCollectRate()
    local textCardRateValue   = imageMainBase:getChildByName("Text_card_rate_value")
    textCardRateValue:setString(string.format("%.2f%%", cardCollectRate))

    local equipCollectRate    = KUtil.getEquipCollectRate()
    local textEquipRateValue  = imageMainBase:getChildByName("Text_equip_rate_value")
    textEquipRateValue:setString(string.format("%.2f%%", equipCollectRate))

    local textLaunchWinRate   = imageMainBase:getChildByName("Text_launch_win_rate")
    textLaunchWinRate:setString(string.format("%.2f%%", launchWinRate))
    
    local totalExerciseCount  = KPlayer.tRecordData.tExerciseData.nExerciseCount
    local exerciseWinCount    = KPlayer.tRecordData.tExerciseData.nExerciseWinCount
    local exerciseLoseCount   = totalExerciseCount - exerciseWinCount
    local exerciseWinRate     = 0
    if totalExerciseCount ~= 0 then
        exerciseWinRate       = exerciseWinCount * 100 / totalExerciseCount
    end

    local textExerciseWinValue  = imageMainBase:getChildByName("Text_exercise_win_value")
    textExerciseWinValue:setString(exerciseWinCount)
    
    local textExerciseLoseValue = imageMainBase:getChildByName("Text_exercise_lose_value")
    textExerciseLoseValue:setString(exerciseLoseCount)
    
    local textExerciseWinRate   = imageMainBase:getChildByName("Text_exercise_win_rate")
    textExerciseWinRate:setString(string.format("%.2f%%", exerciseWinRate))
end

local function refreshLimitInformation(self)
    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local imageMainBase        = imageCommonBase:getChildByName("Image_zj_base")
    
    local maxTeamCount         = KPlayer.tTeamData.nMaxCount
    local maxTankCount         = KPlayer.tCardData.tStoreHouse.nMaxSize
    local maxWeaponCount       = KPlayer.tItemData.tEquipStoreHouse.nMaxSize
    local maxResourceCount     = KConfig.playerLevelInfo[(KPlayer.level)]["nMaxOil"]
    
    local textTeamLimitValue   = imageMainBase:getChildByName("Text_team_limit_value")
    textTeamLimitValue:setString(maxTeamCount)
    
    local textTankLimitValue   = imageMainBase:getChildByName("Text_tank_limit_value")
    textTankLimitValue:setString(maxTankCount)
    
    local textWeaponLimitValue = imageMainBase:getChildByName("Text_weapon_limit_value")
    textWeaponLimitValue:setString(maxWeaponCount)
    
    local textSupplyLimitValue = imageMainBase:getChildByName("Text_supply_limit_value")
    textSupplyLimitValue:setString(maxResourceCount)
end

local function refreshOtherInformation(self)
    local mainNode            = self._mainLayout
    local imageCommonBase     = mainNode:getChildByName("Image_common_base")
    local imageMainBase       = imageCommonBase:getChildByName("Image_zj_base")
    
    local teamNumber          = KPlayer.tTeamData.nOpenCount
    local factoryBarNumber    = KPlayer.nBuildBarNum
    local repairBarNumber     = KPlayer.nRepairBarNum
    local tankNumber          = KUtil.getCardCount()
    local weaponNumber        = #KPlayer.tItemData.tEquipStoreHouse.tEquipList
    local furnitureNumber     = KUtil.getFurnitrureCount()
    local serviceName         = KPlayer.serverName
    
    local textTeamNumber      = imageMainBase:getChildByName("Text_team_value")
    textTeamNumber:setString(teamNumber)
    
    local textFactoryNumber   = imageMainBase:getChildByName("Text_factory_value")
    textFactoryNumber:setString(factoryBarNumber)
    
    local textRepairNumber    = imageMainBase:getChildByName("Text_repair_value")
    textRepairNumber:setString(repairBarNumber)
    
    local textTankNumber      = imageMainBase:getChildByName("Text_tank_value")
    textTankNumber:setString(tankNumber)
    
    local textWeaponNumber    = imageMainBase:getChildByName("Text_weapon_value")
    textWeaponNumber:setString(weaponNumber)
    
    local textFurnitureNumber = imageMainBase:getChildByName("Text_furniture_value")
    textFurnitureNumber:setString(furnitureNumber)
    
    local textServiceName     = imageMainBase:getChildByName("Text_service")
    textServiceName:setString(serviceName)
end

local function playLeaderTalk()
    local  displayCard = KUtil.getTeamLeaderCard()
    if displayCard then
        KSound.playTalk(KSound.TALK.COMBATGAINS, displayCard.nTemplateID)
    end
end

function KUIRecordNode:refreshUI()
    refreshBaseInformation(self)
    refreshBattleInformation(self)
    refreshLimitInformation(self)
    refreshOtherInformation(self)
    playLeaderTalk(self)
end

function KUIRecordNode:registerAllTouchEvent()
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")

    -- home button
    local projectNodeButtonHome = mainNode:getChildByName("ProjectNode_button_home")
    local panelCommonBase       = projectNodeButtonHome:getChildByName("Panel_common_home")
    local buttonControl         = panelCommonBase:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._parent:returnOffice()
            KSound.playEffect("click")
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    local function onCloseCallBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, onCloseCallBack, "zj_base")
    
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local imageZjBase     = imageCommonBase:getChildByName("Image_zj_base")
    local inputText       = mainNode:getChildByName("TextField_sign")
    local currentString   = ""
    local function textFieldEvent(sender, eventType)
        if eventType == ccui.TextFiledEventType.attach_with_ime then
            currentString = inputText:getString()
        elseif eventType == ccui.TextFiledEventType.detach_with_ime then
            --check same
            local inputString = inputText:getString()
            if currentString == inputString then return end
            -- too short
            if string.len(inputString) <= 0 then 
                showNotice(KUtil.getStringByKey("common.inputError")) 
                return 
            end
            -- too long
            local shortString = KUtil.subString(inputString, 20)
            if shortString ~= inputString then 
                showNotice(KUtil.getStringByKey("common.inputLong")) 
                return 
            end
            -- sensitive word
            if KUtil.hasSensitiveWord(inputString) then 
                showNotice(KUtil.getStringByKey("common.hasSensitiveWord")) 
                return 
            end
            -- save
            require("src/network/KC2SProtocolManager"):requestUpdateRankMessage(inputString)
        end
    end
    inputText:addEventListener(textFieldEvent)
end

function KUIRecordNode:registerAllCustomEvent()
    local function updateRankDate()
        refreshBaseInformation(self)
    end
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_ROLE_RANK, updateRankDate)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIRecordNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

local function stopAllAnimation(self)
    KUtil.stopCommonAnimation(self)
end

function KUIRecordNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
end

function KUIRecordNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
end

function KUIRecordNode:onNodeEnter()
    require("src/network/KC2SProtocolManager"):requestRoleRankData()
end

return KUIRecordNode
