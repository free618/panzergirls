--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairRebornMethodNode.lua
--  Creator     : HuangYiXin
--  Date        : 2015/08/22   10:20
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_TANK_TYPE_COUNT    = 6

local REBORN_ITEM_TEMPLATE_ID    = 3
local COST_REBORN_ITEM_COUNT     = 1

local KUIRepairRebornMethodNode = class(
    "KUIRepairRebornMethodNode", function () return require("src/ui/uibase/KUINodeBase.lua").create() end 
)

function KUIRepairRebornMethodNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil

    self._selectedCardID    = nil
    self._rebornCardID      = nil
    self._applyedReborn     = false
end

function KUIRepairRebornMethodNode.create(owner, nodeData)
    local currentNode = KUIRepairRebornMethodNode.new()

    currentNode._selectedCardID = nodeData.cardID

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_reborn_method.csb"
    currentNode:init()

    return currentNode
end

local function checkItemState(self)
    local rebornItemCount = KUtil.getItemCount(REBORN_ITEM_TEMPLATE_ID)
    local passed = nil
    passed = rebornItemCount >= COST_REBORN_ITEM_COUNT
    if not passed then
        local rebornItemName = KUtil.getItemConfigValue(REBORN_ITEM_TEMPLATE_ID, "szName")
        showNoticeByID("factory.lessResource", rebornItemName)
    end

    return passed
end

local function applyRebornCardByFriend(self)
    if self._applyedReborn then return end
    local deadCardID = self._selectedCardID
    --self._applyedReborn = true
    --assert(false, "reborn dead card by firends is not currently supported")
end

local function applyRebornCardByItem(self)
    if self._applyedReborn then return end
    local deadCardID = self._selectedCardID

    if checkItemState(self) == true then
        local rebornItemName = KUtil.getItemConfigValue(REBORN_ITEM_TEMPLATE_ID, "szName")
        local formatString   = KUtil.getStringByKey("common.promptCostItem")
        local confirmMessage = string.format(formatString, COST_REBORN_ITEM_COUNT, rebornItemName) 

        local function confirmCostItem()
            self._applyedReborn = true
            require("src/network/KC2SProtocolManager"):rebornCardByCostItem(deadCardID)       
        end        

        local function cancelCostItem()

        end

        showConfirmation(confirmMessage, confirmCostItem, cancelCostItem)
    end
end

local function playPanelRebornButtonEffect(self, startFrameIndex, endFrameIndex)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local nodeButtonBase    = imageCommonBase:getChildByName("ProjectNode_button_base")
    local rebornButtonCutEffect = cc.CSLoader:createTimeline("res/ui/animation_node/ani_reborn_button.csb")

    local totalFrameCount = 61
    local isLoop = false

    nodeButtonBase:stopAllActions()
    nodeButtonBase:runAction(rebornButtonCutEffect)
    rebornButtonCutEffect:gotoFrameAndPlay(startFrameIndex, endFrameIndex, isLoop) 

    local effectTimeStep   = rebornButtonCutEffect:getTimeSpeed()
    local effectDuration   = rebornButtonCutEffect:getDuration() * ( effectTimeStep / 60 )
    local effectFrameCount = endFrameIndex - startFrameIndex
    local totalDuration    = effectDuration * effectFrameCount / totalFrameCount
    return totalDuration     
end

local function playPanelRebornButtonCutInEffect(self)
    local startFrameIndex = 31        
    local endFrameIndex   = 59
    return playPanelRebornButtonEffect(self, startFrameIndex, endFrameIndex)
end

local function playPanelRebornButtonCutOffEffect(self)
    local startFrameIndex = 0        
    local endFrameIndex   = 31
    return playPanelRebornButtonEffect(self, startFrameIndex, endFrameIndex)    
end

local function playRebornCardEffect(self)
    local mainNode         = self._mainLayout
    local imageCommonBase  = mainNode:getChildByName("Image_common_base")
    local nodeCardRoot     = imageCommonBase:getChildByName("ProjectNode_card")

    local rebornCardEffect = cc.CSLoader:createTimeline("res/ui/animation_node/ani_reborn.csb")
    local startFrameIndex  = 0
    local endFrameIndex    = 50
    local totalFrameCount  = 51
    local isLoop           = false

    nodeCardRoot:stopAllActions()
    nodeCardRoot:runAction(rebornCardEffect)
    rebornCardEffect:gotoFrameAndPlay(startFrameIndex, endFrameIndex, isLoop)

    local effectTimeStep   = rebornCardEffect:getTimeSpeed()
    local effectDuration   = rebornCardEffect:getDuration() * ( effectTimeStep / 60 )
    local effectFrameCount = endFrameIndex - startFrameIndex
    local totalDuration    = effectDuration * effectFrameCount / totalFrameCount
    return totalDuration          
end

local function switchUI(self, toNodeType)
    local nodeExitDelay = self._parent:removeNode("RebornMethod")
    local parent        = self._parent
    local rebornCardID  = self._rebornCardID
    local function switchNode()
        if toNodeType == "RebornChoice" then
            local rebornChoiceNode = parent:getNode(toNodeType)
            if rebornChoiceNode == nil then return end
            local hasReborn = rebornCardID ~= nil
            rebornChoiceNode:notifyReturnResult(hasReborn, rebornCardID)
        else
            parent:addNode(toNodeType)
            parent:removeNode("RebornChoice")
        end
    end
    delayExecute(parent, switchNode, nodeExitDelay)
end

local function onCardReborn(self, cardID)
    local rebornEffectDelay = playRebornCardEffect(self)

    local function returnBackChoiceView()
        switchUI(self, "RebornChoice")
    end
    delayExecute(self, returnBackChoiceView, rebornEffectDelay)
end

local function refreshNodeCardRoot(self)
    local mainNode         = self._mainLayout
    local imageCommonBase  = mainNode:getChildByName("Image_common_base")
    local nodeCardRoot     = imageCommonBase:getChildByName("ProjectNode_card")

    local deadCardID = self._selectedCardID
    local oneCard    = KUtil.getDeadCardById(deadCardID)

    local buttonCardBase = nodeCardRoot:getChildByName("Button_card_base")
    buttonCardBase:setTouchEnabled(false)

    local textLevel = buttonCardBase:getChildByName("Text_level")
    textLevel:setString(oneCard.nLevel)

    local projectCard = buttonCardBase:getChildByName("ProjectNode_card")
    KUtil.drawCardByConfigID(projectCard, oneCard.nTemplateID)

    nodeCardRoot:stopAllActions()
end

local function refreshRebornChoiceArea(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local nodeButtonBase    = imageCommonBase:getChildByName("ProjectNode_button_base")
    local panelButtonBase   = nodeButtonBase:getChildByName("Panel_button_base")
    local imageButtonBase   = panelButtonBase:getChildByName("Image_button_base")

    local textFriends = imageButtonBase:getChildByName("Text_friends")
    --TODO:
    local currentLoginFriendCount = "?"
    local friendCount = "?"
    textFriends:setString( currentLoginFriendCount .. "/" .. friendCount)
end

local function refreshBaseInfoArea(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local imageBase         = imageCommonBase:getChildByName("Image_xl_base")

    local textRebornTimes   = imageBase:getChildByName("Text_highspeed_repair_value")
    local rebornItemCount   = KUtil.getItemCount(REBORN_ITEM_TEMPLATE_ID)
    textRebornTimes:setString(rebornItemCount)     
end

function KUIRepairRebornMethodNode:runEnterAction()
    cclog("KUINodeBase:runEnterAction")
    assert(self._mainLayout ~= nil)
    -- override the method to play the reborn button enter effect
    return playPanelRebornButtonCutInEffect(self)
end

function KUIRepairRebornMethodNode:runExitAction() -- please let scene call this and clean node
    cclog("KUINodeBase:runExitAction")
    return playPanelRebornButtonCutOffEffect(self)
end

local function refreshRedPoint(self)
    KUtil.refreshRepairRedPoint(self)
end

function KUIRepairRebornMethodNode:refreshUI()
    refreshBaseInfoArea(self)
    refreshNodeCardRoot(self)
    refreshRebornChoiceArea(self)
    refreshRedPoint(self)
end

function KUIRepairRebornMethodNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local buttonHome        = mainNode:getChildByName("Button_home")
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local buttonClose       = imageCommonBase:getChildByName("Button_close")

    local function onHomeClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onHomeClick~")
        self._parent:returnOffice()
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local function onCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onCloseClick~")
        switchUI(self, "RebornChoice")
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local nodeButtonBase    = imageCommonBase:getChildByName("ProjectNode_button_base")
    local panelButtonBase   = nodeButtonBase:getChildByName("Panel_button_base")
    local imageButtonBase   = panelButtonBase:getChildByName("Image_button_base")

    local buttonTool = imageButtonBase:getChildByName("Button_prop")
    local function onToolClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onToolClick~")
        applyRebornCardByItem(self)
    end
    buttonTool:addTouchEventListener(onToolClick)

    local buttonFriends = imageButtonBase:getChildByName("Button_friends")
    local function onFriendsClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onFriendsClick~")
        applyRebornCardByFriend(self)
    end
    buttonFriends:addTouchEventListener(onFriendsClick)

    local buttonReturn = imageButtonBase:getChildByName("Button_return")
    local function onRebornReturn(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRebornReturn~")
        KSound.playEffect("click")
        switchUI(self, "RebornChoice")
    end
    buttonReturn:addTouchEventListener(onRebornReturn)

    local panelLabelButton = imageCommonBase:getChildByName("Panel_label_button")
    local buttonSupply     = panelLabelButton:getChildByName("Button_recharge")
    local function onSupplyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onSupplyClick~")
        KSound.playEffect("click")
        switchUI(self, "Supply")
    end
    buttonSupply:addTouchEventListener(onSupplyClick)

    local buttonRepair = panelLabelButton:getChildByName("Button_repair")
    local function onRepairClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRepairClick~")
        KSound.playEffect("click")
        switchUI(self, "Repair")
    end
    buttonRepair:addTouchEventListener(onRepairClick)

    local buttonReborn = panelLabelButton:getChildByName("Button_resurrection")
    local function onRebornClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRebornClick~")
        KSound.playEffect("click")
        switchUI(self, "RebornChoice")
    end
    buttonReborn:addTouchEventListener(onRebornClick)
end

function KUIRepairRebornMethodNode:registerAllCustomEvent()
    local eventDispatcher = require("src/logic/KEventDispatchCenter")

    local function onAddCard(cardID)
        cclog("----------> onEvent onAddCard")
        if self._selectedCardID == cardID then
            self._rebornCardID = cardID
            onCardReborn(self, cardID)
        end
    end
    self:addCustomEvent(eventDispatcher.EventType.NET_NOTIFY_ADD_CARD, onAddCard)

    local function onUpdateItem(itemID)
        cclog("----------> onEvent onAddCard")
        if itemID == REBORN_ITEM_TEMPLATE_ID then
            refreshBaseInfoArea(self)
        end
    end
    self:addCustomEvent(eventDispatcher.EventType.NET_ITEM_ADD, onUpdateItem)   
end

return KUIRepairRebornMethodNode
