--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairRebornNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/03/23   10:40
--  Contact     : GUOWEIQIANG@kingsoft.com
--  Comment     :
--  *********************************************************************

local REBORN_ITEM_TEMPLATE_ID   = 3
local COST_REBORN_ITEM_COUNT    = 1
local MAX_REBORN_CARD_COUNT     = 6
local ONE_POSITIONX             = 410

local KUIRepairRebornNode = class("KUIRepairRebornNode")

local m_linkHead
local m_linkTail

function pushOneLinkTail(oneData)
    local index             = (m_linkTail.data and m_linkTail.data.index or 0)
    local linked            = {data = oneData, lastL = m_linkTail}

    m_linkTail.nextL    = linked
    m_linkTail          = linked

    oneData.index           = index + 1
    return linked
end

function pushOneLinkHead(oneData)
    local nextL     = m_linkHead.nextL
    local index     = (nextL and nextL.data.index or 2)
    local linked    = {data = oneData, nextL = nextL}
    if nextL then
        nextL.lastL = linked
    end

    linked.nextL    = nextL
    linked.lastL    = m_linkHead
    m_linkHead.nextL = linked

    oneData.index  = index - 1

    return linked
end

function delLink(linked)
    local nextL     = linked.nextL
    local lastL     = linked.lastL
    if nextL then
        nextL.lastL = lastL
    else
        m_linkTail = lastL
    end

    if lastL then
        lastL.nextL = nextL
    end
end

function popOneLinkHead()
    local linked = m_linkHead.nextL
    if not linked then return end

    delLink(linked)

    return linked.data
end

function popOneLinkTail()
    local linked = m_linkTail
    if not linked then return end

    delLink(linked)

    return linked.data
end

function KUIRepairRebornNode:ctor(owner, node)
    self._mainLayout            = node
    self._parent                = owner

    self._animationList         = {}
    self._rebornBaseList        = {}
    self._selectedIndex         = 1
    self._beganX                = 0

    self._applyedReborn         = false
    self:onInitUI()
end

function KUIRepairRebornNode:onInitUI()
    self:onInitAnimation()

    local mainNode              = self._mainLayout
    local projectNodeCard       = mainNode:getChildByName("ProjectNode_card")
    local scrollView            = projectNodeCard:getChildByName("ScrollView_dead_card")
    local panelCard             = scrollView:getChildByName("Panel_card")

    self._scrollNode = panelCard

    local oneData  = {data = nil, nextL = nil, lastL = nil}
    m_linkHead = oneData
    m_linkTail = oneData

    self._noUseList = {}

    for i=1,MAX_REBORN_CARD_COUNT do
        local projectNode           = panelCard:getChildByName("ProjectNode_card_"..i)
        self._rebornBaseList[i]     = {
                node        = projectNode, 
                baseCard    = projectNode:getChildByName("Panel_ani_reborn"),
                index       = i,
                animation   = {
                    ani         = KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_reborn.csb"),
                    smallInto   = {0, 0},         --小灰
                    bigInto     = {100, 100},     --大灰
                    bigOut      = {110, 140},     --大灰变小灰
                    smallOut    = {70, 85},       --小灰变大灰
                    reborn      = {150, 215}},    --150-215是复活消失 150 还需要 ani_reborn_effert02.csb
                }
        projectNode:setVisible(false)

        table.insert(self._noUseList, self._rebornBaseList[i])
    end

    self:refreshNodeCardRoot()

    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

function KUIRepairRebornNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local list              = self._animationList
    local projectNode       = mainNode:getChildByName("ProjectNode_button_base")
    list.buttom             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_reborn_button.csb"), {0, 15, 49, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_card")
    list.nodeCard           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_reborn_content.csb"), {0, 15, 49, 65}}
end

local function checkItemState(self)
    local rebornItemCount = KUtil.getItemCount(REBORN_ITEM_TEMPLATE_ID)
    local passed = nil
    passed = rebornItemCount >= COST_REBORN_ITEM_COUNT

    return passed
end

local function getOneCardDeathList()
    return KPlayer.tCardData.tDeadList
end

local function getOneCardDeathNum()
    return #KPlayer.tCardData.tDeadList
end

--local function applyRebornCardByFriend(self)
--    if self._applyedReborn then return end
--    local deadCardID = self:getSelectID()
--    self._applyedReborn = true
--    assert(false, "reborn dead card by firends is not currently supported")
--end

local function requestBuyReborn(self, goodConfig, deadCardID)
    local onConfirm = function ()
        if KPlayer.coin >= goodConfig.nPrice then
            require("src/network/KC2SProtocolManager"):rebornCardByCostCoin(deadCardID)
            self._applyedReborn = true
        else
            --show after this confirm
            delayExecute(self._mainLayout, function ()
                KUtil.showGotoBuyDiamondConfirmation(self._parent._parent)
            end, 0.1) 
        end
    end

    local showString = string.format(KUtil.getStringByKey("factory.buyReborn"), goodConfig.nPrice)
    showConfirmation(showString, onConfirm)
end

local function applyRebornCardByItem(self)
    if self._applyedReborn then return end
    local deadCardID = self:getSelectID()

    if deadCardID then
        local rebornItemName = KUtil.getItemConfigValue(REBORN_ITEM_TEMPLATE_ID, "szName")
        local formatString   = KUtil.getStringByKey("common.promptCostItem")
        local confirmMessage = string.format(formatString, COST_REBORN_ITEM_COUNT, rebornItemName) 

        local function confirmCostItem()
            self._applyedReborn = true
            require("src/network/KC2SProtocolManager"):rebornCardByCostItem(deadCardID)
        end        

        local function cancelCostItem()

        end

        if checkItemState(self) == true then
            showConfirmation(confirmMessage, confirmCostItem, cancelCostItem)
        else
            local goodConfig = KUtil.getGoodConfigByItem(REBORN_ITEM_TEMPLATE_ID)
            if goodConfig then
                requestBuyReborn(self, goodConfig, deadCardID)
            end
        end
        
    end
end

function KUIRepairRebornNode:refreshRedPoint()
    KUtil.refreshRepairRedPoint(self._parent)
end

function KUIRepairRebornNode:getAnimation()
    if not self._selectLinked.data then return end
    return self._selectLinked.data.animation
end

function KUIRepairRebornNode:getReborn()
    if not self._selectLinked.data then return end
    return self._selectLinked.data
end

function KUIRepairRebornNode:getSelectID()
    if not self._selectLinked.data then return end
    return self._selectLinked.data.nID
end

function KUIRepairRebornNode:delOneData(linked)
    delLink(linked)
    local reborn = linked.data
    reborn.nID = nil
    reborn.node:setVisible(false)

    local nextLinked = linked.nextL
    if nextLinked then
        self._selectLinked = nextLinked
        while nextLinked do
            local nextReborn = nextLinked.data
            if nextReborn.nID then
                nextReborn.index = nextReborn.index - 1
                if self._selectedIndex == nextReborn.index then
                    self:playSmallAnimation(nextReborn.animation)
                end

                reborn.node:setPositionX(nextReborn.node:getPositionX())
                nextReborn.node:runAction(cc.MoveBy:create(0.2, cc.p(-ONE_POSITIONX, 0)))

                reborn.index = nextReborn.index
            end

            nextLinked = nextLinked.nextL
        end
    else
        local lastLinked = linked.lastL
        self._selectLinked = lastLinked
        if lastLinked and lastLinked.data then
            self._selectedIndex = self._selectedIndex - 1
            local lastReborn = lastLinked.data
            if lastReborn.nID then
                if self._selectedIndex == lastReborn.index then
                    self:playSmallAnimation(lastReborn.animation)
                end

                self._scrollNode:runAction(cc.MoveBy:create(0.2, cc.p(ONE_POSITIONX, 0)))
            end
        end
    end

    local deathList = getOneCardDeathList()
    local oneCard       = (m_linkTail.data and deathList[m_linkTail.data.index + 1] or nil)
    if oneCard then
        pushOneLinkTail(reborn)
        self:updataCard(reborn, oneCard)
        reborn.node:setVisible(true)
    else
        oneCard         = (m_linkHead.nextL and deathList[m_linkHead.nextL.data.index - 1] or nil)
        if oneCard then
            local x     = m_linkHead.nextL.data.node:getPositionX()
            pushOneLinkHead(reborn)
            self:updataCard(reborn, oneCard)
            reborn.node:setPositionX(x - ONE_POSITIONX)
            reborn.node:setVisible(true)
        end
    end
end


function KUIRepairRebornNode:onCardReborn(cardID)
    self:refreshBaseInfoArea()

    local reborn = self._selectLinked.data
    KUtil.playAnimationByAnimation(reborn.animation.ani, reborn.animation.reborn[1], reborn.animation.reborn[2])
    local rebornEffert = cc.CSLoader:createNode("res/ui/animation_node/ani_reborn_effert02.csb")
    reborn.node:addChild(rebornEffert)

    delayExecute(self._mainLayout, function()
        self:delOneData(self._selectLinked)
        rebornEffert:removeFromParent()
        self._applyedReborn = false
    end, 2)
end

function KUIRepairRebornNode:updataCard(reborn, oneCard)
    reborn.nID = oneCard.nID

    local tCardConfig    = KConfig.cardInfo[oneCard.nTemplateID]
    local panelChara     = reborn.baseCard:getChildByName("Panel_card_chara")
    local imageChara     = panelChara:getChildByName("Image_card_chara")

    local cardHeadPath   = KUtil.getCardImagePath(oneCard)
    imageChara:loadTexture(cardHeadPath)

    --tank text
    local textTank       = reborn.baseCard:getChildByName("Text_tank_name")
    textTank:setString(tCardConfig.szName)

    local textTankLv     = reborn.baseCard:getChildByName("BitmapFontLabel_tank_level")
    textTankLv:setString(oneCard.nLevel)

    local nTankTypeCount = #CARD_TYPE_NAME
    local panelTankType  = reborn.baseCard:getChildByName("Panel_card_type")
    for num = 1, nTankTypeCount do 
        local imageCardType              = panelTankType:getChildByName("Image_card_type_" .. num)
        if imageCardType then
            imageCardType:setVisible(num == tCardConfig.nTankType) 
        end
    end

    --tank medal
    local panelTankMedal  = reborn.baseCard:getChildByName("Panel_card_meda")
    for num = 1, nTankTypeCount do 
        local imageCardMedal              = panelTankMedal:getChildByName("Image_card_medal_" .. num)
        if imageCardMedal then
            imageCardMedal:setVisible(num == tCardConfig.nQuality) 
        end
    end

    local cardOneChange  = reborn.baseCard:getChildByName("Image_card_kai_1")
    cardOneChange:setVisible(tCardConfig.nChangeTimes == 1)

    local cardTwoChange  = reborn.baseCard:getChildByName("Image_card_kai_2")
    cardTwoChange:setVisible(tCardConfig.nChangeTimes == 2)

    --start
    local panelStart     = reborn.baseCard:getChildByName("Panel_card_star")
    for starCount = 1, KUtil.MAX_STAR do -- max star is 6 
        local imageStarControl = panelStart:getChildByName("Image_common_star_" .. starCount)
        imageStarControl:setVisible(starCount <= tCardConfig.nQuality)
    end

    if reborn.index == self._selectedIndex then
        reborn.animation.ani:gotoFrameAndPause(reborn.animation.bigInto[1])
    else
        reborn.animation.ani:gotoFrameAndPause(reborn.animation.smallInto[1])
    end
end

function KUIRepairRebornNode:refreshNodeCardRoot()
    local deathList = getOneCardDeathList()
    local i = 1
    while true do
        local oneCard = deathList[i]
        if oneCard then
            local reborn = self._noUseList[1]
            if reborn then
                local linked = pushOneLinkTail(reborn)
                if not self._selectLinked then
                    self._selectLinked = linked
                    --self:playSmallAnimation(self._selectLinked.data.animation)
                end

                reborn.node:setVisible(true)
                self:updataCard(reborn, oneCard)

                table.remove(self._noUseList, 1)
            else
                break
            end
        else
            break
        end
        i = i + 1
    end

    if not self._selectLinked then
        self._selectLinked = m_linkHead
    end
end

function KUIRepairRebornNode:refreshBaseInfoArea()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_xl_base")

    local textRebornTimes   = imageBase:getChildByName("Text_highspeed_repair_value")
    local rebornItemCount   = KUtil.getItemCount(REBORN_ITEM_TEMPLATE_ID)
    textRebornTimes:setString(rebornItemCount)     
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:stopAllActions()
    mainNode:setVisible(true)
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

local function exitAnimation(self)
    local mainNode     = self._mainLayout
    local nDelayTime = 0
    for name, animation in pairs(self._animationList) do
        local nTime = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    delayExecute(self._mainLayout, function()
        mainNode:setVisible(false)
    end, nDelayTime)

    return nDelayTime
end

function KUIRepairRebornNode:enter()
    self:refreshUI()
    enterAnimation(self)
end

function KUIRepairRebornNode:quit()
    return exitAnimation(self)
end

function KUIRepairRebornNode:refreshUI()
    self:refreshRedPoint()
    self:refreshBaseInfoArea()
end

function KUIRepairRebornNode:playSmallAnimation(animation)
    KUtil.playAnimationByAnimation(animation.ani, animation.smallOut[1], animation.smallOut[2])
end

function KUIRepairRebornNode:playBigAnimation(animation)
    KUtil.playAnimationByAnimation(animation.ani, animation.bigOut[1], animation.bigOut[2])
end

function KUIRepairRebornNode:onScrollSort(moveNum)
    if moveNum > 0 then
        if getOneCardDeathNum() > MAX_REBORN_CARD_COUNT then
            if m_linkTail.data.index - self._selectLinked.data.index < 3 then
                local deathList = getOneCardDeathList()
                -- move fisrt to end
                local oneCard       = deathList[m_linkTail.data.index + 1]
                if oneCard then
                    local data      = popOneLinkHead()
                    local linked    = pushOneLinkTail(data)
                    self:updataCard(linked.data, oneCard)
                    local x         = linked.data.node:getPositionX()
                    linked.data.node:setPositionX(x + MAX_REBORN_CARD_COUNT * ONE_POSITIONX)
                end
            end
        end

        self._selectLinked          = self._selectLinked.nextL
    else
        if getOneCardDeathNum() > MAX_REBORN_CARD_COUNT then
            if self._selectLinked.data.index - m_linkHead.nextL.data.index < 3 then
                local deathList     = getOneCardDeathList()
                -- move end to fisrt
                local oneCard       = deathList[m_linkHead.nextL.data.index - 1]
                if oneCard then
                    local data      = popOneLinkTail()
                    local linked    = pushOneLinkHead(data)
                    self:updataCard(linked.data, oneCard)
                    local x         = linked.data.node:getPositionX()
                    linked.data.node:setPositionX(x - MAX_REBORN_CARD_COUNT * ONE_POSITIONX)
                end
            end
        end

        self._selectLinked          = self._selectLinked.lastL
    end
end

function KUIRepairRebornNode:moveOne(vectro, time, fun)
    self._scrollNode:runAction(cc.MoveBy:create(time, cc.p(-vectro * ONE_POSITIONX, 0)))
    self._selectedIndex         = self._selectedIndex + vectro

    self:onScrollSort(vectro)

    self._mainLayout:stopActionByTag(12345)
    local delayAction = delayExecute(self._mainLayout, function() fun() end, time)
    delayAction:setTag(12345)
end

function KUIRepairRebornNode:moveByNum(moveNum, time)
    if getOneCardDeathNum() == 0 then
        return
    end

    if self._selectedIndex + moveNum < 1 then
        moveNum = 1 - self._selectedIndex
    end

    if self._selectedIndex + moveNum > getOneCardDeathNum() then
        moveNum = getOneCardDeathNum() - self._selectedIndex
    end

    if moveNum == 0 then
        return
    end

    self:playBigAnimation(self._selectLinked.data.animation)
    local vectro  = math.abs(moveNum) / moveNum
    local oneTime = time / math.abs(moveNum)
    local function moveOneOver()
        moveNum = moveNum - vectro
        if moveNum ~= 0 then
            self:moveOne(vectro, oneTime, moveOneOver)
        else
            self:playSmallAnimation(self._selectLinked.data.animation)
        end
    end
    self:moveOne(vectro, oneTime, moveOneOver)
end

function KUIRepairRebornNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout

    local nodeButtonBase    = mainNode:getChildByName("ProjectNode_button_base")
    local imageButtonBase   = nodeButtonBase:getChildByName("Image_button_base")

    local buttonTool        = imageButtonBase:getChildByName("Button_prop")
    local function onToolClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._applyedReborn then return end

        cclog("-----> onToolClick~")
        KSound.playEffect("fieldRescue")
        applyRebornCardByItem(self)
    end
    buttonTool:addTouchEventListener(onToolClick)

    --[[local buttonFriends = imageButtonBase:getChildByName("Button_friends")
    local function onFriendsClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onFriendsClick~")
        KSound.playEffect("callAllies")
        applyRebornCardByFriend(self)
    end
    buttonFriends:addTouchEventListener(onFriendsClick)]]

    local mainNode              = self._mainLayout
    local imageBase             = mainNode:getChildByName("Image_xl_base")
    local function onScrollView(sender, type)
        if self._applyedReborn then return end

        if type == ccui.TouchEventType.began then
            self._beganX = sender:getTouchBeganPosition().x
        elseif type == ccui.TouchEventType.ended or type == ccui.TouchEventType.canceled then
            if self._vectorX and math.abs(self._vectorX) > 10 then
                local needMoveNum = self._vectorX / 20
                if needMoveNum < 0 then
                    needMoveNum = -math.floor(needMoveNum)
                else
                    needMoveNum = -math.ceil(needMoveNum)
                end

                self:moveByNum(needMoveNum, math.min(1.3, math.abs(needMoveNum * 0.2)))
            else
                local endX = sender:getTouchEndPosition().x
                local needMoveNum = (endX - self._beganX) / ONE_POSITIONX
                if needMoveNum < 0 then
                    needMoveNum = -math.floor(needMoveNum)
                else
                    needMoveNum = -math.ceil(needMoveNum)
                end
                
                self:moveByNum(needMoveNum, 0.5)
            end
            self._movePos = nil
            self._vectorX = nil
        elseif type == ccui.TouchEventType.moved then
            local movePosX =  sender:getTouchMovePosition().x
            if self._movePosX then
                self._vectorX = movePosX - self._movePosX
            end
            self._movePosX = movePosX
            self._moveTouchTime = os.clock()
        end
    end
    imageBase:addTouchEventListener(onScrollView)
end

function KUIRepairRebornNode:registerAllCustomEvent()
    local eventDispatcher = require("src/logic/KEventDispatchCenter")

    local function onAddCard(cardID)
        cclog("----------> onEvent onAddCard")
        if self:getSelectID() == cardID then
            self:onCardReborn(cardID)
        end
        self:refreshRedPoint()
    end
    self._parent:addCustomEvent(eventDispatcher.EventType.NET_NOTIFY_ADD_CARD, onAddCard)

    local function onUpdateItem(itemID)
        cclog("----------> onEvent onAddCard")
        if itemID == REBORN_ITEM_TEMPLATE_ID then
            self:refreshBaseInfoArea()
        end
    end
    self._parent:addCustomEvent(eventDispatcher.EventType.NET_ITEM_ADD, onUpdateItem)
    self._parent:addCustomEvent(eventDispatcher.EventType.NET_ITEM_UPDATE, onUpdateItem)
end

return KUIRepairRebornNode
