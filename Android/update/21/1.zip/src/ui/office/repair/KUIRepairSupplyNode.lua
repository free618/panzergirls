--  *********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairNode.lua
--  Creator     : Jiang xufeng
--  Date        : 2016/03/20   10:00
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_tSpriteSupply = KUtil.SpriteSupply

local m_tButtonStateTexture = {
    ["buttonNormalTexture"]   = "res/ui/ui_material/public/common_team_button.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/public/common_team_button_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/public/common_team_button_disable.png"
}

local m_tButtonSupplyAllStateTexture = {
    ["buttonNormalTexture"]   = "res/ui/ui_material/public/button_currency.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/public/button_currency_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/public/button_currency_disable.png"
}

local m_tTeamButtonNameOfTeamID = {
    "Button_team_sheet_1",
    "Button_team_sheet_2",
    "Button_team_sheet_3",
    "Button_team_sheet_4"
}

local MAX_SCALE                 = 100
local CARD_UNIT_COUNT           = 6
local TEAM_SHEET_START          = 1
local OIL_PERCENT_START         = 0 
local AMMO_PERCENT_START        = 0
local OIL_ACTION_END_FRAME      = 70
local AMMO_ACTION_END_FRAME     = 70
local ANIMATION_ORIGIN_FRAME    = 0
local OIL_ACTION_START_FRAME    = 0
local AMMO_ACTION_START_FRAME   = 0
local BUTTON_TEAM_SHEET_COUNT   = 4
local FULL_SUPPLY_PERCENT_FRAME = 45
local SPRITE_SUPPLY_COUNT       = 4

local KUIRepairSupplyNode = class("KUIRepairSupplyNode")

function KUIRepairSupplyNode:ctor(owner, node)
    self._currentChooseTeamID   = 1
    self._mainLayout            = node
    self._parent                = owner
    self._cardList              = {}
    self._animationList         = {}
    self._eventList             = {}
    self._openTeamCount         = KPlayer.tTeamData.nOpenCount
    local needID                = KUtil.needSupplyTeamID()
    if needID ~= 0 then self._currentChooseTeamID = needID end
    self:initData()
    self._initUI                = false
end

local function resetAllButtonState(self)
    local mainNode          = self._mainLayout
    local projectNodeUnit   = mainNode:getChildByName("ProjectNode_top")
    local panel             = projectNodeUnit:getChildByName("Panel_1")
    
    for sheetNum = 1, self._openTeamCount do
        local buttonName    = "Button_team_sheet_" .. sheetNum
        local buttonControl = panel:getChildByName(buttonName)
        buttonControl:loadTextures(
            m_tButtonStateTexture.buttonNormalTexture,
            m_tButtonStateTexture.buttonPressTexture,
            m_tButtonStateTexture.buttonDisableTexture
        )
    end
end

local function changeButtonStateByTeamID(self, currentChooseTeamID)
    local mainNode          = self._mainLayout
    local projectNodeUnit   = mainNode:getChildByName("ProjectNode_top")
    local panel             = projectNodeUnit:getChildByName("Panel_1")
    local buttonName        = m_tTeamButtonNameOfTeamID[currentChooseTeamID]
    assert(buttonName ~= nil, "Get Team Button Name By ID Failed~")
    local buttonControl     = panel:getChildByName(buttonName)
    buttonControl:loadTextures(
        m_tButtonStateTexture.buttonPressTexture,
        m_tButtonStateTexture.buttonPressTexture, 
        m_tButtonStateTexture.buttonDisableTexture  
    )
end

local function refreshTeamButtonArea(self)
    local mainNode              = self._mainLayout
    local projectNodeTop        = mainNode:getChildByName("ProjectNode_top")
    local panelTeamName         = projectNodeTop:getChildByName("Panel_team_name")
    local textTeamNameValue     = panelTeamName:getChildByName("Text_team_name_value")
    local currentChooseTeamID   = self._currentChooseTeamID
    textTeamNameValue:setString(KUtil.getTeamName(currentChooseTeamID))
    
    resetAllButtonState(self)
    changeButtonStateByTeamID(self, currentChooseTeamID)
end

local function updateCardUnit(self, unitNode, card)
    local cardConfig   = KUtil.getCardConfig(card.nTemplateID)
    -- empty card
    local buttonBjUnitBase = unitNode:getChildByName("Button_bj_unit_base")
    local panelSupplyOne   = unitNode:getChildByName("Panel_supply_1")
    local panelSupplyTwo   = unitNode:getChildByName("Panel_supply_2")
    if not card then
        buttonBjUnitBase:setVisible(false)
        panelSupplyOne:setVisible(false)
        panelSupplyTwo:setVisible(false)
        return
    end
    buttonBjUnitBase:setVisible(true)
    panelSupplyOne:setVisible(true)
    panelSupplyTwo:setVisible(true)

    -- have card
    local projectNodeCardBase = buttonBjUnitBase:getChildByName("ProjectNode_cardbas")
    local panelBase           = projectNodeCardBase:getChildByName("Panel_base")

    local panelFirendDegree   = panelBase:getChildByName("Panel_firend_degree")
    panelFirendDegree:setVisible(false)

    -- -- update card base
    KUtil.updateCardBase(panelBase, card)

    local currentOil            = card.nCurrentOil 
    local currentAmmo           = card.nCurrentAmmo 
    local cardMaxCarryOil       = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
    local cardMaxCarryAmmo      = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
    local oilPercent            = math.ceil(currentOil / cardMaxCarryOil * FULL_SUPPLY_PERCENT_FRAME)
    local ammoPercent           = math.ceil(currentAmmo / cardMaxCarryAmmo * FULL_SUPPLY_PERCENT_FRAME)
    local panelSupplyOne        = unitNode:getChildByName("Panel_supply_1")
    local panelSupplyTwo        = unitNode:getChildByName("Panel_supply_2")
    local projectNodeOil        = panelSupplyOne:getChildByName("ProjectNode_unit_supply_green_oil")
    local projectNodeAmmo       = panelSupplyTwo:getChildByName("ProjectNode_unit_supply_green_ammo")
    local oilSpirteVisible      = math.ceil(currentOil / cardMaxCarryOil * 100)
    local ammoSpirteVisible     = math.ceil(currentAmmo / cardMaxCarryAmmo * 100)
    local panelSpriteOil        = projectNodeOil:getChildByName("Panel_sprite")
    local panelSpriteAmmo       = projectNodeAmmo:getChildByName("Panel_sprite")

    for i = 1, SPRITE_SUPPLY_COUNT do 
        local spritSupplyOil = panelSpriteOil:getChildByName("Sprite_supply_" .. i)
        local spritSupplyAmmo = panelSpriteAmmo:getChildByName("Sprite_supply_" .. i)
        spritSupplyOil:setVisible(false)
        spritSupplyAmmo:setVisible(false)

        for key, var in ipairs(m_tSpriteSupply) do
            if oilSpirteVisible <= var.upLimit and oilSpirteVisible > var.downLimit then 
                spritSupplyOil = panelSpriteOil:getChildByName(var.spritName)
                spritSupplyOil:setVisible(true) 
            end

            if ammoSpirteVisible <= var.upLimit and ammoSpirteVisible > var.downLimit then 
                spritSupplyAmmo = panelSpriteAmmo:getChildByName(var.spritName)
                spritSupplyAmmo:setVisible(true)
            end
        end
    end

    local oilAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_value.csb")
    assert(oilAnimationAction  ~= nil, "Get oilAnimationAction Failed~")
    local ammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_value.csb")
    assert(ammoAnimationAction ~= nil, "Get ammoAnimationAction Failed~")

    projectNodeOil:stopAllActions()
    projectNodeOil:runAction(oilAnimationAction)
    oilAnimationAction:gotoFrameAndPlay(OIL_PERCENT_START, oilPercent, false)

    projectNodeAmmo:stopAllActions()
    projectNodeAmmo:runAction(ammoAnimationAction)
    ammoAnimationAction:gotoFrameAndPlay(AMMO_PERCENT_START, ammoPercent, false)
end

function KUIRepairSupplyNode:updateSkillSupply()
    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local imageResourceBase = projectNodeBottom:getChildByName("Image_resource_base")

    local tSkillCost        = KUtil.getSkillSupplyData()
    local oilPercent        = 1
    if tSkillCost.maxOil > 0 then
        oilPercent = (tSkillCost.maxOil - tSkillCost.needOil) / tSkillCost.maxOil
    end

    local ammoPercent       = 1
    if tSkillCost.maxAmmo > 0 then
        ammoPercent = (tSkillCost.maxAmmo - tSkillCost.needAmmo) / tSkillCost.maxAmmo
    end

    local steelPercent      = 1
    if tSkillCost.maxSteel > 0 then
        steelPercent = (tSkillCost.maxSteel - tSkillCost.needSteel) / tSkillCost.maxSteel
    end

    local spammoPercent     = 1
    if tSkillCost.maxSpammo > 0 then
        spammoPercent = (tSkillCost.maxSpammo - tSkillCost.needSpammo) / tSkillCost.maxSpammo
    end
    
    local projectNodeOil        = imageResourceBase:getChildByName("ProjectNode_skill_1")
    local projectNodeAmmo       = imageResourceBase:getChildByName("ProjectNode_skill_2")
    local projectNodeSteel      = imageResourceBase:getChildByName("ProjectNode_skill_3")
    local projectNodeSpammo     = imageResourceBase:getChildByName("ProjectNode_skill_4")

    local oilAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_skill_1.csb")
    assert(oilAnimationAction  ~= nil, "Get oilAnimationAction Failed~")
    local ammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_skill_2.csb")
    assert(ammoAnimationAction ~= nil, "Get ammoAnimationAction Failed~")
    local steelAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_skill_3.csb")
    assert(steelAnimationAction  ~= nil, "Get steelAnimationAction Failed~")
    local spammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_skill_4.csb")
    assert(spammoAnimationAction ~= nil, "Get spammoAnimationAction Failed~")

    projectNodeOil:stopAllActions()
    projectNodeOil:runAction(oilAnimationAction)
    oilAnimationAction:gotoFrameAndPlay(OIL_PERCENT_START, math.ceil(oilPercent * FULL_SUPPLY_PERCENT_FRAME), false)

    projectNodeAmmo:stopAllActions()
    projectNodeAmmo:runAction(ammoAnimationAction)
    ammoAnimationAction:gotoFrameAndPlay(AMMO_PERCENT_START, math.ceil(ammoPercent * FULL_SUPPLY_PERCENT_FRAME), false)

    projectNodeSteel:stopAllActions()
    projectNodeSteel:runAction(steelAnimationAction)
    steelAnimationAction:gotoFrameAndPlay(AMMO_PERCENT_START, math.ceil(steelPercent * FULL_SUPPLY_PERCENT_FRAME), false)

    projectNodeSpammo:stopAllActions()
    projectNodeSpammo:runAction(spammoAnimationAction)
    spammoAnimationAction:gotoFrameAndPlay(AMMO_PERCENT_START, math.ceil(spammoPercent * FULL_SUPPLY_PERCENT_FRAME), false)

    local panelSpriteOil        = projectNodeOil:getChildByName("Panel_sprite")
    local panelSpriteAmmo       = projectNodeAmmo:getChildByName("Panel_sprite")
    local panelSpriteSteel      = projectNodeSteel:getChildByName("Panel_sprite")
    local panelSpriteSpammo     = projectNodeSpammo:getChildByName("Panel_sprite")
    for key, var in ipairs(m_tSpriteSupply) do
        local spritSupplyOil = panelSpriteOil:getChildByName(var.spritName)
        if oilPercent * 100 <= var.upLimit and oilPercent * 100 > var.downLimit then 
            spritSupplyOil:setVisible(true)
        else
            spritSupplyOil:setVisible(false)
        end

        local spritSupplyAmmo = panelSpriteAmmo:getChildByName(var.spritName)
        if ammoPercent * 100 <= var.upLimit and ammoPercent * 100 > var.downLimit then 
            spritSupplyAmmo:setVisible(true)
        else
            spritSupplyAmmo:setVisible(false)
        end

        local spritSupplySteel = panelSpriteSteel:getChildByName(var.spritName)
        if steelPercent * 100 <= var.upLimit and steelPercent * 100 > var.downLimit then
            spritSupplySteel:setVisible(true)
        else
            spritSupplySteel:setVisible(false)
        end

        local spritSupplySpammo = panelSpriteSpammo:getChildByName(var.spritName)
        if spammoPercent * 100 <= var.upLimit and spammoPercent * 100 > var.downLimit then 
            spritSupplySpammo:setVisible(true)
        else
            spritSupplySpammo:setVisible(false)
        end
    end
end

local function refreshCardArea(self)
    local mainNode          = self._mainLayout
    local projectNodeUnit   = mainNode:getChildByName("ProjectNode_unit")
    local panelAniSupplyTeam= projectNodeUnit:getChildByName("Panel_ani_supply_team")
    self._cardList          = KUtil.getOneTeamCardList(self._currentChooseTeamID)
    
    for unitNum , card in ipairs(self._cardList) do
        local unitNodeName  = "Node_unit_" .. unitNum
        local unitNode      = panelAniSupplyTeam:getChildByName(unitNodeName)
        unitNode:setVisible(true)
        updateCardUnit(self, unitNode, card)
    end
end

local function resetResourceAnimation(self)
    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local imageResourceBase = projectNodeBottom:getChildByName("Image_resource_base")
    local projectNodeOil    = imageResourceBase:getChildByName("ProjectNode_oil_drop")
    local projectNodeAmmo   = imageResourceBase:getChildByName("ProjectNode_ammo_drop")
    local projectNodeSteel  = imageResourceBase:getChildByName("ProjectNode_steel_drop")
    local projectNodeSpammo = imageResourceBase:getChildByName("ProjectNode_spammo_drop")
    
    projectNodeOil:stopAllActions()
    projectNodeAmmo:stopAllActions()
    projectNodeSteel:stopAllActions()
    projectNodeSpammo:stopAllActions()
    
    local oilAction         = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_oil_drop.csb")
    assert(oilAction ~= nil, "Create oilAction Failed~")
    projectNodeOil:runAction(oilAction)
    oilAction:gotoFrameAndPause(ANIMATION_ORIGIN_FRAME)

    local ammoAction        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_ammo_drop.csb")
    assert(ammoAction ~= nil, "Create ammoAction Failed~")
    projectNodeAmmo:runAction(ammoAction)
    ammoAction:gotoFrameAndPause(ANIMATION_ORIGIN_FRAME)

    local steelAction        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_steel_drop.csb")
    assert(steelAction ~= nil, "Create steelAction Failed~")
    projectNodeSteel:runAction(steelAction)
    steelAction:gotoFrameAndPause(ANIMATION_ORIGIN_FRAME)

    local spammoAction        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_spammo_drop.csb")
    assert(spammoAction ~= nil, "Create spammoAction Failed~")
    projectNodeSpammo:runAction(spammoAction)
    spammoAction:gotoFrameAndPause(ANIMATION_ORIGIN_FRAME)
end

local function updateSupplyCostState(self)    
    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local imageResourceBase = projectNodeBottom:getChildByName("Image_resource_base")
    local projectNodeOil    = imageResourceBase:getChildByName("ProjectNode_oil_drop")
    local projectNodeAmmo   = imageResourceBase:getChildByName("ProjectNode_ammo_drop")
    local textOilData       = projectNodeBottom:getChildByName("Text_oil_drop")
    local textAmmoData      = projectNodeBottom:getChildByName("Text_ammo_drop")
    local textSteelData     = projectNodeBottom:getChildByName("Text_ammo_steel_drop")
    local textSpammoData    = projectNodeBottom:getChildByName("Text_spammo_drop")
    
    --local projectNodeSkills = projectNodeBottom:getChildByName("ProjectNode_skills")
    local checkBoxSkills    = imageResourceBase:getChildByName("CheckBox_skills")

    local needOil, needAmmo, needSteel, needSpammo  = KUtil.getTotalSupplyData(self._currentChooseTeamID, checkBoxSkills:isSelected())
    textOilData:setString(needOil)
    textAmmoData:setString(needAmmo)
    textSteelData:setString(needSteel)
    textSpammoData:setString(needSpammo)

    local buttonSupplyAll   = imageResourceBase:getChildByName("Button_supply_all_button")
    local playerOil         = KPlayer.oil  
    local playerAmmo        = KPlayer.ammo 
    local playerSteel           = KPlayer.steel  
    local playerSpammo          = KPlayer.people 
    local canClick          = true
    
    if needOil == 0 and needAmmo == 0 and needSteel == 0 and needSpammo == 0 then
        canClick = false
    end
    
    if playerOil < needOil then 
        canClick = false
    end

    if playerAmmo < needAmmo then
        canClick = false
    end
    
    if playerSteel < needSteel then 
        canClick = false
    end

    if playerSpammo < needSpammo then
        canClick = false
    end
    
    if not canClick then
        buttonSupplyAll:setTouchEnabled(false)
        buttonSupplyAll:loadTextures(
            m_tButtonSupplyAllStateTexture.buttonDisableTexture,
            m_tButtonSupplyAllStateTexture.buttonDisableTexture,
            m_tButtonSupplyAllStateTexture.buttonDisableTexture
        )
    else
        buttonSupplyAll:setTouchEnabled(true)
        buttonSupplyAll:loadTextures(
            m_tButtonSupplyAllStateTexture.buttonNormalTexture,
            m_tButtonSupplyAllStateTexture.buttonPressTexture,
            m_tButtonSupplyAllStateTexture.buttonDisableTexture
        )
        resetResourceAnimation(self)
    end
end

local function canSupplyCard(cardID)
    if not cardID then return false end

    local card      = KUtil.getCardById(cardID)
    local carryOil  = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
    local carryAmmo = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
    local oil       = KPlayer.oil
    local ammo      = KPlayer.ammo

    if card.nCurrentOil == carryOil and card.nCurrentAmmo == carryAmmo then 
        return false
    end

    if carryOil - card.nCurrentOil <= oil and carryAmmo - card.nCurrentAmmo <= ammo then
        return true
    end

    return false
end

local function getCardPosition(self, cardID)
    for index, card in ipairs(self._cardList) do
        if card.nID == cardID then
            return index
        end
    end
    return 0
end

local function playSupplyAnimation(self)
    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local imageResourceBase = projectNodeBottom:getChildByName("Image_resource_base")
    
    --Play Oil Supply Animation
    local nodeProjectOil        = imageResourceBase:getChildByName("ProjectNode_oil_drop")
    local oilAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_oil_drop.csb")
    assert(oilAnimationAction  ~= nil, "Get oilAnimationAction Failed~")

    nodeProjectOil:stopAllActions()
    nodeProjectOil:runAction(oilAnimationAction)
    oilAnimationAction:gotoFrameAndPlay(OIL_ACTION_START_FRAME, OIL_ACTION_END_FRAME, false)

    --Play Ammo Supply Animation
    local nodeProjectAmmo       = imageResourceBase:getChildByName("ProjectNode_ammo_drop")
    local ammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_ammo_drop.csb")
    assert(ammoAnimationAction ~= nil, "Get ammoAnimationAction Failed~")
   
    nodeProjectAmmo:stopAllActions()
    nodeProjectAmmo:runAction(ammoAnimationAction)
    ammoAnimationAction:gotoFrameAndPlay(AMMO_ACTION_START_FRAME, AMMO_ACTION_END_FRAME, false)

    --Play Steel Supply Animation
    local nodeProjectSteel        = imageResourceBase:getChildByName("ProjectNode_steel_drop")
    local steelAnimationAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_steel_drop.csb")
    assert(steelAnimationAction  ~= nil, "Get steelAnimationAction Failed~")

    nodeProjectSteel:stopAllActions()
    nodeProjectSteel:runAction(steelAnimationAction)
    steelAnimationAction:gotoFrameAndPlay(AMMO_ACTION_START_FRAME, AMMO_ACTION_END_FRAME, false)

    --Play Smmo Supply Animation
    local nodeProjectSpammo       = imageResourceBase:getChildByName("ProjectNode_spammo_drop")
    local spammoAnimationAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_spammo_drop.csb")
    assert(spammoAnimationAction ~= nil, "Get spammoAnimationAction Failed~")
   
    nodeProjectSpammo:stopAllActions()
    nodeProjectSpammo:runAction(spammoAnimationAction)
    spammoAnimationAction:gotoFrameAndPlay(AMMO_ACTION_START_FRAME, AMMO_ACTION_END_FRAME, false)

end

local function refreshResourceArea(self)
    resetResourceAnimation(self)
    updateSupplyCostState(self)
end

local function hideAllUnitNode(self)
    local mainNode          = self._mainLayout
    local projectNodeUnit   = mainNode:getChildByName("ProjectNode_unit")
    local panelAniSupplyTeam= projectNodeUnit:getChildByName("Panel_ani_supply_team") 

    for k = 1, CARD_UNIT_COUNT do
        local nodeName = "Node_unit_" .. k
        local unitNode = panelAniSupplyTeam:getChildByName(nodeName)
        unitNode:setVisible(false)
    end
end

local function switchTabUI(self, fromNodeType, toNodeType)
    local parentNode    = self._parent
    local disappearTime = 0
    if fromNodeType ~= nil then
        disappearTime = parentNode:removeNode(fromNodeType)
    end

    local function addNode()
        parentNode:addNode(toNodeType)
    end

    delayExecute(self._parent, addNode, disappearTime)
end

local function refreshRedPoint(self)
    KUtil.refreshRepairRedPoint(self._parent)
end

local function refreshExpeditionTeam(self)
    local mainNode        = self._mainLayout
    local projectNodeUnit = mainNode:getChildByName("ProjectNode_top")
    local panelButtonTeam = projectNodeUnit:getChildByName("Panel_1")
    for teamID = 2, MAX_TEAM_COUNT do
        local buttonControl   = panelButtonTeam:getChildByName("Button_team_sheet_" .. teamID)
        local projectNodeMark = buttonControl:getChildByName("ProjectNode_mark")
        local isExpedition    = KUtil.isTeamInExpedition(teamID)
        projectNodeMark:setVisible(isExpedition)
    end
end

function KUIRepairSupplyNode:initData()
    local nodeBuildTop          = self._mainLayout:getChildByName("ProjectNode_top")
    self._animationList.top     = KUtil.initAnimation(nodeBuildTop, "res/ui/animation_node/ani_supply_top.csb")
    local nodeButtonBottom      = self._mainLayout:getChildByName("ProjectNode_bottom")
    self._animationList.bottom  = KUtil.initAnimation(nodeButtonBottom, "res/ui/animation_node/ani_supply_bottom.csb")
    local nodeBuildContent      = self._mainLayout:getChildByName("ProjectNode_unit")
    self._animationList.content = KUtil.initAnimation(nodeBuildContent, "res/ui/animation_node/ani_supply_team.csb")
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    KUtil.playEnterAnimation(self._animationList.top)
    KUtil.playEnterAnimation(self._animationList.bottom)
    KUtil.playEnterAnimation(self._animationList.content, 0, 40)
end

local function exitAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(false)

    local nDelayTime = 0
    for _, animation in pairs(self._animationList) do
        local nTime = KUtil.playQuitAnimation(animation)
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    return nDelayTime
end

local function initUI(self)
    if self._initUI then return end
    self._initUI = true
    refreshExpeditionTeam(self)
end

function KUIRepairSupplyNode:enter()
    self:refreshUI()
    enterAnimation(self)
end

function KUIRepairSupplyNode:quit()
    return exitAnimation(self)
end

function KUIRepairSupplyNode:refreshUI()
    initUI(self)
    hideAllUnitNode(self)
    refreshTeamButtonArea(self)
    refreshCardArea(self)
    refreshResourceArea(self)
    refreshRedPoint(self)
    self:updateSkillSupply()
end

function KUIRepairSupplyNode:playProjectNodeUnit(isOpenPanel)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_unit")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_team.csb")
    local nStart            = 0
    local nMiddle           = 35
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

function KUIRepairSupplyNode:playProjectNodeTop(isOpenPanel)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_top")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_top.csb")
    local nStart            = 0
    local nMiddle           = 15
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

function KUIRepairSupplyNode:playProjectNodeButtom(isOpenPanel)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_bottom")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_supply_bottom.csb")
    local nStart            = 0
    local nMiddle           = 15
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

function KUIRepairSupplyNode:registerAllTouchEvent()
    local mainNode           = self._mainLayout
    local projectNodeUnit    = mainNode:getChildByName("ProjectNode_unit")
    local projectNodeTop     = mainNode:getChildByName("ProjectNode_top")
    local projectNodeBottom  = mainNode:getChildByName("ProjectNode_bottom")
    local panelAniSupplyTeam = projectNodeUnit:getChildByName("Panel_ani_supply_team")
    local panel              = projectNodeTop:getChildByName("Panel_1")
    local imageResourceBase  = projectNodeBottom:getChildByName("Image_resource_base")
    
    
    for nodeID = 1, CARD_UNIT_COUNT do
        local nodeName      = "Node_unit_" .. nodeID
        local unitNode      = panelAniSupplyTeam:getChildByName(nodeName)
        local buttonControl = unitNode:getChildByName("Button_bj_unit_base")
        local function onUnitBaseClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("supply")
                local cardList = KUtil.getOneTeamCardList(self._currentChooseTeamID)
                if not cardList then return end 
                local cardID = cardList[nodeID].nID
                if not cardID then return end
                if canSupplyCard(cardID) then 
                    require("src/network/KC2SProtocolManager"):supplyCard(cardID)
                end
            end
        end    
        buttonControl:addTouchEventListener(onUnitBaseClick)
    end
    
    for i = 1, BUTTON_TEAM_SHEET_COUNT do
        local buttonTeamSheet = panel:getChildByName("Button_team_sheet_" .. i)
        local function onTeamSheetButton(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                self._currentChooseTeamID = i
                self:refreshUI()
                cclog ("click onTeamSheetButton~" .. i)
            end
        end
        buttonTeamSheet:addTouchEventListener(onTeamSheetButton)

        if i > self._openTeamCount then
            buttonTeamSheet:loadTextures(m_tButtonStateTexture.buttonDisableTexture,m_tButtonStateTexture.buttonDisableTexture,m_tButtonStateTexture.buttonDisableTexture)
            buttonTeamSheet:setEnabled(false)
            local imageTeamIndex = buttonTeamSheet:getChildByName("Image_common_team_" .. i)
            imageTeamIndex:setVisible(false)
        end
    end
    
    local buttonSupplyAll = imageResourceBase:getChildByName("Button_supply_all_button")
    local checkBoxSkills  = imageResourceBase:getChildByName("CheckBox_skills")
    local function onSupplyAllButton(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog ("click onSupplyAllButton~")
            KSound.playEffect("supply")
            local currentTeamID = self._currentChooseTeamID
            local bSupplySkill = checkBoxSkills:isSelected()
            require("src/network/KC2SProtocolManager"):supplyTeam(currentTeamID, bSupplySkill)
        end 
    end
    buttonSupplyAll:addTouchEventListener(onSupplyAllButton)  

    local function selectedEvent(sender,eventType)
        updateSupplyCostState(self)
    end  
    checkBoxSkills:addEventListener(selectedEvent)
end

function KUIRepairSupplyNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    
    local function onSupplyTeamFinish()
        cclog("onEvent ------------> onSuppplyTeamFinish")
        self:refreshUI()
        playSupplyAnimation(self)
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish) 


    local function onSupplySkillFinish()
        cclog("onEvent ------------> onSupplySkillFinish")
        self:refreshUI()
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_SKILL_FINISH, onSupplySkillFinish)
    
    local function onSupplyCardFinish(cardID)
        cclog("onEvent ------------> onSuppplyCardFinish")
        local card = KUtil.getCardById(cardID)
        if not card then return end
        local position           = getCardPosition(self, cardID)
        if position == 0 then return end
        
        local projectNodeUnit    = self._mainLayout:getChildByName("ProjectNode_unit")
        local panelAniSupplyTeam = projectNodeUnit:getChildByName("Panel_ani_supply_team")
        local nodeUnit           = panelAniSupplyTeam:getChildByName("Node_unit_" .. position)

        updateCardUnit(self, nodeUnit, card)
        refreshResourceArea(self)
        refreshRedPoint(self)
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_CARD_FINISH, onSupplyCardFinish) 
end

return KUIRepairSupplyNode
