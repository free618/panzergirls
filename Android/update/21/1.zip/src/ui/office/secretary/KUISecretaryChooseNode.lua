--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUISecretaryChooseNode.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/05/27   10:11
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     : 
--  *********************************************************************


local SHOW_ROW_SIZE    = 4
local SHOW_COLUMN_SIZE = 7
local SHOW_ROW_OFF     = -5
local VALID_OFF        = 20
local FIRST_NODE_ID    = -1
local KSetting = require("src/logic/KSetting")

local KUISecretaryChooseNode = class(
    "KUISecretaryChooseNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISecretaryChooseNode:ctor()
    self._mainLayout       = nil
    self._parent           = nil
    self._uiPath           = nil
    self._sortType         = KSetting.getInt(KSetting.Key.SECRETARY_COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    self._teamType         = KSetting.getInt(KSetting.Key.SECRETARY_TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
    self._baseListData     = {}
    self._showListData     = {}
    self._baseControl      = nil
    self._pageData         = {}
end

function KUISecretaryChooseNode.create(owner, nodeData)
    local currentNode      = KUISecretaryChooseNode.new()

    currentNode._parent    = owner
    currentNode._uiPath    = "res/ui/layout_secretary_unit_choose.csb"
    currentNode:init()

    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_button")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_secretary_unit_choose_bottom"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTopAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_top")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_unit_choose_top"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playContentAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_content")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_secretary_unit_choose_content"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()

    local projectNode     = imageCommon:getChildByName("ProjectNode_button")
    projectNode:stopAllActions()

    local projectNode = imageCommon:getChildByName("ProjectNode_content")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playContentAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "SecretaryChoose", callBacks, isReturnOffice)
end

local function refreshSortButton(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageCommon:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    local panelSort         = panleBottom:getChildByName("Button_common_sort")

    KUtil.refreshCardSortButton(panelSort, self._sortType)
end

local function refreshTypeButton(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageCommon:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    local panelType         = panleBottom:getChildByName("Button_common_type")

    KUtil.refreshCardTypeButton(panelType, self._teamType)
end

local function UpdateShowList(self)
    self._showListData = KUtil.getCardsByKey(self._baseListData, self._teamType)
    refreshTypeButton(self)
end

local function initAllCard(self)
    self._baseListData = {}
    for i, oneCard in pairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        table.insert(self._baseListData, oneCard)
    end

    UpdateShowList(self)
end

local function refreshCardNumber(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local topProject       = imageCommon:getChildByName("ProjectNode_top")
    local panelTop         = topProject:getChildByName("Panel_1")
    local labelCardCount   = panelTop:getChildByName("Text_contant_quantity")

    local currentCount = #KPlayer.tCardData.tStoreHouse.tCardList
    labelCardCount:setString(currentCount .. "/" .. KPlayer.tCardData.tStoreHouse.nMaxSize)
end

local function updateScrollItemByCard(self, uiControl, card)
    uiControl:setName(tostring(card.nID))
    KUtil.updateCardBase(uiControl, card)

    local buttonCard = KUtil.getCardBaseActiveFrameButtom(uiControl, card.nID)
   
    local function onUnitClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("onUnitClick~")
            local secretaryData     = KPlayer.tSecretaryData
            require("src/network/KC2SProtocolManager"):changeSecretary(card.nID, SECRETARY_TYPE.DESIGNATE, secretaryData.nState)
            self._parent:removeNode("SecretaryChoose")
        end
    end
    buttonCard:addTouchEventListener(onUnitClick)
end

local function addScrollPageView(self, isCutIn)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")

    local panelScroll    = projectContent:getChildByName("Panel_scroll")
    local slideControl   = panelScroll:getChildByName("Slider_scroll")
    local showListData   = KUtil.getUnitSelectSortList(self._showListData, self._sortType)

    local function refreshCall(control, dataInfo)
        updateScrollItemByCard(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollControl,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        dataList    = showListData,
        refreshCall = refreshCall,
        row         = SHOW_ROW_SIZE,
        column      = SHOW_COLUMN_SIZE,
        spanY       = SHOW_ROW_OFF,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function initUI(self)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
    local buttonUnitBase = scrollControl:getChildByName("Button_unit_base1")

    self._baseControl    = KUtil.getCardBaseNode(buttonUnitBase)
    self._baseControl:retain()

    scrollControl:removeAllChildren()
    
    refreshSortButton(self)
    refreshTypeButton(self)
end

function KUISecretaryChooseNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    initUI(self)
end

function KUISecretaryChooseNode:refreshUI(isCutIn)
    initAllCard(self)
    addScrollPageView(self, isCutIn)
    refreshCardNumber(self)
end

function KUISecretaryChooseNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playBottomAnimation(self, true)
    playTopAnimation(self, true)
    playContentAnimation(self, true)
end

function KUISecretaryChooseNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "dwxz_base")
    
    local mainNode          = self._mainLayout
    local imageControl      = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageControl:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")

    local panelButtonSort = imageControl:getChildByName("Image_screen_base_2")
    local panelButtonType = imageControl:getChildByName("Image_screen_base_1")

    local buttonScreen = imageControl:getChildByName("Button_screen")
    buttonScreen:setSwallowTouches(false)
    buttonScreen:setVisible(false)
    local function hideButtonScreen()
        buttonScreen:setVisible(false)
        if panelButtonType:isVisible() then
            KUtil.showUiScale(panelButtonType, false)
        end
        if panelButtonSort:isVisible() then
            KUtil.showUiScale(panelButtonSort, false)
        end
    end
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            hideButtonScreen()
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)

    local function onSortCall(sortIndex)
        self._sortType = sortIndex
        refreshSortButton(self)
        addScrollPageView(self, true)
        buttonScreen:setVisible(false)
    end
    KUtil.registerSortButtonList(panelButtonSort, onSortCall, KSetting.Key.SECRETARY_COMMON_CHOOSE_TYPE)

    local function onTypeCall(typeIndex)
        self._teamType = typeIndex
        UpdateShowList(self)
        addScrollPageView(self, true)
        buttonScreen:setVisible(false)
    end
    KUtil.registerTypeButtonList(panelButtonType, onTypeCall, KSetting.Key.SECRETARY_TEAM_CHOOSE_TYPE)

    local buttonSort = panleBottom:getChildByName("Button_common_sort")
    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(panelButtonType, false)
            local isVisible = not panelButtonSort:isVisible()
            KUtil.showUiScale(panelButtonSort, isVisible)
            buttonScreen:setVisible(isVisible)
            KSound.playEffect("click")
            cclog("onSortClick~")
        end
    end
    buttonSort:addTouchEventListener(onSortClick)

    local buttonType = panleBottom:getChildByName("Button_common_type")
    local function onTypeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(panelButtonSort, false)
            local isVisible = not panelButtonType:isVisible()
            KUtil.showUiScale(panelButtonType, isVisible)
            buttonScreen:setVisible(isVisible)
            KSound.playEffect("click")
            cclog("onTypeClick~")
        end
    end
    buttonType:addTouchEventListener(onTypeClick)
end

function KUISecretaryChooseNode:registerAllCustomEvent()
end

function KUISecretaryChooseNode:onCleanup()
    self._baseControl:release() 
end

return KUISecretaryChooseNode
