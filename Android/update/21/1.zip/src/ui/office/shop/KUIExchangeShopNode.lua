--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExchangeShopNode.lua
--  Creator     : Huang Yixin
--  Date        : 2016/07/28   10:00
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local EXCHANGE_COIN_ID   = 96
local KUIExchangeShopNode = class(
    "KUIExchangeShopNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExchangeShopNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._pageIndex             = nil
    self._panelBase             = nil
    self._pageCount             = 0
    self._animationList         = {}
end

function KUIExchangeShopNode.create(owner)
    local currentNode   = KUIExchangeShopNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_exchange_shop.csb"
    currentNode:init()

    return currentNode
end

local function loadTextureAndScaleToFix(imageView, imagePath)
    local contentSize =  imageView:getContentSize()
    local oldWidth    = contentSize.width
    local oldHeight   = contentSize.height
    local oldScaleX   = imageView:getScaleX()
    local oldScaleY   = imageView:getScaleY()
    local realWidth   = oldWidth * oldScaleX
    local realHeight  = oldHeight * oldScaleY

    imageView:loadTexture(imagePath)
    local contentSize = imageView:getContentSize()
    local newWidth    = contentSize.width
    local newHeight   = contentSize.height
    if newWidth == 0 or newHeight == 0 then return end
    local newScaleX = realWidth  / newWidth
    local newScaleY = realHeight / newHeight
    imageView:setScaleX(newScaleX)
    imageView:setScaleY(newScaleY)
end

local function getProjectNode(self, nodeName)
    local mainNode      = self._mainLayout
    local imageShopBase = mainNode:getChildByName("Image_shop_base")
    local projectNode   = imageShopBase:getChildByName(nodeName)
    assert(projectNode, nodeName)
    return projectNode
end

local function getProjectNodeTitle(self)
    return getProjectNode(self, "ProjectNode_title")
end

local function getProjectNodeChara(self)
    return getProjectNode(self, "ProjectNode_chara")
end

local function getProjectNodeShop(self)
    return getProjectNode(self, "ProjectNode_goods")
end

local function getPageViewShop(self)
    local projectNodeShop = getProjectNodeShop(self)
    local imageShopFrame  = projectNodeShop:getChildByName("Image_shop_frame")
    local pageView        = imageShopFrame:getChildByName("PageView_list")
    return pageView
end

local function getCoinImagePath(coinType, coinID)
    if coinType == ITEM_TYPE.CURRENCY then
        return KUtil.getCurrencyImagePath(coinID)
    elseif coinType == ITEM_TYPE.OTHER then
        return KUtil.getItemImagePathByID(coinID)
    else
        return nil
    end
end

local function pageChange(self)
    local pageView  = getPageViewShop(self)
    local pageCount = self._pageCount

    if self._pageIndex < 0 then 
        self._pageIndex = pageCount - 1
    elseif self._pageIndex > pageCount - 1 then 
        self._pageIndex = 0
    end

    pageView:scrollToPage(self._pageIndex) 
end

local function refreshCoinArea(self)
    local projectNodeTitle  = getProjectNodeTitle(self)
    local panelBase         = projectNodeTitle:getChildByName("Panel_1")
    local imageResourceBase = panelBase:getChildByName("Image_resource_base")
    local imageDiamond      = imageResourceBase:getChildByName("Image_resource_diamond")
    local textDiamond       = imageDiamond:getChildByName("BitmapFontLabel_diamond")
    textDiamond:setString(KPlayer.coin)

    local imageMedal        = imageResourceBase:getChildByName("Image_resource_medal")
    local textMedal         = imageMedal:getChildByName("BitmapFontLabel_medal")
    textMedal:setString(KUtil.getItemCount(EXCHANGE_COIN_ID))
end

local function refreshCharacter(self)
    local projectNodeChara = getProjectNodeChara(self)
    local panelChara       = projectNodeChara:getChildByName("Panel_chara")
    local imageCharaShadow = panelChara:getChildByName("Image_chara_shadow")
    local imageChara       = panelChara:getChildByName("Image_chara")

    local displayCardID = 1
    local isHead        = false
    local isBreak       = false
    local imagePath     = KUtil.getCardImagePathByConfigID(displayCardID, false)
    imageChara:loadTexture(imagePath)
    imageCharaShadow:loadTexture(imagePath)
end

local function refreshShopPageViewItem(self, itemUI, itemInfo)
    if not itemInfo then itemUI:setVisible(false) return end
    itemUI:setVisible(true)
    itemUI:setName(tostring(itemInfo.nID))

    local textName = itemUI:getChildByName("Text_name_value")
    textName:setString(itemInfo.szName)

    local textDescription = itemUI:getChildByName("Text_diamond")
    textDescription:setString(itemInfo.szDescription)
    
    local itemType, itemID, itemNum = itemInfo.nItemType, itemInfo.nItemID, itemInfo.nItemCount
    local filePath, scale = KUtil.getRewardItemPathAndScale(itemType, itemID)
    local imageIcon = itemUI:getChildByName("Image_icon")
    imageIcon:loadTexture(filePath)
    imageIcon:setScale(scale * 1.3)
    
    local buttonUnit = itemUI:getChildByName("Button_unit")
    local textCost = buttonUnit:getChildByName("BitmapFontLabel_medal")
    textCost:setString(tostring(itemInfo.nPrice))

    local imageMedal = buttonUnit:getChildByName("Image_medal_august")
    local coinImagePath = getCoinImagePath(itemInfo.nCoinType, itemInfo.nCoinID)
    assert(coinImagePath, "exchange shop, coin image path unfound.")
    loadTextureAndScaleToFix(imageMedal, coinImagePath)

    local goodID = itemInfo.nID
    local isBuy   = KUtil.isCanBuy(goodID)
    KUtil.setTouchEnabled(buttonUnit, isBuy)
    local function onClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if not KUtil.isCanBuy(goodID) then return end
        cclog("buy Good, goodID = :" .. goodID)
        KUtil.buyRequest(KUtil.shopType.EXCHANGE, goodID)
    end
    buttonUnit:addTouchEventListener(onClick)
end

local function refreshShopPageView(self )
    local pageView     = getPageViewShop(self)
    local panelBase    = self._panelBase    
    local rowSize      = 4
    local colSize      = 2
    local pageUnitSize = rowSize * colSize

    local itemListData = KUtil.getSortListByType(KUtil.shopType.EXCHANGE)
    table.output(itemListData)

    local itemCount    = #itemListData
    local pageCount    = (itemCount - 1)/pageUnitSize + 1

    pageView:removeAllPages()
    for pageIndex = 1, pageCount do
        local panelUI = panelBase:clone()
        pageView:addPage(panelUI)
        for itemIndex = 1, pageUnitSize do
            local currentIndex   = (pageIndex - 1) * pageUnitSize + itemIndex
            local itemInfo       = itemListData[currentIndex]
            local itemUI         = panelUI:getChildByName(string.format("Image_item_unit_%d", itemIndex))
            refreshShopPageViewItem(self, itemUI, itemInfo)
        end
    end

    --need delay one frame
    local scrollToPage = function()
        pageView:scrollToPage(0)
        self._pageIndex = pageView:getCurPageIndex()
    end
    delayExecute(pageView, scrollToPage, 0.0)
    self._pageCount = pageCount
end

local function refreshShopArea(self)
    refreshShopPageView(self)
end

local function initPanelUIBase(self)
    local pageView        = getPageViewShop(self)
    local panelUnit       = pageView:getChildByName("Panel_unit")
    self._panelBase = panelUnit
    self._panelBase:retain()
end

local function getAnimationDuration(self, isEnter)
    local animationList = self._animationList
    local animationKeys = {"title", "chara", "goods"}
    local duration      = 0
    for i, k in pairs(animationKeys) do
        local anima = animationList[k]
        if isEnter then
            duration = math.max(duration, anima.enterEndedFrame - anima.enterStartFrame)
        else
            duration = math.max(duration, anima.exitEndedFrame - anima.exitStartFrame)
        end
    end
    return duration / KUtil.FRAME_PER_SECOND
end


local function getAnimation(self, isEnter)
    local animationList = self._animationList
    local duration      = getAnimationDuration(self, isEnter)

    local function callAnimation()
        local animationKeys = {"title", "chara", "goods"}
        for i, k in pairs(animationKeys) do
            local anima = animationList[k]
            if isEnter then
                KUtil.playAnimationByAnimation(anima.animation, anima.enterStartFrame, anima.enterEndedFrame)
            else
                KUtil.playAnimationByAnimation(anima.animation, anima.exitStartFrame, anima.exitEndedFrame)
            end
        end
    end
    
    local frameAction = cc.Sequence:create(
        cc.CallFunc:create(callAnimation),
        cc.DelayTime:create(duration)
    )

    return frameAction, duration
end

local function initAnimation(self)
    local mainNode      = self._mainLayout
    local imageShopBase = mainNode:getChildByName("Image_shop_base")

    local animationList  = self._animationList
    local projectNode    = imageShopBase:getChildByName("ProjectNode_title")
    local animationPath  = "res/ui/animation_node/ani_exchange_shop_title.csb"
    local animationTitle = {
        ["animation"]       = KUtil.initAnimation(projectNode, animationPath),
        ["enterStartFrame"] = 0,
        ["enterEndedFrame"] = 15,
        ["exitStartFrame"]  = 50,
        ["exitEndedFrame"]  = 65,
    }
    animationList.title = animationTitle

    local projectNode    = imageShopBase:getChildByName("ProjectNode_chara")
    local animationPath  = "res/ui/animation_node/ani_exchange_shop_chara.csb"
    local animationChara = {
        ["animation"]       = KUtil.initAnimation(projectNode, animationPath),
        ["enterStartFrame"] = 0,
        ["enterEndedFrame"] = 15,
        ["exitStartFrame"]  = 50,
        ["exitEndedFrame"]  = 65,
    }
    animationList.chara = animationChara

    local projectNode    = imageShopBase:getChildByName("ProjectNode_goods")
    local animationPath  = "res/ui/animation_node/ani_exchange_shop.csb"
    local animationGoods = {
        ["animation"]       = KUtil.initAnimation(projectNode, animationPath),
        ["enterStartFrame"] = 0,
        ["enterEndedFrame"] = 15,
        ["exitStartFrame"]  = 50,
        ["exitEndedFrame"]  = 65,
    }
    animationList.goods = animationGoods
end


function KUIExchangeShopNode:refreshUI()
    refreshCoinArea(self)
    refreshCharacter(self)
    refreshShopArea(self)
end

function KUIExchangeShopNode:onInitUI()
    initAnimation(self)
    initPanelUIBase(self)
end

function KUIExchangeShopNode:getEnterAction()
    local enterAction, duration = getAnimation(self, true)
    return enterAction, duration
end

function KUIExchangeShopNode:getExitAction()
    local exitAction, duration = getAnimation(self, false)
    return exitAction, duration
end

function KUIExchangeShopNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local projectNodeTitle = getProjectNodeTitle(self)
    local panelBase        = projectNodeTitle:getChildByName("Panel_1")
    local imageResourceBase = panelBase:getChildByName("Image_resource_base")
    local buttonClose       = imageResourceBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("ExchangeShop")
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local projectNodeShop = getProjectNodeShop(self)
    local imageShopFrame  = projectNodeShop:getChildByName("Image_shop_frame")
    local pageView        = imageShopFrame:getChildByName("PageView_list")
    local buttonLeft      = imageShopFrame:getChildByName("Button_left")
    local buttonRight     = imageShopFrame:getChildByName("Button_right")
    
    --Page Right Button
    local function onPageRightClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            cclog("click onPageRightButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex + 1
            pageChange(self)
        end
    end
    buttonRight:addTouchEventListener(onPageRightClick)

    --Page Left Button
    local function onPageLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPageLeftButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex - 1
            pageChange(self)
        end
    end
    buttonLeft:addTouchEventListener(onPageLeftClick)

    --set pageView touch feeling
    pageView:setCustomScrollThreshold(100)
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then 
            self._pageIndex = pageView:getCurPageIndex()
        end
    end
    pageView:addEventListener(onPageViewEvent)
end

function KUIExchangeShopNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBuyGoodSuccess(goodID, nResult, nBuyCount)
        if nResult == BUY_RET.SUCCESS then
            cclog("----------> onEvent NET_BUY_GOOD_SUCCESS %d", goodID)
            refreshCoinArea(self)
            KUtil.showBuySuccessTip(goodID, nBuyCount)
        elseif nResult == BUY_RET.OVERDUE then
            showNoticeByID("shop.goodsOverdue")
        elseif nResult == BUY_RET.COINNOTENOUGH then
            local tGoodsConfig = KConfig.shop[goodID]
            showNoticeByID("common.lessResource", KUtil.getItemName(tGoodsConfig.nCoinType, tGoodsConfig.nCoinID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_GOOD_SUCCESS, onBuyGoodSuccess) 

    local function onUpdateBuyCount(nGoodsID, nBuyCount)
        local pageView  = getPageViewShop(self) 
        local itemUI    = ccui.Helper:seekWidgetByName(pageView, tostring(nGoodsID))
        if itemUI then
            local buttonUnit = itemUI:getChildByName("Button_unit")
            KUtil.setTouchEnabled(buttonUnit, KUtil.isCanBuy(nGoodsID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_COUNT, onUpdateBuyCount) 
end

function KUIExchangeShopNode:onCleanup()
    self._panelBase:release()  
end

return KUIExchangeShopNode
