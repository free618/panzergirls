--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIStoryPlayNode.lua
--  Creator     : ChenJiaLiang
--  Date        : 2016/06/22   13:45
--  Contact     : chenjialiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local PlayControl  = require("src/logic/KStoryPlayControl")

local BlackPath = "res/ui/ui_material/guide/black.png"
local FaceName  = {"happy", "sad", "shy", "anger", "shock"}

local KUIStoryPlayNode = class(
    "KUIStoryPlayNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIStoryPlayNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._animationList         = {}
    self._enterExitAnimation    = {}
end

function KUIStoryPlayNode.create(owner, storyPath)
    local currentNode       = KUIStoryPlayNode.new()
    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_studio_theatre_dialog.csb"
    currentNode._storyPath  = storyPath
    currentNode:init()

    return currentNode
end

local function initData(self)
    local mainNode    = self._mainLayout
    local buttonBase  = mainNode:getChildByName("Button_base")
    local charaNode   = mainNode:getChildByName("Node_chara_expression")
    local charaUnit   = charaNode:getChildByName("Panel_chara_BT-2")
    self._charaUnit   = charaUnit
    charaUnit:retain()
    charaUnit:removeFromParent()
    charaNode:setVisible(false)

    local topImage = ccui.ImageView:create(BlackPath)
    local viewSize = cc.Director:getInstance():getWinSize()
    self._mainLayout:addChild(topImage, 999)
    
    topImage:setPosition(cc.p(0, 0))
    topImage:setAnchorPoint(0, 0)
    topImage:ignoreContentAdaptWithSize(false)
    topImage:setContentSize(cc.size(viewSize.width, viewSize.height))
    topImage:setVisible(false)
    self._topImage = topImage

    local asideImage = ccui.ImageView:create(BlackPath)
    asideImage:setName("aside")
    self._mainLayout:addChild(asideImage, 900)
    asideImage:setPosition(cc.p(0, 0))
    asideImage:setAnchorPoint(0, 0)
    asideImage:ignoreContentAdaptWithSize(false)
    asideImage:setContentSize(cc.size(viewSize.width, viewSize.height))    
    asideImage:setVisible(false)
    self._asideImage = asideImage

    local buttonPass  = mainNode:getChildByName("Button_pass")
    buttonPass:setVisible(false)

    local dialog = self:getDialog()
    local label  = dialog:getChildByName("BitmapFontLabel_dialogue_1")
    label:setString("")

    self:hideDialog()
    self:showCharaFace(charaUnit, "", "")
end

function KUIStoryPlayNode:showCharaFace(charaUnit, faceName, imagePath)
    local imageChara = charaUnit:getChildByName("Image_chara")
    for _, name in ipairs(FaceName) do
        local image = imageChara:getChildByName("Image_chara_" .. name)
        if name == faceName then
            image:setVisible(true)
            image:loadTexture(imagePath)
        else
            image:setVisible(false)
        end
    end
end

function KUIStoryPlayNode:playAnimation(aniName, frameConfigName)
    local aniConfig = self._animationList[aniName]
    if not aniConfig then
        return
    end

    local frameConfig = aniConfig[frameConfigName]
    return KUtil.playAnimationByAnimation(aniConfig.ani, frameConfig[1], frameConfig[2])
end

function KUIStoryPlayNode:activate(nowTime)
end

function KUIStoryPlayNode:onInitUI()
    initData(self)
    self:initContent()
end

function KUIStoryPlayNode:initContent()
    
end

function KUIStoryPlayNode:refreshUI()
end

function KUIStoryPlayNode:registerAllTouchEvent()
    local buttonClose = self._mainLayout:getChildByName("Button_pass")
    local function onClose(sender, type)
        if type == ccui.TouchEventType.ended then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.UI_STORY_PLAY_END)

            KUtil.closePanel(self, "StoryPlay", false)
        end
    end
    buttonClose:addTouchEventListener(onClose)

    local buttonBase = self._mainLayout:getChildByName("Button_base")
    local function onClickBase(sender, type)
        if type == ccui.TouchEventType.ended then
            PlayControl.onClickBase()
        end
    end
    buttonBase:addTouchEventListener(onClickBase)
end

function KUIStoryPlayNode:getEnterAction()
    return nil, nil
end

function KUIStoryPlayNode:onEnterActionFinished()
    --self:enterAnimation()
    PlayControl.startWithFile(self._storyPath, self)
end

function KUIStoryPlayNode:onNodeEnter()
end

function KUIStoryPlayNode:onNodeExit()
end

function KUIStoryPlayNode:enterAnimation()    
    for _, aniName in pairs(self._enterExitAnimation) do
        self:playAnimation(aniName, "enter")
    end
end

function KUIStoryPlayNode:exitAnimation()
    local delayTime = 0
    for _, aniName in pairs(self._enterExitAnimation) do
        local aniTime = self:playAnimation(aniName, "exit")
        if aniTime > delayTime then
            delayTime = aniTime
        end
    end

    return delayTime
end

function KUIStoryPlayNode:playPanelCloseAnimation(isReturnOffice)
end

function KUIStoryPlayNode:registerAllCustomEvent(parameters)
end

function KUIStoryPlayNode:getNewCharaNode()
    return self._charaUnit:clone()
end

function KUIStoryPlayNode:getDialog()
    return self._mainLayout:getChildByName("Panel_dialog_big")
end

function KUIStoryPlayNode:hideDialog()
    local dialog = self._mainLayout:getChildByName("Panel_dialog_big")
    dialog:setVisible(false)
end


function KUIStoryPlayNode:getAside()
    return self._asideImage
end

function KUIStoryPlayNode:hideAside()
    self._asideImage:setVisible(false)
end

function KUIStoryPlayNode:getButtonBase()
    return self._mainLayout:getChildByName("Button_base")
end

function KUIStoryPlayNode:getTopImage()
    return self._topImage
end

function KUIStoryPlayNode:onCleanup()
    self._charaUnit:release()
end

return KUIStoryPlayNode