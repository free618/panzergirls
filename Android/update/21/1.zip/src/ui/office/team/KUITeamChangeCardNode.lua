--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamChangeCardNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/3/13   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     : 
--  *********************************************************************


local SHOW_ROW_SIZE    = 4
local SHOW_COLUMN_SIZE = 7
local SHOW_ROW_OFF     = -5     -- 行偏移
local VALID_OFF        = 20
local FIRST_NODE_ID    = -1
local KSetting = require("src/logic/KSetting")

local m_BouttonUnit =
{
    ["normal"]   = "res/ui/ui_material/cardbase/card_%s_buttom.png", 
    ["press"]    = "res/ui/ui_material/cardbase/card_%s_buttom_active.png", 
    ["disable"]  = "res/ui/ui_material/cardbase/card_%s_buttom.png",
}

local KUITeamChangeCardNode = class(
    "KUITeamChangeCardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamChangeCardNode:ctor()
    self._mainLayout       = nil
    self._parent           = nil
    self._uiPath           = nil
    self._teamID           = nil
    self._teamIndex        = nil
    self._panelType        = nil
    self._haveLeaveTeam    = true
    self._sortType         = KSetting.getInt(KSetting.Key.COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    self._teamType         = KSetting.getInt(KSetting.Key.TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
    self._baseControl      = nil
    self._leaveControl     = nil
    self._attributeControl = nil
    self._baseListData     = {}
    self._showListData     = {}
    self._showAttribute    = false
    self._canEnterDetail   = false
    self._pageData         = {}
    self._selectedMap      = {}
    self._lockSelectStatus = false
end

function KUITeamChangeCardNode.create(owner, nodeData)
    local currentNode      = KUITeamChangeCardNode.new()

    currentNode._parent    = owner
    currentNode._uiPath    = "res/ui/layout_unit_choose.csb"
    currentNode._teamID    = nodeData.teamID
    currentNode._teamIndex = nodeData.nodeUnitID
    currentNode._panelType = nodeData.panelType
    if nodeData.sortType then
        currentNode._sortType  = nodeData.sortType
    end
    if nodeData.cardType then
        currentNode._teamType  = nodeData.cardType
    end
    -- check exist leave button
    if currentNode._panelType == CARD_SELECT_PANEL_TYPE.ADD then
        currentNode._haveLeaveTeam = false
    elseif KUtil.getTeamSize(currentNode._teamID) == 1 and currentNode._teamID == 1 then
        currentNode._haveLeaveTeam = false
    end

    currentNode:init()

    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_button")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_unit_choose_bottom"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTopAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_top")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_unit_choose_top"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playContentAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_content")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_unit_choose_content"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()

    local projectNode     = imageCommon:getChildByName("ProjectNode_button")
    projectNode:stopAllActions()

    local projectNode = imageCommon:getChildByName("ProjectNode_content")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playContentAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "TeamChangeCard", callBacks, isReturnOffice)
end

local function deyalAddAttributePanel(self)
    if not self._pageData.itemList or not self._pageData.dataList then
        return
    end
    local cardMap = {}
    for k, v in pairs(self._pageData.dataList) do
        cardMap[tostring(v.nID)] = v
    end
    for _, baseNode in ipairs(self._pageData.itemList) do
        local nodeName = baseNode:getName()
        -- delay create attribute panel
        local panelAttribute = baseNode:getChildByName("Image_attribute_base")
        if not panelAttribute then
            panelAttribute = self._attributeControl:clone()
            baseNode:addChild(panelAttribute)
        end
        local oneCard = cardMap[nodeName] 
        if self._showAttribute and oneCard and oneCard.nID ~= FIRST_NODE_ID then
            KUtil.updateCardAttributePanel(panelAttribute, oneCard)
        end
        panelAttribute:setVisible(false)
        if nodeName ~= tostring(FIRST_NODE_ID) then
            panelAttribute:setVisible(self._showAttribute)
        end
    end
end

local function refreshAttribute(self)
    self._showAttribute = not self._showAttribute
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageCommon:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    local buttonDetail      = panleBottom:getChildByName("Button_detail")
    local textDetail        = buttonDetail:getChildByName("Text_detail")
    local stringDetail      = KUtil.getStringByKey("team.detail")
    if self._showAttribute then
        stringDetail = KUtil.getStringByKey("team.return")
    end
    textDetail:setString(stringDetail)

    deyalAddAttributePanel(self)
end

local function showLockTip(tCardList)
    local lockCount, unLockCount = 0, 0
    for _, card in ipairs(tCardList) do
        if card.bLock then
            lockCount = lockCount + 1
        else
            unLockCount = unLockCount + 1
        end
    end
    showNoticeByID("card.lock", lockCount, unLockCount)
end

local function setTeamUnit(self, tCardId)
    local chooseTeamID         = self._teamID
    local position             = self._teamIndex
    local isSameTemplateInTeam = KUtil.isSameTemplateCardInTeam(tCardId, chooseTeamID, position)
    if isSameTemplateInTeam then
        showNoticeByID("team.selectSameCard")
        return
    end

    local changeCardID = KUtil.getCardInTeam(chooseTeamID, position)
    local enterTeamIndex = KUtil.getEnterTeamId(tCardId)
    if changeCardID ~= 0 and enterTeamIndex ~= 0 and enterTeamIndex ~= chooseTeamID then
        local targtePosition = KUtil.getPositionInTeam(enterTeamIndex, tCardId)
        isSameTemplateInTeam = KUtil.isSameTemplateCardInTeam(changeCardID, enterTeamIndex, targtePosition)
        if isSameTemplateInTeam then
            showNoticeByID("team.selectSameCard")
            return
        end
    end
    local isFirstBeEmpty = KUtil.isFirstTeamChangeToEmpty(tCardId, chooseTeamID, position)
    if isFirstBeEmpty then
        showNoticeByID("team.firstTeamEmpty")
        return
    end
    
    local isTeamExpedition = KUtil.isTeamInExpedition(chooseTeamID)
    if isTeamExpedition then
        showNoticeByID("expedition.onExpedition")
        return
    end
    -- send protocol
    require("src/network/KC2SProtocolManager"):cardEnterTeam(tCardId, chooseTeamID, position)
    cclog("-------------------->setTeamUnit: tCardId:%d chooseTeamID:%d position:%d",tCardId, chooseTeamID, position)
end

local function leaveTeamUnit(self)
    local oldTeamID     = self._teamID
    local oldTeamIndex  = self._teamIndex
    local oldCardID     = KUtil.getCardInTeam(oldTeamID, oldTeamIndex)

    local isTeamExpedition = KUtil.isTeamInExpedition(oldTeamID)
    if isTeamExpedition then
        showNoticeByID("expedition.onExpedition")
        return
    end
    -- send protocol
    require("src/network/KC2SProtocolManager"):cardLeaveTeam(oldCardID)
    cclog("-------------------->leaveTeamUnit: oldCardID:%d", oldCardID)
end

local function refreshSortButton(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageCommon:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    local panelSort         = panleBottom:getChildByName("Button_common_sort")

    KUtil.refreshCardSortButton(panelSort, self._sortType)
end

local function refreshTypeButton(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageCommon:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    local panelType         = panleBottom:getChildByName("Button_common_type")

    KUtil.refreshCardTypeButton(panelType, self._teamType)
end

local function refreshLockButtonStatus(self, isLockMode)
    local mainNode                = self._mainLayout
    local imageControl            = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode       = imageControl:getChildByName("ProjectNode_button")
    local panelChooseBottom       = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom             = panelChooseBottom:getChildByName("Image_kb_base_2")

    local buttonLockConfirmButton = panleBottom:getChildByName("Button_locking_confirm_button")
    local buttonLockButton        = panleBottom:getChildByName("Button_locking_button")
    buttonLockConfirmButton:setVisible(isLockMode)
    buttonLockButton:setVisible(not isLockMode)
end

local function getButtonUnitPath(cardID)
    local cardCountryName           = KUtil.getCardCountryName(cardID)
    local buttonUnitPressPath       = string.format(m_BouttonUnit["press"],cardCountryName)
    local buttonUnitNormalPath      = string.format(m_BouttonUnit["normal"],cardCountryName)
    local buttonUnitDisablePath     = string.format(m_BouttonUnit["disable"],cardCountryName)

    return buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath
end

local function refreshButtonStatus(self, uiControl, isSelected)
    local cardID     = uiControl:getName()
    cardID    = tonumber(cardID)
    if not cardID or cardID <= 0 then return end

    local buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath = getButtonUnitPath(cardID)

    local frameButtom = KUtil.getCardBaseActiveFrameButtom(uiControl, cardID)
    if isSelected then
        frameButtom:loadTextures(buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath)
    else
        frameButtom:loadTextures(buttonUnitNormalPath, buttonUnitPressPath, buttonUnitDisablePath)
    end
end

local function changeControlButtonStatus(self, uiControl)
    local cardID     = uiControl:getName()
    local nCardID    = tonumber(cardID)
    if not nCardID or nCardID <= 0 then return end

    local isSelected = self._selectedMap[nCardID]
    isSelected       = not isSelected
    if isSelected then
        self._selectedMap[nCardID] = true
    else
        self._selectedMap[nCardID] = nil
    end
    refreshButtonStatus(self, uiControl, isSelected)
end

local function changeToLockMode(self)
    self._lockSelectStatus = true
    refreshLockButtonStatus(self, true)
end

local function lockSelectedList(self)
    self._lockSelectStatus = false
    local lockList = {}
    local cardList = KPlayer.tCardData.tStoreHouse.tCardList
    for _, card in pairs(cardList) do
        local isLockCard = self._selectedMap[card.nID]
        if isLockCard then
            table.insert(lockList, {nID = card.nID, bLock = card.bLock})
        end
    end
    -- lockList
    if #lockList > 0 then
        require("src/network/KC2SProtocolManager"):LockCardList(lockList)
    end
    -- unlock ui
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
    for cardID, v in pairs(self._selectedMap) do
        local uiControl = scrollControl:getChildByName(tostring(cardID))
        if uiControl then
            refreshButtonStatus(self, uiControl, false)
        end
    end
    self._selectedMap = {}
    refreshLockButtonStatus(self, false)
end

local function UpdateShowList(self)
    self._showListData = KUtil.getCardsByKey(self._baseListData, self._teamType)
    refreshTypeButton(self)
end

local function initAllCardExceptExpedition(self)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    local teamList = KPlayer.tTeamData.tTeamList
    local cardInExpedition = {}
    local enterTeam = {}
    for i, oneExpedition in pairs(expeditionList) do
        enterTeam[oneExpedition.nTeamID] = true
    end
    for tTeamID, isTrue in pairs(enterTeam) do
        local oneTeam = HArray.FindFirst(teamList, "nIndex", tTeamID)
        if oneTeam then 
            for i, cardID in pairs(oneTeam.tCardIDList) do
               cardInExpedition[cardID] = true
            end
        end
    end
    self._baseListData = {}
    for i, oneCard in pairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        if not cardInExpedition[oneCard.nID] then
            table.insert(self._baseListData, oneCard)
        end
    end

    UpdateShowList(self)
end

local function refreshCardNumber(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local topProject       = imageCommon:getChildByName("ProjectNode_top")
    local panelTop         = topProject:getChildByName("Panel_1")
    local labelCardCount   = panelTop:getChildByName("Text_contant_quantity")

    local currentCount = #KPlayer.tCardData.tStoreHouse.tCardList
    labelCardCount:setString(currentCount .. "/" .. KPlayer.tCardData.tStoreHouse.nMaxSize)
end

local function setLockButton(unitControl, isLock)
    if not unitControl then return end
    local button = unitControl:getChildByName("Image_lock")
    local bIsLock = (isLock == true)
    button:setVisible(bIsLock)
end

local function setLevelTeamCard(self, unitControl)
    local leaveParent = self._leaveControl:getParent()
    if leaveParent then
        leaveParent:removeChild(self._leaveControl)
        for _, node in ipairs(leaveParent:getChildren()) do
            node:setVisible(true)
        end
    end
    for _, node in ipairs(unitControl:getChildren()) do
        node:setVisible(false)
    end
    unitControl:addChild(self._leaveControl)
    self._leaveControl:setVisible(true)
end

local function updateScrollItemByCard(self, uiControl, card)
    -- handle special node
    if card.nID == FIRST_NODE_ID then
        setLevelTeamCard(self, uiControl)
        uiControl:setName(tostring(card.nID))
        return
    end
    local buttonLeave = uiControl:getChildByName("Button_leave")
    if buttonLeave then
        uiControl:removeChild(buttonLeave)
        for _, node in ipairs(uiControl:getChildren()) do
            node:setVisible(true)
        end
    end
    -- update disable flag
    uiControl:setName(tostring(card.nID))
    setLockButton(uiControl, card.bLock)
    

    local isSelected = self._selectedMap[card.nID]
    refreshButtonStatus(self, uiControl, isSelected)

    -- update card
    KUtil.updateCardBase(uiControl, card, false, self._showAttribute, false, true)

    --Item Click Event
    local buttonCard = KUtil.getCardBaseActiveFrameButtom(uiControl, card.nID)
    local startTime = 0

    local enterDetailFun = function()
        if self._canEnterDetail then
            local nodeData = {cardID = card.nID,}
            self._parent:addNode("TeamCharacter", nodeData)
        end
    end
    local startX    = 0
    local startY    = 0
    local startTime = 0
    local function onUnitClick(sender, type)
        if ccui.TouchEventType.began == type then
            if self._lockSelectStatus then return end
            local startPos       = sender:getTouchBeganPosition()
            startX               = startPos.x
            startY               = startPos.y
            startTime            = C_GetTickCount()
            self._canEnterDetail = true
            delayExecute(buttonCard, enterDetailFun, KUtil.KEEP_DOWN_SECOND)
        elseif ccui.TouchEventType.moved == type then
            if self._lockSelectStatus then return end
            local endPos = sender:getTouchMovePosition()
            local endX   = endPos.x
            local endY   = endPos.y
            if math.abs(startX - endX) > VALID_OFF or  math.abs(startY - endY) > VALID_OFF then 
                if self._canEnterDetail then
                    self._canEnterDetail = false
                    buttonCard:stopAllActions()
                end
            end
        elseif ccui.TouchEventType.canceled == type then
            if self._lockSelectStatus then return end
            self._canEnterDetail = false
            buttonCard:stopAllActions()
        elseif ccui.TouchEventType.ended == type then
            if self._lockSelectStatus then 
                changeControlButtonStatus(self, uiControl)
                return
            end
            if not self._canEnterDetail then return end
            self._canEnterDetail = false
            buttonCard:stopAllActions()
            local passTime    = C_GetTickCount() - startTime
            local milliSecond = KUtil.KEEP_DOWN_SECOND * KUtil.MILLI_SECOND_RATE
            if passTime < milliSecond then
                KSound.playEffect("click")
                setTeamUnit(self, card.nID)
            end
        end
    end
    buttonCard:addTouchEventListener(onUnitClick)
    buttonCard:setSwallowTouches(false)
end

local function addScrollPageView(self, isCutIn)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")

    local panelScroll    = projectContent:getChildByName("Panel_scroll")
    local slideControl   = panelScroll:getChildByName("Slider_scroll")
    local showListData   = KUtil.getUnitSelectSortList(self._showListData, self._sortType)

    local tempList       = showListData
    if self._haveLeaveTeam then
        tempList         = table.shallowcopy(showListData)
        table.insert(tempList, 1, {nID = FIRST_NODE_ID})
    end
    local function refreshCall(control, dataInfo)
        updateScrollItemByCard(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollControl,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        dataList    = tempList,
        refreshCall = refreshCall,
        row         = SHOW_ROW_SIZE,
        column      = SHOW_COLUMN_SIZE,
        spanY       = SHOW_ROW_OFF,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)

    if self._showAttribute then
        deyalAddAttributePanel(self)
    end
end

local function initUI(self)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
    local buttonUnitBase = scrollControl:getChildByName("Button_unit_base1")
    local buttonLeave    = buttonUnitBase:getChildByName("Button_leave")

    self._leaveControl   = buttonLeave
    self._leaveControl:retain()

    self._baseControl    = KUtil.getCardBaseNode(buttonUnitBase)
    self._baseControl:retain()

    self._attributeControl = self._baseControl:getChildByName("Image_attribute_base")
    self._attributeControl:retain()

    self._baseControl:removeChild(self._attributeControl)

    scrollControl:removeAllChildren()
    -- update button visible
    refreshSortButton(self)
    refreshTypeButton(self)
end

function KUITeamChangeCardNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    initUI(self)
    refreshLockButtonStatus(self, false)
end

function KUITeamChangeCardNode:refreshUI(isCutIn)
    --init data
    initAllCardExceptExpedition(self)
    -- update scroll view
    addScrollPageView(self, isCutIn)
    -- update card count in total
    refreshCardNumber(self)
end

function KUITeamChangeCardNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playBottomAnimation(self, true)
    playTopAnimation(self, true)
    playContentAnimation(self, true)
end

function KUITeamChangeCardNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "dwxz_base")
    
    local mainNode          = self._mainLayout
    local imageControl      = mainNode:getChildByName("Image_common_base")
    local bottomProjectNode = imageControl:getChildByName("ProjectNode_button")
    local panelChooseBottom = bottomProjectNode:getChildByName("Panel_choose_bottom")
    local panleBottom       = panelChooseBottom:getChildByName("Image_kb_base_2")
    
    local function onLeaveTeamClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            leaveTeamUnit(self)
            KUtil.setTouchEnabled(self._leaveControl, false)
            cclog("onLeaveTeamClick~")
        end
    end
    self._leaveControl:addTouchEventListener(onLeaveTeamClick)

    local buttonDetail = panleBottom:getChildByName("Button_detail")
    local function onDetailClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            refreshAttribute(self)
            cclog("onDetailClick~")
        end
    end
    buttonDetail:addTouchEventListener(onDetailClick)

    local panelButtonSort = imageControl:getChildByName("Image_screen_base_2")
    local panelButtonType = imageControl:getChildByName("Image_screen_base_1")

    local buttonScreen = imageControl:getChildByName("Button_screen")
    buttonScreen:setSwallowTouches(false)
    buttonScreen:setVisible(false)
    local function hideButtonScreen()
        buttonScreen:setVisible(false)
        if panelButtonType:isVisible() then
            KUtil.showUiScale(panelButtonType, false)
        end
        if panelButtonSort:isVisible() then
            KUtil.showUiScale(panelButtonSort, false)
        end
    end
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            hideButtonScreen()
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)

    local function onSortCall(sortIndex)
        self._sortType = sortIndex
        refreshSortButton(self)
        addScrollPageView(self, true)
        buttonScreen:setVisible(false)
    end
    KUtil.registerSortButtonList(panelButtonSort, onSortCall)

    local function onTypeCall(typeIndex)
        self._teamType = typeIndex
        UpdateShowList(self)
        addScrollPageView(self, true)
        buttonScreen:setVisible(false)
    end
    KUtil.registerTypeButtonList(panelButtonType, onTypeCall)

    local buttonSort = panleBottom:getChildByName("Button_common_sort")
    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(panelButtonType, false)
            local isVisible = not panelButtonSort:isVisible()
            KUtil.showUiScale(panelButtonSort, isVisible)
            buttonScreen:setVisible(isVisible)
            KSound.playEffect("click")
            cclog("onSortClick~")
        end
    end
    buttonSort:addTouchEventListener(onSortClick)

    local buttonType = panleBottom:getChildByName("Button_common_type")
    local function onTypeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(panelButtonSort, false)
            local isVisible = not panelButtonType:isVisible()
            KUtil.showUiScale(panelButtonType, isVisible)
            buttonScreen:setVisible(isVisible)
            KSound.playEffect("click")
            cclog("onTypeClick~")
        end
    end
    buttonType:addTouchEventListener(onTypeClick)

    local buttonLockConfirmButton = panleBottom:getChildByName("Button_locking_confirm_button")
    local function onLockConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("onLockConfirmClick~")
            lockSelectedList(self)
        end
    end
    buttonLockConfirmButton:addTouchEventListener(onLockConfirmClick)

    local buttonLockButton        = panleBottom:getChildByName("Button_locking_button")
    local function onLockClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            cclog("onLockClick~")
            changeToLockMode(self)
        end
    end
    buttonLockButton:addTouchEventListener(onLockClick)
end

function KUITeamChangeCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onChooseCardFinish()
        local teamConvertNode = self._parent:getNode("Convert")
        local teamStrengthenNode = self._parent:getNode("Strengthen")
        if not teamConvertNode and not teamStrengthenNode then
            playPanelCloseAnimation(self, false)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onChooseCardFinish)

    local function onRefreshConvert()    
        cclog("-----------------refresh onRefreshConvert")
        self:refreshUI(false)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CONVERT_CARD, onRefreshConvert)

    local function onMarried(tOneCard)
        self:refreshUI(false)
        KUtil.playMarryAnimation(tOneCard)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_MARRIAGE_RING, onMarried)

    local function onFeeling()
        self:refreshUI(false)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FEELING, onFeeling)

    local function onCardChange(tOne)
        local mainNode       = self._mainLayout
        local imageCommon    = mainNode:getChildByName("Image_common_base")
        local projectContent = imageCommon:getChildByName("ProjectNode_content")
        local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
        local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
        local baseControl    = scrollControl:getChildByName(tostring(tOne.nID))
        if not baseControl then return end
        updateScrollItemByCard(self, baseControl, tOne)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ONE_CARD_CHANGE, onCardChange)

    local function onResourceUpdate()
        cclog("----------> onEvent KUITeamChangeCardNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)

    local function onStrengthenFinish()
        cclog("----------> onEvent KUITeamChangeCardNode onStrengthenFinish")
        self:refreshUI(false)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_STRENGTHEN_FINISH, onStrengthenFinish)

    local function onStrengthen()
        local teamStrengthenNode = self._parent:getNode("Strengthen")
        if not teamStrengthenNode then
            self:refreshUI(false)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_STRENGTHEN, onStrengthen)
    
    local function onLockCardList(resultList)
        cclog("----------> onEvent KUITeamChangeCardNode onLockCardList")
        local mainNode       = self._mainLayout
        local imageCommon    = mainNode:getChildByName("Image_common_base")
        local projectContent = imageCommon:getChildByName("ProjectNode_content")
        local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
        local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
        for _, card in pairs(resultList) do
            local uiControl = scrollControl:getChildByName(tostring(card.nID))
            if uiControl then
                setLockButton(uiControl, card.bLock)
            end
        end
        showLockTip(resultList)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_LOCK_CARD_LIST, onLockCardList)

    local function onLockCard(card)
        cclog("----------> onEvent KUITeamChangeCardNode onLockCard")
        local mainNode       = self._mainLayout
        local imageCommon    = mainNode:getChildByName("Image_common_base")
        local projectContent = imageCommon:getChildByName("ProjectNode_content")
        local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
        local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
        local uiControl = scrollControl:getChildByName(tostring(card.nID))
        if uiControl then
            setLockButton(uiControl, card.bLock)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CARD_LOCK, onLockCard)
end

function KUITeamChangeCardNode:onCleanup()
    self._baseControl:release() 
    self._leaveControl:release() 
    self._attributeControl:release() 
end

return KUITeamChangeCardNode
