--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamStrengthenChooseNode.lua
--  Creator     : HuangZhiLong
--  Date        : 2015/8/8   10:32
--  Contact     : huangzhilong1@kingsoft.com
--  Comment     :
--  *********************************************************************


local STARTNUMBER = 6
local TEAMNUMBER  = 4
local CARD_STATE  = 0.5
local CARD_COUNT  = 5
local DELAY_TIME  = 0.0001
local ADD_TIME    = 0.025

local KUITeamStrengthenChooseNode = class(
    "KUITeamStrengthenChooseNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamStrengthenChooseNode:ctor()
    self._mainLayout             = nil
    self._parent                 = nil
    self._uiPath                 = nil
    self._strengthenCardID       = nil  
    self._chosenList             = nil
    self._showList               = nil
    self._textChosenUnitBase     = nil
    self._orginScrollSizeHeight  = nil
end

function KUITeamStrengthenChooseNode.create(owner, nodeData)
    local currentNode = KUITeamStrengthenChooseNode.new()

    currentNode._parent             = owner
    currentNode._uiPath             = "res/ui/layout_tank_multi_choose.csb"
    currentNode._strengthenCardID   = nodeData.cardID
    currentNode._selectedCardIDList = nodeData.selectedCardIDList  
    currentNode._chosenList         = {}   
    currentNode:init()

    return currentNode
end

local function getTeam(cardID,teamID)
    local tTeamList     = KPlayer.tTeamData.tTeamList
    local tOneTeamList  = HArray.FindFirst(tTeamList, "nIndex", teamID)
    if not tOneTeamList then return end

    for key, card in ipairs(tOneTeamList.tCardIDList) do
        if card == cardID then return true end
    end
end

local function isExist(tab, cardID)
    for key, var in ipairs(tab) do
        if (var == cardID) then return true end
    end

    return false
end

local function updateChosenListText(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local imageBase        = imageCommon:getChildByName("Image_xztk_base")
    local scrollControl    = imageBase:getChildByName("Scrollview_chosen_list")
    local textChosenTank   = scrollControl:getChildByName("Text_chosen_tank")
    
    scrollControl:removeAllChildren()
    local buttonUnitBase = self._textChosenUnitBase
    
    local basePosX          = buttonUnitBase:getPositionX()
    local basePosY          = buttonUnitBase:getPositionY()
    local baseWidth         = buttonUnitBase:getContentSize().width
    local baseHeight        = buttonUnitBase:getContentSize().height

    local orginScrollSize   = scrollControl:getInnerContainerSize()
    
    local textListCount     = #self._chosenList  
    local baseHeightAndCardCount = baseHeight * textListCount
    
    if self._orginScrollSizeHeight > baseHeightAndCardCount then
        baseHeightAndCardCount = self._orginScrollSizeHeight 
    end
    scrollControl:setInnerContainerSize(cc.size(baseWidth, baseHeightAndCardCount))
    
    local heightInnerContainerOffset = baseHeightAndCardCount -  self._orginScrollSizeHeight
    basePosY = basePosY + heightInnerContainerOffset

    for key, cardID in ipairs(self._chosenList) do
        local newButtonUnitBase = buttonUnitBase:clone()
        scrollControl:addChild(newButtonUnitBase)
        newButtonUnitBase:setPosition(cc.p(basePosX, basePosY - (key - 1) * baseHeight))
        
        local tCardList = KPlayer.tCardData.tStoreHouse.tCardList
        local tOneCard  = HArray.FindFirstByID(tCardList, cardID)
        local cardName  = KConfig["cardInfo"][tOneCard.nTemplateID]["szName"]
        newButtonUnitBase:setString(cardName)
    end 
end

local function updateChosenList(self, cardID)
    for key, card in ipairs(self._chosenList) do
    	if (card == cardID) then
            table.remove(self._chosenList, key)
            return 
    	end
    end
    
    table.insert(self._chosenList, cardID)
end

local function updateScrollItemByCard(self, uiButtonControl, card)  
    --shadow  
    local imageDisableFlag = uiButtonControl:getChildByName("Image_xztk_unit_shadow")
    
    local imageActivityPath = "res/ui/ui_material/tank_multi_choose/xztk_unit_base.png"
    
    if card.bLock then 
        imageDisableFlag:setVisible(true) 
    elseif isExist(self._chosenList, card.nID) then
        imageActivityPath = "res/ui/ui_material/tank_multi_choose/xztk_unit_base_active.png"
    else
        imageDisableFlag:setVisible(false) 
    end
    uiButtonControl:loadTextureNormal(imageActivityPath)
    
    --lock
    local lockImagePath = "res/ui/ui_material/public/common_unlock.png"
    local imageLock = uiButtonControl:getChildByName("Button_lock")
    imageLock:setEnabled(false)
    
    local lockState = card.bLock
    
    if (lockState) then lockImagePath = "res/ui/ui_material/public/common_lock.png" end    
    imageLock:loadTextureNormal(lockImagePath)
    
    --start
    for starCount = 1, STARTNUMBER do 
        local starVisible       = false
        local imageStarControl  = uiButtonControl:getChildByName("Image_common_star_" .. starCount)
        local initStart         = KConfig["cardInfo"][card.nTemplateID]["nQuality"]
        if starCount <= initStart then starVisible = true end 
        imageStarControl:setVisible(starVisible)
    end

    for teamID = 1, TEAMNUMBER do 
        local teamIDVisible = false
        local imageTeamIDImageControl = uiButtonControl:getChildByName("Image_common_team_" .. teamID)
        if getTeam(card.nID,teamID) then teamIDVisible = true end        
        imageTeamIDImageControl:setVisible(teamIDVisible)
    end

    local labelLevel = uiButtonControl:getChildByName("Text_level_data")
    labelLevel:setString(card.nLevel) 

    local loadingBarExp = uiButtonControl:getChildByName("LoadingBar_common_exp")
    loadingBarExp:setPercent(card.nCurrentExp / KConfig["levelInfo"][card.nLevel]["nCardExp"] * 100)  

    local labelName = uiButtonControl:getChildByName("Text_tank_name") 
    labelName:setString(KConfig["cardInfo"][card.nTemplateID]["szName"])

    local imageHead = uiButtonControl:getChildByName("Image_common_chara") 

    KUtil.drawRoleHeadUi(imageHead, card)
end 

local function updateItem(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local imageBase     = imageCommon:getChildByName("Image_xztk_base")
    local scrollControl = imageBase:getChildByName("Scrollview_tank_list")

    local allCard = self._showList  
    for key, card in ipairs(allCard) do
        local buttonControl = scrollControl:getChildByName("Card" .. key)
        updateScrollItemByCard(self, buttonControl, card)
    end
end

local function addCardToScroll(self, allCard)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local imageBase         = imageCommon:getChildByName("Image_xztk_base")
    local scrollControl     = imageBase:getChildByName("Scrollview_tank_list")
    local buttonUnitControl = scrollControl:getChildByName("Button_unit")
    
    local slideControl      = imageCommon:getChildByName("Slider_scroll")

    local cardCount = table.getn(allCard)    
    if (cardCount == 0) then buttonUnitControl:setVisible(false) return end

    local showListUI = {}
    for index = 1, cardCount do
        local newUnitButtonControl = buttonUnitControl:clone()
        newUnitButtonControl:setName("Card" .. index)

        local card = allCard[index]
        updateScrollItemByCard(self, newUnitButtonControl, card)  
        local function onUnitClick(sender, type)
            if ccui.TouchEventType.ended == type then
                if (not card.bLock) then
                    updateChosenList(self, card.nID)
                    updateChosenListText(self) 
                    --update one
                    updateScrollItemByCard(self, newUnitButtonControl, card) 
                end  
            end
        end
        newUnitButtonControl:addTouchEventListener(onUnitClick)
        
        table.insert(showListUI, newUnitButtonControl)
    end
    KUtil.addScrollView(scrollControl, showListUI, true, slideControl)

    scrollControl:removeChild(buttonUnitControl)
end

local function getShowItemList(cardList, self)
    local showList = {}

    for key, card in ipairs(cardList) do
        if (KUtil.getEnterTeamId(card.nID) == 0 and (not isExist(self._selectedCardIDList, card.nID))) then
            local repairList    = KPlayer.tCardData.tRepairingList
            local repairFlag    = false

            for _, repairCard in ipairs(repairList) do
                if repairCard.nCardID == card.nID then
                    repairFlag = true
                    break  
                end
            end            
            local isSelectedCard = self._strengthenCardID == card.nID
            if (not repairFlag) and (not isSelectedCard) then table.insert(showList, card) end
        end
    end
    return showList
end

local function initUI(self)
    local mainNode          = self._mainLayout
    local iamgeCommon       = mainNode:getChildByName("Image_common_base")
    local iamgeBase         = iamgeCommon:getChildByName("Image_xztk_base")
    local scrollControl     = iamgeBase:getChildByName("Scrollview_chosen_list")
    local textChosenTank    = scrollControl:getChildByName("Text_chosen_tank")
    
    self._orginScrollSizeHeight = scrollControl:getInnerContainerSize().height
    
    textChosenTank:retain()
    self._textChosenUnitBase = textChosenTank
    
    
    local buttonSort = iamgeBase:getChildByName("Button_common_sort")
    buttonSort:setVisible(false)

    local cardCount = iamgeBase:getChildByName("Text_contant_value")
    local maxSize   = KPlayer.tCardData.tStoreHouse.nMaxSize
    
    -- remove team card
    self._showList  = getShowItemList(KPlayer.tCardData.tStoreHouse.tCardList, self)
    
    local cardNum   = table.getn(self._showList)
    cardCount:setString(cardNum .. "/" .. maxSize)

    addCardToScroll(self, self._showList)
end

function KUITeamStrengthenChooseNode:refreshUI()
    initUI(self)  
    updateChosenListText(self)
end

function KUITeamStrengthenChooseNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    
    --Home Button
    local buttonControl = mainNode:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then  
            KSound.playEffect("close")        
            self._parent:returnOffice()
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    --Close Button
    local imageControl = mainNode:getChildByName("Image_common_base")
    local buttonControl = imageControl:getChildByName("Button_close")
 
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("StrengthenChoose")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
    
    --clear Button
    local imageBase       = imageControl:getChildByName("Image_xztk_base") 
    local buttonClearList = imageBase:getChildByName("Button_cleanup")
    local function onClearClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            self._chosenList = {} 
                        
            updateChosenListText(self)            
            updateItem(self)
        end
    end
    buttonClearList:addTouchEventListener(onClearClick)
    
    --confirm Button
    local buttonConfirm = imageBase:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local nodeStrengthen        = self._parent:addNode("Strengthen")       
                      
            for k, cardID in pairs(self._chosenList) do
                nodeStrengthen:addSelectedCardID(cardID)
            end
            
            self._parent:removeNode("StrengthenChoose")
            nodeStrengthen:refreshUI()
            cclog("click onConfirmButton~")
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)
    
    --silderControl
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local slideControl      = imageCommon:getChildByName("Slider_scroll")
    local scrollControl     = imageBase:getChildByName("Scrollview_tank_list")
    
   local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)
end

function KUITeamStrengthenChooseNode:onNodeExit()
    self._textChosenUnitBase:release()
end

return KUITeamStrengthenChooseNode
