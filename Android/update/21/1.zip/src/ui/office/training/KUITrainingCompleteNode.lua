--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITrainingCompleteNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/07/12   9:35
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  ********************************************************************


local KEEP_PANEL_TIME = 500
local KUITrainingCompleteNode = class(
    "KUITrainingCompleteNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITrainingCompleteNode:ctor(use)
    self._parent          = nil
    self._mainLayout      = nil
    self._uiPath          = nil
    self._cardID          = nil
    self._warID           = nil
    self._opemTime        = C_GetTickCount()
end

function KUITrainingCompleteNode.create(owner, userData)
    local currentNode   = KUITrainingCompleteNode.new()

    currentNode._cardID = userData.cardID
    currentNode._warID  = userData.warID

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_campaig_train_complete.csb"
    currentNode:init()

    return currentNode
end

local function playCompleteAnimation(self, isOpen)
    local mainNode          = self._mainLayout
    local imageCompleteBase = mainNode:getChildByName("Image_complete_base")
    local projectNode       = imageCompleteBase:getChildByName("ProjectNode_1")

    local openEndFrame      = 20
    local closeStartFrame   = 50
    local animationName     = "ani_campaig_train_complete"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode          = self._mainLayout
    local imageCompleteBase = mainNode:getChildByName("Image_complete_base")
    local projectNode       = imageCompleteBase:getChildByName("ProjectNode_1")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playCompleteAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "TrainingComplete", callBacks, isReturnOffice)
end

function KUITrainingCompleteNode:refreshCompleteUI()
    local mainNode          = self._mainLayout
    local imageCompleteBase = mainNode:getChildByName("Image_complete_base")
    local projectNode       = imageCompleteBase:getChildByName("ProjectNode_1")

    local characterPanel   = projectNode:getChildByName("Panel_1")
    local imageCharater    = characterPanel:getChildByName("Image_chara")
    local cardHeadPath     = KUtil.getCardImagePathByConfigID(self._cardID, false, 0)
    imageCharater:loadTexture(cardHeadPath)

    local cardWarItem  = KUtil.getCardWarItem(self._cardID, self._warID)
    assert(cardWarItem)

    local warConfig = KConfig.trainingWar[self._warID]
    assert(warConfig, "warConfig not found! nWarID=:" .. self._warID)

    local skillConfig   = KConfig.trainingSkill[cardWarItem.nSkill]
    assert(skillConfig, "skillConfig not found! nSkill=:" .. cardWarItem.nSkill)

    local detailPanel    = projectNode:getChildByName("Panel_2")
    local warDetailPanel = detailPanel:getChildByName("Image_complete_base")
    local textWarName    = warDetailPanel:getChildByName("Text_name_value")
    textWarName:setString(warConfig.szName)

    local skillDetailPanel = detailPanel:getChildByName("Image_attribute_base")
    local textSkillName = skillDetailPanel:getChildByName("Text_name_value")
    textSkillName:setString(skillConfig.szName)

    local textSkillContent = skillDetailPanel:getChildByName("Text_content_value")
    textSkillContent:setString(skillConfig.szDescribe1)
end

function KUITrainingCompleteNode:onInitUI()
    stopAllAnimation(self)
end

function KUITrainingCompleteNode:refreshUI()
    self:refreshCompleteUI()
end

function KUITrainingCompleteNode:onEnterActionFinished()
    playCompleteAnimation(self, true)
end

function KUITrainingCompleteNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local imageCompleteBase = mainNode:getChildByName("Image_complete_base")

     local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            if self._opemTime + KEEP_PANEL_TIME > C_GetTickCount() then
                return
            end
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            playPanelCloseAnimation(self, false)
        end
    end
    imageCompleteBase:addTouchEventListener(onCloseClick)
    imageCompleteBase:setTouchEnabled(true)
end

function KUITrainingCompleteNode:registerAllCustomEvent()
end

return KUITrainingCompleteNode
