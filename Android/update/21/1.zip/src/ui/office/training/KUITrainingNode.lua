--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITrainingNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/07/12   9:35
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  ********************************************************************


local KUITrainingNode = class(
    "KUITrainingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITrainingNode:ctor()
    self._parent          = nil
    self._mainLayout      = nil
    self._uiPath          = nil
    self._baseControl     = nil
    self._cardBaseControl = nil
    self._selectWarID     = 0
    self._warCardMap      = {}
    self._showList        = {}
end

function KUITrainingNode.create(owner)
    local currentNode = KUITrainingNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_campaign_training.csb"
    currentNode:init()

    return currentNode
end

local function playCardAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_card")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_campaign_training_card"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_left")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_campaign_training_left"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRightAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_right")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_campaign_training_right"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local panalBase       = mainNode:getChildByName("Image_bg_base")
    local projectNode     = panalBase:getChildByName("ProjectNode_left")
    projectNode:stopAllActions()

    local projectNode     = panalBase:getChildByName("ProjectNode_right")
    projectNode:stopAllActions()

    local projectNode     = panalBase:getChildByName("ProjectNode_card")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playCardAnimation(self, false))
        table.insert(framesList, playLeftAnimation(self, false))
        table.insert(framesList, playRightAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Training", callBacks, isReturnOffice)
end

function KUITrainingNode:handleRequestCardBattle(cardID)
    assert(self._selectWarID)
    -- check training
    local isFight = self:iSCardFightFinish(cardID, self._selectWarID)
    if isFight then
        showNotice(KUtil.getStringByKey("training.havaFight"))
        return 
    end

    local trainingInfo = KConfig.trainingCard[cardID]
    local cardConfig   = KConfig.cardInfo[cardID]

    local cardWarItem  = KUtil.getCardWarItem(cardID, self._selectWarID)
    assert(cardWarItem)

    local warConfig = KConfig.trainingWar[cardWarItem.nWarID]
    assert(warConfig, "warConfig not found! nWarID=:" .. cardWarItem.nWarID)

    local skillConfig   = KConfig.trainingSkill[cardWarItem.nSkill]
    assert(skillConfig, "skillConfig not found! nSkill=:" .. cardWarItem.nSkill)

    local itemConfig = KConfig.itemInfo[warConfig.nItemID]
    assert(itemConfig, "itemConfig not found! nItemID=:" .. warConfig.nItemID)

    local cardData = HArray.FindFirst(KPlayer.tCardData.tStoreHouse.tCardList, "nTemplateID", cardID)
    if not cardData then
        local notGetTip  = KUtil.getStringByKey("training.notGetTip") 
        local tipFirst = string.format(notGetTip, cardConfig.szName)

        local attributeTip1 = KUtil.getStringByKey("training.attributeTip1")
        local tipSecond = string.format(attributeTip1, warConfig.szName, skillConfig.szDescribe1)

        local showString = string.format("%s\n\n%s", tipFirst, tipSecond)

        local function onConfirm()
        end
        showConfirmation(showString, onConfirm)
        return
    end

    -- item not enough
    local itemCount    = KUtil.getItemCount(warConfig.nItemID) 
    if cardWarItem.nCount > itemCount then
        local attributeTip  = KUtil.getStringByKey("training.attributeTip") 
        local tipFirst = string.format(attributeTip, cardConfig.szName, warConfig.szName, skillConfig.szDescribe1)

        local itemNotEnough = KUtil.getStringByKey("training.itemNotEnough")
        local tipSecond = string.format(itemNotEnough, itemConfig.szName)

        local showString = string.format("%s\n\n%s", tipFirst, tipSecond)

        local function onConfirm()
        end
        showConfirmation(showString, onConfirm)
        return
    end

    local attributeTip = KUtil.getStringByKey("training.attributeTip") 
    local tipFirst     = string.format(attributeTip, cardConfig.szName, warConfig.szName, skillConfig.szDescribe1)
    local confirmTip = KUtil.getStringByKey("training.confirm")
    local tipSecond = string.format(confirmTip, cardConfig.szName)

    local confirmItem = KUtil.getStringByKey("training.confirmItem")
    local tipThree    = string.format(confirmItem, itemConfig.szName, itemCount, itemCount - cardWarItem.nCount)
    local showString = string.format("%s\n\n%s\n\n%s", tipFirst, tipSecond, tipThree)

    local function onConfirm()
        require("src/network/KC2SProtocolManager"):requestCardTraining(cardID, self._selectWarID)
    end
    showConfirmation(showString, onConfirm)
end

function KUITrainingNode:cardWarSuccess(nCardID, nWarID)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_left")
    local panelLeft       = projectNode:getChildByName("Image_left_base")
    local scrollControl   = panelLeft:getChildByName("ScrollView_list")

    local control         = scrollControl:getChildByName(tostring(nWarID))
    if control then
        self:updateOneWar(control, {nID = nWarID})
    end
    -- update card
    local projectNode     = imageCommon:getChildByName("ProjectNode_card")
    local panelRight      = projectNode:getChildByName("Panel_right")
    local scrollControl   = panelRight:getChildByName("ScrollView_card")
    local control         = scrollControl:getChildByName(tostring(nCardID))

    local cardData = HArray.FindFirstByID(self._showList, nCardID)
    if cardData then
        cardData.isFight = true
    end
    if control and cardData then
        self:updateOneCard(control, cardData)
    end

    local userData = {cardID = nCardID, warID = nWarID}
    self._parent:addNode("TrainingComplete", userData)
end

function KUITrainingNode:getShowListCardData()
    local fightCardMap = {}
    for _, oneCard in ipairs(KPlayer.tTrainingList) do
        for _, nWarID in ipairs(oneCard.tWarList) do
            if self._selectWarID == nWarID then
                fightCardMap[oneCard.nTemplateID] = true
            end
        end
    end

    local getCardMap = {}
    for i,v in ipairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        getCardMap[v.nTemplateID] = true
    end

    local cardList = {}
    for _, nTemplateID in ipairs(self._warCardMap[self._selectWarID] or {}) do
        local isGet = getCardMap[nTemplateID] or false
        local cardInfo = {nID = nTemplateID, isGet = isGet, isFight = false}
        if fightCardMap[nTemplateID] then cardInfo.isFight = true end
        table.insert(cardList, cardInfo)
    end

    local function funSort(item1, item2)
        return item1.nID < item2.nID
    end
    table.sort(cardList, funSort)
    return cardList
end

function KUITrainingNode:iSCardFightFinish(nTemplateID, selectWarID)
    local dataList = KPlayer.tTrainingList
    for _, oneCard in ipairs(dataList) do
        for _, nWarID in ipairs(oneCard.tWarList) do
            if selectWarID == nWarID and oneCard.nTemplateID == nTemplateID then
                return true
            end
        end
    end
    return false
end

function KUITrainingNode:updateOneCard(control, dataInfo)
    local nTemplateID  = dataInfo.nID
    local cardConfig   = KUtil.getCardConfig(nTemplateID)
    local countryType  = cardConfig.nCountryType
    -- update card base
    local backPath  = KUtil.getCardBaseBackGround(nTemplateID)
    local panelCardBase = control:getChildByName("Panel_card_baes")
    local imageCardBase = panelCardBase:getChildByName("Image_card_base")
    imageCardBase:loadTexture(backPath)
    imageCardBase:setTouchEnabled(true)

    local function onCardClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCardClick~")
            KSound.playEffect("click")
            self:handleRequestCardBattle(nTemplateID)
        end
    end
    imageCardBase:addTouchEventListener(onCardClick)

    local cardHeadPath   = KUtil.getScaleImagePathByConfigID(nTemplateID, false, 0)
    local imageCharacter = control:getChildByName("Image_card_chara")
    imageCharacter:setVisible(false)
    KUtil.asynLoadTexture(imageCharacter, cardHeadPath)

    local imageNotClick = control:getChildByName("Image_not_click")
    imageNotClick:setVisible(not dataInfo.isGet)

    local textTankName = control:getChildByName("Text_tank_name")
    textTankName:setString(cardConfig.szName)

    local textTankNum = control:getChildByName("BitmapFontLabel_num")
    textTankNum:setString(cardConfig.nID)

    local medalFilePath = string.format("res/ui/ui_material/cardbase/card_medal_%d.png", cardConfig.nQuality)
    local imageMedal = control:getChildByName("Image_card_medal")
    imageMedal:loadTexture(medalFilePath)

    local imageCardType = control:getChildByName("Image_card_type")
    imageCardType:loadTexture(KUtil.getCardBackGround(cardConfig.nTankType))

    -- update star
    local panelStar = control:getChildByName("Panel_star")
    local qualityNum = 0
    while true do
        qualityNum = qualityNum + 1
        local imageStar = panelStar:getChildByName("Image_common_star_" .. qualityNum)
        if not imageStar then break end
        imageStar:setVisible(qualityNum <= cardConfig.nQuality)    
    end
    
    local imageFinish = control:getChildByName("Image_compete_base")
    imageFinish:setVisible(dataInfo.isFight)
end

function KUITrainingNode:refreshCardArea()
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_card")
    local panelRight      = projectNode:getChildByName("Panel_right")
    local scrollControl   = panelRight:getChildByName("ScrollView_card")

    self._showList        = self:getShowListCardData()
    local refreshCall = function(control, dataInfo)
        self:updateOneCard(control, dataInfo)
    end

    local parameters = {
        scrollView   = scrollControl,
        itemBase     = self._cardBaseControl,
        dataList     = self._showList,
        refreshCall  = refreshCall,
        row          = 1,
        column       = 6,
        isHorizontal = true,
    }

    local pageData = KUtil.addDynamicScrollView(parameters)

    KUtil.delayShowList(pageData.itemList, pageData.column, pageData.row)
end

function KUITrainingNode:refreshRightArea()
    local warConfig        = KConfig.trainingWar[self._selectWarID]
    assert(warConfig, "refreshRightArea warConfig not found! id=:" .. self._selectWarID)
    local imagePath = string.format("res/ui/ui_material/campaign_training/%s.png", warConfig.szImagePath)
    
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_right")
    local panelRight      = projectNode:getChildByName("Panel_1")
    local imagePhotoChara = panelRight:getChildByName("Image_photo_chara")
    imagePhotoChara:loadTexture(imagePath)

    local panelDescrition = panelRight:getChildByName("Image_descrition_base")
    local textTitle = panelDescrition:getChildByName("Text_title")
    textTitle:setString(warConfig.szName)

    local textDescription = panelDescrition:getChildByName("Text_description")
    textDescription:setString(warConfig.szDescribe2)
end

function KUITrainingNode:getWarSortList()
    local listInfo = {}
    for k, v in pairs(KConfig.trainingWar) do
        local itemInfo = {nID = k,}
        table.insert(listInfo, itemInfo)
    end
    local function funSort(item1, item2)
        return item1.nID < item2.nID
    end
    table.sort(listInfo, funSort)
    return listInfo
end

function KUITrainingNode:updateOneWar(control, dataInfo)
    control:setName(tostring(dataInfo.nID))
    local warConfig        = KConfig.trainingWar[dataInfo.nID]
    assert(warConfig, "warConfig not found! id=:" .. dataInfo.nID)

    local textTitle        = control:getChildByName("Text_title")
    textTitle:setString(warConfig.szName)

    local textDescription  = control:getChildByName("Text_description")
    textDescription:setString(warConfig.szDescribe1)

    local itemCount  = KUtil.getItemCount(warConfig.nItemID) 
    local textNumber = control:getChildByName("BitmapFontLabel_num")
    textNumber:setString(itemCount)

    local buttonUnit       = control:getChildByName("Button_unit")
    local warID            = dataInfo.nID
    local function onButtonClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onButtonClick~")
            KSound.playEffect("click")
            self:switchOneWarTab(warID)
        end
    end
    buttonUnit:addTouchEventListener(onButtonClick)

    local bSelect = (self._selectWarID == dataInfo.nID)
    self:switchWarSelectedStatus(dataInfo.nID, bSelect)
end

function KUITrainingNode:refreshLeftArea()
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_bg_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_left")
    local panelLeft       = projectNode:getChildByName("Image_left_base")
    local scrollControl   = panelLeft:getChildByName("ScrollView_list")

    self._showList        = self:getWarSortList()
    local refreshCall = function(control, dataInfo)
        self:updateOneWar(control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollControl,
        itemBase    = self._baseControl,
        dataList    = self._showList,
        refreshCall = refreshCall,
        row         = 7,
        column      = 1,
    }

    KUtil.addDynamicScrollView(parameters)
end

function KUITrainingNode:switchWarSelectedStatus(warID, bSelect)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_bg_base")
    local projectNode    = imageCommon:getChildByName("ProjectNode_left")
    local panelLeft      = projectNode:getChildByName("Image_left_base")
    local scrollControl  = panelLeft:getChildByName("ScrollView_list")
    local unitPanel      = scrollControl:getChildByName(tostring(warID))
    if not unitPanel then return end

    local buttonControl = unitPanel:getChildByName("Button_unit")
    if bSelect then
        buttonControl:setBrightStyle(ccui.BrightStyle.highlight)
        buttonControl:setEnabled(false)
    else
        buttonControl:setBrightStyle(ccui.BrightStyle.normal)
        buttonControl:setEnabled(true)
    end
end

function KUITrainingNode:switchOneWarTab(warID)
    if not warID and self._showList[1] then 
        warID = self._showList[1].nID
    end
    assert(warID, "not warID")

    if self._selectWarID == warID then
        return
    end
    -- cancel select
    if self._selectWarID ~= 0 then
        self:switchWarSelectedStatus(self._selectWarID, false)
    end
    self:switchWarSelectedStatus(warID, true)
    self._selectWarID = warID
    self:refreshCardArea()
    self:refreshRightArea()
end

function KUITrainingNode:initUi()
    local mainNode   = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_bg_base")
    local projectNode    = imageCommon:getChildByName("ProjectNode_left")
    local panelLeft      = projectNode:getChildByName("Image_left_base")
    local scrollControl  = panelLeft:getChildByName("ScrollView_list")
    self._baseControl    = scrollControl:getChildByName("Panel_unit")

    self._baseControl:retain()
    scrollControl:removeAllChildren()


    local projectNode     = imageCommon:getChildByName("ProjectNode_card")
    local panelRight      = projectNode:getChildByName("Panel_right")
    local scrollControl   = panelRight:getChildByName("ScrollView_card")
    self._cardBaseControl = scrollControl:getChildByName("Panel_unit")

    self._cardBaseControl:retain()
    scrollControl:removeAllChildren()

    self._warCardMap = {}
    for cardID, v in pairs(KConfig.trainingCard) do
        for _, itemInfo in ipairs(v.tList) do
            local nWarID = itemInfo.nWarID
            self._warCardMap[nWarID] = self._warCardMap[nWarID] or {}
            table.insert(self._warCardMap[nWarID], cardID)
        end
    end
end

function KUITrainingNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    self:initUi()
end

function KUITrainingNode:refreshUI()
    self:refreshLeftArea()
    self:switchOneWarTab()
end

function KUITrainingNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playCardAnimation(self, true)
    playLeftAnimation(self, true)
    playRightAnimation(self, true)
end

function KUITrainingNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "xlzy_base")
end

function KUITrainingNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onCardTraining(nCardID, nWarID, OneTraining)
        cclog("onEvent ------------> onCardTraining")
        if self._selectWarID ~= nWarID then return end
        -- update war
        self:cardWarSuccess(nCardID, nWarID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CARD_TRAINING_FINISH, onCardTraining)
end

function KUITrainingNode:onCleanup()
    self._baseControl:release()
    self._cardBaseControl:release()
end

return KUITrainingNode
