--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIWeddingNode.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/06/15   10:10
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIWeddingNode = class(
    "KUIWeddingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIWeddingNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._isCovered     = false
    self._cardInfo      = nil
    self._hideAttribute = false
    self._marryAction   = nil
    self._canContinue   = false
    self._startFrame    = 0
    self._endFrame      = 0
    self._loopStartFrame= 0
    self._loopEndFrame  = 0
end

function KUIWeddingNode.create(owner, userData)
    local currentNode = KUIWeddingNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_wedding.csb"
    currentNode._cardInfo       = userData.cardInfo
    currentNode._hideAttribute  = userData.hideAttribute
    currentNode:init()

    return currentNode
end

local function refreshAnimation(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_wedding")
    local panelAnimation    = projectNode:getChildByName("Panel_wedding_animation")

    KSound.playMusic("marry")
    local marryAction       = KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_wedding_animation.csb")
    self._marryAction       = marryAction

    local startFrame        = 0
    local endFrame          = marryAction:getDuration()
    local loopStartFrame    = 1069
    local loopEndFrame      = 1109
    KUtil.animationGotoFrameAndPlay(marryAction, startFrame, endFrame, false)

    self._startFrame        = startFrame
    self._endFrame          = endFrame
    self._loopStartFrame    = loopStartFrame
    self._loopEndFrame      = loopEndFrame

    self._canContinue       = false
    local framesPerSecond   = 60
    local duration = (loopStartFrame - startFrame) / framesPerSecond
    local func = function()
        marryAction:gotoFrameAndPlay(loopStartFrame, loopEndFrame, true)
        self._canContinue = true
    end
    delayExecute(mainNode, func, duration)

    local cardInfo = self._cardInfo
    -- update image
    local imageCardChara = panelAnimation:getChildByName("card_chara2")
    local imagePath = KUtil.getCardImagePathByConfigID(cardInfo.nTemplateID, false, cardInfo.nSkinTemplateID)
    imageCardChara:setTexture(imagePath)

    -- update dialog
    local panelDialog   = projectNode:getChildByName("Panel_dialog")
    local labelTankType = panelDialog:getChildByName("Text_tank_type")
    local labelTankName = panelDialog:getChildByName("Text_tank_name")
    local labelDialog   = panelDialog:getChildByName("Text_dialog")
    -- tank name
    local cardID       = cardInfo.nTemplateID
    local cardConfig   = KConfig:getLine("cardInfo", cardID)
    local cardName     = cardConfig["szName"]
    labelTankName:setString(cardName)
    -- tank type
    local tankType              = tonumber(cardConfig["nTankType"])
    local tankTypeName          = CARD_TYPE_NAME[tankType]
    labelTankType:setString(tankTypeName)
    -- dialog
    labelDialog:setString(cardConfig["szMarryDialogue"])
    
    local spriteAixin    = panelAnimation:getChildByName("Sprite_aixin")
    local effectUtil     = require("src/base/KEffectUtil") 
    local vertSource     = effectUtil.vshader_normal()
    local fragSource     = effectUtil.fshader_HighLight()
    local glProgam       = cc.GLProgram:createWithByteArrays(vertSource, fragSource)
    local glprogramstate = cc.GLProgramState:getOrCreateWithGLProgram(glProgam)
    spriteAixin:setGLProgram(glProgam)
    
    --marry sound
    local soundStartFrame = 1000
    local duration = (soundStartFrame - startFrame) / framesPerSecond
    local function playMarrySound()
        KSound.playTalk(KSound.TALK.MARRIED, cardID)
    end
    delayExecute(mainNode, playMarrySound, duration)
end

function KUIWeddingNode:refreshUI()
    refreshAnimation(self)
end

function KUIWeddingNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_wedding")
    local panelAnimation    = projectNode:getChildByName("Panel_wedding_animation")
    
    local marryAction       = self._marryAction
    local startFrame        = self._startFrame
    local endFrame          = self._endFrame
    local loopStartFrame    = self._loopStartFrame
    local loopEndFrame      = self._loopEndFrame
    local cardInfo          = self._cardInfo
    local hideAttribute     = self._hideAttribute

    local closeFun = function()
        self._parent:removeNode("TankWedding")

        KSound.playMusic("base")

        local textureCache = cc.Director:getInstance():getTextureCache()
        local starMax  = 21
        local starPath = "res/ui/ui_material/animation/ui/wedding_animation/aixin_%05d.png"
        for i = 0, starMax do
            local imagePath = string.format(starPath, i)
            imagePath = cc.FileUtils:getInstance():fullPathForFilename(imagePath)
            textureCache:removeTextureForKey(imagePath)
        end
        
        local churchMax  = 7
        local churchPath = "res/ui/ui_material/animation/ui/wedding_animation/church_%02d.png"
        for i = 1, churchMax do
            local imagePath = string.format(churchPath, i)
            imagePath = cc.FileUtils:getInstance():fullPathForFilename(imagePath)
            textureCache:removeTextureForKey(imagePath)
        end
    end

    local showAttribute = function()
        local panelAward          = projectNode:getChildByName("Panel_award")
        local panelAwardInfo      = panelAward:getChildByName("Panel_award_info")
        local labelHitValue       = panelAwardInfo:getChildByName("Text_hit_value")
        local labelAvoidValue     = panelAwardInfo:getChildByName("Text_avoid_value")
        local labelMoonlightValue = panelAwardInfo:getChildByName("Text_moonlight_value")
        local labelHPValue        = panelAwardInfo:getChildByName("Text_HP_value")

        local attribute = KUtil.getRingAttribute(cardInfo)
        local hitValue = (attribute[ATTRIBUTE.HITRATE] or 0) * 100
        labelHitValue:setString(tostring(hitValue))
        labelAvoidValue:setString(tostring(attribute[ATTRIBUTE.DODGE] or 0))
        labelMoonlightValue:setString(tostring(attribute[ATTRIBUTE.NIGHTBATTLE] or 0))
        labelHPValue:setString(tostring(attribute[ATTRIBUTE.MAX_HP] or 0))

        -- close panel
        local buttonConfirm = panelAward:getChildByName("Button_confirm")
        local function onCloseClick(sender, type)
            if type == ccui.TouchEventType.ended then
                closeFun()
            end
        end
        buttonConfirm:addTouchEventListener(onCloseClick)

        marryAction:gotoFrameAndPlay(loopEndFrame, endFrame, false)
    end

    local function onClick(sender, type)
        if type == ccui.TouchEventType.ended then
            if not self._canContinue then return end
            self._canContinue = false
            if hideAttribute then closeFun() return end
            showAttribute()
        end
    end
    panelAnimation:addTouchEventListener(onClick)

end

function KUIWeddingNode:registerAllCustomEvent()
end

return KUIWeddingNode