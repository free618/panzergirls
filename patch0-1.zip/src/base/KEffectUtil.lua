local KEffectUtil = {}

KEffectUtil.WidgetStatus = 
{
    normal = 1,
    bright = 2,
    gray   = 3,
    dark   = 4,
}

local function addAction(effect, ...)
    for _, action in ipairs({...}) do
        table.insert(effect.actionList, action)
    end

    return effect
end

local function runEffect(effect, ccui, effectEndCallback)
    local actionCount = #effect.actionList

    local function onActionFinished()
        actionCount = actionCount - 1
        if actionCount > 0 then return end

        effect.actionList = {}
        if effectEndCallback then effectEndCallback() end
    end

    for _, action in ipairs(effect.actionList) do
        ccui:runAction(
            cc.Sequence:create(
                action,
                cc.CallFunc:create(onActionFinished)
            )
        )
    end
end

local function createEffect(effectName, effectEndCallback)
    local effect = {
        effectName      = effectName,
        actionList      = {},
        endCallback     = effectEndCallback,
    }
    return effect
end

local function getVertexShaderByName(effectName)
    local shader = KEffectUtil["vshader_" .. effectName]()
    return shader
end

local function getFragmentShaderByName(effectName)
    local shader = KEffectUtil["fshader_" .. effectName]()
    return shader
end

local function createGLProgramByName(effectName)
    local vertexShader = getVertexShaderByName(effectName)
    local fragShader   = getFragmentShaderByName(effectName)
    local glProgram    = cc.GLProgram:createWithByteArrays(vertexShader, fragShader)
    glProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION)
    glProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORD)
    glProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR)
    glProgram:link()
    glProgram:updateUniforms()
    return glProgram
end

local function getGLProgramByName(effectName)
    local programCache = cc.GLProgramCache:getInstance()
    local glProgram = programCache:getGLProgram(effectName)
    if glProgram ~= nil then return glProgram end
    local glProgram = createGLProgramByName(effectName)
    if glProgram ~= nil then
        programCache:addGLProgram(glProgram, effectName)
    end
    return glProgram
end

local function uniformValueAction(programState, uniformName, uniformType, duration, fromValue, toValue, interval)
    if interval == nil or interval < 0.02 then interval = 0.02 end
    local repeatTime = duration / interval
    local inc = (toValue - fromValue) / repeatTime
    local curValue = fromValue

    local function onValueInc()
        KEffectUtil.setUniformValue(programState, uniformName, uniformType, curValue)
        curValue = math.max(curValue + inc, 0)
    end

    return KEffectUtil.repeatAction(onValueInc, repeatTime, interval)
end

--------------------------------------------------------------------
-- create a repeat action which repeat excuting repeatFunc repeatTimes after
-- every interval delay time
-- @param: repeateFunc #function
-- @param: repeatTimes #int
-- @param: interval #float
-- @return: #cc.Repeat
function KEffectUtil.repeatAction(repeatFunc, repeatTimes, interval)
    local ccAction = cc.Repeat:create(
        cc.Sequence:create(
            cc.CallFunc:create(repeatFunc),
            cc.DelayTime:create(interval)
        ), repeatTimes)

    return ccAction
end

------------------------------------------------------------------------
-- set gl program's uniform value
-- @param: programState  #cc.GLProgramState program state whose binding shader contain uniformName
-- @param: uniformName   #string uniform name in shader program
-- @param: szUniformType #string type of uniform, one of "Float", "Int", "Vec2", Vec3", "Vec4", "Mat4"
-- @param: value         #var value to pass to unifrom handler indicated by 'uniformName'
function KEffectUtil.setUniformValue(programState, uniformName, szUniformType, value)
    local program = programState:getGLProgram():getProgram()
    local handler = gl.getUniformLocation(program, uniformName)
    programState["setUniform" .. szUniformType](programState, handler, value)
end


---------------------------------------------------------------------------------
-- run out glow effect for ImageView ccui with param, invoke effectEndCallback
-- after effect finished, texture must be loaded in imageView before run effect and it's 
-- glProgram can not be changed during effect running process
-- @param: imageView #ccui.ImageView
-- @param: effectParam #table effect controlled paramter, nil if use default setting
-- @param: effectEndCallback #function
-- @parameter list:
--      NAME                            |TYPE     |EXPLATATION
--      effectParam.tintColr            |#cc.c4f  |tint color for image area 
--      effectParam.outGlowColor        |#cc.c4f  |out glow color
--      effectParam.outGlowRadius       |#float   |radius = (radiusInPixels)/(imageResolution)
--      effectParam.outGLowStep         |#int     |larger step would increase glow detail,main pramater of
--                                                |effect performence,but also the main reason of gpu cost
--      effectParam.outGlowIntensity    |#float   |1.0 for noraml intensity 
--      effectParam.frameInterval       |#float   |effect rate,glow radius changed per 'frameInterval' second
--      effectParam.tintInDuration      |#float   |duration for image's visibility from 0 to 1
--      effectParam.tintFadeDuration    |#float   |duration for tint color's visibility from 1 to 0  
--      effectParam.outGlowInDuration   |#float   |duration for out glow radius form 0 to 'outGLowRadius'
--      effectParam.outGlowFadeDuration |#float   |duration for out glow radius form 'outGlowRadius' to 0 
--      effectParam.tintInDelay         |#float   |delay for image's visibility from 0 to 1 
--      effectParam.tintFadeDelay       |#float   |delay for tint color's visibility from 1 to 0
--      effectParam.outGlowInDelay      |#float   |delay for out glow radius form 0 to 'outGLowRadius'
--      effectParam.outGlowFadeDelay    |#float   |delay for out glow radius form 'outGlowRadius' to 0

function KEffectUtil.runOutGlowEffect(imageView, effectParam, effectEndCallback)
    local outGlowEffect = createEffect("outGlow", effectEndCallback)

    local param = effectParam or {}
    local tintColor              = param.tintColor or cc.c4f(1, 1, 1, 1)
    local outGlowColor           = param.outGlowColor or cc.c4f(1, 1, 1, 1)
    local outGlowRadius          = param.outGlowRadius or 1
    local outGlowStep            = param.outGlowStep or 20
    local outGlowIntensity       = param.outGlowIntensity or 2.0
    local frameInterval          = param.frameInterval or 0.02

    local tintInDuration         = param.tintInDuration or 0
    local tintFadeDuration       = param.tintFadeDuration  or 0
    local outGlowInDuration      = param.outGlowInDuration  or 0
    local outGlowFadeDuration    = param.outGlowFadeDuration or 0

    local tintInDelay            = param.tintInDelay or 0
    local tintFadeDelay          = param.tintFadeDelay or 0
    local outGlowInDelay         = param.outGlowInDelay or 0
    local outGlowFadeDelay       = param.outGlowFadeDelay or 0

    local function onActionFinished()
        local oldProgram     = cc.GLProgramCache:getInstance():getGLProgram(imageView:getName() .. "_old")
        local rendererSprite = imageView:getVirtualRenderer():getSprite()
        assert(rendererSprite, "imageView get sprite is nil")
        rendererSprite:setGLProgram(oldProgram)
        imageView:setOpacity(255)
        imageView:setColor(cc.c3b(255, 255, 255))

        if effectEndCallback then
            effectEndCallback()
        end
    end

    function outGlowEffect:stopEffect()
        imageView:stopAllActions()
        onActionFinished()
    end

    local rendererSprite = imageView:getVirtualRenderer():getSprite()
    if rendererSprite == nil then
        print("play effect failed:render sprite is nil in imageView,")
        print("maybe imageView's content is not assigned.")
        return
    end
    
    local rendererSprite         = imageView:getVirtualRenderer():getSprite()
    local oldGLProgram           = rendererSprite:getGLProgram()
    cc.GLProgramCache:getInstance():addGLProgram(oldGLProgram, imageView:getName() .. "_old")

    local program                = getGLProgramByName(outGlowEffect.effectName)
    if program == nil then return end
    
    local programState           = cc.GLProgramState:create(program)
    rendererSprite:setGLProgramState(programState)
    KEffectUtil.setUniformValue(programState, "u_outGlowRadius", "Float", 0)
    KEffectUtil.setUniformValue(programState, "u_intensity", "Float", outGlowIntensity)
    local vec4Color = {x = outGlowColor.r, y = outGlowColor.g, z = outGlowColor.b, w = outGlowColor.a}
    KEffectUtil.setUniformValue(programState, "u_outGlowColor", "Vec4", vec4Color)

    addAction(outGlowEffect,
        cc.Sequence:create(
            cc.DelayTime:create(tintInDelay),
            cc.FadeIn:create(tintInDuration),
            cc.DelayTime:create(tintFadeDelay),
            cc.TintTo:create(tintFadeDuration, 0, 0, 0)
        ),
        cc.Sequence:create(
            cc.DelayTime:create(outGlowInDelay),
            uniformValueAction(programState, "u_outGlowRadius", "Float", outGlowInDuration, 0, outGlowRadius, frameInterval),
            cc.DelayTime:create(outGlowFadeDelay),
            cc.Spawn:create(
                uniformValueAction(programState, "u_outGlowRadius", "Float", outGlowFadeDuration, outGlowRadius, 0, frameInterval),
                uniformValueAction(programState, "u_intensity", "Float", outGlowFadeDuration, outGlowIntensity, 0, frameInterval)
            )
        )
    )
    imageView:setOpacity(0)
    runEffect(outGlowEffect, imageView, onActionFinished)
    return outGlowEffect
end

function KEffectUtil.setWidgetStatus(widgetUI, widgetStatus)
    assert(widgetUI, "widgetUI:" .. tostring(widgetUI))
    local vertSource = KEffectUtil.vshader_normal()
    local fragSource
    if widgetStatus == KEffectUtil.WidgetStatus.normal then
        fragSource = KEffectUtil.fshader_Normal()
    elseif widgetStatus == KEffectUtil.WidgetStatus.bright then
        fragSource = KEffectUtil.fshader_HighLight()
    elseif widgetStatus == KEffectUtil.WidgetStatus.gray then
        fragSource = KEffectUtil.fshader_Gray()
    elseif widgetStatus == KEffectUtil.WidgetStatus.dark then
        fragSource = KEffectUtil.fshader_Dark()
    end

    local glProgam = cc.GLProgram:createWithByteArrays(vertSource, fragSource)
    local glprogramstate = cc.GLProgramState:getOrCreateWithGLProgram(glProgam)
    
    local rendererSprite = widgetUI:getVirtualRenderer():getSprite()
    rendererSprite:setGLProgram(glProgam)
end

KEffectUtil.vshader_normal = function()
    return [[
        attribute vec4 a_position;
        attribute vec2 a_texCoord;
        attribute vec4 a_color;
        #ifdef GL_ES
        varying lowp vec4 v_fragmentColor;
        varying mediump vec2 v_texCoord;
        #else
        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;
        #endif
    
        void main()
        {
            gl_Position = CC_PMatrix * a_position;
            v_fragmentColor = a_color;
            v_texCoord = a_texCoord;
        }
    ]]
end

KEffectUtil.vshader_outGlow = KEffectUtil.vshader_normal
KEffectUtil.fshader_outGlow = function()
    return [[
        #ifdef GL_ES
        precision mediump float;
        #endif
        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;
        uniform float u_outGlowRadius;
        uniform float u_intensity;
        uniform vec4 u_outGlowColor;

        float calcAlphaFactorScatter(float p, float a, float r)
        {
            float f = 0.0;
            float d = r / 25.0;
            vec2 t = vec2(cos(a), sin(a));
            vec2 off = vec2(0.5, 0.5);
            off = off + (p - d) * t;
            f = texture2D(CC_Texture0, off).a;
            if(r < 0.01){ return f;}
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            if(f!=0.0){ return (10.0 + f)/25.0;}

            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            if(f!=0.0){ return (5.0 + f)/25.0;}

            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            off = off - d * t;
            f += texture2D(CC_Texture0, off).a;
            return f /25.0;
        }

        void main(void)
        {
            vec2 p = v_texCoord.xy;
            vec4 texColor = texture2D(CC_Texture0, v_texCoord);
            vec4 tintColor = vec4(0.0, 0.0, 0.0, 0.0);
            vec4 outGlowColor = vec4(0.0, 0.0, 0.0, 0.0);
            tintColor.rgb = v_fragmentColor.rgb * texColor.a;
            
            if(u_outGlowRadius != 0.0){
                float x = v_texCoord.x - 0.5;
                float y = v_texCoord.y - 0.5;
                float p = length(vec2(x, y));
                float a = atan(y, x);
                
                //float ga = sin(5000.0*a);
                //float ga = sin(p)*sin(50000.0*a)/10.0+0.1;
               
                //if(p*p<ga){
                    float afh = calcAlphaFactorScatter(p, a, u_outGlowRadius);

                    float g = abs(afh * (0.5 - p)) * u_intensity;
                    outGlowColor = vec4(u_outGlowColor.rgb, 1.0)*g;
                //}
            }
            float opc = v_fragmentColor.a;
            if( opc < 0.99){
               opc = 0.0;
            }
            gl_FragColor = tintColor + outGlowColor + texColor * opc;
        }
    ]]
end

KEffectUtil.fshader_Gray = function()
    return [[ 
        #ifdef GL_ES
        precision mediump float;
        #endif

        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;

        void main(void)
        {
            vec4 v_orColor = v_fragmentColor * texture2D(CC_Texture0, v_texCoord);
            float gray = dot(v_orColor.rgb, vec3(0.3, 0.3, 0.3));
            gl_FragColor = vec4(gray, gray, gray, v_orColor.a);
        }
    ]]
end

KEffectUtil.fshader_HighLight = function()
    return [[ 
        #ifdef GL_ES
        precision mediump float;
        #endif

        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;
        const float CC_LightValue = 1.4;

        void main(void)
        {
            vec4 v_orColor = v_fragmentColor * texture2D(CC_Texture0, v_texCoord);
            float alpha = v_orColor.a;
            gl_FragColor = vec4(v_orColor.r * CC_LightValue, v_orColor.g * CC_LightValue, v_orColor.b * CC_LightValue, alpha);
        }
    ]]
end

KEffectUtil.fshader_Dark = function()
    return [[ 
        #ifdef GL_ES
        precision mediump float;
        #endif

        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;
        const float CC_LightValue = 0.5;

        void main(void)
        {
            vec4 v_orColor = v_fragmentColor * texture2D(CC_Texture0, v_texCoord);
            float alpha = v_orColor.a;
            gl_FragColor = vec4(v_orColor.r * CC_LightValue, v_orColor.g * CC_LightValue, v_orColor.b * CC_LightValue, alpha);
        }
    ]]
end

KEffectUtil.fshader_Normal = function()
    return [[ 
        #ifdef GL_ES
        precision mediump float;
        #endif

        varying vec4 v_fragmentColor;
        varying vec2 v_texCoord;

        void main(void)
        {
            gl_FragColor = texture2D(CC_Texture0, v_texCoord);
        }
    ]]
end

return KEffectUtil
