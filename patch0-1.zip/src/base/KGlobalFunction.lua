--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KGlobalFunction.lua
--  Creator     : SunXun
--  Date        : 2015/03/31   11:13
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


UPDATE_V2_ENABLE = true
local MAX_SEND_LEN = 2 * 1024
--INFO_GATHER_SERVER = "http://172.18.69.110:8700/" -- For Lan
--INFO_GATHER_SERVER = "http://205.252.235.92:8700/" -- For Net
--INFO_GATHER_SERVER = "http://123.59.11.121:8700/" -- For XiaoMi
INFO_GATHER_SERVER = "http://127.0.0.1:8700/" 
-- INFO_GATHER_SERVER = "http://120.132.89.192:8700/" -- For Net
if cc.FileUtils:getInstance():isFileExist("src/network/KInfoGatherServerAddress.lua") or cc.FileUtils:getInstance():isFileExist("src/network/KInfoGatherServerAddress.luac") then
    INFO_GATHER_SERVER = unpack(require("src/network/KInfoGatherServerAddress"))
end

function cclog(...)
    print(string.format(...))
    local logInfo = string.format(...)
    local dateLog = "[" .. os.date() .. "] " .. logInfo
    
    C_Log(dateLog)
end

--[[function addDebugInfo(dateLog)
    local currentScene  = cc.Director:getInstance():getRunningScene()
    
    local debugInfoNode = currentScene:getChildByName("debugInfoNode")
    if not debugInfoNode then return end--print("----------> not debugInfoNode") end
    
    debugInfoNode:addDebugInfo(dateLog)
end]]

function showDebugInfo()
    print("----------> DebugInfo Init Start~")
    local currentScene  = cc.Director:getInstance():getRunningScene()
    
    local debugInfoNode = require("src/ui/common/KUIShowDebugInfoNode").create(currentScene)
    debugInfoNode:setName("debugInfoNode")
    currentScene:addChild(debugInfoNode, 990)
    
    print("----------> DebugInfo Init Ready~")
end

function delayExecute(target, func, delay)
    assert(target, debug.traceback())
    local wait = cc.DelayTime:create(delay)
    return target:runAction(cc.Sequence:create(wait, cc.CallFunc:create(func)))
end

function tryShowError(msg, stackInfo)
    cclog("--------------------> Call Global Function: tryShowError Start")

    print("Error:", msg, tostring(stackInfo))

    local currentScene = cc.Director:getInstance():getRunningScene()
    
    local errorShowNode = require("src/ui/common/KUIShowErrorNode").create(currentScene)
    errorShowNode:setErrorInfo(msg, stackInfo)
    currentScene:addChild(errorShowNode, 999) -- we must see this top
    
    cclog("--------------------> Call Global Function: tryShowError Finish")
end

function showNoticeByID(noticeID, ...)
    local stringConfig = KConfig:getLine("string", noticeID)
    if not stringConfig then return end
    showNotice(stringConfig.szText,  stringConfig.szType, ...)
end

function showNotice(noticeInfo, type, ...)
    cclog("--------------------> Call Global Function showNotice Start~")
    noticeInfo = string.format(noticeInfo, ...)
    cclog("--------------------> Call Global Function showNotice Start~" .. noticeInfo)
    local currentScene = cc.Director:getInstance():getRunningScene()
    assert(currentScene)
    
    local showNoticeNode = require("src/ui/common/KUIShowNoticeNode").create(currentScene)
    assert(showNoticeNode)
    showNoticeNode:setNoticeInfo(noticeInfo, type)
    currentScene:addChild(showNoticeNode, 999) -- we must see this top
    cclog("--------------------> Call Global Function showNotice Finish~")
end

function showConfirmation(confirmationInfo, confirmFunction, cancelFunction)
    cclog("--------------------> Call Global Function: showConfirmation Start~")

    local currentScene = cc.Director:getInstance():getRunningScene() 
       
    local showNode = currentScene:getChildByName("showConfirmationNode")
    if showNode then return end 
    
    local showConfirmationNode = require("src/ui/common/KUIShowConfirmationNode").create(currentScene)
    showConfirmationNode:setConfirmationInfo(confirmationInfo)
    showConfirmationNode:setOnTouchEvent(confirmFunction, cancelFunction)
    showConfirmationNode:setName("showConfirmationNode")
    currentScene:addChild(showConfirmationNode, 999) -- we must see this top
    cclog("--------------------> Call Global Function: showConfirmation Finish")
end

function showAnnounce(currentScene)
    cclog("--------------------> Call Global Function showAnnounce Start~")
    local showAnnounceNode = require("src/ui/common/KUIShowAnnounceNode").create(currentScene)
    currentScene:addChild(showAnnounceNode, 1000)
    cclog("--------------------> Call Global Function showAnnounceNode Finish~")
end

local resume = coroutine.resume
coroutine.resume = function (thread, ...)            
    local hCurThread = coroutine.running()

    --print("-----> thread resume", tostring(thread), tostring(hCurThread), debug.getinfo(2, "Sln").name)

    local ret = {resume(thread, ...)}
    if not ret[1] then
        tryShowError(ret[2], debug.traceback())
    end

    return unpack(ret, 1, table.maxn(ret))
end

function createThreadResumeFunc(...)
    local thread = coroutine.running()
    assert(thread, "main thread cannot call createThreadResumeFunc")

    local arg = {...}
    local argn = select("#", ...)
    local called = false
    return function (...)
        if argn > 0 then
            print(unpack(arg, 1, table.maxn(arg)))
        end

        assert(not called, tostring(thread) .. " resume twice!")

        called = true
        return coroutine.resume(thread, ...)
    end
end

function random(range)
    if not range then
        return math.random()
    end

    return math.random(range[1] * 1000, range[2] * 1000) / 1000
end

local lastSendString = ""
function sendErrorMsg(szMsg, szStackInfo)
    if not (KPlayer and KPlayer.bDataReady) then return end
    if not szMsg or not szStackInfo then return end
    if lastSendString == szMsg then return end

    local replaceLeng = string.len("stack traceback:")
    szStackInfo = string.sub(szStackInfo, replaceLeng)
    szStackInfo = "\nstack" .. szStackInfo
    szStackInfo = string.sub(szStackInfo, 0, 500)
    lastSendString = szMsg
    require("src/network/KC2SProtocolManager"):recordClientErrorMsg(szMsg, szStackInfo)
end

function sendInfoGatherServer(szText)
    local nLen = string.len(szText)
    if nLen > MAX_SEND_LEN then
        szText = string.sub(szText, -MAX_SEND_LEN)
    end
    local errorReport = cc.XMLHttpRequest:new()
    errorReport.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    errorReport:open("POST", INFO_GATHER_SERVER)
    local function onReadyStateChange()
        if errorReport.readyState == 4 and (errorReport.status >= 200 and errorReport.status < 207) then
            print(errorReport.response)
        else
            print("errorReport.readyState is:", errorReport.readyState, "errorReport.status is: ",errorReport.status)
        end
    end
    errorReport:registerScriptHandler(onReadyStateChange)
    errorReport:send(szText)
end

function sendIGS(szFun, szText)
    local nLen = string.len(szText)
    if nLen > MAX_SEND_LEN then
        szText = string.sub(szText, -MAX_SEND_LEN)
    end
    local errorReport = cc.XMLHttpRequest:new()
    errorReport.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    errorReport:open("POST", INFO_GATHER_SERVER .. szFun)
    local function onReadyStateChange()
        if errorReport.readyState == 4 and (errorReport.status >= 200 and errorReport.status < 207) then
            print(errorReport.response)
        else
            print("errorReport.readyState is:", errorReport.readyState, "errorReport.status is: ",errorReport.status)
        end
    end
    errorReport:registerScriptHandler(onReadyStateChange)
    errorReport:send(szText)
end

function httpGet(szURL, funGet)
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    xhr:open("GET", szURL)
    xhr.timeout = 2
    local function onGet()
        local isGet
        if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
            isGet = true 
        else
            isGet = false
            print("httpGet xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
        end
        if funGet then
            local szText = string.format(" %s", xhr.response)
            funGet(isGet, xhr.response)
        end
    end

    xhr:registerScriptHandler(onGet)
    xhr:send()
end

function reload(moduleName)
    if package.loaded[moduleName] then
        package.loaded[moduleName] = nil
    end
    require(moduleName)
end

local function valueToString(v)
    if "number" == type(v) then  
        return string.format("%d", v)
    elseif "string" == type(v) then  
        return '"' .. v .. '"' 
    elseif "table" == type(v) then  
        return tableToString(v) 
	else
		return tostring(v)
    end  
end

function tableToString(t)  
    local szRet = "{"  
    function doToString(_i, _v)  
        if "number" == type(_i) then  
            szRet = szRet .. "[" .. _i .. "] = "  
            szRet = szRet .. valueToString(_v) .. "," 
        elseif "string" == type(_i) then  
            szRet = szRet .. '["' .. _i .. '"] = '  
            szRet = szRet .. valueToString(_v) .. "," 
        end  
    end  
    table.foreach(t, doToString)  
    szRet = szRet .. "}"  
    return szRet  
end 

function toAcronymString(value)
    local szType   = type(value)
    local szString = tostring(value)
    if szType == "table" then
        szString = string.gsub(szString, "table", "t", 1)
    elseif szType == "function" then
        szString = string.gsub(szString, "function", "f", 1)
    elseif szType == "userdata" then
        szString = string.gsub(szString, "userdata", "u", 1)
        if tolua.isnull(value) then
            szString = szString .. " " .. nil
        end
    end
    return szString
end

local function valueToSting(nIndex, szKey, szValue)      
    if type(szValue) == "table" then
        szValue = tableToString(szValue)
    end
    
    return nIndex .. ":" .. szKey .. "=" .. toAcronymString(szValue)
end

function getStackInfo(nLevel)
    if not nLevel then
        nLevel = 2
    end
    local nFirstLevel = nLevel
    
    local szTrace = "\nStack trackback:"
    while true do
        local tStackInfo = debug.getinfo(nLevel, "nSluf")
        if not tStackInfo then
            break
        end

        local szArgs = ""
        local nIndex = 1
        while true do
            local szKey, szValue = debug.getlocal(nLevel, nIndex)
            if not szKey then break end
            if szArgs ~= "" then
                szArgs = szArgs .. "\n"
            end
            szArgs = szArgs .. valueToSting(nIndex, szKey, szValue)
            nIndex = nIndex + 1
        end

        local szUpvalue = "" 

        if tStackInfo.func then
            local nIndex = 1
            while true do
                local szKey, szValue = debug.getupvalue(tStackInfo.func, nIndex)
                if not szKey then break end
                print("[U]", nIndex, szKey, szValue)
                if szUpvalue ~= "" then
                    szUpvalue = szUpvalue .. "\n"
                end
                szUpvalue = szUpvalue .. valueToSting(nIndex, szKey, szValue)
                nIndex = nIndex + 1
            end
        end
        
        if nFirstLevel ~= nLevel then 
            if tStackInfo.what == "C" then
                szTrace = szTrace .. "\n[C] " .. tStackInfo.name or ""
            elseif tStackInfo.what == "main" then
                szTrace = szTrace .. string.format(
                    "\n%s:%d", 
                    tStackInfo.short_src, 
                    tStackInfo.currentline
                )
            else
                local szFileName = string.match(tStackInfo.short_src, "/(%w+)%.lua")
                szTrace = szTrace .. string.format(
                    "\n[%s]:%d:%s", 
                    szFileName, 
                    tStackInfo.currentline, 
                    tStackInfo.name or ""
                )
            end
        end
        if szArgs ~= "" then
            szTrace = szTrace .. "\n[A]" .. szArgs
        end
        if szUpvalue ~= "" then
            szTrace = szTrace .. "\n[U]" .. szUpvalue
        end
        
        nLevel = nLevel + 1
    end
    return string.sub(szTrace, 0, 2000) 
end
