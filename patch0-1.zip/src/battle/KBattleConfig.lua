

-- 攻击方 耐久和士气 影响系数
-- local nSrcStateAttackCoe      = self.tBattleData:getStateAttackCoe(tSrcCard)          -- 火力影响系数
-- local nSrcStatePenetrateCoe   = self.tBattleData:getStatePenetrateCoe(tSrcCard)       -- 穿透影响系数
-- local nSrcStateSpeedCoe       = self.tBattleData:getStateSpeedCoe(tSrcCard)           -- 速度影响系数
-- local nSrcStateArmorCoe       = self.tBattleData:getStateArmorCoe(tSrcCard)           -- 护甲影响系数
-- local nSrcStateScoutCoe       = self.tBattleData:getStateScoutCoe(tSrcCard)           -- 侦查影响系数
-- local nSrcStateDodgeCoe       = self.tBattleData:getStateDodgeCoe(tSrcCard)           -- 回避影响系数
-- local nSrcStateHideCoe        = self.tBattleData:getStateHideCoe(tSrcCard)            -- 隐蔽影响系数
-- local nSrcStateHitRateCoe     = self.tBattleData:getStateHitRateCoe(tSrcCard)         -- 命中影响系数

-- -- 目标 耐久和士气 影响系数
-- local nDstStateAttackCoe      = self.tBattleData:getStateAttackCoe(tDstCard)          -- 火力影响系数
-- local nDstStatePenetrateCoe   = self.tBattleData:getStatePenetrateCoe(tDstCard)       -- 穿透影响系数
-- local nDstStateSpeedCoe       = self.tBattleData:getStateSpeedCoe(tDstCard)           -- 速度影响系数
-- local nDstStateArmorCoe       = self.tBattleData:getStateArmorCoe(tDstCard)           -- 护甲影响系数
-- local nDstStateScoutCoe       = self.tBattleData:getStateScoutCoe(tDstCard)           -- 侦查影响系数
-- local nDstStateDodgeCoe       = self.tBattleData:getStateDodgeCoe(tDstCard)           -- 回避影响系数
-- local nDstStateHideCoe        = self.tBattleData:getStateHideCoe(tDstCard)            -- 隐蔽影响系数
-- local nDstStateHitRateCoe     = self.tBattleData:getStateHitRateCoe(tDstCard)         -- 命中影响系数
 
CARD_BROKEN_STATE = 
{
	NORMAL 	= 0,
	LITTLE 	= 1,
	MIDDLE	= 2,
	BIG		= 3,
	DEAD 	= 4,
}

ATTACK_RESULT = 
{
    MISS        = 0,
    RICOCHET    = 1,
    CRIT        = 2,
    NORMAL      = 3,
    GRAZE       = 4,
}
 
local BROKEN_STATE_COE = 
{
	------------------ 正常状态 ------------------
	[CARD_BROKEN_STATE.NORMAL] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.0	-- 命中率
	},
	------------------ 小破状态 ------------------
	[CARD_BROKEN_STATE.LITTLE] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.0	-- 命中率
	},	
	------------------ 中破状态 ------------------
	[CARD_BROKEN_STATE.MIDDLE] =
	{
		nAttack 	= 0.7,	-- 火力
		nPenetrate 	= 0.7,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 0.7,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.7	-- 命中率
	},	
	------------------ 大破状态 ------------------
	[CARD_BROKEN_STATE.BIG] =
	{
		nAttack 	= 0.4,	-- 火力
		nPenetrate 	= 0.4,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 0.5,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.7	-- 命中率
	},
	------------------ 死亡状态 ------------------
	[CARD_BROKEN_STATE.DEAD] =
	{
		nAttack 	= 0.0,	-- 火力
		nPenetrate 	= 0.0,	-- 穿透力
		nSpeed 		= 0.0,	-- 速度
		nArmor		= 0.0,	-- 装甲
		nScout 		= 0.0,	-- 侦察
		nDodge 		= 0.0,	-- 回避
		nHide 		= 0.0,	-- 隐蔽
		nHitRate 	= 0.0	-- 命中率
	}
}

local function getCardBrokenState(tCard)
	local nCurrentHP 	= tCard.nCurrentHP
	local nMaxHP 		= tCard.nMaxHP
	
	if nCurrentHP <= 0 then
		return CARD_BROKEN_STATE.DEAD
	end
	
	if nCurrentHP / nMaxHP <= BROKEN_LIMIT.BIG then
		return CARD_BROKEN_STATE.BIG
	end
	
	if nCurrentHP / nMaxHP <= BROKEN_LIMIT.MIDDLE then
		return CARD_BROKEN_STATE.MIDDLE
	end
	
	if nCurrentHP / nMaxHP <= BROKEN_LIMIT.LITTLE then
		return CARD_BROKEN_STATE.LITTLE
	end
	
	return CARD_BROKEN_STATE.NORMAL
end

local MORALE_STATE = 
{
	VERY_TIRED 	= 15,
	TIRED 		= 30,
	NORMAL 		= 49,
	EXCITING 	= 100,
}

local MORALE_STATE_COE = {
	------------------ 严重疲劳状态 ------------------
	[MORALE_STATE.VERY_TIRED] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 0.3,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.7	-- 命中率
	},
	------------------ 疲劳状态 ------------------
	[MORALE_STATE.TIRED] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 0.7,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.8	-- 命中率
	},	
	------------------ 普通状态 ------------------
	[MORALE_STATE.NORMAL] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.0	-- 命中率
	},	
	------------------ 志气高涨状态 ------------------
	[MORALE_STATE.EXCITING] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmor		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.1,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.1	-- 命中率
	}
}

local function getCardMoralState(tCard)
	local nMoral 	= tCard.nMoral
	
	if nMoral <= MORALE_STATE.VERY_TIRED then
		return MORALE_STATE.VERY_TIRED
	end
	
	if nMoral <= MORALE_STATE.TIRED then
		return MORALE_STATE.TIRED
	end
	
	if nMoral <= MORALE_STATE.NORMAL then
		return MORALE_STATE.NORMAL
	end
	return MORALE_STATE.EXCITING
end

local KBattleConfig = {}

function KBattleConfig.getBrokenState(tCard)
	return getCardBrokenState(tCard)
end

function KBattleConfig.getCardBrokenStateCoe(tCard)
	local nCardBrokenState = getCardBrokenState(tCard)
	if nCardBrokenState == CARD_BROKEN_STATE.MIDDLE and tCard.bImmueMiddleBrokenPunishment then
		return BROKEN_STATE_COE[NROMAL]
	end

	return BROKEN_STATE_COE[nCardBrokenState]
end

function KBattleConfig.getCardMoralStateCoe(tCard)
	local nMoraleState = getCardMoralState(tCard)
	return MORALE_STATE_COE[nMoraleState]
end

local LAND_FORM = 
{
	PLAIN 				= 1,
	JUNGLE 				= 2,
	SELF_HIGHLAND 		= 3,
	ENEMY_HIGHLAND 		= 4,
}

------------------- 地形影响 -------------------
local LAND_COE = {
	------------------ 平原战 ------------------
	[LAND_FORM.PLAIN] =
	{
		nAttack 	= 1.0,	-- 火力
		nPenetrate 	= 1.0,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmour		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.0	-- 命中率
	},
	------------------ 丛林战 ------------------
	[LAND_FORM.JUNGLE] =
	{
		nAttack 	= 0.9,	-- 火力
		nPenetrate 	= 0.9,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmour		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.9	-- 命中率
	},
	------------------ 我方占领高地 ------------------
	[LAND_FORM.SELF_HIGHLAND] =
	{
		nAttack 	= 1.2,	-- 火力
		nPenetrate 	= 1.2,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmour		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 1.2	-- 命中率
	},
	------------------ 敌方占领高地 ------------------
	[LAND_FORM.ENEMY_HIGHLAND] =
	{
		nAttack 	= 0.8,	-- 火力
		nPenetrate 	= 0.8,	-- 穿透力
		nSpeed 		= 1.0,	-- 速度
		nArmour		= 1.0,	-- 装甲
		nScout 		= 1.0,	-- 侦察
		nDodge 		= 1.0,	-- 回避
		nHide 		= 1.0,	-- 隐蔽
		nHitRate 	= 0.8	-- 命中率
	}
}

local LEFT_TEAM_GRAZE_RATE = 0.15 -- 我方擦伤率
local RIGHT_TEAM_GRAZE_RATE = 0.50 -- 敌方擦伤率
-- 坦克擦伤数值范围
local TANK_GRAZE_RANGE = {
    [CARD_TYPE.LIGHT_TANK]          = {0.05, 0.10}, 
    [CARD_TYPE.MEDIUM_TANK]         = {0.01, 0.05}, 
    [CARD_TYPE.HEAVY_TANK]          = nil,
    [CARD_TYPE.TANK_DESTORYER]      = {0.01, 0.03}, 
    [CARD_TYPE.SELF_PROPELLED_GUN]  = nil,
    [CARD_TYPE.TRANSPORT]           = nil, 
    [CARD_TYPE.BOSS]                = nil, 
    [CARD_TYPE.TURRET]              = nil,
}

function KBattleConfig.getGrazeRate(tCard)
    local nGrazeRate   = 0 
    if tCard.bLeftSide then
        return  LEFT_TEAM_GRAZE_RATE
    else
        return  RIGHT_TEAM_GRAZE_RATE
    end
end

function KBattleConfig.getGrazeRange(tCard)
    return TANK_GRAZE_RANGE[tCard.nNamedType]
end

function KBattleConfig.getRandomLand()
	local tAllLandType = {}
	for _, v in pairs(LAND_FORM) do
		table.insert(tAllLandType, v)
	end

	assert(tAllLandType)

	local nRandomValue = math.random(1, #tAllLandType)
	local nRandomLandType = tAllLandType[nRandomValue]

	print("----> randomLand", nRandomValue, nRandomLandType, #tAllLandType)

	return nRandomLandType
end

function KBattleConfig.getLandCoe(nLandType, bLeftSide)
	if nLandType == LAND_FORM.PLAIN then
		return LAND_COE[LAND_FORM.PLAIN]
	end

	if nLandType == LAND_FORM.JUNGLE then
		return LAND_COE[LAND_FORM.JUNGLE]	
	end

	if nLandType == LAND_FORM.SELF_HIGHLAND then
		if bLeftSide then
			return LAND_COE[LAND_FORM.SELF_HIGHLAND]			
		end

		return LAND_COE[LAND_FORM.ENEMY_HIGHLAND]
	end

	if nLandType == LAND_FORM.ENEMY_HIGHLAND then
		if bLeftSide then
			return LAND_COE[LAND_FORM.ENEMY_HIGHLAND]			
		end

		return LAND_COE[LAND_FORM.SELF_HIGHLAND]
	end
end

return KBattleConfig
 
