

local m_tSkillList = {
    Guide      = "src/battle/skill/KSkillGuide",
    AirBomb    = "src/battle/skill/KSkillAirBombLogic",
    AirSupport = "src/battle/skill/KSkillAirSupportLogic",
    Barrage    = "src/battle/skill/KSkillBarrageLogic",
    Bunker     = "src/battle/skill/KSkillBunkerLogic",
    Combo      = "src/battle/skill/KSkillComboLogic",
    Landmine   = "src/battle/skill/KSkillLandmineLogic",
    Supply     = "src/battle/skill/KSkillSupplyLogic",
    Repair     = "src/battle/skill/KSkillRepairLogic",
    UpExp      = "src/battle/skill/KSkillUpExpLogic",
}

local KBattleManager = class("KBattleManager")

function KBattleManager:ctor(tUserData, tUI, fnEndCallback) 

	local tSrcTeam = tUserData.leftTeam
	local tDstTeam = tUserData.rightTeam
	local fnGuideUseSkill = tUserData.guideUseSkill
	local nGuildBattleID = tUserData.mapID
	local roundList = tUserData.roundList
	local beginAtNightFight = tUserData.beginAtNightFight
	local fightMusic = tUserData.fightMusic
	local nightFightMusic = tUserData.nightFightMusic

	self.bInRunning = false
	self.tData 	= require("battle/KBattleData").new(tSrcTeam, tDstTeam, beginAtNightFight, tUserData.battleType)
	self.tUI 	= tUI
	self.tAbilityManager = require("battle/ability/KAbilityManager").new(self)
	self.hMainBattleThread = coroutine.create(self.run)
    self.hSkillThread  = coroutine.create(self.runSkillThread)
    self.tUseSkillList = {}
    self.bSkillEnable  = false
	self.tStepWaitingList = {}
	self.nPreUsedID = 0
	self.bWaitingSubStepFinished = false
	self.fnEndCallback = fnEndCallback
    self.fnGuideUseSkill = fnGuideUseSkill
    self.nGuildBattleID = nGuildBattleID
    self.roundList = roundList
    self.beginAtNightFight = beginAtNightFight
    self.fightMusic = fightMusic
    self.nightFightMusic = nightFightMusic
    self.tCurrentStep    = nil
    math.randomseed(os.time())
end

function KBattleManager:createStep(szStepName)
	return require("battle/" ..  szStepName).new(self)
end

local function isCardDedad(tCard)
	return tCard.nCurrentHP == 0
end

local function isTeamDead(tTeam)	
	for _, v in ipairs(tTeam) do
		if not isCardDedad(v) then
			return false
		end
	end

	return true
end

local function getTeamDeadPercent(tTeam)
	local nTotalCount = #tTeam
	local nDeadCount = 0
	for _, v in ipairs(tTeam) do
		if isCardDedad(v) then
			nDeadCount = nDeadCount + 1
		end
	end

	return nDeadCount / nTotalCount
end

function KBattleManager:getBattleResultType()
	local tBattleData = self.tData

	if isTeamDead(tBattleData.tSrcTeam) then
		return FIGHT_SCORE.E
	end

	if tBattleData.nSrcLostHP == 0 then
		if isTeamDead(tBattleData.tDstTeam) then
			return FIGHT_SCORE.SS
		end
	else
		if isTeamDead(tBattleData.tDstTeam) then
			return FIGHT_SCORE.S
		end
	end

	if getTeamDeadPercent(tBattleData.tDstTeam) > 0.5 then
		return FIGHT_SCORE.A
	end

	if tBattleData.nSrcLostHP == 0 or tBattleData.nDstLostHP / tBattleData.nSrcLostHP > 2.5 then
		return FIGHT_SCORE.B
	end

	if isCardDedad(tBattleData.tDstTeam[1]) then
		return FIGHT_SCORE.B
	end

	if tBattleData.nDstLostHP == 0 or tBattleData.nSrcLostHP / tBattleData.nDstLostHP > 2.5 then
		return FIGHT_SCORE.D
	end

	return FIGHT_SCORE.C
end

function KBattleManager:getMVPCardID()
	local tBattleData = self.tData
	local nMVPCardID = 0
	local nMVPCardDamage = -1
	for _, v in ipairs(tBattleData.tSrcTeam) do
		if v.nCurrentHP > 0 and v.nTotalDamage > nMVPCardDamage then
			nMVPCardID = v.nID or v.nTemplateID
			nMVPCardDamage = v.nTotalDamage
		end
	end
	return nMVPCardID
end

function KBattleManager:getBattleBossDamagePercent()
	local tBattleData = self.tData
	if not tBattleData.tDstTeam.isBossFoothold then
		return 0
	end

	local card = tBattleData.tDstTeam[1]
	if card.nMaxHP == 0 then return 0 end

	return 100 - math.floor(card.nCurrentHP / card.nMaxHP * 100)
end

function KBattleManager:getSrcDamagePercent()
	local tBattleData = self.tData
	return math.floor((tBattleData.nDstLostHP / tBattleData.nDstTotalHP) * 100)
end

function KBattleManager:getDstDamagePercent()
	local tBattleData = self.tData
	return math.floor((tBattleData.nSrcLostHP / tBattleData.nSrcTotalHP) * 100)
end


function KBattleManager:getSkillUsedData()
    local tBattleData = self.tData
    return tBattleData:getSkillUsedData()
end

function KBattleManager:buildBattleResult()
	local tBattleResult = 
	{
        nType             = self:getBattleResultType(),
        nMVPCardID        = self:getMVPCardID(),
        nProgress         = self:getBattleBossDamagePercent(),
        nSrcDamagePercent = self:getSrcDamagePercent(),
        nDstDamagePercent = self:getDstDamagePercent(),
        nDstTeam          = self.tData.tDstTeam,
        tKillMonsters     = self.tData.tKillMonsters,
        tDeadMonsters     = self.tData.tDeadMonsters,
        tSkillUsedData    = self:getSkillUsedData()
    }

	return tBattleResult
end

function KBattleManager:endFighting(win)
	print("Fighting End", self.fnEndCallback)

	if self.fnEndCallback then
		local tBattleResult = self:buildBattleResult()
		self.fnEndCallback(tBattleResult)
		return
	end

    local officeScene = require("src/ui/office/KUIOfficeScene").create("endFighting")
    KUtil.replaceSceneAndRemoveAllTexture(officeScene)
end

function KBattleManager:playAnimation(szFunc, ...)
    print("playAnimation", szFunc, ... )

    local KBattleUIHelper   = require("battle/KBattleUIHelper")
    local tBattleData       = self:getData()
    local tBattleUI         = self:getUI()
    KBattleUIHelper.playAnimation(szFunc, tBattleData, tBattleUI, ...)
end

function KBattleManager:run()
	assert(not self.bInRunning)

	self.bInRunning = true

	local tSteps = {"KStepScout", "KStepArtilleryStrike", "KStepAmbush", "KStepArtilleryAction", "KStepArtilleryAction2", "KStepDogFight", "KStepNightFight"}
	if self.beginAtNightFight then
		tSteps = {"KStepScout", "KStepNightFight"}
	end
	self.tData:beginFight()
	self.tAbilityManager:checkPoint(ABILITY_CHECK_POINT.BATTLE_BEGIN)

    local nStepIndex = 1
    for i, v in ipairs(tSteps) do
        local tStep = self:createStep(v)
        self.tCurrentStep = tStep
        self.tData.nCurrentStep = tStep.nStepType
        if tStep:canEnter() then
            print("[Main] Enter Step [" .. tStep:getName() .. "]", i)
            tStep:run(nStepIndex)
            self.tData:deleteExtraProperty(nStepIndex)
            nStepIndex = nStepIndex + 1
            self.tData.nCurrentStepIndex = nStepIndex
            print("[Main] Leave Step [" .. tStep:getName() .. "]")
        else
            print("[Main] Skip Step [" .. tStep:getName() .. "], canEnter false")
        end
    end
    
    self:playAnimation("playGateClosedAnimation")
    self.bInRunning = false

    self.tAbilityManager:checkPoint(ABILITY_CHECK_POINT.BATTLE_END)
	self:endFighting(true)
end

function KBattleManager:resume()
	local bResult, szError = coroutine.resume(self.hMainBattleThread, self)
	if not bResult then
		print("KBattleManager.resume Error", szError, "KBattleManager")
	end
end

function KBattleManager:takeID()
	self.nPreUsedID = self.nPreUsedID + 1
	return self.nPreUsedID
end

function KBattleManager:addWaiting()
	local nID = self:takeID()
	assert(self.tStepWaitingList[nID] == nil)
	self.tStepWaitingList[nID] = nID
    return nID
end

function KBattleManager:delWaiting(nID)
	assert(self.tStepWaitingList[nID] ~= nil, nID)
	self.tStepWaitingList[nID] = nil

	if next(self.tStepWaitingList) ~= nil then
		return
	end

	if not self.bWaitingSubStepFinished then
		return
	end

	self.bWaitingSubStepFinished = false
	
	coroutine.resume(self.hMainBattleThread)
end

function KBattleManager:waitSubStepFinish()
	assert(not self.bWaitingSubStepFinished)
	
	if next(self.tStepWaitingList) == nil then
	   return
	end

	self.bWaitingSubStepFinished = true
	coroutine.yield()
end

function KBattleManager:enableSkill(bEnable)
    self.bSkillEnable = bEnable
    -- self.tSkillManager:enable(bEnable)
end

function KBattleManager:canUseSkill(bLeft, nSkillID, tBattleData)
    local tSrcTeam    = tBattleData.tSrcTeam
    local tDstTeam    = tBattleData.tDstTeam
    if not bLeft then
        tSrcTeam = tBattleData.tDstTeam
        tDstTeam = tBattleData.tSrcTeam
    end
    local tSkillConfig = KConfig:getLine("skill", nSkillID)
    return require(m_tSkillList[tSkillConfig.szType]).canUse(tBattleData, tSrcTeam, tDstTeam)
end

function KBattleManager:useSkill(tUseSkillInfo, tBattleData, tBattleUI)
    -- tBattleData:setSkillAble(false)   
    -- local tTaskIDList   = {}
    local tSrcTeam = tBattleData.tSrcTeam
    local tDstTeam = tBattleData.tDstTeam
    if not tUseSkillInfo.isLeft then
        tSrcTeam = tBattleData.tDstTeam
        tDstTeam = tBattleData.tSrcTeam
    end
    local tSkillConfig = KConfig:getLine("skill", tUseSkillInfo.ID)
    local tSkill       = require(m_tSkillList[tSkillConfig.szType])
    if not tSkill.canUse(tBattleData, tSrcTeam, tDstTeam) then return end
    local tSkillClass  = tSkill.new(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, tUseSkillInfo.equipTemplateID, unpack(tUseSkillInfo.args, 1, table.maxn(tUseSkillInfo.args)))

    if tUseSkillInfo.isLeft then
        local nSkillPosition  = tUseSkillInfo.args[1]
        local tSkillList      = tBattleData:getLeftTeamSkillList()
        local tOneSkill       = tSkillList[nSkillPosition]
        tOneSkill.tSkillClass = tSkillClass
    end

    tSkillClass:use()
end

function KBattleManager:runSkillThread()
    local tBattleData   = self:getData()
    local tBattleUI     = self:getUI()
    local nWaitingID
    while true do
        if not nWaitingID then
            nWaitingID   = self:addWaiting()
        end
        if #self.tUseSkillList > 0 then
            local tUseSkillInfo = self.tUseSkillList[1]
            self:useSkill(tUseSkillInfo, tBattleData, tBattleUI)
            table.remove(self.tUseSkillList, 1)
        else
            local nDeleteID = nWaitingID
            nWaitingID = nil
            self:delWaiting(nDeleteID)
            coroutine.yield()
        end
    end
end

function KBattleManager:castSkill(bLeft, nSkillID, nEquipTemplateID, ...)
    table.insert(self.tUseSkillList, {ID = nSkillID, isLeft = bLeft, equipTemplateID = nEquipTemplateID, args = { ... }})
    assert(self.hSkillThread)

    if #self.tUseSkillList > 1 then
    	return
    end

    local status = coroutine.status(self.hSkillThread)
    assert(status == "suspended")
    coroutine.resume(self.hSkillThread, self) 
end

function KBattleManager:getData()
	return self.tData
end

function KBattleManager:getUI()
	return self.tUI
end

return KBattleManager

