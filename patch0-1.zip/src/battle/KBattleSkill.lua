local KBattleSkill = class("KBattleSkill")

function KBattleSkill:ctor()
	self.bEnable       = false
	self.tAsyncExector = require("battle/KAsyncExector").new()
end

function KBattleSkill:asyncExec(fnFunc, ...)
    return self.tAsyncExector:exec(fnFunc, ...)
end

function KBattleSkill:waitAsync(tTaskIDList)
    self.tAsyncExector:waiting(tTaskIDList)
end

function KBattleSkill:actionSkill0(tBattleData, tBattleUI)
    self:playAnimation("playSkill1Aniamtion", tBattleData, tBattleUI)

    print("-----> Call actionSkill0~")
    local nDamage       = 34 
    local nType         = ATTACK_RESULT.NORMAL
    local tTaskIDList   = {}
    for _, v in ipairs(tBattleData.tDstTeam) do
        local nID = self:asyncExec(self.playSkillAnimation, self, tBattleData, tBattleUI, v, nType, nDamage)
        table.insert(tTaskIDList, nID)
    end

    self:waitAsync(tTaskIDList)
end

function KBattleSkill:playSkillAnimation(tBattleData, tBattleUI, tDstTeam, nType, nDamage)
    print("-----> Call playSkillAnimation~")
    local nOldHP, nCurrentHP = tBattleData:costHP(tDstTeam, nDamage)
    
    self:playAnimation("playCostHPAnimation", tBattleData, tBattleUI, tDstTeam, nOldHP, nCurrentHP)
    self:playAnimation("playHurtAnimation", tBattleData, tBattleUI, tDstTeam, nType, nDamage)
end

function KBattleSkill:actionSkill1(tBattleData, tBattleUI)
    print("-----> Call actionSkill1~")
    self:playAnimation("playSkill1Aniamtion", tBattleData, tBattleUI)
    
    local tLogic = require("src/battle/KStepArtillerySkillLogic").new(tBattleData)
    
    local tTaskIDList   = {}
    for _, v in ipairs(tBattleData.tDstTeam) do
        local nType, nDamage       = tLogic:calcDamage(v)
        local nID = self:asyncExec(self.playSkillAnimation, self, tBattleData, tBattleUI, v, nType, nDamage)
        table.insert(tTaskIDList, nID)
    end
    
    self:waitAsync(tTaskIDList)
end

function KBattleSkill:playAnimation(szFunc, tBattleData, tBattleUI, ...)
	print("playAnimation", szFunc, ... )

	local KBattleUIHelper   = require("battle/KBattleUIHelper")
	KBattleUIHelper.playAnimation(szFunc, tBattleData, tBattleUI,  ...)
end

function KBattleSkill:enable(bEnable)
	self.bEnable = bEnable
end

function KBattleSkill:castSkill(nSkillID, tBattleManager, tBattleData, tBattleUI, ...)
	if not self.bEnable then
		return
	end
	
    tBattleData:setSkillAble(false)
    local nWaitingID = tBattleManager:addWaiting()
	KBattleSkill["actionSkill" .. nSkillID](self, tBattleData, tBattleUI, ...)
	

	tBattleManager:delWaiting(nWaitingID)
end

return KBattleSkill
