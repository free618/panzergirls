--
-- 技能相关动画
--


local KBattleSkillAnimation = {}

local FRAME_PER_SECOND = 60

-- 轰炸
function KBattleSkillAnimation.playSkillGuideAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig)
    print("-----> Call playSkillGuideAnimation~", isLeft, nEquipTemplateID)
    fnCallback()
end

--战略轰炸动画
function KBattleSkillAnimation.playSkillAirBombAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    local szSound1          = tSkillConfig.szSound1
    local nEquipTemplateID  = equipConfig.nID
    local equipImage        = KUtil.getEquipImagePathByID(nEquipTemplateID)
    print("-----> Call playSkillAirBombAnimation~", isLeft, equipConfig)
    if isLeft then
        local skillIntro = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bomber.csb")
        local skillPlay  = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bombing_v2.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bomber.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bombing_v2.csb")

        local mainNode                  = tBattleUI._mainLayout
        local panelBattleBomber         = skillIntro:getChildByName("Panel_battle_bomber")
        local textName                  = panelBattleBomber:getChildByName("Text_name")
        textName:setString(equipConfig.szName)

        local panelBomber = panelBattleBomber:getChildByName("Panel_bomber")
        for i = 1, 3 do
            local imageBomberName = "Image_bomber_" .. i
            local imageBomber = panelBomber:getChildByName(imageBomberName)
            imageBomber:loadTexture(equipImage)
        end

        local panelBattleBomberPlay = skillPlay:getChildByName("Panel_battle_bombing")
        local panelBomberPlay       = panelBattleBomberPlay:getChildByName("Panel_bomber")
        for i = 1, 6 do
            local imageBomberName = "Image_bomber_" .. i
            local imageBomber     = panelBomberPlay:getChildByName(imageBomberName)
            imageBomber:loadTexture(equipImage)
        end
        
        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame  = 0
        local skillIntroEndFrame    = 130
        local skillIntroActionTime  = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame   = 0
        local skillPlayEndFrame     = 130
        local skillPlayActionTime   = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillPlayEnd2Frame    = 150
        local skillPlayActionTime2  = (skillPlayEnd2Frame - skillPlayEndFrame) / FRAME_PER_SECOND
        local skillCostHPTime       = skillIntroActionTime + skillPlayActionTime
        local skillAllTime          = skillCostHPTime + skillPlayActionTime2
        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function() 
                    KSound.playEffect(szSound1)
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function()
                    skillPlay:setVisible(true)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)
        
        delayExecute(
            tBattleUI,
            function()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    else
        local skillIntro = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bomber_enemy.csb")
        local skillPlay  = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bombing_v2_enemy.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bomber_enemy.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bombing_v2_enemy.csb")

        local mainNode           = tBattleUI._mainLayout
        local panelBattleBomber  = skillIntro:getChildByName("Panel_battle_bomber")
        local textName           = panelBattleBomber:getChildByName("Text_name")
        textName:setString(equipConfig.szName)

        local panelBomber = panelBattleBomber:getChildByName("Panel_bomber")
        for i = 1, 3 do
            local imageBomberName = "Image_bomber_" .. i
            local imageBomber = panelBomber:getChildByName(imageBomberName)
            imageBomber:loadTexture(equipImage)
        end

        local panelBattleBomberPlay = skillPlay:getChildByName("Panel_battle_bombing")
        local panelBomberPlay       = panelBattleBomberPlay:getChildByName("Panel_bomber")
        for i = 1, 6 do
            local imageBomberName = "Image_bomber_" .. i
            local imageBomber     = panelBomberPlay:getChildByName(imageBomberName)
            imageBomber:loadTexture(equipImage)
        end

        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame  = 0
        local skillIntroEndFrame    = 130
        local skillIntroActionTime  = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame   = 0
        local skillPlayEndFrame     = 130
        local skillPlayActionTime   = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillPlayEnd2Frame    = 150
        local skillPlayActionTime2  = (skillPlayEnd2Frame - skillPlayEndFrame) / FRAME_PER_SECOND
        local skillCostHPTime       = skillIntroActionTime + skillPlayActionTime
        local skillAllTime          = skillCostHPTime + skillPlayActionTime2
        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function() 
                    KSound.playEffect(szSound1)
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function()
                    skillPlay:setVisible(true)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)
        
        delayExecute(
            tBattleUI,
            function()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    end
end

--空中支援
function KBattleSkillAnimation.playSkillAirSupportAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillAirSupportAnimation~", isLeft, equipConfig, tSkillConfig)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    local nEquipTemplateID  = equipConfig.nID
    local equipImage        = KUtil.getEquipImagePathByID(nEquipTemplateID)
    if isLeft then
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_airsupport_V1.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_airsupport_V1.csb")
        local panel            = skillPlay:getChildByName("Panel_1")
        local panelText        = panel:getChildByName("Panel_text")
        local textEquipment    = panelText:getChildByName("Text_equipment_name")
        textEquipment:setString(equipConfig.szName)
        local panelFighter     = panel:getChildByName("Panel_fighter")
        for i = 1, 3 do
            local imageFighterName = "Image_fighter_" .. i
            local imageFighter     = panelFighter:getChildByName(imageFighterName)
            imageFighter:loadTexture(equipImage)
        end
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        KSound.playEffect(szSound1)
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_airsupport_V1_enemy.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_airsupport_V1_enemy.csb")
        local panel            = skillPlay:getChildByName("Panel_1")
        local panelText        = panel:getChildByName("Panel_text")
        local textEquipment    = panelText:getChildByName("Text_equipment_name")
        textEquipment:setString(equipConfig.szName)
        local panelFighter     = panel:getChildByName("Panel_fighter")
        for i = 1, 3 do
            local imageFighterName = "Image_fighter_" .. i
            local imageFighter     = panelFighter:getChildByName(imageFighterName)
            imageFighter:loadTexture(equipImage)
        end
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    end
end

--徐进弹幕
function KBattleSkillAnimation.playSkillBarrageAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillBunkerAnimation~", isLeft)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    if isLeft then
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_barrage_V1.csb")
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_barrage_V2.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_barrage_V1.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_barrage_V2.csb")
        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillPlayAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillIntroActionTime = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillPlayActionTime = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillAllTime        = skillIntroActionTime + skillPlayActionTime

        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function()
                    KSound.playEffect(szSound1)
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function ()
                    skillPlay:setVisible(true)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)

        delayExecute(
            tBattleUI, 
            function ()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    else
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_barrage_V1_enemy.csb")
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_barrage_V2_enemy.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_barrage_V1_enemy.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_barrage_V2_enemy.csb")
        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillPlayAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillIntroActionTime = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillPlayActionTime = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillAllTime        = skillIntroActionTime + skillPlayActionTime

        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function()
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function ()
                    skillPlay:setVisible(true)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)

        delayExecute(
            tBattleUI, 
            function ()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    end
end

--掩体制造
function KBattleSkillAnimation.playSkillBunkerAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillBunkerAnimation~", isLeft)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    if isLeft then
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_bunkerbuild.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_bunkerbuild.csb")
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_bunkerbuild.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_bunkerbuild.csb")
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    end
end

--突袭
function KBattleSkillAnimation.playSkillComboAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillComboAnimation~", isLeft, nEquipTemplateID, nTimes)
    local mainNode = tBattleUI._mainLayout
    if isLeft then
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_strike.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_strike.csb")
        local panelSkillStrike = skillIntro:getChildByName("Panel_skill_strike")
        local imageBg          = panelSkillStrike:getChildByName("Image_bg")
        local backgroundType   = tBattleData.tSrcTeam.background
        local imagePath        = KUtil.getBattleBackgroundImagePath(backgroundType, false)
        imageBg:loadTexture(imagePath)
        mainNode:addChild(skillIntro, 100)
        skillIntro:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillAllTime        = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
        delayExecute(
            tBattleUI, 
            function () 
                skillIntro:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        local skillIntro        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_strike_enemy.csb")
        local skillIntroAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_strike_enemy.csb")
        local panelSkillStrike  = skillIntro:getChildByName("Panel_skill_strike")
        local imageBg           = panelSkillStrike:getChildByName("Image_bg")
        local backgroundType    = tBattleData.tSrcTeam.background
        local imagePath         = KUtil.getBattleBackgroundImagePath(backgroundType, false)
        imageBg:loadTexture(imagePath)
        mainNode:addChild(skillIntro, 100)
        skillIntro:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillAllTime        = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
        delayExecute(
            tBattleUI, 
            function () 
                skillIntro:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    end
end

--布雷
function KBattleSkillAnimation.playSkillLandmineAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillLandmineAnimation~", isLeft)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    local szSound2 = tSkillConfig.szSound2
    if isLeft then
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_landmine.csb")
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_skills_landmine.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_landmine.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skills_landmine.csb")
        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillPlayAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillIntroActionTime = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillPlayActionTime = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillAllTime        = skillIntroActionTime + skillPlayActionTime

        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function()
                    KSound.playEffect(szSound1)
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function ()
                    skillPlay:setVisible(true)
                    KSound.playEffect(szSound2)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)

        delayExecute(
            tBattleUI, 
            function ()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    else
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_landmine_enemy.csb")
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_skills_landmine_enemy.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_landmine_enemy.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skills_landmine_enemy.csb")
        skillIntro:stopAllActions()
        skillPlay:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        skillIntroAction:gotoFrameAndPause(0)
        skillPlay:runAction(skillPlayAction)
        skillPlayAction:gotoFrameAndPause(0)
        skillPlay:setVisible(false)
        mainNode:addChild(skillIntro, 100)
        mainNode:addChild(skillPlay, 100)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillIntroActionTime = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillPlayActionTime = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        local skillAllTime        = skillIntroActionTime + skillPlayActionTime

        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function()
                    skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
                end
            ),
            cc.DelayTime:create(skillIntroActionTime),
            cc.CallFunc:create(
                function ()
                    skillPlay:setVisible(true)
                    skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)

        delayExecute(
            tBattleUI, 
            function ()
                skillIntro:removeFromParent()
                skillPlay:removeFromParent()
                fnCallback()
            end,
            skillAllTime
        )
    end
end

--补给
function KBattleSkillAnimation.playSkillSupplyAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillSupplyAnimation~", isLeft, nEquipTemplateID, nTimes)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    if isLeft then
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_supply.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_supply.csb")
        mainNode:addChild(skillIntro, 100)
        skillIntro:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillAllTime        = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillIntro:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        assert(false)
    end
end

--修理
function KBattleSkillAnimation.playSkillRepairAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig)
    print("-----> Call playSkillRepairAnimation~", isLeft, nEquipTemplateID, nTimes)
    local mainNode = tBattleUI._mainLayout
    local szSound1 = tSkillConfig.szSound1
    if isLeft then
        local skillIntro       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_repair.csb")
        local skillIntroAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_repair.csb")
        mainNode:addChild(skillIntro, 100)
        skillIntro:stopAllActions()
        skillIntro:runAction(skillIntroAction)
        local skillIntroStartFrame = 0
        local skillIntroEndFrame   = skillIntroAction:getDuration()
        local skillIntroTime       = (skillIntroEndFrame - skillIntroStartFrame) / FRAME_PER_SECOND
        skillIntroAction:gotoFrameAndPlay(skillIntroStartFrame, skillIntroEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillIntro:removeFromParent()
                fnCallback()
            end, 
            skillIntroTime
        )
    else
        assert(false)
    end
end

--战果提升
function KBattleSkillAnimation.playSkillUpExpAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, nExpMuti)
    print("-----> Call playSkillUpExpAnimation~", isLeft, nExpMuti)
    local szSound1 = tSkillConfig.szSound1
    if isLeft then
        local mainNode         = tBattleUI._mainLayout
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_experience.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_experience.csb")

        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame     = 0
        local skillPlayEndFrame       = skillPlayAction:getDuration()
        local skillAllTime            = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)
        KSound.playEffect(szSound1)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        assert(false)
    end
end

function KBattleSkillAnimation.playAnimation(szFunc, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, ...)
    print("-----> Call play Skill Animation~", isLeft, equipConfig, tSkillConfig, ...)
    local nType     = tSkillConfig.szType
    local szFunc    = "playSkill" .. nType .. "Animation"
	local hThread   = coroutine.running()
	local bCallback = false

	local fnEndCallback = function()
        assert(not bCallback, tostring(hThread) .. " resume twice!")

		bCallback = true

		local szStatus = coroutine.status(hThread)
		if szStatus == "running" then
			return
		end
		
        print("---------- > KBattleSkillAnimation.playAnimation fnEndCallback, szFunc:", szFunc, tostring(hThread))
		return coroutine.resume(hThread)
	end
    
	KBattleSkillAnimation[szFunc](fnEndCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, ...)
	if bCallback then
		return
	end

	coroutine.yield()
end

return KBattleSkillAnimation