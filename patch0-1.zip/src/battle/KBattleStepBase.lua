local KBattleStepBase = class("KBattleStepBase")

function KBattleStepBase:ctor(tBattleManager)
	self.tBattleManager              = tBattleManager
	self.tAsyncExector 	             = require("battle/KAsyncExector").new()
	self.tBulletList 	             = {}
    self.tCalc = require("src/battle/formula/KBattleCalcBase").new(self:getBattleData())
    self.tFullScreenAnimationList    = {}
end

function KBattleStepBase:takeID()
	return self.tBattleManager:takeID()
end

function KBattleStepBase:canEnter()
	self:print(" base canEnter")
	return true
end

function KBattleStepBase:getName()
	return self.__cname
end

function KBattleStepBase:enableSkill(bEnable)
	self:print("enableSkill", bEnable)
	local tBattleManager = self.tBattleManager
	tBattleManager:enableSkill(bEnable)
end

function KBattleStepBase:getBattleData()
	return self.tBattleManager:getData()
end

function KBattleStepBase:getBattleUI()
	return self.tBattleManager:getUI()
end

function KBattleStepBase:addBullet(tSrcCard, tDstCard, nType, nDamage)
	local nID = self:takeID()

	self.tBulletList[nID] = 
	{
		nID 			= nID,
		tSrcCard 		= tSrcCard,
		tDstCard		= tDstCard,
		nType           = nType,
		nDamage 		= nDamage,
	}

	self:print("addBullet", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, nDamage, "nID:", nID)

	return nID
end

function KBattleStepBase:delBullet(nID)
	local tBulletInfo = self.tBulletList[nID]
	assert(tBulletInfo)

	self.tBulletList[nID] = nil

	self:print("delBullet", nID)

	return tBulletInfo
end

function KBattleStepBase:applyBulletDamage(nID)
	local tBulletInfo = self:delBullet(nID)
	assert(tBulletInfo)
    
    if tBulletInfo.tDstCard.bLeftSide then 
        if tBulletInfo.nDamage >= tBulletInfo.tDstCard.nMaxHP then
            tBulletInfo.nDamage = math.floor(tBulletInfo.nDamage / 2)
        end
    end

    local tTaskIDList = {}
    local tParam = {tBulletInfo = tBulletInfo, tTaskIDList = tTaskIDList}
    self:checkPoint(ABILITY_CHECK_POINT.CARD_BEFORE_COST_HP, tBulletInfo.tDstCard, tBulletInfo.tSrcCard, tParam)
    
    local nOldHP, nCurrentHP = self:getBattleData():costHP(tBulletInfo.tDstCard, tBulletInfo.nDamage, tBulletInfo.tSrcCard)
    
    self:print("HPCost", tBulletInfo.tDstCard.bLeftSide, nOldHP, nCurrentHP)
    
    if tBulletInfo.nDamage > 0 then
        local nID = self:asyncExec(self.playAnimation, self, "playCostHPAnimation", tBulletInfo.tDstCard, nOldHP, nCurrentHP)
        table.insert(tTaskIDList, nID)
    end
    local nID = self:asyncExec(self.playAnimation, self, "playHurtAnimation", tBulletInfo.tDstCard, tBulletInfo.nType, tBulletInfo.nDamage)    
    table.insert(tTaskIDList, nID)

    if tBulletInfo.tDstCard.bLeftSide then 
        -- 统计闪避，和被攻击次数
        if tBulletInfo.nType == ATTACK_RESULT.MISS then
            tBulletInfo.tDstCard.nMiss = tBulletInfo.tDstCard.nMiss + 1
        end

        tBulletInfo.tDstCard.nBeHit = tBulletInfo.tDstCard.nBeHit + 1
    end

    self:waitAsync(tTaskIDList)

    self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_COST_HP, tBulletInfo.tDstCard, tBulletInfo.tSrcCard, tBulletInfo.nDamage)
    
    if nOldHP > 0 and nCurrentHP == 0 then
        self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_DEAD, tBulletInfo.tDstCard)
    end
end

function KBattleStepBase:processCardAttack(tSrcCard)
    if tSrcCard.tComboSkill then
        if tSrcCard.tComboSkill.skill:fire(self, tSrcCard, tSrcCard.tComboSkill.muti) then
            return
        end
    end

    self:processAttackOnce(tSrcCard)
end


function KBattleStepBase:processAttackOnce(tSrcCard)
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tSrcCardState = KBattleConfig.getBrokenState(tSrcCard)
    if tSrcCardState == CARD_BROKEN_STATE.BIG then
        return
    end
	local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
	if not tDstCard then
		return
	end
	
    self:processAttackTarget(tSrcCard, tDstCard)
end

function KBattleStepBase:playNightBlastLeftAnimation(tSrcCard, tDstCard) 
    local tTaskIDList = {}
    local nID = self:asyncExec(self.playAnimation, self, "playNightCardAttackFireAnimation", tSrcCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightBulletFireAnimation", tSrcCard, tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playComboBulletBlastLeftAnimation", tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightCardBeAttackedAnimation", tDstCard)
    table.insert(tTaskIDList, nID)
    KSound.playEffect("boom")
    self:waitAsync(tTaskIDList)
end

function KBattleStepBase:playNightBlastRightAnimation(tSrcCard, tDstCard) 
    local tTaskIDList = {}
    local nID = self:asyncExec(self.playAnimation, self, "playNightCardAttackFireAnimation", tSrcCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightBulletFireAnimation", tSrcCard, tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playComboBulletBlastRightAnimation", tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightCardBeAttackedAnimation", tDstCard)
    table.insert(tTaskIDList, nID)
    KSound.playEffect("boom")
    self:waitAsync(tTaskIDList)
end

function KBattleStepBase:playNightBlastMiddleAnimation(tSrcCard, tDstCard, nOldHP, nCurrentHP, nDamage) 
    local nOldHP, nCurrentHP    = self:getBattleData():costHP(tDstCard, nDamage, tSrcCard)
    local nType                 = ATTACK_RESULT.CRIT    --night fight combo must be 
    local tTaskIDList = {}
    local nID = self:asyncExec(self.playAnimation, self, "playNightCardAttackFireAnimation", tSrcCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightBulletFireAnimation", tSrcCard, tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playComboBulletBlastMiddleAnimation", tDstCard)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playNightCostHPAnimation", tDstCard, nOldHP, nCurrentHP)
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.playAnimation, self, "playHurtAnimation", tDstCard, nType, nDamage)    
    table.insert(tTaskIDList, nID)
    KSound.playEffect("boom")
    self:waitAsync(tTaskIDList)
end

function KBattleStepBase:processAttackCombo(tSrcCard, funCalcDamage)
    local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
    if not tDstCard then
        return
    end
    local nDamageType, nDamage = funCalcDamage(tSrcCard, tDstCard)

    local nBulletID             = self:addBullet(tSrcCard, tDstCard, nDamageType, nDamage)
    local KBattleConfig         = require("battle/KBattleConfig")
    local oldCardState          = KBattleConfig.getBrokenState(tDstCard)
    local nOldHP, nCurrentHP    = self:getBattleData():costHP(tDstCard, nDamage, tSrcCard)
    local newCardState          = KBattleConfig.getBrokenState(tDstCard)
    
    KSound.playEffect("fire")
    self:playAnimation("playCardRoleComboAttackAnimation", tSrcCard)
    self:playNightBlastLeftAnimation(tSrcCard, tDstCard)
    self:playNightBlastRightAnimation(tSrcCard, tDstCard)
    self:playNightBlastMiddleAnimation(tSrcCard, tDstCard, nOldHP, nCurrentHP, nDamage)
    
    local bIsLeftTeam  = tDstCard.bLeftSide

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self:playBrokenAnimation(tDstCard)
    end
    
    if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        self:playFightDestroyAnimation(tDstCard)
    end
end

function KBattleStepBase:cardFireTarget(tSrcCard, tDstCard, nLaunchNum, nInterval, tInfo)
    self:delay((nLaunchNum-1) * nInterval)

    local nType, nDamage = tInfo.damageType, tInfo.damage
    if (not nType) or (not nDamage) then
        nType, nDamage = self.tLogic:calcDamage(tSrcCard, tDstCard)
    end

    -- 被动技能埋点
    local tParam = {tDstCard = tDstCard}
    self:checkPoint(ABILITY_CHECK_POINT.CARD_BEFORE_ATTACK, tSrcCard, tDstCard, nDamage, nType, tParam)
    tDstCard = tParam.tDstCard
    --

    local nBulletID      = self:addBullet(tSrcCard, tDstCard, nType, nDamage)
    self:playAnimation("playCardFireAnimation", tSrcCard)
    KSound.playEffect("fire")
    self:playAnimation("playBulletFireAnimation", tSrcCard, tDstCard)
    KSound.playEffect("boom")
    
    if nType ~= ATTACK_RESULT.GRAZE then
        self:playAnimation("playBulletBlastAnimation", tDstCard)
    end

    -- self:applyBulletDamage(nBulletID)
    local nTaskID       = self:asyncExec(self.applyBulletDamage, self, nBulletID)
    table.insert(tInfo.tDamageTaskIDList, nTaskID)

    -- 被动技能埋点
    self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_ATTACK, tSrcCard, tDstCard, nDamage, nType)
end

function KBattleStepBase:processAttackTarget(tSrcCard, tDstCard, nType, nDamage)
    self:print("processAttackOnce", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, tSrcCard, tDstCard)

    local KEquip        = require("src/battle/KEquip")
    local nAddLaunchNum, nInterval = KEquip.getAddLaunchCount(self.nStepType, tSrcCard)
    local nLaunchNum    = 1 + nAddLaunchNum
    local tInfo         = {tDamageTaskIDList = {}, damageType = nType, damage = nDamage}
    local KBattleConfig = require("battle/KBattleConfig")
    local oldCardState  = KBattleConfig.getBrokenState(tDstCard)

    local tTaskIDList   = {}

    local bShowAbilityAnimation = false
    local crossStartFrame = 0
    local crossFireFrame  = 60
    if tSrcCard.tAbilityList then
        for _, oneAbility in ipairs(tSrcCard.tAbilityList) do
            if oneAbility.bShowAttackAnimation then
                bShowAbilityAnimation = true
                local nID = self:asyncExec(self.playAnimation, self, "playCardAbilityAnimation", tSrcCard, oneAbility.nAbilityID)
                table.insert(tTaskIDList, nID)
                break
            end
        end
    end
    if not bShowAbilityAnimation then
        crossFireFrame = 30
        local nID = self:asyncExec(self.playAnimation, self, "playCardRoleAttackAnimation", tSrcCard)    
        table.insert(tTaskIDList, nID)
    end
    local nID = self:asyncExec(self.playAnimation, self, "playCardAttackBeginAnimation", tSrcCard)    
    table.insert(tTaskIDList, nID)
    self:delay((crossFireFrame - crossStartFrame) / 60)
    for i = 1, nLaunchNum do
        local nTaskID   = self:asyncExec(self.cardFireTarget, self, tSrcCard, tDstCard, i, nInterval, tInfo)
        table.insert(tTaskIDList, nTaskID)
    end
    self:waitAsync(tTaskIDList)
    self:playAnimation("playCardAttackEndAnimation", tSrcCard)
    self:waitAsync(tInfo.tDamageTaskIDList)

    local bIsLeftTeam  = tDstCard.bLeftSide

    local newCardState  = KBattleConfig.getBrokenState(tDstCard)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self:playBrokenAnimation(tDstCard)
    end

    if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        self:playFightDestroyAnimation(tDstCard)
    end
end

function KBattleStepBase:guideFire(tRoundList)
    for _, attackInfo in ipairs(tRoundList) do
        print(attackInfo.attacker, attackInfo.beAttacker, attackInfo.hurt, attackInfo.isLeft)
        local isLeft    = attackInfo.isLeft
        local tScrCard  = self:getBattleData():getCardData(attackInfo.attacker, isLeft)
        local tDstCard  = self:getBattleData():getCardData(attackInfo.beAttacker, not isLeft)
        local nDamage   = attackInfo.hurt
        local nType     = ATTACK_RESULT.NORMAL
        if nDamage == 0 then 
            nType = ATTACK_RESULT.MISS
        end
        self:processAttackTarget(tScrCard, tDstCard, nType, nDamage)
    end
end

function KBattleStepBase:playAnimation(szFunc, ...)
	self:print("playAnimation", szFunc, ... )

	local KBattleUIHelper   = require("battle/KBattleUIHelper")
    local tBattleData       = self:getBattleData()
    local tBattleUI         = self:getBattleUI()
	KBattleUIHelper.playAnimation(szFunc, tBattleData, tBattleUI, ...)
end

function KBattleStepBase:addOutWaiter()
    return self.tBattleManager:addWaiting()
end

function KBattleStepBase:delOutWaiter(nID)
    self.tBattleManager:delWaiting(nID)
end

function KBattleStepBase:waitSubStepFinish()
    self:print("waitSubStepFinish")

    self.tBattleManager:waitSubStepFinish()
end

function KBattleStepBase:asyncExec(fnFunc, ...)
	return self.tAsyncExector:exec(fnFunc, ...)
end

function KBattleStepBase:waitAsync(tTaskIDList)
	self.tAsyncExector:waiting(tTaskIDList)
end

function KBattleStepBase:print(...)
	print("[" .. self:getName() .. "]", ...)
end

function KBattleStepBase:delay(seconds)
	self:print("delay", seconds)
	local tUI = self:getBattleUI()
    local mainNode = tUI._mainLayout
    
    local func = createThreadResumeFunc()
    delayExecute(mainNode, func, seconds)
    coroutine.yield()
end

function KBattleStepBase:showOneScoutResult(card, seqIndex)
    self:print("showOneScoutResult", card.bLeftSide, card.nIndex, card.bScouted)
    local  delaySeconds = seqIndex * 0.3
    self:delay(delaySeconds)
    self:playAnimation("playOneCardAnimation", card, "actionExclamation", 2, 59, false)
end

function KBattleStepBase:resettingOneScoutResult(card, seqIndex)
    self:print("resettingOneScoutResult", card.bLeftSide, card.nIndex, card.bScouted)
    self:playAnimation("playOneCardAnimation", card, "actionExclamation", 60, 80, false)
end

function KBattleStepBase:getLeftSideScoutCard()
    local tCard    = nil
    local tBattleData   = self:getBattleData()
    for _, v in ipairs(tBattleData.tSrcTeam) do    
        if not tCard or v.nCurrentHP > 0 and v.nScout > tCard.nScout then
            tCard = v
        end
    end
    
    return tCard
end

function KBattleStepBase:getRightSideScoutCard()
    local tCard         = nil
    local tBattleData   = self:getBattleData()
    for _, v in ipairs(tBattleData.tDstTeam) do
        if not tCard or v.nCurrentHP > 0 and v.nScout > tCard.nScout then
            tCard = v
        end
    end
    
    return tCard 
end

local scoutRandomRange = {0.7, 1.3}

function KBattleStepBase:getLineupScout(tCard)
    return self:getBattleData():getLineupScout(tCard)
end

function KBattleStepBase:getTankTypeScoutCoe(tSrcCard, tDstCard)
    return self.tLogic:getTankTypeScoutCoe(tSrcCard, tDstCard)
end

function KBattleStepBase:getLeftSideScoutResult()
    local tBattleData       = self:getBattleData()
    local tSrcCard          = self:getLeftSideScoutCard()
    local lineupScout       = self:getLineupScout(tSrcCard)
    local tResult           = {}
    
    for _, tDstCard in ipairs(tBattleData.tDstTeam) do
        if tDstCard.nCurrentHP > 0 then
            local randomValue   = random(scoutRandomRange)
            local scoutAddtion  = self:getTankTypeScoutCoe(tSrcCard, tDstCard)
            local scoutedValue  = ((tSrcCard.nScout * lineupScout * randomValue) * scoutAddtion - tDstCard.nHide)
			
            if tDstCard.bScouted ~= (scoutedValue > 0) then
                tDstCard.bScouted = scoutedValue > 0
                table.insert(tResult, {scoutedValue, tDstCard})
            end 
            
            print("CardScout", tDstCard.bLeftSide, tDstCard.nIndex, tDstCard.nHide, tSrcCard.nScout, randomValue, tDstCard.bScouted)

        else
            tDstCard.bScouted = false            
        end
    end
    
    table.sort(tResult, function (a, b) return a[1] < b[1] end)
    
    return tResult
end

function KBattleStepBase:getRightSideScoutResult()
    local tBattleData     = self:getBattleData()
    local tDstCard        = self:getRightSideScoutCard()
    local lineupScout     = self:getLineupScout(tDstCard)
    local tResult         = {}

    for _, tSrcCard in ipairs(tBattleData.tSrcTeam) do 
        if tSrcCard.nCurrentHP > 0 then
            local randomValue   = random(scoutRandomRange)
            local scoutAddtion  = self:getTankTypeScoutCoe(tDstCard, tSrcCard)
            local scoutedValue  = ((tDstCard.nScout  * lineupScout * randomValue) * scoutAddtion - tSrcCard.nHide)

            if tSrcCard.bScouted ~= (scoutedValue > 0) then
                tSrcCard.bScouted = scoutedValue > 0
                table.insert(tResult, {scoutedValue, tSrcCard})
            end
            print("CardScout", tSrcCard.bLeftSide, tSrcCard.nIndex, tSrcCard.nHide, tDstCard.nScout, randomValue, tSrcCard.bScouted)
        else
            tSrcCard.bScouted = false
        end
    end
    
    table.sort(tResult, function (a, b) return a[1] < b[1] end)
    
    return tResult    	
end

function KBattleStepBase:scout()
    local tBattleData = self:getBattleData()
    
    local tLeftScoutResult = self:getLeftSideScoutResult()
    local tRightScoutResult = self:getRightSideScoutResult()
    
    local taskList = {}
    local seqIndex = 0
    for _, v in ipairs(tLeftScoutResult) do
        local tDstCard = v[2]
        if tDstCard.bScouted then
            seqIndex = seqIndex + 1
            local taskID = self:asyncExec(self.showOneScoutResult, self, tDstCard, seqIndex)
            table.insert(taskList, taskID)
        else
            if not tDstCard.bScouted then
                return
            end
            local taskID = self:asyncExec(self.resettingOneScoutResult, self, tDstCard, seqIndex)
            table.insert(taskList, taskID)
        end
    end
    
    seqIndex = 0
    for _, v in ipairs(tRightScoutResult) do
        local tDstCard = v[2]
        if tDstCard.bScouted then
            seqIndex = seqIndex + 1
            local taskID = self:asyncExec(self.showOneScoutResult, self, tDstCard, seqIndex)
            table.insert(taskList, taskID)
        else
            if not tDstCard.bScouted then
                return
            end
            local taskID = self:asyncExec(self.resettingOneScoutResult, self, tDstCard, seqIndex)
            table.insert(taskList, taskID)
        end
    end
     
     self:waitAsync(taskList)
end

function KBattleStepBase:playFightFullScreenAnimation()
    if #self.tFullScreenAnimationList ~= 1 then return end

    while #self.tFullScreenAnimationList > 0 do
        local tOneToShow = self.tFullScreenAnimationList[1]
        self:playAnimation(unpack(tOneToShow, 1, table.maxn(tOneToShow)))
        table.remove(self.tFullScreenAnimationList, 1)
    end
end

function KBattleStepBase:playBrokenAnimation(card)
    if card.bBrokenAnimationPlayed then 
        return 
    end
    card.bBrokenAnimationPlayed = true

    local KBattleConfig = require("battle/KBattleConfig")
    local newCardState  = KBattleConfig.getBrokenState(card)
    local isNightFight  = self.nStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT

    local tBattleData    = self:getBattleData()
    local backgroundType = tBattleData.tSrcTeam.background
    
    table.insert(self.tFullScreenAnimationList, {"playBrokenAnimation", card, backgroundType, isNightFight, newCardState})

    self:playFightFullScreenAnimation()
end

function KBattleStepBase:playNightBrokenAnimation(card)
    if card.bBrokenAnimationPlayed then 
        return 
    end
    card.bBrokenAnimationPlayed = true

    local tBattleData           = self:getBattleData()
    local backgroundType        = tBattleData.tSrcTeam.background

    table.insert(self.tFullScreenAnimationList, {"playNightBrokenAnimation", card, backgroundType, true, newCardState})

    self:playFightFullScreenAnimation()
end

function KBattleStepBase:playFightDestroyAnimation(card)
    for _, v in ipairs(self.tFullScreenAnimationList) do
        if v[1] == "playFightDestroyAnimation" and v[2] == card then
            return
        end
    end
    table.insert(self.tFullScreenAnimationList, {"playFightDestroyAnimation", card})

    self:playFightFullScreenAnimation()
end

function KBattleStepBase:emergencyRepairHandle()
    local tBattleData                   = self:getBattleData()
    local emergencyRepairCardList       = tBattleData.tEmergencyRepairCards
    local tTaskIDList                   = {}
    tBattleData.tEmergencyRepairCards   = {}

    for _, emergencyRepairCard in pairs(emergencyRepairCardList) do
        local oneEmergencyCardCurrentHP = math.floor(emergencyRepairCard.nMaxHP * 0.5)
        emergencyRepairCard.nCurrentHP  = oneEmergencyCardCurrentHP
        emergencyRepairCard.bBrokenProtect = true
        emergencyRepairCard.bUseMountItem  = false

        local nID = self:asyncExec(self.playAnimation, self, "playEmergencyRepairAnimation", emergencyRepairCard, oneEmergencyCardCurrentHP)
        table.insert(tTaskIDList, nID)
    end
    self:waitAsync(tTaskIDList)
end

function KBattleStepBase:moveOneUnit(tCard, szDstPositionName)
    print("[" .. self:getName() .. "] moveOneUnit bIsLeftTeam", tCard.bLeftSide, "nCardIndex", tCard.nIndex, "szDstPositionName", szDstPositionName)
    self:playAnimation("playCardMoveAnimation", tCard.bLeftSide, tCard.nIndex, szDstPositionName)

    if tCard.tLandmine then
        tCard.tLandmine:effect(self, tCard)
    end
end

function KBattleStepBase:getTankTypeScoutCoe(tSrcCard, tDstCard)
    return self:getBattleData():getTankTypeScoutCoe(tSrcCard, tDstCard)
end

function KBattleStepBase:getTankTypeScoutCoe2(tSrcCard, tDstCard)
    return self:getBattleData():getTankTypeDamageCoe(tSrcCard, tDstCard)
end

function KBattleStepBase:setSkillUseState(szType, bCanUse)
    self:getBattleData():setSkillUseState(szType, bCanUse)
    self:getBattleUI():refreshSkillButtonUI()
end

function KBattleStepBase:getSkillUseState(szType)
    return self:getBattleData():getSkillUseState(szType)
end

function KBattleStepBase:rightTeamCastSkill(tOneSkill)
    local tBattleManager    = self.tBattleManager
    local tBattleData       = self:getBattleData()
    local bIsLeftTeam       = false
    local nEquipTemplateID  = tOneSkill.nEquipTemplateID
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local nSkillID          = equipConfig.nSkill

    if tBattleData:canUseSkill(tOneSkill, bIsLeftTeam) and tBattleManager:canUseSkill(bIsLeftTeam, nSkillID, tBattleData) then
        tBattleData:useSkill(tOneSkill, bIsLeftTeam)
        tBattleManager:castSkill(bIsLeftTeam, nSkillID, nEquipTemplateID)
        return
    end
end

function KBattleStepBase:rightTeamUseSkill()
    local tBattleData = self:getBattleData()
    local tSkillList  = tBattleData:getRightTeamSkillList()
    if not tSkillList or #tSkillList == 0 then return end
    for _, oneSkill in ipairs(tSkillList) do
        local nUseSkillRate = oneSkill.tSkillUseRate[self.nStepType]

        local randomValue = random()
        print("---------> rightTeam use skill randomValue: " .. randomValue)
        local bUseSkill = (randomValue < nUseSkillRate)
        if bUseSkill then
            self:rightTeamCastSkill(oneSkill)
        end
    end
end

function KBattleStepBase:showSkillPanel()
    print("[" .. self:getName() .. "] showSkillPanel")
    local tBattleData   = self:getBattleData()
    local getSkillAble  = tBattleData:getSkillAble() 
    if not getSkillAble then return end
    -- self:getBattleUI():refreshSkillButtonUI()

    self:playAnimation("playShowSkillPanelAnimation")
end

function KBattleStepBase:hideSkillPanel()
    print("[" .. self:getName() .. "] hideSkillPanel")
    local tBattleData   = self:getBattleData()
    local getSkillAble  = tBattleData:getSkillAble() 
    if not getSkillAble then return end

    self:playAnimation("playHideSkillPanelAnimation")
end

function KBattleStepBase:checkSkillButtonState()
    local tBattleData   = self:getBattleData()
    local getSkillAble  = tBattleData:getSkillAble() 
    if not getSkillAble then return end

    local changeList = tBattleData.tSkillChangeStateList
    local index = #changeList
    for i = index, 1, -1 do
        local stateInfo  = changeList[i]
        if self.nStepType >= stateInfo.stepType then
            local tSkillList = self:getBattleData():getLeftTeamSkillList()
            local tOneSkill  = tSkillList[stateInfo.skillPosition]
            tOneSkill.tSkillClass:changeSkillButtonState(stateInfo.state)
            table.remove(changeList, i)
        end
    end

    local changeListIndex = tBattleData.tSkillChangeStateListIndex
    local index = #changeListIndex
    for i = index, 1, -1 do
        local stateInfo = changeListIndex[i]
        if tBattleData.nCurrentStepIndex >= stateInfo.stepIndex then
            local tSkillList = self:getBattleData():getLeftTeamSkillList()
            local tOneSkill  = tSkillList[stateInfo.skillPosition]
            tOneSkill.tSkillClass:changeSkillButtonState(stateInfo.state)
            table.remove(changeListIndex, i)
        end
    end
end

-- -- 伤害
-- function KBattleStepBase:calcDamage(tSrcCard, tDstCard, nEquipPos, ...)
--     return self.tCalc:calcDamage(tSrcCard, tDstCard, nEquipPos, ...)
-- end

function KBattleStepBase:checkPoint(nCheckPointID, ...)
    self.tBattleManager.tAbilityManager:checkPoint(nCheckPointID, ...)
end

return KBattleStepBase
