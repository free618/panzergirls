
local KBattleUIHelper = {}

local FRAME_PER_SECOND = 60

local damage = 0

local m_tDamageSection = {
    {["upLimit"] = 100, ["downLimit"] = 75,  ["stateName"] = nil,                   ["hpState"] = "unit_blood_1"},
    {["upLimit"] = 75,  ["downLimit"] = 50,  ["stateName"] = "Image_damage_light",  ["hpState"] = "unit_blood_2"},
    {["upLimit"] = 50,  ["downLimit"] = 25,  ["stateName"] = "Image_damage_middle", ["hpState"] = "unit_blood_3"},
    {["upLimit"] = 25,  ["downLimit"] = 0,   ["stateName"] = "Image_damage_heavy",  ["hpState"] = "unit_blood_4"},
    {["upLimit"] = 0,   ["downLimit"] = -1,  ["stateName"] = "Image_damage_broken", ["hpState"] = nil}
}

local function attackWhiteFlash(tBattleUI, bVisible, tAttackCard)
    local nodeTeamName      = "Node_ally_unit"
    if not tAttackCard.bLeftSide then nodeTeamName = "Node_enemy_unit" end
    local nodeTeamUnit      = tBattleUI._mainLayout:getChildByName(nodeTeamName)
    local projectNodeCard   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. tAttackCard.nIndex)
    local panelUnitBase     = projectNodeCard:getChildByName("Panel_unit")
    local panelMember       = panelUnitBase:getChildByName("Panel_member")
    local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
    local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
    local imageMemberRed    = panelMember:getChildByName("Image_member_red")
    panelMember:setVisible(bVisible)
    imageMemberBounce:setVisible(bVisible)
    imageMemberShadow:setVisible(false)
    imageMemberRed:setVisible(false)
end

local function playAnimationAndCallback(fnCallback, tBattleUI, szActionName, bLoop, bStillVisible, nStartFrame, nEndFrame)
    local nStartAnimationFrame  = nStartFrame
    if not nStartAnimationFrame then nStartAnimationFrame = 0 end

    local nEndAnimationFrame    = nEndFrame
    local tAction               = tBattleUI[szActionName]
    local tActionNode           = tAction.actionNode
    local nDurationFrame        = tAction:getDuration()
    if not nEndAnimationFrame then nEndAnimationFrame = nDurationFrame end

    local fDelaySecond      = nEndAnimationFrame / FRAME_PER_SECOND
    print("-----> szActionName ", szActionName, "-----> nDurationFrame", nDurationFrame, "-----> fDelaySecond", fDelaySecond)
    local actionSequence    = cc.Sequence:create(
        cc.CallFunc:create(
            function ()
                tActionNode:setVisible(true)
                tAction:gotoFrameAndPlay(nStartAnimationFrame, nEndAnimationFrame, bLoop)
            end
        ),
        cc.DelayTime:create(fDelaySecond),
        cc.CallFunc:create(
            function() 
                tAction:gotoFrameAndPause(nEndAnimationFrame)
                if not bStillVisible then 
                    tActionNode:setVisible(false)
                end
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

local function safePlayAnimation(tBattleUI, tActionUI, nStartFrame, nEndFrame, bLoop, szComment)
    --print("--------------------> safePlayAnimation Start", szComment, nStartFrame, nEndFrame, bLoop)
    local actionNode = tActionUI.actionNode
    assert(actionNode)

    actionNode:setVisible(true)
    tActionUI:gotoFrameAndPlay(nStartFrame, nEndFrame, bLoop)

    local fActionTime = (nEndFrame - nStartFrame) / FRAME_PER_SECOND
    delayExecute(
        tBattleUI,
        function()
            actionNode:setVisible(false)
            --print("--------------------> safePlayAnimation End", szComment, nStartFrame, nEndFrame, bLoop)
        end,
        fActionTime
    )
end

function KBattleUIHelper.playGateClosedState(fnCallback, tBattleData, tBattleUI)
    -- gate is closed in init function() of KUIBattleNode , so we delay time and call callback function().
    print("-----> Call playGateClosedState~")
    KSound.playEffect("gateClose")
    delayExecute(
        tBattleUI, 
        function () 
            fnCallback()
        end, 
        1.0
    )
end

function KBattleUIHelper.playGateClosedAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playGateClosedAnimation~")
    local nGateClosedFrame = 25 
    KSound.playEffect("gateClose")
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionNodeGate", false, true, 0, nGateClosedFrame)
end

function KBattleUIHelper.playStartBattleAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playStartBattleAnimation~")
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionStartBattle", false, false)
end

function KBattleUIHelper.playOpenGateAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playOpenGateAnimation~")
    local nGateClosedFrame  = 35
    KSound.playEffect("gateOpen")
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionNodeGate", false, false, nGateClosedFrame)
end

function KBattleUIHelper.playBattleStateAnimation(fnCallback, tBattleData, tBattleUI, szStep)
    print("-----> Call playScoutStateAnimation~")
    local tStepTemplateInfo     = {
        ["Scout"]               = {["nStartFrame"] = 0,     ["nEndFrame"] = 30},
        ["ArtilleryStrike"]     = {["nStartFrame"] = 30,    ["nEndFrame"] = 60},
        ["Ambush"]              = {["nStartFrame"] = 60,    ["nEndFrame"] = 90},
        ["ArtilleryAction"]     = {["nStartFrame"] = 90,    ["nEndFrame"] = 120},
        ["ArtilleryAction2"]    = {["nStartFrame"] = 120,   ["nEndFrame"] = 150},
        ["DogFight"]            = {["nStartFrame"] = 150,   ["nEndFrame"] = 180},
        ["NightFight"]          = {["nStartFrame"] = 180,   ["nEndFrame"] = 210},
    }
    local tStepInfo = tStepTemplateInfo[szStep]
    assert(tStepInfo, "Get tStepInfo Failed~")

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionBattleStep", false, true, tStepInfo.nStartFrame, tStepInfo.nEndFrame)
end

function KBattleUIHelper.playShowSkillPanelAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playShowSkillPanelAnimation~")
    local tSkillList  = tBattleData:getLeftTeamSkillList()
    local nSkillCount = #tSkillList
    if not tSkillList or #tSkillList < 1 then 
        nSkillCount = 0
        -- return
    end

    local tShowSkillPanelFrameInfo = {
        {["nStartFrame"] = 0, ["nEndFrame"] = 0},
        {["nStartFrame"] = 0, ["nEndFrame"] = 9},
        {["nStartFrame"] = 0, ["nEndFrame"] = 15},
        {["nStartFrame"] = 0, ["nEndFrame"] = 21},
    }

    local nShowSkillPanelStartFrame = tShowSkillPanelFrameInfo[nSkillCount+1].nStartFrame
    local nShowSkillPanelEndFrame = tShowSkillPanelFrameInfo[nSkillCount+1].nEndFrame

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionSkill", false, true, nShowSkillPanelStartFrame, nShowSkillPanelEndFrame)
end

function KBattleUIHelper.playHideSkillPanelAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playHideSkillPanelAnimation~")
    local tSkillList  = tBattleData:getLeftTeamSkillList()
    local nSkillCount = #tSkillList
    if not tSkillList or #tSkillList < 1 then 
        nSkillCount = 0
        -- return
    end

    local tShowSkillPanelFrameInfo = {
        {["nStartFrame"] = 61, ["nEndFrame"] = 61},
        {["nStartFrame"] = 52, ["nEndFrame"] = 61},
        {["nStartFrame"] = 46, ["nEndFrame"] = 61},
        {["nStartFrame"] = 39, ["nEndFrame"] = 61},
    }

    local nHideSkillPanelStartFrame = tShowSkillPanelFrameInfo[nSkillCount+1].nStartFrame
    local nHideSkillPanelEndFrame   = tShowSkillPanelFrameInfo[nSkillCount+1].nEndFrame

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionSkill", false, false, nHideSkillPanelStartFrame, nHideSkillPanelEndFrame)
end

function KBattleUIHelper.playSkill1Aniamtion(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playSkillAniamtion~")
    local battleBomberSkill         = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bomber.csb")
    local battleBombingSkill        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_bombing_v2.csb")
    local battleBomberSkillAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bomber.csb")
    local battleBombingSkillAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bombing_v2.csb")
    local mainNode                = tBattleUI._mainLayout
    battleBomberSkill:stopAllActions()
    battleBombingSkill:stopAllActions()
    battleBomberSkill:runAction(battleBomberSkillAction)
    battleBomberSkillAction:gotoFrameAndPause(0)
    battleBombingSkill:runAction(battleBombingSkillAction)
    battleBomberSkillAction:gotoFrameAndPause(0)
    battleBombingSkill:setVisible(false)
    mainNode:addChild(battleBomberSkill, 20)
    mainNode:addChild(battleBombingSkill, 21)
    local battleBomberStartFrame    = 0
    local battleBomberEndFrame      = 120
    local battleBomberActionTime    = (battleBomberEndFrame - battleBomberStartFrame) / FRAME_PER_SECOND
    local battleBombingStartFrame   = 0
    local battleBombingEndFrame     = 150
    local battleBomberingActionTime = (battleBombingEndFrame - battleBombingStartFrame) / FRAME_PER_SECOND
    local battleBomberAllTime       = battleBomberActionTime + battleBomberActionTime
    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                battleBomberSkillAction:gotoFrameAndPlay(battleBomberStartFrame, battleBomberEndFrame, false)
            end
        ),
        cc.DelayTime:create(battleBomberActionTime),
        cc.CallFunc:create(
            function()
                battleBombingSkill:setVisible(true)
                battleBombingSkillAction:gotoFrameAndPlay(battleBombingStartFrame, battleBombingEndFrame, false)
            end
        )
    )
    tBattleUI:runAction(actionSequence)
    
    delayExecute(
        tBattleUI,
        function()
            battleBomberSkill:removeFromParent()
            battleBombingSkill:removeFromParent()
            fnCallback()
        end,
        battleBomberAllTime
    )

    KSound.playEffect("bombardment")
end

function KBattleUIHelper.playLeftTeamCutInAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playLeftTeamCutInAnimation~")
    -- fill card info by tBattleData
    local mainNode      = tBattleUI._mainLayout
    local nodeTeamUnit  = mainNode:getChildByName("Node_ally_unit")

    for k = 1, MAX_TEAM_CARD_COUNT do
        v = tBattleData.tSrcTeam[k]
        if not v then
            for j = k, MAX_TEAM_CARD_COUNT do
                local projectNodeTeamUnit   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. j)
                projectNodeTeamUnit:setVisible(false)
            end
            break
        end

        local projectNodeTeamUnit   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. k)
        local panelTeam             = projectNodeTeamUnit:getChildByName("Panel_unit")

        -- hide card red effect
        local panelCardEffect   = panelTeam:getChildByName("Panel_member")
        panelCardEffect:setVisible(false)

        local nHPPercent = v.nCurrentHP / v.nMaxHP * 100
        -- update card state
        local nodeCardState     = panelTeam:getChildByName("Node_damage")
        local imageHPBase       = panelTeam:getChildByName("Image_unit_blood")

        local hpName    = {"unit_blood_1", "unit_blood_2", "unit_blood_3", "unit_blood_4", nil}
        local stateName = {nil, "Image_damage_light", "Image_damage_middle", "Image_damage_heavy", "Image_damage_broken"}
        KUtil.drawCardState(imageHPBase, nodeCardState, hpName, stateName, nHPPercent)

        -- update card HP
        local textHPInfo        = panelTeam:getChildByName("Text_hp_numerical")
        textHPInfo:setString(v.nCurrentHP .. "/" .. v.nMaxHP)

        local nCardTemplateID   = v.nTemplateID
        -- update card head image
        local imageHead = panelTeam:getChildByName("ProjectNode_card")
        local tHeadInfo = {["nID"] = v.nID, ["nTemplateID"] = nCardTemplateID, ["nSkinTemplateID"] = v.nSkinTemplateID, 
                            ["nCurrentHP"] = v.nCurrentHP, ["bRing"] = v.bRing, ["nMaxHP"] = v.nMaxHP}
        KUtil.onlyUpdateCardHeadBase(imageHead, tHeadInfo)

        if v.nCurrentHP <= 0 then
            local panelMember       = panelTeam:getChildByName("Panel_member")
            local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
            local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
            local imageMemberRed    = panelMember:getChildByName("Image_member_red")
            local projectNodeExclamation = panelTeam:getChildByName("ProjectNode_exclamation")
            panelMember:setVisible(true)
            imageMemberShadow:setVisible(true)
            imageMemberBounce:setVisible(false)
            imageMemberRed:setVisible(false)  
            projectNodeExclamation:setVisible(false)  
        end
    end

    -- make card cut in scene
    local nMaxDelayTime = 0
    for k, v in ipairs(tBattleData.tSrcTeam) do
        local actionCard = tBattleUI["_actionLeftTeam"][k].actionCard
        local nCurrentDelayTime     = k * 0.2
        local nCardActionTime       = actionCard:getDuration() / FRAME_PER_SECOND
        local nCardCutInStartFrame  = 6
        local nCardCutInEndFrame    = 30
        local nCardActionTime       = (nCardCutInEndFrame - nCardCutInStartFrame) / FRAME_PER_SECOND
        local actionSequence = cc.Sequence:create(
            cc.DelayTime:create(nCurrentDelayTime),
            cc.CallFunc:create(
                function() 
                    KSound.playEffect("tankAppear")
                    actionCard:gotoFrameAndPlay(nCardCutInStartFrame, nCardCutInEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)
        nMaxDelayTime = nCurrentDelayTime + nCardActionTime + 0.2
    end

    print("-----> nMaxDelayTime", nMaxDelayTime)
    --delayExecute(tBattleUI, function () fnCallback() end, nMaxDelayTime)
    --temp for now cut in
    delayExecute(tBattleUI, function () fnCallback() end, nMaxDelayTime)
end

function KBattleUIHelper.playCardMoveAnimation(fnCallback, tBattleData, tBattleUI, bIsLeftTeam, nCardIndex, szDstPositionName)
    print("-----> Call playCardMoveAnimation~", bIsLeftTeam, nCardIndex, szDstPositionName)
    local mainNode      = tBattleUI._mainLayout
    local nodeMovePos   = mainNode:getChildByName("Node_mobile")

    local szCardTeamUIName  = "Node_ally_unit"
    if not bIsLeftTeam then szCardTeamUIName = "Node_enemy_unit" end
    local szTeamPosUIName   = "Node_mobile_ally"
    if not bIsLeftTeam then szTeamPosUIName = "Node_mobile_enemy" end

    -- get fDstPosX
    local nodeDstPos        = nodeMovePos:getChildByName(szTeamPosUIName)
    local nodeTankMove      = nodeDstPos:getChildByName("Node_tank_move")
    local nodeFinalPos      = nodeTankMove:getChildByName(szDstPositionName)
    assert(nodeFinalPos, "Get nodeFinalPos Failed~")
    local fDstPosX          = nodeFinalPos:getPositionX()

    -- get fDstPosY
    local nodeCard          = mainNode:getChildByName(szCardTeamUIName)
    local projectNodeCard   = nodeCard:getChildByName("ProjectNode_unit_" .. nCardIndex)
    assert(projectNodeCard, "Get projectNodeCard Failed~")
    local fDstPosY          = projectNodeCard:getPositionY()

    local nTankStartMoveFrame   = 100
    local nTankEndMoveFrame     = 130
    local nTankNormalFrame      = 60
    local nTankMoveTime         = 1.0
    local szTeamActionName      = "_actionLeftTeam"
    if not bIsLeftTeam then szTeamActionName = "_actionRightTeam" end
    print("----------> KBattleUIHelper.playCardMoveAnimation", fDstPosX, fDstPosY)
    local actionSequence        = cc.Sequence:create(
        cc.CallFunc:create(
            function () 
                print("-----> playCardMoveAnimation start")
                tBattleUI[szTeamActionName][nCardIndex].actionCard:gotoFrameAndPlay(nTankStartMoveFrame, nTankEndMoveFrame, true)
            end
        ),
        cc.MoveTo:create(nTankMoveTime, cc.p(fDstPosX, fDstPosY)),
        cc.CallFunc:create(
            function () 
                print("-----> playCardMoveAnimation end")
                tBattleUI[szTeamActionName][nCardIndex].actionCard:gotoFrameAndPause(nTankMoveTime)
                fnCallback()
            end
        )
    )
    projectNodeCard:runAction(actionSequence)

    KSound.playEffect("tankFightForward")
end

function KBattleUIHelper.playOneCardAnimation(fnCallback, tBattleData, tBattleUI, tCard, szAnimationName, nStartFrame, nEndFrame, bLoop)
    local bIsLeftTeam = tCard.bLeftSide
    local nCardIndex = tCard.nIndex

    print("-----> playOneCardAnimation", tCard.bLeftSide, tCard.nIndex, szAnimationName, nStartFrame, nEndFrame, bLoop)

    local mainNode      = tBattleUI._mainLayout

    local szCardTeamUIName  = "Node_ally_unit"
    if not bIsLeftTeam then szCardTeamUIName = "Node_enemy_unit" end
    local szTeamPosUIName   = "Node_mobile_ally"
    if not bIsLeftTeam then szTeamPosUIName = "Node_mobile_enemy" end
    local szTeamActionName      = "_actionLeftTeam"
    if not bIsLeftTeam then szTeamActionName = "_actionRightTeam" end

    local nodeCard          = mainNode:getChildByName(szCardTeamUIName)
    local projectNodeCard   = nodeCard:getChildByName("ProjectNode_unit_" .. nCardIndex)

    local action = tBattleUI[szTeamActionName][nCardIndex][szAnimationName]

    nStartFrame = nStartFrame or 0
    nEndFrame   = nEndFrame or action:getDuration()
    bLoop       = bLoop or false

    if nStartFrame == nEndFrame then
        action:gotoFrameAndPause(nEndFrame)
        fnCallback()
        return
    end

    local actionNode            = action.actionNode
    local actionSequence        = cc.Sequence:create(
        cc.CallFunc:create(
            function ()
                actionNode:setVisible(true)
                action:gotoFrameAndPlay(nStartFrame, nEndFrame, bLoop)
            end
        ),
        cc.DelayTime:create((nEndFrame - nStartFrame) / FRAME_PER_SECOND),
        cc.CallFunc:create(
            function ()
                -- now the function only called by scout
                --actionNode:setVisible(false)
                fnCallback()
            end
        )
    )
    projectNodeCard:runAction(actionSequence)
end

function KBattleUIHelper.playDistanceRuleAnimation(fnCallback, tBattleData, tBattleUI, szStep, nMoveDistance)
    print("-----> Call playDistanceRuleAnimation", szStep, nMoveDistance)
    local tStepTemplateInfo = {
        ["Scout"]               = {["nStartFrame"] = 1,     ["nEndFrame"] = 30},
        ["Ambush"]              = {["nStartFrame"] = 31,    ["nEndFrame"] = 60},
        ["ArtilleryStrike"]     = {["nStartFrame"] = 61,    ["nEndFrame"] = 90},
        ["ArtilleryAction"]     = {["nStartFrame"] = 91,    ["nEndFrame"] = 110},
        ["ArtilleryAction2"]    = {["nStartFrame"] = 111,   ["nEndFrame"] = 120},
        ["DogFight"]            = {["nStartFrame"] = 121,   ["nEndFrame"] = 150},
    }
    local tStepInfo = tStepTemplateInfo[szStep]
    assert(tStepInfo, "Get tStepInfo Failed~")

    local mainNode              = tBattleUI._mainLayout
    local nodeDistanceRuler     = mainNode:getChildByName("Node_distance_ruler")
    -- play ruler action
    playAnimationAndCallback(function() end, tBattleUI, "_actionDistanceRuler", false, true, tStepInfo.nStartFrame, tStepInfo.nEndFrame)

    -- play burning action
    local projectNodeDistanceText   = nodeDistanceRuler:getChildByName("ProjectNode_burning_track")
    local spritePanel               = projectNodeDistanceText:getChildByName("Sprite_2")
    local textDistance              = spritePanel:getChildByName("Text_1")
    textDistance:setString(tostring(nMoveDistance))
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionDistanceText", false, false)
end

function KBattleUIHelper.playScoutEffectAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playScoutEffect~")
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionDetect", false, false)
end

function KBattleUIHelper.playRightTeamCutInAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playRightTeamCutInAnimation~")
    local mainNode          = tBattleUI._mainLayout
    local nodeTeamUnit      = mainNode:getChildByName("Node_enemy_unit")

    for k = 1, MAX_TEAM_CARD_COUNT do
        local v = tBattleData.tDstTeam[k]
        if not v then
            for j = k, MAX_TEAM_CARD_COUNT do
                local projectNodeTeamUnit = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. j)
                projectNodeTeamUnit:setVisible(false)
            end
            break
        end

        local projectNodeTeamUnit   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. k)
        local panelTeam             = projectNodeTeamUnit:getChildByName("Panel_unit")

        -- hide card red effect
        local panelCardEffect   = panelTeam:getChildByName("Panel_member")
        panelCardEffect:setVisible(false)

        local nHPPercent = v.nCurrentHP / v.nMaxHP * 100
        -- update card state
        local nodeCardState     = panelTeam:getChildByName("Node_damage")
        local imageHPBase       = panelTeam:getChildByName("Image_unit_blood")

        local hpName    = {"unit_blood_1", "unit_blood_2", "unit_blood_3", "unit_blood_4", nil}
        local stateName = {nil, "Image_damage_light", "Image_damage_middle", "Image_damage_heavy", "Image_damage_broken"}
        KUtil.drawCardState(imageHPBase, nodeCardState, hpName, stateName, nHPPercent)
        -- update card HP
        local textHPInfo        = panelTeam:getChildByName("Text_hp_numerical")
        textHPInfo:setString(v.nCurrentHP .. "/" .. v.nMaxHP)
     
        local nCardTemplateID   = v.nTemplateID
        -- update card head image
        local imageHead         = panelTeam:getChildByName("ProjectNode_card")
        local tHeadInfo         = {["nTemplateID"] = nCardTemplateID, ["nSkinTemplateID"] = v.nSkinTemplateID, ["nCurrentHP"] = v.nCurrentHP, 
                                    ["bRing"] = v.bRing, ["bIsRole"] = v.bIsRole, ["nMaxHP"] = v.nMaxHP}
        local isMonster         = not v.bIsRole
        KUtil.updateRightTeamHeadBase(imageHead, tHeadInfo, isMonster)
        
        if v.nCurrentHP <= 0 then
            local panelMember       = panelTeam:getChildByName("Panel_member")
            local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
            local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
            local imageMemberRed    = panelMember:getChildByName("Image_member_red")
            local projectNodeExclamation = panelTeam:getChildByName("ProjectNode_exclamation")
            panelMember:setVisible(true)
            imageMemberShadow:setVisible(true)
            imageMemberBounce:setVisible(false)
            imageMemberRed:setVisible(false)       
            projectNodeExclamation:setVisible(false)    
        end
    end

    -- make card cut in scene
    local nMaxDelayTime = 0
    for k, v in ipairs(tBattleData.tDstTeam) do
        local actionCard = tBattleUI["_actionRightTeam"][k].actionCard
        local nCurrentDelayTime     = k * 0.2
        local nCardCutInStartFrame  = 6
        local nCardCutInEndFrame    = 30
        local nCardActionTime       = (nCardCutInEndFrame - nCardCutInStartFrame) / FRAME_PER_SECOND
        local actionSequence = cc.Sequence:create(
            cc.DelayTime:create(nCurrentDelayTime),
            cc.CallFunc:create(
                function() 
                    KSound.playEffect("tankAppear")
                    actionCard:gotoFrameAndPlay(nCardCutInStartFrame, nCardCutInEndFrame, false)
                end
            )
        )
        tBattleUI:runAction(actionSequence)
        nMaxDelayTime = nCurrentDelayTime + nCardActionTime + 0.2
    end

    print("-----> nMaxDelayTime", nMaxDelayTime)
    delayExecute(tBattleUI, function () fnCallback() end, nMaxDelayTime)
end

function KBattleUIHelper.playLineupAnimation(fnCallback, tBattleData, tBattleUI, nLeftTeamLineup, nRightTeamLineup)
    print("-----> Call playLineupAnimation nLeftTeamLineup:", nLeftTeamLineup, "nRightTeamLineup:", nRightTeamLineup)
    local mainNode      = tBattleUI._mainLayout
    local nodeLineup    = mainNode:getChildByName("Node_radar_base")
    local projectNodeLeftTeam   = nodeLineup:getChildByName("ProjectNode_radar_ally")
    local projectNodeRightTeam  = nodeLineup:getChildByName("ProjectNode_radar_enemy")
    local imageLeftLineupBase   = projectNodeLeftTeam:getChildByName("Image_radar_ally")
    local imageRightLineupBase  = projectNodeRightTeam:getChildByName("Image_radar_enemy")

    local lineupNum = 0
    while true do 
        lineupNum = lineupNum + 1
        local imageLeftLineup   = imageLeftLineupBase:getChildByName("Image_formation_" .. lineupNum)
        if not imageLeftLineup then break end
        local imageRightLineup  = imageRightLineupBase:getChildByName("Image_formation_" .. lineupNum)
        if not imageRightLineup then break end

        local bIsLeftLineupVisible  = false
        local bIsRightLineupVisible = false

        if lineupNum == nLeftTeamLineup then bIsLeftLineupVisible = true end
        if lineupNum == nRightTeamLineup then bIsRightLineupVisible = true end

        imageLeftLineup:setVisible(bIsLeftLineupVisible)
        imageRightLineup:setVisible(bIsRightLineupVisible)
    end

    local nLineupEndFrame = 25 
    playAnimationAndCallback(function() end, tBattleUI, "_actionLeftRadar", false, true, 0, nLineupEndFrame)
    playAnimationAndCallback(fnCallback, tBattleUI, "_actionRightRadar", false, true, 0, nLineupEndFrame)

end

function KBattleUIHelper.playChangeLineupAnimation(fnCallback, tBattleData, tBattleUI, nLeftTeamLineup, nRightTeamLineup, nRandomLandType)
    print("-----> Call playChangeLineupAnimation~")
    local mainNode                  = tBattleUI._mainLayout
    local nodeLineup                = mainNode:getChildByName("Node_below")
    local projectNodeLeftLineup     = nodeLineup:getChildByName("ProjectNode_below_ally")
    local projectNodeRightLineup    = nodeLineup:getChildByName("ProjectNode_below_enemy")
    local imageLeftTeamPanel        = projectNodeLeftLineup:getChildByName("Image_upper")
    local imageRightTeamPanel       = projectNodeRightLineup:getChildByName("Image_upper")

    -- play lineup action
    local lineupNum = 0
    while true do 
        lineupNum = lineupNum + 1
        local imageLeftLineup   = imageLeftTeamPanel:getChildByName("Image_upper_" .. lineupNum)
        if not imageLeftLineup then break end
        local imageRightLineup  = imageRightTeamPanel:getChildByName("Image_upper_" .. lineupNum)
        if not imageRightLineup then break end

        local bIsLeftLineupVisible      = lineupNum == nLeftTeamLineup
        local bIsRightLineupVisible     = lineupNum == nRightTeamLineup

        imageLeftLineup:setVisible(bIsLeftLineupVisible)
        imageRightLineup:setVisible(bIsRightLineupVisible)
    end
    playAnimationAndCallback(function() end, tBattleUI, "_actionLeftLineup", false, false)
    playAnimationAndCallback(function() end, tBattleUI, "_actionRightLineup", false, false)
    --playAnimationAndCallback(fnCallback, tBattleUI, "_actionRightLineup", false)

    -- randomLandType action
    local tLandTemplateInfo = {
        {"Image_ping",  "Image_yuan"},
        {"Image_cong",  "Image_lin"},
        {"Image_shan",  "Image_di"},
        {"Image_jie",   "Image_jin"}
    }
    local tLandInfo = tLandTemplateInfo[nRandomLandType]
    assert(tLandInfo, "Get Land Info Failed~")

    local panelLineupText       = mainNode:getChildByName("ProjectNode_character")
    local projectNodeLineupText = panelLineupText:getChildByName("Panel_battle_character")
    for k, v in ipairs(tLandTemplateInfo) do
        local panelFirstText    = projectNodeLineupText:getChildByName("Panel_character_1")
        local panelSecondText   = projectNodeLineupText:getChildByName("Panel_character_2")

        local imageFirstText    = panelFirstText:getChildByName(v[1])
        local imageSecondText   = panelSecondText:getChildByName(v[2]) 
        local bIsShowText       = nRandomLandType == k
        print("-----> playChangeLineupAnimation nRandomLandType", nRandomLandType, k, bIsShowText)

        imageFirstText:setVisible(bIsShowText)
        imageSecondText:setVisible(bIsShowText)
    end

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionLineupText", false, false)

    KSound.playEffect("formation")
end

function KBattleUIHelper.playCardRoleAttackAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playCardRoleAttackAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local nodeAttack                = mainNode:getChildByName("Node_cross")
    local projectNodeLeftAttack     = nodeAttack:getChildByName("ProjectNode_cross_ally")
    local projectNodeRightAttack    = nodeAttack:getChildByName("ProjectNode_cross_enemy")

    local projectNodeTarget         = projectNodeLeftAttack
    if not tAttackCard.bLeftSide then 
        projectNodeTarget = projectNodeRightAttack
    end

    local cardImagePath         = nil
    local cardImageLightPath    = nil
    local infoName              = "cardInfo"
    if not tAttackCard.bIsRole then
        infoName = "monster"
        cardImagePath       = KUtil.getMonsterImagePath(tAttackCard, false)
        cardImageLightPath  = KUtil.getMonsterImageLightPath(tAttackCard)
    else
        cardImagePath       = KUtil.getCardImagePath(tAttackCard, false)
        cardImageLightPath  = KUtil.getCardImageLightPath(tAttackCard) 
    end

    local tCardTemplateInfo     = KConfig:getLine(infoName, tAttackCard.nTemplateID)

    local panelCross                = projectNodeTarget:getChildByName("Panel_bule_cross")
    local ALL_POP_STATE_NUM         = 4
    local panelStateBaseCurrentNum  = math.random(1, ALL_POP_STATE_NUM)
    for i = 1, ALL_POP_STATE_NUM do
        local panelStateBase    = panelCross:getChildByName("Panel_state_base_0" .. i)
        panelStateBase:setVisible(i == panelStateBaseCurrentNum)
    end

    local panelStateBase    = panelCross:getChildByName("Panel_state_base_0" .. panelStateBaseCurrentNum)

    local imageChara        = panelStateBase:getChildByName("Image_chara")    
    imageChara:loadTexture(cardImagePath)

    local imageCharaLight   = panelStateBase:getChildByName("Image_chara_light")
    imageCharaLight:loadTexture(cardImageLightPath)

    local panelStateBaseInfo = panelStateBase:getChildByName("Panel_state_base")  

    local textTankName       = panelStateBaseInfo:getChildByName("Text_tank_name")
    textTankName:setString(tCardTemplateInfo.szName)

    local textTankHP         = panelStateBaseInfo:getChildByName("Text_tank_hp")
    textTankHP:setString(tAttackCard.nCurrentHP .. "/" .. tAttackCard.nMaxHP)

    local loadingBarTankHP   = panelStateBaseInfo:getChildByName("LoadingBar_tank_hp")    
    local nTankHPPercent     = tAttackCard.nCurrentHP / tAttackCard.nMaxHP * 100
        loadingBarTankHP:setPercent(nTankHPPercent)

    local actionName = "_actionLeftAttack"
    if not tAttackCard.bLeftSide then actionName = "_actionRightAttack" end
    playAnimationAndCallback(fnCallback, tBattleUI, actionName, false, false)
    if tAttackCard.bLeftSide then
        KSound.playTalk(KSound.TALK.FIRE1, tAttackCard.nTemplateID, not tAttackCard.bIsRole)
    end
end

function KBattleUIHelper.playCardRoleComboAttackAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playCardRoleComboAttackAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local bIsLeftTeam           = tAttackCard.bLeftSide
    local actionName            = "_actionLeftCombo"
    local mainNode              = tBattleUI._mainLayout
    local nodeSkill             = mainNode:getChildByName("Node_skill")
    local projectNodeSkillLeft  = nodeSkill:getChildByName("ProjectNode_skill_ally")
    local projectNodeSkillRight = nodeSkill:getChildByName("ProjectNode_skill_enemy")

    local  projectNodeTarget    = projectNodeSkillLeft
    if not bIsLeftTeam then projectNodeTarget = projectNodeSkillRight end

    local panelThree            = projectNodeTarget:getChildByName("Panel_3")
    local panelCharacter        = panelThree:getChildByName("Panel_chara")
    local imageCharacter        = panelCharacter:getChildByName("Image_chara")
    local imageCharacterLight   = panelCharacter:getChildByName("Image_chara_light")

    local cardImagePath         = nil 
    local cardImageLightPath    = nil    
    if not tAttackCard.bIsRole then 
        cardImagePath       = KUtil.getMonsterImagePath(tAttackCard, false) 
        cardImageLightPath  = KUtil.getMonsterImageLightPath(tAttackCard)
    else
        cardImagePath       = KUtil.getCardImagePath(tAttackCard, false)
        cardImageLightPath  = KUtil.getCardImageLightPath(tAttackCard) 
    end
    imageCharacter:loadTexture(cardImagePath)
    imageCharacterLight:loadTexture(cardImageLightPath)
    
    if not bIsLeftTeam then actionName = "_actionRightCombo" end
    
    --attackWhiteFlash(tBattleUI, true, tAttackCard)

    playAnimationAndCallback(fnCallback, tBattleUI, actionName, false, false)
end

function KBattleUIHelper.playCardStandAttackAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playCardStandAttackAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tAttackCard.bLeftSide
    local nCardIndex                = tAttackCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                local fireAction         = tBattleUI[actionName][nCardIndex].actionNormalFire
                local fireActionDuration = fireAction:getDuration()
                safePlayAnimation(tBattleUI, fireAction, 0, fireActionDuration, false, "playCardStandAttackAnimation")
            end
        ),
        cc.CallFunc:create(
            function()
                --attackWhiteFlash(tBattleUI, false, tAttackCard)
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playCardAttackBeginAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tAttackCard.bLeftSide
    local nCardIndex                = tAttackCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nBeginFrame    = 60
    local nEndFrame      = 68

    local attackDelay    = 0.5-- (nEndFrame - nBeginFrame) / FRAME_PER_SECOND
    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nBeginFrame, nEndFrame, false)
            end
        ),
        cc.DelayTime:create(attackDelay),
        cc.CallFunc:create(
            function()
                --attackWhiteFlash(tBattleUI, false, tAttackCard)
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playCardFireAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tAttackCard.bLeftSide
    local nCardIndex                = tAttackCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nBeginFrame    = 69
    local nEndFrame      = 73

    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                local fireAction         = tBattleUI[actionName][nCardIndex].actionNormalFire
                local fireActionDuration = fireAction:getDuration()
                safePlayAnimation(tBattleUI, fireAction, 0, fireActionDuration, false, "playCardAttackAnimation")
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nBeginFrame, nEndFrame, false)
            end
        ),
        cc.CallFunc:create(
            function()
                --attackWhiteFlash(tBattleUI, false, tAttackCard)
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playCardAttackEndAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tAttackCard.bLeftSide
    local nCardIndex                = tAttackCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nBeginFrame      = 74
    local nEndFrame        = 100

    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nBeginFrame, nEndFrame, false)
            end
        ),
        cc.CallFunc:create(
            function()
                --attackWhiteFlash(tBattleUI, false, tAttackCard)
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playCardAttackAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playCardAttackAttackAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tAttackCard.bLeftSide
    local nCardIndex                = tAttackCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nReadyAttackStartFrame    = 60
    local nReadyAttackEndFrame      = 73
    local nBackPositionFrame        = 100

    local attackDelay               = 0.5 -- (nReadyAttackEndFrame - nReadyAttackStartFrame) / FRAME_PER_SECOND
    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function() 
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nReadyAttackStartFrame, nReadyAttackEndFrame, false)
            end
        ),
        cc.DelayTime:create(attackDelay),
        cc.CallFunc:create(
            function() 
                local fireAction         = tBattleUI[actionName][nCardIndex].actionNormalFire
                local fireActionDuration = fireAction:getDuration()
                safePlayAnimation(tBattleUI, fireAction, 0, fireActionDuration, false, "playCardAttackAnimation")
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nReadyAttackEndFrame, nBackPositionFrame, false)
            end
        ),
        cc.CallFunc:create(
            function()
                --attackWhiteFlash(tBattleUI, false, tAttackCard)
                fnCallback()
            end
        )
    )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playArtilleryStrikeCardAttackAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard)
    print("-----> Call playArtilleryStrikeCardAttackAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)
    local mainNode      = tBattleUI._mainLayout
    local bIsLeftTeam   = tSrcCard.bLeftSide
    local nCardIndex    = tSrcCard.nIndex
    
    local actionName    = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    
    local nReadyAttackStartFrame    = 60
    local nReadyAttackEndFrame      = 90
    
    local fireAction            = tBattleUI[actionName][nCardIndex].actionHuoPaoFire
    local fireActionDuration    = fireAction:getDuration()
    safePlayAnimation(tBattleUI, fireAction, 0, fireActionDuration, false, "playArtilleryStrikeCardAttackAnimation")
    
    --attackWhiteFlash(tBattleUI, false, tSrcCard)
    
    fnCallback()

    -- KSound.playEffect("boom")
end

function KBattleUIHelper.playCardComboAttackAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard)
    print("-----> Call playCardComboAttackAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)

    fnCallback()
end

function KBattleUIHelper.playArtilleryStrikeBulletFireAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard, tDstCard)
    print("-----> Call playArtilleryStrikeBulletFireAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)
    local setRotationTitedUpDegree      = 330
    local setRotationTitedDownDegree    = 45
    local frameBulletUp                 = 44    
    local frameBulletDown               = 46
    local frameBulletEnd                = 90
    local scaleFlyVisibleSize           = 0.3
    local scaleStartVisibleSize         = 0.7
    local offsetBulletVisibleY          = 80

    local mainNode          = tBattleUI._mainLayout
    local bIsLeftTeam       = tSrcCard.bLeftSide
    local nSrcCardIndex     = tSrcCard.nIndex
    local actionName        = "_actionLeftTeam"
    local nodeCardTeamName  = "Node_ally_unit" 
    
    if not bIsLeftTeam then actionName          = "_actionRightTeam"    end
    if not bIsLeftTeam then nodeCardTeamName    = "Node_enemy_unit"     end
    
    local nodeTeanUnit              = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeSrcUnitName    = "ProjectNode_unit_" .. nSrcCardIndex
    local projectNodeCard           = nodeTeanUnit:getChildByName(projectNodeSrcUnitName)
    local projectNodeFire           = projectNodeCard:getChildByName("ProjectNode_Fire_2")
    local firePosition              = projectNodeFire:convertToWorldSpace(cc.p(0, 0))
    local firePositionX             = firePosition.x
    local firePositionY             = firePosition.y
    
    local bIsRightTeam              = tDstCard.bLeftSide
    local nDstCardIndex             = tDstCard.nIndex
    local nodeTargetTeamName        = "Node_ally_unit"
    if not bIsRightTeam then nodeTargetTeamName = "Node_enemy_unit" end
    local nodeTargetTeamUnit        = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeDstUnitName    = "ProjectNode_unit_" .. nDstCardIndex
    local projectNodeTargetCard     = nodeTargetTeamUnit:getChildByName(projectNodeDstUnitName)
    local projectNodeTargetFire     = projectNodeTargetCard:getChildByName("Node_shells_falling")
    local bLastPosition             = projectNodeTargetFire:convertToWorldSpace(cc.p(0, 0))
    local bLastPositionX            = bLastPosition.x
    local bLastPositionY            = bLastPosition.y
    
    local projectNodeBullet         = cc.CSLoader:createNode("res/ui/animation_node/ani_feidan_tilted.csb")
    local actionProjectNodeBullet   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_feidan_tilted.csb")
    projectNodeBullet:stopAllActions()
    projectNodeBullet:runAction(actionProjectNodeBullet)
    local visibleSize               = cc.Director:getInstance():getVisibleSize()
    local flyVisibleSizeX           = visibleSize.width  * scaleFlyVisibleSize
    local StartVisibleSizeX         = visibleSize.width  * scaleStartVisibleSize 
    local visibleSizeY              = visibleSize.height + offsetBulletVisibleY 
    
    mainNode:addChild(projectNodeBullet, 100)
    projectNodeBullet:setPosition(cc.p(firePositionX, firePositionY))
    
    print("----------> playBulletAnimation Info:", firePositionX, firePositionY)
    print("----------> playBulletAnimation Info:", bLastPositionX, bLastPositionY)
    print("----------> playBulletAnimation Info:", bIsLeftTeam, bIsRightTeam, nSrcCardIndex, nDstCardIndex)
    
    local bulletFlyTime         = 2.0 
    local bulletStartAndUpTime  = 0.2
    local bulletEndAndDownTime  = 0.2
    local bulletAllTime         = bulletFlyTime + bulletStartAndUpTime + bulletEndAndDownTime 
    
    actionProjectNodeBullet:gotoFrameAndPlay(0, frameBulletUp, true) 
    if not bIsLeftTeam then projectNodeBullet:setRotation(setRotationTitedUpDegree) end
    if bIsRightTeam then
        local actionBulletSequence  = cc.Sequence:create(
            cc.MoveTo:create(bulletStartAndUpTime, cc.p(StartVisibleSizeX, visibleSizeY)),
            cc.MoveTo:create(bulletFlyTime, cc.p(flyVisibleSizeX, visibleSizeY)),
            cc.CallFunc:create(
                function()
                    projectNodeBullet:setRotation(setRotationTitedDownDegree)
                    actionProjectNodeBullet:gotoFrameAndPlay(frameBulletDown, frameBulletEnd, true) 
                end
            ),
            cc.MoveTo:create(bulletEndAndDownTime, cc.p(bLastPositionX, bLastPositionY))
        )
        projectNodeBullet:runAction(actionBulletSequence)
    else
        local actionBulletSequence  = cc.Sequence:create(
            cc.MoveTo:create(bulletStartAndUpTime, cc.p(flyVisibleSizeX, visibleSizeY)),
            cc.MoveTo:create(bulletFlyTime, cc.p(StartVisibleSizeX, visibleSizeY)),
            cc.CallFunc:create(
                function()
                    actionProjectNodeBullet:gotoFrameAndPlay(frameBulletDown, frameBulletEnd, true) 
                end
            ),
            cc.MoveTo:create(bulletEndAndDownTime, cc.p(bLastPositionX, bLastPositionY))
        )
        projectNodeBullet:runAction(actionBulletSequence)
    end
    
    delayExecute(
        tBattleUI,
        function()
            projectNodeBullet:removeFromParent()
            fnCallback()
        end,
        bulletAllTime
    )
end

function KBattleUIHelper.playBulletFireAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard, tDstCard)
    print("-----> Call playBulletFireAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)
    local setRotationDegree         = 180

    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tSrcCard.bLeftSide
    local nSrcCardIndex             = tSrcCard.nIndex
    local actionName                = "_actionLeftTeam"
    local nodeCardTeamName          = "Node_ally_unit"
    if not bIsLeftTeam then 
        actionName                  = "_actionRightTeam"
        nodeCardTeamName            = "Node_enemy_unit"
    end

    local nodeTeamUnit      = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeCard   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. nSrcCardIndex)
    local panelUnit         = projectNodeCard:getChildByName("Panel_unit")
    local projectNodeFire   = panelUnit:getChildByName("ProjectNode_Fire_1")
    local firePosition      = projectNodeFire:convertToWorldSpace(cc.p(0, 0))
    local firePositionX     = firePosition.x
    local firePositionY     = firePosition.y

    local bIsRightTeam          = tDstCard.bLeftSide
    local nDstCardIndex         = tDstCard.nIndex
    local nodeTargetTeamName    = "Node_ally_unit"
    if not bIsRightTeam then nodeTargetTeamName = "Node_enemy_unit" end
    local nodeTargetTeamUnit    = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeTargetCard = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. nDstCardIndex)
    local panelUnit             = projectNodeTargetCard:getChildByName("Panel_unit")
    -- local projectNodeTargetFire = panelUnit:getChildByName("ProjectNode_Fire_1")
    local projectNodeTargetFire = projectNodeTargetCard:getChildByName("Node_shells_falling")
    local blastPosition         = projectNodeTargetFire:convertToWorldSpace(cc.p(0, 0))
    local blastPositionX        = blastPosition.x
    local blastPositionY        = blastPosition.y

    local projectNodeBullet = cc.CSLoader:createNode("res/ui/animation_node/ani_feidan_horizon.csb")

    mainNode:addChild(projectNodeBullet, 100)
    projectNodeBullet:setPosition(cc.p(firePositionX, firePositionY))

    local bulletRotation = -1 * math.deg(math.atan((blastPositionY - firePositionY) / (blastPositionX - firePositionX)))
    projectNodeBullet:setRotation(bulletRotation)

    if not bIsLeftTeam then projectNodeBullet:setRotation(setRotationDegree + bulletRotation) end

    print("----------> playBulletAnimation Info:", firePositionX, firePositionY)
    print("----------> playBulletAnimation Info:", blastPositionX, blastPositionY)
    print("----------> playBulletAnimation Info:", bIsLeftTeam, bIsRightTeam, nSrcCardIndex, nDstCardIndex)
    local bulletFlyTime = 0.1
    local actionBulletSequence = cc.Sequence:create(
        cc.MoveTo:create(bulletFlyTime, cc.p(blastPositionX, blastPositionY)),
        cc.CallFunc:create(
            function() 
                print("----------> bullet clear after", bulletFlyTime)
                --projectNodeBullet:removeFromParent()
                --fnCallback() 
            end
        )
    )
    projectNodeBullet:runAction(actionBulletSequence)

    --attackWhiteFlash(tBattleUI, false, tSrcCard)

    delayExecute(
        tBattleUI,
        function ()
            projectNodeBullet:removeFromParent()
            fnCallback()
        end,
        bulletFlyTime
    )

    -- KSound.playEffect("howitzer")
end

function KBattleUIHelper.playArtilleryStrikeBulletAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playArtilleryStrikeBulletAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)

    local mainNode      = tBattleUI._mainLayout
    local bIsLeftTeam   = tDstCard.bLeftSide
    local nCardIndex    = tDstCard.nIndex
    
    local actionName    = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    
    local explosionAction   = tBattleUI[actionName][nCardIndex].actionExplosion
    local actionDuration    = explosionAction:getDuration()
    safePlayAnimation(tBattleUI, explosionAction, 0, actionDuration, false, "playArtilleryStrikeBulletAnimation")
    
    fnCallback()
end

function KBattleUIHelper.playComboBulletFireAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard, tDstCard)
    print("-----> Call playComboBulletFireAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)
    local setRotationDegree     = 180
    local mainNode              = tBattleUI._mainLayout
    local bIsLeftTeam           = tSrcCard.bLeftSide
    local nSrcCardIndex         = tSrcCard.nIndex
    local actionName            = "_actionLeftTeam"
    if not bIsLeftTeam  then actionName = "_actionRightTeam" end
    local nodeCardTeamName      = "Node_ally_unit"
    if not bIsLeftTeam then nodeCardTeamName = "Node_enemy_unit" end

    local nodeTeamUnit          = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeCard       = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. nSrcCardIndex)
    local panelUnit             = projectNodeCard:getChildByName("Panel_unit")
    local projectNodeFire       = panelUnit:getChildByName("ProjectNode_Fire_1")
    local firePosition          = projectNodeFire:convertToWorldSpace(cc.p(0, 0))
    local firePositionX         = firePosition.x
    local firePositionY         = firePosition.y

    local bIsRightTeam          = tDstCard.bLeftSide
    local nDstCardIndex         = tDstCard.nIndex
    local nodeTargetTeamName    = "Node_ally_unit"
    if not bIsRightTeam then nodeTargetTeamName = "Node_enemy_unit" end
    local nodeTargetTeamUnit    = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeTargetCard = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. nDstCardIndex)
    local panelTargetUnit       = projectNodeTargetCard:getChildByName("Panel_unit")
    -- local projectNodeTargetFire = panelUnit:getChildByName("ProjectNode_Fire_1")
    local projectNodeTargetFire = projectNodeTargetCard:getChildByName("Node_shells_falling")
    local bLastPosition         = projectNodeTargetFire:convertToWorldSpace(cc.p(0, 0))
    local bLastPositionX        = bLastPosition.x
    local bLastPositionY        = bLastPosition.y

    local projectNodeBullet     = cc.CSLoader:createNode("res/ui/animation_node/ani_feidan_horizon.csb")

    mainNode:addChild(projectNodeBullet, 100)
    projectNodeBullet:setPosition(cc.p(firePositionX, firePositionY))

    local bulletRotation = -1 * math.deg(math.atan((bLastPositionY - firePositionY) / (bLastPositionX - firePositionX)))
    projectNodeBullet:setRotation(bulletRotation)
    if not bIsLeftTeam then projectNodeBullet:setRotation(setRotationDegree + bulletRotation) end

    print("----------> playBulletAnimation Info:", firePositionX, firePositionY)
    print("----------> playBulletAnimation Info:", bLastPositionX, bLastPositionY)
    print("----------> playBulletAnimation Info:", bIsLeftTeam, bIsRightTeam, nSrcCardIndex, nDstCardIndex)
    local bulletFlyTime = 0.2 
    local actionBulletSequence = cc.Sequence:create(
        cc.MoveTo:create(bulletFlyTime, cc.p(bLastPositionX, bLastPositionY)),
        cc.CallFunc:create(
            function() 
                print("----------> bullet clear after", bulletFlyTime)
                --projectNodeBullet:removeFromParent()
                --fnCallback() 
            end
        )
    )
    projectNodeBullet:runAction(actionBulletSequence)

    --attackWhiteFlash(tBattleUI, false, tSrcCard)
    
    delayExecute(
        tBattleUI,
        function ()
            projectNodeBullet:removeFromParent()
            fnCallback()
        end,
        bulletFlyTime
    )
end

function KBattleUIHelper.playBulletBlastAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playBulletBlastAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex

    local actionName = "_actionLeftTeam" 
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local normalHurtAction = tBattleUI[actionName][nCardIndex].actionNormalHurt
    local actionDuration = normalHurtAction:getDuration()
    safePlayAnimation(tBattleUI, normalHurtAction, 0, actionDuration, false, "playBulletBlastAnimation")

    fnCallback()

    -- KSound.playEffect("boom")
end

function KBattleUIHelper.playComboBulletBlastLeftAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playComboBulletBlastAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local leftHurtAction            = tBattleUI[actionName][nCardIndex].actionLeftHurt
    local leftHurtActionDuration    = leftHurtAction:getDuration()
    safePlayAnimation(tBattleUI, leftHurtAction, 0, leftHurtActionDuration, false, "playComboBulletBlastLeftAnimation")

    local actionTime = 0.4  -- tangyu need
    delayExecute(
        tBattleUI,
        function ()
            fnCallback()
        end,
        actionTime
    )
end

function KBattleUIHelper.playComboBulletBlastRightAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playComboBulletBlastAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local rightHurtAction           = tBattleUI[actionName][nCardIndex].actionRightHurt
    local rightHurtActionDuration   = rightHurtAction:getDuration()
    safePlayAnimation(tBattleUI, rightHurtAction, 0, rightHurtActionDuration, false, "playComboBulletBlastRightAnimation")

    local actionTime = 0.4  -- tangyu neeed
    delayExecute(
        tBattleUI,
        function ()
            fnCallback()
        end,
        actionTime
    )
end

function KBattleUIHelper.playComboBulletBlastMiddleAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playComboBulletBlastAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local middleHurtAction = tBattleUI[actionName][nCardIndex].actionMiddleHurt
    local middleHurtActionDuration = middleHurtAction:getDuration()
    safePlayAnimation(tBattleUI, middleHurtAction, 0, middleHurtActionDuration, false, "playComboBulletBlastMiddleAnimation")

    local actionTime = middleHurtActionDuration / FRAME_PER_SECOND
    delayExecute(
        tBattleUI,
        function ()
            fnCallback()
        end,
        actionTime
    )
end

function KBattleUIHelper.playCostHPAnimation(fnCallback, tBattleData, tBattleUI, tCard, nOldHP, nCurrentHP)
    print("-----> Call playCostHPAnimation~", nCurrentHP)
    if damage < 0 then fnCallback() return end
    
    local bIsLeftTeam               = tCard.bLeftSide
    local nCardIndex                = tCard.nIndex
    local actionName = "_actionLeftTeam"    
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nodeTeamName= "Node_ally_unit"
    if not bIsLeftTeam then nodeTeamName = "Node_enemy_unit" end

    local mainNode          = tBattleUI._mainLayout
    local nodeTeamUnit      = mainNode:getChildByName(nodeTeamName)
    local projectNodeCard   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. nCardIndex)
    
    local projectNodeDamage     = projectNodeCard:getChildByName("ProjectNode_normal")
    local projectNodeDamagePosition = projectNodeDamage:convertToWorldSpace(cc.p(0, 0))

    local panelUnitBase     = projectNodeCard:getChildByName("Panel_unit")
    local imageBloodBase    = panelUnitBase:getChildByName("Image_unit_blood")

    local nNewHPPercent     = math.ceil(nCurrentHP / tCard.nMaxHP * 100)
    local nOldHPPercent     = math.ceil(nOldHP / tCard.nMaxHP * 100)
    
    local textHPNumber      = panelUnitBase:getChildByName("Text_hp_numerical")
    textHPNumber:setString(nCurrentHP .. "/" .. tCard.nMaxHP)
    if bIsLeftTeam then
        KUtil.playBrokenTalk(tCard.nTemplateID, nNewHPPercent/100, nOldHPPercent/100, tCard.bIsRole)
    end

    --change head
    local imageHead = panelUnitBase:getChildByName("ProjectNode_card")
    local tHeadInfo     = {["nID"] = tCard.nID, ["nTemplateID"] = tCard.nTemplateID, ["nSkinTemplateID"] = tCard.nSkinTemplateID, 
                            ["nCurrentHP"] = nCurrentHP, ["bRing"] = tCard.bRing, ["nMaxHP"] = tCard.nMaxHP}
    if bIsLeftTeam then KUtil.onlyUpdateCardHeadBase(imageHead, tHeadInfo) end

    -- update card state
    local nodeCardState  = panelUnitBase:getChildByName("Node_damage")
    
    local hpName    = {"unit_blood_1", "unit_blood_2", "unit_blood_3", "unit_blood_4", nil}
    local stateName = {nil, "Image_damage_light", "Image_damage_middle", "Image_damage_heavy", "Image_damage_broken"}
    KUtil.drawCardState(nil, nodeCardState, hpName, stateName, nNewHPPercent)
    
    --update blood 
    local nTotalTimes = 0.8
    local nCostTimes  = nOldHPPercent - nNewHPPercent
    local nCostHPRate = 0
    if nCostTimes > 0 then
        nCostHPRate = nTotalTimes / nCostTimes
    end

    local function updateHPPercent()
        nOldHPPercent = nOldHPPercent - 1
        KUtil.drawCardState(imageBloodBase, nil, hpName, stateName, nOldHPPercent)
    end 

    local costHPSequence    = cc.Sequence:create(
        cc.CallFunc:create(updateHPPercent),
        cc.DelayTime:create(nCostHPRate)
    )
    
    local repeatAction = cc.Sequence:create(
        cc.Repeat:create(costHPSequence, nCostTimes),
        cc.CallFunc:create(
            function()
                local nCurrentHPPercent = math.ceil(tCard.nCurrentHP / tCard.nMaxHP * 100)
                KUtil.drawCardState(imageBloodBase, nil, hpName, stateName, nCurrentHPPercent)
            end
        )
    )
    
    local delayTime = nTotalTimes
   
    --shark
    local panelMember = panelUnitBase:getChildByName("Panel_member")
    local startFrame = 140
    local endFrame   = 170
    local playFrameTime = (endFrame - startFrame) / FRAME_PER_SECOND

    local actionShark  = cc.Sequence:create(
        cc.CallFunc:create(
            function()
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(startFrame, endFrame, false)
                panelMember:setVisible(true)
            end
        ),
        cc.DelayTime:create(playFrameTime),
        cc.CallFunc:create(
            function()
                panelMember:setVisible(false)
                tBattleUI[actionName][nCardIndex].actionCard:pause()
            end
        )        
    )
    if delayTime < playFrameTime then delayTime = playFrameTime end
 
    local spawnAction = cc.Spawn:create(repeatAction, actionShark)
    tBattleUI:runAction(spawnAction)
    delayExecute(tBattleUI, 
        function()
            if nCurrentHP <= 0 then
                local panelMember       = panelUnitBase:getChildByName("Panel_member")
                local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
                local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
                local imageMemberRed    = panelMember:getChildByName("Image_member_red")
                local projectNodeExclamation = panelUnitBase:getChildByName("ProjectNode_exclamation")
                panelMember:setVisible(true)
                imageMemberShadow:setVisible(true)
                imageMemberBounce:setVisible(false)
                imageMemberRed:setVisible(false)
                projectNodeExclamation:setVisible(false)
            end
            fnCallback() 
        end, 
        delayTime)
end

function KBattleUIHelper.playHurtAnimation(fnCallback, tBattleData, tBattleUI, tTargetCard, nType, nDamage)
    print("-----> Call playHurtAnimation~", tTargetCard.bLeftSide, tTargetCard.nIndex, nType, nDamage)
    local bIsLeftTeam               = tTargetCard.bLeftSide
    local nCardIndex                = tTargetCard.nIndex
    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    local nodeTargetTeamName= "Node_ally_unit"
    if not bIsLeftTeam then nodeTargetTeamName = "Node_enemy_unit" end

    --print("*****> playHurtAnimation", bIsLeftTeam, nCardIndex, actionName, nodeTargetTeamName)
    local mainNode           = tBattleUI._mainLayout
    local nodeTargetTeamUnit = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeTargetCard = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. nCardIndex)
    local projectNodeDamage     = projectNodeTargetCard:getChildByName("ProjectNode_normal")
    local projectNodeDamagePosition = projectNodeDamage:convertToWorldSpace(cc.p(0, 0))

    local panelUnitBase     = projectNodeTargetCard:getChildByName("Panel_unit")
    local imageBloodBase    = panelUnitBase:getChildByName("Image_unit_blood")

    local projectNodeHurt   = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_float_word_v2.csb")
    local actionHurt        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_float_word_v2.csb")
    projectNodeHurt:setPosition(cc.p(projectNodeDamagePosition.x, projectNodeDamagePosition.y))
    mainNode:addChild(projectNodeHurt, 100)
    projectNodeHurt:stopAllActions()
    local panelWordValue    = projectNodeHurt:getChildByName("Panel_word_value")
    panelWordValue:setVisible(false)
    local panelWordMiss     = projectNodeHurt:getChildByName("Panel_word_miss")
    panelWordMiss:setVisible(false)
    local panelWordCrit     = projectNodeHurt:getChildByName("Panel_word_crit")
    panelWordCrit:setVisible(false)
    local panelWordRicochet = projectNodeHurt:getChildByName("Panel_word_ricochet")
    panelWordRicochet:setVisible(false)
    local panelWordGraze = projectNodeHurt:getChildByName("Panel_word_graze")
    panelWordGraze:setVisible(false)

    local damageValue = tostring(nDamage)

    local tProcessor =
    {
        [ATTACK_RESULT.MISS] = function() 
            panelWordMiss:setVisible(true)
        end,
        
        [ATTACK_RESULT.CRIT] = function()
            local panelFloatWorldLeftCrit   = panelWordCrit:getChildByName("Panel_word_crit_1")
            local panelFloatWorldRightCrit  = panelWordCrit:getChildByName("Panel_word_crit_2")
            local textAttackCritLeft        = panelFloatWorldLeftCrit:getChildByName("BitmapFontLabel_word_crit")
            textAttackCritLeft:setString(damageValue)
            local textAttackCritRight       = panelFloatWorldRightCrit:getChildByName("BitmapFontLabel_word_crit")
            textAttackCritRight:setString(damageValue)
            panelWordCrit:setVisible(true)
        end,
        
        [ATTACK_RESULT.NORMAL] = function()
            local panelFloatWorldLeftValue   = panelWordValue:getChildByName("Panel_float_word_1")
            local panelFloatWorldRightValue  = panelWordValue:getChildByName("Panel_float_word_2")
            local textAttackValueLeft        = panelFloatWorldLeftValue:getChildByName("Text_attack_value")
            textAttackValueLeft:setString(damageValue)
            local textAttackValueRight       = panelFloatWorldRightValue:getChildByName("Text_attack_value")
            textAttackValueRight:setString(damageValue)
            panelWordValue:setVisible(true)
        end,
        
        [ATTACK_RESULT.RICOCHET] = function()
            local panelFloatWorldLeftRicochet   = panelWordRicochet:getChildByName("Panel_word_ricochet_1")
            local panelFloatWorldRightRicochet  = panelWordRicochet:getChildByName("Panel_word_ricochet_2")
            local textAttackRicochetLeft        = panelFloatWorldLeftRicochet:getChildByName("BitmapFontLabel_word_ricochet")
            textAttackRicochetLeft:setString(damageValue)
            local textAttackRicochetRight       = panelFloatWorldRightRicochet:getChildByName("BitmapFontLabel_word_ricochet")
            textAttackRicochetRight:setString(damageValue)

            local ricochetAction = tBattleUI[actionName][nCardIndex].actionRicochet
            local ricochetActionDuration = ricochetAction:getDuration()
            safePlayAnimation(tBattleUI, ricochetAction, 0, ricochetActionDuration, false, "playHurtAnimation")
            panelWordRicochet:setVisible(true)
        end,

        [ATTACK_RESULT.GRAZE] = function()
            local panelFloatWorldLeftGraze   = panelWordGraze:getChildByName("Panel_word_graze_1")
            local panelFloatWorldRightGraze  = panelWordGraze:getChildByName("Panel_word_graze_2")
            local textAttackGrazeLeft        = panelFloatWorldLeftGraze:getChildByName("BitmapFontLabel_word_graze")
            textAttackGrazeLeft:setString(damageValue)
            local textAttackGrazeRight       = panelFloatWorldRightGraze:getChildByName("BitmapFontLabel_word_graze")
            textAttackGrazeRight:setString(damageValue)

            local grazeSparkAction = tBattleUI[actionName][nCardIndex].actionGrazeSpark
            grazeSparkActionDuration = grazeSparkAction:getDuration()
            safePlayAnimation(tBattleUI, grazeSparkAction, 0, grazeSparkActionDuration, false, "playHurtAnimation")
            panelWordGraze:setVisible(true)
        end,
    }

    tProcessor[nType]()
    
    projectNodeHurt:runAction(actionHurt)
    actionHurt:gotoFrameAndPlay(0, actionHurt:getDuration(), false)
    local nActionTime = actionHurt:getDuration() / FRAME_PER_SECOND
    delayExecute(
        tBattleUI,
        function ()

            projectNodeHurt:removeFromParent()
            fnCallback()
        end,
        nActionTime
    )
end

function KBattleUIHelper.playBrokenAnimation(fnCallback, tBattleData, tBattleUI, tDstCard, backgroundType, isNight, cardState)
    print("-----> Call playBrokenAnimation~")
    local mainNode                  = tBattleUI._mainLayout
    local characterHeavyHurtPanel   = mainNode:getChildByName("ProjectNode_destruction")
    local destructionStartFrame     = 0
    local destructionEndFrame       = 160 
    
    local imageBackGround           = characterHeavyHurtPanel:getChildByName("Image_bg")
    local imagePath                 = KUtil.getBattleBackgroundImagePath(backgroundType, isNight)
    imageBackGround:loadTexture(imagePath)

    local panel                     = characterHeavyHurtPanel:getChildByName("Panel_1")
    local nodeBigDestruction        = panel:getChildByName("Panel_big_destruction")
    local nodeMediumDestruction     = panel:getChildByName("Panel_medium_destruction")
    nodeMediumDestruction:setVisible(cardState == CARD_BROKEN_STATE.MIDDLE)
    nodeBigDestruction:setVisible(cardState == CARD_BROKEN_STATE.BIG)

    local imageCharacter            = panel:getChildByName("Image_chara")

    local cardID                    = tDstCard.nTemplateID
    local cardImagePath
    if tDstCard.bIsRole then
        cardImagePath               = KUtil.getCardImagePathByConfigID(cardID, true, tDstCard.nSkinTemplateID)
    else
        cardImagePath               = KUtil.getMonsterImagePathByConfigID(cardID, false, tDstCard.nCurrentHP)
    end
    imageCharacter:loadTexture(cardImagePath)

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionCharacterHeavyHurt", false, false, destructionStartFrame, destructionEndFrame)
end

function KBattleUIHelper.playAskIfNightFightAnimation(fnCallback, tBattleData, tBattleUI, isGuide)
    print("-----> Call playAskIfNightFightAnimation~")
    local mainNode = tBattleUI._mainLayout
    local projectNodeNightFight         = mainNode:getChildByName("ProjectNode_night_battle")

    local function fnChooseCallback(enterNightFight)
        tBattleData:setIfChooseNightFight(enterNightFight)
        fnCallback()
    end
    tBattleUI:setNightBattleCallBack(fnChooseCallback)

    local nOpenGateStartFrame   = 0
    local nOpenGateEndFrame     = 25
    local isVisible = true
    if isGuide then
        isVisible = false
    end
    playAnimationAndCallback(function() tBattleUI:changeNightBattleMenuVisible(isVisible) end, tBattleUI, "_actionNodeGate", false, true, nOpenGateStartFrame, nOpenGateEndFrame)
end

--night fight
function KBattleUIHelper.playNightCardRoleAttackAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playNightCardRoleAttackAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local nodeAttack                = mainNode:getChildByName("Node_cross")
    local projectNodeLeftAttack     = nodeAttack:getChildByName("ProjectNode_cross_ally")
    local projectNodeRightAttack    = nodeAttack:getChildByName("ProjectNode_cross_enemy")

    local projectNodeTarget         = projectNodeLeftAttack
    if not tAttackCard.bLeftSide then 
        projectNodeTarget = projectNodeRightAttack
    end

    local cardImagePath         = nil
    local cardImageLightPath    = nil
    local infoName              = "cardInfo"
    if not tAttackCard.bIsRole then
        infoName = "monster"
        cardImagePath       = KUtil.getMonsterImagePath(tAttackCard, false)
        cardImageLightPath  = KUtil.getMonsterImageLightPath(tAttackCard)
    else
        cardImagePath       = KUtil.getCardImagePath(tAttackCard, false)
        cardImageLightPath  = KUtil.getCardImageLightPath(tAttackCard) 
    end

    local tCardTemplateInfo     = KConfig:getLine(infoName, tAttackCard.nTemplateID)

    local panelCross                = projectNodeTarget:getChildByName("Panel_bule_cross")
    local ALL_POP_STATE_NUM         = 4
    local panelStateBaseCurrentNum  = math.random(1, ALL_POP_STATE_NUM)
    for i = 1, ALL_POP_STATE_NUM do
        local panelStateBase    = panelCross:getChildByName("Panel_state_base_0" .. i)
        panelStateBase:setVisible(i == panelStateBaseCurrentNum)
    end

    local panelStateBase         = panelCross:getChildByName("Panel_state_base_0" .. panelStateBaseCurrentNum)

    local imageChara        = panelStateBase:getChildByName("Image_chara")    
    imageChara:loadTexture(cardImagePath)

    local imageCharaLight   = panelStateBase:getChildByName("Image_chara_light")
    imageCharaLight:loadTexture(cardImageLightPath)

    local panelStateBaseInfo = panelStateBase:getChildByName("Panel_state_base")  

    local textTankName       = panelStateBaseInfo:getChildByName("Text_tank_name")
    textTankName:setString(tCardTemplateInfo.szName)

    local textTankHP         = panelStateBaseInfo:getChildByName("Text_tank_hp")
    textTankHP:setString(tAttackCard.nCurrentHP .. "/" .. tAttackCard.nMaxHP)

    local loadingBarTankHP   = panelStateBaseInfo:getChildByName("LoadingBar_tank_hp")    
    local nTankHPPercent     = tAttackCard.nCurrentHP / tAttackCard.nMaxHP * 100
        loadingBarTankHP:setPercent(nTankHPPercent)

    local actionName = "_actionLeftAttack"
    if not tAttackCard.bLeftSide then actionName = "_actionRightAttack" end
    playAnimationAndCallback(fnCallback, tBattleUI, actionName, false, false)
    if tAttackCard.bLeftSide then
        KSound.playTalk(KSound.TALK.NIGHTATTACK, tAttackCard.nTemplateID, not tAttackCard.bIsRole)
    end
end

function KBattleUIHelper.playNightCardAttackFireAnimation(fnCallback, tBattleData, tBattleUI, tAttackCard)
    print("-----> Call playNightCardAttackFireAnimation~", tAttackCard.bLeftSide, tAttackCard.nIndex)
    local mainNode              = tBattleUI._mainLayout
    local bIsLeftTeam           = tAttackCard.bLeftSide
    local nCardIndex            = tAttackCard.nIndex
    
    local nodeCardTeamName      = "Node_ally_unit"
    if not bIsLeftTeam then nodeCardTeamName = "Node_enemy_unit" end
    
    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    
    local fireAction            = tBattleUI[actionName][nCardIndex].actionNormalFire
    local fireActionDuration    = fireAction:getDuration()
    safePlayAnimation(tBattleUI, fireAction, 0, fireActionDuration, false, "playNightCardAttackFireAnimation")
    
    local attackDelay   = fireActionDuration / FRAME_PER_SECOND
    delayExecute(
        tBattleUI,
        function ()
            fnCallback()
        end,
        attackDelay
    )
    -- KSound.playEffect("fire")
end

function KBattleUIHelper.playNightCardBeAttackedAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playNightCardAttackEndAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex
    local nodeCardTeamName          = "Node_ally_unit"
    if not bIsLeftTeam then nodeCardTeamName = "Node_enemy_unit" end
    local nodeCardTeamUnit          = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeDstUnitName    = "ProjectNode_unit_" .. nCardIndex
    local projectNodeDstUnit        = nodeCardTeamUnit:getChildByName(projectNodeDstUnitName)
    local panelUnit                 = projectNodeDstUnit:getChildByName("Panel_unit")
    local panelMember               = panelUnit:getChildByName("Panel_member")

    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nReadyAttackEndFrame      = 140
    local nBackPositionFrame        = 170

    local attackDelay               = (nBackPositionFrame - nReadyAttackEndFrame) / FRAME_PER_SECOND
    tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(nReadyAttackEndFrame, nBackPositionFrame, false)
    panelMember:setVisible(true)
    delayExecute(
        tBattleUI,
        function ()
            panelMember:setVisible(false)
            fnCallback()
        end,
        attackDelay
    )
    -- KSound.playEffect("fire")
end

function KBattleUIHelper.playNightBulletFireAnimation(fnCallback, tBattleData, tBattleUI, tSrcCard, tDstCard)
    print("-----> Call playNightBulletFireAnimation~", tSrcCard.bLeftSide, tSrcCard.nIndex)
    local setRotationDegree         = 180
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tSrcCard.bLeftSide
    local nSrcCardIndex             = tSrcCard.nIndex
    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    local nodeCardTeamName          = "Node_ally_unit"
    if not bIsLeftTeam then nodeCardTeamName = "Node_enemy_unit" end

    local nodeTeamUnit      = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeCard   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. nSrcCardIndex)
    local panelUnit         = projectNodeCard:getChildByName("Panel_unit")
    local projectNodeFire   = panelUnit:getChildByName("ProjectNode_Fire_1")
    local firePosition      = projectNodeFire:convertToWorldSpace(cc.p(0, 0))
    local firePositionX     = firePosition.x
    local firePositionY     = firePosition.y

    local bIsRightTeam      = tDstCard.bLeftSide
    local nDstCardIndex     = tDstCard.nIndex
    local nodeTargetTeamName= "Node_ally_unit"
    if not bIsRightTeam then nodeTargetTeamName = "Node_enemy_unit" end
    local nodeTargetTeamUnit = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeTargetCard = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. nDstCardIndex)
    local panelTargetUnit       = projectNodeTargetCard:getChildByName("Panel_unit")
    -- local projectNodeTargetFire = panelUnit:getChildByName("ProjectNode_Fire_1")
    local projectNodeTargetFire = projectNodeTargetCard:getChildByName("Node_shells_falling")
    local blastPosition     = projectNodeTargetFire:convertToWorldSpace(cc.p(0, 0))
    local blastPositionX    = blastPosition.x
    local blastPositionY    = blastPosition.y

    local projectNodeBullet = cc.CSLoader:createNode("res/ui/animation_node/ani_feidan_horizon.csb")

    mainNode:addChild(projectNodeBullet, 100)
    projectNodeBullet:setPosition(cc.p(firePositionX, firePositionY))

    local bulletRotation = -1 * math.deg(math.atan((blastPositionY - firePositionY) / (blastPositionX - firePositionX)))
    projectNodeBullet:setRotation(bulletRotation)
    if not bIsLeftTeam then projectNodeBullet:setRotation(setRotationDegree + bulletRotation) end

    print("----------> playNightBulletFireAnimation Info:", firePositionX, firePositionY)
    print("----------> playNightBulletFireAnimation Info:", blastPositionX, blastPositionY)
    print("----------> playNightBulletFireAnimation Info:", bIsLeftTeam, bIsRightTeam, nSrcCardIndex, nDstCardIndex)
    local bulletFlyTime = 0.1
    local actionBulletSequence = cc.Sequence:create(
        cc.MoveTo:create(bulletFlyTime, cc.p(blastPositionX, blastPositionY)),
        cc.CallFunc:create(
            function() 
                print("----------> bullet clear after", bulletFlyTime)
                --projectNodeBullet:removeFromParent()
                --fnCallback() 
            end
        )
    )
    projectNodeBullet:runAction(actionBulletSequence)

    delayExecute(
        tBattleUI,
        function ()
            projectNodeBullet:removeFromParent()
            fnCallback()
        end,
        bulletFlyTime
    )
    -- KSound.playEffect("howitzer")
end

function KBattleUIHelper.playNightCostHPAnimation(fnCallback, tBattleData, tBattleUI, tCard, nOldHP, nCurrentHP)
    print("-----> Call playCostHPAnimation~", nCurrentHP)
    if damage < 0 then fnCallback() return end

    local bIsLeftTeam               = tCard.bLeftSide
    local nCardIndex                = tCard.nIndex
    local actionName = "_actionLeftTeam"    
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local nodeTeamName= "Node_ally_unit"
    if not bIsLeftTeam then nodeTeamName = "Node_enemy_unit" end

    local mainNode          = tBattleUI._mainLayout
    local nodeTeamUnit      = mainNode:getChildByName(nodeTeamName)
    local projectNodeCard   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. nCardIndex)

    local projectNodeDamage     = projectNodeCard:getChildByName("ProjectNode_normal")
    local projectNodeDamagePosition = projectNodeDamage:convertToWorldSpace(cc.p(0, 0))

    local panelUnitBase     = projectNodeCard:getChildByName("Panel_unit")
    local imageBloodBase    = panelUnitBase:getChildByName("Image_unit_blood")

    local nNewHPPercent     = math.ceil(nCurrentHP / tCard.nMaxHP * 100)
    local nOldHPPercent     = math.ceil(nOldHP / tCard.nMaxHP * 100)

    local textHPNumber      = panelUnitBase:getChildByName("Text_hp_numerical")
    textHPNumber:setString(nCurrentHP .. "/" .. tCard.nMaxHP)
    if bIsLeftTeam then
        KUtil.playBrokenTalk(tCard.nTemplateID, nNewHPPercent/100, nOldHPPercent/100, tCard.bIsRole)
    end
    --change head
    local imageHead = panelUnitBase:getChildByName("ProjectNode_card")
    local tHeadInfo     = {["nID"] = tCard.nID, ["nTemplateID"] = tCard.nTemplateID, ["nSkinTemplateID"] = tCard.nSkinTemplateID,
                            ["nCurrentHP"] = nCurrentHP, ["bRing"] = tCard.bRing, ["nMaxHP"] = tCard.nMaxHP}
    if bIsLeftTeam then KUtil.onlyUpdateCardHeadBase(imageHead, tHeadInfo) end

    -- update card state
    local nodeCardState  = panelUnitBase:getChildByName("Node_damage")
    local tCardStateInfo = {
        {"Image_damage_light",  50, 75 },
        {"Image_damage_middle", 25, 50 },
        {"Image_damage_heavy",  0,  25 },
        {"Image_damage_broken", -1, 0  }
    }

    for _, var in ipairs(tCardStateInfo) do        
        local imageStateHurt = nodeCardState:getChildByName(var[1])
        local bIsVisible     = false

        if nNewHPPercent > var[2] and nNewHPPercent <= var[3] then bIsVisible = true end
        imageStateHurt:setVisible(bIsVisible)
    end 

    local tHPTemplateInfo   = {
        ["unit_blood_1"] = {75, 100},
        ["unit_blood_2"] = {50, 75},
        ["unit_blood_3"] = {25, 50},
        ["unit_blood_4"] = {-1, 25}
    }

    --update blood 
    local nTotalTimes = 0.8
    local nCostTimes  = nOldHPPercent - nNewHPPercent
    local nCostHPRate     = nTotalTimes / nCostTimes
    if nCostTimes <= 0 then nCostTimes = 0 end
    local function updateHPPercent()
        local useLoadingBar = nil
        for k, v in pairs(tHPTemplateInfo) do
            local loadingBarHP = imageBloodBase:getChildByName(k)        
            local bIsVisible = false

            if nOldHPPercent > v[1] and nOldHPPercent <= v[2] then bIsVisible = true useLoadingBar = loadingBarHP end
            loadingBarHP:setVisible(bIsVisible)
        end

        nOldHPPercent = nOldHPPercent - 1
        useLoadingBar:setPercent(nOldHPPercent)
    end 

    local costHPSequence    = cc.Sequence:create(
        cc.CallFunc:create(updateHPPercent),
        cc.DelayTime:create(nCostHPRate)
    )
    local repeatAction = cc.Repeat:create(costHPSequence, nCostTimes)
    local delayTime = nTotalTimes

    --shark
    local panelMember = panelUnitBase:getChildByName("Panel_member")
    local startFrame = 140
    local endFrame   = 170
    local playFrameTime = (endFrame - startFrame) / FRAME_PER_SECOND

    local actionShark  = cc.Sequence:create(
        cc.CallFunc:create(
            function()
                tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPlay(startFrame, endFrame, false)
                panelMember:setVisible(true)
            end
        )
    )
    if delayTime < playFrameTime then delayTime = playFrameTime end

    local spawnAction = cc.Spawn:create(repeatAction, actionShark)
    tBattleUI:runAction(spawnAction)
    delayExecute(tBattleUI, 
        function()
            panelMember:setVisible(false)
            if nCurrentHP <= 0 then
                local panelMember       = panelUnitBase:getChildByName("Panel_member")
                local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
                local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
                local imageMemberRed    = panelMember:getChildByName("Image_member_red")
                local projectNodeExclamation = panelUnitBase:getChildByName("ProjectNode_exclamation")
                panelMember:setVisible(true)
                imageMemberShadow:setVisible(true)
                imageMemberBounce:setVisible(false)
                imageMemberRed:setVisible(false)
                projectNodeExclamation:setVisible(false)
            end
            tBattleUI[actionName][nCardIndex].actionCard:gotoFrameAndPause(1)
            fnCallback() 
        end, 
        delayTime)
end

function KBattleUIHelper.playNightBulletBlastAnimation(fnCallback, tBattleData, tBattleUI, tDstCard)
    print("-----> Call playNightBulletBlastAnimation~", tDstCard.bLeftSide, tDstCard.nIndex)
    local mainNode                  = tBattleUI._mainLayout
    local bIsLeftTeam               = tDstCard.bLeftSide
    local nCardIndex                = tDstCard.nIndex

    local actionName = "_actionLeftTeam" 
    if not bIsLeftTeam then actionName = "_actionRightTeam" end

    local normalHurtAction = tBattleUI[actionName][nCardIndex].actionNormalHurt
    local normalHurtActionDuration = normalHurtAction:getDuration()
    safePlayAnimation(tBattleUI, normalHurtAction, 0, normalHurtActionDuration, false, "playNightBulletBlastAnimation")

    fnCallback()
    -- KSound.playEffect("boom")
end

function KBattleUIHelper.playNightHurtAnimation(fnCallback, tBattleData, tBattleUI, tTargetCard, nDamage)
    print("-----> Call playNightHurtAnimation~", tTargetCard.bLeftSide, tTargetCard.nIndex, nDamage)
    local bIsLeftTeam               = tTargetCard.bLeftSide
    local nCardIndex                = tTargetCard.nIndex
    local actionName = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    local nodeTargetTeamName= "Node_ally_unit"
    if not bIsLeftTeam then nodeTargetTeamName = "Node_enemy_unit" end

    --print("*****> playHurtAnimation", bIsLeftTeam, nCardIndex, actionName, nodeTargetTeamName)
    local mainNode           = tBattleUI._mainLayout
    local nodeTargetTeamUnit = mainNode:getChildByName(nodeTargetTeamName)
    local projectNodeTargetCard = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. nCardIndex)
    local projectNodeDamage     = projectNodeTargetCard:getChildByName("ProjectNode_normal")
    local projectNodeDamagePosition = projectNodeDamage:convertToWorldSpace(cc.p(0, 0))

    local panelUnitBase     = projectNodeTargetCard:getChildByName("Panel_unit")
    local imageBloodBase    = panelUnitBase:getChildByName("Image_unit_blood")

    local projectNodeHurt   = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_float_word_v2.csb")
    local actionHurt        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_float_word_v2.csb")
    projectNodeHurt:setPosition(cc.p(projectNodeDamagePosition.x, projectNodeDamagePosition.y))
    mainNode:addChild(projectNodeHurt, 100)
    projectNodeHurt:stopAllActions()
    local panelWordValue    = projectNodeHurt:getChildByName("Panel_word_value")
    panelWordValue:setVisible(false)
    local panelWordMiss     = projectNodeHurt:getChildByName("Panel_word_miss")
    panelWordMiss:setVisible(false)
    local panelWordCrit     = projectNodeHurt:getChildByName("Panel_word_crit")
    panelWordCrit:setVisible(true)
    local panelWordRicochet = projectNodeHurt:getChildByName("Panel_word_ricochet")
    panelWordRicochet:setVisible(false)

    local panelFloatWorldLeft   = panelWordCrit:getChildByName("Panel_word_crit_1")
    local panelFloatWorldRight  = panelWordCrit:getChildByName("Panel_word_crit_2")
    local textAttackValueLeft   = panelFloatWorldLeft:getChildByName("BitmapFontLabel_word_crit")
    local damageValue           = tostring(nDamage)
    textAttackValueLeft:setString(damageValue)
    local textAttackValueRight  = panelFloatWorldRight:getChildByName("BitmapFontLabel_word_crit")
    textAttackValueRight:setString(damageValue)

    projectNodeHurt:runAction(actionHurt)
    actionHurt:gotoFrameAndPlay(0, actionHurt:getDuration(), false)
    local nActionTime = actionHurt:getDuration() / FRAME_PER_SECOND
    delayExecute(
        tBattleUI,
        function ()
            projectNodeHurt:removeFromParent()
            fnCallback()
        end,
        nActionTime
    )
end

function KBattleUIHelper.playNightBrokenAnimation(fnCallback, tBattleData, tBattleUI, tDstCard, backgroundType, isNight, cardState)
    print("-----> Call playNightBrokenAnimation~")
    local mainNode                  = tBattleUI._mainLayout
    local characterHeavyHurtPanel   = mainNode:getChildByName("ProjectNode_destruction")
    local destructionStartFrame     = 0
    local destructionEndFrame       = 160 
    
    local imageBackGround           = characterHeavyHurtPanel:getChildByName("Image_backgrond")
    local imagePath                 = KUtil.getBattleBackgroundImagePath(backgroundType, isNight)
    imageBackGround:loadTexture(imagePath)

    local nodeBigDestruction        = characterHeavyHurtPanel:getChildByName("Node_big_destruction")
    local nodeMediumDestruction     = characterHeavyHurtPanel:getChildByName("Node_medium_destruction")
    nodeMediumDestruction:setVisible(cardState == CARD_BROKEN_STATE.MIDDLE)
    nodeBigDestruction:setVisible(cardState == CARD_BROKEN_STATE.BIG)

    local imageCharacter            = characterHeavyHurtPanel:getChildByName("Image_chara")

    local cardID                    = tDstCard.nTemplateID
    local cardImagePath             = KUtil.getCardImagePathByConfigID(cardID, true, tDstCard.nSkinTemplateID)
    imageCharacter:loadTexture(cardImagePath)

    playAnimationAndCallback(fnCallback, tBattleUI, "_actionCharacterHeavyHurt", false, false, destructionStartFrame, destructionEndFrame)
end

function KBattleUIHelper.playEmergencyRepairAnimation(fnCallback, tBattleData, tBattleUI, emergencyRepairCard, emergencyRepairCardNewCurrentHP)
    print("-----> Call playEmergencyRepairAnimation~")
    local mainNode                   = tBattleUI._mainLayout
    local bIsLeftTeam                = emergencyRepairCard.bLeftSide
    local nCardIndex                 = emergencyRepairCard.nIndex
    local projectNodeDstUnitName     = "ProjectNode_unit_" .. nCardIndex
    local nodeCardTeamName           = "Node_ally_unit"
    if not bIsLeftTeam then nodeCardTeamName = "Node_enemy_unit" end
    local nodeTeanUnit               = mainNode:getChildByName(nodeCardTeamName)
    local projectNodeCard            = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
    local projectRepairBrushlight    = projectNodeCard:getChildByName("ProjectNode_repair_brushlight")
    local panelUnitBase              = projectNodeCard:getChildByName("Panel_unit")
    local nodeCardState              = panelUnitBase:getChildByName("Node_damage")
    local imageBloodBase             = panelUnitBase:getChildByName("Image_unit_blood")
    local hpName                     = {"unit_blood_1", "unit_blood_2", "unit_blood_3", "unit_blood_4", nil}
    local stateName                  = {nil, "Image_damage_light", "Image_damage_middle", "Image_damage_heavy", "Image_damage_broken"}
    
    local emergencyRepairStartFrame  = 0
    local emergencyRepairEndFrame    = 120

    local actionName  = "_actionLeftTeam"
    if not bIsLeftTeam then actionName = "_actionRightTeam" end
    local emergencyAction           = tBattleUI[actionName][nCardIndex].actionEmergencyRepair
    local emergencyActionDuration   = emergencyAction:getDuration()
    local emergencyActionTime       = emergencyActionDuration / FRAME_PER_SECOND

    local projectNodePosition  = projectRepairBrushlight:convertToWorldSpace(cc.p(0, 0))
    local bLastPositionX       = projectNodePosition.x
    local bLastPositionY       = projectNodePosition.y

    local brushlightNode       
    local brushlightAction 
    local brushLightStartFrame = 0
    local brushLightEndFrame   = 40
    local brushLightActionTime = (brushLightEndFrame - brushLightStartFrame) / FRAME_PER_SECOND

    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(
            function()
                safePlayAnimation(tBattleUI, emergencyAction, 0, emergencyActionDuration, false, "playEmergencyRepairAnimation")
            end
        ),
        cc.DelayTime:create(emergencyActionTime),
        cc.CallFunc:create(
            function ()
                brushlightNode       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_repair_brushlight.csb")
                brushlightAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_repair_brushlight.csb")
                mainNode:addChild(brushlightNode, 100)
                brushlightNode:stopAllActions()
                brushlightNode:runAction(brushlightAction)
                brushlightNode:setPosition(cc.p(bLastPositionX, bLastPositionY))
                brushlightAction:gotoFrameAndPlay(brushLightStartFrame, brushLightEndFrame, false)
            end
        ),
        cc.DelayTime:create(brushLightActionTime),
        cc.CallFunc:create(
            function ()
                local textHPNumber = panelUnitBase:getChildByName("Text_hp_numerical")
                textHPNumber:setString(emergencyRepairCardNewCurrentHP .. "/" .. emergencyRepairCard.nMaxHP)

                local nNewHPPercent = math.floor(emergencyRepairCardNewCurrentHP / emergencyRepairCard.nMaxHP * 100)
                KUtil.drawCardState(imageBloodBase, nodeCardState, hpName, stateName, nNewHPPercent)

                local panelMember       = panelUnitBase:getChildByName("Panel_member")
                local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
                local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
                local imageMemberRed    = panelMember:getChildByName("Image_member_red")
                panelMember:setVisible(true)
                imageMemberShadow:setVisible(false)
                imageMemberBounce:setVisible(false)
                imageMemberRed:setVisible(false)

                brushlightNode:removeFromParent()
                fnCallback()
            end
            )
        )
    tBattleUI:runAction(actionSequence)
end

function KBattleUIHelper.playNightFightBeginWordAnimation(fnCallback, tBattleData, tBattleUI)
    print("-----> Call playNightFightBeginWordAnimation~")
    local mainNode                      = tBattleUI._mainLayout
    local nightFightBeginWordNode       = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_character2.csb")
    local nightFightBeginWordNodeAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_character2.csb")
    local startFrame                    = 0
    local endFrame                      = nightFightBeginWordNodeAction:getDuration()
    local actionTime                    = (endFrame - startFrame) / FRAME_PER_SECOND
    mainNode:addChild(nightFightBeginWordNode, 100)
    nightFightBeginWordNode:stopAllActions()
    nightFightBeginWordNode:runAction(nightFightBeginWordNodeAction)
    nightFightBeginWordNodeAction:gotoFrameAndPlay(startFrame, endFrame, false)

    delayExecute(
        tBattleUI, 
        function () 
            nightFightBeginWordNode:removeFromParent()
            fnCallback()
        end, 
        actionTime
    )
end

function KBattleUIHelper.playFightDestroyAnimation(fnCallback, tBattleData, tBattleUI, card)
    print("-----> Call playFightDestroyAnimation~")
    local mainNode              = tBattleUI._mainLayout
    local fightDestroyNode      = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_destroying.csb") 
    local fightDestroyAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_destroying.csb")
    local panel                 = fightDestroyNode:getChildByName("Panel_1")
    local panelChara            = panel:getChildByName("Panel_chara")
    local imageChara            = panelChara:getChildByName("Image_chara")
    local isHead                = false
    local isBreak               = true 
    local cardImagePath         = KUtil.getCardImagePath(card, isHead, isBreak)
    imageChara:loadTexture(cardImagePath)
    local startFrame            = 0
    local endFrame              = fightDestroyAction:getDuration()
    local actionTime            = (endFrame - startFrame) / FRAME_PER_SECOND
    mainNode:addChild(fightDestroyNode, 100)
    fightDestroyNode:stopAllActions()
    fightDestroyNode:runAction(fightDestroyAction)
    fightDestroyAction:gotoFrameAndPlay(startFrame, endFrame, false)

    --Fight Destroy Music
    KSound.pauseMusic()
    local cardID        = card.nTemplateID
    local textFont      = fightDestroyNode:getChildByName("Text_font")
    local cardConfig    = KConfig:getLine("cardInfo", cardID)
    textFont:setString(cardConfig["szDestroyDialogue"])
    KSound.playTalk(KSound.TALK.BEWRECK, cardID, not card.bIsRole)

    delayExecute(
        tBattleUI,
        function()
            KSound.resumeMusic()
            fightDestroyNode:removeFromParent()
            fnCallback()
        end,
        actionTime
    )
end

function KBattleUIHelper.playSkillAirSupportPlayAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
    print("-----> Call playSkillAirSupportPlayAnimation~", isLeft)
    local mainNode = tBattleUI._mainLayout
    local szSound2 = tSkillConfig.szSound2
    local nDelay2  = tSkillConfig.nDelay2
    local szSound3 = tSkillConfig.szSound3
    local nDelay3  = tSkillConfig.nDelay3

    local nEquipTemplateID  = equipConfig.nID
    local equipImage        = KUtil.getEquipImagePathByID(nEquipTemplateID)
    if isLeft then
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_airsupport_V2.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_airsupport_V2.csb")

        local panelSkillAirsupport = skillPlay:getChildByName("Panel_skill_airsupport_V2")
        local panelFighter         = panelSkillAirsupport:getChildByName("Panel_fighter")
        for i = 1, 3 do
            local imageFighterName = "Image_fighter_" .. i
            local imageFighter     = panelFighter:getChildByName(imageFighterName)
            imageFighter:loadTexture(equipImage)
        end
        local nCardIndex                = tCard.nIndex
        local projectNodeDstUnitName    = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName          = "Node_enemy_unit"
        local nodeTeamUnit              = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard           = nodeTeamUnit:getChildByName(projectNodeDstUnitName)
        local projectNodeCritical       = projectNodeCard:getChildByName("ProjectNode_critical")

        local criticalPosition      = projectNodeCritical:convertToWorldSpace(CCPoint(0, 0))
        local criticalPositionX     = criticalPosition.x
        local criticalPositionY     = criticalPosition.y

        local panelSkillAirsupport  = skillPlay:getChildByName("Panel_skill_airsupport_V2")
        local panelSkillAirsupportPosition  = panelSkillAirsupport:convertToWorldSpace(CCPoint(0, 0))
        local panelSkillAirsupportPositionX = panelSkillAirsupportPosition.x
        local panelSkillAirsupportPositionY = panelSkillAirsupportPosition.y

        local panelGunfire          = panelSkillAirsupport:getChildByName("Panel_gunfire")
        local spriteGunfireHit      = panelGunfire:getChildByName("Sprite_gunfire_hit")
        local spriteGunfireHitPosition  = spriteGunfireHit:convertToWorldSpace(CCPoint(0, 0))
        local spriteGunfireHitPositionX = spriteGunfireHitPosition.x
        local spriteGunfireHitPositionY = spriteGunfireHitPosition.y

        local finalX = (panelSkillAirsupportPositionX + (spriteGunfireHitPositionX - criticalPositionX))
        local finalY = (panelSkillAirsupportPositionY + (spriteGunfireHitPositionY - criticalPositionY))

        skillPlay:setPosition(cc.p(criticalPositionX, criticalPositionY))
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)

        local delayTime2 = nDelay2 / FRAME_PER_SECOND
        delayExecute(
            tBattleUI, 
            function () 
                KSound.playEffect(szSound2)
            end, 
            delayTime2
        )
        local delayTime3 = nDelay3 / FRAME_PER_SECOND
        delayExecute(
            tBattleUI, 
            function () 
                KSound.playEffect(szSound3)
            end, 
            delayTime3
        )

        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    else
        local skillPlay        = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_airsupport_V2_enemy.csb")
        local skillPlayAction  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_airsupport_V2_enemy.csb")

        local panelSkillAirsupport = skillPlay:getChildByName("Panel_skill_airsupport_V2")
        local panelFighter         = panelSkillAirsupport:getChildByName("Panel_fighter")
        for i = 1, 3 do
            local imageFighterName = "Image_fighter_" .. i
            local imageFighter     = panelFighter:getChildByName(imageFighterName)
            imageFighter:loadTexture(equipImage)
        end

        local nCardIndex                = tCard.nIndex
        local projectNodeDstUnitName    = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName          = "Node_ally_unit"
        local nodeTeamUnit              = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard           = nodeTeamUnit:getChildByName(projectNodeDstUnitName)
        local projectNodeCritical       = projectNodeCard:getChildByName("ProjectNode_critical")

        local criticalPosition      = projectNodeCritical:convertToWorldSpace(CCPoint(0, 0))
        local criticalPositionX     = criticalPosition.x
        local criticalPositionY     = criticalPosition.y

        local panelSkillAirsupport  = skillPlay:getChildByName("Panel_skill_airsupport_V2")
        local panelSkillAirsupportPosition  = panelSkillAirsupport:convertToWorldSpace(CCPoint(0, 0))
        local panelSkillAirsupportPositionX = panelSkillAirsupportPosition.x
        local panelSkillAirsupportPositionY = panelSkillAirsupportPosition.y

        local panelGunfire          = panelSkillAirsupport:getChildByName("Panel_gunfire")
        local spriteGunfireHit      = panelGunfire:getChildByName("Sprite_gunfire_hit")
        local spriteGunfireHitPosition  = spriteGunfireHit:convertToWorldSpace(CCPoint(0, 0))
        local spriteGunfireHitPositionX = spriteGunfireHitPosition.x
        local spriteGunfireHitPositionY = spriteGunfireHitPosition.y

        local finalX = (panelSkillAirsupportPositionX + (spriteGunfireHitPositionX - criticalPositionX))
        local finalY = (panelSkillAirsupportPositionY + (spriteGunfireHitPositionY - criticalPositionY))

        skillPlay:setPosition(cc.p(criticalPositionX, criticalPositionY))
        mainNode:addChild(skillPlay, 100)
        skillPlay:stopAllActions()
        skillPlay:runAction(skillPlayAction)
        local skillPlayStartFrame = 0
        local skillPlayEndFrame   = skillPlayAction:getDuration()
        local skillAllTime        = (skillPlayEndFrame - skillPlayStartFrame) / FRAME_PER_SECOND
        skillPlayAction:gotoFrameAndPlay(skillPlayStartFrame, skillPlayEndFrame, false)

        local delayTime2 = nDelay2 / FRAME_PER_SECOND
        delayExecute(
            tBattleUI, 
            function () 
                KSound.playEffect(szSound2)
            end, 
            delayTime2
        )
        local delayTime3 = nDelay3 / FRAME_PER_SECOND
        delayExecute(
            tBattleUI, 
            function () 
                KSound.playEffect(szSound3)
            end, 
            delayTime3
        )

        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            skillAllTime
        )
    end
end

function KBattleUIHelper.playSkillStrikeTargetAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
    print("-----> Call playStrikeTargetAnimation~", isLeft, equipConfig, tCard)

    local szSound2 = tSkillConfig.szSound2
    if isLeft then
        local nCardIndex       = tCard.nIndex
        local actionName       = "_actionRightTeam"
        local strikeTargetAction  = tBattleUI[actionName][nCardIndex].actionStrikeTarget
        local strikeTargetActionDuration    = strikeTargetAction:getDuration()
        local strikeTargetActionTime        = strikeTargetActionDuration / FRAME_PER_SECOND
        safePlayAnimation(tBattleUI, strikeTargetAction, 0, strikeTargetActionDuration, false, "playStrikeTargetAnimation")
        KSound.playEffect(szSound2)
        delayExecute(
            tBattleUI, 
            function () 
                fnCallback()
            end, 
            strikeTargetActionTime
        )
    else
        local actionName       = "_actionLeftTeam"
        local nCardIndex       = tCard.nIndex
        local strikeTargetAction  = tBattleUI[actionName][nCardIndex].actionStrikeTarget
        local strikeTargetActionDuration    = strikeTargetAction:getDuration()
        local strikeTargetActionTime        = strikeTargetActionDuration / FRAME_PER_SECOND
        safePlayAnimation(tBattleUI, strikeTargetAction, 0, strikeTargetActionDuration, false, "playStrikeTargetAnimation")
        KSound.playEffect(szSound2)
        delayExecute(
            tBattleUI, 
            function () 
                fnCallback()
            end, 
            strikeTargetActionTime
        )
    end
end

function KBattleUIHelper.playSkillExperienceBlinkAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
    print("-----> Call playSkillExperienceBlinkAnimation~", isLeft, equipConfig, tCard)
    local mainNode = tBattleUI._mainLayout
    if isLeft then
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_ally_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeExperience  = panelBattleSkill:getChildByName("ProjectNode_experience_light")
        local projectNodeExperiencePosition     = projectNodeExperience:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_experience_light.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_experience_light.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    else
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_enemy_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeExperience  = panelBattleSkill:getChildByName("ProjectNode_experience_light")
        local projectNodeExperiencePosition     = projectNodeExperience:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_experience_light.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_experience_light.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    end
end

function KBattleUIHelper.playSkillBunkerbuildBlinkAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
    print("-----> Call playSkillBunkerbuildBlinkAnimation~", isLeft, equipName, tCard)
    local mainNode = tBattleUI._mainLayout
    if isLeft then
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_ally_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeExperience  = panelBattleSkill:getChildByName("ProjectNode_bunkerbuild_light")
        local projectNodeExperiencePosition     = projectNodeExperience:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_bunkerbuild_light.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_bunkerbuild_light.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    else
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_enemy_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeExperience  = panelBattleSkill:getChildByName("ProjectNode_bunkerbuild_light")
        local projectNodeExperiencePosition     = projectNodeExperience:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_bunkerbuild_light.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_bunkerbuild_light.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    end
end

function KBattleUIHelper.playSkillSupplyOilAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard, nAddOil)
    print("-----> Call playSkillSupplyOilAnimation~", isLeft, equipConfig, tCard, nAddOil)
    local mainNode = tBattleUI._mainLayout
    local m_tSpriteSupply = {
        {["upLimit"] = 101, ["downLimit"] = 99, ["spritName"] = "value100"},
        {["upLimit"] = 99,  ["downLimit"] = 75, ["spritName"] = "value80"},
        {["upLimit"] = 75,  ["downLimit"] = 50, ["spritName"] = "value60"},
        {["upLimit"] = 50,  ["downLimit"] = 25, ["spritName"] = "value40"},
        {["upLimit"] = 20,  ["downLimit"] = 0 , ["spritName"] = "value20"},
    }

    if isLeft then
        local actionName                    = "_actionLeftTeam"
        local nCardIndex                    = tCard.nIndex
        local nCardMaxOil                   = tCard.nMaxOil
        local supplyCurrentOilPercent       = math.ceil(tCard.nCarryOil / nCardMaxOil * 100)
        local supplyOilPercent              = math.ceil(nAddOil / nCardMaxOil * 100)
        if supplyOilPercent > 100 then
            supplyOilPercent = 100
        end
        local newSupplyOilPercent = supplyCurrentOilPercent + supplyOilPercent
        if newSupplyOilPercent > 100 then
            newSupplyOilPercent = 100
        end
        local supplyValueActionDuration 
        local supplyValueActionTime     
        local skillPlay  
        local skillPlayAction

        for _, var in ipairs(m_tSpriteSupply) do
            if newSupplyOilPercent <= var.upLimit and newSupplyOilPercent > var.downLimit then
                skillPlay             = cc.CSLoader:createNode("res/ui/animation_node/ani_skill_supply_" .. var.spritName .. ".csb")
                skillPlayAction       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skill_supply_" .. var.spritName .. ".csb")
                skillPlay:stopAllActions()
                skillPlay:runAction(skillPlayAction)
                supplyValueActionDuration   = skillPlayAction:getDuration()
                supplyValueActionTime       = supplyValueActionDuration / FRAME_PER_SECOND
                local panel                 = skillPlay:getChildByName("Panel_2")
                local bitMapFontLabelFont   = panel:getChildByName("BitmapFontLabel_1")
                bitMapFontLabelFont:setString("+" .. supplyOilPercent .. "%")
            end
        end

        mainNode:addChild(skillPlay, 100)
        local projectNodeDstUnitName    = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName          = "Node_ally_unit"
        local nodeTeamUnit              = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard           = nodeTeamUnit:getChildByName(projectNodeDstUnitName)
        local panelUnitBase             = projectNodeCard:getChildByName("Panel_unit") 
        local panelBattleSkill          = panelUnitBase:getChildByName("Panel_battle_skill")
        local projectNodeSupplyValue    = panelBattleSkill:getChildByName("Node_value_1")
        local SupplyValuePosition       = projectNodeSupplyValue:convertToWorldSpace(CCPoint(0, 0))
        local SupplyValuePositionX      = SupplyValuePosition.x
        local SupplyValuePositionY      = SupplyValuePosition.y
        skillPlay:setPosition(cc.p(SupplyValuePositionX, SupplyValuePositionY))

        skillPlayAction:gotoFrameAndPlay(0, supplyValueActionDuration, false)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay:removeFromParent()
                fnCallback()
            end, 
            supplyValueActionTime
        )
    else
       assert(false)
    end
end

function KBattleUIHelper.playSkillSupplyAmmoAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard, nAddAmmo)
    print("-----> Call playSkillSupplyAmmoAnimation~", isLeft, equipConfig, tCard, nAddOil)
    local mainNode = tBattleUI._mainLayout
    local m_tSpriteSupply = {
        {["upLimit"] = 101, ["downLimit"] = 99, ["spritName"] = "value100"},
        {["upLimit"] = 99,  ["downLimit"] = 75, ["spritName"] = "value80"},
        {["upLimit"] = 75,  ["downLimit"] = 50, ["spritName"] = "value60"},
        {["upLimit"] = 50,  ["downLimit"] = 25, ["spritName"] = "value40"},
        {["upLimit"] = 20,  ["downLimit"] = 0 , ["spritName"] = "value20"},
    }

    if isLeft then
        local actionName                    = "_actionLeftTeam"
        local nCardIndex                    = tCard.nIndex
        local nCardMaxAmmo                  = tCard.nMaxAmmo
        local supplyCurrentAmmoPercent       = math.ceil(tCard.nCarryAmmo / nCardMaxAmmo * 100)
        local supplyAmmoPercent              = math.ceil(nAddAmmo / nCardMaxAmmo * 100)

        if supplyAmmoPercent > 100 then
            supplyAmmoPercent = 100
        end
        local newSupplyAmmoPercent = supplyCurrentAmmoPercent + supplyAmmoPercent
        if newSupplyAmmoPercent > 100 then
            newSupplyAmmoPercent = 100
        end
        local supplyValue2ActionDuration 
        local supplyValue2ActionTime     
        local skillPlay2     
        local skillPlay2Action

        for _, var in ipairs(m_tSpriteSupply) do
            if newSupplyAmmoPercent <= var.upLimit and newSupplyAmmoPercent > var.downLimit then
                skillPlay2            = cc.CSLoader:createNode("res/ui/animation_node/ani_skill_supply1_" .. var.spritName .. ".csb")
                skillPlay2Action      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skill_supply1_" .. var.spritName .. ".csb")
                skillPlay2:stopAllActions()
                skillPlay2:runAction(skillPlay2Action)
                supplyValue2ActionDuration  = skillPlay2Action:getDuration()
                supplyValue2ActionTime      = supplyValue2ActionDuration / FRAME_PER_SECOND
                local panel                 = skillPlay2:getChildByName("Panel_2")
                local bitMapFontLabelFont   = panel:getChildByName("BitmapFontLabel_1")
                bitMapFontLabelFont:setString("+" .. supplyAmmoPercent .. "%")
            end
        end

        mainNode:addChild(skillPlay2, 100)
        local projectNodeDstUnitName    = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName          = "Node_ally_unit"
        local nodeTeamUnit              = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard           = nodeTeamUnit:getChildByName(projectNodeDstUnitName)
        local panelUnitBase             = projectNodeCard:getChildByName("Panel_unit") 
        local panelBattleSkill          = panelUnitBase:getChildByName("Panel_battle_skill")
        local projectNodeSupply2Value   = panelBattleSkill:getChildByName("Node_value_2")
        local SupplyValue2Position      = projectNodeSupply2Value:convertToWorldSpace(CCPoint(0, 0))
        local SupplyValue2PositionX     = SupplyValue2Position.x
        local SupplyValue2PositionY     = SupplyValue2Position.y
        skillPlay2:setPosition(cc.p(SupplyValue2PositionX, SupplyValue2PositionY))

        skillPlay2Action:gotoFrameAndPlay(0, supplyValue2ActionDuration, false)
        delayExecute(
            tBattleUI, 
            function () 
                skillPlay2:removeFromParent()
                fnCallback()
            end, 
            supplyValue2ActionTime
        )
    else
       assert(false)
    end
end

function KBattleUIHelper.playLandmineBoomAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
    print("-----> Call playLandmineBoomAnimation~")
    local mainNode = tBattleUI._mainLayout
    if isLeft then
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_enemy_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeMinesexplosion  = panelBattleSkill:getChildByName("ProjectNode_minesexplosion")
        local projectNodeExperiencePosition     = projectNodeMinesexplosion:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_skills_minesexplosion.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skills_minesexplosion.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    else
        local nCardIndex             = tCard.nIndex
        local projectNodeDstUnitName = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName       = "Node_ally_unit"
        local nodeTeanUnit           = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard        = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnit              = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill       = panelUnit:getChildByName("Panel_battle_skill")

        local projectNodeMinesexplosion  = panelBattleSkill:getChildByName("ProjectNode_minesexplosion")
        local projectNodeExperiencePosition     = projectNodeMinesexplosion:convertToWorldSpace(CCPoint(0, 0))
        local projectNodeExperiencePositionX    = projectNodeExperiencePosition.x
        local projectNodeExperiencePositionY    = projectNodeExperiencePosition.y
        local brushlightNode                    = cc.CSLoader:createNode("res/ui/animation_node/ani_skills_minesexplosion.csb")
        local brushlightAction                  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skills_minesexplosion.csb")
        local cardBlinkActionDuration           = brushlightAction:getDuration()
        brushlightNode:setPosition(cc.p(projectNodeExperiencePositionX, projectNodeExperiencePositionY))
        mainNode:addChild(brushlightNode, 100)
        brushlightNode:stopAllActions()
        brushlightNode:runAction(brushlightAction)
        brushlightAction:gotoFrameAndPlay(0, cardBlinkActionDuration, false)
        local cardBlinkActionTime  = cardBlinkActionDuration / FRAME_PER_SECOND

        delayExecute(
            tBattleUI, 
            function () 
                brushlightNode:removeFromParent()
                fnCallback()
            end, 
            cardBlinkActionTime
        )
    end
end

function KBattleUIHelper.playSkillRepairAnimation(fnCallback, tBattleData, tBattleUI, isLeft, equipConfig, tSkillConfig, tCard, nRepairHP)
    print("-----> Call playSkillRepairAnimation~", isLeft, equipName, tCard)
    if isLeft then
        local mainNode   = tBattleUI._mainLayout
        local actionName = "_actionLeftTeam"
        local nCardIndex = tCard.nIndex
        local projectNodeDstUnitName         = "ProjectNode_unit_" .. nCardIndex
        local nodeCardTeamName               = "Node_ally_unit"
        local nodeTeanUnit                   = mainNode:getChildByName(nodeCardTeamName)
        local projectNodeCard                = nodeTeanUnit:getChildByName(projectNodeDstUnitName)
        local panelUnitBase                  = projectNodeCard:getChildByName("Panel_unit")
        local panelBattleSkill               = panelUnitBase:getChildByName("Panel_battle_skill")
        local projectNodeBrushlight          = panelBattleSkill:getChildByName("Node_skill_repair_brushlight")
        local brushlightPostion              = projectNodeBrushlight:convertToWorldSpace(CCPoint(0, 0))
        local projectNodePositionX           = brushlightPostion.x
        local projectNodePositionY           = brushlightPostion.y
        local nodeCardState                  = panelUnitBase:getChildByName("Node_damage")
        local imageBloodBase                 = panelUnitBase:getChildByName("Image_unit_blood")
        local hpName                         = {"unit_blood_1", "unit_blood_2", "unit_blood_3", "unit_blood_4", nil}
        local stateName                      = {nil, "Image_damage_light", "Image_damage_middle", "Image_damage_heavy", "Image_damage_broken"}

        local projectNodeSkillRepairBrushLight = cc.CSLoader:createNode("res/ui/animation_node/ani_battle_skill_repair_brushlight.csb")
        local actionSkillRepairBrushLight      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_repair_brushlight.csb")
        projectNodeSkillRepairBrushLight:setPosition(cc.p(projectNodePositionX, projectNodePositionY))
        mainNode:addChild(projectNodeSkillRepairBrushLight, 100)
        projectNodeSkillRepairBrushLight:stopAllActions()
        projectNodeSkillRepairBrushLight:runAction(actionSkillRepairBrushLight)
        actionSkillRepairBrushLight:gotoFrameAndPause(0)
        local repairBrushLightActionDuration = actionSkillRepairBrushLight:getDuration()
        local repairBrushLightActionTime     = repairBrushLightActionDuration / FRAME_PER_SECOND

        local panel = projectNodeSkillRepairBrushLight:getChildByName("Panel_1")
        local bitMapFontLabelFont = panel:getChildByName("BitmapFontLabel_font")
        bitMapFontLabelFont:setString("+" .. nRepairHP)
        local actionSequence = cc.Sequence:create(
            cc.CallFunc:create(
                function ()
                    actionSkillRepairBrushLight:gotoFrameAndPlay(0, repairBrushLightActionDuration, false)
                end
            ),
            cc.DelayTime:create(repairBrushLightActionTime),
            cc.CallFunc:create(
                function ()
                    local textHPNumber = panelUnitBase:getChildByName("Text_hp_numerical")
                    textHPNumber:setString(tCard.nCurrentHP .. "/" .. tCard.nMaxHP)

                    local projectNodeCard = panelUnitBase:getChildByName("ProjectNode_card")
                    local imageCharaHead  = projectNodeCard:getChildByName("Image_chara_head")

                    local nNewHPPercent = math.floor(tCard.nCurrentHP / tCard.nMaxHP * 100)
                    KUtil.drawCardState(imageBloodBase, nodeCardState, hpName, stateName, nNewHPPercent)
                    local isBroken
                    if tCard.nCurrentHP / tCard.nMaxHP <= 0.5 then
                        isBroken = true
                    else
                        isBroken = false
                    end
                    local cardImagePath = KUtil.getCardImagePath(tCard, true, isBroken)
                    imageCharaHead:loadTexture(cardImagePath)

                    local panelMember       = panelUnitBase:getChildByName("Panel_member")
                    local imageMemberShadow = panelMember:getChildByName("Image_member_shadow")
                    local imageMemberBounce = panelMember:getChildByName("Image_member_bounce")
                    local imageMemberRed    = panelMember:getChildByName("Image_member_red")
                    panelMember:setVisible(true)
                    imageMemberShadow:setVisible(false)
                    imageMemberBounce:setVisible(false)
                    imageMemberRed:setVisible(false)

                    projectNodeSkillRepairBrushLight:removeFromParent()
                    fnCallback()
                end
                )
            )
        tBattleUI:runAction(actionSequence)
    else
        assert(false)
    end
end

function KBattleUIHelper.playCardAbilityAnimation(fnCallBack, tBattleData, tBattleUI, tAttackCard, nAbilityID)
    if not tAttackCard.bLeftSide then 
        return 
    end

    local mainNode      = tBattleUI._mainLayout
    local nodeAbility   = mainNode:getChildByName("ProjectNode_train_buff")
    local panelBase     = nodeAbility:getChildByName("Panel_0")
    local panelChara    = panelBase:getChildByName("Panel_2")
    local imageChara    = panelChara:getChildByName("Image_chara")
    local cardImagePath = KUtil.getCardImagePath(tAttackCard, false)
    imageChara:loadTexture(cardImagePath)
  
    local panelBuff   = panelBase:getChildByName("Panel_1")
    local imageBuff   = panelBuff:getChildByName("Image_buff_name")
    local szBuffWord  = KConfig.trainingSkill[nAbilityID].szBuffWord
    local szImagePath = "res/ui/ui_material/battle_buff/" .. szBuffWord .. ".png"
    imageBuff:loadTexture(szImagePath)

    playAnimationAndCallback(fnCallBack, tBattleUI, "_actionUseAbility", false, false)
end

function KBattleUIHelper.playCardAbilityBuffAnimation(fnCallBack, tBattleData, tBattleUI, tTargetCard, bShow)
    local bIsLeftTeam = tTargetCard.bLeftSide
    local nCardIndex  = tTargetCard.nIndex
    local actionName = "_actionLeftTeam"
    local nodeTargetTeamName = "Node_ally_unit"
    if not bIsLeftTeam then 
        actionName = "_actionRightTeam"
        nodeTargetTeamName = "Node_enemy_unit"
    end

    local mainNode              = tBattleUI._mainLayout
    local nodeTargetTeamUnit    = mainNode:getChildByName(nodeTargetTeamName)
    local nodeCardUnit          = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. tTargetCard.nIndex)
    local panelUnit             = nodeCardUnit:getChildByName("Panel_unit")
    local panelBattleSkill      = panelUnit:getChildByName("Panel_battle_skill")
    local projectNodeSkillBuff  = panelBattleSkill:getChildByName("ProjectNode_skill_buff")

    projectNodeSkillBuff:setVisible(bShow)

    fnCallBack()
    return 
end

function KBattleUIHelper.playCardAbilityLightAnimation(fnCallBack, tBattleData, tBattleUI, tTargetCard)
    local bIsLeftTeam = tTargetCard.bLeftSide
    local nCardIndex  = tTargetCard.nIndex
    local nodeTargetTeamName = "Node_ally_unit"
    if not bIsLeftTeam then 
        nodeTargetTeamName = "Node_enemy_unit"
    end

    local mainNode              = tBattleUI._mainLayout
    local nodeTargetTeamUnit    = mainNode:getChildByName(nodeTargetTeamName)
    local nodeCardUnit          = nodeTargetTeamUnit:getChildByName("ProjectNode_unit_" .. tTargetCard.nIndex)
    local panelUnit             = nodeCardUnit:getChildByName("Panel_unit")
    local panelBattleSkill      = panelUnit:getChildByName("Panel_battle_skill")
    local projectNodeSkillBuff  = panelBattleSkill:getChildByName("ProjectNode_skill_light")
    local projectNodeSkillBuffPosition = projectNodeSkillBuff:convertToWorldSpace(CCPoint(0,0))
    local projectNodeSkillBuffPositionX = projectNodeSkillBuffPosition.x
    local projectNodeSkillBuffPositionY = projectNodeSkillBuffPosition.y
    local nodeSkillLight = cc.CSLoader:createNode("res/ui/animation_node/ani_get_skill_light.csb")
    local lightAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_get_skill_light.csb")
    local nDurationFrame = lightAction:getDuration()

    nodeSkillLight:setPosition(projectNodeSkillBuffPositionX, projectNodeSkillBuffPositionY)
    mainNode:addChild(nodeSkillLight, 100)
    nodeSkillLight:stopAllActions()
    nodeSkillLight:runAction(lightAction)
    lightAction:gotoFrameAndPlay(0, nDurationFrame, false)
    local actionTime = nDurationFrame / FRAME_PER_SECOND

    delayExecute(
        tBattleUI, 
        function () 
            nodeSkillLight:removeFromParent()
            fnCallBack()
        end, 
        actionTime
    )
    return 
end

function KBattleUIHelper.playAnimation(szFunc, tBattleData, tBattleUI, ...)
    local hThread = coroutine.running()
    local bCallback = false

    local fnEndCallback = function()
        assert(not bCallback, tostring(hThread) .. " resume twice!")

        bCallback = true

        local szStatus = coroutine.status(hThread)
        if szStatus == "running" then
            return
        end
        
        print("---------- > KBattleUIHelper.playAnimation fnEndCallback, szFunc:", szFunc, tostring(hThread))
        return coroutine.resume(hThread)
    end
    
    KBattleUIHelper[szFunc](fnEndCallback, tBattleData, tBattleUI, ...)
    if bCallback then
        return
    end

    coroutine.yield()
end

function KBattleUIHelper.delay(tBattleUI, seconds)
    print("delay", seconds) 
    local mainNode = tBattleUI._mainLayout
    
    local func = createThreadResumeFunc()
    delayExecute(mainNode, func, seconds)
    coroutine.yield()
end

return KBattleUIHelper
