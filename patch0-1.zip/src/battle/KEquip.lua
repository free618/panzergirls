--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KEquip.lua
--  Creator     : liulingli
--  Date        : 2015/10/20   16:05
--  Contact     : liulingli@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KEquip = {}

local function isCardEquipSmokeBomb(tCardInfo)
    for i = 1, 4 do
        local nEquipTemplateID = tCardInfo["nEquip"..i]
        if nEquipTemplateID and nEquipTemplateID ~= 0 then
            local tEquipConfig = KConfig:getLine("equipInfo", nEquipTemplateID)
            assert(tEquipConfig)
            if tEquipConfig.szDetailType == 'SMOKE' then
                return true
            end
        end
    end
end

local function playSmokeAnimation(tCardInfo, nIndex, tBattleData, tBattleUI)
    local KBattleUIHelper   = require("src/battle/KBattleUIHelper")
    KBattleUIHelper.delay(tBattleUI, nIndex * 0.3)
    KBattleUIHelper.playAnimation("playOneCardAnimation", tBattleData, tBattleUI, tCardInfo, "actionSmoke", 2, 59, false)
end

function KEquip.effectSmokeBomb(nStepIndex, tBattleData, tBattleUI)
    if nStepIndex ~= 2 then return end
    local tTaskIDList = {}

    local KBattleUIHelper = require("src/battle/KBattleUIHelper")
    local tAsyncExector   = require("battle/KAsyncExector").new()

    local nIndex = 1
    for _, tCardInfo in ipairs(tBattleData.tSrcTeam) do 
        if isCardEquipSmokeBomb(tCardInfo) then
            local nTaskID = tAsyncExector:exec(playSmokeAnimation, tCardInfo, nIndex, tBattleData, tBattleUI)
            table.insert(tTaskIDList, nTaskID)
            nIndex = nIndex + 1
        end
    end

    nIndex = 1
    for _, tCardInfo in ipairs(tBattleData.tDstTeam) do 
        if isCardEquipSmokeBomb(tCardInfo) then
            local nTaskID = tAsyncExector:exec(playSmokeAnimation, tCardInfo, nIndex, tBattleData, tBattleUI)
            table.insert(tTaskIDList, nTaskID)
            nIndex = nIndex + 1
        end
    end

    tAsyncExector:waiting(tTaskIDList)
 end 

 function KEquip.getAddLaunchCount(nStepType, tCardInfo)
    local nLaunchNum, nInterval = 0
    if nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION  or nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION2  then
        local nEquipNum = 1
        while true do
            local nEquipTemplateID = tCardInfo["nEquip"..nEquipNum]
            if nEquipTemplateID and nEquipTemplateID ~= 0 then
                local tEquipConfig = KConfig:getLine("equipInfo", nEquipTemplateID)
                assert(tEquipConfig)
                if tEquipConfig.szDetailType == 'DOUBLE_HIT' then
                    local nProbability = random({0, 1})
                    if nProbability   <= tEquipConfig.lszParameters.probability then
                        if nLaunchNum < tEquipConfig.lszParameters.addLaunchNum then
                            nLaunchNum = tEquipConfig.lszParameters.addLaunchNum
                            nInterval  = tEquipConfig.lszParameters.interval
                        end
                    end
                end
                nEquipNum = nEquipNum + 1
            else
                break
            end
        end
    end
    if not nInterval then
        nInterval = 0.5
    end
    return nLaunchNum, nInterval
 end

 return KEquip
 