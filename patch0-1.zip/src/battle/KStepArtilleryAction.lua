local KStepArtilleryAction = class("KStepArtilleryAction", require("battle/KBattleStepBase").new)

function KStepArtilleryAction:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.ARTILLERY_ACTION
    self.tLogic = require("src/battle/KStepArtilleryActionLogic").new(tBattleData)
end

function KStepArtilleryAction:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "ArtilleryAction")
end

function KStepArtilleryAction:showDistanceRuler(szStep, nMoveDistance)
    print("[" .. self:getName() .. "] showDistanceRuler", szStep, nMoveDistance)
    self:playAnimation("playDistanceRuleAnimation", szStep, nMoveDistance)
end

function KStepArtilleryAction:moveUnit()
    print("[" .. self:getName() .. "] moveUnit")
    local tBattleData = self:getBattleData()
    local tAsyncExecList = {}

    local nLightTankType    = 1
    local nMiddleTankType   = 2
    local nHeavyTankType    = 3
    local nAmbushTankType   = 4

    for k, v in ipairs(tBattleData.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_3")
                table.insert(tAsyncExecList, nID)
                break
            end

            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and nTankType == nAmbushTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    for k, v in ipairs(tBattleData.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_3")
                table.insert(tAsyncExecList, nID)
                break
            end

            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and nTankType == nAmbushTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    local nID = self:asyncExec(self.showDistanceRuler, self, "ArtilleryAction", 500)
    table.insert(tAsyncExecList, nID)

    self:waitAsync(tAsyncExecList)
end

function KStepArtilleryAction:randomLandType()
    self:print("randomLandType")
    
    local tBattleData = self:getBattleData()

    local nLeftTeamLineup   = tBattleData.tSrcTeam.lineup.nID
    local nRightTeamLineup  = tBattleData.tDstTeam.lineup.nID
    local nRandomLandType   = tBattleData:randomLand()
    self:playAnimation("playChangeLineupAnimation", nLeftTeamLineup, nRightTeamLineup, nRandomLandType)
end

function KStepArtilleryAction:calcDamage(tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    return self.tLogic:calcDamage(tSrcCard, tDstCard)
end

function KStepArtilleryAction:fire(tCard)
    print("[" .. self:getName() .. "] fire")
    if self.tBattleManager.roundList then
        local tRoundList = self.tBattleManager.roundList.artilleryAction
        return self:guideFire(tRoundList)
    end
    
    local tBattleData           = self:getBattleData()
    
    local tHadActiveTankList    = {}
    while true do
        local tActiveTankList   = tBattleData:getArtilleryActionActiveTank()
        for _, v in ipairs(tHadActiveTankList) do
            for k, card in ipairs(tActiveTankList) do
                if card == v then
                    table.remove(tActiveTankList, k)
                    break
                end
            end
        end
        local tAttackCard = tActiveTankList[1]
        if not tAttackCard then break end

        table.insert(tHadActiveTankList, tAttackCard)
        self:processCardAttack(tAttackCard)
        self:waitSubStepFinish()
        self:emergencyRepairHandle()
    end
end

function KStepArtilleryAction:canEnter()
    local tBattleData    = self:getBattleData()

    local bLeftTeamHasAlive    = tBattleData:isTeamHasLivingCard(true)
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)

    local bCanEnter    = bLeftTeamHasAlive and bRightTeamHasAlive
    return bCanEnter
end

function KStepArtilleryAction:OnArtilleryActionBeforeFire()
    local tBattleData    = self:getBattleData()
    for _, fun in ipairs(tBattleData.tOnArtilleryActionBeforeFire) do
        fun(self)
    end
    tBattleData.tOnArtilleryActionBeforeFire = {}
end

function KStepArtilleryAction:run(nStepIndex)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
    self:checkSkillButtonState()
    self:enableSkill(true)
    self:setSkillUseState("Barrage", false)
    self:showBattleState()
    self:waitSubStepFinish()
    self:moveUnit()
    self:waitSubStepFinish()
    self:scout()
    self:waitSubStepFinish()
    self:randomLandType()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    local KEquip = require("src/battle/KEquip")
    KEquip.effectSmokeBomb(nStepIndex, self:getBattleData(), self:getBattleUI())

    self:OnArtilleryActionBeforeFire()
    self:fire()

    if self.tBattleManager.fnGuideUseSkill then
        local waitID = self.tBattleManager:addWaiting()
        self.tBattleManager.fnGuideUseSkill(waitID)
    end

    self:waitSubStepFinish()
    self:enableSkill(false)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end

return KStepArtilleryAction
