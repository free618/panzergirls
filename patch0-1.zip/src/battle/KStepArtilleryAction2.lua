local KStepArtilleryAction2 = class("KStepArtilleryAction2", require("battle/KBattleStepBase").new)

function KStepArtilleryAction2:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.ARTILLERY_ACTION2
    self.tLogic = require("src/battle/KStepArtilleryAction2Logic").new(tBattleData)
end

function KStepArtilleryAction2:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "ArtilleryAction2")
end

function KStepArtilleryAction2:showDistanceRuler(szStep, nMoveDistance)
    print("[" .. self:getName() .. "] showDistanceRuler", szStep, nMoveDistance)
    self:playAnimation("playDistanceRuleAnimation", szStep, nMoveDistance)
end

function KStepArtilleryAction2:moveUnit()
    print("[" .. self:getName() .. "] moveUnit")
    local tBattleData = self:getBattleData()
    local tAsyncExecList = {}

    local nLightTankType    = 1
    local nMiddleTankType   = 2
    local nHeavyTankType    = 3
    local nAmbushTankType   = 4

    for k, v in ipairs(tBattleData.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_4")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_3")
                table.insert(tAsyncExecList, nID)
                break
            end        

            if v.nCurrentHP > 0 and nTankType == nAmbushTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    for k, v in ipairs(tBattleData.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_4")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and (nTankType == nMiddleTankType or nTankType == nHeavyTankType) then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_3")
                table.insert(tAsyncExecList, nID)
                break
            end

            if v.nCurrentHP > 0 and nTankType == nAmbushTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_2")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    local nID = self:asyncExec(self.showDistanceRuler, self, "ArtilleryAction2", 300)
    table.insert(tAsyncExecList, nID)

    self:waitAsync(tAsyncExecList)
end

function KStepArtilleryAction2:calcDamage(tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    return self.tLogic:calcDamage(tSrcCard, tDstCard)
end

function KStepArtilleryAction2:fire(tCard)
    print("[" .. self:getName() .. "] fire")
    if self.tBattleManager.roundList then
        local tRoundList = self.tBattleManager.roundList.artilleryAction2
        return self:guideFire(tRoundList)
    end
    
    local tBattleData           = self:getBattleData()
    
    local tHadActiveTankList    = {}
    while true do
        local tActiveTankList       = tBattleData:getArtilleryAction2ActiveTank()
        for _, v in ipairs(tHadActiveTankList) do
            for k, card in ipairs(tActiveTankList) do
                if card == v then
                    table.remove(tActiveTankList, k)
                    break
                end
            end
        end
        local tAttackCard = tActiveTankList[1]
        if not tAttackCard then break end

        table.insert(tHadActiveTankList, tAttackCard)
       	self:processCardAttack(tAttackCard)
        tAttackCard.tComboSkill = nil
        self:waitSubStepFinish()
        self:emergencyRepairHandle()    
    end
end

function KStepArtilleryAction2:canEnter()
    local tBattleData   = self:getBattleData()

    local bLeftTeamHasAlive    = tBattleData:isTeamHasLivingCard(true)
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)
    local bHasTankType         = tBattleData:hasLivingCard(CARD_TYPE.HEAVY_TANK)

    local bCanEnter = bLeftTeamHasAlive and bRightTeamHasAlive and bHasTankType
    return bCanEnter
end

function KStepArtilleryAction2:run()
    self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
    self:checkSkillButtonState()
    self:setSkillUseState("Combo", false)
    self:enableSkill(true)
    self:showBattleState()
    self:waitSubStepFinish()
    self:moveUnit()
    self:waitSubStepFinish()
    self:scout()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    self:fire()
    self:waitSubStepFinish()
    self:enableSkill(false)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end

return KStepArtilleryAction2

