
--
-- 远程炮火阶段
--

local KStepArtilleryStrikeLogic = class("KStepArtilleryStrikeLogic")

local TANK_TYPE_COE = 
    {
        [CARD_TYPE.LIGHT_TANK]          = 0.9,
        [CARD_TYPE.MEDIUM_TANK]         = 1.0,
        [CARD_TYPE.HEAVY_TANK]          = 1.2,
        [CARD_TYPE.TANK_DESTORYER]      = 1.0,
        [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.1,
        [CARD_TYPE.TRANSPORT]           = 1.0,
        [CARD_TYPE.BOSS]                = 1.2,
    }

local TANK_TYPE_SCOUT_COE = 
    {
        [CARD_TYPE.LIGHT_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.7, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.8, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.9, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.7, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.5, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.7, 1}, 
            [CARD_TYPE.BOSS]                = {0.9, 1}, 
            [CARD_TYPE.TURRET]              = {0.7, 1},
        },

        [CARD_TYPE.MEDIUM_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.65, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.7, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.8, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.6, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.45, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.7, 1}, 
            [CARD_TYPE.BOSS]                = {0.9, 1}, 
            [CARD_TYPE.TURRET]              = {0.7, 1},
        },

        [CARD_TYPE.HEAVY_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.6, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.65, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.7, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.5, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.4, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.7, 1}, 
            [CARD_TYPE.BOSS]                = {0.8, 1}, 
            [CARD_TYPE.TURRET]              = {0.7, 1},
        },

        [CARD_TYPE.TANK_DESTORYER] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.6, 0.8}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.65, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.7, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.5, 0.9}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.4, 0.7}, 
            [CARD_TYPE.TRANSPORT]           = {0.7, 1}, 
            [CARD_TYPE.BOSS]                = {0.8, 1}, 
            [CARD_TYPE.TURRET]              = {0.7, 1},
        },

        [CARD_TYPE.SELF_PROPELLED_GUN] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {0.6, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.7, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.75, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.5, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.5, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },

        [CARD_TYPE.TRANSPORT] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.9, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.8, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.6, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },

        [CARD_TYPE.BOSS] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.9, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.8, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.6, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },

        [CARD_TYPE.TURRET] = 
        { 
            [CARD_TYPE.LIGHT_TANK]          = {0.75, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {0.8, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {0.9, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.7, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.55, 1}, 
            [CARD_TYPE.TRANSPORT]           = {0.8, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {0.8, 1},
        },
    }
    
local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

function KStepArtilleryStrikeLogic:getTankTypeScoutCoe(tSrcCard, tDstCard)
    return TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][1]
end

function KStepArtilleryStrikeLogic:ctor(tBattleData)
    self.tBattleData = tBattleData
end

local HIT_RANGE = {0.05, 0.9} -- 命中限定区间
-- 命中
function KStepArtilleryStrikeLogic:callHitRate(tSrcCard, tDstCard)
    if tDstCard.bBrokenProtect and tDstCard.nCurrentHP == 1 then
        print("----> [第二轮炮战] 命中计算 [结束], 未命中：因为大破保护 ")
        return false
    end
    local nSrcLevel         = self.tBattleData:getLevel(tSrcCard)                   -- 攻击方 等级
    local nSrcHitRate       = self.tBattleData:getHitRate(tSrcCard)                 -- 攻击方 命中
    local nSrcScoutHitRate  = self.tBattleData:getScoutHitRate(tSrcCard, tDstCard)  -- 攻击方 侦查命中补正
    local nSrcLineupHitRate = self.tBattleData:getLineupHitRate(tSrcCard)           -- 攻击方 阵法命中补正
    local nSrcStateHitRateCoe     = self.tBattleData:getStateHitRateCoe(tSrcCard)                -- 攻击方 耐久和士气影响系数
    local nSrcAbilityHitRate = self.tBattleData:getAbilityHitRate(tSrcCard)         -- 攻击方 被动技能命中率补正

    local nDstDodge         = self.tBattleData:getDodge(tDstCard, true)                   -- 目标 闪避
    local nDstLineupDodge   = self.tBattleData:getLineupDodge(tDstCard)             -- 目标 阵形闪避
    local nDstTankTypeCode  = getTankTypeCoe(tDstCard)                              -- 目标 坦克类型补正
    local nDstAbilityDodge  = self.tBattleData:getAbilityDodge(tDstCard)            -- 目标 坦克被动技能补正

    local nHitRate = ((1.0 + (nSrcLevel / 400) + nSrcHitRate + nSrcScoutHitRate + nSrcLineupHitRate + nSrcAbilityHitRate) - (nDstDodge / (nDstDodge + 15) + nDstLineupDodge + nDstAbilityDodge)) * nDstTankTypeCode * nSrcStateHitRateCoe;
    nHitRate = KUtil.makeInRange(nHitRate, HIT_RANGE)

    local nRandomValue = random()
    local bHitted = nRandomValue < nHitRate

    print("----> [远程炮火] 命中计算 [开始]")
    print("---------> 攻击方 等级：",               nSrcLevel)
    print("---------> 攻击方 命中：",               nSrcHitRate)
    print("---------> 攻击方 侦查命中补正：",       nSrcScoutHitRate)
    print("---------> 攻击方 阵形加成：",           nSrcLineupHitRate)
    print("---------> 攻击方 耐久和士气补正：",     nSrcStateHitRateCoe)
    print("---------> 攻击方 被动技能命中补正：",   nSrcAbilityHitRate)
    print("---------> 目标   闪避：",               nDstDodge)
    print("---------> 目标   阵形补正：",           nDstLineupDodge)
    print("---------> 目标   坦克类型加成：",       nDstTankTypeCode)
    print("---------> 目标   被动技能补正：",       nDstAbilityDodge)
    print("----> [远程炮火] 命中计算 [结束], 命中率：", nHitRate, " 随机值：", nRandomValue, " 命中：", bHitted)

    return bHitted
end

local PIERCE_ADJUST_RANGE   = {0.7, 1.3}     -- 穿甲随机补正系数
local PIERCE_RESULT_RANGE1  = {0.05, 0.2}    -- 穿甲成功后的随机范围
local PIERCE_RESULT_RANGE2  = {0.01, 0.05}   -- 穿甲失败后的随机范围
-- 穿甲
function KStepArtilleryStrikeLogic:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstArmourLineupCoe)
    -- nDstArmour 目标放 护甲
    local nPierceEffectRate     = self.tBattleData:getPierceEffectRate(tDstCard)           -- 目标 穿透生效率
    local nRandomValue = random()
    print("----> [远程炮火] 穿甲计算 [开始], 穿甲生效概率：", nPierceEffectRate, "随机值：", nRandomValue)
    local bEffect = nRandomValue < nPierceEffectRate
    if bEffect then 
        print("----> [远程炮火] 穿甲计算 [结束], 未穿甲：穿甲未生效 ")
        return false, nRandomValue 
    end

    local nSrcPenetrate         = self.tBattleData:getPenetrate(tSrcCard)             -- 攻击方 穿透
    local nSrcRandomAdjustCoe   = random(PIERCE_ADJUST_RANGE)                         -- 攻击方 随机补正系数
    local nSrcLineupCoe         = self.tBattleData:getLineupPenetrate(tSrcCard)       -- 攻击方 阵形穿透加成
    local nSrcStatePenetrateCoe = self.tBattleData:getStatePenetrateCoe(tSrcCard)       -- 穿透影响系数
    local nAttackAddtion 	    = TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]				-- 距离衰减系数

    local nPierceValue = (nSrcPenetrate * nSrcRandomAdjustCoe * nSrcLineupCoe * nSrcStatePenetrateCoe * nAttackAddtion) - nDstArmour * nDstArmourLineupCoe -- 最终穿透值
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --if tSrcCard.nNamedType == CARD_TYPE.SELF_PROPELLED_GUN then bPierced = true end 
    if bPierced then
        nRandomValue = random(PIERCE_RESULT_RANGE1)
    else
        nRandomValue = random(PIERCE_RESULT_RANGE2)
    end

    print("----> [远程炮火] 穿甲计算 [开始]")
    print("--------> 攻击方 穿透：",     nSrcPenetrate)
    print("--------> 攻击方 随机加成：", nSrcRandomAdjustCoe)
    print("--------> 攻击方 阵形加成：", nSrcLineupCoe)
    print("--------> 目标   护甲：",     nDstArmour)
    print("--------> 目标   阵形加成：", nDstArmourLineupCoe)
    print("----> [远程炮火] 穿甲计算 [结束], 最终穿透值：", nPierceValue, "是否穿透：", bPierced, " 随机值：", nRandomValue)

    return bPierced, nRandomValue
end

local THUMP_ADJUST_RANGE    = {0.7, 1.3}   -- 随机家加成范围
local THUMP_RATE_RANGE      = {0.05, 0.8}  -- 重击率最小最大值
local THUMP_MUTI            = 1.5            -- 重击倍率
-- 重击
function KStepArtilleryStrikeLogic:calcThumpRate(tSrcCard, tDstCard, nDstArmour)
    -- nDstArmour 目标放 护甲

    local nSrcAttack            = self.tBattleData:getAttack(tSrcCard)              -- 攻击方 火力
    local nSrcRandomCoe         = random(THUMP_ADJUST_RANGE)                        -- 攻击方 随机系数
    local nSrcStateAttackCoe    = self.tBattleData:getStateAttackCoe(tSrcCard)      -- 火力影响系数

    local nThumpValue = (nSrcAttack * nSrcStateAttackCoe - nDstArmour) / 50.0 * nSrcRandomCoe
    nThumpValue = KUtil.makeInRange(nThumpValue, THUMP_RATE_RANGE)

    local nRandomValue = random()
    local bThump = nRandomValue < nThumpValue
    local nThumpMutiValue = 1
    if bThump then
        nThumpMutiValue = THUMP_MUTI
    end

    print("----> [远程炮火] 重击计算 [开始]")
    print("--------> 攻击方 火力：",      nSrcAttack)
    print("--------> 攻击方 随机系数：",  nSrcRandomCoe)
    print("--------> 目标   护甲：",      nDstArmour)
    print("----> [远程炮火] 重击计算 [结束] 重击最终值：", nThumpValue, " 随机值：", nRandomValue, " 重击：", bThump, "重击倍率：", nThumpMutiValue)

    return bThump, nThumpMutiValue
end

local DAMAGE_ADJUST_RANGE   = {0.7, 1.3}    -- 伤害随机补正范围
local REAR_ARMOUR_RATE      = 0.3           -- 选择后装甲的概率
-- 伤害
function KStepArtilleryStrikeLogic:calcDamage(tSrcCard, tDstCard, nEquipPos)
    print("----> [远程炮火] 伤害计算 [开始]", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, nEquipPos)
    local nSrcLineupAttackRearArmourRate = self.tBattleData:getLineupAttackRearArmourRate(tSrcCard, tDstCard)
    local nAttackRearArmourRate      = REAR_ARMOUR_RATE + nSrcLineupAttackRearArmourRate
    local nDstArmour = tDstCard.nFrontArmour
    local nDstLineupArmour  = self.tBattleData:getLineupFrontArmour(tSrcCard)                -- 目标 阵形前护甲加成
    local nRandomValueForArmour = random()
    if nRandomValueForArmour < nAttackRearArmourRate then
        nDstArmour = tDstCard.nRearArmour
        nDstLineupArmour = self.tBattleData:getLineupRearArmour(tSrcCard)              -- 目标 阵形后护甲加成
    end

    print("--------> [远程炮火] 目标护甲选择, 随机值：", nRandomValueForArmour, "后装甲概率：", nAttackRearArmourRate, " 装甲值：", nDstArmour)

    local bHit = self:callHitRate(tSrcCard, tDstCard)
    if not bHit then
        print("----> [远程炮火] 伤害计算 [结束], 未命中!")
        return ATTACK_RESULT.MISS, 0
    end

    local bPierce, nMinDamagePercent = self:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstLineupArmour)
--    if not bPierce then
--        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
--        if nDamage < 0 then nDamage = 0 end
--        print("----> [远程炮火] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
--        return nDamage
--    end

    local bThump, nThumpCoe = self:calcThumpRate(tSrcCard, tDstCard, nDstArmour)        --bThump 是否重击 nThumpCoe 重击倍率
    local nSrcAttack        = self.tBattleData:getAttack(tSrcCard)                      -- 攻击方 火力
    local nShellAttack      = self.tBattleData:getEquipAttack(tSrcCard, nEquipPos)      -- 攻击方 炮弹攻击力
    local nSrcLineupAttack  = self.tBattleData:getLineupAttack(tSrcCard)                -- 攻击方 阵形攻击加成
    local nSrcAmmoCount     = self.tBattleData:getEquipAmmoCount(tSrcCard, nEquipPos)   -- 攻击方 弹药数量
    local nSrcRandomCoe     = random(DAMAGE_ADJUST_RANGE)                               -- 攻击方 随机系数
    local nSrcStateAttackCoe= self.tBattleData:getStateAttackCoe(tSrcCard)              -- 火力影响系数
    local nAttackAddtion 	= TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]				-- 距离衰减系数

    --旧公式
    --local nDamage = (((nSrcAttack * 0.2) + nShellAttack * math.sqrt(nSrcAmmoCount) + 5)* nSrcRandomCoe * nSrcLineupAttack * nSrcStateAttackCoe - nDstArmour * nDstLineupArmour) * nThumpCoe

    local nPierceCoe
    if bPierce then
        nPierceCoe = 3   -- 穿甲系数
    else 
        nPierceCoe = 10  -- 未穿甲系数
		nThumpCoe = 1
    end

    --新公式
    local stcMaxDamage = ((math.sqrt(nSrcAttack * nSrcStateAttackCoe * nSrcLineupAttack) + nShellAttack * 3) * nSrcRandomCoe * nAttackAddtion )/ (nDstArmour * nDstLineupArmour * nPierceCoe)
    if stcMaxDamage > 1 then stcMaxDamage = 1 end 
    local nDamage = nSrcAttack * stcMaxDamage * nThumpCoe

    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)

    print("---------> 穿透系数：",               nMinDamagePercent)
    print("---------> 重击倍率：",               nThumpCoe)
    print("---------> 攻击方 火力：",            nSrcAttack)
    print("---------> 攻击方 弹药攻击力：",      nShellAttack)
    print("---------> 攻击方 弹药数：",          nSrcAmmoCount)
    print("---------> 攻击方 阵形攻击加成：",    nSrcLineupAttack)
    print("---------> 攻击方 随机系数：",        nSrcRandomCoe)
    print("---------> 目标   护甲：",            nDstArmour)
    print("---------> 目标   阵形护甲加成：",    nDstLineupArmour)
    print("----> [远程炮火] 伤害计算 [结束] 最终伤害值：", nDamage)

    if not bPierce then 
		return ATTACK_RESULT.RICOCHET, nDamage
    end

    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage
end

function KStepArtilleryStrikeLogic:getAttackerList()
    return self.tBattleData:getAllLivingAndNotBigBrokenCard(CARD_TYPE.SELF_PROPELLED_GUN)
end

return KStepArtilleryStrikeLogic
