local KStepDogFight = class("KStepDogFight",  require("battle/KBattleStepBase").new)

function KStepDogFight:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.DOG_FIGHT
    self.tLogic = require("src/battle/KStepDogFightActionLogic").new(tBattleData)
end

function KStepDogFight:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "DogFight")
end

function KStepDogFight:showDistanceRuler(szStep, nMoveDistance)
    print("[" .. self:getName() .. "] showDistanceRuler", szStep, nMoveDistance)
    self:playAnimation("playDistanceRuleAnimation", szStep, nMoveDistance)
end

function KStepDogFight:moveUnit()
    print("[" .. self:getName() .. "] moveUnit")
    local tBattleData = self:getBattleData()
    local tAsyncExecList = {}

    local nLightTankType    = 1
    local nMiddleTankType   = 2

    for k, v in ipairs(tBattleData.tSrcTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_5")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and nTankType == nMiddleTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_4")
                table.insert(tAsyncExecList, nID)
                break
            end     
        end
    end

    for k, v in ipairs(tBattleData.tDstTeam) do
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if v.nCurrentHP > 0 and nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_5")
                table.insert(tAsyncExecList, nID)
                break
            end
        
            if v.nCurrentHP > 0 and nTankType == nMiddleTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_4")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    local nID = self:asyncExec(self.showDistanceRuler, self, "DogFight", 50)
    table.insert(tAsyncExecList, nID)

    self:waitAsync(tAsyncExecList)
end

function KStepDogFight:calcDamage(tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    return self.tLogic:calcDamage(tSrcCard, tDstCard)
end

function KStepDogFight:fire()
    print("[" .. self:getName() .. "] fire")
    if self.tBattleManager.roundList then
        local tRoundList = self.tBattleManager.roundList.dogFight
        return self:guideFire(tRoundList)
    end
    
    local tBattleData = self:getBattleData()

    local tHadActiveTankList    = {}
    while true do
        local tActiveTankList       = tBattleData:getDogFightActiveTank()
        for _, v in ipairs(tHadActiveTankList) do
            for k, card in ipairs(tActiveTankList) do
                if card == v then
                    table.remove(tActiveTankList, k)
                    break
                end
            end
        end
        local tAttackCard = tActiveTankList[1]
        if not tAttackCard then break end

        table.insert(tHadActiveTankList, tAttackCard)
        self:processAttackOnce(tAttackCard)
        self:waitSubStepFinish()
        self:emergencyRepairHandle()
    end
end

function KStepDogFight:canEnter()
    local tBattleData    = self:getBattleData()

    local bLeftTeamHasAlive    = tBattleData:isTeamHasLivingCard(true)
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)
    local bHasLightTank        = tBattleData:hasLivingCard(CARD_TYPE.LIGHT_TANK)
    local bHasMediumTank       = tBattleData:hasLivingCard(CARD_TYPE.MEDIUM_TANK)

    local bHasTankType = bHasLightTank or bHasMediumTank
    local bCanEnter = bLeftTeamHasAlive and bRightTeamHasAlive and bHasTankType
    return bCanEnter
end

function KStepDogFight:run()
    self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
    self:checkSkillButtonState()
    self:setSkillUseState("Landmine", false)
    self:enableSkill(true)
    self:showBattleState()
    self:waitSubStepFinish()
    self:moveUnit()
    self:waitSubStepFinish()
    self:scout()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    self:fire()
    self:waitSubStepFinish()
    self:enableSkill(false)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end

return KStepDogFight

