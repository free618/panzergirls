
--
-- 缠斗
--

local KStepDogFightActionLogic = class("KStepDogFightActionLogic")

function KStepDogFightActionLogic:ctor(tBattleData)
	self.tBattleData = tBattleData
end

local TANK_TYPE_COE = 
{
    [CARD_TYPE.LIGHT_TANK]          = 0.8,
    [CARD_TYPE.MEDIUM_TANK]         = 0.9,
    [CARD_TYPE.HEAVY_TANK]          = 1.0,
    [CARD_TYPE.TANK_DESTORYER]      = 1.1,
    [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.1,
    [CARD_TYPE.TRANSPORT]           = 1.0,
    [CARD_TYPE.BOSS]                = 1.0,
}

local TANK_TYPE_SCOUT_COE = 
    {
        [CARD_TYPE.LIGHT_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1.5, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1.5, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.5, 1.1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1.5, 1.1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1.5, 1.1}, 
            [CARD_TYPE.TRANSPORT]           = {1.5, 1}, 
            [CARD_TYPE.BOSS]                = {1.5, 1}, 
            [CARD_TYPE.TURRET]              = {1.5, 1},
        },

        [CARD_TYPE.MEDIUM_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1.25, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1.25, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.25, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1.25, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1.25, 1}, 
            [CARD_TYPE.TRANSPORT]           = {1.25, 1}, 
            [CARD_TYPE.BOSS]                = {1.25, 1}, 
            [CARD_TYPE.TURRET]              = {1.25, 1},
        },

        [CARD_TYPE.HEAVY_TANK] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1, 0.85}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1.2, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.TANK_DESTORYER] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.9, 0.8}, 
            [CARD_TYPE.TRANSPORT]           = {1.1, 1}, 
            [CARD_TYPE.BOSS]                = {1.2, 1}, 
            [CARD_TYPE.TURRET]              = {1.1, 1},
        },

        [CARD_TYPE.SELF_PROPELLED_GUN] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {0.9, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.9, 1}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1.2, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.TRANSPORT] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {0.9, 0.9}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.BOSS] = 
        {
            [CARD_TYPE.LIGHT_TANK]          = {1.1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1.1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.1, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1, 0.7}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1.1, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },

        [CARD_TYPE.TURRET] = 
        { 
            [CARD_TYPE.LIGHT_TANK]          = {1, 1}, 
            [CARD_TYPE.MEDIUM_TANK]         = {1.1, 1}, 
            [CARD_TYPE.HEAVY_TANK]          = {1.2, 1}, 
            [CARD_TYPE.TANK_DESTORYER]      = {1, 1}, 
            [CARD_TYPE.SELF_PROPELLED_GUN]  = {1, 0.7}, 
            [CARD_TYPE.TRANSPORT]           = {1, 1}, 
            [CARD_TYPE.BOSS]                = {1.2, 1}, 
            [CARD_TYPE.TURRET]              = {1, 1},
        },
    }
    
local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

function KStepDogFightActionLogic:getTankTypeScoutCoe(tSrcCard, tDstCard)
    return TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][1]
end

local HIT_RANGE = {0.05, 0.9} -- 命中限定区间
-- 命中
function KStepDogFightActionLogic:callHitRate(tSrcCard, tDstCard)
    if tDstCard.bBrokenProtect and tDstCard.nCurrentHP == 1 then
        print("----> [第二轮炮战] 命中计算 [结束], 未命中：因为大破保护 ")
        return false
    end
    local nSrcLevel         = self.tBattleData:getLevel(tSrcCard)                   -- 攻击方 等级
    local nSrcHitRate       = self.tBattleData:getHitRate(tSrcCard)                 -- 攻击方 命中
    local nSrcScoutHitRate  = self.tBattleData:getScoutHitRate(tSrcCard, tDstCard)  -- 攻击方 侦查命中补正
    local nSrcLineupHitRate = self.tBattleData:getLineupHitRate(tSrcCard)           -- 攻击方 阵法命中补正
    local nSrcStateHitRateCoe     = self.tBattleData:getStateHitRateCoe(tSrcCard)                -- 攻击方 耐久和士气影响系数
    local nSrcAbilityHitRate = self.tBattleData:getAbilityHitRate(tSrcCard)         -- 攻击方 被动技能命中率补正

    local nDstDodge         = self.tBattleData:getDodge(tDstCard, true)                   -- 目标 闪避
    local nDstLineupDodge   = self.tBattleData:getLineupDodge(tDstCard)             -- 目标 阵形闪避
    local nDstTankTypeCode  = getTankTypeCoe(tDstCard)                              -- 目标 坦克类型补正
    local nDstAbilityDodge  = self.tBattleData:getAbilityDodge(tDstCard)            -- 目标 坦克被动技能补正

 	local nHitRate = ((1.0 + (nSrcLevel / 500) + nSrcHitRate + nSrcScoutHitRate + nSrcLineupHitRate + nSrcAbilityHitRate) - (nDstDodge / (nDstDodge + 40) + nDstLineupDodge + nDstAbilityDodge)) * nSrcStateHitRateCoe * nDstTankTypeCode
	nHitRate = KUtil.makeInRange(nHitRate, HIT_RANGE)

    local nRandomValue = random()
    local bHitted = nRandomValue < nHitRate

    print("----> [缠斗] 命中计算 [开始]")
    print("---------> 攻击方 等级：",               nSrcLevel)
    print("---------> 攻击方 命中：",               nSrcHitRate)
    print("---------> 攻击方 侦查命中补正：",       nSrcScoutHitRate)
    print("---------> 攻击方 阵形加成：",           nSrcLineupHitRate)
    print("---------> 攻击方 耐久和士气补正：",     nSrcStateHitRateCoe)
    print("---------> 攻击方 被动技能补正：",       nSrcAbilityHitRate)
    print("---------> 目标   闪避：",               nDstDodge)
    print("---------> 目标   阵形补正：",           nDstLineupDodge)
    print("---------> 目标   坦克类型加成：",       nDstTankTypeCode)
    print("---------> 目标   坦克被动技能补正：",   nDstAbilityDodge)
    print("----> [缠斗] 命中计算 [结束], 命中率：", nHitRate, " 随机值：", nRandomValue, " 命中：", bHitted)

    return bHitted
end

local PIERCE_ADJUST_RANGE   = {0.7, 1.3}     -- 穿甲随机补正系数
local PIERCE_RESULT_RANGE1  = {0.05, 0.2}    -- 穿甲成功后的随机范围
local PIERCE_RESULT_RANGE2  = {0.01, 0.05}   -- 穿甲失败后的随机范围
-- 穿甲
function KStepDogFightActionLogic:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstArmourLineupCoe)
	-- nDstArmour 目标放 护甲
    local nPierceEffectRate     = self.tBattleData:getPierceEffectRate(tDstCard)           -- 目标 穿透生效率
    local nRandomValue = random()
    print("----> [缠斗] 穿甲计算 [开始], 穿甲生效概率：", nPierceEffectRate, "随机值：", nRandomValue)
    local bEffect = nRandomValue < nPierceEffectRate
    if bEffect then 
        print("----> [缠斗] 穿甲计算 [结束], 未穿甲：穿甲未生效 ")
        return false, nRandomValue 
    end

	local TANK_TYPE_COE = 
{
    [CARD_TYPE.LIGHT_TANK]          = 1.0,
    [CARD_TYPE.MEDIUM_TANK]         = 1.2,
    [CARD_TYPE.HEAVY_TANK]          = 1.0,
    [CARD_TYPE.TANK_DESTORYER]      = 1.0,
    [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
    [CARD_TYPE.TRANSPORT]           = 1.0,
    [CARD_TYPE.BOSS]                = 1.0,
}

local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

    local nSrcPenetrate         = self.tBattleData:getPenetrate(tSrcCard)             -- 攻击方 穿透
    local nSrcRandomAdjustCoe   = random(PIERCE_ADJUST_RANGE)                         -- 攻击方 随机补正系数
    local nSrcLineupCoe         = self.tBattleData:getLineupPenetrate(tSrcCard)       -- 攻击方 阵形穿透加成
	local nSrcSpeed 			= self.tBattleData:getSpeed(tSrcCard)				  -- 攻击方 速度
	local nSrcStatePenetrateCoe   = self.tBattleData:getStatePenetrateCoe(tSrcCard)       -- 穿透影响系数
	local nSrcTankTypeCode  = getTankTypeCoe(tSrcCard)                              -- 目标 坦克类型补正
    local nAttackAddtion 	= TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]				-- 距离衰减系数

	local nPierceValue = (nSrcPenetrate + nSrcSpeed * nSrcTankTypeCode * 0.3) * nSrcRandomAdjustCoe * nSrcLineupCoe * nSrcStatePenetrateCoe * nAttackAddtion - nDstArmour * nDstArmourLineupCoe
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    if bPierced then
        nRandomValue = random(PIERCE_RESULT_RANGE1)
    else
        nRandomValue = random(PIERCE_RESULT_RANGE2)
    end

    print("----> [缠斗] 穿甲计算 [开始]")
    print("--------> 攻击方 穿透：",     nSrcPenetrate)
    print("--------> 攻击方 随机加成：", nSrcRandomAdjustCoe)
    print("--------> 攻击方 阵形加成：", nSrcLineupCoe)
    print("--------> 攻击方 速度：", 	 nSrcSpeed)
    print("--------> 目标   护甲：",     nDstArmour)
    print("--------> 目标   阵形加成：", nDstArmourLineupCoe)
    print("----> [缠斗] 穿甲计算 [结束], 最终穿透值：", nPierceValue, "是否穿透：", bPierced, " 随机值：", nRandomValue)

    return bPierced, nRandomValue
end

local THUMP_ADJUST_RANGE    = {0.7, 1.3}   -- 随机家加成范围
local THUMP_RATE_RANGE      = {0.05, 0.8}  -- 重击率最小最大值
local THUMP_MUTI            = 1.5          -- 重击倍率
-- 重击
function KStepDogFightActionLogic:calcThumpRate(tSrcCard, tDstCard, nDstArmour)
    -- nDstArmour 目标放 护甲

	local TANK_TYPE_COE = 
{
    [CARD_TYPE.LIGHT_TANK]          = 1.0,
    [CARD_TYPE.MEDIUM_TANK]         = 1.2,
    [CARD_TYPE.HEAVY_TANK]          = 1.0,
    [CARD_TYPE.TANK_DESTORYER]      = 1.0,
    [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
    [CARD_TYPE.TRANSPORT]           = 1.0,
    [CARD_TYPE.BOSS]                = 1.0,
}

local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

    local nSrcAttack 	= self.tBattleData:getAttack(tSrcCard)          -- 攻击方 火力
    local nSrcRandomCoe = random(THUMP_ADJUST_RANGE)                    -- 攻击方 随机系数
	local nSrcThump 	= self.tBattleData:getThump(tSrcCard)			-- 攻击方 重击率
	local nSrcSpeed		= self.tBattleData:getSpeed(tSrcCard)			-- 攻击方 速度
	local nSrcStateAttackCoe      = self.tBattleData:getStateAttackCoe(tSrcCard)          -- 火力影响系数
	local nSrcTankTypeCode  = getTankTypeCoe(tSrcCard)                              -- 目标 坦克类型补正

	local nThumpValue = ((nSrcAttack + nSrcSpeed * nSrcTankTypeCode * 0.2) * nSrcStateAttackCoe - nDstArmour ) / 40.0 * nSrcRandomCoe + nSrcThump
	nThumpValue = KUtil.makeInRange(nThumpValue, THUMP_RATE_RANGE)

    local nRandomValue = random()
    local bThump = nRandomValue < nThumpValue
    local nThumpMutiValue = 1
    if bThump then
        nThumpMutiValue = THUMP_MUTI
    end

    print("----> [缠斗] 重击计算 [开始]")
    print("--------> 攻击方 火力：",      nSrcAttack)
    print("--------> 攻击方 随机系数：",  nSrcRandomCoe)
    print("--------> 攻击方 重击率：",    nSrcThump)
    print("--------> 攻击方 速度：",  	  nSrcSpeed)
    print("--------> 目标   护甲：",      nDstArmour)
    print("----> [缠斗] 重击计算 [结束] 重击最终值：", nThumpValue, " 随机值：", nRandomValue, " 重击：", bThump, "重击倍率：", nThumpMutiValue)

    return bThump, nThumpMutiValue
end

-- 擦伤
function KStepDogFightActionLogic:calcGraze(tSrcCard, tDstCard)
    local nRandomValue  = random()
    local KBattleConfig = require("src/battle/KBattleConfig")
    local nGrazeRate   = KBattleConfig.getGrazeRate(tDstCard)
    local tGrazeRange  = KBattleConfig.getGrazeRange(tDstCard)

    local bGrazed   = nRandomValue <= nGrazeRate and tGrazeRange ~= nil
    if not bGrazed then
        print("----> [缠斗] 擦伤计算 [结束], 未擦伤：擦伤未生效 ")
        return false, 0
    end

    local nRandomValue = random(tGrazeRange)
    local nDstMaxHP    = tDstCard.nMaxHP
    local nGrazeValue  = math.max(1, math.floor(nDstMaxHP * nRandomValue))
    
    print("----> [缠斗] 擦伤计算 [开始]")
    print("--------> 目标 随机擦伤率：", nRandomValue)
    print("--------> 目标 最大血量", nDstMaxHP)
    print("----> [缠斗] 擦伤计算 [结束], 最终擦伤值：", nGrazeValue, "是否擦伤：", bGrazed, " 随机值：", nRandomValue)

    return bGrazed, nGrazeValue
end

local DAMAGE_ADJUST_RANGE   = {0.7, 1.3}    -- 伤害随机补正范围
local REAR_ARMOUR_RATE      = 1             -- 选择后装甲的概率
-- 伤害
function KStepDogFightActionLogic:calcDamage(tSrcCard, tDstCard)

	local TANK_TYPE_COE = 
{
    [CARD_TYPE.LIGHT_TANK]          = 1.0,
    [CARD_TYPE.MEDIUM_TANK]         = 1.2,
    [CARD_TYPE.HEAVY_TANK]          = 1.0,
    [CARD_TYPE.TANK_DESTORYER]      = 1.0,
    [CARD_TYPE.SELF_PROPELLED_GUN]  = 1.0,
    [CARD_TYPE.TRANSPORT]           = 1.0,
    [CARD_TYPE.BOSS]                = 1.0,
}

local function getTankTypeCoe(tCard)
    return TANK_TYPE_COE[tCard.nNamedType]
end

	print("----> [缠斗] 伤害计算 [开始]", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex)
    local nSrcLineupAttackRearArmourRate = self.tBattleData:getLineupAttackRearArmourRate(tSrcCard, tDstCard)
    local nAttackRearArmourRate      = REAR_ARMOUR_RATE + nSrcLineupAttackRearArmourRate
    local nDstArmour = tDstCard.nFrontArmour
    local nDstLineupArmour  = self.tBattleData:getLineupFrontArmour(tSrcCard)                -- 目标 阵形前护甲加成
    local nRandomValueForArmour = random()
    if nRandomValueForArmour < nAttackRearArmourRate then
        nDstArmour = tDstCard.nRearArmour
        nDstLineupArmour = self.tBattleData:getLineupRearArmour(tSrcCard)              -- 目标 阵形后护甲加成
    end
	print("--------> [缠斗] 目标护甲选择, 随机值：", nRandomValueForArmour, "后装甲概率：", nAttackRearArmourRate, " 装甲值：", nDstArmour)

	local bHit = self:callHitRate(tSrcCard, tDstCard)
	if not bHit then
        local bGrazed, nGrazeValue =  self:calcGraze(tSrcCard, tDstCard)
        if bGrazed then
            print("----> [缠斗] 伤害计算 [结束], 擦伤! 擦伤值：", nGrazeValue)
            return ATTACK_RESULT.GRAZE, nGrazeValue
        else
            print("----> [缠斗] 伤害计算 [结束], 未命中!")
            return ATTACK_RESULT.MISS, 0
        end
	end

    local bPierce, nMinDamagePercent = self:calcPierce(tSrcCard, tDstCard, nDstArmour, nDstLineupArmour) -- bPierce:是否穿甲, nMinDamagePercent ： 最小百分比
    if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("----> [缠斗] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, nDamage
    end

	local bThump, nThumpCoe = self:calcThumpRate(tSrcCard, tDstCard, nDstArmour)		--bThump 是否重击 nThumpCoe 重击倍率

   	local nSrcAttack        = self.tBattleData:getAttack(tSrcCard)                      -- 攻击方 火力    
    local nSrcRandomCoe     = random(DAMAGE_ADJUST_RANGE)                               -- 攻击方 随机系数
    local nSrcLineupAttack  = self.tBattleData:getLineupAttack(tSrcCard)                -- 攻击方 阵形攻击加成
	local nSrcSpeed 		= self.tBattleData:getSpeed(tSrcCard)						-- 攻击方 速度
	local nSrcStateAttackCoe      = self.tBattleData:getStateAttackCoe(tSrcCard)        -- 火力影响系数
	local nSrcTankTypeCode  = getTankTypeCoe(tSrcCard)                                  -- 目标 坦克类型补正
    local nAttackAddtion 	= TANK_TYPE_SCOUT_COE[tSrcCard.nNamedType][tDstCard.nNamedType][2]				-- 距离衰减系数

	local nDamage = ((nSrcAttack + nSrcSpeed * nSrcTankTypeCode * 0.3) * nSrcRandomCoe * nSrcLineupAttack * nSrcStateAttackCoe * nAttackAddtion - nDstArmour * nDstLineupArmour )*nThumpCoe
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)

    print("---------> 穿透系数：",               nMinDamagePercent)
    print("---------> 重击倍率：",               nThumpCoe)
    print("---------> 攻击方 火力：",          	 nSrcAttack)
    print("---------> 攻击方 阵形攻击加成：",    nSrcLineupAttack)
    print("---------> 攻击方 随机系数：",        nSrcRandomCoe)
    print("---------> 攻击方 速度：",        	 nSrcSpeed)
    print("---------> 目标   护甲：",            nDstArmour)
    print("---------> 目标   阵形护甲加成：",    nDstLineupArmour)
    print("----> [缠斗] 伤害计算 [结束] 最终伤害值：", nDamage)
	
    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage 
end

return KStepDogFightActionLogic
