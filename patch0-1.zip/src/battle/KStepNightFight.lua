local KStepNightFight = class("KStepNightFight", require("battle/KBattleStepBase").new)

function KStepNightFight:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.NIGHT_FIGHT
    self.tLogic = require("src/battle/KStepNightFightLogic").new(tBattleData)
end

function KStepNightFight:canEnter()
    print("[" .. self:getName() .. "] showAskIfNightFight")

    local tBattleData       = self:getBattleData()
    if tBattleData.bBeginAtNightFight then
        return true
    end
    
    local bRightTeamHasAlive   = tBattleData:isTeamHasLivingCard(false)
    if bRightTeamHasAlive == false then return false end
    
    local isGuide = false
    if self:getBattleData().nbattleType == BATTLE_TYPE.GUIDE then
        isGuide = true
        require("src/logic/KGuideEnv").addNextGuideNode()
    end

    self:playAnimation("playAskIfNightFightAnimation", isGuide)
    return tBattleData:ifEnterNightFight()
end

function KStepNightFight:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "NightFight")
end

function KStepNightFight:processNormalAttack(tSrcCard, tDstCard, nType, nDamage)
    -- 被动技能埋点
    local tParam = {tDstCard = tDstCard}
    self:checkPoint(ABILITY_CHECK_POINT.CARD_BEFORE_ATTACK, tSrcCard, tDstCard, nDamage, nType, tParam)
    tDstCard = tParam.tDstCard
    -- 
    
    local tTaskIDList = {}

    local bShowAbilityAnimation = false
    local crossStartFrame = 0
    local crossFireFrame  = 60
    if tSrcCard.tAbilityList then
        for _, oneAbility in ipairs(tSrcCard.tAbilityList) do
            if oneAbility.bShowAttackAnimation then
                bShowAbilityAnimation = true
                local nID = self:asyncExec(self.playAnimation, self, "playCardAbilityAnimation", tSrcCard, oneAbility.nAbilityID)
                table.insert(tTaskIDList, nID)
                break
            end
        end
    end
    if not bShowAbilityAnimation then
        crossFireFrame = 30
        local nID = self:asyncExec(self.playAnimation, self, "playNightCardRoleAttackAnimation", tSrcCard)    
        table.insert(tTaskIDList, nID)
    end

    local nID = self:asyncExec(self.playAnimation, self, "playCardAttackBeginAnimation", tSrcCard)
	table.insert(tTaskIDList, nID)

    self:delay((crossFireFrame - crossStartFrame) / 60)

    self:playAnimation("playCardFireAnimation", tSrcCard)
    KSound.playEffect("fire")

    self:playAnimation("playBulletFireAnimation", tSrcCard, tDstCard)
    KSound.playEffect("boom")
    
    local nBulletID = self:addBullet(tSrcCard, tDstCard, nType, nDamage)
    self:playAnimation("playNightBulletBlastAnimation", tDstCard)
    self:playAnimation("playCardAttackEndAnimation", tSrcCard)

    local KBattleConfig = require("battle/KBattleConfig")
    local oldCardState  = KBattleConfig.getBrokenState(tDstCard)
    local bIsLeftTeam   = tDstCard.bLeftSide
    
    self:applyBulletDamage(nBulletID)

    -- 被动技能埋点
    self:checkPoint(ABILITY_CHECK_POINT.CARD_AFTER_ATTACK, tSrcCard, tDstCard, nDamage, nType)
    --
    local newCardState  = KBattleConfig.getBrokenState(tDstCard)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self:playBrokenAnimation(tDstCard)
    end
    
    if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        self:playFightDestroyAnimation(tDstCard)
    end
end

function KStepNightFight:processComboAttack(tSrcCard, tDstCard, nDamage)
    local nType                 = ATTACK_RESULT.CRIT
    local nBulletID             = self:addBullet(tSrcCard, tDstCard, nType, nDamage)
    local KBattleConfig         = require("battle/KBattleConfig")
    local oldCardState          = KBattleConfig.getBrokenState(tDstCard)
    local nOldHP, nCurrentHP    = self:getBattleData():costHP(tDstCard, nDamage, tSrcCard)
    local newCardState          = KBattleConfig.getBrokenState(tDstCard)

    KSound.playEffect("fire")
    self:playAnimation("playCardRoleComboAttackAnimation", tSrcCard)
    self:playNightBlastLeftAnimation(tSrcCard, tDstCard)
    self:playNightBlastRightAnimation(tSrcCard, tDstCard)
    self:playNightBlastMiddleAnimation(tSrcCard, tDstCard, nOldHP, nCurrentHP, nDamage)
    
    local bIsLeftTeam  = tDstCard.bLeftSide

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        self:playBrokenAnimation(tDstCard)
    end
    
    if tDstCard.bIsRole and bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        self:playFightDestroyAnimation(tDstCard)
    end
end

function KStepNightFight:calcDamage(tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    return self.tLogic:calcDamage(tSrcCard, tDstCard)
end

function KStepNightFight:getConfig()
    return require("src/battle/KBattleConfig")
end

function KStepNightFight:processAttackOnce(tSrcCard)
    local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
    local nHuoPaoTankType   = CARD_TYPE.SELF_PROPELLED_GUN
    local isNightBigBroken  = CARD_BROKEN_STATE.BIG
    local KBattleConfig     = self:getConfig() 
    local nBrokenState      = KBattleConfig.getBrokenState(tSrcCard)
    if isNightBigBroken == nBrokenState then return end
    for k, v in pairs(tSrcCard.tFuncTypeList) do 
        if v == nHuoPaoTankType or tSrcCard.nCurrentHP <= 0 then 
            return        
        end 
    end
    if not tDstCard then
        return
    end

    self:print("processAttackOnce", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex)

    local nType, bCombo, nDamage = self:calcDamage(tSrcCard, tDstCard)
    if not bCombo then
        self:processNormalAttack(tSrcCard, tDstCard, nType, nDamage)
    else
        self:processComboAttack(tSrcCard, tDstCard, nDamage)
    end
end

function KStepNightFight:asyncExec(fnFunc, ...)
    return self.tAsyncExector:exec(fnFunc, ...)
end

function KStepNightFight:waitAsync(tTaskIDList)
    self.tAsyncExector:waiting(tTaskIDList)
end

function KStepNightFight:fire()
    print("[" .. self:getName() .. "] fire")
    if self.tBattleManager.roundList then
        local tRoundList = self.tBattleManager.roundList.nightFight
        return self:guideFire(tRoundList)
    end

    local tBattleData = self:getBattleData()
    local tHadActiveTankList    = {}
    while true do
        local tActiveTankList       = tBattleData:getNightFightActiveTank()
        for _, v in ipairs(tHadActiveTankList) do
            for k, card in ipairs(tActiveTankList) do
                if card == v then
                    table.remove(tActiveTankList, k)
                    break
                end
            end
        end
        local tAttackCard = tActiveTankList[1]
        if not tAttackCard then break end

        table.insert(tHadActiveTankList, tAttackCard)
        self:processAttackOnce(tAttackCard)
        self:waitSubStepFinish()
        self:emergencyRepairHandle()
    end
end

function KStepNightFight:costResouce()
    self:getBattleData():costNightFightResouce()
end

function KStepNightFight:changeBackground()
    local battleUI = self:getBattleUI()
    battleUI:setBattleBackground(battleUI._backgroundType, true)
end

function KStepNightFight:openDoor()
    local tBattleData = self:getBattleData()
    if tBattleData.bBeginAtNightFight then
        return
    end
    self:playAnimation("playOpenGateAnimation")
end

function KStepNightFight:showNightFightBeginWord()
    self:playAnimation("playNightFightBeginWordAnimation")
end

function KStepNightFight:openDoorAndShowNightBeginWord()
    local tTaskIDList = {}
    local nID = self:asyncExec(self.showNightFightBeginWord, self)    
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.openDoor, self)    
    table.insert(tTaskIDList, nID)
    self:waitAsync(tTaskIDList)
end

function KStepNightFight:run()
    self:checkPoint(ABILITY_CHECK_POINT.STEP_BEGIN, self)
    self:checkSkillButtonState()
    self:enableSkill(true)
    self:changeBackground()
    self:openDoorAndShowNightBeginWord()
    self:costResouce()
    self:showBattleState()
    self:waitSubStepFinish()
    self:scout()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    
    self:fire()
    self:waitSubStepFinish()
    self:enableSkill(false)
    self:checkPoint(ABILITY_CHECK_POINT.STEP_END, self)
end

return KStepNightFight
