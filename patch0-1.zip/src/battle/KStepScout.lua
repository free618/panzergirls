
local KStepScout = class("KStepScout", require("battle/KBattleStepBase").new)

function KStepScout:ctor()
    local tBattleData = self:getBattleData()
    self.nStepType = BATTLE_STEP_TYPE.SCOUT
    self.tLogic = require("src/battle/KStepScoutLogic").new(tBattleData)
end

function KStepScout:showClosedGate()
    print("[" .. self:getName() .. "] showClosedGate")

    self:playAnimation("playGateClosedState")
end

function KStepScout:showBattleStartText()
    print("[" .. self:getName() .. "] showBattleStartText")
    self:playAnimation("playStartBattleAnimation")
end

function KStepScout:openGate()
    print("[" .. self:getName() .. "] openGate")
    self:playAnimation("playOpenGateAnimation")
end

function KStepScout:showBattleState()
    print("[" .. self:getName() .. "] showBattleState")
    self:playAnimation("playBattleStateAnimation", "Scout")
end

function KStepScout:showLeftTeamCutIn()
    print("[" .. self:getName() .. "] showLeftTeamCutIn")
    self:playAnimation("playLeftTeamCutInAnimation")
end

function KStepScout:showDistanceRuler(szStep, nMoveDistance)
    print("[" .. self:getName() .. "] showDistanceRuler", szStep, nMoveDistance)
    self:playAnimation("playDistanceRuleAnimation", szStep, nMoveDistance)
end

function KStepScout:moveUnit()
    print("[" .. self:getName() .. "] moveUnit")
    local tBattleData = self:getBattleData()
    local tAsyncExecList = {}
    local nLightTankType = 1

    for k, v in ipairs(tBattleData.tSrcTeam) do
        -- cardType must lightTank
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    for k, v in ipairs(tBattleData.tDstTeam) do
        -- cardType must lightTank
        local tTankTypeList = v.tFuncTypeList
        for _, nTankType in ipairs(tTankTypeList) do
            if nTankType == nLightTankType then
                local nID = self:asyncExec(self.moveOneUnit, self, v, "Node_mobile_1")
                table.insert(tAsyncExecList, nID)
                break
            end
        end
    end

    local nID = self:asyncExec(self.showDistanceRuler, self, "Scout", 1500)
    table.insert(tAsyncExecList, nID)

    self:waitAsync(tAsyncExecList)
end

function KStepScout:showScoutEffect()
    print("[" .. self:getName() .. "] showScoutEffect")
    self:playAnimation("playScoutEffectAnimation")
end

function KStepScout:showRightTeamCutIn()
    print("[" .. self:getName() .. "] showRightTeamCutIn")
    self:playAnimation("playRightTeamCutInAnimation")
end

function KStepScout:showTeamCutIn()
    print("showTeamCutIn~")
    local tTaskIDList = {}
    local nID = self:asyncExec(self.showLeftTeamCutIn, self) 
    table.insert(tTaskIDList, nID)
    local nID = self:asyncExec(self.showRightTeamCutIn, self) 
    table.insert(tTaskIDList, nID)
    self:waitAsync(tTaskIDList)
end

function KStepScout:showTeamLineup()
    print("[" .. self:getName() .. "] showTeamLineup")
    local tBattleData = self:getBattleData()
    local nLeftTeamLineup   = tBattleData:getLeftTeamLineup()
    local nRightTeamLineup  = tBattleData:getRightTeamLineup()
    self:playAnimation("playLineupAnimation", nLeftTeamLineup, nRightTeamLineup)
end

function KStepScout:run()
    self:showClosedGate()
    self:showBattleStartText()
    self:openGate()
    -- self:showLeftTeamCutIn()
    -- self:showRightTeamCutIn()
    self:showTeamCutIn()
    self:rightTeamUseSkill()
    self:waitSubStepFinish()
    self:moveUnit()
    --self:showScoutEffect()   -- tangyu said temporary hiding
    self:showTeamLineup()
    self:enableSkill(true)
    self:showSkillPanel()
    self:waitSubStepFinish()
end

return KStepScout

