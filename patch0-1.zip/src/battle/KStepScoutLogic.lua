
local KStepScoutLogic = class("KStepScoutLogic")

function KStepScoutLogic:ctor(tBattleData)
	self.tBattleData = tBattleData
end

return KStepScoutLogic
