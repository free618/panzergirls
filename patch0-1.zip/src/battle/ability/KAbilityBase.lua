--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KAbilityBase.lua
--  Creator     : Liuzhen
--  Date        : 2016/07/29   22:13
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  *********************************************************************


local KAbilityBase = class("KAbilityBase")

function KAbilityBase:ctor(nAbilityID, tCard)
    self.nAbilityID                     = nAbilityID
    self.tCard                          = tCard
    self.tAbilityManager                = nil
    self.tPropertyChangeRecord          = {}
    self.tPropertyChangeByPercentRecord = {}
    self.nUseTime                       = 0
    self.bShowAttackAnimation           = false
end

function KAbilityBase:setAbilityManager(tAbilityManager)
    self.tAbilityManager    = tAbilityManager
end

function KAbilityBase:getBattleData()
    return self.tAbilityManager:getBattleData()
end

function KAbilityBase:getBattleUI()
    return self.tAbilityManager:getBattleUI()
end

function KAbilityBase:getBattleManager()
    return self.tAbilityManager:getBattleManager()
end

function KAbilityBase:battleBegin()
    return 
end

function KAbilityBase:battleEnd()
    return
end

-- tTriggerCard： 受伤的卡牌
-- tSrcCard： 伤害来源
-- tParam.nDamage：造成的伤害(可直接修改值)
function KAbilityBase:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    return 
end

function KAbilityBase:cardAfterCostHP(tTriggerCard, tSrcCard, nDamage)
    return
end

-- tTriggerCard：发动攻击的卡牌
-- tDstCard: 被攻击的坦克
-- nDamage: 造成的伤害值
-- nType：伤害类型（miss、命中、穿甲等）
function KAbilityBase:cardBeforeAttack(tTriggerCard, tDstCard, nDamage, nType)
    return
end

function KAbilityBase:cardAfterAttack(tTriggerCard, tDstCard, nDamage, nType)
    return 
end

-- tTriggerCard：死亡的卡
function KAbilityBase:cardBeforeDead(tTriggerCard)
    return 
end

function KAbilityBase:cardAfterDead(tTriggerCard)
    return 
end

function KAbilityBase:stepBegin(tCurrentStep)
    return 
end

function KAbilityBase:stepEnd(tCurrentStep)
    return 
end

------ 修改属性 -----------
function KAbilityBase:changeCardProperty(tCard, szProperty, nValue)
    local oldValue = tCard[szProperty]
    local newValue = oldValue + nValue
    if newValue < 0 then newValue = 0 end
    tCard[szProperty] = newValue

    local offset = newValue - oldValue
    local dataRecord = {tCard = tCard, szProperty = szProperty, nOffSet = offset}
    table.insert(self.tPropertyChangeRecord, dataRecord)
end

function KAbilityBase:recoverCardProperty()
    for index, oneRecord in ipairs(self.tPropertyChangeRecord) do
        local tCard         = oneRecord.tCard
        local szProperty    = oneRecord.szProperty
        local nOffSet       = oneRecord.nOffSet

        tCard[szProperty]   = tCard[szProperty] - nOffSet
    end

    self.tPropertyChangeRecord = {}
end

function KAbilityBase:changeCardPropertyByPercent(tCard, szProperty, nPercent)
    if not tCard.tExtraPropertyByPercent then 
        tCard.tExtraPropertyByPercent = {}
    end

    local tCardPropertyList = tCard.tExtraPropertyByPercent
    local nEmptyIndex = 1
    while true do
        if not tCardPropertyList[nEmptyIndex] then
            break
        end

        nEmptyIndex = nEmptyIndex + 1
    end
    
    local oneExtraProperty  = {szProperty = szProperty, nPercent = nPercent}
    tCardPropertyList[nEmptyIndex] = oneExtraProperty

    local oneRecord = {nPropertyIndex = nEmptyIndex, bLeftTeam = tCard.bLeftSide, nCardIndex = tCard.nIndex}
    table.insert(self.tPropertyChangeByPercentRecord, oneRecord)
end

function KAbilityBase:recoverCardPropertyByPercent()
    for _, oneRecord in ipairs(self.tPropertyChangeByPercentRecord) do
        local tCard = self:getBattleData():getCard(oneRecord.bLeftTeam, oneRecord.nCardIndex)
        tCard.tExtraPropertyByPercent[oneRecord.nPropertyIndex] = nil
    end

    self.tPropertyChangeByPercentRecord = {}
end

return KAbilityBase
