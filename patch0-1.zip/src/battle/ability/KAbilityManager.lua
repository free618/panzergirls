--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KAbilityBase.lua
--  Creator     : Liuzhen
--  Date        : 2016/07/29   22:13
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  *********************************************************************


local KAbilityManager = class("KAbilityManager")

local tCheckPointFuncMap = 
{
    [ABILITY_CHECK_POINT.BATTLE_BEGIN]          = "battleBegin",
    [ABILITY_CHECK_POINT.BATTLE_END]            = "battleEnd",
    [ABILITY_CHECK_POINT.CARD_BEFORE_COST_HP]   = "cardBeforeCostHP",
    [ABILITY_CHECK_POINT.CARD_AFTER_COST_HP]    = "cardAfterCostHP",
    [ABILITY_CHECK_POINT.CARD_BEFORE_ATTACK]    = "cardBeforeAttack",
    [ABILITY_CHECK_POINT.CARD_AFTER_ATTACK]     = "cardAfterAttack",
    [ABILITY_CHECK_POINT.CARD_BEFORE_DEAD]      = "cardBeforeDead",
    [ABILITY_CHECK_POINT.CARD_AFTER_DEAD]       = "cardAfterDead",
    [ABILITY_CHECK_POINT.STEP_BEGIN]            = "stepBegin",
    [ABILITY_CHECK_POINT.STEP_END]              = "stepEnd",
}


function KAbilityManager:ctor(tBattleManager)
    self.tBattleManager = tBattleManager
    self.tAbilityList = {}
    self.tCommonLogic = require("src/battle/ability/KAbilityCommonLogic").new(self)

    self:initAbilityList()
end

function KAbilityManager:initAbilityList()
    local tBattleData = self:getBattleData()
    local tLeftTeam = tBattleData:getLeftTeamData()
    for _, oneCard in ipairs(tLeftTeam) do
        if oneCard.tAbilityList ~= nil and #oneCard.tAbilityList > 0 then
            for _, oneAbility in ipairs(oneCard.tAbilityList) do
                oneAbility:setAbilityManager(self)
                table.insert(self.tAbilityList, oneAbility)
            end
        end
    end

    local tRightTeam = tBattleData:getRightTeamData()
    for _, oneCard in ipairs(tRightTeam) do
        if oneCard.tAbilityList ~= nil and #oneCard.tAbilityList > 0 then
            for _, oneAbility in ipairs(oneCard.tAbilityList) do
                oneAbility:setAbilityManager(self)
                table.insert(self.tAbilityList, oneAbility)
            end
        end
    end
end

function KAbilityManager:getBattleData()
    return self.tBattleManager:getData()
end

function KAbilityManager:getBattleUI()
    return self.tBattleManager:getUI()
end

function KAbilityManager:getBattleManager()
    return self.tBattleManager
end

function KAbilityManager:getAbilityList()
    return self.tAbilityList
end

function KAbilityManager:checkPoint(nCheckPointID, ...)
    local tAbilityList = self:getAbilityList()
    local szFunc = tCheckPointFuncMap[nCheckPointID]
    for _, oneAbility in ipairs(tAbilityList) do
        oneAbility[szFunc](oneAbility, ...)
    end
end

return KAbilityManager