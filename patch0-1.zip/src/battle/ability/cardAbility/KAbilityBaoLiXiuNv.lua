-- M7 牧师
-- 暴力修女
-- 攻击命中时，自己和相邻位置火力·穿透+5（可以叠加）


local KAbilityBaoLiXiuNv = class("KAbilityBaoLiXiuNv", require("src/battle/ability/KAbilityBase").new)

function KAbilityBaoLiXiuNv:ctor()
end

function KAbilityBaoLiXiuNv:battleBegin()
    self.bShowAttackAnimation = true
end

function KAbilityBaoLiXiuNv:cardAfterAttack(tTriggerCard, tDstCard, nDamage, nType)
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    if not self.tAbilityManager.tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if nType == ATTACK_RESULT.MISS then
        return
    end
    
    local tEffectCardList = self.tAbilityManager.tCommonLogic:getAdjCard(tCard)
    table.insert(tEffectCardList, tCard)

    local tCurrentStep = self:getBattleManager().tCurrentStep
    
    for _, oneCard in ipairs(tEffectCardList) do
        self:changeCardProperty(oneCard, "nAttack", 5)
        self:changeCardProperty(oneCard, "nPenetrate", 5)
        tCurrentStep:playAnimation("playCardAbilityBuffAnimation", oneCard, true)
    end

    self.nUseTime = self.nUseTime + 1
end

function KAbilityBaoLiXiuNv:battleEnd()
    self:recoverCardProperty()
    self.bShowAttackAnimation = false
    self.nUseTime = 0
end

return KAbilityBaoLiXiuNv
