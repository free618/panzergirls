-- I号C型
-- 害怕巨响
-- 队伍中邻近火炮时，自己被攻击几率-99%


local KAbilityHaiPaJuXiang = class("KAbilityHaiPaJuXiang", require("src/battle/ability/KAbilityBase").new)

function KAbilityHaiPaJuXiang:ctor()
    self.recordList = {}
end

local function changeTargetProbability(self, tCard, nProbability)
    if not tCard.nExtraTargetProbability then 
        tCard.nExtraTargetProbability = 0
    end

    local nOldProbability = tCard.nExtraTargetProbability 
    local nNewProbability = tCard.nExtraTargetProbability + nProbability
    if nNewProbability < -1 then
        nNewProbability = -1
    end

    local nOffSet = nNewProbability - nOldProbability
    tCard.nExtraTargetProbability = nNewProbability

    local oneRecord = {nOffSet = nOffSet, tCard = tCard}

    table.insert(self.recordList, oneRecord)
end

local function resetTargetProbability(self)
    for _, oneRecord in ipairs(self.recordList) do
        local tCard = oneRecord.tCard
        if not tCard.nExtraTargetProbability then return end

        local nOffSet = oneRecord.nOffSet
        tCard.nExtraTargetProbability = tCard.nExtraTargetProbability - nOffSet
    end

    self.recordList = {}
end

function KAbilityHaiPaJuXiang:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tAdjCardList = tCommonLogic:getAdjCard(tCard)
    for _, oneCard in ipairs(tAdjCardList) do
        if oneCard.nCurrentHP > 0 and oneCard.nNamedType == CARD_TYPE.SELF_PROPELLED_GUN then
            changeTargetProbability(self, tCard, -0.99)
            break
        end
    end

    self.nUseTime = self.nUseTime + 1
end

function KAbilityHaiPaJuXiang:battleEnd()
    resetTargetProbability(self)

    self.nUseTime = 0
end

return KAbilityHaiPaJuXiang
