-- 野牛
-- 火力震慑
-- 被持有此技能坦克攻击的敌人，前甲·后甲-10，回避-5%（不可叠加）


local KAbilityHuoLiZhenShe = class("KAbilityHuoLiZhenShe", require("src/battle/ability/KAbilityBase").new)

function KAbilityHuoLiZhenShe:ctor()
end

local function bRepeatUseAbility(self, tDstCard)
    for _, oneRecord in ipairs(self.tPropertyChangeRecord) do
        local tCard = oneRecord.tCard
        if self.tAbilityManager.tCommonLogic:bIsSameCard(tDstCard, tCard) then
            return true
        end
    end

    return false
end

function KAbilityHuoLiZhenShe:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end
    self.bShowAttackAnimation = true
end

function KAbilityHuoLiZhenShe:cardAfterAttack(tTriggerCard, tDstCard, nDamage, nType)
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if bRepeatUseAbility(self, tDstCard) then
        return 
    end

    self:changeCardProperty(tDstCard, "nFrontArmour", -10)
    self:changeCardProperty(tDstCard, "nRearArmour", -10)
    self:changeCardPropertyByPercent(tDstCard, "nDodge", -0.05)

    -- 缺少debuff动画

    self.nUseTime = self.nUseTime + 1
end

function KAbilityHuoLiZhenShe:battleEnd()
    self:recoverCardProperty()
    self:recoverCardPropertyByPercent()
    self.bShowAttackAnimation = false
    self.nUseTime = 0
end

return KAbilityHuoLiZhenShe