-- M4
-- 可靠的先锋
-- 一次出击只能发动一次，受到15点以上伤害时，伤害变为1

local KAbilityKeKaoDeXianFeng = class("KAbilityKeKaoDeXianFeng", require("src/battle/ability/KAbilityBase").new)

local nMaxCostHP = 15

function KAbilityKeKaoDeXianFeng:ctor()
end

function KAbilityKeKaoDeXianFeng:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    if self.nUseTime > 0 then
        return
    end

    local tCard = self.tCard
    if not self.tAbilityManager.tCommonLogic:bIsSameCard(tCard, tTriggerCard) then
        return 
    end

    if tParam.tBulletInfo.nDamage < nMaxCostHP then
        return
    end

    local tCurrentStep  = self:getBattleManager().tCurrentStep
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityLightAnimation", tCard)
    table.insert(tParam.tTaskIDList, nID)
    tParam.tBulletInfo.nDamage = 1

    self.nUseTime = self.nUseTime + 1
    return 
end

return KAbilityKeKaoDeXianFeng
