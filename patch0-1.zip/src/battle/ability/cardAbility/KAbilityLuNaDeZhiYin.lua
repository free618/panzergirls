-- T2
-- 露娜的指引
-- 缠斗·夜战阶段，我方全体中破能力惩罚减少100%


local KAbilityLuNaDeZhiYin = class("KAbilityLuNaDeZhiYin", require("src/battle/ability/KAbilityBase").new)

function KAbilityLuNaDeZhiYin:ctor()
    self.bUsing = false
    self.bShowAnimation = true
end

local function setImmuneMiddleBrokenPunishment(tOneCard, bFlat)
    tOneCard.bImmueMiddleBrokenPunishment = bFlat
end

function KAbilityLuNaDeZhiYin:stepBegin(tCurrentStep)
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    local nCurrentStepType = tCurrentStep.nStepType
    if not (nCurrentStepType == BATTLE_STEP_TYPE.DOG_FIGHT or nCurrentStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT) then
        return 
    end

    if self.bShowAnimation then 
        self.bShowAnimation = false
    end
    
    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tCardTeam = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tCardTeam) do
        setImmuneMiddleBrokenPunishment(oneCard, true)
    end

    self.nUseTime = self.nUseTime + 1
    self.bUsing = true
end

function KAbilityLuNaDeZhiYin:stepEnd(tCurrentStep)
    if not self.bUsing then
        return 
    end
    local tCard = self.tCard

    local nCurrentStepType = tCurrentStep.nStepType
    if not (nCurrentStepType == BATTLE_STEP_TYPE.DOG_FIGHT or nCurrentStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT) then
        return 
    end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tCardTeam = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tCardTeam) do
        setImmuneMiddleBrokenPunishment(oneCard, false)
    end
    self.bUsing = false
end

function KAbilityLuNaDeZhiYin:battleEnd()
    self.nUseTime = 0
    self.bUsing = false
end

return KAbilityLuNaDeZhiYin
