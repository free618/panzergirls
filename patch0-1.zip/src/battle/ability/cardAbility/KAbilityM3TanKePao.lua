-- M3"格兰特"
-- M3"坦克炮"
-- 伏击阶段60%几率发动，进行一次攻击，100%命中后甲(缠斗攻击）


local KAbilityM3TanKePao = class("KAbilityM3TanKePao", require("src/battle/ability/KAbilityBase").new)

local nProbability = 0.6

function KAbilityM3TanKePao:ctor()
    self.tCurrentStep = nil
end

function KAbilityM3TanKePao:stepEnd(tCurrentStep)
    local nCurrentStepType = tCurrentStep.nStepType
    if not (nCurrentStepType == BATTLE_STEP_TYPE.AMBUSH) then
        return 
    end
    self.tCurrentStep = tCurrentStep

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:checkProbability(nProbability) then
        return
    end

    local tCard = self.tCard

    self:processAttackOnce(tCard)
end

function KAbilityM3TanKePao:processAttackOnce(tSrcCard)
    local KBattleConfig = require("src/battle/KBattleConfig")
    local tSrcCardState = KBattleConfig.getBrokenState(tSrcCard)
    if tSrcCardState == CARD_BROKEN_STATE.BIG then
        return
    end
    local tDstCard = self:getBattleData():getRandomCard(not tSrcCard.bLeftSide)
    if not tDstCard then
        return
    end
    
    self:processAttackTarget(tSrcCard, tDstCard)
end

function KAbilityM3TanKePao:processAttackTarget(tSrcCard, tDstCard)
    local tCurrentStep = self.tCurrentStep

    local nLaunchNum    = 1 
    local tInfo         = {tDamageTaskIDList = {}}
    local KBattleConfig = require("battle/KBattleConfig")
    local oldCardState  = KBattleConfig.getBrokenState(tDstCard)

    local tTaskIDList   = {}

    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityAnimation", tSrcCard, self.nAbilityID)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAttackBeginAnimation", tSrcCard)
    table.insert(tTaskIDList, nID)
    local crossStartFrame = 0
    local crossFireFrame  = 60
    tCurrentStep:delay((crossFireFrame - crossStartFrame) / 60)

    local nTaskID   = tCurrentStep:asyncExec(self.cardFireTarget, self, tSrcCard, tDstCard, tInfo)
    table.insert(tTaskIDList, nTaskID)

    tCurrentStep:waitAsync(tTaskIDList)
    tCurrentStep:playAnimation("playCardAttackEndAnimation", tSrcCard)
    tCurrentStep:waitAsync(tInfo.tDamageTaskIDList)

    local bIsLeftTeam   = tDstCard.bLeftSide
    local newCardState  = KBattleConfig.getBrokenState(tDstCard)
    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        tCurrentStep:playBrokenAnimation(tDstCard)
    end
    if bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tDstCard.bUseMountItem then
        tCurrentStep:playFightDestroyAnimation(tDstCard)
    end
end

function KAbilityM3TanKePao:cardFireTarget(tSrcCard, tDstCard, tInfo)
    local tCurrentStep  = self.tCurrentStep
    local tBattleData   = self:getBattleData()
    local nType         = 0
    local nDamage       = 0
    local tLogic        = require("src/battle/KStepDogFightActionLogic").new(tBattleData)
    nType, nDamage      = tLogic:calcDamage(tSrcCard, tDstCard)
    
    local nBulletID      = tCurrentStep:addBullet(tSrcCard, tDstCard, nType, nDamage)
    tCurrentStep:playAnimation("playCardFireAnimation", tSrcCard)
    KSound.playEffect("fire")
    tCurrentStep:playAnimation("playBulletFireAnimation", tSrcCard, tDstCard)
    KSound.playEffect("boom")
    tCurrentStep:playAnimation("playBulletBlastAnimation", tDstCard)

    local nTaskID = tCurrentStep:asyncExec(tCurrentStep.applyBulletDamage, tCurrentStep, nBulletID)
    table.insert(tInfo.tDamageTaskIDList, nTaskID)
end

return KAbilityM3TanKePao
