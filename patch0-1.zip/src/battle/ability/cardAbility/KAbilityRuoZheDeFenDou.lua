-- T-46
-- 弱者的奋斗
-- 每场战斗一次，队友免疫一次致命伤害，作为代价T-46受到1点伤害（自己大破保护下不会死亡）


local KAbilityRuoZheDeFenDou = class("KAbilityRuoZheDeFenDou", require("src/battle/ability/KAbilityBase").new)

function KAbilityRuoZheDeFenDou:ctor()
end

function KAbilityRuoZheDeFenDou:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    if self.nUseTime > 0 then return end
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tAllTeamCard = tCommonLogic:getAllOwnCard(tCard)
    if tCommonLogic:bIsSameCard(tTriggerCard, tCard) or (tTriggerCard.bLeftSide ~= tCard.bLeftSide) then
        return 
    end

    local  mockCard = {
        nCurrentHP = tTriggerCard.nCurrentHP - tParam.tBulletInfo.nDamage,
        nMaxHP     = tTriggerCard.nMaxHP
    }
    local KBattleConfig = require("src/battle/KBattleConfig")
    local mockState     = KBattleConfig.getBrokenState(mockCard)
    if mockState <= CARD_BROKEN_STATE.BIG then
        return
    end

    local nDamage = tParam.tBulletInfo.nDamage
    local nType = tParam.tBulletInfo.nType
    tParam.tBulletInfo.nDamage = 0
    tParam.tBulletInfo.nType = ATTACK_RESULT.NORMAL

    nDamage = 1
    self:hurtCard(tCard, nType, nDamage, tParam)

    self.nUseTime = self.nUseTime + 1
end

function KAbilityRuoZheDeFenDou:hurtCard(tCard, nType, nDamage, tParam)
    local tBattleData = self:getBattleData()
    local tBattleUI   = self:getBattleUI()
    local tCurrentStep = tBattleUI._tBattleManager.tCurrentStep

    local bIsLeftTeam        = tCard.bLeftSide
    local KBattleConfig      = require("src/battle/KBattleConfig")
    local KBattleUIHelper    = require("battle/KBattleUIHelper")
    local oldCardState       = KBattleConfig.getBrokenState(tCard)
    local nOldHP, nCurrentHP = tBattleData:costHP(tCard, nDamage)
    local newCardState       = KBattleConfig.getBrokenState(tCard)

    local tTaskIDList = tParam.tTaskIDList
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityLightAnimation", tCard)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCostHPAnimation", tCard, nOldHP, nCurrentHP)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playHurtAnimation", tCard, nType, nDamage)
    table.insert(tTaskIDList, nID)

    -- local playBrokenAnimation = 30 + 50 -- playCostHPAnimation and playHurtAnimation frame
    -- KBattleUIHelper.delay(tBattleUI, playBrokenAnimation / 60)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        tCurrentStep:playBrokenAnimation(tCard)
    end

    if bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tCard.bUseMountItem then
        tCurrentStep:playFightDestroyAnimation(tCard)
    end
    -- tCurrentStep:waitAsync(tTaskIDList)
end

function KAbilityRuoZheDeFenDou:battleEnd()
    self.nUseTime = 0
end

return KAbilityRuoZheDeFenDou
