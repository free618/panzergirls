-- III号
-- 闪电作战
-- 作为队长时，敌方坦克回避-10%，前甲·后甲-10


local KAbilityShanDianZuoZhan = class("KAbilityShanDianZuoZhan", require("src/battle/ability/KAbilityBase").new)

function KAbilityShanDianZuoZhan:ctor()
    self.tPropertyChangeRecord = {}
end

function KAbilityShanDianZuoZhan:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:bIsTeamLeader(tCard) then
        return 
    end

    local tEffectCardList = tCommonLogic:getAllEmenyCard(tCard)
    for _, oneCard in ipairs(tEffectCardList) do
        self:changeCardProperty(oneCard, "nFrontArmour", -10)
        self:changeCardProperty(oneCard, "nRearArmour", -10)
        self:changeCardPropertyByPercent(oneCard, "nDodge", -0.1)
    end

    self.nUseTime = self.nUseTime + 1
end

function KAbilityShanDianZuoZhan:battleEnd()
    self:recoverCardProperty()
    self:recoverCardPropertyByPercent()

    self.nUseTime = 0
end

function KAbilityShanDianZuoZhan:cardAfterDead(tTriggerCard)
    local tCard = self.tCard
    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:bIsSameCard(tTriggerCard, tCard) then
        return 
    end
    
    self:recoverCardProperty()
    self:recoverCardPropertyByPercent()
end

return KAbilityShanDianZuoZhan
