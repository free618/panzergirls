-- KV-1
-- 守护之盾
-- 非大破状态下，炮击战·二轮炮击中40%几率代替相邻坦克承受攻击，伤害减少80%

local nProbability = 0.4

local KAbilityShouHuZhiDun = class("KAbilityShouHuZhiDun", require("src/battle/ability/KAbilityBase").new)

function KAbilityShouHuZhiDun:ctor()
end

function KAbilityShouHuZhiDun:cardBeforeCostHP(tTriggerCard, tSrcCard, tParam)
    local tCard = self.tCard

    local KBattleConfig = require("src/battle/KBattleConfig")
    local cardState     = KBattleConfig.getBrokenState(tCard)
    if cardState >= CARD_BROKEN_STATE.BIG then
        return 
    end

    local tBattleManager = self:getBattleManager()
    local tCurrentStep  = tBattleManager.tCurrentStep
    local nStepType     = tCurrentStep.nStepType
    if not (nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION or nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION2) then
        return 
    end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:checkProbability(nProbability) then
        return
    end

    local tAdjCardList = tCommonLogic:getAdjCard(tCard)
    for _, oneCard in ipairs(tAdjCardList) do
        if tCommonLogic:bIsSameCard(oneCard, tTriggerCard) then
            local nDamage = tParam.tBulletInfo.nDamage
            local nType = tParam.tBulletInfo.nType
            if nDamage < 1 then
                return 
            end

            tParam.tBulletInfo.nDamage = 0
            tParam.tBulletInfo.nType = ATTACK_RESULT.NORMAL

            nDamage = nDamage - math.floor(nDamage * 0.8)
            self:hurtCard(tCard, nType, nDamage, tParam)
            break
        end
    end
end

function KAbilityShouHuZhiDun:hurtCard(tCard, nType, nDamage, tParam)
    local tBattleData = self:getBattleData()
    local tBattleUI   = self:getBattleUI()
    local tCurrentStep = tBattleUI._tBattleManager.tCurrentStep

    local bIsLeftTeam        = tCard.bLeftSide
    local KBattleConfig      = require("src/battle/KBattleConfig")
    local KBattleUIHelper    = require("battle/KBattleUIHelper")
    local oldCardState       = KBattleConfig.getBrokenState(tCard)
    local nOldHP, nCurrentHP = tBattleData:costHP(tCard, nDamage)
    local newCardState       = KBattleConfig.getBrokenState(tCard)

    local tTaskIDList = tParam.tTaskIDList
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCardAbilityLightAnimation", tCard)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playCostHPAnimation", tCard, nOldHP, nCurrentHP)
    table.insert(tTaskIDList, nID)
    local nID = tCurrentStep:asyncExec(tCurrentStep.playAnimation, tCurrentStep, "playHurtAnimation", tCard, nType, nDamage)
    table.insert(tTaskIDList, nID)

    -- local playBrokenAnimation = 30 + 50 -- playCostHPAnimation and playHurtAnimation frame
    -- KBattleUIHelper.delay(tBattleUI, playBrokenAnimation / 60)

    if bIsLeftTeam and oldCardState < CARD_BROKEN_STATE.MIDDLE and newCardState >= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.DEAD then
        tCurrentStep:playBrokenAnimation(tCard)
    end

    if bIsLeftTeam and oldCardState ~= CARD_BROKEN_STATE.DEAD and newCardState == CARD_BROKEN_STATE.DEAD and not tCard.bUseMountItem then
        tCurrentStep:playFightDestroyAnimation(tCard)
    end
    -- tCurrentStep:waitAsync(tTaskIDList)
end

return KAbilityShouHuZhiDun
