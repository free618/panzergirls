-- M37
-- 小型底盘
-- 队伍中没有其他火炮时，命中·回避+15%，成为目标几率-20%


local KAbilityXiaoXingDiPan = class("KAbilityXiaoXingDiPan", require("src/battle/ability/KAbilityBase").new)

function KAbilityXiaoXingDiPan:ctor()
    self.recordList = {}
end

local function changeTargetProbability(self, tCard, nProbability)
    if not tCard.nExtraTargetProbability then 
        tCard.nExtraTargetProbability = 0
    end

    local nOldProbability = tCard.nExtraTargetProbability 
    local nNewProbability = tCard.nExtraTargetProbability + nProbability
    if nNewProbability < -1 then
        nNewProbability = -1
    end

    local nOffSet = nNewProbability - nOldProbability
    tCard.nExtraTargetProbability = nNewProbability

    local oneRecord = {nOffSet = nOffSet, tCard = tCard}
    table.insert(self.recordList, oneRecord)
end

local function resetTargetProbability(self)
    for _, oneRecord in ipairs(self.recordList) do
        local tCard = oneRecord.tCard
        if not tCard.nExtraTargetProbability then return end

        local nOffSet = oneRecord.nOffSet
        tCard.nExtraTargetProbability = tCard.nExtraTargetProbability - nOffSet
    end

    self.recordList = {}
end

function KAbilityXiaoXingDiPan:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local ownTeamData = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(ownTeamData) do
        if not tCommonLogic:bIsSameCard(tCard, oneCard) and oneCard.nNamedType == CARD_TYPE.SELF_PROPELLED_GUN then
            return 
        end
    end

    self:changeCardPropertyByPercent(tCard, "nHitRate", 0.15)
    self:changeCardPropertyByPercent(tCard, "nDodge", 0.15)

    changeTargetProbability(self, tCard, -0.2)

    self.nUseTime = self.nUseTime + 1
end

function KAbilityXiaoXingDiPan:battleEnd()
    self:recoverCardPropertyByPercent()
    resetTargetProbability(self)

    self.nUseTime = 0
end

return KAbilityXiaoXingDiPan
