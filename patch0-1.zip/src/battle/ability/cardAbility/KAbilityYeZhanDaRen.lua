-- IV号
-- 夜战达人
-- 缠斗·夜战命中率提高100%，火力·穿透+15


local KAbilityYeZhanDaRen = class("KAbilityYeZhanDaRen", require("src/battle/ability/KAbilityBase").new)

function KAbilityYeZhanDaRen:ctor()
end

function KAbilityYeZhanDaRen:stepBegin(tCurrentStep)
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local nStepType = tCurrentStep.nStepType
    if not (nStepType == BATTLE_STEP_TYPE.DOG_FIGHT or nStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT) then 
        return
    end

    self.bShowAttackAnimation = true
    self:changeCardProperty(tCard, "nAttack", 15)
    self:changeCardProperty(tCard, "nPenetrate", 15)
    self:changeCardPropertyByPercent(tCard, "nHitRate", 1)

    self.nUseTime = self.nUseTime + 1
end

function KAbilityYeZhanDaRen:stepEnd(tCurrentStep)
    local nStepType = tCurrentStep.nStepType
    if not (nStepType == BATTLE_STEP_TYPE.DOG_FIGHT or nStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT) then 
        return
    end

    self:recoverCardProperty()
    self:recoverCardPropertyByPercent()
    self.bShowAttackAnimation = false
end

function KAbilityYeZhanDaRen:battleEnd()
    self:recoverCardProperty()
    self:recoverCardPropertyByPercent()
    self.bShowAttackAnimation = false

    self.nUseTime = 0
end

return KAbilityYeZhanDaRen
