-- LT-35
-- 异国的指导者
-- 闪电战中战斗开始时50%几率发动，炮击战·二轮炮击阶段，我方全体轻中型坦克火力·穿透+30

local nShanDianZhanID = 2
local nProbability = 0.5

local KAbilityYiGuoDeZhiDaoZhe = class("KAbilityYiGuoDeZhiDaoZhe", require("src/battle/ability/KAbilityBase").new)

function KAbilityYiGuoDeZhiDaoZhe:ctor()
    self.bUsing = false
end

function KAbilityYiGuoDeZhiDaoZhe:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    local tBattleData   = self:getBattleData()
    local tLineupData   = tBattleData:getLineup(tCard)
    local nLineupID     = tLineupData.nID
    if nLineupID ~= nShanDianZhanID then
        return 
    end

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    if not tCommonLogic:checkProbability(nProbability) then
        return
    end

    self.bUsing   = true
    self.nUseTime = self.nUseTime + 1
end

function KAbilityYiGuoDeZhiDaoZhe:stepBegin(tCurrentStep)
    local tCard = self.tCard
    if tCard.nCurrentHP <= 0 then return end

    if not self.bUsing then return end

    local nStepType = tCurrentStep.nStepType
    if not (nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION or nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION2) then
        return 
    end

    self.bShowAttackAnimation = true

    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tAllOwnCard = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tAllOwnCard) do
        if oneCard.nNamedType == CARD_TYPE.LIGHT_TANK or oneCard.nNamedType == CARD_TYPE.MEDIUM_TANK then
            self:changeCardProperty(oneCard, "nAttack", 30)
            self:changeCardProperty(oneCard, "nPenetrate", 30)

            tCurrentStep:playAnimation("playCardAbilityBuffAnimation", oneCard, true)
        end
    end
end

function KAbilityYiGuoDeZhiDaoZhe:stepEnd(tCurrentStep)
    if not self.bUsing then return end

    local nStepType = tCurrentStep.nStepType
    if not (nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION or nStepType == BATTLE_STEP_TYPE.ARTILLERY_ACTION2) then
        return 
    end

    self.bShowAttackAnimation = false
    local tCard = self.tCard
    local tCommonLogic = self.tAbilityManager.tCommonLogic
    local tAllOwnCard = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tAllOwnCard) do
        tCurrentStep:playAnimation("playCardAbilityBuffAnimation", oneCard, false)
    end
    self:recoverCardProperty()
end

function KAbilityYiGuoDeZhiDaoZhe:battleEnd()
    self:recoverCardProperty()

    self.nUseTime = 0
    self.bUsing = false
    self.bShowAttackAnimation = false
end

return KAbilityYiGuoDeZhiDaoZhe
