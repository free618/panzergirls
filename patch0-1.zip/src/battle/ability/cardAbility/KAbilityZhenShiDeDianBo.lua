-- T-60
-- 真实的电波
-- 机动作战中我方全体火力·穿透上升速度的20%


local nJiDongZuoZhanID = 3

local KAbilityZhenShiDeDianBo = class("KAbilityZhenShiDeDianBo", require("src/battle/ability/KAbilityBase").new)

function KAbilityZhenShiDeDianBo:ctor()    
end

function KAbilityZhenShiDeDianBo:battleBegin()
    local tCard = self.tCard
    if tCard.nCurrentHP == 0 then return end

    local tBattleData   = self:getBattleData()
    local tLineupData   = tBattleData:getLineup(tCard)
    local nLineupID     = tLineupData.nID
    if nLineupID ~= nJiDongZuoZhanID then
        return 
    end

    local tCommonLogic  = self.tAbilityManager.tCommonLogic
    local tAllCard      = tCommonLogic:getAllOwnCard(tCard)
    for _, oneCard in ipairs(tAllCard) do
        local nSpeed    = oneCard.nSpeed
        local nAddValue = math.floor(nSpeed * 0.2)
        self:changeCardProperty(oneCard, "nAttack", nAddValue)
        self:changeCardProperty(oneCard, "nPenetrate", nAddValue)
    end

    return 
end

function KAbilityZhenShiDeDianBo:batttleEnd()
    self:recoverCardProperty()

    self.nUseTime = 0
end

return KAbilityZhenShiDeDianBo
