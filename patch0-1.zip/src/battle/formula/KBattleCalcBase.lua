--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleCalcBase.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleFormula    = require("src/battle/formula/KBattleFormula")
local KBattleFormulaEnv = require("src/battle/formula/KBattleFormulaEnv")

local KBattleCalcBase = class("KBattleCalcBase")

function KBattleCalcBase:ctor(tBattleData)
    print("KBattleCalcBase:ctor", tostring(tBattleData))
    self.tBattleData  = tBattleData
end

function KBattleCalcBase:getBattleData()
    return self.tBattleData
end

-- 命中
function KBattleCalcBase:calcHitRate(funCalcHitRate, tSrcCard, tDstCard)
    if tDstCard.bBrokenProtect and tDstCard.nCurrentHP == 1 then
        print("----> 命中计算 [结束], 未命中：因为大破保护 ")
        return false
    end

    local nHitRate = funCalcHitRate()

    local nRandomValue = random()
    local bHitted = nRandomValue < nHitRate
    print("----> 命中计算 [结束], 命中率：", nHitRate, "随机数：", nRandomValue, "命中结果：", bHitted)
    return bHitted
end

-- 穿甲
function KBattleCalcBase:calcPierce(funCalcPierce, tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    local nPierceEffectRate     = tBattleData:getPierceEffectRate(tDstCard)           -- 目标 穿透生效率
    local nRandomValue = random()
    print("----> 穿甲计算 [开始], 穿甲生效概率：", nPierceEffectRate, "随机值：", nRandomValue)
    local bEffect = nRandomValue < nPierceEffectRate
    if bEffect then 
        print("----> 穿甲计算 [结束], 未穿甲：穿甲未生效 ")
        return false, 0 
    end
    return funCalcPierce()
end

-- 重击
function KBattleCalcBase:calcThumpRate(funCalcThumpRate, tSrcCard, tDstCard)
    local tBattleData = self:getBattleData()
    local nThumpValue, nThumpMutiValue = funCalcThumpRate()

    local nRandomValue = random()
    local bThump = nRandomValue < nThumpValue
    if not bThump then
        nThumpMutiValue = 1
    end
    print("----> 重击计算 [结束], 重击率:", nThumpValue, "随机值：", nRandomValue, "重击倍率:", nThumpMutiValue)
    return bThump, nThumpMutiValue
end

function KBattleCalcBase:doCalcDamage(tSrcCard, tDstCard, tFun, ...)
    local bHit = self:calcHitRate(tFun.hit, tSrcCard, tDstCard)
    if not bHit then
        print("----> 伤害计算 [结束], 未命中!")
        return ATTACK_RESULT.MISS, 0
    end
    local bPierce, nMinDamagePercent = self:calcPierce(tFun.pierce, tSrcCard, tDstCard)
    if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, nDamage
    end

    local bThump, nThumpCoe          = self:calcThumpRate(tFun.thump, tSrcCard, tDstCard)
    local nDamage = tFun.damage(bPierce, nMinDamagePercent, bThump, nThumpCoe)
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
        if nDamage < 0 then nDamage = 0 end
    end
    nDamage = math.floor(nDamage)
    
    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage
end

-- 伤害
function KBattleCalcBase:calcDamage(tSrcCard, tDstCard, nEquipPos, ...)
    print("----> 伤害计算 [开始]", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, nEquipPos)
    local tBattleData   = self:getBattleData()
    local KEnv          = KBattleFormulaEnv.createFormulaEnv(tBattleData, tSrcCard, tDstCard, nEquipPos)

    local tFun = KBattleFormula[tBattleData.nCurrentStep]
    for szName, fun in pairs(tFun) do
        print(szName)
        setfenv(fun, KEnv)
    end   
    
    return self:doCalcDamage(tSrcCard, tDstCard, tFun, ...)
end

-- 技能伤害
function KBattleCalcBase:calcSkillDamage(tSkillConfig, tSrcCard, tDstCard, nEquipPos, ...)
    if tSrcCard then
        print("----> 技能伤害计算 [开始]", tSkillConfig.szType, tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex, nEquipPos)
    else
        print("----> 技能伤害计算 [开始], 无攻击者", tSkillConfig.szType, tDstCard.bLeftSide, tDstCard.nIndex, nEquipPos)
    end
    local tBattleData   = self:getBattleData()
    local KEnv          = KBattleFormulaEnv.createSkillFormulaEnv(tBattleData, tSkillConfig, tSrcCard, tDstCard, nEquipPos)

    local tFun = KBattleFormula[tSkillConfig.szType]
    for szName, fun in pairs(tFun) do
        print(szName)
        setfenv(fun, KEnv)
    end   
    
    return self:doCalcDamage(tSrcCard, tDstCard, tFun, ...)
end

return KBattleCalcBase
