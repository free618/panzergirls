--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleCalcNighFight.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleCalcBase = require("src/battle/formula/KBattleCalcBase")

local KBattleCalcCombo = class( "KBattleCalcCombo", KBattleCalcBase )

function KBattleCalcCombo:ctor(tBattleData)
    KBattleCalcBase.ctor(self, tBattleData)
end

function KBattleCalcCombo:doCalcDamage(tSrcCard, tDstCard, tFun, nMuti)
    print("----> [突袭] 伤害计算 [开始]", tSrcCard.bLeftSide, tSrcCard.nIndex, tDstCard.bLeftSide, tDstCard.nIndex)

    local bPierce, nMinDamagePercent = self:calcPierce(tFun.pierce, tSrcCard, tDstCard)  -- bPierce:是否穿甲, nMinDamagePercent ： 最小百分比
    if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("----> [突袭] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, nDamage
    end

    local bThump, nThumpCoe          = self:calcThumpRate(tFun.thump, tSrcCard, tDstCard) --bThump 是否重击 nThumpCoe 重击倍率
    local nDamage = tFun.damage(bPierce, nMinDamagePercent, bThump, nThumpCoe, nMuti)
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    nDamage = math.floor(nDamage)
    print("----> [突袭] 伤害计算 [结束]", " 伤害：", nDamage)
    
    if bThump then
        return ATTACK_RESULT.CRIT, nDamage
    end
    return ATTACK_RESULT.NORMAL, nDamage
end

return KBattleCalcCombo
