--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleCalcNighFight.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleCalcBase = require("src/battle/formula/KBattleCalcBase")

local KBattleCalcNighFight = class( "KBattleCalcNighFight", KBattleCalcBase )

function KBattleCalcNighFight:ctor(tBattleData)
    print("KBattleCalcNighFight", tBattleData, tBattleData.nCurrentStep)
    KBattleCalcBase.ctor(self, tBattleData)
    print("KBattleCalcNighFight2", tBattleData, self.tBattleData.nCurrentStep)
end

-- 必杀
function KBattleCalcNighFight:calcCombo(funCombo, tSrcCard, tDstCard)
    print("----> [夜战] 必杀计算 [开始]")

    local nComboMuti  = self:getBattleData():getComboMuti(tSrcCard)
    if not nComboMuti then
        print("----> [夜战] 必杀计算 [结束]， 无法触发必杀， 装备组合不匹配!")
        return false, 1
    end

    local nComboRate = funCombo()

    local nRandomValue = random()
    local bCommbo = nRandomValue < nComboRate
    print("----> [夜战] 必杀计算 [结束]， 必杀率：", nComboRate, "随机值：", nRandomValue, "必杀伤害倍数：", nComboMuti)
    return bCommbo, nComboMuti
end

function KBattleCalcNighFight:doCalcDamage(tSrcCard, tDstCard, tFun)
    local bCommbo, nComboCoe =  self:calcCombo(tFun.combo, tSrcCard, tDstCard)
    if not bCommbo then
        local bHit = self:calcHitRate(tFun.hit, tSrcCard, tDstCard)
        if not bHit then
            print("----> [夜战] 伤害计算 [结束], 未命中!")
            return ATTACK_RESULT.MISS, false, 0
        end
    end

    local bPierce, nMinDamagePercent = self:calcPierce(tFun.pierce, tSrcCard, tDstCard)  -- bPierce:是否穿甲, nMinDamagePercent ： 最小百分比
    if not bPierce then
        local nDamage = math.floor(tDstCard.nMaxHP * nMinDamagePercent)
        if nDamage < 0 then nDamage = 0 end
        print("----> [夜战] 伤害计算 [结束], 未穿甲! 伤害百分比：", nMinDamagePercent, "目标最大耐久：", tDstCard.nMaxHP, " 伤害：", nDamage)
        return ATTACK_RESULT.RICOCHET, bCommbo, nDamage
    end

    local bThump, nThumpCoe          = self:calcThumpRate(tFun.thump, tSrcCard, tDstCard) --bThump 是否重击 nThumpCoe 重击倍率
    local nDamage = tFun.damage(bPierce, nMinDamagePercent, bThump, nThumpCoe) * nComboCoe
    if nDamage < 1 then
        nDamage = tDstCard.nMaxHP * nMinDamagePercent
    end
    print("----> [夜战] 伤害计算 [结束],  伤害：", nDamage)
    nDamage = math.floor(nDamage)

    if bThump then
        return ATTACK_RESULT.CRIT, bCommbo, nDamage
    end
    return ATTACK_RESULT.NORMAL, bCommbo, nDamage 
end

return KBattleCalcNighFight
