--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleFormula.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleFormula = {}

--火炮阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_STRIKE] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_STRIKE].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 400) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) 
            - (DstDodgeAddExtra / (DstDodgeAddExtra + 15) + DstLineupDodge)) 
            * DstHitCoe * SrcStateHitRateCoe
	--命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_STRIKE].pierce = function ()
    local nPierceValue = (SrcPierce * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe) 
            - getDstRandomArmour(0.3) * DstLineupFrontArmour

    local bPierced = nPierceValue > 0
    local nRandomValue = 0 
    --下面的没用用到，并没有什么卵用
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end

    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_STRIKE].thump = function ()
    local nThumpValue = (SrcAttack * SrcStateAttackCoe - DstRandomArmour) / 50.0 * random(0.7, 1.3)
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_STRIKE].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    local nPierceCoe
    if bPierce then
        nPierceCoe = 3   -- 穿甲系数
    else 
        nPierceCoe = 10  -- 未穿甲系数
        nThumpCoe = 1
    end

    local stcMaxDamage = ((math.sqrt(SrcAttack * SrcStateAttackCoe * SrcLineupAttack) + SrcEquipAttack * 3) 
                         * random(0.7, 1.3) * TankTypeDamageCoe)/ (DstRandomArmour * DstLineupFrontArmour * nPierceCoe)
    if stcMaxDamage > 1 then stcMaxDamage = 1 end 
    local nDamage = SrcAttack * stcMaxDamage * nThumpCoe
    return nDamage
end

--伏击阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.AMBUSH] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.AMBUSH].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 500) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) 
        - (DstDodgeAddExtra / (DstDodgeAddExtra + 40) + DstLineupDodge)) * DstHitCoe * SrcStateHitRateCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.AMBUSH].pierce = function ()
    local nPierceValue = (SrcPierce * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe) 
                        - getDstRandomArmour(0) * DstLineupFrontArmour -- 最终穿透值
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹后伤害计算系数
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.AMBUSH].thump = function ()
    local nThumpValue = (SrcAttack * SrcStateAttackCoe - DstRandomArmour) / 50.0 * random(0.7, 1.3)
    --重击上下限
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    --重击倍率（下方1.2处可以修改）
    return nThumpValue, 1.2
end

--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.AMBUSH].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return (SrcAttack * random(0.7, 1.3) * SrcLineupAttack * SrcStateAttackCoe * TankTypeDamageCoe - DstRandomArmour * DstLineupFrontArmour) * nThumpCoe 
end

--一轮炮击阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 450) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) 
                    - (DstDodgeAddExtra / (DstDodgeAddExtra + 45) + DstLineupDodge)) * SrcLandHitRate * SrcStateHitRateCoe * SrcHitCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION].pierce = function ()
    local nPierceValue = (SrcPierce * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe) - getDstRandomArmour(0) * DstLineupFrontArmour
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION].thump = function ()
    local nThumpValue = (SrcAttack * SrcStateAttackCoe - DstRandomArmour) / 40.0 * random(0.7, 1.3)
    --重击上下限以及重击伤害倍率
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return (SrcAttack * random(0.7, 1.3) * SrcLineupAttack * SrcLandAttack * SrcStateAttackCoe * TankTypeDamageCoe - getDstRandomArmour(0) * DstLineupFrontArmour) * nThumpCoe
end

--二轮炮击阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION2] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION2].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 450) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) 
                    - (DstDodgeAddExtra / (DstDodgeAddExtra + 45) + DstLineupDodge)) * SrcLandHitRate * SrcStateHitRateCoe * DstHitCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION2].pierce = function ()
    local nPierceValue = (SrcPierce * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe) - getDstRandomArmour(0) * DstLineupFrontArmour
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION2].thump = function ()   
    local nThumpValue = (SrcAttack * SrcStateAttackCoe - DstRandomArmour) / 40.0 * random(0.7, 1.3)
    --重击上下限
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    --重击倍率
    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.ARTILLERY_ACTION2].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return (SrcAttack * random(0.7, 1.3) * SrcLineupAttack * SrcLandAttack * SrcStateAttackCoe * TankTypeDamageCoe - DstRandomArmour * DstLineupFrontArmour) * nThumpCoe
end

--缠斗阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.DOG_FIGHT] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.DOG_FIGHT].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 500) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) 
                    - (DstDodgeAddExtra / (DstDodgeAddExtra + 40) + DstLineupDodge)) * SrcStateHitRateCoe * SrcHitCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.DOG_FIGHT].pierce = function ()
    local nPierceValue = (SrcPierce + SrcSpeed * SrcPierceCoe * 0.3) * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe - getDstRandomArmour(1) * DstLineupFrontArmour
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.DOG_FIGHT].thump = function ()  
    local nThumpValue = ((SrcAttack + SrcSpeed * SrcThumpCoe * 0.2) * SrcStateAttackCoe - DstRandomArmour ) / 40.0 * random(0.7, 1.3) + SrcThump
    --重击上下限和重击倍率
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end
--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.DOG_FIGHT].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return ((SrcAttack + SrcSpeed * SrcDamageCoe * 0.3) * random(0.7, 1.3) * SrcLineupAttack * SrcStateAttackCoe * TankTypeDamageCoe - DstRandomArmour * DstLineupFrontArmour ) * nThumpCoe
end

--夜战阶段公式*******************************************************************************************************************
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT] = {}

--命中公式
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 500) + SrcHitRate + ScoutHitRate + SrcLineupHitRate) - (DstDodgeAddExtra / (DstDodgeAddExtra + 35) + DstLineupDodge)) * SrcStateHitRateCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT].pierce = function ()
    local nPierceValue = (SrcPierce + SrcSpeed * 0.3 * SrcPierceCoe) * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe - DstNightArmour * DstLineupFrontArmour
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT].thump = function () 
    local nThumpValue = (SrcAttack + SrcSpeed * 0.3 * SrcDamageCoe * SrcStateAttackCoe - DstNightArmour ) / 40.0 * random(0.7, 1.3) + SrcThump
    --重击上下限和重击倍率
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 2
end

--伤害公式
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return ((SrcAttack + SrcSpeed * 0.3 * SrcDamageCoe) * random(0.7, 1.3) * SrcLineupAttack * SrcStateAttackCoe * TankTypeDamageCoe - DstNightArmour * DstLineupFrontArmour ) * nThumpCoe
end

--CI触发率公式
KBattleFormula[BATTLE_STEP_TYPE.NIGHT_FIGHT].combo = function ()
    local nComboRate = (0.85 * SrcNightValue + SrcBrokenComboCoe + SrcTeamPositionComboCoe + ( SrcCombo * 100 ) ) / 180
    --CI概率上下限
    return makeInRange(nComboRate, {0.05, 0.9})
end

--战略轰炸技能公式*******************************************************************************************************************
KBattleFormula["AirBomb"] = {}

--命中公式
KBattleFormula["AirBomb"].hit = function ()
    local nHitRate = ((1.0 + SkillParam2 + ScoutHitRate + SrcMaxScout / 450) - (DstDodge / (DstDodge + 55) + DstLineupDodge)) * DstHitCoe
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula["AirBomb"].pierce = function ()
    local nPierceValue = (SkillParam1 / 2 + SrcMaxScout * 0.3) * random(0.6, 1.4) - ((DstFrontArmour + DstRearArmour) /  2 * DstLineupFrontArmour)
    local bPierced     = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害范围
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula["AirBomb"].thump = function () 
    local nThumpValue   = ((SkillParam1 + SrcMaxScout * 0.4) - (DstFrontArmour + DstRearArmour) / 2 * random(0.7, 1.3)) / 200
    --重击上下限和重击倍率
    nThumpValue         = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.2
end

--伤害公式
KBattleFormula["AirBomb"].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return ((SkillParam1 / 1.5 + SrcMaxScout * 0.4) * random(0.5, 1.5)  - ((DstFrontArmour + DstRearArmour) / 2 * DstLineupFrontArmour)) * nThumpCoe * DstDamageCoe
end

--空中支援技能公式*******************************************************************************************************************
KBattleFormula["AirSupport"] = {}

--命中公式
KBattleFormula["AirSupport"].hit = function ()
    return 1
end 

--穿透公式
KBattleFormula["AirSupport"].pierce = function ()
    local nPierceValue = (SkillParam1 * 0.7 + SrcMaxScout * 0.3) * random(0.6, 1.4) - getDstRandomArmour(0.5) * DstLineupFrontArmour 
    local bPierced     = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula["AirSupport"].thump = function () 
    local nThumpValue   = (SkillParam1 + SrcMaxScout * 0.4 - DstRandomArmour * random(0.7, 1.3)) / 300
    --重击上下限和重击倍率
    nThumpValue         = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end
--伤害公式
KBattleFormula["AirSupport"].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return ((SkillParam1 + SrcMaxScout / 2) * random(0.7, 1.3) - DstRandomArmour * DstLineupFrontArmour) * nThumpCoe * DstDamageCoe
end

--徐进弹幕技能公式*******************************************************************************************************************
KBattleFormula["Barrage"] = {}

--命中公式
KBattleFormula["Barrage"].hit = function ()
    local nHitRate = ((1.0 + (SrcLevel / 400) + SrcHitRate + ScoutHitRate + SrcLineupHitRate - SkillParam1) 
                    - (DstDodge / (DstDodge + 15) + DstLineupDodge)) * DstHitCoe * SrcStateHitRateCoe;
    --命中上下限
    return makeInRange(nHitRate, {0.05, 0.9})
end 

--穿透公式
KBattleFormula["Barrage"].pierce = function ()
    local nPierceValue = (SrcPierce * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe * SkillParam2) 
                        - getDstRandomArmour(0.3) * DstLineupFrontArmour -- 最终穿透值
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --if tSrcCard.nNamedType == CARD_TYPE.SELF_PROPELLED_GUN then bPierced = true end 
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula["Barrage"].thump = function () 
    local nThumpValue = (SrcAttack * SrcStateAttackCoe - DstRandomArmour) / 50.0 * random(0.7, 1.3)
    --重击上下限和重击倍率
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula["Barrage"].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    local nPierceCoe
    if bPierce then
        nPierceCoe = 3   -- 穿甲系数
    else 
        nPierceCoe = 10  -- 未穿甲系数
        nThumpCoe = 1
    end

    local stcMaxDamage = ((math.sqrt(SrcAttack * SrcStateAttackCoe * SrcLineupAttack) + SrcEquipAttack * 3) 
                         * random(0.7, 1.3) * TankTypeDamageCoe) / (DstRandomArmour * DstLineupFrontArmour * nPierceCoe)
    if stcMaxDamage > 1 then stcMaxDamage = 1 end 
    local nDamage = SrcAttack * SkillParam3 * stcMaxDamage * nThumpCoe
    return nDamage
end

--突袭技能公式*******************************************************************************************************************
KBattleFormula["Combo"] = {}

--必定命中/穿透公式
KBattleFormula["Combo"].pierce = function ()
    local nPierceValue = (SrcPierce * SkillParam3 * random(0.7, 1.3) * SrcLineupPierce * SrcStatePierceCoe * TankTypeDamageCoe) 
                        - getDstRandomArmour(SkillParam4) * DstLineupFrontArmour
    local bPierced = nPierceValue > 0
    local nRandomValue = 0
    --跳弹伤害
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula["Combo"].thump = function () 
    local nThumpValue = (SrcAttack * SkillParam2 * SrcStateAttackCoe - DstRandomArmour) / 40.0 * random(0.7, 1.3)
    --重击上下限和重击倍率
    nThumpValue = makeInRange(nThumpValue, {0.05, 0.8})

    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula["Combo"].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe, nMuti)
    return (SrcAttack * SkillParam2 * random(0.7, 1.3) * SrcLineupAttack * SrcLandAttack * SrcStateAttackCoe * TankTypeDamageCoe - DstRandomArmour * DstLineupFrontArmour) * nThumpCoe * nMuti
end

--布雷技能公式*******************************************************************************************************************
KBattleFormula["Landmine"] = {}

--命中公式
KBattleFormula["Landmine"].hit = function ()
    return 1
end 

--穿透公式
KBattleFormula["Landmine"].pierce = function ()
    local nPierceValue = 1
    local bPierced     = nPierceValue > 0
    local nRandomValue = 0
    if bPierced then
        nRandomValue = random(0.05, 0.2)
    else
        nRandomValue = random(0.01, 0.05)
    end
    return bPierced, nRandomValue
end

--重击公式
KBattleFormula["Landmine"].thump = function () 
    local nThumpValue   = 0.3-- (SkillParam1 - (DstFrontArmour + DstRearArmour) / 2) * random(0.7, 1.3) / 80
    --重击上下限和重击倍率
    nThumpValue         = makeInRange(nThumpValue, {0.05, 0.8})
    return nThumpValue, 1.5
end

--伤害公式
KBattleFormula["Landmine"].damage = function (bPierce, nMinDamagePercent, bThump, nThumpCoe)
    return SkillParam1 * nThumpCoe + random(-SkillParam3, SkillParam3)
end

return KBattleFormula
