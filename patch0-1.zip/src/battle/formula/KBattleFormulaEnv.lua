--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KBattleFormulaEnv.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KBattleFormulaEnv = {}

-- 目标护甲，有nRealRate几率后甲,
-- bNoReset为false取上次计算的护甲值，用于命中，穿透，重击，伤害用相同的护甲计算
local function getCardRandomArmour(tEnv, tDstCard, nRealRate, bNoReset)
    if bNoReset and tEnv.DstRandomArmour then
            return tEnv.DstRandomArmour
        end
        local nDstArmour = tDstCard.nFrontArmour
        local nRandomValueForArmour = random()
        if nRandomValueForArmour < nRealRate + tEnv.LineupRearArmourRate then
            nDstArmour = tDstCard.nRearArmour
        end
        if not tEnv.DstRandomArmour then
            tEnv.DstRandomArmour = nDstArmour
        end
        return nDstArmour
end

function KBattleFormulaEnv.createFormulaEnv(tBattleData, tSrcCard, tDstCard, nEquipPos)
    local KEnv = {
        math        = math,
        random      = KBattleFormulaEnv.random,
        makeInRange = KBattleFormulaEnv.makeInRange,
    }

    KBattleFormulaEnv.initSrcParam(KEnv, tBattleData, tSrcCard, tDstCard, nEquipPos)
    KBattleFormulaEnv.initDstParam(KEnv, tBattleData, tSrcCard, tDstCard)

    function KEnv.getDstRandomArmour(nRealRate, bNoReset)
        return getCardRandomArmour(KEnv, tDstCard, nRealRate, bNoReset)
    end
    return KEnv
end

function KBattleFormulaEnv.createSkillFormulaEnv(tBattleData, tSkillConfig, tSrcCard, tDstCard, nEquipPos)
    local KEnv = {
        math        = math,
        random      = KBattleFormulaEnv.random,
        makeInRange = KBattleFormulaEnv.makeInRange,
    }

    if tSrcCard then
        KBattleFormulaEnv.initSrcParam(KEnv, tBattleData, tSrcCard, tDstCard, nEquipPos)
    end
    KBattleFormulaEnv.initDstParam(KEnv, tBattleData, tSrcCard, tDstCard)
    KBattleFormulaEnv.initSkillParam(KEnv, tBattleData, tSrcCard, tDstCard, tSkillConfig)

    function KEnv.getDstRandomArmour(nRealRate, bNoReset)
        return getCardRandomArmour(KEnv, tDstCard, nRealRate, bNoReset)
    end
    return KEnv
end  

function KBattleFormulaEnv.initSrcParam(tEnv, tBattleData, tSrcCard, tDstCard, nEquipPos)
    tEnv.SrcLevel         = tBattleData:getLevel(tSrcCard)-- 攻击方 等级
    tEnv.SrcHitRate       = tBattleData:getHitRate(tSrcCard)--攻击方 命中
    tEnv.SrcAttack        = tBattleData:getAttack(tSrcCard)             -- 攻击方 火力
    tEnv.SrcPierce        = tBattleData:getPenetrate(tSrcCard)             -- 攻击方 穿透
    tEnv.SrcThump         = tBattleData:getThump(tSrcCard)           -- 攻击方 重击率
    tEnv.SrcSpeed         = tBattleData:getSpeed(tSrcCard)               -- 攻击方 速度
    tEnv.SrcCombo         = tBattleData:getCrit(tSrcCard)      --攻击方，必杀值
    
    
    tEnv.SrcLineupHitRate   = tBattleData:getLineupHitRate(tSrcCard) -- 攻击方 阵法命中补正
    tEnv.SrcLineupPierce    = tBattleData:getLineupPenetrate(tSrcCard) --攻击方 阵形穿透加成
    tEnv.SrcLineupAttack    = tBattleData:getLineupAttack(tSrcCard)    --攻击方 阵形火力加成
    tEnv.SrcStateHitRateCoe = tBattleData:getStateHitRateCoe(tSrcCard)--攻击方 命中耐久和士气影响系数
    tEnv.SrcStatePierceCoe  = tBattleData:getStatePenetrateCoe(tSrcCard)       --攻击方 穿透耐久和士气影响系数
    tEnv.SrcStateAttackCoe  = tBattleData:getStateAttackCoe(tSrcCard)          --攻击方 火力耐久和士气影响系数
    tEnv.SrcEquipAttack     = tBattleData:getEquipAttack(tSrcCard, nEquipPos)      -- 攻击方 炮弹攻击力
    tEnv.SrcHitCoe          = tBattleData:getHitCoe(tSrcCard)  --攻击方 命中系数
    tEnv.SrcPierceCoe       = tBattleData:getPierceCoe(tSrcCard)  --攻击方 穿透系数
    tEnv.SrcThumpCoe        = tBattleData:getThumpCoe(tSrcCard)  --攻击方 重击系数
    tEnv.SrcDamageCoe       = tBattleData:getDamageCoe(tSrcCard)  --攻击方 伤害系数
    tEnv.SrcLandHitRate     = tBattleData:getLandHitRate(tSrcCard)                    -- 攻击方 地形命中加成
    tEnv.SrcLandAttack      = tBattleData:getLandAttack(tSrcCard)                           -- 攻击方 地形火力加成
    tEnv.SrcNightValue      = tBattleData:getNightBattle(tSrcCard) --攻击方 夜战值
    tEnv.SrcBrokenComboCoe  = tBattleData:getBrokenComboCoe(tSrcCard) --攻击方 破损状态 必杀补正
    tEnv.SrcTeamPositionComboCoe = tBattleData:getTeamPositionComboCoe(tSrcCard)--攻击方 队伍中的位置的必杀补正

    if tSrcCard then
        tEnv.TankTypeScoutCoe  = tBattleData:getTankTypeScoutCoe(tSrcCard, tDstCard)   --坦克类型侦查系数
        tEnv.TankTypeDamageCoe = tBattleData:getTankTypeDamageCoe(tSrcCard, tDstCard) --坦克类型伤害系数
    end  

    print("攻击方 等级:", tEnv.SrcLevel)
    print("攻击方 命中:", tEnv.SrcHitRate)
    print("攻击方 火力:", tEnv.SrcAttack)
    print("攻击方 穿透:", tEnv.SrcPierce)
    print("攻击方 重击率:", tEnv.SrcThump)
    print("攻击方 速度:", tEnv.SrcSpeed)
    print("攻击方 必杀值:", tEnv.SrcCombo)
    
    print("攻击方 阵法命中补正:", tEnv.SrcLineupHitRate)
    print("攻击方 阵形穿透加成:", tEnv.SrcLineupPierce)
    print("攻击方 阵形火力加成:", tEnv.SrcLineupAttack)
    print("攻击方 命中耐久和士气影响系数:", tEnv.SrcStateHitRateCoe)
    print("攻击方 穿透耐久和士气影响系数:", tEnv.SrcStatePierceCoe)
    print("攻击方 火力耐久和士气影响系数:", tEnv.SrcStateAttackCoe)
    print("攻击方 炮弹攻击力:", tEnv.SrcEquipAttack)
    print("攻击方 命中系数:", tEnv.SrcHitCoe)
    print("攻击方 穿透系数:", tEnv.SrcPierceCoe)
    print("攻击方 重击系数:", tEnv.SrcThumpCoe)
    print("攻击方 伤害系数:", tEnv.SrcDamageCoe)
    print("攻击方 地形命中加成:", tEnv.SrcLandHitRate)
    print("攻击方 地形火力加成:", tEnv.SrcLandAttack)
    print("攻击方 夜战值:", tEnv.SrcNightValue)
    print("攻击方 破损状态 必杀补正:", tEnv.SrcBrokenComboCoe)
    print("攻击方 队伍中的位置 必杀补正:", tEnv.SrcTeamPositionComboCoe)  
    print("坦克类型侦查系数:", tEnv.TankTypeScoutCoe)
    print("坦克类型伤害系数:", tEnv.TankTypeDamageCoe)
end

function KBattleFormulaEnv.initDstParam(tEnv, tBattleData, tSrcCard, tDstCard) 
    local tSrcTeam   = tBattleData.tSrcTeam
    if tDstCard.bLeftSide then
        tSrcTeam  = tBattleData.tDstTeam
    end
    tEnv.SrcMaxScout       = tBattleData:getMaxScout(tSrcTeam)           -- 攻击方 最大侦查值

    tEnv.DstHitCoe         = tBattleData:getHitCoe(tDstCard)  --目标方 命中系数
    tEnv.DstDamageCoe      = tBattleData:getDamageCoe(tDstCard)  --目标方 伤害系数

    tEnv.DstDodge          = tBattleData:getDodge(tDstCard, false)--目标方 闪避
    tEnv.DstDodgeAddExtra  = tBattleData:getDodge(tDstCard, true)--目标方 闪避(带技能额外增加的闪避)
    
    tEnv.DstLineupDodge    = tBattleData:getLineupDodge(tDstCard)--目标 阵形闪避加成
    tEnv.DstLineupFrontArmour = tBattleData:getLineupFrontArmour(tDstCard)     -- 目标方 阵形前甲加成
    tEnv.DstLineupRearArmour  = tBattleData:getLineupRearArmour(tDstCard)      -- 目标方 阵形后甲加成
    tEnv.LineupRearArmourRate = tBattleData:getLineupAttackRearArmourRate(tSrcCard, tDstCard)    --阵形攻击对方后甲的概率增加值
    tEnv.DstRandomArmour   = nil   -- 目标护甲，有一定几率后甲
    tEnv.DstFrontArmour    = tDstCard.nFrontArmour -- 目标护甲，前甲
    tEnv.DstRearArmour     = tDstCard.nRearArmour    -- 目标方 后装甲

    if tSrcCard then
        local nSrcCardType = tSrcCard.nNamedType
        if nSrcCardType == CARD_TYPE.LIGHT_TANK or nSrcCardType == CARD_TYPE.MEDIUM_TANK then
            tEnv.DstNightArmour = tDstCard.nRearArmour
        else
            tEnv.DstNightArmour = tDstCard.nFrontArmour
        end
    end

    tEnv.ScoutHitRate = tBattleData:getScoutHitRate(tSrcCard or {}, tDstCard),--攻击方 侦查命中补正

    print("攻击方 最大侦查值:", tEnv.SrcMaxScout)
    print("目标方 命中系数:", tEnv.DstHitCoe)
    print("目标方 伤害系数:", tEnv.DstDamageCoe)
    print("目标方 闪避:", tEnv.DstDodge)
    print("目标方 闪避(带技能额外增加的闪避):", tEnv.DstDodgeAddExtra)
    print("目标方 阵形闪避加成:", tEnv.DstLineupDodge)
    print("目标方 阵形前甲加成:", tEnv.DstLineupFrontArmour)
    print("目标方 阵形后甲加成:", tEnv.DstLineupRearArmour)
    print("阵形攻击对方后甲的概率增加值:", tEnv.LineupRearArmourRate)
    print("目标方 前甲:", tEnv.DstFrontArmour)
    print("目标方 后装甲:", tEnv.DstRearArmour)
    print("目标方 护甲，有一定几率后甲:", tEnv.DstRandomArmour)
    print("目标方 夜战护甲:", tEnv.DstNightArmour)
    print("侦查命中补正:", tEnv.ScoutHitRate)
end

function KBattleFormulaEnv.initSkillParam(tEnv, tBattleData, tSrcCard, tDstCard, tSkillConfig)
    local nIndex = 1
    while true do
        local nParam = tSkillConfig["nParam" .. nIndex]
        if not nParam then break end
        tEnv["SkillParam" .. nIndex] = nParam
        nIndex = nIndex + 1
    end

    local szSkillType = tSkillConfig.szType
    if tSrcCard then
        local szSrcType = tBattleData:getCardTypeName(tSrcCard)
        local t = {SrcHitCoe = "_HIT", SrcPierceCoe = "_PIERCE", SrcThumpCoe = "_THUMP", SrcDamageCoe = "_DAMAGE"}
        for szKey, szValue in pairs(t) do
            local tConfig = KConfig:getLine("coefficient", szSkillType .. szValue)
            if tConfig then
                tEnv[szKey] = tConfig["n" .. szSrcType]
            end
        end
    end

    local szDstType = tBattleData:getCardTypeName(tDstCard)
    local t = {DstHitCoe = "_HIT", DstDamageCoe = "_DAMAGE"}
    for szKey, szValue in pairs(t) do
        local tConfig = KConfig:getLine("coefficient", szSkillType .. szValue)
        if tConfig then
            tEnv[szKey] = tConfig["n" .. szDstType]
        end
    end
end


function KBattleFormulaEnv.random(p1, p2)
    if not p1 or not p2 then
        return random()
    else
        return random({p1, p2})
    end
end

function KBattleFormulaEnv.makeInRange(nValue, tRange)
    return KUtil.makeInRange(nValue, tRange)
end

return KBattleFormulaEnv
