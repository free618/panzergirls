--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillAirBombLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillAirBombLogic = class( "KSkillAirBombLogic", KSkillBase )

function KSkillAirBombLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nEquipTemplateID   = nEquipTemplateID
end

function KSkillAirBombLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return true
end

function KSkillAirBombLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.END)
    end

    local tTaskIDList = {}
    local nID = self:asyncExec(self.playSkillAnimation, self, "playSkillAirBombAnimation", self.tBattleData, self.tBattleUI)
    table.insert(tTaskIDList, nID)
	
    local bombBeginFrame = 260
    local KBattleUIHelper = require("src/battle/KBattleUIHelper")
    KBattleUIHelper.delay(self.tBattleUI, bombBeginFrame / 60)
    
    for _, tCard in ipairs(self.tDstTeam) do
        local nType, nDamage = self:calcDamage(nil, tCard)
        local nID = self:asyncExec(self.hurtCard, self, self.tBattleData, self.tBattleUI, tCard, nType, nDamage)
        table.insert(tTaskIDList, nID)
    end

    self:waitAsync(tTaskIDList)
end

return KSkillAirBombLogic
