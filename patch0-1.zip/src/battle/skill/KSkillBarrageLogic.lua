--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillBarrageLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillBarrageLogic = class( "KSkillBarrageLogic", KSkillBase )

function KSkillBarrageLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nEquipTemplateID   = nEquipTemplateID
    self.nGunHitRate        = tSkillConfig.nParam1
    self.nGunThumpPrecent   = tSkillConfig.nParam2
    self.nGunAttackPrecent  = tSkillConfig.nParam3
    self.nDodge             = tSkillConfig.nParam4
	self.nDamagePrecentLow  = tSkillConfig.nParam5
	self.nDamagePrecentHigh = tSkillConfig.nParam6
    self.tStep    = nil
    self.tCalc = require("src/battle/formula/KBattleCalcArtilleryStrike").new(tBattleData)
end

function KSkillBarrageLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return tBattleData:getSkillUseState("Barrage")
end

function KSkillBarrageLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.READY)
        self:changeSkillButtonStateInStepType(BATTLE_STEP_TYPE.ARTILLERY_ACTION, SKILL_STATE.BUFF)
        self:changeSkillButtonStateInStepType(BATTLE_STEP_TYPE.DOG_FIGHT, SKILL_STATE.END)
    end

    -- table.insert(self.tBattleData.tBarrageSkill, self)
    local function onFire(tBattleStep)
        self:fire(tBattleStep)
    end 
    self.tBattleData:addOnArtilleryActionBeforeFire(onFire)

    for _, tCard in ipairs(self.tSrcTeam) do
        self.tBattleData:addExtraProperty(tCard, BATTLE_STEP_TYPE.ARTILLERY_ACTION, CARD_EXTRA_PROPERTY.DODGE, self.nDodge)
        self.tBattleData:addExtraProperty(tCard, BATTLE_STEP_TYPE.ARTILLERY_ACTION2, CARD_EXTRA_PROPERTY.DODGE, self.nDodge)
    end
end

function KSkillBarrageLogic:fire(tBattleStep)
    -- HArray.RemoveFirstByValue(self.tBattleData.tBarrageSkill, self)
    if not self.tBattleData:isTeamHasLivingCard(self.tSrcTeam) then return end
    if not self.tBattleData:isTeamHasLivingCard(self.tDstTeam) then return end
    self.tStep = tBattleStep
    print("----> [徐进弹幕] 攻击 [开始]")
    -- tBattleStep:playAnimation("playSkill3Aniamtion")

    local tTaskIDList   = {}

    local tAttackerList = self.tBattleData:getLivingCard(self.tSrcTeam, CARD_TYPE.SELF_PROPELLED_GUN)
    -- print("----> [徐进弹幕] 火炮攻击 [开始]", #tAttackerList)
    for _, tSrcCard in ipairs(tAttackerList) do
        local nID = tBattleStep:asyncExec(self.processGunAttackOnce, self, tBattleStep, tSrcCard)
        table.insert(tTaskIDList, nID)
    end

    local nID = self:asyncExec(self.playSkillAnimation, self, "playSkillBarrageAnimation", self.tBattleData, self.tBattleUI)
    table.insert(tTaskIDList, nID)

    local bombBeginFrame    = 160 + 140 -- 161 is ani_battle_skill_barrage_v1.cab getDuration()
    local KBattleUIHelper   = require("src/battle/KBattleUIHelper")
    KBattleUIHelper.delay(self.tBattleUI, bombBeginFrame / 60)

    for _, tCard in ipairs(self.tDstTeam) do
        local nType = ATTACK_RESULT.NORMAL
        local nDamage = math.ceil(tCard.nMaxHP * random({self.nDamagePrecentLow, self.nDamagePrecentHigh}))
        local nID = tBattleStep:asyncExec(self.hurtCard, self, self.tBattleData, self.tBattleUI, tCard, nType, nDamage)
        table.insert(tTaskIDList, nID)
    end

    tBattleStep:waitAsync(tTaskIDList)
end

function KSkillBarrageLogic:processGunAttackOnce(tBattleStep, tSrcCard)
    tBattleStep:print("processAttackOnce", tSrcCard.bLeftSide, tSrcCard.nIndex)    

    if not self.tBattleData:canGunAttack(tSrcCard) then
        return
    end

    local tTaskIDList = {}

    local i = 1
    local j = 0
    while true do
        i = i + 1
        local nEquipID = tSrcCard["nEquip" .. i]
        if not nEquipID then break end

        if nEquipID > 0 then
            local nTaskID = tBattleStep:asyncExec(self.gunFireBulletOnce, self, tBattleStep, tSrcCard, i, j)
            table.insert(tTaskIDList, nTaskID)

            j = j + 1
        end
    end

    tBattleStep:waitAsync(tTaskIDList)
end

function KSkillBarrageLogic:gunFireBulletOnce(tBattleStep, tSrcCard, nEquipPos, attackIndex)
    local nEquipID = tSrcCard["nEquip" .. nEquipPos]

    local tDstCard = self.tBattleData:getRandomCard(not tSrcCard.bLeftSide)
    if not tDstCard then
        return
    end

    tBattleStep:delay(attackIndex * 1.0)
    tBattleStep:playAnimation("playArtilleryStrikeCardAttackAnimation", tSrcCard)
 
    local nType, nDamage = self:calcDamage(tSrcCard, tDstCard, nEquipPos)

    local nBulletID = tBattleStep:addBullet(tSrcCard, tDstCard, nType, nDamage)
    KSound.playEffect("howitzer")
    tBattleStep:playAnimation("playArtilleryStrikeBulletFireAnimation", tSrcCard, tDstCard)
    tBattleStep:playAnimation("playArtilleryStrikeBulletAnimation", tDstCard)
    KSound.playEffect("boom")

    local KBattleConfig         = require("battle/KBattleConfig")
    local oldCardState          = KBattleConfig.getBrokenState(tDstCard)
    local bIsLeftTeam           = tDstCard.bLeftSide

    tBattleStep:applyBulletDamage(nBulletID)
    
    if not bIsLeftTeam then return end
    local newCardState          = KBattleConfig.getBrokenState(tDstCard)
    if oldCardState == CARD_BROKEN_STATE.MIDDLE and newCardState == CARD_BROKEN_STATE.BIG then return end
    if newCardState == oldCardState then return end
    if newCardState ~= CARD_BROKEN_STATE.MIDDLE and newCardState ~= CARD_BROKEN_STATE.BIG then return end
    table.insert(tBattleStep.tShowBrokenList, {tDstCard, newCardState, tBattleStep.nStepType == BATTLE_STEP_TYPE.NIGHT_FIGHT})
    if #tBattleStep.tShowBrokenList ~= 1 then return end
    local backgroundType        = tBattleStep.tBattleData.tSrcTeam.background

    while #tBattleStep.tShowBrokenList > 0 do
        local tOneToShow = tBattleStep.tShowBrokenList[1]
        local tCard = tOneToShow[1]
        local nState = tOneToShow[2]
        local bNightBattle = tOneToShow[3]
        tBattleStep:playAnimation("playBrokenAnimation", tCard, backgroundType, bNightBattle, nState)
        table.remove(tBattleStep.tShowBrokenList, 1)
    end
end

function KSkillBarrageLogic:changeSkillButtonState(nState)
    local nPosition  = self.nSkillPosition
    local tSkillList = self.tBattleData:getLeftTeamSkillList()
    local tOneSkill  = tSkillList[nPosition]

    if tOneSkill.nState >= nState then return end
    tOneSkill.nState = nState

    if nState == SKILL_STATE.READY then
        self.tBattleUI:readySkillButtonUI(nPosition)
    elseif nState == SKILL_STATE.BUFF then
        self.tBattleUI:buffSkillButtonUI(nPosition, "avoid")
    elseif nState == SKILL_STATE.END then
        self.tBattleUI:unabledSkillButtonUI(nPosition)
    end
end

return KSkillBarrageLogic
