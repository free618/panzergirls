--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillComboLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local UI_INTERVAL = 0.1
local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillComboLogic = class( "KSkillComboLogic", KSkillBase )

function KSkillComboLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nRepeatingFireRate = tSkillConfig.nParam1
    self.nAttackPrecent     = tSkillConfig.nParam2
    self.nThumpPrecent      = tSkillConfig.nParam3
    self.nRearArmourRate    = tSkillConfig.nParam4
    self.nEquipTemplateID   = nEquipTemplateID
    self.tCalc = require("src/battle/formula/KBattleCalcCombo").new(tBattleData)
end

function KSkillComboLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return tBattleData:getSkillUseState("Combo")
end

function KSkillComboLogic:use()
    local tBattleData = self.tBattleData
    local isLeft = (tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        if tBattleData.nCurrentStep < BATTLE_STEP_TYPE.ARTILLERY_ACTION then
            self:changeSkillButtonState(SKILL_STATE.READY)
            self:changeSkillButtonStateInStepType(BATTLE_STEP_TYPE.ARTILLERY_ACTION, SKILL_STATE.BUFF)
        else 
            self:changeSkillButtonState(SKILL_STATE.BUFF)
        end
        
        self:changeSkillButtonStateInStepType(BATTLE_STEP_TYPE.DOG_FIGHT, SKILL_STATE.END)
    end

    for _, tCard in ipairs(self.tSrcTeam) do
        local nTankType
        if tCard.bLeftSide then
            local tCardConfig = KUtil.getCardConfig(tCard.nTemplateID)
            assert(tCardConfig)
            nTankType = tCardConfig.nTankType
        else
            local tMonsterConfig = KConfig.monster[tCard.nTemplateID]
            assert(tMonsterConfig)
            nTankType = tMonsterConfig.nType
        end
        if nTankType ~= CARD_TYPE.SELF_PROPELLED_GUN then
            local nComboMuti  = self.tBattleData:getComboMuti(tCard)
            if nComboMuti then
                tCard.tComboSkill = {skill = self, muti = nComboMuti}
            end
        end
    end

    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper       = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    local tTaskIDList = {}

    KBattleSkillAnimation.playAnimation("playSkillComboAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig)

    for _, tCard in ipairs(self.tDstTeam)do
        local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillStrikeTargetAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tCard)
        table.insert(tTaskIDList, nID)

        KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
    end

    self:waitAsync(tTaskIDList)
end

function KSkillComboLogic:fire(tBattleStep, tSrcCard, nComboMuti)
    local nRandomValue = random()
    local bCombo = nRandomValue < self.nRepeatingFireRate
    if bCombo then
        local function funCalcDamage(tSrcCard, tDstCard)
            return self:calcDamage(tSrcCard, tDstCard, nil, nComboMuti)
        end
        -- local nDamageType, nDamage = self:calcDamage(tSrcCard, tDstCard, nMuti)
        tBattleStep:processAttackCombo(tSrcCard, funCalcDamage)
        return true
    end 
    
end

function KSkillComboLogic:changeSkillButtonState(nState)
    local nPosition  = self.nSkillPosition
    local tSkillList = self.tBattleData:getLeftTeamSkillList()
    local tOneSkill  = tSkillList[nPosition]

    if tOneSkill.nState >= nState then return end
    tOneSkill.nState   = nState
    
    if nState == SKILL_STATE.READY then
        self.tBattleUI:readySkillButtonUI(nPosition)
    elseif nState == SKILL_STATE.BUFF then
        self.tBattleUI:buffSkillButtonUI(nPosition, "cri")
    elseif nState == SKILL_STATE.END then
        self.tBattleUI:unabledSkillButtonUI(nPosition)
    end
end

return KSkillComboLogic
