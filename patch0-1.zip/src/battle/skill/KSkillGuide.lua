--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillGuide.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillGuide = class( "KSkillGuide", KSkillBase )

function KSkillGuide.canUse(tBattleData, tSrcTeam, tDstTeam)
    return true
end

function KSkillGuide:use()
    self:playAnimation("playSkill1Aniamtion", self.tBattleData, self.tBattleUI)

    print("-----> Call actionSkill0~")
    local nDamage       = 34 
    local nType         = ATTACK_RESULT.NORMAL
    local tTaskIDList   = {}
    for _, tCard in ipairs(self.tDstTeam) do
        local nID = self:asyncExec(self.hurtCard, self, self.tBattleData, self.tBattleUI, tCard, nType, nDamage)
        table.insert(tTaskIDList, nID)
    end

    self:waitAsync(tTaskIDList)
end

return KSkillGuide