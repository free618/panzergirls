--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillLandmineLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillLandmineLogic = class( "KSkillLandmineLogic", KSkillBase )

function KSkillLandmineLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nAttack      = tSkillConfig.nParam1
    self.nEffectRate  = tSkillConfig.nParam2
    self.nEquipTemplateID   = nEquipTemplateID
end

function KSkillLandmineLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return tBattleData:getSkillUseState("Landmine")
end

function KSkillLandmineLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.END)
    end

    for _, tCard in ipairs(self.tDstTeam) do
        tCard.tLandmine = self
    end

    local tTaskIDList = {}
    local nID = self:asyncExec(self.playSkillAnimation, self, "playSkillLandmineAnimation", self.tBattleData, self.tBattleUI)
    table.insert(tTaskIDList, nID)

    self:waitAsync(tTaskIDList)
end

function KSkillLandmineLogic:effect(tStep, tCard)
    local nRandomValue   = random()
    local bEffect = nRandomValue < tCard.tLandmine.nEffectRate * self:getHitCoe(tCard)
    if bEffect then
        local tTaskIDList = {}
        local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
        local nEquipTemplateID  = self.nEquipTemplateID
        local tSkillConfig      = self.tSkillConfig
        local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
        local equipName         = equipConfig.szName
        local KBattleUIHelper   = require("src/battle/KBattleUIHelper")
        local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playLandmineBoomAnimation", self.tBattleData, self.tBattleUI, isLeft, equipConfig, tSkillConfig, tCard)
        table.insert(tTaskIDList, nID)

        KSound.playEffect("boom")

        local nType, nDamage     = self:calcDamage(nil, tCard)
        local nID = self:asyncExec(self.hurtCard, self, self.tBattleData, self.tBattleUI, tCard, nType, nDamage)
        table.insert(tTaskIDList, nID)
        
        tCard.tLandmine = nil
        self:waitAsync(tTaskIDList)
    end
end

return KSkillLandmineLogic
    