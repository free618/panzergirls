--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSkillSupplyLogic.lua
--  Creator     : LiuLingLi
--  Date        : 2016/02/25   22:13
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local UI_INTERVAL = 0.1  -- ui need
local KSkillBase = require("src/battle/skill/KSkillBase")
local KSkillSupplyLogic = class( "KSkillSupplyLogic", KSkillBase )

function KSkillSupplyLogic:ctor(tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nEquipTemplateID, nSkillPosition)
    KSkillBase.ctor(self, tBattleUI, tBattleData, tSkillConfig, tSrcTeam, tDstTeam, nSkillPosition)
    self.nOil         = tSkillConfig.nParam1
    self.nAmmo        = tSkillConfig.nParam2
    self.nEquipTemplateID = nEquipTemplateID
end

function KSkillSupplyLogic.canUse(tBattleData, tSrcTeam, tDstTeam)
    return true
end

function KSkillSupplyLogic:use()
    local isLeft = (self.tBattleData.tSrcTeam == self.tSrcTeam)
    if isLeft then 
        self:changeSkillButtonState(SKILL_STATE.END)
    end

    local tDataToSync = {}
    print("[补给开始]", self.nOil, self.nAmmo)
    for i, tCard in ipairs(self.tSrcTeam) do
        if tCard.nCurrentHP > 0 then
            print("[补给前]：", i, tCard.nCarryOil, "/", tCard.nMaxOil, ",", tCard.nCarryAmmo, "/", tCard.nMaxAmmo)
            tCard.nCarryOil  = tCard.nCarryOil + self.nOil
            if tCard.nCarryOil > tCard.nMaxOil then
                tCard.nCarryOil = tCard.nMaxOil
            end
            tCard.nCarryAmmo = tCard.nCarryAmmo + self.nAmmo
            if tCard.nCarryAmmo > tCard.nMaxAmmo then
                tCard.nCarryAmmo = tCard.nMaxAmmo
            end
            print("[补给后]：", tCard.nCarryOil, "/", tCard.nMaxOil, ",", tCard.nCarryAmmo, "/", tCard.nMaxAmmo)

            local oneCardData = {nCardID = tCard.nID, nOil = tCard.nCarryOil, nAmmo = tCard.nCarryAmmo}
            table.insert(tDataToSync, oneCardData)
        end
    end

    require("src/network/KC2SProtocolManager"):SupplyTeamInBattle(tDataToSync)

    local nEquipTemplateID  = self.nEquipTemplateID
    local tSkillConfig      = self.tSkillConfig
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local equipName         = equipConfig.szName
    local KBattleUIHelper       = require("src/battle/KBattleUIHelper")
    local KBattleSkillAnimation = require("src/battle/KBattleSkillAnimation")
    local tTaskIDList = {}
    
    KBattleSkillAnimation.playAnimation("playSkillSupplyAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig)

    for _, tCard in ipairs(self.tSrcTeam)do
        if tCard.nCurrentHP > 0 then
            local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillSupplyOilAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tCard, self.nOil)
            table.insert(tTaskIDList, nID)
            local nID = self:asyncExec(KBattleUIHelper.playAnimation, "playSkillSupplyAmmoAnimation", self.tBattleData, self.tBattleUI, isLeft, equipName, tSkillConfig, tCard, self.nAmmo)
            table.insert(tTaskIDList, nID)

            KBattleUIHelper.delay(self.tBattleUI, UI_INTERVAL)
        end
    end

    self:waitAsync(tTaskIDList)
end

return KSkillSupplyLogic
