--
-- FileName: event_dispatcher.lua
-- Author: hanruofei
-- Time: 2013/6/18
-- Comment:
--

 SHEventDispatcher = SHEventDispatcher or Extend()
 
 function SHEventDispatcher:New()
	self.tbCallBack = self.tbCallBack or {}
 end
  
 function SHEventDispatcher:Register(nEventID, fnCallBack, ...)
	local tbCallBack = self.tbCallBack[nEventID] or {}
	local nCallBackID = #tbCallBack + 1
	tbCallBack[nCallBackID] = {fnCallBack, {...}}
	self.tbCallBack[nEventID] = tbCallBack
	

	assert(type(fnCallBack) == "function")

	return nCallBackID
 end
 
 function SHEventDispatcher:UnRegister(nEventID, nCallBackID)
	local tbCallBack = self.tbCallBack[nEventID]
	tbCallBack[nCallBackID] = nil
 end
 
 function SHEventDispatcher:UnRegisterByFunction(nEventID, fnFunc)
 	local tbCallBack = self.tbCallBack[nEventID]
	for k, v in pairs(tbCallBack) do
		if v == fnFunc then
			tbCallBack[v] = nil
			break
		end
	end
 end
 
 function SHEventDispatcher:Fire(nEventID, ...)
	local tbCallBack = self.tbCallBack[nEventID]
	if not tbCallBack then
		return
	end
	local tbInputArg = {...}
	for _, v in pairs(tbCallBack) do
		local tbArg = self:MergeTable(v[2], tbInputArg)
		v[1](unpack(tbArg, 1, table.maxn(tbArg)))
	end
 end
 
 function SHEventDispatcher:MergeTable(tbA, tbB)
	local tbResult = {}
		
	if tbA then
		for _, v in ipairs(tbA) do
			table.insert(tbResult, v)
		end
	end
	
	if tbB then
		for _, v in ipairs(tbB) do
			table.insert(tbResult, v)
		end
	end
	
	return tbResult
 end
 
 