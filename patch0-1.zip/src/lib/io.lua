local load = loadstring

function io.openinifile(strFile)
    local tResult = {}
    local tCurSection
    local strBom = "\239\187\191"

    local nLineIndex = 0
    for strLine in io.lines(strFile) do
        nLineIndex = nLineIndex + 1
        if nLineIndex == 1 then
            strLine = string.removestart(strLine, strBom)
        end
        strLine = string.trim(strLine)
        if #strLine > 0 then
            local strFirstChar = string.sub(strLine, 1, 1)
            if strFirstChar == "[" then
                local _, _, strSection = string.find(strLine, "^%[(.+)%]$")
                assert(strSection)
                assert(tResult[strSection] == nil)

                tCurSection = {}
                tResult[strSection] = tCurSection
            elseif strFirstChar ~= "#" then
                local _, _, strKey, strValue = string.find(strLine, "^([^=]+)=(.*)$")
                assert(strKey)
                assert(strValue)
                assert(tCurSection[strKey] == nil)

                local nNumValue = tonumber(strValue)
                if not nNumValue then
                    tCurSection[strKey] = strValue
                else
                    tCurSection[strKey] = nNumValue
                end
            end
        end
    end

    return tResult
end

function io.opentabfile(strFile, varKeyCreator, varKeyCreator2)
    local tResult = {}
    local tKeyList = nil
    local strBom = "\239\187\191"

    local fileData = cc.FileUtils:getInstance():getStringFromFile(strFile)
    fileData = string.removestart(fileData, strBom)
    fileData = string.gsub(fileData, "\r\n", "\r")
      
    local nLineIndex = 0
    for strLine in string.gmatch(fileData, "[^\r]+") do
        nLineIndex = nLineIndex + 1
        if nLineIndex == 1 then
            strLine = string.removestart(strLine, strBom)
            tKeyList = string.split(strLine, "\t")
            assert(HArray.IsValueUnique(tKeyList))
        else
            local tLine = {}
            local tValues = string.split(strLine, "\t")
            assert(#tValues <= #tKeyList)

            for i, strKey in ipairs(tKeyList) do
                local strValue = tValues[i]
                assert(strValue)

                local varValue = nil
                if string.startwith(strKey, "n") then
                    if strValue == "" then
                        varValue = 0
                    else
                        varValue = tonumber(strValue)
                        assert(varValue, strValue .. "|" .. strKey)
                    end
                elseif string.startwith(strKey, "sz") then
                    varValue = strValue or ""
                elseif string.startwith(strKey, "b") then
                    if strValue == "" then
                        varValue = false
                    else
                        varValue = tonumber(strValue)
                        assert(varValue)
                        varValue = varValue ~= 0
                    end
                elseif string.startwith(strKey, "fun") then
                    if strValue ~= "" then
                        varVrealue = assert(load(strValue))
                    end
                elseif string.startwith(strKey, "lsz") then
                    if strValue ~= "" then
                        varValue = assert(load("return ".. strValue))
                        varValue = varValue()
                    end
                 elseif string.startwith(strKey, "an") then
                    if strValue ~= "" then
                        varValue = load("return {" .. string.gsub(strValue, "|", ",") .. "}")()
                    else
                        varValue = {}
                    end           
                elseif string.startwith(strKey, "t") then
                    varValue = load("return {" .. strValue .. "}")()
                else
                    assert(false, "Invalid Type of strKey " .. strKey)
                end

                tLine[strKey] = varValue
            end

            local varKey = #tResult + 1
            if type(varKeyCreator) == "string" then
                varKey = tLine[varKeyCreator]
            elseif type(varKeyCreator) == "function" then
                varKey = varKeyCreator(tLine)
            elseif varKey ~= nil then
                assert(false)
            end

            local varKey2
            if type(varKeyCreator2) == "string" then
                varKey2 = tLine[varKeyCreator2]
            elseif type(varKeyCreator2) == "function" then
                varKey2 = varKeyCreator2(tLine)
            end

            if varKey2 == nil then
                assert(tResult[varKey] == nil)
                tResult[varKey] = tLine
            else
                if tResult[varKey] == nil then
                    tResult[varKey] = {}
                end
                assert(tResult[varKey][varKey2] == nil)
                tResult[varKey][varKey2] = tLine
            end
        end
    end
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.LOAD_FILE_COMPLETE)    
    return tResult
end


