
require "lib.class"
require "lib.event"
require "lib.event_dispatcher";
require "lib.tcp_client"
require "lib.timer"
require "lib.misc"
require "lib.io"
require "lib.string"
require "lib.table"
require "lib.time"

EventCenter 	= EventCenter or New(SHEventDispatcher)
TimerManager 	= TimerManager or New(SHTimer)
GlobalStatus	= GlobalStatus or {nCurrentTime = 0, nDeltaTime = 0}

SHLib = {}

function SHLib:Init()

end

function SHLib:UnInit()
end


function SHLib:Activate(nCurrentTime)
	GlobalStatus.nCurrentTime = nCurrentTime
	GlobalStatus.nServerTime = GlobalStatus.nCurrentTime + GlobalStatus.nDeltaTime

	TimerManager:Activate()
end