local function FormatString(szFormat, ...)
	local nArgCount = select("#", ...)
	if nArgCount <= 0 then
		return szFormat
	end

	local tbArg = {...}
	local nIndex = 0
	local bAAppeared = false
	local function fnReplace(v)
		if bAAppeared then
			return v
		end

		if nIndex >= nArgCount then
			return v
		end

		if v ~= "%A" then
			nIndex = nIndex + 1
			return tostring(tbArg[nIndex])
		end

		bAAppeared = true
		nIndex = nIndex + 1
		local szResult = tostring(tbArg[nIndex])
		while nIndex < nArgCount do
			nIndex = nIndex + 1
			szResult = szResult .. "," .. tostring(tbArg[nIndex])
		end
		return szResult
	end
	return string.gsub(szFormat, "(%%%w)", fnReplace)
end

function Log(szFormat, ...)
	local strMsg = FormatString(szFormat, ...)
	C_Log(strMsg)
end

function LogStack(szFormat, ...)	
	local strMsg = FormatString(szFormat, ...) .. debug.traceback()
	C_Log(strMsg)
end

local function ErrorProcess(szError)
	C_Log(debug.traceback(tostring(szError), 5))
end

function SafeCall(fnFunc, ...)
	local tArgs = {...}
	local function fc()
		fnFunc(unpack(tArgs, 1, table.maxn(tArgs)))
	end
	return xpcall(fc, ErrorProcess)
end


