

function string.split(strValue, strSeperater)
    assert(#strSeperater == 1)

    assert(strValue)

    local tResult = {}

    local i = 1
    while true do
        local j = string.find(strValue, strSeperater, i)
        if not j then 
            table.insert(tResult, string.sub(strValue, i, #strValue))
            break 
        end

        table.insert(tResult, string.sub(strValue, i, j - 1))
        i = j + #strSeperater
    end

    return tResult
end

function string.startwith(strValue, strStart)
	return string.sub(strValue, 1, string.len(strStart)) == strStart 
end

function string.removestart(strValue, strStart)
	if not string.startwith(strValue, strStart) then
		return strValue
	end

	return string.sub(strValue, string.len(strStart) + 1)
end

function string.trimStart(strValue)
    local nIndex = string.find(strValue, "%S")
    if not nIndex then
        return ""
    end

    return string.sub(strValue, nIndex)
end

function string.trimEnd(strValue)
    local nIndex = string.find(strValue, "%s+$")
    if not nIndex then
        return strValue
    end

    return string.sub(strValue, 1, nIndex - 1)
end

function string.trim(strValue)
    local strOldValue = strValue
    strValue = string.trimStart(strValue)
    strValue = string.trimEnd(strValue)

    return strValue
end

function string.utf8Len(strValue)
    assert(strValue)
    local nUTFLen = 0
    for i = 1, #strValue do 
        local nChar = string.byte(strValue, i)
        if (nChar >= 192 and nChar <= 252) then
            nUTFLen = nUTFLen + 1
        elseif nChar < 128 then
            nUTFLen = nUTFLen + 0.5
        end
    end

    return nUTFLen
end