 
local function Info(szFormat, ...)
	local tArg = {...}
	for i = 1, select("#", ...) do
		tArg[i] = tostring(tArg[i])
	end
	local szMessage = string.format(szFormat, unpack(tArg))
	print(szMessage)
end

function table.shallowcopy(t)
    local tResult = {}
    for k, v in pairs(t) do
        tResult[k] = v
    end
    return tResult
end

function table.output(t, strPrefix, strTab)
    strPrefix = strPrefix or ""

    strTab = strTab or "\t"

    if strPrefix and strPrefix ~= "" then
        Info(strPrefix)
    end

    if t[1] then
        for k1, v1 in ipairs(t) do
            Info("%s [%s] = %s", strTab, k1, v1)
            if type(v1) == "table" then
                table.output(v1, nil, strTab .. "\t")
            end
        end
    else
        for k1, v1 in pairs(t) do
            Info("%s [%s] = %s", strTab, k1, v1)
            if type(v1) == "table" then
                table.output(v1, nil, strTab .. "\t")
            end
        end
    end
end

function table.tostring(t, nMaxLevel, strTab, nCurLevel)
    nMaxLevel = nMaxLevel or -1
    nCurLevel = nCurLevel or 1
    local szTable = "{"
    strTab = strTab or ""
    local szInterval = string.rep(strTab, nCurLevel)

    if t[1] then
        for k1, v1 in ipairs(t) do
            szTable = szTable .. string.format("\n%s [%s] = %s", szInterval, k1, v1)
            if type(v1) == "table" and nMaxLevel ~= 1 then
                szTable = szTable .. table.tostring(v1, nMaxLevel - 1, strTab, nCurLevel + 1)
            end
        end
    else
        for k1, v1 in pairs(t) do
            szTable = szTable .. string.format("\n%s [%s] = %s", szInterval, k1, v1)
            if type(v1) == "table" and nMaxLevel ~= 1 then
                szTable = szTable .. table.tostring(v1, nMaxLevel - 1, strTab, nCurLevel + 1)
            end
        end
    end

    szTable = szTable .. "}"
    return szTable
end

function table.getkey(t, vValue)
	for k, v in pairs(t) do
		if v == vValue then
			return k
		end
	end
end

function table.add(t1, t2)
    local t = {}
    for key, value in pairs(t1) do
        assert(type(value) == "number")
        t[key] = value
    end
    for key, value in pairs(t2) do
        assert(type(value) == "number")
        if value > 0 then
            t[key] = (t[key] or 0) + value
        end
    end
    return t
end

function table.sum(t)
    local nSum = 0
    for key, value in pairs(t) do
        assert(type(value) == "number")
        nSum = nSum + value
    end
    return nSum
end

HArray = HArray or {}

function HArray.IsValueUnique(t)
	local tTemp = {}
	for _, v in pairs(t) do
		if tTemp[v] ~= nil then
			return false
		end

		tTemp[v] = true
	end

	return true
end

function HArray.FindFirstByValue(t, vValue)
	for i, v in ipairs(t) do
		if v == vValue then
			return v
		end
	end
end

function HArray.FindFirstIndexByValue(t, vValue)
    for i, v in ipairs(t) do
        if v == vValue then
            return i
        end
    end
end

function HArray.RemoveFirstByValue(t, vValue)
	assert(vValue ~= nil)
	for i, v in ipairs(t) do
		if v == vValue then
			table.remove(t, i)
			return v
		end
	end
end

function HArray.UniqueInsertByValue(t, vValue)
	if HArray.FindFirstByValue(t, vValue) then
		return false
	end

	table.insert(t, vValue)
	return true
end

function HArray.FindFirst(t, vKey, vKeyValue)
	assert(vKey)
	assert(vKeyValue ~= nil, debug.traceback())

	for i, v in ipairs(t) do
		if v[vKey] == vKeyValue then
			return v
		end
	end
end

function HArray.FindFirstEx(t, vKey, vKeyValue)
	assert(vKey)
	assert(vKeyValue ~= nil, debug.traceback())

	for i, v in ipairs(t) do
		if v[vKey] == vKeyValue then
			return i, v
		end
	end
end

function HArray.RemoveFirst(t, vKey, vKeyValue)
	assert(vKeyValue)
	for i, v in ipairs(t) do
		if v[vKey] == vKeyValue then
			table.remove(t, i)
			return v
		end
	end
end

function HArray.UniqueInsert(t, v, vKey)
	if HArray.FindFirst(t, vKey, v[vKey]) then
		return false
	end

	table.insert(t, v)
	return true
end

function HArray.FindFirstByID(t, nID)
	return HArray.FindFirst(t, "nID", nID)
end

function HArray.RemoveFirstByID(t, nID)
	for i, v in ipairs(t) do
		if v.nID == nID then
			table.remove(t, i)
			return v
		end
	end
end

function HArray.FindFirstByFun(t, vKeyValue, fun)
    assert(vKeyValue)
    assert(fun ~= nil, debug.traceback())

    for i, v in ipairs(t) do
        if fun(v) == vKeyValue then
            return v
        end
    end
end

function HArray.UniqueInsertByID(t, v)
	if HArray.FindFirstByID(t, v.nID) then
		return false
	end

	table.insert(t, v)
	return true
end

function HArray.numberAdd(t1, t2)
    local new_table = {}
    local num
    if #t1 < #t2 then
        num = #t2
    else
        num = #t1
    end
    for i = 1, num do
        assert(t1[i] == nil or type(t1[i]) == "number")
        assert(t2[i] == nil or type(t2[i]) == "number")
        new_table[i] = (t1[i] or 0) + (t2[i] or 0)
    end
    return new_table
end

function HArray.arraySub(t1, t2)
    local new_table = {}
    for _, v1 in ipairs(t1) do
        if HArray.FindFirstByValue(t2, v1) == nil then
            table.insert(new_table, v1)
        end
    end
    return new_table
end

function HArray.inserArray(t1, t2)
    for _, v in ipairs(t2) do
        table.insert(t1, v)
    end
end
