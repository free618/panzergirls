------------------------------------------
----- FileName:SHTcpClient.lua
----- Creator: Han Ruofei
----- CreateTime: 2013/6/20
-------------------------------------------

if C_TcpClient.SetTargetAddress ~= nil then
	return require "lib.tcp_client_v2"
end

require "lib.class"
require "lib.event_dispatcher"

SHTcpClient = SHTcpClient or Extend()

function SHTcpClient:New(strName)
	assert(strName)

	self.strName = strName
	self.dwID = 0

	EventCenter:Register(SHGLOBAL_EVENT.TCP_CLIENT_DISCONNECT, self.OnClientDisconnect, self)
	EventCenter:Register(SHGLOBAL_EVENT.TCP_CLIENT_READ, self.OnDefaultRecvPackage, self)	
end

function SHTcpClient:Init()
	return true
end

function SHTcpClient:OnDefaultRecvPackage(nClientID, szFunc, ...)
	if nClientID ~= self.dwID then
		return
	end

	self:OnRecvPackage(szFunc, ...)
end

function SHTcpClient:Activate(nCurrentTime)

end

function SHTcpClient:Connect(strIP, dwPort)
	if self.dwID ~= 0 then
		self:Disconnect()
		self.dwID = 0
	end

	Log("Connect To (%s:%s)", strIP, dwPort)
	self.dwID = C_TcpClient.Open(strIP, dwPort)	
	return self.dwID ~= 0
end

function SHTcpClient:Disconnect()
	if self.dwID ~= 0 then
		C_TcpClient.Close(self.dwID)
		self.dwID = 0
		
		Log(self.strName .. " Disconnect!")
	end
	
	return true
end

function SHTcpClient:Send( ...)
	if self.dwID == 0 then return false end
	return C_TcpClient.Send(self.dwID, ...)
end

function SHTcpClient:IsConnected()
	return self.dwID ~= 0
end

function SHTcpClient:OnClientDisconnect(dwID, nErrorCode)
	if self.dwID ~= dwID then
		return
	end
	
	Log(self.strName .. " Disconnect!")
	
	self.dwID = 0

	if self.OnClientDisconnectCB then
		self:OnClientDisconnectCB()
	end
end

function SHOnTCPClientPackageReceived(nClientID, ...)
	EventCenter:Fire(SHGLOBAL_EVENT.TCP_CLIENT_READ, nClientID, ...)
end

function SHOnTCPClientDisconnected(nClientID, nErrorCode)
	EventCenter:Fire(SHGLOBAL_EVENT.TCP_CLIENT_DISCONNECT, nClientID, nErrorCode)
end

function SHOnSDKAgentMessage(...)
    --cclog("Call Global Function -----> OnSDKAgentEvent~ begin")
    --for k, v in pairs(package.loaded) do
        --cclog("-----> package.loaded k:%s\nv:%s", k, tostring(v))
    --end
    local bResult, KSDKAgent = pcall(require,"src/logic/KSDKAgent")
    --cclog("-----> KSDKAgent = %s", tostring(KSDKAgent))
    KSDKAgent:dispatchMessage(...)
    --cclog("Call Global Function -----> OnSDKAgentEvent~ end")
end
