--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KAccelerateCheck.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/06/21   15:00
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     : 
--  *********************************************************************

local KAccelerateCheck = {}

local MAX_CLIENT_ADD_RATIO = 1.45
local MAX_SERVER_ADD_RATIO = 1.45

local CLIENT_TOTAL_STATISTIC_TIME = 30
local REQUEST_SERVER_TIME_INTERVAL = 120


local MAX_CLIENT_CHECK_COUNT = 3
local MAX_SERVER_CHECK_COUNT = 4

local bShowAccelerate           = false
local bSendRequestServerTime    = false 

local serverTime            = 0
local clientTime            = 0

local statisticClientTickTime   = 0
local statisticClientTime       = 0
local statisticDelayTime        = 0

local requestServerTime         = 0

local serverCheckCount = 0
local clientCheckCount = 0

function KAccelerateCheck.cleanData()
    bShowAccelerate         = false
    bSendRequestServerTime  = false

    serverTime              = 0
    clientTime              = 0
    statisticClientTickTime = 0
    statisticClientTime     = 0
    statisticDelayTime      = 0
    requestServerTime       = 0
    serverCheckCount        = 0
    clientCheckCount        = 0
end

local function sendAccelerateLog(bClientAccelerate, nRatio)
    local name  = KPlayer.name
    local id    = KPlayer.id

    local str
    if bClientAccelerate then
        local dateTime = os.date("%Y-%m-%d %H:%M:%S", os.time())
        str = string.format(" player accelerate ratio:%s, ClientTime:%s, nPlayerID:%s, Name:%s", nRatio, dateTime, id, name)
    else 
        local dateTime = os.date("%Y-%m-%d %H:%M:%S", serverTime)
        str = string.format(" player accelerate ratio:%s, ServerTime:%s, nPlayerID:%s, Name:%s", nRatio, dateTime, id, name)
    end

    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("AccelerateCheck", str)
    KLogGather.sendLog("AccelerateCheck")
end

local function showAccelerateTip(bClientAccelerate, nRatio)
    if bShowAccelerate then return end

    local function onLoginOut()
        KPlayer:Logout()
        
        local gameScene = require("src/ui/login/KUILoginScene").create()
        if cc.Director:getInstance():getRunningScene() then
            cc.Director:getInstance():replaceScene(gameScene)
        else
            cc.Director:getInstance():runWithScene(gameScene)
        end
    end

    sendAccelerateLog(bClientAccelerate, nRatio)

    local tip
    if bClientAccelerate then
        tip = KUtil.getStringByKey("acceleratecheck.clienttip")
    else
        tip = KUtil.getStringByKey("acceleratecheck.servertip")
    end
    showConfirmation(tip, onLoginOut, onLoginOut)
    
    bShowAccelerate = true
end

local function checkClientTime(clientIntervalTime, clientTickIntervalTime, delayIntervalTime)    
    if clientIntervalTime == 0 or clientTickIntervalTime == 0 or delayIntervalTime == 0 then return end

    local maxAddRatio               = MAX_CLIENT_ADD_RATIO
    local maxClientCheckCount       = MAX_CLIENT_CHECK_COUNT

    local ratio     = delayIntervalTime / clientIntervalTime
    local tickRatio = delayIntervalTime / clientTickIntervalTime

    if ratio >= maxAddRatio or tickRatio >= maxAddRatio then
        clientCheckCount = clientCheckCount + 1
        if clientCheckCount >= maxClientCheckCount then
            showAccelerateTip(true, tickRatio)
        end
    end
end

local function getTickTime()
    return C_GetTickCount() / 1000
end

local function checkClientAccelerate(nowTime, delayTime)
    if statisticClientTickTime == 0 then
        statisticClientTickTime = getTickTime()
        statisticClientTime     = os.time()
        statisticDelayTime      = 0
        return
    end

    statisticDelayTime  = statisticDelayTime + delayTime
    local clientTotalStatisticTime = CLIENT_TOTAL_STATISTIC_TIME
    local clientTickIntervalTime = getTickTime() - statisticClientTickTime
    local clientIntervalTime = os.time() - statisticClientTime

    if clientTickIntervalTime >= clientTotalStatisticTime then
        checkClientTime(clientIntervalTime, clientTickIntervalTime, statisticDelayTime)
        statisticDelayTime      = 0
        statisticClientTime     = os.time()
        statisticClientTickTime = getTickTime()
    end
end

local function requestSyncServerTime(nowTime, delayTime)
    if bShowAccelerate or bSendRequestServerTime then return end

    if requestServerTime == 0 then
        requestServerTime = os.time()
        return
    end

    local requestInterval = os.time() - requestServerTime
    if requestInterval >= REQUEST_SERVER_TIME_INTERVAL then
        bSendRequestServerTime = true
        requestServerTime = os.time()
        require("src/network/KC2SProtocolManager"):requestServerTime()
    end
end

function KAccelerateCheck.checkServerTime(nServerTime)
    bSendRequestServerTime = false

    if serverTime == 0 then
        serverTime = nServerTime
        clientTime = os.time()
        return
    end

    local serverInterval = nServerTime - serverTime
    local clientInterval = os.time() - clientTime

    if serverInterval == 0 or clientInterval == 0 then return end

    local ratio = clientInterval / serverInterval

    serverTime = nServerTime
    clientTime = os.time()

    if ratio < MAX_SERVER_ADD_RATIO then
        serverCheckCount = 0
        return
    end
    
    serverCheckCount            = serverCheckCount + 1
    local maxServerCheckCount   = MAX_SERVER_CHECK_COUNT
    if serverCheckCount >= maxServerCheckCount then
        showAccelerateTip(false, ratio)
    end
end

function KAccelerateCheck.activate(nowTime, delayTime)
    if not KPlayer.bDataReady then return end

    checkClientAccelerate(nowTime, delayTime)
    requestSyncServerTime(nowTime, delayTime)
end

return KAccelerateCheck