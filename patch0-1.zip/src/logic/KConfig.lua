--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KConfig.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   22:46
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


KConfig = KConfig or {}

local function combineValues(v1, ...)
    if select("#", ...) == 0 then
        return v1
    end

    local tValues = {v1, ...}
    return table.concat(tValues, "-")
end

KConfig._loadTable = {
    ["cardInfo"]                = {["path"] = "cardinfo",               },
    ["levelInfo"]               = {["path"] = "levelinfo",              },
    ["itemInfo"]                = {["path"] = "iteminfo",               },
    ["string"]                  = {["path"] = "string",                 },
    ["cardbreakdowninfo"]       = {["path"] = "cardbreakdowninfo",      },
    ["equipInfo"]               = {["path"] = "equipinfo",              },
    ["equipBreakDownInfo"]      = {["path"] = "equipbreakdowninfo",     },
    ["expedition"]              = {["path"] = "expedition",             },
    ["mission"]                 = {["path"] = "mission",                },
    ["cardstrengthen"]          = {["path"] = "cardstrengthen",         },
    ["playerLevelInfo"]         = {["path"] = "playerlevelinfo",        },
    ["sound"]                   = {["path"] = "sound",                  },
    ["battle"]                  = {["path"] = "battle",                 },
    ["monster"]                 = {["path"] = "monster",                },
    ["monstergroup"]            = {["path"] = "monstergroup",           },
    ["guide"]                   = {["path"] = "guide",                  },
    ["shop"]                    = {["path"] = "shop",                   },
    ["currency"]                = {["path"] = "currency",               },
    ["lineup"]                  = {["path"] = "lineup",                 },
    ["reward"]                  = {["path"] = "reward",                 },
    ["sensitiveword"]           = {["path"] = "sensitiveword",          },
    ["messageSensitiveword"]    = {["path"] = "messageSensitiveword",   },
    ["rankinfo"]                = {["path"] = "rankinfo",               },
    ["sign"]                    = {["path"] = "sign",                   },
    ["announce"]                = {["path"] = "announce",               },
    ["furniture"]               = {["path"] = "furniture",              },
    ["furnitureType"]           = {["path"] = "furnituretype",          },
    ["raiders"]                 = {["path"] = "raiders",                },
    ["foodsys"]                 = {["path"] = "foodsys",                },
    ["food"]                    = {["path"] = "food",                   },
    ["raiderspage"]             = {["path"] = "raiderspage",            },
    ["systeminfo"]              = {["path"] = "systeminfo",             },
    ["otherSetting"]            = {["path"] = "otherSetting",           },
    ["skill"]                   = {["path"] = "skill",                  },
    ["coefficient"]             = {["path"] = "coefficient",            },
    ["scoutcoefficient"]        = {["path"] = "scoutcoefficient",       },
    
    ["medalinfo"]               = {["path"] = "medal",                  },
    ["medalRequire"]            = {["path"] = "medalRequire",           },
    ["cardrepairpowerinfo"]     = {["path"] = "cardrepairpowerinfo",    },
    ["cardrepairratioinfo"]     = {["path"] = "cardrepairratioinfo",    },
    ["skin"]                    = {["path"] = "skin",                   },
    ["spSign"]                  = {["path"] = "spSign",                 },
    ["sysopen"]                 = {["path"] = "sysopen",                },
    ["buildactivity"]           = {["path"] = "buildactivity",          },
    ["story"]                   = {["path"] = "story",                  },
    ["storyChapter"]            = {["path"] = "storyChapter",           },
    ["cardproduceinfo"]         = {["path"] = "cardproduceinfo",        },
    ["equipproduceinfo"]        = {["path"] = "equipproduceinfo",       },
    ["trainingCard"]            = {["path"] = "trainingcard",           },
    ["trainingWar"]             = {["path"] = "trainingwar",            },
    ["trainingSkill"]           = {["path"] = "trainingskill",          },
}

function KConfig:getLine(table, ...)
    local key = combineValues(...)
    if self[table] ~= nil then
        return self[table][key]
    end
    return nil
end

function KConfig:getValue(table, id1, id2)
    local line = self:getLine(table, id1)
	if line ~= nil then
        return line[id2]
	end
	return nil
end



--[[
    This file loaded by KUIConfigLoadingNode.
    Now load sync. We should change it for async.
]]
