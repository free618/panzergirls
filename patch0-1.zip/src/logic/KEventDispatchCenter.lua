--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KEventDispatchCenter.lua
--  Creator     : SunXun
--  Date        : 2015/03/31   9:40
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KEventDispatchCenter = {}

KEventDispatchCenter.EventType = {
    -- NET EVENT
    NET_LS_HANDSHAKE                    = "NET_LS_HANDSHAKE",
    NET_REGISTER_RESULT                 = "NET_REGISTER_RESULT",
    NET_LOGIN_RESULT                    = "NET_LOGIN_RESULT", 
    NET_CHANGE_PASSWORD_RESULT          = "NET_CHANGE_PASSWORD_RESULT",
    NET_SYNC_SERVER_LIST                = "NET_SYNC_SERVER_LIST",
    NET_ENTER_SERVER_RESULT             = "NET_ENTER_SERVER_RESULT",
    NET_SYNC_DATA_END                   = "NET_SYNC_DATA_END",
    NET_LS_DISCONNECT                   = "NET_LS_DISCONNECT",
    NET_SYNC_MAIL_LIST                  = "NET_SYNC_MAIL_LIST",
    NET_UPDATE_RESOURCE                 = "NET_UPDATE_RESOURCE",
    NET_UPDATE_PLAYER_PROGRESS          = "NET_UPDATE_PLAYER_PROGRESS",
    NET_NOTIFY_BEGAN_BUILD              = "NET_NOTIFY_BEGAN_BUILD",
    NET_NOTIFY_FINISH_BUILD             = "NET_NOTIFY_FINISH_BUILD",
    NET_NOTIFY_DEL_PRODUCING_CARD       = "NET_NOTIFY_DEL_PRODUCING_CARD",
    NET_NOTIFY_ADD_CARD                 = "NET_NOTIFY_ADD_CARD",
    NET_NOTIFY_GET_PRODUCED_CARD        = "NET_NOTIFY_GET_PRODUCED_CARD",
    NET_NOTIFY_DEL_CARD                 = "NET_NOTIFY_DEL_CARD",
    NET_ADD_CARD_TO_COLLECTION          = "NET_ADD_CARD_TO_COLLECTION",
    NET_ITEM_UPDATE                     = "NET_ITEM_UPDATE",
    NET_ITEM_REMOVE                     = "NET_ITEM_REMOVE",
    NET_ITEM_ADD                        = "NET_ITEM_ADD",
    NET_CARD_LOCK                       = "NET_CARD_LOCK",
    NET_CARDS_BREAK                     = "NET_CARDS_BREAK",
    NET_NOTIFY_SUPPLY_TEAM_FINISH       = "NET_NOTIFY_SUPPLY_TEAM_FINISH",
    NET_NOTIFY_SUPPLY_SKILL_FINISH      = "NET_NOTIFY_SUPPLY_SKILL_FINISH",
    NET_NOTIFY_SUPPLY_CARD_FINISH       = "NET_NOTIFY_SUPPLY_CARD_FINISH",
    NET_FINISH_REPAIR_CAR_COSTITEM      = "NET_FINISH_REPAIR_CAR_COSTITEM",
    NET_FINISH_QUICKREPAIRNG            = "NET_FINISH_QUICKREPAIRNG",
    NET_FINISH_QUICKREPAIRNG_ALLCARD    = "NET_FINISH_QUICKREPAIRNG_ALLCARD",
    NET_BEGAN_REPAIR_CARD               = "NET_BEGAN_REPAIR_CARD",
    NET_DEL_REPAIR_CARD                 = "NET_DEL_REPAIR_CARD",
    NET_FINISH_REPAIR_CARD              = "NET_FINISH_REPAIR_CARD",
    NET_DELETE_DEAD_CARD                = "NET_DELETE_DEAD_CARD",
    NET_ADD_DEAD_CARD                   = "NET_ADD_DEAD_CARD",
    NET_NOTIFY_CONVERT_CARD             = "NET_NOTIFY_CONVERT_CARD",
    NET_GET_MISSION_REWARD              = "NET_GET_MISSION_REWARD",
    NET_UPDATE_MISSION                  = "NET_UPDATE_MISSION",
    NET_NOTIFY_CHOOSE_CARD_FINISH       = "NET_NOTIFY_CHOOSE_CARD_FINISH",
    NET_NOTIFY_ONE_CARD_CHANGE          = "NET_NOTIFY_ONE_CARD_CHANGE",
    NET_NOTIFY_ADD_EXPEDITION           = "NET_NOTIFY_ADD_EXPEDITION",
    NET_NOTIFY_REMOVE_EXPEDITION        = "NET_NOTIFY_REMOVE_EXPEDITION",
    NET_NOTIFY_EXPEDITION_REWARD        = "NET_NOTIFY_EXPEDITION_REWARD",
    NET_NOTIFY_SAVE_RECORD_TEAM         = "NET_NOTIFY_SAVE_RECORD_TEAM",
    NET_NOTIFY_DEL_RECORD_TEAM          = "NET_NOTIFY_DEL_RECORD_TEAM",
    NET_STRENGTHEN                      = "NET_STRENGTHEN",
    NET_UPDATE_COIN                     = "NET_UPDATE_COIN",
    NET_BUY_GOOD_SUCCESS                = "NET_BUY_GOOD_SUCCESS",
    NET_BUILD_EQUIP                     = "NET_BUILD_EQUIP",
    NET_BREAK_DOWN_EQUIP                = "NET_BREAK_DOWN_EQUIP",
    NET_EQUIPS_BREAK                    = "NET_EQUIPS_BREAK",
    NET_UPDATE_GUIDE                    = "NET_UPDATE_GUIDE",
    NET_UPDATE_ROLE_RANK                = "NET_UPDATE_ROLE_RANK",
    NET_UPDATE_PAGE_RANK                = "NET_UPDATE_PAGE_RANK",
    NET_UPDATE_RANK_REWARD              = "NET_UPDATE_RANK_REWARD",
    NET_ADD_EQUIP_COLLECT               = "NET_ADD_EQUIP_COLLECT",
    NET_ADD_CARD_COLLECT                = "NET_ADD_CARD_COLLECT",
    NET_REMOVE_EQUIP_COLLECT            = "NET_REMOVE_EQUIP_COLLECT",
    NET_REMOVE_CARD_COLLECT             = "NET_REMOVE_EQUIP_COLLECT",
    NET_UPDATE_EQUIP_COLLECT            = "NET_UPDATE_EQUIP_COLLECT",
    NET_UPDATE_CARD_COLLECT             = "NET_UPDATE_CARD_COLLECT",
    NET_UPDATE_EQUIP_LOG                = "NET_UPDATE_EQUIP_LOG",
    NET_UPDATE_CARD_LOG                 = "NET_UPDATE_CARD_LOG",
    NET_EQUIP_LOCK                      = "NET_EQUIP_LOCK",
    NET_SIGN                            = "NET_SIGN",
    NET_ANNOUNCE                        = "NET_ANNOUNCE",
    NET_CHANGE_FURNITURE                = "NET_CHANGE_FURNITURE",
    NET_BUY_FURNITURE                   = "NET_BUY_FURNITURE",
    NET_UPDATE_FURNITURE_COIN           = "NET_UPDATE_FURNITURE_COIN",
    NET_EXCHANGE                        = "NET_EXCHANGE",
    NET_UPDATE_MAIL_DATA                = "NET_UPDATE_MAIL_DATA",
    NET_UPDATE_MAIL_REWARD              = "NET_UPDATE_MAIL_REWARD",
    NET_SEND_MAIL_RESULT                = "NET_SEND_MAIL_RESULT",
    NET_REMOVE_MAIL                     = "NET_REMOVE_MAIL",
    NET_RECEIVE_NEW_MAIL                = "NET_RECEIVE_NEW_MAIL",
    NET_MARRIAGE_RING                   = "NET_MARRIAGE_RING",
    NET_UPDATE_FEELING                  = "NET_UPDATE_FEELING",
    NET_EXERCISE_ROLE_LIST              = "NET_EXERCISE_ROLE_LIST",
    NET_EXERCISE_ROLE_DETAIL            = "NET_EXERCISE_ROLE_DETAIL",
    NET_EXERCISE_BATTLE_FINISH          = "NET_EXERCISE_BATTLE_FINISH",
    NET_CHANGE_DIFFICULTY               = "NET_CHANGE_DIFFICULTY",
    NET_DIFFICULTY_LEVEL_PASS           = "NET_DIFFICULTY_LEVEL_PASS",
    NET_PLUNDER_LIST                    = "NET_PLUNDER_LIST",
    NET_ADD_PLUNDER_TIME                = "NET_ADD_PLUNDER_TIME",
    NET_PLUNDER_DETAIL                  = "NET_PLUNDER_DETAIL",
    NET_PLUNDER_BATTLE_FINISH           = "NET_PLUNDER_BATTLE_FINISH",
    NET_ERROR_CODE                      = "NET_ERROR_CODE",
    NET_BUY_COUNT                       = "NET_BUY_COUNT",
    NET_DAY_BUY_COUNT                   = "NET_DAY_BUY_COUNT",
    NET_WEEK_BUY_COUNT                  = "NET_WEEK_BUY_COUNT",
    NET_ACTIVATE_RESULT                 = "NET_ACTIVATE_RESULT",
    NET_SKILL_CHANGE                    = "NET_SKILL_CHANGE",
    NET_LOCK_CARD_LIST                  = "NET_LOCK_CARD_LIST",
    NET_TEAM_RENAME                     = "NET_TEAM_RENAME",
    NET_COOK_RESULT                     = "NET_COOK_RESULT",
    NET_UPDATE_EXP_BUFF                 = "NET_UPDATE_EXP_BUFF",
    NET_UPDATE_FOOD_DATA                = "NET_UPDATE_FOOD_DATA",
    NET_CARD_TRAINING_FINISH            = "NET_CARD_TRAINING_FINISH",
    NET_UPDATE_SECRETARY_DATA           = "NET_UPDATE_SECRETARY_DATA",
    NET_ACCESS_MISSION                  = "NET_ACCESS_MISSION",
    NET_BIND_ACCOUNT_RESULT             = "NET_BIND_ACCOUNT_RESULT",
	
	-- MESSAGE EVENT
    NET_RECEIVE_GLOBAL_MESSAGE          = "NET_RECEIVE_GLOBAL_MESSAGE",
    NET_RECEIVE_PRIVATE_MESSAGE         = "NET_RECEIVE_PRIVATE_MESSAGE",
    NET_TARGET_NOT_EXIST                = "NET_TARGET_NOT_EXIST",
    NET_TARGET_OFF_LINE                 = "NET_TARGET_OFF_LINE",
	
    -- LOGIC EVENT
    LOGIC_STRONG_HOLD_INFO_UPDATE       = "LOGIC_STRONG_HOLD_INFO_UPDATE",
    LOAD_FILE_COMPLETE                  = "LOAD_FILE_COMPLETE",
    
    -- UI EVENT
    UI_CLOSE_MESSAGE                    = "UI_CLOSE_MESSAGE",
    UI_ACTION_FINISH                    = "UI_ACTION_FINISH",
    UI_BREAK_CHOOSE_FINISH              = "UI_BREAK_CHOOSE_FINISH",
    UI_OPEN_PANEL                       = "UI_OPEN_PANEL",
    UI_CLOSE_SETTING                    = "UI_CLOSE_SETTING",
    UI_EQUIP_CHOOSE_FINISH              = "UI_EQUIP_CHOOSE_FINISH",
    UI_STRENGTHEN_FINISH                = "UI_STRENGTHEN_FINISH",
    UI_STORY_PLAY_END                   = "UI_STORY_PLAY_END",
    
    BATTLE_FINISHED                     = "BATTLE_FINISHED",
    RESOURCE_FOOTHOLD                   = "RESOURCE_FOOTHOLD",
    ACCIDENT_FOOTHOLD                   = "ACCIDENT_FOOTHOLD",
    NONE_FOOTHOLD                       = "NONE_FOOTHOLD",  
    EXPAND_REPAIRBAR                    = "EXPAND_REPAIRBAR",
    EXPAND_BUILDBAR                     = "EXPAND_BUILDBAR",
    RENAME_FAILED                       = "RENAME_FAILED",
    RENAME_SUCCESS                      = "RENAME_SUCCESS",
    RESPOND                             = "RESPOND",
    SENDING_TIME_OUT                    = "SENDING_TIME_OUT",	
    NET_ACTION_END_TYPE                 = "NET_ACTION_END_TYPE",
    NET_OTHER_RANK_GET                  = "NET_OTHER_RANK_GET",
    NET_UPDATE_MEDAL                    = "NET_UPDATE_MEDAL",
    NET_UPDATE_MEDAL_VALUE              = "NET_UPDATE_MEDAL_VALUE",
    NET_USE_SKIN                        = "NET_USE_SKIN",
    NET_BUY_SKIN_SUCCESS                = "NET_BUY_SKIN_SUCCESS",
    NET_SPSIGN_RESULT                   = "NET_SPSIGN_RESULT",
    NET_GENERATE_NAME_RET               = "NET_GENERATE_NAME_RET",
    NET_STORY_REWARD                    = "NET_STORY_REWARD", 
}

KEventDispatchCenter.EventQuene = {}
KEventDispatchCenter._backKeyEventListener = nil

function KEventDispatchCenter:registerEvent(eventType, callback)
    print("--------------------> KEventDispatchCenter:registerEvent eventType", eventType, callback)
    if self.EventType[eventType] == nil or type(callback) ~= "function" then
        print("KEventDispatchCenter:registerEvent param is error~ eventType:", eventType)
        return
    end
    
    if self.EventQuene[eventType] == nil then
        self.EventQuene[eventType] = {}
    end
    
    local index = table.getn(self.EventQuene[eventType])
    self.EventQuene[eventType][index + 1] = callback
end

function KEventDispatchCenter:unregisterEvent(eventType, callback)
    print("--------------------> KEventDispatchCenter:unregisterEvent eventType", eventType, callback)
    if self.EventQuene[eventType] == nil or type(callback) ~= "function" then
        print("KEventDispatchCenter:unregisterEvent param is error~ eventType:", eventType)
        return
    end
    
    for k, v in pairs(self.EventQuene[eventType]) do
        if callback == v then
            table.remove(self.EventQuene[eventType], k)
            return
        end
    end
end

function KEventDispatchCenter:dispatchEvent(eventType, ...)
    print("--------------------> KEventDispatchCenter:dispatch eventType", eventType)
    if self.EventType[eventType] == nil then
        print("KEventDispatchCenter:dispatchEvent eventType is unknow : ", eventType)
        return    
    end
    
    if self.EventQuene[eventType] == nil then
        print("KEventDispatchCenter:dispatchEvent callback is nil eventType:", eventType)
        return 
    end
    
    for k, v in pairs(self.EventQuene[eventType]) do
        v(...)
    end
end

function KEventDispatchCenter:clearAllEvent()
    self.EventQuene = {}

    if self._backKeyEventListener then
        local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
        eventDispatcher:removeEventListener(self._backKeyEventListener)
    end
end

function KEventDispatchCenter:registerKeyBackEvent()
    local function onBackKeyClick(keyType, event)
        if keyType == cc.KeyCode.KEY_BACK then
            C_SDKAgent.Exit("S1")
        end
    end
    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onBackKeyClick, cc.Handler.EVENT_KEYBOARD_RELEASED)

    local eventPriority = 1
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithFixedPriority(listener, eventPriority)

    self._backKeyEventListener = listener
end

return KEventDispatchCenter
