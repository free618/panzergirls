--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIGuideDialogueNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/22   20:00
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KGuideEnv = {}
KGuideEnv.FIRST_FIGHT_END =  ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_BEGIN + 130000

KGuideEnv.NodeType = {
    ["GuideClick"]           = "src/ui/guide/KUIGuideClickNode",
    ["GuideDialogue"]        = "src/ui/guide/KUIGuideDialogueNode",
    ["GuideAnimation"]       = "src/ui/guide/KUIGuideAnimationNode",
}

function KGuideEnv.init()
    KGuideEnv._guideIndex = nil
    KGuideEnv._waitID     = nil
    KGuideEnv._eventList  = {}
end

function  KGuideEnv.removeGuideNode()
    local currentScene = cc.Director:getInstance():getRunningScene() 
    local guideNode    = currentScene:getChildByName("guideNode")
    if guideNode then
        guideNode._isValid = true
        guideNode:removeFromParent()
    end
    KGuideEnv.unregisterAllEvent()
end

function KGuideEnv.addGuideNode(guideIndex, delayTime, isLogin)
    assert(KConfig)
    local guideConfig = KConfig:getLine("guide", guideIndex)
    assert(guideConfig)
    local currentScene = cc.Director:getInstance():getRunningScene()
    assert(currentScene)
    if isLogin then
        local stringBase = [[local scene = select(2,...); setfenv(1, select(1,...)); scene:gotoUI(%s) ]]
        local funcGotoUI = assert(loadstring(string.format(stringBase, guideConfig.szStartUI)), guideConfig.szStartUI)
        funcGotoUI(KGuideEnv, currentScene)
    end
    
    if guideConfig then
        local filePath = KGuideEnv.NodeType["Guide"..guideConfig.szType]
        assert(filePath)
        assert(require(filePath), filePath)
        local guideNode  = require(filePath).create(currentScene, guideIndex, delayTime)
        assert(guideNode)
        guideNode:setName("guideNode")
        KGuideEnv._guideIndex = guideIndex
        currentScene:addChild(guideNode, 100)
    end
end

function KGuideEnv.addNextGuideNode(delayTime, isSkip)
    KGuideEnv.removeGuideNode()
    local isLogin = true
    local index
    if KGuideEnv._guideIndex then
        isLogin   = false
        index     = KGuideEnv._guideIndex
    else
        index     = 0
        if KPlayer.progressID > ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_BEGIN then
            index = KPlayer.progressID - ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_BEGIN
        end
    end
    local guideIndex, guideConfig
    for i, v in pairs(KConfig["guide"]) do
        if i > index and (not guideIndex or i < guideIndex) and ( not isSkip or (isSkip and not v.bSkip) ) then
            guideIndex  = i
            guideConfig = v
        end
    end 
    if isLogin and guideConfig then
        local funGetBegin = assert(loadstring("setfenv(1, select(1,...)); return "..guideConfig.szBegin))
        guideIndex  = funGetBegin(require("src/logic/KGuideEnv")) 
        guideConfig = KConfig:getLine("guide", guideIndex)
        delayTime   = guideConfig.nLoginDelayTime
        assert(guideConfig)
    end
    local previousGuideIndex 
    for i, v in pairs(KConfig["guide"]) do
        if (not guideIndex or i < guideIndex) and (not previousGuideIndex or i > previousGuideIndex) then
            previousGuideIndex  = i
        end
    end
    local guideName = "no name"
    if previousGuideIndex then
        local guideConfig = KConfig.guide[previousGuideIndex]
        if guideConfig then guideName = guideConfig.szName end
        require("src/network/KC2SProtocolManager"):updateGuide(previousGuideIndex, guideName, guideIndex, KGuideEnv._guideIndex)
	end
    if guideIndex then
        KGuideEnv.addGuideNode(guideIndex, nextDelayTime, isLogin)
    else
        local currentIndex = ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_END - ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_BEGIN
        guideName = "新手结束"
        require("src/network/KC2SProtocolManager"):updateGuide(currentIndex, guideName, nil)
    end
end

function KGuideEnv.addCurrentGuideNode()
    if KGuideEnv._guideIndex then
        KGuideEnv.removeGuideNode()
        KGuideEnv.addGuideNode(KGuideEnv._guideIndex, 0, false)
    else
        KGuideEnv.addNextGuideNode(0, false)
    end
end

function KGuideEnv.addNode(...)
    return cc.Director:getInstance():getRunningScene():addNode(...)
end

function KGuideEnv.removeNode(...)
    return cc.Director:getInstance():getRunningScene():removeNode(...)
end

function KGuideEnv.getNode(...)
    local node = cc.Director:getInstance():getRunningScene():getNode(...)
    assert(node)
    return node
end

function KGuideEnv.returnOffice()
    return cc.Director:getInstance():getRunningScene():returnOffice()
end

function KGuideEnv.getCardID(index)
    return KUtil.getCardList()[index].nID
end

function KGuideEnv.isBuild(index)
    local producingCard = KUtil.getProducingCardByIndex(index)
    return producingCard and producingCard.nEndTime > os.time()
end

function KGuideEnv.isRepair(catdID)
    return KUtil.getRepairingCardByCradID(catdID) ~= nil
end

function KGuideEnv.isCardFullHp(index)
    local card        = KUtil.getCardList()[index]
    local cardConfig  = KConfig.cardInfo[card.nTemplateID]
    local maxHP       = KUtil.getCardMaxHp(card)
    return card.nCurrentHP == maxHP
end

function KGuideEnv.prepareFight(zoneID, mapID, roundList, isUseSkill)
    local function waitUseSkill(waitID)
        KGuideEnv._waitID = waitID
        KGuideEnv.addNextGuideNode()
    end

    local battleInfo = 
    {
        zoneID     = zoneID,
        mapID      = mapID,
        teamIndex  = 1,
        roundList  = roundList,
        guideUseSkill = waitUseSkill,
        battleType = BATTLE_TYPE.GUIDE,
        isUseSkill = isUseSkill
    }

    -- KGuideEnv.addNode("BattlePrepare", battleInfo)
    local battleScene = require("src/ui/battle/KUIBattleScene").create(battleInfo, "Guide")
    KUtil.replaceSceneAndRemoveAllTexture(battleScene)
end

function KGuideEnv.beginFight(zoneID, mapID, footholdID, roundList, isUseSkill)
    local teamIndex = 1
    local leftTeam       = KUtil.createLeftTeamInfo(teamIndex)
    if footholdID ~= 3 then
        for _, card in ipairs(leftTeam) do
            card.nCurrentHP = card.nMaxHP
        end
    end
    leftTeam.lineup      = KConfig:getLine("lineup", 1)
    local rightTeam      = KUtil.createRightTeamInfo(zoneID, mapID, footholdID)
    local backgroundType = KUtil.getBattleBackgroundType(zoneID, mapID, footholdID)
    leftTeam.background  = backgroundType
    
    local function endFight(tBattleResult)
        KUtil.showBattleResult(zoneID, mapID, footholdID, tBattleResult, leftTeam)
    end

    local mapMusic, fightMusic, nightMusic = KUtil.getBattleMusicSetting(zoneID, mapID, footholdID)
    KSound.resetLastMusic()
    
    KUtil.removeUnusedTextures()
    local battleInfo = 
    {
        leftTeam        = leftTeam,
        rightTeam       = rightTeam,
        endCallback     = endFight,
        mapID           = mapID,
        roundList       = roundList,
        battleType      = BATTLE_TYPE.GUIDE,
        fightMusic      = fightMusic,
        nightFightMusic = nightMusic,
    }

    if isUseSkill then
        local function waitUseSkill(waitID)
            KGuideEnv._waitID = waitID
            KGuideEnv.addNextGuideNode()
        end
        battleInfo.guideUseSkill = waitUseSkill
    end
    local battleNode = KGuideEnv.addNode("Battle", battleInfo)
    battleNode:setBattleBackground(backgroundType, false)
end
--beginFight(1, {1, 4, 10, 27, 35, 40}, {artilleryAction = { {attacker = 1, beAttacker = 3, isLeft = 1, hurt = 15},{attacker = 1, beAttacker = 1, hurt = 0},{attacker = 2, beAttacker = 1, hurt = 1},{attacker = 3, beAttacker = 1, hurt = 1},{attacker = 4, beAttacker = 1, hurt = 2},{attacker = 5, beAttacker = 1, hurt = 2},{attacker = 6, beAttacker = 1, hurt = 5}}})
--beginFight(2, {7, 11, 15}, {artilleryAction = { {attacker = 1, beAttacker = 2, hurt = 16, isLeft = 1},{attacker = 2, beAttacker = 1, hurt = 10, isLeft = 1},{attacker = 1, beAttacker = 2, hurt = 2},{attacker = 3, beAttacker = 1, hurt = 4}},artilleryAction2 = {{attacker = 1, beAttacker = 1, hurt = 12, isLeft = 1},{attacker = 2, beAttacker = 3, hurt = 15, isLeft = 1},{attacker = 1, beAttacker = 1, hurt = 1},{attacker = 3, beAttacker = 2, hurt = 2}}, dogFight = {{attacker = 1, beAttacker = 1, hurt = 12, isLeft = 10},{attacker = 2, beAttacker = 3, hurt = 15, isLeft = 7}}})

function KGuideEnv.useSkill()
    local nodeBattle     = KGuideEnv.getNode("Battle")
    assert(nodeBattle)
    local tBattleManager = nodeBattle._tBattleManager
    assert(tBattleManager)
    tBattleManager:castSkill(true, 1, nil, 1)
    tBattleManager:delWaiting(KGuideEnv._waitID)
    print("KGuideEnv._waitID",KGuideEnv._waitID)
end

function KGuideEnv.registerEvent(eventType, callbackFunc)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    table.insert(KGuideEnv._eventList, 
        {
            ["eventType"]       = eventType, 
            ["callbackFunc"]    = callbackFunc
        }
    )
    eventDispatchCenter:registerEvent(eventDispatchCenter.EventType[eventType], callbackFunc)
end

function KGuideEnv.unregisterAllEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    for _, v in pairs(KGuideEnv._eventList) do
        eventDispatchCenter:unregisterEvent(v["eventType"], v["callbackFunc"])
    end
    KGuideEnv._eventList = {}
end

function KGuideEnv.MoveBy(time, x, y)
    return cc.MoveBy:create(time, cc.p(x, y));
end

function KGuideEnv.MoveTo(time, x, y)
    return cc.MoveTo:create(time, cc.p(x, y));
end

function KGuideEnv.ScaleBy(...)
    return cc.ScaleBy:create(...);
end

function KGuideEnv.ScaleTo(...)
    return cc.ScaleTo:create(...);
end

function KGuideEnv.SkewTo(...)
    return cc.SkewTo:create(...);
end

function KGuideEnv.DelayTime(...)
    return cc.DelayTime:create(...);
end

function KGuideEnv.CallFunc(...)
    return cc.CallFunc:create(...)
end

function KGuideEnv.Sequence(...)
    return cc.Sequence:create(...)
end

function KGuideEnv.Spawn(...)
    return cc.Spawn:create(...)
end

function KGuideEnv.playMusic(szMusic)
    return KSound.playMusic(szMusic)
end

KGuideEnv.server = require("src/network/KC2SProtocolManager")

KGuideEnv.init()
return KGuideEnv
