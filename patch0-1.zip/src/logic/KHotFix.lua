
local KHotFix            = {}
KHotFix.nURLIndex        = 1
KHotFix.nCurrentUrlErrorCount = 0
KHotFix.tUrlList         = nil
KHotFix.nNowVersion      = nil
local szWritablePath     = cc.FileUtils:getInstance():getWritablePath()
KHotFix.szStoragePath    = szWritablePath .. "load/hotfix/"
KHotFix.szUncompressPath = szWritablePath .. "s1_update/"

local function myPrint( ... )
    local str = "" .. C_GetTickCount() .. "  "
    for _, v in ipairs({...}) do
        str = str .. "  " .. tostring(v)
    end
    cclog(str)
end

local function setInt(key, value)
    cc.UserDefault:getInstance():setIntegerForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

local function getInt(key, default)
    return cc.UserDefault:getInstance():getIntegerForKey(key, default or 0)
end

local function getSettingString(key, default)
    return cc.UserDefault:getInstance():getStringForKey(key, default)
end

function KHotFix.init(tUrlList)
    myPrint("KHotFix.init--------------")
    KHotFix.tUrlList              = tUrlList
    KHotFix.nURLIndex             = 1
    KHotFix.nCurrentUrlErrorCount = 0
end

function KHotFix.loadVersion()
    local function onLoad(strRemoteUrl, result, fileSize, loadSize, szError)
        KHotFix.onLoad("version", strRemoteUrl, result, fileSize, loadSize, szError)
    end
    os.remove(KHotFix.szStoragePath .. "version.txt")
    C_AsyncDownloadFile(KHotFix.tUrlList[KHotFix.nURLIndex] .. 'hotfix/version.txt', KHotFix.szStoragePath .. "version.txt", 10, false, onLoad, KHotFix.onLoadProgress)
    myPrint("C_AsyncDownloadFile--------------", KHotFix.tUrlList[KHotFix.nURLIndex] .. 'hotfix/version.txt', KHotFix.szStoragePath .. "version.txt")
end

function KHotFix.disposeVersion()
    local szText      = cc.FileUtils:getInstance():getStringFromFile(KHotFix.szStoragePath .. "version.txt")
    
    assert(szText)
    local fun         = loadstring(szText)
    assert(fun)
    local nVersion, szSrcVersion = fun()
    myPrint("KHotFix.disposeVersion--------------", szSrcVersion, getSettingString("srcversion", VERSION))
    if szSrcVersion ~= getSettingString("srcversion", VERSION) then
        return
    end
    assert(nVersion)
    local nNowVersion = getInt("hotFixversion")
    if nVersion > nNowVersion then
        KHotFix.nNowVersion = nVersion
        C_RemoveFile(KHotFix.szUncompressPath .. "hotfix/")
        KHotFix.loadZip(true)
    elseif nVersion == nNowVersion then
        KHotFix.run()
    end
end

function KHotFix.loadZip(bReload)
    local function onLoad(strRemoteUrl, result, fileSize, loadSize, szError)
        KHotFix.onLoad("zip", strRemoteUrl, result, fileSize, loadSize, szError)
    end
    C_AsyncDownloadFile(KHotFix.tUrlList[KHotFix.nURLIndex] .. 'hotfix/hotfix.zip', KHotFix.szStoragePath .. "hotfix.zip", 10, not bReload, onLoad, KHotFix.onLoadProgress)
    myPrint("C_AsyncDownloadFile--------------", KHotFix.tUrlList[KHotFix.nURLIndex] .. 'hotfix/hotfix.zip', KHotFix.szStoragePath .. "hotfix.zip")
end

function KHotFix.disposeZip()
    C_AsyncUncompress(KHotFix.szStoragePath .. "hotfix.zip", KHotFix.szUncompressPath, true, KHotFix.onUncompress, KHotFix.onUncompressProgress)
end

function KHotFix.run()
    myPrint("KHotFix.run ----------------------------")
    package.path = KHotFix.szUncompressPath .. "hotfix/?.lua;" .. package.path
    require("load")
end

function KHotFix.onLoadProgress(strRemoteUrl, fileSize, loadSize)
end

function KHotFix.changeUrl()
    KHotFix.nURLIndex = KHotFix.nURLIndex + 1
    if KHotFix.nURLIndex > #KHotFix.tUrlList then
        KHotFix.nURLIndex = 1
    end
    KHotFix.nCurrentUrlErrorCount = 0
end

function KHotFix.onLoad(szFileType, strRemoteUrl, result, fileSize, loadSize, szError)
    myPrint("KHotFix.onLoad--------------", szFileType, strRemoteUrl, result, fileSize, loadSize, szError)
    if not result then
        local szShortError = string.match(szError, ":([%w%s]-)$")
        if szShortError == "Timeout was reached" then
            if KHotFix.nCurrentUrlErrorCount >= 3 then
                KHotFix.changeUrl(tFileInfo)
            else
                KHotFix.nCurrentUrlErrorCount = KHotFix.nCurrentUrlErrorCount + 1
            end
        elseif szShortError == "HTTP response code said error" then -- not found file
            return
        elseif szShortError ~= "Out of memory" then
            KHotFix.changeUrl(tFileInfo)
        end

        if szFileType == "version" then
            return KHotFix.loadVersion()
        elseif szFileType == "zip" then
            return KHotFix.loadZip(true)
        end
        assert(false)
    end
    if szFileType == "version" then
        KHotFix.disposeVersion()
    elseif szFileType == "zip" then
        KHotFix.disposeZip()
    end
end

function KHotFix.onUncompressProgress(storagePath, nFileCount, nUncompressCount)
end

function KHotFix.onUncompress(storagePath, result, szError)
    myPrint("KHotFix.onUncompress--------------", storagePath, result, szError)
    if not result then return end
    KHotFix.run()
    assert(KHotFix.nNowVersion)
    setInt("hotFixversion", KHotFix.nNowVersion)
    C_RemoveFile(KHotFix.szStoragePath)
end

return KHotFix
