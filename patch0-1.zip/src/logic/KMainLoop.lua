--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KMainLoop.lua
--  Creator     : SunXun
--  Date        : 2015/04/01   17:04
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************

local DEBUG_LUA_PATH = cc.FileUtils:getInstance():getWritablePath() .. "s1_update/"
local DEBUG_LUA_NAME = "debug"
local KMainLoop     = {}
KMainLoop._loadTime = 0


local function initGlobalObject(self)
    require "src/lib/lib"
    require "src/sharedefine/game_define"
    require "src/sharedefine/error_code"
    require "src/logic/KPlayer"
    require "src/logic/KConfig"
    require "src/logic/KSound"
    require "src/network/KGameServer"
    require "src/base/KUtil"
    require "src/logic/KOpenTime"
    require "src/logic/KShop"
        
    SHLib:Init()
    KPlayer:init()
end

function KMainLoop:addActivateObject(object)
    if not self._activateObject then self._activateObject = {} end
    
    for k, v in ipairs(self._activateObject) do
        if v == object then
            cclog("--------------------> addActivateObject Failed Because Object Is Existed~")
            return false
        end
    end
    
    table.insert(self._activateObject, object)
    return true
end

function KMainLoop:removeActivateObject(object)
    for k, v in ipairs(self._activateObject) do
        if v == object then
            table.remove(self._activateObject, k)
            --cclog("--------------------> removeActivateObject successed~")
            return true
        end
    end

    assert(false, "Can't find object type!")
end

local function loadDebugLua(nowTime)
    if KMainLoop._loadTime + 10 <= nowTime then
        KMainLoop._loadTime = nowTime
        local filePath = DEBUG_LUA_PATH .. DEBUG_LUA_NAME ..".lua"
        print(filePath, cc.FileUtils:getInstance():isFileExist(filePath))
        if cc.FileUtils:getInstance():isFileExist(filePath) then
            reload(DEBUG_LUA_NAME)
            os.remove(filePath)
            -- C_RemoveFile(filePath)
        end
    end
end

local function checkAccelerate(nowTime, delayTime)
    require("src/logic/KAccelerateCheck").activate(nowTime, delayTime)
end

function KMainLoop:activateObject(nowTime)
    pcall(loadDebugLua, nowTime)

    if not self._activateObject then return end
    for k, v in ipairs(self._activateObject) do
    	v:activate(nowTime)
    end

    SafeCall(require("src/network/KNetLog").activate, nowTime)
end

function KMainLoop:start()
    if self._activateEntryID then
        return 
    end
    --init global script
    initGlobalObject(self)
    
    local function frameActivate(delayTime)
        local nowTime = os.time()
        KGameServer:Activate(nowTime)
        SHLib:Activate(nowTime)

        -- activate per frame
        self:activateObject(nowTime)
        
        SafeCall(checkAccelerate, nowTime, delayTime)
    end
    
    --start schedule
    local mainSchedule      = cc.Director:getInstance():getScheduler()
    self._activateEntryID   = mainSchedule:scheduleScriptFunc(frameActivate, 0, false)
end

function KMainLoop:stop()
    if not self._activateEntryID then
        return 
    end
    
    local mainSchedule = cc.Director:getInstance():getScheduler()
    mainSchedule:unscheduleScriptEntry(self._activateEntryID)
    self._activateEntryID = nil
end

return KMainLoop
