--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KPLayer.lua
--  Creator     : SunXun
--  Date        : 2015/07/10   10:39
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


KPlayer = KPlayer or {}

function KPlayer:init()
    self.bDataReady              = false
    self.tRankData               = {}
    self.tMailData               = {}
    self.tMailData.tMailList     = {}

    self.tMessageData = {}    
    for _, v in pairs(CHAT_CHANEL_TYPE) do
        self.tMessageData[v] = {}
    end

    self.tLastSendChatMessageTime = {}
    for _, v in pairs(CHAT_TYPE) do
        self.tLastSendChatMessageTime[v] = 0
    end
    self.bHasNewPrivateMessage = false
    self.tLogData              = {}
    self.tExerciseData         = {}
    self.tPlunderData          = {}
    self.nSyncCount            = 0
    self.chargeCoin            = 0
end

function KPlayer:unInit()
end

function KPlayer:getRespondID()
    return KGameServer:GetRespondID()
end

function KPlayer:SyncBaseData(tBaseData)
    self.nSyncCount          = 1
    self.nErrorCount         = 0

    self.id                  = tBaseData.nID
    self.level               = tBaseData.nLevel
    self.exp                 = tBaseData.nExp
    self.name                = tBaseData.szName
    self.createTime          = tBaseData.nCreateTime
    self.lastLoginTime       = tBaseData.nLastLoginTime
    self.lastLogoutTime      = tBaseData.nLastLogoutTime
    self.oil                 = tBaseData.nOil
    self.ammo                = tBaseData.nAmmo
    self.steel               = tBaseData.nSteel
    self.people              = tBaseData.nPeople
    self.autoAddOil          = tBaseData.nAutoAddOil
    self.autoAddAmmo         = tBaseData.nAutoAddAmmo
    self.autoAddSteel        = tBaseData.nAutoAddSteel
    self.autoAddPeople       = tBaseData.nAutoAddPeople
    self.coin                = tBaseData.nCoin
    self.furnitureCoin       = tBaseData.nFurnitureCoin
    self.currentServerTime   = tBaseData.nCurrentServerTime
    self.chargeCoin          = tBaseData.nChargeCoin
    self.banChat             = tBaseData.nBanChat
    self.progressID          = tBaseData.nProgressID
    self.syncClientTime      = os.time()
    self.lastAddResourceTime = tBaseData.nLastAddResourceTime
    GlobalStatus.nDeltaTime  = self.currentServerTime - self.syncClientTime

    KUtil.addRegisterRecord("syncDataBegin")

    -- apply pay info
    require("src/logic/KSDKAgent"):applyPayInfo()
    --cclog("-----***** > KPlayer -----> applyPayInfo")
    -- wait for call back to fill it.
    self.tPayInfo = {}
end

function KPlayer:SyncItemData(szItemData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tItemData = require("src/logic/KRoleDataDispose").StringToTable(szItemData, "ItemData")
end

function KPlayer:SyncCardData(szCardData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tCardData = require("src/logic/KRoleDataDispose").StringToTable(szCardData, "CardData")
end

function KPlayer:SyncTeamData(tTeamData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tTeamData = tTeamData
end

function KPlayer:SyncExpeditionData(tExpeditionData)
    self.nSyncCount      = self.nSyncCount + 1
    self.tExpeditionData = tExpeditionData
end

function KPlayer:SyncMissionData(szMissionData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tMissionData   = require("src/logic/KRoleDataDispose").StringToTable(szMissionData, "MissionData")
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MISSION)
end

function KPlayer:SyncMedalData(tMedalData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tMedalData          = tMedalData
end

function KPlayer:UpdateOneMedal(nMedalID, tMedal)
    if not self.tMedalData then return end
    local tMedalList = self.tMedalData.tMedalList
    HArray.RemoveFirstByID(tMedalList, nMedalID)
    table.insert(tMedalList, tMedal)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MEDAL, nMedalID)
end

function KPlayer:UpdateMedalValue(nValue)
    if not self.tMedalData then return end
    self.tMedalData.nValue = nValue
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MEDAL_VALUE, nValue)
end

function KPlayer:RequestCardRankData(tRankData)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_OTHER_RANK_GET, tRankData)
end

function KPlayer:SyncBattleData(tBattleData)
    self.nSyncCount  = self.nSyncCount + 1
    self.tBattleData = tBattleData
end

function KPlayer:SyncBattleSpecialData(tBattleSpecialData)
    self.nSyncCount  = self.nSyncCount + 1
    self.tBattleSpecialData = tBattleSpecialData
end

function KPlayer:SyncRepairBarData(nRepairBarNum)
    self.nSyncCount          = self.nSyncCount + 1
    self.nRepairBarNum = nRepairBarNum
end

function KPlayer:SyncBuildBarData(nBuildBarNum)
    self.nSyncCount          = self.nSyncCount + 1
    self.nBuildBarNum = nBuildBarNum
end

function KPlayer:SyncRecordData(tRecordData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tRecordData = tRecordData
end

function KPlayer:SyncLastUpdateTime(nLastUpdateTime)
    self.nSyncCount          = self.nSyncCount + 1
    self.nLastUpdateTime = nLastUpdateTime
end

function KPlayer:SyncSignData(tSignData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tSignData = tSignData
end

function KPlayer:SyncFurnitureData(szFurnitureData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tFurnitureData = require("src/logic/KRoleDataDispose").StringToTable(szFurnitureData, "FurnitureData")
end

function KPlayer:SyncShopData(szShopData)
    self.nSyncCount          = self.nSyncCount + 1
    self.tShopData = require("src/logic/KRoleDataDispose").StringToTable(szShopData, "ShopData")
end

function KPlayer:SyncFoodHouseData(tFoodHouseData)
    self.nSyncCount = self.nSyncCount + 1
    self.tFoodHouseData  = tFoodHouseData
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_FOOD_DATA)
end

function KPlayer:SyncExpBuffData(tExpBuffData)
    self.nSyncCount   = self.nSyncCount + 1
    self.tExpBuffData = tExpBuffData
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_EXP_BUFF)
end

function KPlayer:SyncSecretaryData(tSecretaryData)
    self.nSyncCount     = self.nSyncCount + 1
    self.tSecretaryData = tSecretaryData
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_SECRETARY_DATA)
end

function KPlayer:SyncSkinData(tSkinData)
    self.nSyncCount = self.nSyncCount + 1
    self.tSkinData  = tSkinData
end

function KPlayer:SyncSkillData(tSkillData)
    self.nSyncCount = self.nSyncCount + 1
    self.tSkillList = tSkillData
end

function KPlayer:SyncSPSignData(tSPSignData)
    self.nSyncCount   = self.nSyncCount + 1
    self.tSPSignData  = tSPSignData
end

function KPlayer:SyncStoryData(tStoryData)
    self.nSyncCount   = self.nSyncCount + 1
    self.tStoryData  = tStoryData
end

function KPlayer:SyncTrainData(tTrainingList)
    self.nSyncCount    = self.nSyncCount + 1
    self.tTrainingList = tTrainingList
end

function KPlayer:RespondRoleRankData(tRoleRankData, nNextUpdateTime, nNextMonthEndTime, nCount)
    self.tRankData.nNextUpdateTime   = nNextUpdateTime
    self.tRankData.nNextMonthEndTime = nNextMonthEndTime
    self.tRankData.nCount            = nCount
    self.tRankData.tRoleRank         = tRoleRankData

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_ROLE_RANK, tRoleRankData, nNextUpdateTime, nNextMonthEndTime, nCount) 
end

function KPlayer:RespondRankPageData(nRoleID, nPageIndex, nPageSize, nCount, tRankList)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    if not self.tRankData.tRankList then
        self.tRankData.tRankList = {}
    end
    self.tRankData.nCount = nCount
    for _, rankItem in ipairs(tRankList) do
        self.tRankData.tRankList[rankItem.nRank] = rankItem
        if self.tRankData.tRoleRank and self.tRankData.tRoleRank.roleid == rankItem.roleid then
            self.tRankData.tRoleRank = rankItem
            local nNextUpdateTime = self.tRankData.tRoleRank.nNextUpdateTime
            eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_ROLE_RANK, rankItem, nNextUpdateTime, nCount) 
        end
    end

    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_PAGE_RANK, nPageIndex, nPageSize, nCount, tRankList) 
end

function KPlayer:RespondGetRankReward(nRoleID, nRewardID, tResultList)
    if self.tRankData.tRoleRank then
        self.tRankData.tRoleRank.rewardid = 0
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_RANK_REWARD, nRoleID, nRewardID, tResultList) 
end

function KPlayer:RespondUpdateRankMessage(nRoleID, szMessage)
    if not self.tRankData.tRoleRank then return end
    if nRoleID == self.tRankData.tRoleRank.roleid then
        self.tRankData.tRoleRank.message = szMessage 
        showNotice(KUtil.getStringByKey("record.setSignatureSuccess"), "success")
    end
    if not self.tRankData.tRankList then return end
    for _, rankItem in pairs(self.tRankData.tRankList) do
        if nRoleID == rankItem.roleid then
            rankItem.message = szMessage
            break
        end
    end   
end

function KPlayer:AddCardCollectLog(tOne)
    if self.tLogData.tCardLogCollect then 
        local tOne = KUtil.getFormatCollectData(tOne)
        table.insert(self.tLogData.tCardLogCollect, 1, tOne)
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ADD_CARD_COLLECT, tOne) 
end

function KPlayer:RemoveCardCollectLog(nID)
    if self.tLogData.tCardLogCollect then 
        local RemoveOne = HArray.RemoveFirstByID(self.tLogData.tCardLogCollect, nID)
        if RemoveOne then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.NET_REMOVE_CARD_COLLECT, nID) 
        end
    end
end

function KPlayer:GetCardCollectLogList(tList)
    self.tLogData.tCardLogCollect = {}
    for _, tOne in ipairs(tList) do
        local tTempOne = KUtil.getFormatCollectData(tOne)
        table.insert(self.tLogData.tCardLogCollect, tTempOne)
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_CARD_COLLECT, tList) 
end

function KPlayer:RespondCardLogPageData(nID, nTabType, nNextUpdateTime, tLogList)
    self.tLogData.tCardLogData = self.tLogData.tCardLogData or {}
    self.tLogData.tCardLogData[nTabType] = self.tLogData.tCardLogData[nTabType] or {}
    if nID == 0 then 
        self.tLogData.tCardLogData[nTabType] = tLogList
    else
        local list = self.tLogData.tCardLogData[nTabType]
        if #list > 0 and list[#list].id == nID then
            for _, tLog in ipairs(tLogList) do
                table.insert(list, tLog)
            end
        end
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_CARD_LOG, nID, nTabType, nNextUpdateTime, tLogList) 
end

function KPlayer:AddEquipCollectLog(tOne)
    if self.tLogData.tEquipLogCollect then 
        local tOne = KUtil.getFormatCollectData(tOne)
        table.insert(self.tLogData.tEquipLogCollect, 1, tOne)
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ADD_EQUIP_COLLECT, tOne) 
end

function KPlayer:RemoveEquipCollectLog(nID)
    if self.tLogData.tEquipLogCollect then 
        local RemoveOne = HArray.RemoveFirstByID(self.tLogData.tEquipLogCollect, nID)
        if RemoveOne then
            local eventDispatch = require("src/logic/KEventDispatchCenter")
            eventDispatch:dispatchEvent(eventDispatch.EventType.NET_REMOVE_EQUIP_COLLECT, nID) 
        end
    end
end

function KPlayer:GetEquipCollectLogList(tList)
    self.tLogData.tEquipLogCollect = {}
    for _, tOne in ipairs(tList) do
        local tTempOne = KUtil.getFormatCollectData(tOne)
        table.insert(self.tLogData.tEquipLogCollect, tTempOne)
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_EQUIP_COLLECT, tList) 
end

function KPlayer:RespondEquipLogPageData(nID, nTabType, nNextUpdateTime, tLogList)
    self.tLogData.tEquipLogData = self.tLogData.tEquipLogData or {}
    self.tLogData.tEquipLogData[nTabType] = self.tLogData.tEquipLogData[nTabType] or {}
    if nID == 0 then 
        self.tLogData.tEquipLogData[nTabType] = tLogList
    else
        local list = self.tLogData.tEquipLogData[nTabType]
        if #list > 0 and list[#list].id == nID then
            for _, tLog in ipairs(tLogList) do
                table.insert(list, tLog)
            end
        end
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_EQUIP_LOG, nID, nTabType, nNextUpdateTime, tLogList) 
end

function KPlayer:SyncDataEnd(nProgressID, bGM)
    self.nSyncCount          = self.nSyncCount + 1
    self.progressID = nProgressID
    self.bDataReady = true
    self.bGM        = bGM

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SYNC_DATA_END)
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_PLAYER_PROGRESS)   

    KUtil.addRegisterRecord("syncDataEnd")
    local accelerateCheck = require("src/logic/KAccelerateCheck")
    accelerateCheck.cleanData()

    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.ROLE_ID, self.id)
    kSetting.setString(kSetting.Key.TOKEN, C_MD5("hdfhifhekt43ennvm39" .. self.id))
    kSetting.setString(kSetting.Key.ROLE_NAME, self.name)
    kSetting.setString(kSetting.Key.ROLE_LEVEL, self.level)
    kSetting.setString(kSetting.Key.COIN_COUNT, self.coin)
end

function KPlayer:UpdatePlayerProgress(nProgressID)
    self.progressID = nProgressID

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_PLAYER_PROGRESS)
end

function KPlayer:RenameRet(nRetCode, szName)
    if nRetCode ~= RENAME_RET.SUCCESS then
        local eventDispatch = require("src/logic/KEventDispatchCenter")
        eventDispatch:dispatchEvent(eventDispatch.EventType.RENAME_FAILED, nRetCode)
        return 
    end
    self.name = szName
    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.ROLE_NAME, self.name)
end

-- only use item change name
function KPlayer:RenameByItemRet(nRetCode, szName)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    if nRetCode ~= RENAME_RET.SUCCESS then
        if nRetCode == RENAME_RET.USED then
            showNoticeByID("common.renamefailed.isUsed")
        elseif nRetCode == RENAME_RET.ILLEGA_NAME then
            showNoticeByID("common.renamefailed.use_illega_name")
        end
        
        return
    end
    self.name = szName
    
    eventDispatch:dispatchEvent(eventDispatch.EventType.RENAME_SUCCESS, nRetCode)
    showNoticeByID("common.rename.success")

    if not self.tRankData.tRoleRank then return end
    self.tRankData.tRoleRank.name = szName 
    
    if not self.tRankData.tRankList then return end
    for _, rankItem in pairs(self.tRankData.tRankList) do
        if self.id == rankItem.roleid then
            rankItem.name = szName
            break
        end
    end
end

function KPlayer:GenerateNameRet(szName)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_GENERATE_NAME_RET, szName)
end

function KPlayer:BanChatRet(nbanChat)
    self.banChat = nbanChat
end

function KPlayer:UpdateBattleRecordData(tLaunchData)
    self.tRecordData.tLaunchData = tLaunchData
end

function KPlayer:UpdateExerciseRecordData(tExerciseData)
    self.tRecordData.tExerciseData = tExerciseData
end

function KPlayer:getID()
    return self.id
end

function KPlayer:getName()
    return self.name    
end

function KPlayer:SyncCoin(nCoin)
    self.coin = nCoin
    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.COIN_COUNT, self.coin)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_COIN)
end

function KPlayer:AddCoin(nCoin, nCurrentCoin)
    self.coin = nCurrentCoin
    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.COIN_COUNT, self.coin)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_COIN)
end

function KPlayer:SyncLevel(nLevel, nCurrentExp)
    self.level = nLevel
    self.exp   = nCurrentExp
    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.ROLE_LEVEL, self.level)
end

function KPlayer:CostCoin(nCoin, nCurrentCoin)
    self.coin = nCurrentCoin
    local kSetting = require("src/logic/KSetting")
    kSetting.setString(kSetting.Key.COIN_COUNT, self.coin)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_COIN)
end

function KPlayer:SyncResource(nOil, nAmmo, nSteel, nPeople, nLastAddResourceTime)
    self.oil                 = nOil
    self.ammo                = nAmmo
    self.steel               = nSteel
    self.people              = nPeople
    self.lastAddResourceTime = nLastAddResourceTime
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_RESOURCE)
end

function KPlayer:AddResource(nOil, nAmmo, nSteel, nPeople)
    self.oil = self.oil + nOil
    self.ammo = self.ammo + nAmmo
    self.steel = self.steel + nSteel
    self.people = self.people + nPeople
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_RESOURCE)
end

function KPlayer:CostResource(nOil, nAmmo, nSteel, nPeople)
    self.oil = self.oil - nOil
    self.ammo = self.ammo - nAmmo
    self.steel = self.steel - nSteel
    self.people = self.people - nPeople
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_RESOURCE)
end

-- card 
function KPlayer:ChooseInitCard(nProgressID, nID)
    self:UpdatePlayerProgress(nProgressID)
end

function KPlayer:AddProducingCard(tOne)
    table.insert(self.tCardData.tProducingList, tOne)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_BEGAN_BUILD, tOne.nIndex)
end

function KPlayer:ProduceCardRespond(nCardID)

end

function KPlayer:CardProduceFinish(nIndex)
    local tOne = HArray.FindFirst(self.tCardData.tProducingList, "nIndex", nIndex)
    assert(tOne)
    tOne.nEndTime = 0
    
    KSound.playTalk(KSound.TALK.BUILDCOMPLETE, tOne.nTemplateID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_FINISH_BUILD, nIndex)
end

function KPlayer:DelProducingCard(nIndex)  
    local tOne = HArray.RemoveFirst(self.tCardData.tProducingList, "nIndex", nIndex)
    if not tOne then
    	return
    end
    
    local cardID = tOne.nTemplateID
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_DEL_PRODUCING_CARD, nIndex, cardID)
end

function KPlayer:GetProducedCard(cardID, isNewCard)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_GET_PRODUCED_CARD, cardID, isNewCard)
end

function KPlayer:AddCardToCollection(nTemplateID)
    local tCardCollection = self.tCardData.tHistoricalCardID
    HArray.UniqueInsertByValue(tCardCollection, nTemplateID)
end

function KPlayer:AddHistoricalMairriedCard(nTemplateID)
    local tHistoricalList = self.tCardData.tHistoricalMarriedList
    HArray.UniqueInsertByValue(tHistoricalList, nTemplateID)
end

function KPlayer:AddCardToStoreHouse(tOne, isNewCard)
    HArray.UniqueInsert(self.tCardData.tStoreHouse.tCardList, tOne, "nID")

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_ADD_CARD, tOne.nID, isNewCard)
end

function KPlayer:DelCardFromStoreHouse(nID)
    HArray.RemoveFirstByID(self.tCardData.tStoreHouse.tCardList, nID)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_DEL_CARD, nID)
end

function KPlayer:UpdateCard(tCardData)
    local tOne = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, tCardData.nID)
    for k, v in pairs(tCardData) do
        tOne[k] = v
    end
end

function KPlayer:AddDeadCard(tOne)
    table.insert(self.tCardData.tDeadList, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ADD_DEAD_CARD, tOne.nID)    
end

function KPlayer:DelDeadCard(nID)
    HArray.RemoveFirstByID(self.tCardData.tDeadList, nID)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_DELETE_DEAD_CARD, nID)    
end

function KPlayer:SyncCardLock(nID, bLock)
    local tOneCard = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, nID)
    tOneCard.bLock = bLock
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CARD_LOCK, tOneCard)
end

--function KPlayer:BreakDownCard(nID, nOil, nAmmo, nSteel, nPeople)
--    local eventDispatch = require("src/logic/KEventDispatchCenter")
--    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CARD_BREAK, nID)
--end

function KPlayer:BreakDownCardList(cardIDList, nOil, nAmmo, nSteel, nPeople)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CARDS_BREAK, cardIDList)
end

function KPlayer:DelRepairingCard(tOneCard)
    HArray.RemoveFirst(self.tCardData.tRepairingList, "nCardID", tOneCard.nCardID)

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_DEL_REPAIR_CARD, tOneCard.nRepairPosition)
end

function KPlayer:AddRepairingCard(tOne)
    cclog("----------------------------------->insert success")

    table.insert(self.tCardData.tRepairingList, tOne)
    KUtil.playRepairTalk(tOne.nCardID)

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_BEGAN_REPAIR_CARD, tOne.nCardID)
end

function KPlayer:FinishRepairCard(nCardID, nCurrentHP)
    local tOne = HArray.FindFirst(self.tCardData.tStoreHouse.tCardList, "nID", nCardID)
    tOne.nCurrentHP = nCurrentHP    
    KSound.playTalk(KSound.TALK.REPAIRCOMPLETE, tOne.nTemplateID)

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CARD, tOne.nCardID)
end

function KPlayer:FinishRepairngCardByCostItem(tOneCard)
    local tOne = HArray.FindFirst(self.tCardData.tRepairingList, "nCardID", tOneCard.nCardID)
    if not tOne then
        return
    end
    
    tOne.nEndTime = tOneCard.nEndTime  

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CAR_COSTITEM, tOneCard)
end

function KPlayer:QuickRepairngCard(nCardID, nCurrentHP)
    local tOne = HArray.FindFirst(self.tCardData.tStoreHouse.tCardList, "nID", nCardID)
    tOne.nCurrentHP = nCurrentHP    
    KSound.playTalk(KSound.TALK.REPAIRCOMPLETE, tOne.nTemplateID)

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG, nCardID)
end

function KPlayer:QuickRepairngAllCard(nTeamID)
    local tList = self.tTeamData.tTeamList 
    local tOneTeam = HArray.FindFirst(tList, "nIndex", nTeamID)
    local cardList = tOneTeam["tCardIDList"]
    for k, v in ipairs(cardList) do
        local tOne = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, v)
        local nMaxHP = KUtil.getCardMaxHp(tOne)
        tOne.nCurrentHP = nMaxHP
    end

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG_ALLCARD, nTeamID)
end

function KPlayer:CardSupplyed(nID, nCostOil, nCostAmmo)
    local tOne = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, nID)
    tOne.nCurrentOil = KConfig["cardInfo"][tOne.nTemplateID]["nCarryOil"]
    tOne.nCurrentAmmo = KConfig["cardInfo"][tOne.nTemplateID]["nCarryAmmo"]

    KSound.playTalk(KSound.TALK.SUPPLY, tOne.nTemplateID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_SUPPLY_CARD_FINISH,nID)
end

function KPlayer:TeamSupplyed(nTeamID, nCostOil, nCostAmmo)
    local tList = self.tTeamData.tTeamList 
    local tOneTeam = HArray.FindFirst(tList, "nIndex", nTeamID)
    local cardList = tOneTeam["tCardIDList"]
    for k, v in ipairs(cardList) do
        local tOne = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, v)
        tOne.nCurrentOil = KConfig["cardInfo"][tOne.nTemplateID]["nCarryOil"]
        tOne.nCurrentAmmo = KConfig["cardInfo"][tOne.nTemplateID]["nCarryAmmo"]
        if k == 1 then
            KSound.playTalk(KSound.TALK.SUPPLY, tOne.nTemplateID)
        end
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, nTeamID)
    print("dispatchEvent:NET_NOTIFY_SUPPLY_TEAM_FINISH，",nTeamID)
end

function KPlayer:SkillSupplyed(tSupplySkillInfo)
    local tList = self.tSkillList
    for _,tSupplyData in pairs(tSupplySkillInfo) do
        for __, tSkillData in ipairs(tList) do
            if tSkillData.nEquipID == tSupplyData.nEquipID then
                tSkillData.nLeftTimes = tSupplyData.nLeftTimes
            end
        end
    end
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_SUPPLY_SKILL_FINISH, tSupplySkillInfo)
    print("dispatchEvent:NET_NOTIFY_SUPPLY_SKILL_FINISH", tSupplySkillInfo)
end

function KPlayer:UpdateSkillLeftTimes(nEquipID, nLeftTimes)
    local tList     = self.tSkillList
    local tOneSkill = HArray.FindFirst(tList, "nEquipID", nEquipID)
    if tOneSkill then
        tOneSkill.nLeftTimes = nLeftTimes
    end
end

function KPlayer:UpdateCardLevel(nID, nLevel, nCurrentExp)
    local tOne = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, nID)
    tOne.nLevel = nLevel
    tOne.nCurrentExp = nCurrentExp 
end

-- item && equip

function KPlayer:AddProducingEquip(tOne)
    table.insert(self.tItemData.tProducingEquipList, tOne)
end

function KPlayer:EquipProduceFinish(nID)
    local tOneEquip = HArray.FindFirstByID(self.tItemData.tEquipStoreHouse.tEquipList, nID)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    eventDispatchCenter:dispatchEvent(eventDispatchCenter.EventType.NET_BUILD_EQUIP, tOneEquip.nTemplateID)
end

function KPlayer:DelProducingEquip(nID)
    HArray.RemoveFirstByID(self.tItemData.tProducingList, nID)
end

function KPlayer:AddEquip(tOne)
    table.insert(self.tItemData.tEquipStoreHouse.tEquipList, tOne)

    local templateID = tOne.nTemplateID
    local tEquipCollection = self.tItemData.tHistoricalEquipID
    local reverseTable = {}
    for index, id in ipairs(tEquipCollection) do
        assert(reverseTable[id] == nil, "repeated equip ID exist~")
        reverseTable[id] = index
    end
    if reverseTable[templateID] == nil then
        table.insert(tEquipCollection, templateID)
    end
end

function KPlayer:DelEquip(nID)
    HArray.RemoveFirstByID(self.tItemData.tEquipStoreHouse.tEquipList, nID)
end

function KPlayer:AddOneItem(tOne)
    table.insert(self.tItemData.tStoreHouse.tItemList, tOne)
    local templateID = tOne.nTemplateID
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ITEM_ADD, templateID)
    print("dispatchEvent:NET_ITEM_ADD，", templateID)
end

function KPlayer:RemoveItem(nID)
    local tOne = HArray.FindFirstByID(self.tItemData.tStoreHouse.tItemList, nID)
    local templateID = tOne.nTemplateID
    
    HArray.RemoveFirstByID(self.tItemData.tStoreHouse.tItemList, nID)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ITEM_REMOVE, templateID)
    print("dispatchEvent:NET_ITEM_REMOVE，", templateID)
end

function KPlayer:UpdateItemCount(nID, nCount)
    local tOne = HArray.FindFirstByID(self.tItemData.tStoreHouse.tItemList, nID)
    tOne.nCount = nCount
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ITEM_UPDATE, tOne.nTemplateID)
    print("dispatchEvent:NET_ITEM_UPDATE，", tOne.nTemplateID)
end

function KPlayer:BreakDownEquip(nID, nOil, nAmmo, nSteel, nPeople)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BREAK_DOWN_EQUIP, nID, nOil, nAmmo, nSteel, nPeople)
end

function KPlayer:BreakDownEquipList(tEquipIDList)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EQUIPS_BREAK, tEquipIDList)
end

-- team
function KPlayer:SyncOneTeam(tOne, nCardID)
    local tList = self.tTeamData.tTeamList
    HArray.RemoveFirst(tList, "nIndex", tOne.nIndex)
    table.insert(tList, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, nCardID, tOne.nIndex) 
end

-- teamRecord
function KPlayer:SyncOneRecordTeam(tOne)
    local tList = self.tTeamData.tRecordTeamList
    HArray.RemoveFirst(tList, "nIndex", tOne.nIndex)
    table.insert(tList, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_SAVE_RECORD_TEAM, tOne.nIndex) 
end

function KPlayer:DelOneRecordTeam(nIndex)
    local tList = self.tTeamData.tRecordTeamList
    HArray.RemoveFirst(tList, "nIndex", nIndex)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_DEL_RECORD_TEAM, nIndex)
end

function KPlayer:SyncTwoTeam(tTeamA, tTeamB, nCardID)
    local tList = self.tTeamData.tTeamList
    HArray.RemoveFirst(tList, "nIndex", tTeamA.nIndex)
    HArray.RemoveFirst(tList, "nIndex", tTeamB.nIndex)
    table.insert(tList, tTeamA)
    table.insert(tList, tTeamB)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, nCardID) 
end

function KPlayer:SyncOneCard(tOne)
    local tList = self.tCardData.tStoreHouse.tCardList
    HArray.RemoveFirstByID(tList, tOne.nID)
    table.insert(tList, tOne)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_ONE_CARD_CHANGE, tOne) 
end

function KPlayer:AddCardMountItem(nCardID, nItemTemplateID)
    local cardList = self.tCardData.tStoreHouse.tCardList
    local oneCard = HArray.FindFirstByID(cardList, nCardID)

    if not oneCard then return end

    oneCard.nMountItemTemplateID = nItemTemplateID

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_ONE_CARD_CHANGE, oneCard)
end

function KPlayer:RemoveCardMountItem(nCardID)
    local cardList = self.tCardData.tStoreHouse.tCardList
    local oneCard = HArray.FindFirstByID(cardList, nCardID)

    if not oneCard then return end

    oneCard.nMountItemTemplateID = 0

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_ONE_CARD_CHANGE, oneCard)
end

function KPlayer:AddExpeditionDataRespond(tOne)
    local tList = self.tExpeditionData.tExpeditionList
    table.insert(tList, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_ADD_EXPEDITION, tOne.nType, tOne.nTemplateID, tOne.nTeamID) 
end

function KPlayer:RemoveExpeditionRespond(nType, nTemplateID)
    KUtil.removeExpedition(nType, nTemplateID)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_REMOVE_EXPEDITION, nType, nTemplateID) 
end

function KPlayer:AddAreaLastIDRespond(tOne)
    local tList = self.tExpeditionData.tAreaLastIDList
    table.insert(tList, tOne)
end

function KPlayer:UpdateAreaLastIDRespond(tOne)
    local tList = self.tExpeditionData.tAreaLastIDList
    HArray.RemoveFirst(tList, "nType", tOne.nType)
    table.insert(tList, tOne)
end

function KPlayer:AddPlunderTime(nLeftTimes)
    self.tPlunderData.nLeftTimes = nLeftTimes

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ADD_PLUNDER_TIME, nLeftTimes) 
end

function KPlayer:GetExpeditionReward(nTemplateID, nAreaType, tResultList, tExtraResource, szNameList, nFightCount)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_EXPEDITION_REWARD, nTemplateID, nAreaType, tResultList, tExtraResource, szNameList, nFightCount) 
end

function KPlayer:RespondPlunderExpeditionList(tRolePlunderData, nRefreshTime, nLeftTimes, bIsReload)
    self.tPlunderData.tRolePlunderDetail = {}
    self.tPlunderData.tRolePlunderList   = tRolePlunderData
    self.tPlunderData.nRefreshTime       = nRefreshTime
    self.tPlunderData.nLeftTimes         = nLeftTimes

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_PLUNDER_LIST, tRolePlunderData, nRefreshTime, nLeftTimes, bIsReload) 
end

function KPlayer:RespondExpeditionBattleData(tExpeditionInfo, nLeftTimes)
    self.tPlunderData.nLeftTimes         = nLeftTimes
    self.tPlunderData.tRolePlunderDetail = self.tPlunderData.tRolePlunderDetail or {}
    local nType       = tExpeditionInfo.tOne.expeditiontype
    local nTemplateID = tExpeditionInfo.tOne.expeditionid
    local szKey       = KUtil.getExpeditionTableKey(nType, nTemplateID)
    self.tPlunderData.tRolePlunderDetail[szKey] = tExpeditionInfo

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_PLUNDER_DETAIL, tExpeditionInfo, nLeftTimes) 
end

function KPlayer:RespondExpeditionFinishBattle(nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes, tCardExpAward, tCardFeeling)
    self.tPlunderData.nLeftTimes = nLeftTimes

    self.tPlunderData.tRolePlunderDetail = self.tPlunderData.tRolePlunderDetail or {}
    local szKey       = KUtil.getExpeditionTableKey(nExpeditionType, nExpeditionID)
    local tExpeditionInfo = self.tPlunderData.tRolePlunderDetail[szKey]
    if tExpeditionInfo then tExpeditionInfo.bBattle = true end

    self.tPlunderData.tRolePlunderList = self.tPlunderData.tRolePlunderList or {}
    local tRoleExpedition = self.tPlunderData.tRolePlunderList[szKey]
    if tRoleExpedition then tRoleExpedition.bBattle = true end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_PLUNDER_BATTLE_FINISH, nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes, tCardExpAward, tCardFeeling) 
end

function KPlayer:ErrorRespond(errorCode)
    local errorKey = "errorCode" .. errorCode

    local stringConfig = KConfig:getLine("string", errorKey) or {}
    local errorString = stringConfig.szText or ("errorCode:" .. errorCode)
    local szType = stringConfig.szType or ""
    showNotice(errorString, szType)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ERROR_CODE, errorCode) 
end

function KPlayer:AccessMission(missionID)
    self.bAccessMission = false
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ACCESS_MISSION, missionID) 
end

function KPlayer:ReturnGetMissionReward(missionID)
    local missionData = self.tMissionData
    local missionList = missionData.tMissionList
    assert(#missionList > 0)
    HArray.RemoveFirst(missionList, "nID", missionID)
    HArray.UniqueInsertByValue(missionData.tHistoricalMissionList, missionID)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_GET_MISSION_REWARD, missionID)
end

function KPlayer:UpdateOneMission(missionID, mission)
    if not self.tMissionData then return end
    HArray.RemoveFirstByValue(self.tMissionData.tHistoricalMissionList, missionID)

    local missionList = self.tMissionData.tMissionList
    if mission == nil then
        HArray.RemoveFirst(missionList, "nID", missionID)
    else
        local oldMission = HArray.FindFirstByID(missionList, missionID)
        if oldMission == nil then
            table.insert(missionList, mission)
        else
            oldMission.tObjectivesList = {}
            local objectiveList = mission.tObjectivesList
            for i, v in ipairs(objectiveList) do
                print(v.nID ,  v.nCompletedCount)
                table.insert(oldMission.tObjectivesList, {nID = v.nID , nCompletedCount = v.nCompletedCount})
            end
        end
    end
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MISSION, missionID)
end

function KPlayer:StrengthenCard(bSuccess, nConsumeCardID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_STRENGTHEN, bSuccess, nConsumeCardID)
end

function KPlayer:ConvertCard(nOldCardID, nCardID, nLevel, tAttributes, nCurrentHP, isNewCard)
    local tOne = HArray.FindFirst(self.tCardData.tStoreHouse.tCardList, "nID", nCardID)
    tOne.nLevel      = nLevel 
    tOne.tAttributes = tAttributes    
    tOne.nCurrentHP  = nCurrentHP
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_NOTIFY_CONVERT_CARD, nOldCardID, nCardID, isNewCard)
end

function KPlayer:UseSkin(nCardID, nSkinTemplateID)
    local tOneCard = HArray.FindFirst(self.tCardData.tStoreHouse.tCardList, "nID", nCardID)
    tOneCard.nSkinTemplateID = nSkinTemplateID
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_USE_SKIN, nCardID, nSkinTemplateID)
end

function KPlayer:BuyGoodRespond(nGoodID, nResult, nBuyCount)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BUY_GOOD_SUCCESS, nGoodID, nResult, nBuyCount)
end

function KPlayer:BuySkinRespond(nGoodID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BUY_GOOD_SUCCESS, nGoodID, BUY_RET.SUCCESS, 1)
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BUY_SKIN_SUCCESS, nGoodID)
end

function KPlayer:AddSkin(nSkinTemplateID)
    HArray.UniqueInsertByValue(self.tSkinData.tSkinList, nSkinTemplateID)
end

function KPlayer:BuyCount(nGoodsID, nBuyCount)
    local tOneGoods = HArray.FindFirstByID(self.tShopData.tBuyGoods, nGoodsID)
    if not tOneGoods then
        tOneGoods = {nID = nGoodsID, nCount = nBuyCount, nDayCount = 0, nWeekCount = 0}
        table.insert(self.tShopData.tBuyGoods, tOneGoods)
    else
        tOneGoods.nCount = nBuyCount
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BUY_COUNT, nGoodsID, nBuyCount)
end

function KPlayer:DayBuyCount(nGoodsID, nDayBuyCount)
    local tOneGoods = HArray.FindFirstByID(self.tShopData.tBuyGoods, nGoodsID)
    if not tOneGoods then
        tOneGoods = {nID = nGoodsID, nCount = 0, nDayCount = nDayBuyCount, nWeekCount = 0}
        table.insert(self.tShopData.tBuyGoods, tOneGoods)
    else
        tOneGoods.nDayCount = nDayBuyCount
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_DAY_BUY_COUNT, nGoodsID, nDayBuyCount)
end

function KPlayer:WeekBuyCount(nGoodsID, nWeekBuyCount)
    local tOneGoods = HArray.FindFirstByID(self.tShopData.tBuyGoods, nGoodsID)
    if not tOneGoods then
        tOneGoods = {nID = nGoodsID, nCount = 0, nDayCount = 0, nWeekCount = nWeekBuyCount}
        table.insert(self.tShopData.tBuyGoods, tOneGoods)
    else
        tOneGoods.nWeekCount = nWeekBuyCount
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_WEEK_BUY_COUNT, nGoodsID, nWeekBuyCount)
end

-- battle
function KPlayer:OpenBattleZone(tOne)
    local tBattleData = self.tBattleData

    HArray.RemoveFirst(tBattleData, "nZoneID", tOne.nZoneID)
    table.insert(tBattleData, tOne)
end

function KPlayer:OpenBattleMap(nZoneID, tOne, tOneMapSpecialData)
    local tBattleData = self.tBattleData
    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    HArray.RemoveFirst(tOneBattleZoneData.tMaps, "nMapID", tOne.nMapID)
    table.insert(tOneBattleZoneData.tMaps, tOne)

    if tOneMapSpecialData == nil then return end
    local tMapSetting = KConfig:getLine("battle", tOneMapSpecialData.nZoneID, tOneMapSpecialData.nMapID, 1)
    if tMapSetting.nMode == BATTLE_MAP_MODE.DIFFCULT2 then
        for i, v in ipairs(self.tBattleSpecialData.t2ndDiffcultModeSpecialData) do
            if v.nZoneID == tOneMapSpecialData.nZoneID and v.nMapID == tOneMapSpecialData.nMapID then
                table.remove(self.tBattleSpecialData.t2ndDiffcultModeSpecialData, i)
                break
            end
        end
        table.insert(self.tBattleSpecialData.t2ndDiffcultModeSpecialData, tOneMapSpecialData)
        return
    end
end

function KPlayer:BattleZoneClosed(nZoneID)
    local tBattleData = self.tBattleData
    HArray.RemoveFirst(tBattleData, "nZoneID", nZoneID)
end

function KPlayer:MapPass(nZoneID, nMapID)
    local tBattleData = self.tBattleData
    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    local tOneMapData = HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", nMapID)
    tOneMapData.bPass = true
end

function KPlayer:SyncMapProgress(nZoneID, nMapID, nProgress)
    local tBattleData = self.tBattleData
    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    local tOneBattleMapData = HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", nMapID)

    tOneBattleMapData.nProgress = nProgress
end

function KPlayer:MapWinCount(nZoneID, nMapID, nWinCount, nLastWinDay)
    local tBattleData = self.tBattleData
    local tOneBattleZoneData      = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    local tOneBattleMapData       = HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", nMapID)
    tOneBattleMapData.nWinCount   = nWinCount
    tOneBattleMapData.nLastWinDay = nLastWinDay
end

function KPlayer:GetBattleMapSpecialData(nZoneID, nMapID)
    for _, v in ipairs(self.tBattleSpecialData.t2ndDiffcultModeSpecialData) do
        if v.nZoneID == nZoneID and v.nMapID == nMapID then
            return v
        end
    end
end

function KPlayer:SyncDiffcult2MapPassFlag(nZoneID, nMapID, nDiffcultLevel, bPass)
    local tOneMapSpecialData = self:GetBattleMapSpecialData(nZoneID, nMapID)
    local bLevelPassName     = "bLevel" .. nDiffcultLevel .. "Pass"
    tOneMapSpecialData[bLevelPassName] = bPass

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_DIFFICULTY_LEVEL_PASS, nZoneID, nMapID, nDiffcultLevel, bPass)
end

function KPlayer:SelectMapDifficult(nZoneID, nMapID, nDiffcult, nProgress, bPass)
    local tBattleData            = self.tBattleData
    local tOneBattleZoneData     = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    local tOneBattleMapData      = HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", nMapID)
    tOneBattleMapData.nProgress  = nProgress
    local tOneMapSpecialData     = self:GetBattleMapSpecialData(nZoneID, nMapID)
    tOneMapSpecialData.nDiffcult = nDiffcult
    tOneMapSpecialData.bPass     = false

    local eventDispatch = require("src/logic/KEventDispatchCenter") 
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CHANGE_DIFFICULTY, nZoneID, nMapID, nDiffcult, nProgress)
end

function KPlayer:AddMapFinishFoothold(nZoneID, nMapID, nFootholdID)
    local tBattleData = self.tBattleData

    local tOneBattleZoneData = HArray.FindFirst(tBattleData, "nZoneID", nZoneID)
    local tOneBattleMapData = HArray.FindFirst(tOneBattleZoneData.tMaps, "nMapID", nMapID)

    HArray.UniqueInsertByValue(tOneBattleMapData.tFinishFoothold, nFootholdID)
end

function KPlayer:BattleFinished(nResultType, nZoneID, nMapID, nFootholdID, ...)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.BATTLE_FINISHED, nResultType, nZoneID, nMapID, nFootholdID, ...)
end

function KPlayer:FinishResourceFoothold(nZoneID, nMapID, nFootholdID, tAwardList)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.RESOURCE_FOOTHOLD, nnZoneID, nMapID, nFootholdID, tAwardList)
end

function KPlayer:FinishAccidentFoothold(nZoneID, nMapID, nFootholdID, nCostOil, nCostAmmo)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.ACCIDENT_FOOTHOLD, nZoneID, nMapID, nFootholdID, nCostOil, nCostAmmo)
end

function KPlayer:FinishEmptyFoothold(nZoneID, nMapID, nFootholdID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NONE_FOOTHOLD, nZoneID, nMapID, nFootholdID)
end

function KPlayer:AddDeadEquip(tOne)
    table.insert(self.tItemData.tDeadEquipList, tOne)
end

function KPlayer:DelDeadEquip(nID)
    HArray.RemoveFirstByID(self.tItemData.tDeadEquipList, nID)
end

function KPlayer:ExpandBar(type)  
    local eventDispatch = require("src/logic/KEventDispatchCenter")       
    if type == EXPAND_BAR_TYPE.BUILD then
        self.nBuildBarNum = self.nBuildBarNum + 1
        eventDispatch:dispatchEvent(eventDispatch.EventType.EXPAND_BUILDBAR)
    else
        self.nRepairBarNum = self.nRepairBarNum + 1
        eventDispatch:dispatchEvent(eventDispatch.EventType.EXPAND_REPAIRBAR)
    end
end

function KPlayer:OpenNextTeam(nOpenCount)
    self.tTeamData.nOpenCount = nOpenCount
end

function KPlayer:showNoticeByID(nNoticeID, ...)
    showNoticeByID(nNoticeID, ...)
end

function KPlayer:showNotice(szNoticeInfo, nType, ...)
    showNotice(szNoticeInfo, nType, ...)
end

function KPlayer:ShowAddItem(tItems, tFirstAddCard)
    local uiRewardNode = cc.Director:getInstance():getRunningScene():addNode("Reward", {tResultList = tItems})

    if not tFirstAddCard or not uiRewardNode then return end

    local function playGetCardAnimation(nCardID, bNewCard)
        KUtil.playGetCardAnimation(nCardID, bNewCard)
    end 
    uiRewardNode:setCallback(playGetCardAnimation, {tFirstAddCard.nCardID, tFirstAddCard.bNewCard})
end

function KPlayer:SyncBagCount(nCardBagCount, nEquipBagCount)
    self.tCardData.tStoreHouse.nMaxSize      = nCardBagCount
    self.tItemData.tEquipStoreHouse.nMaxSize = nEquipBagCount
end

function KPlayer:ReturnUpdateGuide(nProgress, nNextGuideIndex)
    KPlayer.progressID  = nProgress
    require("src/logic/KGuideEnv")._guideIndex = nNextGuideIndex 
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_GUIDE, nNextGuideIndex)
end

-- team rename
function KPlayer:TeamRename(tOne)
    local tList = self.tTeamData.tTeamList
    HArray.RemoveFirst(tList, "nIndex", tOne.nIndex)
    table.insert(tList, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_TEAM_RENAME, tOne)
end

function KPlayer:SyncEquipLock(nID, bLock)
    local tOneEquip = HArray.FindFirstByID(self.tItemData.tEquipStoreHouse.tEquipList, nID)
    tOneEquip.bLock = bLock
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EQUIP_LOCK, nID, bLock)
end

function KPlayer:KickedByRelogin()
    KGameServer:BeKicked()
    local function confirmFunction()
        cc.Director:getInstance():endToLua()
    end
    showConfirmation(KUtil.getStringByKey("common.kicked"), confirmFunction, confirmFunction)
end

function KPlayer:ReturnSign(tSignData)
    self.tSignData = tSignData
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SIGN, tSignData.nCurDay, tSignData.nCount)
end

function KPlayer:GetAnnounceInfo(nVersionIndex, tAnnounceInfo)
    local isChange = false
    if nVersionIndex and tAnnounceInfo and type(tAnnounceInfo) == "table" then
        local annouceString = KUtil.getAnnounceString(tAnnounceInfo)
        local setting = require("src/logic/KSetting")
        setting.setString(setting.Key.ANNOUNCE_INFO, annouceString)

        local setting = require("src/logic/KSetting")
        setting.setInt(setting.Key.ANNOUNCE_VERSION, tonumber(nVersionIndex))

        isChange = true
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ANNOUNCE, isChange)
end

function KPlayer:ShowAnnounce(tMessage)
    if not self.bDataReady then return end
    require("src/ui/common/KUIShowAnnounceNode").insertMessage(tMessage)
end

function KPlayer:ChangeRoleFurniture(tOne)
    local tRoleFurniture = self.tFurnitureData.tRoleFurniture
    HArray.RemoveFirst(tRoleFurniture, "nType", tOne.nType)

    table.insert(tRoleFurniture, tOne)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CHANGE_FURNITURE, tOne)
end

function KPlayer:AddFurniture(tOne)
    local tFurnitureList = self.tFurnitureData.tFurnitureList
    HArray.RemoveFirst(tFurnitureList, "nTemplateID", tOne.nTemplateID)

    table.insert(tFurnitureList, tOne)
end

function KPlayer:BuyFurniture(nTemplateID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BUY_FURNITURE, nTemplateID)
end

function KPlayer:SyncFurnitureCoin(nFurnitureCoin)
    self.furnitureCoin = nFurnitureCoin

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_FURNITURE_COIN)
end

function KPlayer:RetExchangeCode(nRetuenCode)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EXCHANGE, nRetuenCode)
end

function KPlayer:SyncCardFeeling(nCardID, nFeeling)
    local tOne = HArray.FindFirst(self.tCardData.tStoreHouse.tCardList, "nID", nCardID)
    assert(tOne, "SyncCardFeeling not found card is=:" .. nCardID)
    tOne.nFeeling = nFeeling

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_FEELING, tOne)
end

function KPlayer:OnRecvPrivateMessage(nSrcRoleID, szSrcRoleName, szMessage)
    local tOneMessageData = 
    {
        szType          = CHAT_TYPE.PRIVATE,
        nSrcRoleID      = nSrcRoleID,
        szSrcRoleName   = szSrcRoleName,
        szMessage       = szMessage,
    }

    KPlayer:AddReceivedMessage(tOneMessageData)

    self.bHasNewPrivateMessage = true

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_RECEIVE_PRIVATE_MESSAGE, tOneMessageData)
end

function KPlayer:AddReceivedMessage(tOneMessageData)

    for szChanelType, tMessageList in pairs(self.tMessageData) do
        local tFilter = CHAT_CHANEL_SETTINGS[szChanelType].FILTER
        if HArray.FindFirstIndexByValue(tFilter, tOneMessageData.szType) then
            table.insert(tMessageList, tOneMessageData)
            if #tMessageList >  KConfig.otherSetting["nMaxChatCount_" .. szChanelType] then
                table.remove(tMessageList, 1)
            end
        end
    end
end

function KPlayer:OnRecvGlobalMessage(nSrcRoleID, szSrcRoleName, szMessage)
    local tOneMessageData = 
    {
        szType          = CHAT_TYPE.GLOBAL,
        nSrcRoleID      = nSrcRoleID,
        szSrcRoleName   = szSrcRoleName,
        szMessage       = szMessage,
    }

    KPlayer:AddReceivedMessage(tOneMessageData)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_RECEIVE_GLOBAL_MESSAGE, tOneMessageData) 
end

function KPlayer:RecordSendMessage(nChatType, szMessage, ...)
    self.tLastSendChatMessageTime[nChatType] = GlobalStatus.nCurrentTime

    if nChatType == CHAT_TYPE.PRIVATE then
        local tOneMessageData = 
        {
            szType          = CHAT_TYPE.SEND_PRIVATE,
            nSrcRoleID      = KPlayer.id,
            szMessage       = szMessage,
            szDstRoleName   = select(1, ...),
        }

        KPlayer:AddReceivedMessage(tOneMessageData)
    end
end

function KPlayer:TargetNotExist(szDstRoleName)
    local szDstRoleName = szDstRoleName

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_TARGET_NOT_EXIST, szDstRoleName) 
end

function KPlayer:TargetOffline(szDstRoleName)
    local szDstRoleName = szDstRoleName

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_TARGET_OFF_LINE, szDstRoleName) 
end

function KPlayer:WearMarriageRing(tOneCard)
    local tCardList = self.tCardData.tStoreHouse.tCardList
    HArray.RemoveFirstByID(tCardList, tOneCard.nID)
    table.insert(tCardList, tOneCard)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_MARRIAGE_RING, tOneCard)
end

function KPlayer:RespondExerciseRoleList(nNextTime, tRoleList)
    self.tExerciseData.nNextTime = nNextTime
    self.tExerciseData.tRoleList = tRoleList

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EXERCISE_ROLE_LIST, nNextTime, tRoleList)
end

function KPlayer:RespondExerciseRoleDetail(nBattleRoleID, tExercise)
    if not self.tExerciseData.tRoleList then return end
    local roleData = HArray.FindFirst(self.tExerciseData.tRoleList, "nRoleID", nBattleRoleID)
    if not roleData then return end

    roleData.tExercise = tExercise
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EXERCISE_ROLE_DETAIL, nBattleRoleID, tExercise)
end

function KPlayer:FinishExerciseBattle(nBattleRoleID, nResultType, tCardExpAward, tCardFeeling)
    local tOne  = HArray.FindFirst(self.tExerciseData.tRoleList, "nRoleID", nBattleRoleID)
    assert(tOne)
    tOne.nScore = nResultType

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_EXERCISE_BATTLE_FINISH, nBattleRoleID, nResultType, tCardExpAward, tCardFeeling)
end

function KPlayer:SyncMailBox(tMailList)
    KUtil.sortOneMailList(tMailList)
    self.tMailData.tMailList = tMailList

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SYNC_MAIL_LIST)
end

function KPlayer:RespondSendMail(nID)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SEND_MAIL_RESULT, nID)
end

function KPlayer:ReceiveNewMail(nID, tOneMail)
    local oneMailList = self.tMailData.tMailList
    local oneMail = HArray.FindFirstByID(oneMailList, tOneMail.nID)
    if not oneMail then
        table.insert(oneMailList, 1, tOneMail)

        local eventDispatch = require("src/logic/KEventDispatchCenter")
        eventDispatch:dispatchEvent(eventDispatch.EventType.NET_RECEIVE_NEW_MAIL, nID)
    end
end

function KPlayer:RespondMailData(tMailDataList)
    local oneMailList = self.tMailData.tMailList
    local mailIDList  = {}

    for _, mailData in ipairs(tMailDataList) do
        local oneMail = HArray.FindFirstByID(oneMailList, mailData.nID)
        if oneMail then
            oneMail.tMailData = mailData
            table.insert(mailIDList, oneMail.nID)
        end 
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MAIL_DATA, mailIDList)
end

function KPlayer:RespondOpenMail(nID)
    local oneMail = HArray.FindFirstByID(self.tMailData.tMailList, nID)
    oneMail.bOpen = true

    KUtil.sortOneMailList(self.tMailData.tMailList)
end

function KPlayer:RespondGetMailReward(nID, nRewardID, tRewardList)
    local oneMail = HArray.FindFirstByID(self.tMailData.tMailList, nID)
    oneMail.bAward = true

    KUtil.sortOneMailList(self.tMailData.tMailList)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_MAIL_REWARD, nID, nRewardID, tRewardList)
end

function KPlayer:RemoveMailList(tMailIDList)
    local tMailList = self.tMailData.tMailList
    for _, nID in ipairs(tMailIDList) do
        HArray.RemoveFirstByID(tMailList, nID)
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_REMOVE_MAIL)
end

function KPlayer:LockCardList(tCardLockList)
    local lockMap = {}
    for _, tLockCard in ipairs(tCardLockList) do
        lockMap[tLockCard.nID] = tLockCard.bLock
    end

    local resultList = {}
    local cardList = self.tCardData.tStoreHouse.tCardList
    for _, tCard in ipairs(cardList) do
        local isLock = lockMap[tCard.nID]
        if isLock ~= nil then
            tCard.bLock = isLock
            table.insert(resultList, tCard)
        end
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_LOCK_CARD_LIST, resultList)
end

function KPlayer:SyncCardCurrentHP(nCardID, nCurrentHP)
    local card = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, nCardID)
    if not card then return end
    card.nCurrentHP = nCurrentHP
end

function KPlayer:SyncCardOilAndAmmo(nCardID, nCurrentOil, nCurrentAmmo)
    local card = HArray.FindFirstByID(self.tCardData.tStoreHouse.tCardList, nCardID)
    if not card then return end
    card.nCurrentOil  = nCurrentOil
    card.nCurrentAmmo = nCurrentAmmo
end

function KPlayer:CookResult(bFree, nCookResultIdx, tItems)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_COOK_RESULT, bFree, nCookResultIdx, tItems)
end

function KPlayer:SPSignResult(nSignDay, tItems)
    self.tSPSignData.nSignDay = nSignDay
    self.tSPSignData.nLastSignTime = KUtil.getServerTime(os.time())

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SPSIGN_RESULT, nSignDay, tItems)
end

function KPlayer:SkillEnterRole(tOneSkill)
    local tSkillList = self.tSkillList
    HArray.RemoveFirst(tSkillList, "nPos", tOneSkill.nPos)
    table.insert(tSkillList, tOneSkill)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SKILL_CHANGE)
end

function KPlayer:SyncServerTime(nServerTime)
    require("src/logic/KAccelerateCheck").checkServerTime(nServerTime)
end

function KPlayer:StoryGainRewardRet(nStoryID, tItems)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_STORY_REWARD, nStoryID, tItems)
end

function KPlayer:RespondCardTraining(nCardID, nWarID, OneTraining)
    HArray.RemoveFirst(self.tTrainingList, "nTemplateID", nCardID)
    table.insert(self.tTrainingList, OneTraining)
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CARD_TRAINING_FINISH, nCardID, nWarID, OneTraining)
end


function KPlayer:AddProduceCardType(nType)
    local node = cc.Director:getInstance():getRunningScene():addNode("BuildUnlock")
    if not node then return end
    node:addCardUnlockType(nType)
end

function KPlayer:AddProduceEquipType(nType)
    local node = cc.Director:getInstance():getRunningScene():addNode("BuildUnlock")
    if not node then return end
    node:addEquipUnlockType(nType)
end

function KPlayer:IOSPayVerifyRet(strReceiptData, nStatus)
    cclog("-----> strReceiptData: %s\nnStatus: %s", strReceiptData, nStatus)

    -- nStatus = 0 is success
    if nStatus == 0 then
        self:RemoveReceipyInfo(strReceiptData)
    end
end

function KPlayer:RemoveReceipyInfo(szReceiptInfo)
    local KSetting  = require("src/logic/KSetting")
    local roleId    = KPlayer.id

    cclog("-----> KPlayer:RemoveReceipyInfo %s", szReceiptInfo)

    for index = 1, 100 do -- we had reason enough for believe 100 is most limit.
        local payRoleIDKey  = KSetting.Key.PAY_ROLE_ID_KEY_INDEX .. "_" .. index
        local payReceiptKey = KSetting.Key.PAY_RECEIPT_KEY_INDEX .. "_" .. index

        roleIdInfo  = KSetting.getInt(payRoleIDKey, 0)
        rolePayInfo = KSetting.getString(payReceiptKey, "")
        if szReceiptInfo == rolePayInfo then
            cclog(
                "-----> remove receipy success -----> \n<%s : %d>\n<%s : %s>",
                payRoleIDKey, roleIdInfo, payReceiptKey, rolePayInfo
            )

            KSetting.setInt(payRoleIDKey, 0)
            KSetting.setString(payReceiptKey, "")
            return
        end
    end

    cclog("----- Recv Server Remove Receipt But Can't Find Receipt For : s", szReceiptInfo)
end

function KPlayer:GooglePayVerifyRet(strReceiptData, nStatus)
    AppBilling.OnServerVerifyRet(strReceiptData, nStatus)
end

function KPlayer:Logout()
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:clearAllEvent()
    KGameServer:Logout()
    for k, v in pairs(self) do 
        if type(v) ~= "function" then 
            self[k] = nil
        end
    end

    self:init()
end

function KPlayer:AddChargeCoinNotice(tGoodsInfo, nChargeCoin)
    self.chargeCoin = nChargeCoin
end

