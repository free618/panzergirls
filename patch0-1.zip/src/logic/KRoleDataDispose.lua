
local KRoleDataDispose = {}
KRoleDataDispose.tKeyList = {}
KRoleDataDispose.tBaseTypeList = {int32 = {0}, bool = {}, bytes = {}}

function KRoleDataDispose.Init()
    KRoleDataDispose.tKeyList = require "src/settings/data" 
end

local function ValueToString(value, szType)
    if not value then return end
    local tBaseType = KRoleDataDispose.tBaseTypeList[szType]
    if tBaseType and tBaseType[1] == value then return end
    -- if szType == "int32" and value == 0 then return end
    local tKeyList = KRoleDataDispose.tKeyList[szType]
    if tKeyList then
        return KRoleDataDispose.ToString(value, szType) 
    end
    assert(KRoleDataDispose.tBaseTypeList[szType])
    return tostring(value)
end

function KRoleDataDispose.TableToString(t, szType)
    local tKeyList = KRoleDataDispose.tKeyList[szType]
    assert(tKeyList)
    local szLua    = "{"
    for i, szKey in ipairs(tKeyList) do
        local value  = t[szKey[1]]
        -- print(szKey[1], "=", tostring(value))
        local szType = szKey[2]
        local szValue
        if szType == "array" then
            szValue = "{"
            for i, v in ipairs(value) do
                local szTemp = ValueToString(v, szKey[3])
                if szTemp then
                    szValue = szValue .. szTemp
                end
                szValue = szValue .. ","
            end
            szValue = szValue .. "}"
        else
            szValue = ValueToString(value, szType)
        end
        if szValue then
            szLua = szLua .. szValue
        end
        szLua = szLua .. ","
    end
    szLua = szLua .. "}"
    return szLua
end

local function ParseValue(szValue, szType)
    if szType == "bool" then
        return true
    elseif szType == 'bytes' then
        local szTemp = string.match(szValue, '%b""')
        assert(string.len(szTemp) + 2 == string.len(szValue), szValue)
        return szTemp
    elseif szType == "int32" then
        return tonumber(szValue)
    end
end

local function ParseString(szString, szType, nPos)
    local value
    local tKeyList  = KRoleDataDispose.tKeyList[szType]
    if not tKeyList then
        local nFindPos = string.find(szString, ",", nPos)
        assert(nFindPos, nPos)
        if nPos ~= nFindPos then
            local szValue  = string.sub(szString, nPos, nFindPos - 1)
            -- print("szValue", szValue)
            value          = ParseValue(szValue, szType)
        end
        nPos = nFindPos
    else
        local szSubString = string.match(szString, "%b{}", nPos)
        -- print("szSubString", szSubString)
        value = KRoleDataDispose.StringToTable(szSubString, szType)
        nPos  = nPos + string.len(szSubString)
    end
    assert(string.sub(szString, nPos, nPos) == ",", "" .. nPos .. ":" .. szString)
    if not value and KRoleDataDispose.tBaseTypeList[szType] then
        value = KRoleDataDispose.tBaseTypeList[szType][1]
    end
    return value, nPos + 1
end

function KRoleDataDispose.StringToTable(szString, szType)
    -- print(szType)
    local nPos = 1
    assert(string.sub(szString, nPos, nPos) == "{", szString)
    nPos       = nPos + 1
    local t = {}
    local tKeyList = KRoleDataDispose.tKeyList[szType]
    assert(tKeyList, szType)
    for _, v in ipairs(tKeyList) do
        local szKey     = v[1]
        local szSubType = v[2]
        if szSubType   == "array" then
            local szSubString = string.match(szString, "%b{}", nPos)
            local nBeginPos   = 1
            local nEndPos     = string.len(szSubString)
            szSubType         = v[3]
            nBeginPos         = nBeginPos + 1
            t[szKey]          = {}
            -- print(szKey, nPos, szSubType)
            while nBeginPos < nEndPos do
                local value
                value, nBeginPos  = ParseString(szSubString, szSubType, nBeginPos)
                table.insert(t[szKey], value)
            end
            nPos = nPos + nEndPos
            assert(string.sub(szString, nPos, nPos) == ",", "" .. nPos .. ":" .. szString)
            nPos = nPos + 1
        else
            local value
            value, nPos = ParseString(szString, szSubType, nPos)
            if value then
                t[szKey] = value
            end
        end
    end
    assert(string.sub(szString, nPos, nPos) == "}", "" .. nPos .. ":" .. szString)
    return t
end

KRoleDataDispose.Init()
return KRoleDataDispose