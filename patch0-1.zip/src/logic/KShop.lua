--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KShop.lua
--  Creator     : LiuLingLi
--  Date        : 2015/09/21   19:00
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


KUtil = KUtil or {}
KUtil.shopType = {DIAMOND = 1, ITEM = 2, FURNITURE = 3, SPRING = 4, SKIN = 5, EXCHANGE = 6,}

function KUtil.getSortListByType(type)
    local itemList = {}
    for _, itemInfo in pairs(KConfig.shop) do
        if itemInfo.nType == type then 
            if KUtil.isOpeningTime(KUtil.getCurrentServerTime(), itemInfo.otOpenTimes) then
                table.insert(itemList, itemInfo)
            end
        end
    end
    local function sortFunc(item1, item2)
        return item1.nIndex < item2.nIndex
    end
    table.sort(itemList, sortFunc)
    return itemList
end

function KUtil.isShopOpen(type)
    for _, itemInfo in pairs(KConfig.shop) do
        if itemInfo.nType == type then 
            if KUtil.isOpeningTime(KUtil.getCurrentServerTime(), itemInfo.otOpenTimes) then
                return true
            end
        end
    end
    return false
end

function KUtil.isCanBuy(nGoodsID)
    local tOneGoodsConfig = KConfig.shop[nGoodsID]
    assert(tOneGoodsConfig)
    local buyCount = tOneGoodsConfig.nBuyCount or 0
    local dayBuyCount = tOneGoodsConfig.nDayBuyCount or 0
    local weekBuyCount = tOneGoodsConfig.nWeekBuyCount or 0

    print("isCanBuy", nGoodsID, buyCount, dayBuyCount, weekBuyCount)

    local tOneGoodsData = HArray.FindFirstByID(KPlayer.tShopData.tBuyGoods, nGoodsID)
    if not tOneGoodsData then
        return true
    end

    print("isCanBuy", nGoodsID, tOneGoodsConfig.nBuyCount, tOneGoodsData, nCount)

    if buyCount > 0 and tOneGoodsData.nCount >= buyCount then
        return false
    end 

    if dayBuyCount > 0 and tOneGoodsData.nDayCount >= dayBuyCount then
        return false
    end

    if weekBuyCount > 0 and tOneGoodsData.nWeekCount >= weekBuyCount then
        return false
    end

    return true
end

function KUtil.canBuyLimitCount(nGoodsID)
    local tOneGoodsConfig = KConfig.shop[nGoodsID]
    assert(tOneGoodsConfig)
    local buyCount      = tOneGoodsConfig.nBuyCount or 0
    local dayBuyCount   = tOneGoodsConfig.nDayBuyCount or 0
    local weekBuyCount  = tOneGoodsConfig.nWeekBuyCount or 0

    if buyCount <= 0 and dayBuyCount <= 0 and weekBuyCount <= 0 then  return 0 end
    
    local haveBuyCount, haveDayBuyCount, haveWeekBuyCount = 0, 0, 0

    local tOneGoodsData = HArray.FindFirstByID(KPlayer.tShopData.tBuyGoods, nGoodsID)
    if tOneGoodsData then
        haveBuyCount        = tOneGoodsData.nCount
        haveDayBuyCount     = tOneGoodsData.nDayCount
        haveWeekBuyCount    = tOneGoodsData.nWeekCount
    end

    local canBuyCount           =  9999

    if buyCount > 0 then
        local residueBuyCount       = buyCount - haveBuyCount
        canBuyCount = math.min(canBuyCount, residueBuyCount)
    end
    
    if dayBuyCount > 0 then
        local residueDayBuyCount    = dayBuyCount - haveDayBuyCount
        canBuyCount = math.min(canBuyCount, residueDayBuyCount)
    end
    
    if weekBuyCount > 0 then
        local residueWeekBuyCount   = weekBuyCount - haveWeekBuyCount
        canBuyCount = math.min(canBuyCount, residueWeekBuyCount)
    end

    return canBuyCount
end

function KUtil.isShowDouble(nGoodsID)
    local tOneGoodsConfig     = KConfig.shop[nGoodsID]
    assert(tOneGoodsConfig)

    local nMaxAdditionalTimes = tOneGoodsConfig.nMaxAdditionalTimes

    local nBuyCount = 0
    local tOneGoodsData = HArray.FindFirstByID(KPlayer.tShopData.tBuyGoods, nGoodsID)
    if tOneGoodsData then
        nBuyCount = tOneGoodsData.nCount
    end

    return nBuyCount < nMaxAdditionalTimes 
end

function KUtil.isAutoUseItem(nID)
    local config = KConfig.shop[nID]
    if not config then return end
    if config.nItemType ~= ITEM_TYPE.OTHER then
        return
    end
    local itemInfo = KConfig.itemInfo[config.nItemID]
    if not itemInfo then return end

    if itemInfo.bAutoUse then
        return true
    end
end

function KUtil.buyRequest(nShopType, nID)
    local config = KConfig.shop[nID]
    if not config then return end
    local number   = config.nItemCount
    local price    = config.nPrice
    local itemName = config.szName
    if config.nType == KUtil.shopType.DIAMOND then
        local function onConfirm()
            --require("src/network/KC2SProtocolManager"):buyCoin(nID)
            require("src/logic/KSDKAgent"):requestPay(nID)
        end
        local showString = string.format(KUtil.getStringByKey("shop.buyCoinTip"), price, number)
        showConfirmation(showString, onConfirm)
    else
        local function onConfirm()
            require("src/network/KC2SProtocolManager"):buyGood(nID, 1)
        end
        local szCoinName = KUtil.getItemName(config.nCoinType, config.nCoinID)
        local szTipKey   = "shop.buyGoodTip"
        if nShopType == KUtil.shopType.SPRING then szTipKey = "shop.exchangeGoods" end
        local showString = string.format(KUtil.getStringByKey(szTipKey), price, szCoinName, number, itemName)
        showConfirmation(showString, onConfirm)
    end
end

function KUtil.showBuySuccessTip(nID, nCount)
    local config = KConfig.shop[nID]
    if not config then return end
    local number   = config.nItemCount * nCount
    local itemName = config.szName
    if config.nType == KUtil.shopType.DIAMOND then
        showNoticeByID("shop.buyCoinSuccess", number)
    else
        if not KUtil.isAutoUseItem(nID) then
            showNoticeByID("shop.buyGoodSuccess", number, itemName)
        end
    end
end

function KUtil.getCoinLocalizedName(itemInfo)
    local tPrice2ProductID = {
        [6]   = "com.capricegame.panzergirls.coin6.id75",
        [30]  = "com.capricegame.panzergirls.coin30.id2",
        [98]  = "com.capricegame.panzergirls.coin98.id3",
        [198] = "com.capricegame.panzergirls.coin198.id4",
        [328] = "com.capricegame.panzergirls.coin328.id80",
        [648] = "com.capricegame.panzergirls.coin648.id81"
    }

    local itemProductID = tPrice2ProductID[itemInfo.nPrice]

    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if not KPlayer.tPayInfo then
        return itemInfo.szName
    end

    local tPayInfoList = KPlayer.tPayInfo[targetPlatform]
    if not tPayInfoList then
        return itemInfo.szName
    end

    for _, v in pairs(tPayInfoList) do
        if v.productIdentifier == itemProductID then
            return v.localizedPrice
        end
    end
    return itemInfo.szName
end

