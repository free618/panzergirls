--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KSound.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/18   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     : 
--  *********************************************************************


KSound =  KSound or {}

local m_tEffectInfo    = {} --音效
local m_nEffectLimit   = 10  --音效上限
local m_tTalkInfo      = {} --对话
local m_nTalkLimit     = 5  --对话上限
local m_nMusicDefault  = 0.25
local m_nEffectDefault = 0.5
local m_szSoundSuffix  = ".wav"
local m_szSoundPath    = "audio_win"
local m_lastMusicName  = ""

local nTargetPlatform = cc.Application:getInstance():getTargetPlatform()
if (cc.PLATFORM_OS_IPHONE == nTargetPlatform) or (cc.PLATFORM_OS_IPAD == nTargetPlatform) or (cc.PLATFORM_OS_MAC == nTargetPlatform) then
    m_szSoundSuffix = ".mp3"
    m_szSoundPath = "audio_ios"
elseif (cc.PLATFORM_OS_ANDROID == nTargetPlatform) then
    m_szSoundSuffix = ".OGG"
    m_szSoundPath = "audio_and"
elseif (cc.PLATFORM_OS_WINDOWS == nTargetPlatform) then
    m_szSoundSuffix = ".wav"
    m_szSoundPath = "audio_win"
end

KSound.TALK = 
{
    GETCARD            = 6,    --卡片获得时的对白，卡片获得界面对话框出现时播放
    COMMAND1           = 7,    --玩家点击司令部中立绘时播放，在这三个语音中随机一个
    COMMAND2           = 8,    --
    COMMAND3           = 9,
    LAUNCH             = 10,   --玩家点击出击按钮时播放，一个队伍只播放队长的
    FIRE1              = 11,   --攻击阶段，在卡牌立绘出现的同时播放，两条语音中随机播放一个
    FIRE2              = 12,
    NIGHTFIGHT         = 13,   --玩家点击夜战按钮后播放，只播放队长
    NIGHTATTACK        = 14,   --夜战攻击阶段，在卡牌立绘出现的同时播放
    BEWRECK            = 15,   --单位被击毁，在击毁动画出现的同时播放
    ENROLL             = 16,   --整编界面将单位替换时播放(点完退回整编界面时)
    GETRESOURCE        = 17,   --地图上踩到资源点(种类4)时播放
    SMALLBREAK1        = 18,   --单位进入小破状态时播放(被命中的同时)，两条语音中随机播放一个
    SMALLBREAK2        = 19,
    MIDDLEBREAK        = 20,   --单位进入中破状态时播放(被命中的同时)
    MPV                = 21,   --结算界面中当评价出来的同时播放，播放内容为获得MPV的单位
    FINISHFIGHT        = 22,   --从战斗地图返回主界面时播放
    SUPPLY             = 23,   --点击补给按钮时播放(多人同时补给的话只播放队长)
    STRENGTHEN         = 24,   --当玩家点击强化按钮时播放(有属性增长时)
    SMALLREPAIR        = 25,   --小破以及以下状态进入修理状态时播放
    MIDDLEREPAIR       = 26,   --中破及以上状态进入修理状态时播放
    REPAIRCOMPLETE     = 27,   --当有修理完成时播放(语音为队长)
    BUILDCOMPLETE      = 28,   --当有建造完成时播放(语音为队长)
    COMBATGAINS        = 29,   --玩家点进战绩界面时播放(语音为队长)(TODO)
    MARRIED            = 30,   --结婚显示文字语音
}

function KSound.getEffectPath(szEffectKey)
    local tConfig = KConfig.sound[szEffectKey]
    if not tConfig then cclog("szEffectKey=:%s not found", szEffectKey) return end
    if tConfig.nType ~= 2 then cclog("szEffectKey=:%s not sound effect", szEffectKey) return end
    if "" == tConfig.szPath then return end
    local szFileName = tConfig.szPath .. m_szSoundSuffix
    local szFilePath = string.format("res/%s/effect/%s", m_szSoundPath, szFileName)
    return szFilePath
end

function KSound.getTalkPath(nTalkID, nCardID, bMonster)
    local tCardConfig
    if bMonster then
        tCardConfig = KConfig.monster[nCardID]
    else
        tCardConfig = KConfig.cardInfo[nCardID]
    end
    local szCardName = "I"
    if tCardConfig then szCardName = tCardConfig.szTalkPath end
    local szFileName = nTalkID .. m_szSoundSuffix
    local szFilePath = string.format("res/%s/talk/%s/%s", m_szSoundPath, szCardName, szFileName)
    return szFilePath
end

function KSound.getMusicPath(szMusicKey)
    local tConfig = KConfig.sound[szMusicKey]
    if not tConfig then cclog("szMusicKey=:%s not found", szMusicKey) return end
    if tConfig.nType ~= 1 then cclog("szMusicKey=:%s not music", szMusicKey) return end
    if "" == tConfig.szPath then return end
    local szFileName = tConfig.szPath .. m_szSoundSuffix
    local szFilePath = string.format("res/%s/music/%s", m_szSoundPath, szFileName)
    return szFilePath
end

function KSound.playEffect(szEffect)
    local szFilePath  = KSound.getEffectPath(szEffect)
    if not szFilePath then return end
    KSound.stopSameCaseEffect(szFilePath, szEffect)
    local nSoundID = AudioEngine.playEffect(szFilePath, false)
    AudioEngine.setEffectsVolume(KSound.getEffectVolume())
    KSound.checkEffectList(m_tEffectInfo, m_nEffectLimit, nSoundID, szFilePath, szEffect)
end

function KSound.playTalk(nTalkID, nCardID, bMonster)
    --check random target
    local nStartID, nEndID = KSound.getRandomRange(nTalkID)
    if nStartID ~= 0 and nEndID ~= 0 then 
         nTalkID = math.random(nStartID, nEndID)
    end
    --play target
    local szFilePath = KSound.getTalkPath(nTalkID, nCardID, bMonster)
    if not cc.FileUtils:getInstance():isFileExist(szFilePath) then
        return
    end
    --stop same case
    KSound.stopSameCaseTalk(nTalkID)
    local nSoundID = AudioEngine.playEffect(szFilePath, false)
    AudioEngine.setEffectsVolume(KSound.getEffectVolume())
    
    KSound.checkEffectList(m_tTalkInfo, m_nTalkLimit, nSoundID, szFilePath, tostring(nTalkID))
end

function KSound.playMusic(szMusic, isLoop)
    --can release resource
    local bIsLoop = true
    if isLoop ~= nil then bIsLoop = isLoop end
    local szFilePath  = KSound.getMusicPath(szMusic)
    if not szFilePath then return end
    AudioEngine.playMusic(szFilePath, bIsLoop)
    AudioEngine.setMusicVolume(KSound.getMusicVolume())
end

function KSound.stopMusic()
    AudioEngine.stopMusic()
end

function KSound.pauseMusic()
    AudioEngine.pauseMusic()
end

function KSound.resumeMusic()
    AudioEngine.resumeMusic()
end

function KSound.preloadMusic(szFilePath)
    AudioEngine.preloadMusic(szFilePath)
end

function KSound.preloadEffect(szFilePath)
    AudioEngine.preloadEffect(szFilePath)
end

local specialEffect = {
    ["boom"] = true,
    ["fire"] = true,
    ["howitzer"] = true,
    ["tankFightForward"] = true,
    ["tankAppear"] = true,
}

function KSound.stopSameCaseEffect(szFilePath, szName)
    if specialEffect[szName] then return end
    for nIndex, tInfo in ipairs(m_tEffectInfo) do
        if szFilePath == tInfo.szFilePath then
            for _, nSoundID in ipairs(tInfo.tList) do
                AudioEngine.stopEffect(nSoundID)
            end
            tInfo.tList = {}
        end
    end
end

local specialTalk = {
    [KSound.TALK.SMALLBREAK1] = true,
    [KSound.TALK.SMALLBREAK2] = true,
    [KSound.TALK.MIDDLEBREAK] = true,
}
function KSound.stopSameCaseTalk(nTalkID, nCardID)
    for nIndex, tInfo in ipairs(m_tTalkInfo) do
        local bIsSpecial = specialTalk[tonumber(tInfo.szEffectType)]
        if not bIsSpecial then
            for _, nSoundID in ipairs(tInfo.tList) do
                AudioEngine.stopEffect(nSoundID)
            end
            tInfo.tList = {}
        end
    end
end

function KSound.checkEffectList(tTable, nLimit, nSoundID, szFilePath, szEffectType)
    --current target path can not unload
    local nIndex = #tTable
    while nIndex > nLimit do
        local tInfo = tTable[nIndex]
        if tInfo.szFilePath ~= szFilePath then
            for _, nSoundID in ipairs(tInfo.tList) do
                AudioEngine.stopEffect(nSoundID)
            end
            AudioEngine.unloadEffect(tInfo.szFilePath)
            table.remove(tTable, nIndex)
        end
        nIndex = nIndex - 1
    end
    --find index for swap
    local nTargetIndex = 0
    for i, tInfo in ipairs(tTable) do
        if tInfo.szFilePath == szFilePath then
            nTargetIndex = i
            break
        end
    end

    --swap target
    if nTargetIndex ~= 0 then
        local tTarget = tTable[nTargetIndex]
        table.remove(tTable, nTargetIndex)
        table.insert(tTarget.tList, nSoundID)
        table.insert(tTable, 1, tTarget)
        tTarget.lastTime = os.time()
    else
        --add new target 
        local lastTime = os.time()
        local tTarget = {szFilePath = szFilePath, lastTime = lastTime, szEffectType = szEffectType, tList = {nSoundID,}}
        table.insert(tTable, 1, tTarget)
    end
end

function KSound.getRandomRange(nTalkID)
    local nStartID, nEndID = 0, 0
    if not nTalkID then return nStartID, nEndID end
    if nTalkID >= KSound.TALK.COMMAND1 and nTalkID <= KSound.TALK.COMMAND3 then
        nStartID, nEndID = KSound.TALK.COMMAND1, KSound.TALK.COMMAND3
    elseif nTalkID >= KSound.TALK.FIRE1 and nTalkID <= KSound.TALK.FIRE2 then
        nStartID, nEndID = KSound.TALK.FIRE1, KSound.TALK.FIRE2
    elseif nTalkID >= KSound.TALK.SMALLBREAK1 and nTalkID <= KSound.TALK.SMALLBREAK2 then
        nStartID, nEndID = KSound.TALK.SMALLBREAK1, KSound.TALK.SMALLBREAK2
    end
    return nStartID, nEndID
end

function KSound.getEffectVolume()
    local setting = require("src/logic/KSetting")
    local volume  = setting.getInt(setting.Key.EFFECT_VOLUME, -1)
    if volume == -1 then volume = m_nEffectDefault * 100 end
    return volume/100
end

function KSound.getMusicVolume()
    local setting = require("src/logic/KSetting")
    local volume  = setting.getInt(setting.Key.MUSIC_VOLUME, -1)
    if volume == -1 then volume = m_nMusicDefault * 100 end
    return volume/100
end

function KSound.setEffectVolume(percent)
    if percent > 100 then percent = 100 end
    if percent < 0 then percent = 0 end
    local setting = require("src/logic/KSetting")
    setting.setInt(setting.Key.EFFECT_VOLUME, percent)
    AudioEngine.setEffectsVolume(percent/100)
end

function KSound.setMusicVolume(percent)
    if percent > 100 then percent = 100 end
    if percent < 0 then percent = 0 end
    local setting = require("src/logic/KSetting")
    setting.setInt(setting.Key.MUSIC_VOLUME, percent)
    AudioEngine.setMusicVolume(percent/100)
end

function KSound.resetLastMusic()
    m_lastMusicName = ""
end

function KSound.playBattleMusic(szMusic, isEnter)
    if not (szMusic and string.len(szMusic) > 0) then
        return
    end
    if isEnter then
        KSound.resetLastMusic()
    end

    if m_lastMusicName == szMusic then return end
    KSound.playMusic(szMusic, true)
    m_lastMusicName = szMusic
end