local KStoryPlayControl  = {}

local BlackImagePath = "res/ui/ui_material/guide/black.png"
local RedImagePath = "res/ui/ui_material/guide/black.png"


local DefaultFontSize   = 26
local DefaultFontColor  = cc.c3b(97, 104, 171)
local DefaultImageColor = cc.c3b(255, 255, 255)
local ACTION_TAG        = 10000

local function getActionTag()
    ACTION_TAG = ACTION_TAG + 1
    return ACTION_TAG
end

function KStoryPlayControl.startWithFile(filePath, playNode)
    KStoryPlayControl.mainNode = playNode
    KStoryPlayControl.config = require(filePath)

    KStoryPlayControl.charaList = {}
    KStoryPlayControl.index = 0
    KStoryPlayControl._waitForClickBase = nil
    KStoryPlayControl._dialogFinishNowFunc = nil
    KStoryPlayControl.next()
end

function KStoryPlayControl.next()
    KStoryPlayControl.index = KStoryPlayControl.index + 1
    if KStoryPlayControl.index > #KStoryPlayControl.config then
        local eventDispatch = require("src/logic/KEventDispatchCenter")
        eventDispatch:dispatchEvent(eventDispatch.EventType.UI_STORY_PLAY_END)
        KUtil.closePanel(KStoryPlayControl.mainNode, "StoryPlay", false)
        return
    end

    local config = KStoryPlayControl.config[KStoryPlayControl.index]
    cclog("-----------------> proccessConfig config: %d", KStoryPlayControl.index)
    KStoryPlayControl.proccessConfig(config)
end

function KStoryPlayControl.proccessConfig(config)
    if config.szBackground ~= "" then
        KStoryPlayControl.changeBackground(config.szBackground)
        cclog("-----------------> proccess changeBackground")
    end

    if config.nShakeScreen > 0 then
        KStoryPlayControl.shakeScreen(config.nShakeScreen)
        cclog("-----------------> proccess shakeScreen")
    end

    if config.szShakeChara ~= "" then
        local params = string.split(config.szShakeChara, "|")
        KStoryPlayControl.shakeCharactor(params[1], tonumber(params[2]))
        cclog("-----------------> proccess shakeCharactor")
    end

    if config.nTurnBlackTime > 0 then
        KStoryPlayControl.turnBlack(config.nTurnBlackTime)
        cclog("-----------------> proccess turnBlack")
    end

    if config.nHideBlack > 0 then
        KStoryPlayControl.hideBlack(config.nHideBlack)
        cclog("-----------------> proccess hideBlack")
    end

    if config.nRedBlinkTime > 0 then
        KStoryPlayControl.redBlink(config.nRedBlinkTime)
        cclog("-----------------> proccess redBlink")
    end

    if config.szCreateChara ~= "" then
        local params = string.split(config.szCreateChara, "|")
        KStoryPlayControl.createCharactor(unpack(params))
        cclog("-----------------> proccess createCharactor")
    end

    if config.szMoveChara ~= "" then
        local params = string.split(config.szMoveChara, "|")
        KStoryPlayControl.moveCharactor(unpack(params))
        cclog("-----------------> proccess moveCharactor")
    end

    if config.szRemoveChara ~= "" then
        local params = string.split(config.szRemoveChara, "|")
        KStoryPlayControl.removeCharactor(unpack(params))
        cclog("-----------------> proccess removeCharactor")
    end

    if config.szChangeCharaFace ~= "" then
        local params = string.split(config.szChangeCharaFace, "|")
        KStoryPlayControl.showCharaFace(unpack(params))
        cclog("-----------------> proccess showCharaFace")
    end

    if config.szHighlightChara ~= "" then
        KStoryPlayControl.highlightChara(config.szHighlightChara)
        cclog("-----------------> proccess highlightChara")
    end

    if config.szDialogTitle ~= "" then
        local params = {szTitle = config.szDialogTitle, textConfig = config.lszDialogText}
        KStoryPlayControl.showDialog(params)
        cclog("-----------------> proccess showDialog")
    else
        KStoryPlayControl.hideDialog()
    end

    if config.lszAsideText and #config.lszAsideText > 0 then
        local params = {textConfig = config.lszAsideText}
        KStoryPlayControl.showAside(params)
        cclog("-----------------> proccess showAside")
    else
        KStoryPlayControl.hideAside()
    end

    if config.szSound ~= "" then
        local params = string.split(config.szSound, "|")
        KStoryPlayControl.playSound(params[1], tonumber(params[2]) > 0)
        cclog("-----------------> proccess playSound")
    end

    if config.szTalk ~= "" then
        local params = string.split(config.szTalk, "|")
        KStoryPlayControl.playTalk(tonumber(params[1]), tonumber(params[2]))
        cclog("-----------------> proccess playTalk")
    end

    if config.nWaitSecond > 0 then
        KStoryPlayControl.waitSecond(config.nWaitSecond)
        cclog("-----------------> proccess waitSecond")
    elseif config.bWaitPress then
        KStoryPlayControl.waitPress()
        cclog("-----------------> proccess waitPress")
    else
        KStoryPlayControl.next()
        cclog("-----------------> proccess next without wait")
    end
end

function KStoryPlayControl.createCharactor(path, tag, posX, posY, zOrder, isFade, flip, scale, rotation, alpha)
    print(path, tag, posX, posY, zOrder)
    zOrder = tonumber(zOrder) or 0
    isFade = tonumber(isFade) or 0
    rotation = tonumber(rotation) or 0
    scale  = tonumber(scale) or 1
    alpha  = tonumber(alpha) or 255
    flip = flip or "0:0"
    local flipParam = string.split(flip, ":")
    local flipX = tonumber(flipParam[1]) or 0
    local flipY = tonumber(flipParam[2]) or 0

    local node       = KStoryPlayControl.mainNode:getNewCharaNode()
    local imageChara = node:getChildByName("Image_chara")
    imageChara:loadTexture(path)
    node:setName(tostring(tag))
    node:setVisible(true)

    assert(not KStoryPlayControl.charaList[tag], "tag exist:" .. tag)
    KStoryPlayControl.charaList[tag] = node
    KStoryPlayControl.mainNode:getButtonBase():addChild(node)
    node:setLocalZOrder(zOrder)
    node:stopAllActions()
    node:setPosition(cc.p(posX, posY))

    node:setFlippedX(flipX == 1)
    node:setFlippedY(flipY == 1)
    node:setRotation(rotation)
    node:setScale(scale)
    imageChara:setOpacity(alpha)

    if tonumber(isFade) == 1 then
        imageChara:setOpacity(0)
        imageChara:runAction(cc.FadeIn:create(1))
    end
end

function KStoryPlayControl.removeCharactor(tag)
    local node             = KStoryPlayControl.charaList[tag]
    KStoryPlayControl.charaList[tag] = nil
    node:runAction(cc.FadeOut:create(0.4))
    delayExecute(KStoryPlayControl.mainNode, function ()
        node:removeFromParent()
    end, 0.5)
end

function KStoryPlayControl.moveCharactor(tag, second, posX, posY)
    local node  = KStoryPlayControl.charaList[tag]
    node:runAction(
        cc.MoveTo:create(second, cc.p(posX, posY))
    )
end

function KStoryPlayControl.shakeCharactor(tag, second)
    local node   = KStoryPlayControl.charaList[tag]
    if node then
        KStoryPlayControl.shake(second, node)
    end
end

function KStoryPlayControl.highlightChara(tag)
    if tag ~= "none" then
        for k, v in pairs(KStoryPlayControl.charaList) do
            local imageChara = v:getChildByName("Image_chara")
            if k == tag then
                KUtil.setWidgetNormal(imageChara)
            else
                KUtil.setWidgetDark(imageChara)
            end
        end
    else
        for k, v in pairs(KStoryPlayControl.charaList) do
            local imageChara = v:getChildByName("Image_chara")
            KUtil.setWidgetNormal(imageChara)
        end
    end
end

function KStoryPlayControl.showCharaFace(charaTag, faceName, imagePath)
    local chara = KStoryPlayControl.charaList[charaTag]
    if chara then
        KStoryPlayControl.mainNode:showCharaFace(chara, faceName, imagePath)
    end
end

function KStoryPlayControl.changeBackground(bgPath)
    local buttonBase    = KStoryPlayControl.mainNode:getButtonBase()
    buttonBase:setOpacity(255)
    buttonBase:loadTextures(bgPath, bgPath, bgPath)
end

function KStoryPlayControl.turnBlack(second)
    local topImage = KStoryPlayControl.mainNode:getTopImage()
    topImage:loadTexture(BlackImagePath)
    topImage:setVisible(true)
    topImage:setOpacity(0)
    topImage:runAction(cc.FadeIn:create(second))
end

function KStoryPlayControl.hideBlack(second)
    local topImage = KStoryPlayControl.mainNode:getTopImage()
    topImage:loadTexture(BlackImagePath)
    topImage:runAction(cc.FadeOut:create(second))
    delayExecute(KStoryPlayControl.mainNode, function ()
        topImage:setVisible(false)
    end, second)
end

function KStoryPlayControl.redBlink(second)
    local topImage = KStoryPlayControl.mainNode:getTopImage()
    topImage:loadTexture(RedImagePath)
    topImage:setVisible(true)
    topImage:setOpacity(0)
    
    local repeatAction = cc.RepeatForever:create(
        cc.Sequence:create(
            cc.FadeIn:create(0.5),
            cc.FadeOut:create(0.5)
        )
    )

    topImage:runAction(repeatAction)
    local tag = getActionTag()
    repeatAction:setTag(tag)
    delayExecute(topImage, function ()
        topImage:stopActionByTag(tag)
        topImage:setVisible(false)
    end, second)
end

local function proccessTextConfig(textConfig)
    local richTextConfigTable = {}
    for index, info in ipairs(textConfig) do
        
        if info.text then
            local words   = KUtil.splitChinese(info.text)
            local color   = info.color and cc.c3b(unpack(info.color)) or DefaultFontColor
            local size    = info.size or DefaultFontSize
            for _, word in ipairs(words) do
                table.insert(richTextConfigTable, {color = color, fontSize = size, text = word.word, font = info.font})
            end
        elseif info.image then
            local color   = info.color and cc.c3b(unpack(info.color)) or DefaultImageColor
            table.insert(richTextConfigTable, {color = color, fontSize = size, image = info.image, font = info.font})
        elseif info.newline then
            local color   = info.color and cc.c3b(unpack(info.color)) or DefaultFontColor
            local size    = info.size or DefaultFontSize
            table.insert(richTextConfigTable, {color = color, fontSize = size, newline = true, font = info.font})
        end
    end

    return richTextConfigTable
end

local function playRichText(node, textConfig, posX, posY)
    local arrow          = node:getChildByName("ProjectNode_arrow")
    local speed          = 0.2
    local words          = proccessTextConfig(textConfig)
    local wordCount      = #words
    local wordIndex      = 0
    local isEnd 

    local nodeRichText   = node:getChildByName("richText")
    if nodeRichText then
        node:removeChild(nodeRichText)
    end

    local richText = ccui.RichText:create()
    richText:setName("richText")
    richText:ignoreContentAdaptWithSize(false)
    richText:setVerticalSpace(0)
    richText:setAnchorPoint(cc.p(0, 1))
    richText:setContentSize(900, 0)
    richText:setPosition(posX, posY)
    node:addChild(richText, 10)

    local function appendOneWord(index, formatNow)
        KUtil.setRichItemList(richText, {[1] = words[index]}, 25)
        if formatNow then
            richText:formatText()
        end

        local newWidth = richText:getContentSize().width
        richText:setPosition(posX - newWidth / 2, posY)
    end

    local function setString()
        wordIndex = wordIndex + 1
        appendOneWord(wordIndex)
        
        if isEnd or (wordIndex >= wordCount) then
            isEnd = true
            if arrow then
                arrow:setVisible(true)
            end
            node:stopAllActions()
            KStoryPlayControl._dialogFinishNowFunc = nil
        end
    end

    KStoryPlayControl._dialogFinishNowFunc = function ()
        isEnd = true
        if arrow then
            arrow:setVisible(true)
        end
        node:stopAllActions()
        for i = wordIndex + 1, wordCount, 1 do
            appendOneWord(i, i == wordCount)
        end
    end

    node:runAction(
        cc.RepeatForever:create(
            cc.Sequence:create(cc.CallFunc:create(setString), 
            cc.DelayTime:create(speed)
        )
    ))
end

function KStoryPlayControl.showDialog(dialogConfig)
    local title       = dialogConfig.szTitle

    local dialog      = KStoryPlayControl.mainNode:getDialog()
    local textName    = dialog:getChildByName("Text_name")
    local label1      = dialog:getChildByName("BitmapFontLabel_dialogue")
    local arrow       = dialog:getChildByName("ProjectNode_arrow")

    textName:setString(title)
    label1:setString("")
    arrow:setVisible(false)
    dialog:setVisible(true)

    playRichText(dialog, dialogConfig.textConfig, label1:getPositionX(), label1:getPositionY())
end

function KStoryPlayControl.hideDialog()
    KStoryPlayControl.mainNode:hideDialog()
end

function KStoryPlayControl.showAside(asideConfig)
    local aside       = KStoryPlayControl.mainNode:getAside()
    local viewSize    = cc.Director:getInstance():getWinSize()
    aside:setVisible(true)
    aside:setOpacity(0)
    aside:runAction(cc.FadeIn:create(1))
    delayExecute(aside, function ()
        playRichText(aside, asideConfig.textConfig, viewSize.width * 0.4, viewSize.height * 0.75)
    end, 1)
end

function KStoryPlayControl.hideAside()
    KStoryPlayControl.mainNode:hideAside()
end

function KStoryPlayControl.waitSecond(second)
    delayExecute(KStoryPlayControl.mainNode, function ()
        KStoryPlayControl.next()
    end, second)
end

function KStoryPlayControl.playSound(soundName, isLoop)
    KSound.playMusic(soundName, isLoop)
end

function KStoryPlayControl.playTalk(talkID, cardID)
    KSound.playTalk(talkID, cardID)
end

function KStoryPlayControl.shakeScreen(second)
    KStoryPlayControl.shake(second, KStoryPlayControl.mainNode)
end

function KStoryPlayControl.shake(second, node)
    local posX, posY    = node:getPositionX(), node:getPositionY()
    local repeatAction  = cc.RepeatForever:create(
                            cc.Sequence:create(
                                cc.MoveTo:create(0.03, cc.p(posX + math.random(-30, 0), posY + math.random(-30, 0))),
                                cc.MoveTo:create(0.03, cc.p(posX + math.random(0, 30), posY + math.random(0, 30))),
                                cc.MoveTo:create(0.04, cc.p(posX + math.random(-10, 10), posY - math.random(-10, 10)))
                            )
                        )
    node:runAction(repeatAction)
    local tag = getActionTag()
    repeatAction:setTag(tag)
    delayExecute(node, function ()
        node:stopActionByTag(tag)
        node:setPosition(posX, posY)
    end, second)
end

function KStoryPlayControl.waitPress()
    KStoryPlayControl._waitForClickBase = true
end

function KStoryPlayControl.onClickBase()
    if KStoryPlayControl._dialogFinishNowFunc then
        local func = KStoryPlayControl._dialogFinishNowFunc
        KStoryPlayControl._dialogFinishNowFunc = nil
        func()
    elseif KStoryPlayControl._waitForClickBase then
        KStoryPlayControl._waitForClickBase = nil
        KStoryPlayControl.next()
    end
end

return KStoryPlayControl