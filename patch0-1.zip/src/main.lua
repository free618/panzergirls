--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : main.lua
--  Creator     : SunXun
--  Date        : 2015/07/10   10:38
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


-- CC_USE_DEPRECATED_API = true
require "cocos.init"

-- Load Global Function
require "src/base/KGlobalFunction"
require "src/version"

math.randomseed(os.time())

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
	cclog("----------------------------------------")
	cclog("LUA ERROR: " .. tostring(msg) .. "\n")
	local stackInfo = getStackInfo(3)
	-- cclog(stackInfo)
	cclog("2---------------------------------------")

	local targetPlatform = cc.Application:getInstance():getTargetPlatform()
	if targetPlatform == cc.PLATFORM_OS_WINDOWS or
		targetPlatform == cc.PLATFORM_OS_LINUX or
		targetPlatform == cc.PLATFORM_OS_MAC or 
		(KUtil and KUtil.isGuide()) then
		--tryShowError(msg, stackInfo)
	end

	-- send error msg to server
	sendErrorMsg(msg, stackInfo)

	return msg
end
--[[  
--=================  
--XMLHttpRequestTest.lua  
--http请求  
--=================  
--]]--  
require("json")  

local function XMLHttpRequestLayer()  
	local layer = cc.Layer:create()-- 创建层  
	local winSize = cc.Director:getInstance():getWinSize()-- 得到窗口大小  
	local margin = 40-- 间距  
	local space  = 35-- 宽度  

	local function init()  
		local label = cc.LabelTTF:create("XML Http Request Test", "Arial", 28)-- 使用ttf文字格式的标签  
		label:setAnchorPoint(cc.p(0.5, 0.5))-- 设置锚点  
		label:setPosition(cc.p(winSize.width / 2, winSize.height - margin))-- 设置显示位置，宽度为屏幕的中间，高度为屏幕高度减去间距  
		layer:addChild(label, 0) -- 添加标签到层中  

		-- 显示返回码的标签  
		local labelStatusCode = cc.LabelTTF:create("HTTP Status Code", "Arial", 20)  
		labelStatusCode:setAnchorPoint(cc.p(0.5, 0.5))  
		labelStatusCode:setPosition(cc.p(winSize.width / 2,  winSize.height - margin - 6 * space))  
		layer:addChild(labelStatusCode)  

		local menuRequest = cc.Menu:create() -- 创建菜单  
		menuRequest:setPosition(cc.p(0,0))  
		layer:addChild(menuRequest) -- 添加菜单  

		--Get  
		local function onMenuGetClicked()  
			local xhr = cc.XMLHttpRequest:new() -- http请求  
			--xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING -- 响应类型  
			--local url = "https://github.com/free618/panzergirls/files/577540/newestverion.txt"
			local url = "https://github.com/free618/panzergirls/files/573117/59.zip"
			xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_ARRAY_BUFFER
			--xhr:open("GET", "http://httpbin.org/get") -- 打开链接  
			xhr:open("GET", url)

			-- 状态改变时调用  
			local function onReadyStateChange(...)  
				-- 显示状态文本  
				local statusString = "Http Status Code:"..xhr.statusText  
				print ("status:", statusString)
				labelStatusCode:setString(statusString)  
				print(xhr.response)  
			end  

			-- 注册脚本回调方法  
			xhr:registerScriptHandler(onReadyStateChange)  
			xhr:send() -- 发送请求  

			labelStatusCode:setString("waiting...")  
		end  

		-- 测试Get的标签  
		local labelGet  = cc.LabelTTF:create("Test Get", "Arial", 22)  
		labelGet:setAnchorPoint(cc.p(0.5, 0.5))  
		local itemGet  =  cc.MenuItemLabel:create(labelGet) -- 菜单标签  
		itemGet:registerScriptTapHandler(onMenuGetClicked) -- 菜单点击事件  
		itemGet:setPosition(cc.p(winSize.width / 2, winSize.height - margin - space))  
		menuRequest:addChild(itemGet) -- 添加菜单项  

		--Post  
		local function onMenuPostClicked()  
			local xhr = cc.XMLHttpRequest:new() -- 新建一个XMLHttpRequest对象  
			xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING -- 相应类型为字符串  
			xhr:open("POST", "http://httpbin.org/post")-- post方式  
			local function onReadyStateChange()  
				labelStatusCode:setString("Http Status Code:"..xhr.statusText)  
				print(xhr.response)  
			end  
			-- 注册脚本方法回调  
			xhr:registerScriptHandler(onReadyStateChange)  
			xhr:send()-- 发送  

			labelStatusCode:setString("waiting...")  
		end  

		-- 测试Post的标签  
		local labelPost = cc.LabelTTF:create("Test Post", "Arial", 22)  
		labelPost:setAnchorPoint(cc.p(0.5, 0.5)) -- 设置锚点  
		local itemPost =  cc.MenuItemLabel:create(labelPost) -- 设置菜单项标签  
		itemPost:registerScriptTapHandler(onMenuPostClicked) -- 注册菜单项点击回调方法  
		itemPost:setPosition(cc.p(winSize.width / 2, winSize.height - margin - 2 * space))  
		menuRequest:addChild(itemPost)  

		--Post Binary  
		local function onMenuPostBinaryClicked()  
			local xhr = cc.XMLHttpRequest:new()-- 新建一个XMLHttpRequest对象  
			xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_ARRAY_BUFFER --返回数据为字节流  
			xhr:open("POST", "http://httpbin.org/post") -- 打开Socket  

			-- 状态改变时调用  
			local function onReadyStateChange()  
				local response   = xhr.response -- 获得返回数据  
				local size     = table.getn(response) -- 获得返回数据大小  
				local strInfo = ""  

				for i = 1,size do  
					if 0 == response[i] then  
						strInfo = strInfo.."\'\\0\'"  
					else  
						strInfo = strInfo..string.char(response[i])  
					end  
				end  
				labelStatusCode:setString("Http Status Code:"..xhr.statusText)  
				print(strInfo)  
			end  

			-- 注册脚本方法回调  
			xhr:registerScriptHandler(onReadyStateChange)  
			xhr:send()-- 发送  

			labelStatusCode:setString("waiting...")  
		end  

		-- 测试使用Post请求方式发送字节流  
		local labelPostBinary = cc.LabelTTF:create("Test Post Binary", "Arial", 22)  
		labelPostBinary:setAnchorPoint(cc.p(0.5, 0.5))  
		local itemPostBinary = cc.MenuItemLabel:create(labelPostBinary)  
		itemPostBinary:registerScriptTapHandler(onMenuPostBinaryClicked)  
		itemPostBinary:setPosition(cc.p(winSize.width / 2, winSize.height - margin - 3 * space))  
		menuRequest:addChild(itemPostBinary)  

		--Post Json  
		local function onMenuPostJsonClicked()  
			local xhr = cc.XMLHttpRequest:new() -- 新建一个XMLHttpRequest对象  
			xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON -- json数据类型  
			xhr:open("POST", "http://httpbin.org/post")-- POST方式  

			local function onReadyStateChange()  
				-- 显示状态码,成功显示200  
				labelStatusCode:setString("Http Status Code:"..xhr.statusText)  
				local response   = xhr.response -- 获得响应数据  
				local output = json.decode(response,1) -- 解析json数据  
				table.foreach(output,function(i, v) print (i, v) end)  
				print("headers are")  
				table.foreach(output.headers,print)  
			end  

			-- 注册脚本方法回调  
			xhr:registerScriptHandler(onReadyStateChange)  
			xhr:send()-- 发送请求  

			labelStatusCode:setString("waiting...")  
		end  

		-- 测试使用POST方式发送json的标签  
		local labelPostJson = cc.LabelTTF:create("Test Post Json", "Arial", 22)  
		labelPostJson:setAnchorPoint(cc.p(0.5, 0.5)) -- 锚点  
		local itemPostJson = cc.MenuItemLabel:create(labelPostJson) -- 菜单项标签  
		itemPostJson:registerScriptTapHandler(onMenuPostJsonClicked) -- 注册菜单项点击  
		itemPostJson:setPosition(cc.p(winSize.width / 2, winSize.height - margin - 4 * space))  
		menuRequest:addChild(itemPostJson)  
	end  


	-- 节点回调事件  
	local function onNodeEvent(eventName)  
		if "enter" == eventName then  
			init()  
		end  
	end  

	-- 注册层的监听回调事件  
	layer:registerScriptHandler(onNodeEvent)  

	return layer  
end  

function XMLHttpRequestTestMain()  
	local scene = cc.Scene:create() -- 创建场景  
	scene:addChild(XMLHttpRequestLayer()) -- 添加层  
	return scene  
end  

local function main()
	collectgarbage("collect")
	-- avoid memory leak
	collectgarbage("setpause", 100)
	collectgarbage("setstepmul", 5000)

	local director = cc.Director:getInstance()
	cc.Device:setKeepScreenOn(true)
	director:setDisplayStats(false)
	director:setAnimationInterval(1.0 / 60)
	cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(1280, 720, cc.ResolutionPolicy.EXACT_FIT)

	-- cc.Director:getInstance():getScheduler():setTimeScale(0.4)
	local isAutoUpdate = false -- auto update flag
	if C_AsyncDownloadFile and UPDATE_V2_ENABLE then
		--isAutoUpdate = true
		local targetPlatform = cc.Application:getInstance():getTargetPlatform()
		if targetPlatform ~= cc.PLATFORM_OS_WINDOWS and 
			targetPlatform ~= cc.PLATFORM_OS_LINUX and
			targetPlatform ~= cc.PLATFORM_OS_MAC then
			isAutoUpdate = true -- close auto updte for Full Client
		end 
	end

	isAutoUpdate = true
	if not isAutoUpdate then
		local gameScene = require("src/ui/login/KUILoginScene").create()
		--local gameScene = XMLHttpRequestTestMain() 
		if cc.Director:getInstance():getRunningScene() then
			cc.Director:getInstance():replaceScene(gameScene)
		else
			cc.Director:getInstance():runWithScene(gameScene)
		end
	else
		require("src/ui/login/KUILoginUpdateNode")
		addUpdateScene()
	end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
	error(msg)
end
