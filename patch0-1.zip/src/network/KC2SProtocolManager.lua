--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KC2SProtocolManager.lua
--  Creator     : SunXun
--  Date        : 2015/07/14   09:56
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


local KC2SProtocolManager = {}

function KC2SProtocolManager:applyChooseInitCard(cardIndex)
    cclog("--------------------> KC2SProtocolManager:applyChooseInitCard cardIndex:%d", cardIndex)
    return KGameServer:SendToGS("ApplyChooseInitCard", cardIndex)
end

function KC2SProtocolManager:applyRename(newName)
    cclog("--------------------> KC2SProtocolManager:applyRename newName:%s", newName)
    return KGameServer:SendToGS("ApplyRename", newName)
end

function KC2SProtocolManager:produceCard(nIndex, nOil, nAmmo, nSteel, nPeople)
    cclog("--------------------> KC2SProtocolManager:applyRename newName:%d,%d,%d,%d,%d", nIndex, nOil, nAmmo, nSteel, nPeople)
    return KGameServer:SendToGS("ProduceCard", nIndex, nOil, nAmmo, nSteel, nPeople)
end

function KC2SProtocolManager:finishProducingCardByCostItem(nIndex)
    cclog("--------------------> KC2SProtocolManager:finishProducingCardByCostItem card_id:%d", nIndex)
    return KGameServer:SendToGS("FinishProducingCardByCostItem", nIndex)
end

function KC2SProtocolManager:getProducedCard(nIndex)
    cclog("--------------------> KC2SProtocolManager:getProducedCard card_id:%d", nIndex)
    return KGameServer:SendToGS("GetProducedCard", nIndex)
end

function KC2SProtocolManager:breakDownCard(nCardID)
    return KGameServer:SendToGS("BreakDownCard", nCardID)
end

function KC2SProtocolManager:breakDownCardList(arrayCardID, isUnloadingEquipment)
    return KGameServer:SendToGS("BreakDownCardList", arrayCardID, isUnloadingEquipment)
end

function KC2SProtocolManager:repairCard(nCardID,nRepairPosition)
    return KGameServer:SendToGS("RepairCard", nCardID ,nRepairPosition)
end

function KC2SProtocolManager:FinishRepairCard(nCardID)
    return KGameServer:SendToGS("FinishRepairCard", nCardID)
end

function KC2SProtocolManager:FinishRepairCardingByCostItem(nCardID)
    return KGameServer:SendToGS("FinishRepairCardingByCostItem", nCardID)
end

function KC2SProtocolManager:quickRepairCard(nCardID)
    return KGameServer:SendToGS("QuickRepairCard", nCardID)
end

function KC2SProtocolManager:quickRepairAllCard(nTeamID)
    return KGameServer:SendToGS("QuickRepairAllCard", nTeamID)
end

function KC2SProtocolManager:supplyCard(nCardID)
    return KGameServer:SendToGS("SupplyCard", nCardID)
end

function KC2SProtocolManager:supplyTeam(nTeamID, bSupplySkill)
    return KGameServer:SendToGS("SupplyTeam", nTeamID, bSupplySkill)
end

function KC2SProtocolManager:rebornCardByCostItem(nCardID)
    return KGameServer:SendToGS("RebornCardByCostItem", nCardID)
end

function KC2SProtocolManager:rebornCardByCostCoin(nCardID)
    return KGameServer:SendToGS("RebornCardByCostCoin", nCardID)
end

function KC2SProtocolManager:lockCard(nCardID, bLock)
    return KGameServer:SendToGS("LockCard", nCardID, bLock)
end

function KC2SProtocolManager:produceEquip(nOil, nAmmo, nSteel, nPeople)
    return KGameServer:SendToGS("ProduceEquip", nOil, nAmmo, nSteel, nPeople)
end

function KC2SProtocolManager:getProducedEquip(nItemID)
    return KGameServer:SendToGS("GetProducedEquip", nItemID)
end

function KC2SProtocolManager:breakDownEquip(nItemID)
    return KGameServer:SendToGS("BreakDownEquip", nItemID)
end

function KC2SProtocolManager:breakDownEquipList(tEquipIDList)
    return KGameServer:SendToGS("BreakDownEquipList", tEquipIDList)
end

function KC2SProtocolManager:cardEnterTeam(nCardID, nTeamIndex, nPos)
    return KGameServer:SendToGS("CardEnterTeam", nCardID, nTeamIndex, nPos)
end

function KC2SProtocolManager:cardLeaveTeam(nCardID)
    return KGameServer:SendToGS("CardLeaveTeam", nCardID)
end

function KC2SProtocolManager:saveRecordTeam(nTeamIndex, nRecordIndex)
    return KGameServer:SendToGS("SaveRecordTeam", nTeamIndex, nRecordIndex)
end

function KC2SProtocolManager:useRecordTeam(nTeamIndex, nRecordIndex)
    return KGameServer:SendToGS("UseRecordTeam", nTeamIndex, nRecordIndex)
end

function KC2SProtocolManager:changeCardEquip(nCardID, nEquipID, nPos)
    return KGameServer:SendToGS("ChangeCardEquip", nCardID, nEquipID, nPos)
end

function KC2SProtocolManager:addCardEquip(nCardID, nEquipID, nPos)
    return KGameServer:SendToGS("AddCardEquip", nCardID, nEquipID, nPos)
end

function KC2SProtocolManager:unloadCardEquip(nCardID, nPos)
    return KGameServer:SendToGS("UnloadCardEquip", nCardID, nPos)
end

function KC2SProtocolManager:getExpeditionReward(nType, nTemplateID)
    return KGameServer:SendToGS("GetExpeditionReward", nType, nTemplateID)
end

function KC2SProtocolManager:joinExpeditionMission(nType, nTemplateID, nTeamID)
    return KGameServer:SendToGS("JoinExpeditionMission", nType, nTemplateID, nTeamID)
end

function KC2SProtocolManager:cancelExpeditionMission(nType, nTemplateID)
    return KGameServer:SendToGS("CancelExpeditionMission", nType, nTemplateID)
end

function KC2SProtocolManager:requestPlunderExpeditionList(bIsRelaod)
    return KGameServer:SendToGS("RequestPlunderExpeditionList", bIsRelaod)
end

function KC2SProtocolManager:requestExpeditionBattleData(nBattleRoleID, nExpeditionType, nExpeditionID)
    return KGameServer:SendToGS("RequestExpeditionBattleData", nBattleRoleID, nExpeditionType, nExpeditionID)
end

function KC2SProtocolManager:requestExpeditionFinishBattle(...)
    return KGameServer:SendToGS("RequestExpeditionFinishBattle", ...)
end

function KC2SProtocolManager:strengthenCard(nCardID, nConsumeCardID)
    if not KUtil.getCardById(nConsumeCardID) then
        KPlayer:ErrorRespond(ERROR_CODE.STRENG_COST_CARD_NOT_EXIST)
        return
    end
    return KGameServer:SendToGS("StrengthenCard", nCardID, nConsumeCardID)
end

function KC2SProtocolManager:dispatchEvent(eventType, ...)
    return KGameServer:SendToGS("DispatchEvent", eventType, ...)
end

function KC2SProtocolManager:getMissionReward(nMissionID)
    return KGameServer:SendToGS("GetMissionReward", nMissionID)
end

function KC2SProtocolManager:updateGuide(nGuideIndex, szName, nNextGuideIndex, ...)
	return KGameServer:SendToGS("UpdateGuide", nGuideIndex, szName, nNextGuideIndex, ...)
end

function KC2SProtocolManager:convertCard(nCardID)
    return KGameServer:SendToGS("ConvertCard", nCardID)
end

function KC2SProtocolManager:buyCoin(nGoodID)
    return KGameServer:SendToGS("BuyCoin", nGoodID)
end

function KC2SProtocolManager:buyGood(nGoodID, nBuyCount)
    return KGameServer:SendToGS("BuyGood", nGoodID, nBuyCount)
end

function KC2SProtocolManager:BuySkin(nGoodID)
    return KGameServer:SendToGS("BuySkin", nGoodID)
end

function KC2SProtocolManager:useItem(nItemTemplateID, szData)
    return KGameServer:SendToGS("UseItem", nItemTemplateID, szData)
end

function KC2SProtocolManager:StartBattleCostResouce(...)
    return KGameServer:SendToGS("StartBattleCostResouce", ...)
end

function KC2SProtocolManager:StartNightBattleCostResouce(...)
    return KGameServer:SendToGS("StartNightBattleCostResouce", ...)
end

function KC2SProtocolManager:BattleCardDead(...)
    return KGameServer:SendToGS("BattleCardDead", ...)
end

function KC2SProtocolManager:FinishBattle(...)
    return KGameServer:SendToGS("FinishBattle", ...)
end

function KC2SProtocolManager:finishExerciseBattle(...)
    return KGameServer:SendToGS("FinishExerciseBattle", ...)
end

function KC2SProtocolManager:addRoleActivityRecord(szName, szSubName)
    return KGameServer:SendToGS("AddRoleActivityRecord", szName, szSubName)
end

function KC2SProtocolManager:addPanelStayRecord(szName, nType)
    return KGameServer:SendToGS("AddPanelStayRecord", szName, nType)
end

function KC2SProtocolManager:AddPlayerExp(addExp, strComment)
    return KGameServer:SendToGS("AddPlayerExp", addExp, strComment)
end

function KC2SProtocolManager:recordClientErrorMsg(szMsg, szStackInfo)
    return KGameServer:SendToGS("RecordClientErrorMsg", szMsg, szStackInfo)
end

function KC2SProtocolManager:ExpandBar(type)
    return KGameServer:SendToGS("ExpandBar", type)
end

function KC2SProtocolManager:ExpandBarByCoin(type)
    return KGameServer:SendToGS("ExpandBarByCoin", type)
end

function KC2SProtocolManager:requestRoleRankData()
    return KGameServer:SendToGS("RequestRoleRankData")
end

function KC2SProtocolManager:requestGetRankReward()
    return KGameServer:SendToGS("RequestGetRankReward")
end

function KC2SProtocolManager:requestRankPageData(nPageIndex, nPageSize)
    return KGameServer:SendToGS("RequestRankPageData", nPageIndex, nPageSize)
end

function KC2SProtocolManager:requestUpdateRankMessage(szMessage)
    return KGameServer:SendToGS("RequestUpdateRankMessage", szMessage)
end

function KC2SProtocolManager:GMCommand(szCommand)
    return KGameServer:SendToGS("GMCommand", szCommand)
end

function KC2SProtocolManager:requestCardLogPageData(nID, nPageSize, nTabType, nStarBegin, nStarEnd)
    return KGameServer:SendToGS("RequestCardLogPageData", nID, nPageSize, nTabType, nStarBegin, nStarEnd)
end

function KC2SProtocolManager:requestEquipLogPageData(nID, nPageSize, nTabType, nStarBegin, nStarEnd)
    return KGameServer:SendToGS("RequestEquipLogPageData", nID, nPageSize, nTabType, nStarBegin, nStarEnd)
end

function KC2SProtocolManager:getCardCollectLogList()
    return KGameServer:SendToGS("GetCardCollectLogList")
end

function KC2SProtocolManager:getEquipCollectLogList()
    return KGameServer:SendToGS("GetEquipCollectLogList")
end

function KC2SProtocolManager:addCardCollectLog(nID, nTemplateID, szName, nRoleID, nOil, nAmmo, nSteel, nPeople)
    return KGameServer:SendToGS("AddCardCollectLog", nID, nTemplateID, szName, nRoleID, nOil, nAmmo, nSteel, nPeople)
end

function KC2SProtocolManager:addEquipCollectLog(nID, nTemplateID, szName, nRoleID, nOil, nAmmo, nSteel, nPeople)
    return KGameServer:SendToGS("AddEquipCollectLog", nID, nTemplateID, szName, nRoleID, nOil, nAmmo, nSteel, nPeople)
end

function KC2SProtocolManager:removeCardCollectLog(nID)
    return KGameServer:SendToGS("RemoveCardCollectLog", nID)
end

function KC2SProtocolManager:removeEquipCollectLog(nID)
    return KGameServer:SendToGS("RemoveEquipCollectLog", nID)
end

function KC2SProtocolManager:teamRename(nTeamIndex, szName)
    return KGameServer:SendToGS("TeamRename", nTeamIndex, szName)
end

function KC2SProtocolManager:lockEquip(nEquipID, bLock)
    return KGameServer:SendToGS("LockEquip", nEquipID, bLock)
end

function KC2SProtocolManager:sign(nCount, ...)
    return KGameServer:SendToGS("Sign", nCount, ...)
end

function KC2SProtocolManager:getAnnounceInfo(nVersion)
    return KGameServer:SendToGS("GetAnnounceInfo", nVersion)
end

function KC2SProtocolManager:changeRoleFurniture(nTemplateID)
    return KGameServer:SendToGS("ChangeRoleFurniture", nTemplateID)
end

function KC2SProtocolManager:buyFurniture(nTemplateID)
    return KGameServer:SendToGS("BuyFurniture", nTemplateID)
end

function KC2SProtocolManager:exchangeCode(szCode)
    print("KC2SProtocolManager:exchangeCode------------------", szCode)
    return KGameServer:SendToGS("ExchangeCode", szCode)
end

function KC2SProtocolManager:requestMailData(tMailIDList)
    return KGameServer:SendToGS("RequestMailData", tMailIDList)
end

function KC2SProtocolManager:requestOpenMail(nID)
    return KGameServer:SendToGS("RequestOpenMail", nID)
end

function KC2SProtocolManager:requestGetMailReward(nID)
    return KGameServer:SendToGS("RequestGetMailReward", nID)
end

function KC2SProtocolManager:requestRemoveMailList(tMailIDList)
    return KGameServer:SendToGS("RequestRemoveMailList", tMailIDList) 
end

function KC2SProtocolManager:SendPrivateMessage(szDstRoleName, szMessage)
    return KGameServer:SendToGS("SendPrivateMessage", szDstRoleName, szMessage)
end

function KC2SProtocolManager:SendGlobalMessage(szMessage, num)
    return KGameServer:SendToGS("SendGlobalMessage", szMessage, num)
end

function KC2SProtocolManager:wearMarriageRing(nCardID)
    return KGameServer:SendToGS("WearMarriageRing", nCardID)
end

function KC2SProtocolManager:addFeelingByItem(nCardID, nTemplateID)
    return KGameServer:SendToGS("AddFeelingByItem", nCardID, nTemplateID)
end

function KC2SProtocolManager:requestExerciseRoleList()
    return KGameServer:SendToGS("RequestExerciseRoleList")
end

function KC2SProtocolManager:selectMapDifficult(nZoneID, nMapID, nDifficult)
    return KGameServer:SendToGS("SelectMapDifficult", nZoneID, nMapID, nDifficult)
end

function KC2SProtocolManager:LockCardList(tCardLockList)
    return KGameServer:SendToGS("LockCardList", tCardLockList)
end

function KC2SProtocolManager:addCardMountItem(nCardID, nItemTemplateID)
    return KGameServer:SendToGS("AddCardMountItem", nCardID, nItemTemplateID)
end

function KC2SProtocolManager:unloadCardMountItem(nCardID)
    return KGameServer:SendToGS("UnloadCardMountItem", nCardID)
end

function KC2SProtocolManager:useCardMountItem(nCardID)
    return KGameServer:SendToGS("UseCardMountItem", nCardID)
end

function KC2SProtocolManager:syncBattleCardLostHP(nCardID, nCurrentHP)
    return KGameServer:SendToGS("SyncBattleCardLostHP", nCardID, nCurrentHP)
end

function KC2SProtocolManager:Cook(nCookType)
    return KGameServer:SendToGS("Cook", nCookType)
end

function KC2SProtocolManager:skillEnterRole( nEquipID, nPos)
    return KGameServer:SendToGS("SkillEnterRole",  nEquipID, nPos)
end

function KC2SProtocolManager:requestCardRankData()
    return KGameServer:SendToGS("RequestCardRankData")
end

function KC2SProtocolManager:changeSecretary(nCardID, nType, nState)
    return KGameServer:SendToGS("ChangeSecretary", nCardID, nType, nState)
end

function KC2SProtocolManager:UseSkin(nCardID, nSkinID)
    return KGameServer:SendToGS("UseSkin", nCardID, nSkinID)
end

function KC2SProtocolManager:SPSign()
    return KGameServer:SendToGS("SPSign")
end

function KC2SProtocolManager:GenerateName()
    return KGameServer:SendToGS("GenerateName")
end

function KC2SProtocolManager:addRegisterStageReocrd(szComment, nCardID)
    return KGameServer:SendToGS("AddRegisterStageReocrd", szComment, nCardID)
end

function KC2SProtocolManager:requestServerTime()
    return KGameServer:SendToGS("RequestServerTime")
end

function KC2SProtocolManager:GainStoryReward(storyID)
    return KGameServer:SendToGS("GainStoryReward", storyID)
end

function KC2SProtocolManager:UseSkill(nEquipID, nUseCount)
    return KGameServer:SendToGS("UseSkill", nEquipID, nUseCount)
end

function KC2SProtocolManager:SupplyTeamInBattle(tDataToSync)
    return KGameServer:SendToGS("SupplyTeamInBattle", tDataToSync)
end

function KC2SProtocolManager:RepairCardInBattle(nCardID, nCurrentHP)
    return KGameServer:SendToGS("RepairCardInBattle", nCardID, nCurrentHP)
end

function KC2SProtocolManager:requestExerciseRoleDetail(nBattleRoleID)
    return KGameServer:SendToGS("RequestExerciseRoleDetail", nBattleRoleID)
end

function KC2SProtocolManager:requestCardTraining(nCardID, nWarID)
    return KGameServer:SendToGS("RequestCardTraining", nCardID, nWarID)
end

function KC2SProtocolManager:IOSPayVerify(strReceiptData)
    return KGameServer:SendToGS("IOSPayVerify", strReceiptData)
end

return KC2SProtocolManager
