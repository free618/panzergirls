--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KGameServer.lua
--  Creator     : SunXun
--  Date        : 2015/07/10   11:29
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************

KGameServer = KGameServer or {}

local STATE_INVALID = 0
local STATE_LS_CONNECTING = 1
local STATE_LS_CONNECTED = 2
local STATE_LS_HANDSHAKE_FAIL = 3
local STATE_LS_HANDSHAKE_SUCCESS = 4
local STATE_LS_VERIFYING = 5
local STATE_LS_VERIFIED = 6
local STATE_LS_WAIT_ACTIVATE = 7
local STATE_LS_ACTIVATEING = 8
local STATE_LS_REQUESTING_ENTERSERVER = 9
local STATE_LS_END = 10
local STATE_BS_CONNECTING = 11
local STATE_BS_CONNECTED = 12
local STATE_BS_VERIFYING = 13
local STATE_BS_VERIFIED = 14
local STATE_BS_PLALYING = 15

local BEGIN_SHOW_SENDING_UI_SECONDS = 2
local MAX_RE_REQUEST_SECONDS = 60

local PING_CYCLE = 60
local PING_TIMEOUT = 180

local m_nShowSendingUITime = nil
local m_nHideSendingUITime = nil

local m_nState = STATE_INVALID
local m_bEnableAutoReconnect = false
local m_nServerID, m_tServerList

local m_szLSIP, m_nLSPort = unpack(require("src/network/KServerAddress"))
local m_tLS2CLProcessor = {}
local m_tLSAgency       = New(SHTcpClient, "LSAgency", m_szLSIP, m_nLSPort)

local m_tBS2CLProcessor = {}
local m_tBSAgency       = New(SHTcpClient, "BSAgency")

local m_nRequestID      = 0
local m_nRespondID      = 0

local m_nLastFrameTime = 0

local m_nLastSendToGSTime = 0
local KNetLog = require("src/network/KNetLog")

function m_tLSAgency:OnConnectFailed()
    assert(m_nState == STATE_LS_CONNECTING, tostring(m_nState))

    SHTcpClient.OnConnectFailed(self)

    m_nState = STATE_INVALID
    self.tDataToSend = nil

    if not m_bEnableAutoReconnect then
        KGameServer:HideSendingUI(NET_ACTION_END_TYPE.CONNECTION_FAILED)
    end
end

function m_tLSAgency:OnConnectSuccess()
    assert(m_nState == STATE_LS_CONNECTING, tostring(m_nState))
    local setting = require("src/logic/KSetting")
    local szVersion = setting.getString(setting.Key.VERSION, VERSION)
    assert(szVersion) 
    m_nState = STATE_LS_CONNECTED
    self:DoSend("HandshakeRequest", szVersion)
end

function m_tLSAgency:OnRecvPackage(szFunc, ...)
    KNetLog.recvLog("LS")

    SHTcpClient.OnRecvPackage(self, szFunc, ...)
    print("LS2CL, ", szFunc, ...)

    local fnProcessor       = m_tLS2CLProcessor[szFunc]
    if not fnProcessor then
        print("LS2CL, not fnProcessor, ", szFunc, ...)
        return
    end

    fnProcessor(m_tLS2CLProcessor, ...)
    self:sendBuff()
end

function m_tLSAgency:OnDisconnected()
    SHTcpClient.OnDisconnected(self)

    self.tDataToSend    = nil

    if m_nState ~= STATE_LS_END then
        m_nState = STATE_INVALID
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_LS_DISCONNECT)
end

function m_tLSAgency:Send(szFunc, ...)
    if m_nState >= STATE_LS_HANDSHAKE_SUCCESS and m_nState < STATE_LS_END then
        assert(self.tDataToSend == nil or #self.tDataToSend == 0)
        if szFunc == "Login" then
            assert(m_nState == STATE_LS_HANDSHAKE_SUCCESS)
            m_nState = STATE_LS_VERIFYING
        end

        self:DoSend(szFunc, ...)
        return
    end

    self.tDataToSend = self.tDataToSend or {}
    table.insert(self.tDataToSend, {szFunc, ...})
end

function m_tLSAgency:sendBuff()
    if m_nState < STATE_LS_HANDSHAKE_SUCCESS or m_nState >= STATE_LS_END then return end
    if not self.tDataToSend or #self.tDataToSend == 0 then return end
    local tSendData = table.remove(self.tDataToSend, 1)
    local szFunc = tSendData[1]
    
    if szFunc == "Register" then
        if m_nState < STATE_LS_HANDSHAKE_SUCCESS then return end
    elseif szFunc == "ChangePassword" then
        if m_nState < STATE_LS_HANDSHAKE_SUCCESS then return end
    elseif szFunc == "Login" then
        if m_nState ~= STATE_LS_HANDSHAKE_SUCCESS then return end
        m_nState = STATE_LS_VERIFYING
    elseif szFunc == "ActivateAccount" then
        if m_nState ~= STATE_LS_WAIT_ACTIVATE then return end
    elseif szFunc == "RequestServerList" then
        if m_nState ~= STATE_LS_VERIFIED then return end
    elseif szFunc == "EnterServer" then
        if m_nState ~= STATE_LS_VERIFIED then return end
    end
    self:DoSend(unpack(tSendData, 1, table.maxn(tSendData)))
end

function m_tLSAgency:RemoveRequestInCache(szFunc)
    if not self.tDataToSend then
        return
    end

    for i = #self.tDataToSend, 1 do
        local tToSendData = self.tDataToSend[i]
        if not tToSendData then
            break
        end

        if tToSendData[1] == szFunc then
            table.remove(self.tDataToSend, i)
        end
    end
end


function m_tLSAgency:SendLog( ... )
    KNetLog.sendLog("LS", select(1, ...))
end

function m_tLS2CLProcessor:HandshakeRespond(nRetCode, szServerVersion)
    if m_nState ~= STATE_LS_CONNECTED then
        print("HandshakeRespond, m_nState ~= STATE_LS_CONNECTED", m_nState, STATE_LS_CONNECTED)      
        return
    end

    if nRetCode == LS_HANDSHAKE_RESPOND_RET.VERSION_ERROR then
        m_nState = STATE_LS_HANDSHAKE_FAIL
        KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)
        KGameServer:Logout()
    elseif nRetCode == LS_HANDSHAKE_RESPOND_RET.SUCCESS then
        m_nState = STATE_LS_HANDSHAKE_SUCCESS
    else
        assert(false)
    end

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_LS_HANDSHAKE, nRetCode, szServerVersion)
end

function m_tLS2CLProcessor:RegisterAccountRet(nRetCode)
    KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_REGISTER_RESULT, nRetCode)
end

function m_tLS2CLProcessor:LoginRet(nRetCode)
    if m_nState ~= STATE_LS_VERIFYING then
        print("LoginRet, m_nState ~= STATE_LS_VERIFYING", m_nState, STATE_LS_VERIFYING)
        return
    end

    if nRetCode == LOGIN_RET.SUCCESS then
        m_nState = STATE_LS_VERIFIED
        m_tLSAgency:RemoveRequestInCache("RequestServerList")
        m_tLSAgency:Send("RequestServerList")
    elseif nRetCode == LOGIN_RET.NOT_ACTIVE then
        m_nState = STATE_LS_WAIT_ACTIVATE
    else
        m_nState = STATE_LS_HANDSHAKE_SUCCESS
    end
    KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_LOGIN_RESULT, nRetCode)
end

function m_tLS2CLProcessor:ActivateAccountRet(nRetCode)
    if m_nState ~= STATE_LS_ACTIVATEING then
        print("ActivateAccountRet, m_nState ~= STATE_LS_ACTIVATEING", m_nState, STATE_LS_ACTIVATEING)
        return
    end

    if nRetCode == ACTIVATE_RET.SUCCESS then
        m_nState = STATE_LS_VERIFIED
        m_tLSAgency:RemoveRequestInCache("RequestServerList")
        m_tLSAgency:Send("RequestServerList")
    else
        m_nState = STATE_LS_WAIT_ACTIVATE
    end
    KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ACTIVATE_RESULT, nRetCode)
end

function m_tLS2CLProcessor:ChangePasswordRet(nRetCode)
    KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_CHANGE_PASSWORD_RESULT, nRetCode)
    print("-----> ChangePasswordRet dispatch event NET_CHANGE_PASSWORD_RESULT")
end

function m_tLS2CLProcessor:BindAccountRet(nRetCode)
   KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)

   local eventDispatch = require("src/logic/KEventDispatchCenter")
   eventDispatch:dispatchEvent(eventDispatch.EventType.NET_BIND_ACCOUNT_RESULT, nRetCode)
end

function m_tLS2CLProcessor:SyncServerList(tServerList)
    m_tServerList = tServerList
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SYNC_SERVER_LIST, tServerList)

    if m_tLSAgency.nTargetServerID then
        KGameServer:EnterServer(m_tLSAgency.nTargetServerID)
    else
        KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)
    end
end

function m_tLS2CLProcessor:EnterServerRet(nRetCode, nRoleID, szIP, nPort, szToken)
    if m_nState ~= STATE_LS_REQUESTING_ENTERSERVER then
        print("EnterServerRet, m_nState ~= STATE_LS_REQUESTING_ENTERSERVER", m_nState, STATE_LS_REQUESTING_ENTERSERVER)
        return
    end
    
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ENTER_SERVER_RESULT, nRetCode, nRoleID)

    if nRetCode ~= ENTER_SERVER_RET.SUCCESS then
        m_tLSAgency.nTargetServerID = nil
        m_nState = STATE_INVALID
        m_tLSAgency:Disconnect()
        return
    end

    m_nState = STATE_LS_END
    m_tLSAgency:Disconnect()

    m_bEnableAutoReconnect = true

    m_tBSAgency.nRoleID = nRoleID
    m_tBSAgency.szToken = szToken
    m_tBSAgency:SetTarget(szIP, nPort)
    if not m_tBSAgency:Connect() then
        return
    end
    m_nState = STATE_BS_CONNECTING
end

function m_tLS2CLProcessor:Hotfix(szScriptData)
    loadstring(szScriptData)()
end

function m_tBSAgency:OnConnectFailed()
    if m_nState ~= STATE_BS_CONNECTING then
        print("m_tBSAgency:OnConnectFailed, m_nState ~= STATE_BS_CONNECTING", m_nState, STATE_BS_CONNECTING)
        return
    end

    SHTcpClient.OnConnectFailed(self)

    self.nWaitingRespondID = nil
    m_nState = STATE_LS_END
end

function m_tBSAgency:OnConnectSuccess()
    assert(m_nState == STATE_BS_CONNECTING)
    
    m_nState = STATE_BS_CONNECTED

    local nRequestID = KGameServer:TakeNextRequestID()
    m_tBSAgency:DoSend(nRequestID, "HandshakeRequest", self.nRoleID, self.szToken)
    self.nWaitingRespondID = nRequestID

    m_nState = STATE_BS_VERIFYING
end

function m_tBSAgency:OnRecvPackage(szFunc, ...)

    SHTcpClient.OnRecvPackage(self, szFunc, ...)

    print("BS2CL ", szFunc)
    
    local fnProcessor  = m_tBS2CLProcessor[szFunc]
    if fnProcessor then
        fnProcessor(m_tBS2CLProcessor, ...)    
        return
    end

    local fnProcessor = KPlayer[szFunc]
    if fnProcessor then
        fnProcessor(KPlayer, ...)
        return
    end
    
    print("BS2CL Unknown Protocal: ", szFunc)
end

function m_tBSAgency:OnDisconnected()
    SHTcpClient.OnConnectFailed(self)

    self.nWaitingRespondID = nil
    m_nState = STATE_LS_END
end

function m_tBSAgency:Send(...)
    local nRequestID = KGameServer:TakeNextRequestID()
    local nCreateTime = os.time()

    self.tDataToSend = self.tDataToSend or {}
    table.insert(self.tDataToSend, {0, nCreateTime, nRequestID, ...})

    m_tBSAgency:TrySendNext()
    return nRequestID
end

function m_tBSAgency:TrySendNext()
    if m_nState ~= STATE_BS_PLALYING then
        return
    end

    if self.nWaitingRespondID then
        return
    end

    if not self.tDataToSend then
        return
    end

    if #self.tDataToSend == 0 then
        return
    end

    self.tDataToSend[1][1] = os.time()
    self.nWaitingRespondID = self.tDataToSend[1][3]
    self:DoSend(unpack(self.tDataToSend[1], 3, table.maxn(self.tDataToSend[1])))
end

function m_tBSAgency:OnRespondReceived(nRequestID)    
    if self.tDataToSend and #self.tDataToSend > 0 then
        if self.tDataToSend[1][3] == nRequestID then
            table.remove(self.tDataToSend, 1)
        end
    end
end

function m_tBSAgency:SendLog( ... )
    KNetLog.sendLog("BS", select(2, ...), select(1, ...))
end

function m_tBS2CLProcessor:HandshakeRespond(bSuccess)
    assert(m_nState == STATE_BS_VERIFYING, "Invalid State:" .. tostring(m_nState) .. " OnBS HandshakeRespond")

    if bSuccess then
        m_nState = STATE_BS_VERIFIED
        return
    end

    m_tBSAgency:Disconnect()
    m_nState = STATE_INVALID
end

function m_tBS2CLProcessor:Respond(nRequestID, tData)
    KNetLog.recvLog("BS", nRequestID)

    assert(m_tBSAgency.nWaitingRespondID == nRequestID)

    m_tBSAgency.nWaitingRespondID = nil

    m_tBSAgency:OnRespondReceived(nRequestID)

    m_nRespondID = nRequestID

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.RESPOND, nRequestID)

    for _, v in ipairs(tData) do
        local szFuncName = v[1]
        -- print("Recv Respond Sub: ", unpack(v))

        local fnProcessor  = m_tBS2CLProcessor[szFuncName]
        if fnProcessor then
            local function processFunc()
                fnProcessor(m_tBS2CLProcessor, unpack(v, 2, table.maxn(v)))
            end
            xpcall(processFunc, __G__TRACKBACK__)    
        else
            local fnProcessor = KPlayer[szFuncName]
            assert(fnProcessor, szFuncName)
            local function processFunc()
                fnProcessor(KPlayer, unpack(v, 2, table.maxn(v)))
            end
            xpcall(processFunc, __G__TRACKBACK__)
        end
    end

    if not m_tBSAgency.tDataToSend or #m_tBSAgency.tDataToSend == 0 then
        KGameServer:HideSendingUI(NET_ACTION_END_TYPE.SUCCESS)
        return
    end

	m_tBSAgency:TrySendNext()
end

function m_tBS2CLProcessor:SyncDataEnd(...)
    assert(m_nState == STATE_BS_VERIFIED, m_nState)
    m_nState = STATE_BS_PLALYING
    KPlayer:SyncDataEnd(...)
    m_tBSAgency:TrySendNext()
end

function m_tBS2CLProcessor:Ping()
end


function m_tBS2CLProcessor:Hotfix(szScriptData)
    loadstring(szScriptData)()
end

local function ProcessPingToGS(nCurrentTime)
    if m_nState < STATE_BS_CONNECTED then
        return
    end

    if m_tBSAgency.nLastSendTime + PING_CYCLE > nCurrentTime then
        return
    end

    if m_tBSAgency.tDataToSend and #m_tBSAgency.tDataToSend > 0 then
        return
    end

    KGameServer:SendToGS("Ping")
end

local function ProcessPingTimeout(nCurrentTime)
    cclog("In New ProcessPingTimeout")
    if m_nState < STATE_BS_CONNECTED then
        return
    end

    if not KPlayer.bDataReady then
        return
    end

    if m_tBSAgency.nLastRecvTime + PING_TIMEOUT > nCurrentTime then
        return
    end

    cclog("cl-bs time out, logout**************")
    KPlayer:Logout()
    
    local function confirmQuitGameFunction()
        if PLAT_ID == PLAT_SELF then
            local gameScene = require("src/ui/login/KUILoginScene").create()
            if cc.Director:getInstance():getRunningScene() then
                cc.Director:getInstance():replaceScene(gameScene)
            else
                cc.Director:getInstance():runWithScene(gameScene)
            end
        else
            C_SDKAgent.Logout("S1")
        end
    end

    local function cancelQuitGameFunction()
    end

    showConfirmation("网络连接中断，请重新登录游戏", confirmQuitGameFunction, cancelQuitGameFunction) 
end

function KGameServer:Activate(nCurrentTime)
    if m_nLastFrameTime == nCurrentTime then
        return
    end

    m_nLastFrameTime = nCurrentTime

    KGameServer:ProcessSendingUILogic(nCurrentTime)

    ProcessPingToGS(nCurrentTime)
    -- ProcessPingTimeout(nCurrentTime)

    if not m_bEnableAutoReconnect then
        return
    end

    if m_nState == STATE_INVALID then
        KGameServer:Login(m_tLSAgency.szAccount, m_tLSAgency.szPassword)
        return
    end

    if m_nState == STATE_LS_END then
        if not m_tBSAgency:Connect() then
            return
        end
        m_nState = STATE_BS_CONNECTING
        return
    end
end

function KGameServer:SetShowSendingUITask()
    if m_nShowSendingUITime then
        return
    end

    m_nShowSendingUITime = os.time() + BEGIN_SHOW_SENDING_UI_SECONDS
end

function KGameServer:HideSendingUI(nEndType)
    m_nShowSendingUITime = nil
    m_nHideSendingUITime = nil

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ACTION_END_TYPE, nEndType)
end

function KGameServer:ProcessSendingUILogic(nCurrentTime)
    if m_nShowSendingUITime and m_nShowSendingUITime + BEGIN_SHOW_SENDING_UI_SECONDS < nCurrentTime then
        m_nShowSendingUITime = nil
        m_nHideSendingUITime = nCurrentTime + MAX_RE_REQUEST_SECONDS

        local currentScene = cc.Director:getInstance():getRunningScene()
        local sendingNode = require("src/ui/common/KUISendingNode").create(currentScene)
        currentScene:addChild(sendingNode, 200)
        return
    end

    if m_nHideSendingUITime and m_nHideSendingUITime < nCurrentTime then
        KGameServer:HideSendingUI(NET_ACTION_END_TYPE.TIME_OUT)
        --m_tBSAgency:Disconnect()
        return
    end
end

local function ConnectToLS()
    if m_nState >= STATE_LS_END then
        return false
    end

    if m_nState ~= STATE_INVALID then
        return true
    end

    if not m_tLSAgency:Connect() then
        cclog("begin connect to LS(%s:%d) failed!", m_szLSIP, m_nLSPort)
        return false
    end
    
    m_nState = STATE_LS_CONNECTING
    cclog("begin connect to LS(%s:%d) success!", m_szLSIP, m_nLSPort)
    return true
end

function KGameServer:Register(szAccount, szPassword, szActivationCode)
    if not ConnectToLS() then
        return false
    end

    m_tLSAgency:Send("Register", szAccount, szPassword, szActivationCode)
    self:SetShowSendingUITask()
    return true
end

function KGameServer:Login(szAccount, szPassword)
    if m_nState == STATE_LS_HANDSHAKE_FAIL then
        return false
    end

    if not (m_nState == STATE_INVALID or m_nState == STATE_LS_CONNECTING or m_nState == STATE_LS_CONNECTED or m_nState == STATE_LS_HANDSHAKE_SUCCESS) then
        return false
    end

    if not ConnectToLS() then
        return false
    end

    m_tLSAgency:RemoveRequestInCache("Login")
    m_tLSAgency.szAccount = szAccount
    m_tLSAgency.szPassword = szPassword
    m_tLSAgency:Send("Login", szAccount, szPassword)
    self:SetShowSendingUITask()
    return true
end

function KGameServer:BindAccount(tInfo)
    if m_nState == STATE_LS_HANDSHAKE_FAIL then
        return false
    end

    if not ConnectToLS() then
        return false
    end

    m_tLSAgency:RemoveRequestInCache("BindAccount")
    m_tLSAgency:Send("BindAccount", tInfo)
    self:SetShowSendingUITask()
end

function KGameServer:ChangePassword(szAccount, szOldPassword, szNewPassword)
    if not ConnectToLS() then
        return false
    end
    
    m_tLSAgency:Send("ChangePassword", szAccount, szOldPassword, szNewPassword)
    self:SetShowSendingUITask()
    return true
end

function KGameServer:ActivateAccount(szActivationCode)
    if m_nState ~= STATE_LS_WAIT_ACTIVATE then
        print("ActivateAccount, m_nState ~= STATE_LS_WAIT_ACTIVATE", m_nState, STATE_LS_WAIT_ACTIVATE)
        return
    end

    m_tLSAgency:Send("ActivateAccount", szActivationCode)
    self:SetShowSendingUITask()
    m_nState = STATE_LS_ACTIVATEING
    return true
end

function KGameServer:EnterServer(nServerID)
    if m_nState ~= STATE_LS_VERIFIED then
        print("Error, RequestServerList, m_nState ~= STATE_LS_VERIFIED", m_nState, STATE_LS_VERIFIED)
        return
    end

    m_tLSAgency:RemoveRequestInCache("EnterServer")
    m_tLSAgency:Send("EnterServer", nServerID)
    m_tLSAgency.nTargetServerID = nServerID

    m_nState = STATE_LS_REQUESTING_ENTERSERVER
end

function KGameServer:TakeNextRequestID()
    m_nRequestID = m_nRequestID + 1
    return m_nRequestID
end

local m_tBackGroupSend = 
{
    ["Ping"] = true
}

function KGameServer:SendToGS(szFunc, ...)
    if not m_tBackGroupSend[szFunc] then
        KGameServer:SetShowSendingUITask()
    end

    return m_tBSAgency:Send(szFunc, ...)
end

function KGameServer:GetRespondID()
    return m_nRespondID
end

function KGameServer:BeKicked()
    KGameServer:Logout()
end

function KGameServer:IsReady()
    C_Log("KGameServer:IsReady(), m_nState:" .. tostring(m_nState) .. " STATE_BS_PLALYING:" .. tostring(STATE_BS_PLALYING))
    return m_nState == STATE_BS_PLALYING
end

function KGameServer:HasPackageInSendingQueue(strName)
    if not m_tBSAgency.tDataToSend  then
        return false
    end

    if strName == nil then
        return #m_tBSAgency.tDataToSend > 0
    end

    for _, v in ipairs(m_tBSAgency.tDataToSend) do
        if v[4] == strName then
            return true
        end
    end

    return false
end

function KGameServer:Logout()
    m_tBSAgency:Disconnect()
    m_tLSAgency:Disconnect()
    m_bEnableAutoReconnect = false
    m_tLSAgency.nTargetServerID = nil
    m_nState = STATE_INVALID
    m_tLSAgency.tDataToSend = nil
    m_tBSAgency.tDataToSend = nil
end

