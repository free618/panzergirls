
--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KS2CProtocolManager.lua
--  Creator     : SunXun
--  Date        : 2015/04/02   10:56
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


-- local KS2CProtocolManager = {}


-- function KS2CProtocolManager.TestProtocol(szInfo)
--     cclog("recv ----------> szInfo:%s", szInfo)
-- end

-- function KS2CProtocolManager.SyncEquipData(tEquipData)
--     KPlayer:setEquipData(tEquipData)
-- end

-- function KS2CProtocolManager.SyncCardData(tCardData)
--     KPlayer:setCardData(tCardData)
-- end

-- function KS2CProtocolManager.SyncTeamData(tTeamData)
--     KPlayer:setTeamData(tTeamData)
-- end

-- function KS2CProtocolManager.SyncDataEnd(nProgressID)
--     KPlayer:setProgress(nProgressID)
--     local eventDispatch = require("src/logic/KEventDispatchCenter")
--     eventDispatch:dispatchEvent(eventDispatch.EventType.NET_SYNC_DATA_END)
--     eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_PLAYER_PROGRESS)
-- end

-- function KS2CProtocolManager.UpdatePlayerProgress(nProgressID)
--     KPlayer:setProgress(nProgressID)
--     local eventDispatch = require("src/logic/KEventDispatchCenter")
--     eventDispatch:dispatchEvent(eventDispatch.EventType.NET_UPDATE_PLAYER_PROGRESS)
-- end

-- function KS2CProtocolManager.CardBuildFinished(tOneCard)
--     KPlayer:CardBuildFinished(tOneCard)
-- end

-- function KS2CProtocolManager.BuildCard(tBuildingCard)
--     KPlayer:BuildCard(tBuildingCard)
-- end

-- function KS2CProtocolManager.DestoryCardSuccess(nCardID, nRecycleOil, nRecycleAmmo, nRecycleSteel, nRecyclePeople)
--     KPlayer:DestoryCardSuccess(nCardID, nRecycleOil, nRecycleAmmo, nRecycleSteel, nRecyclePeople)
-- end

-- function KS2CProtocolManager:dispatchProtocol(szFunc, ...)
--     --cclog("------------------ msgType = %s", msgType)
--     local protocolFunc = self[szFunc]
--     if not protocolFunc then
--         cclog("Recv Unknow Logic Protocol szFunc: %s", szFunc)
--         return false
--     end
--     cclog("KS2CProtocolManager:dispatchProtocol szFunc ----------> %s", szFunc)
--     protocolFunc(...)
--     return true
-- end

-- return KS2CProtocolManager
