return 
{
	[1] = {['nID'] = 1,['otOpenTimes'] = [[openTime = '2016-1-29 0:0:0', closeTime = '2016-6-29 11:17:00']],['nCardID1'] = 1,['nCardID2'] = 2,['nCardID3'] = 3,['nCardID4'] = 4,['nCardID5'] = 5,['nCardID6'] = 6,['nCardID7'] = 7,['nCardID8'] = 8,['nCardID9'] = 9,['nCardID10'] = 10,},
	[2] = {['nID'] = 2,['otOpenTimes'] = [[openTime = '2016-6-29 11:18:00', closeTime = '2016-3-3 0:0:0']],['nCardID1'] = 2,['nCardID2'] = 3,['nCardID3'] = 4,['nCardID4'] = 5,['nCardID5'] = 6,['nCardID6'] = 0,['nCardID7'] = 0,['nCardID8'] = 0,['nCardID9'] = 0,['nCardID10'] = 0,},
	[3] = {['nID'] = 3,['otOpenTimes'] = [[openTime = '2016-7-8 0:0:0', closeTime = '2016-7-14 23:59:59']],['nCardID1'] = 77,['nCardID2'] = 356,['nCardID3'] = 359,['nCardID4'] = 68,['nCardID5'] = 92,['nCardID6'] = 105,['nCardID7'] = 0,['nCardID8'] = 0,['nCardID9'] = 0,['nCardID10'] = 0,},
}