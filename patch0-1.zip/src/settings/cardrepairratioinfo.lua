return 
{
	[1] = {['nID'] = 1,['nLevel'] = 1,['nRatio'] = 10,},
	[2] = {['nID'] = 2,['nLevel'] = 12,['nRatio'] = 26,},
	[3] = {['nID'] = 3,['nLevel'] = 15,['nRatio'] = 30,},
	[4] = {['nID'] = 4,['nLevel'] = 20,['nRatio'] = 34,},
	[5] = {['nID'] = 5,['nLevel'] = 27,['nRatio'] = 38,},
	[6] = {['nID'] = 6,['nLevel'] = 36,['nRatio'] = 42,},
	[7] = {['nID'] = 7,['nLevel'] = 47,['nRatio'] = 46,},
	[8] = {['nID'] = 8,['nLevel'] = 60,['nRatio'] = 50,},
	[9] = {['nID'] = 9,['nLevel'] = 75,['nRatio'] = 54,},
	[10] = {['nID'] = 10,['nLevel'] = 92,['nRatio'] = 58,},
	[11] = {['nID'] = 11,['nLevel'] = 111,['nRatio'] = 62,},
	[12] = {['nID'] = 12,['nLevel'] = 132,['nRatio'] = 66,},
}