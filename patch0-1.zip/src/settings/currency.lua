return 
{
	['COIN'] = {['szName'] = [[COIN]],['szText'] = [[點券]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_diamond.png]],},
	['OIL'] = {['szName'] = [[OIL]],['szText'] = [[油料]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_oil.png]],},
	['AMMO'] = {['szName'] = [[AMMO]],['szText'] = [[彈藥]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_ammo.png]],},
	['STEEL'] = {['szName'] = [[STEEL]],['szText'] = [[鋼材]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_steel.png]],},
	['PEOPLE'] = {['szName'] = [[PEOPLE]],['szText'] = [[人力]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_sp_ammo.png]],},
	['FURNITURE'] = {['szName'] = [[FURNITURE]],['szText'] = [[家具幣]],['nQuality'] = 1,['szImage'] = [[res/ui/ui_material/public/common_furniture_currency.png]],},
}