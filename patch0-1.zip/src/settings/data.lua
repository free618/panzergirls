return
{
	OneEquip =
	{
		{"nID","int32"},
		{"nTemplateID","int32"},
		{"nCreateTime","int32"},
		{"bLock","bool"},
	},
	OneItem =
	{
		{"nID","int32"},
		{"nTemplateID","int32"},
		{"nCount","int32"},
	},
	OneProducingEquip =
	{
		{"nID","int32"},
		{"nTemplateID","int32"},
		{"nEndTime","int32"},
	},
	ItemStoreHouse =
	{
		{"nMaxSize","int32"},
		{"tItemList","array","OneItem"},
	},
	EquipStoreHouse =
	{
		{"nMaxSize","int32"},
		{"tEquipList","array","OneEquip"},
	},
	ItemData =
	{
		{"tProducingEquipList","array","OneProducingEquip"},
		{"tEquipStoreHouse","EquipStoreHouse"},
		{"tStoreHouse","ItemStoreHouse"},
		{"tHistoricalEquipID","array","int32"},
		{"tDeadEquipList","array","OneEquip"},
		{"tProduceType","array","int32"},
	},
	OneCardEquip =
	{
		{"nPos","int32"},
		{"nEquipID","int32"},
	},
	OneRingAttribute =
	{
		{"nIndex","int32"},
		{"nValue","int32"},
	},
	OneCard =
	{
		{"nID","int32"},
		{"nTemplateID","int32"},
		{"nCreateTime","int32"},
		{"bLock","bool"},
		{"nLevel","int32"},
		{"nCurrentExp","int32"},
		{"nCurrentHP","int32"},
		{"nCurrentOil","int32"},
		{"nCurrentAmmo","int32"},
		{"nAddHP","int32"},
		{"nAddAttack","int32"},
		{"nAddPenetrate","int32"},
		{"nAddSpeed","int32"},
		{"nAddFrontArmour","int32"},
		{"nAddRearArmour","int32"},
		{"nAddScout","int32"},
		{"nAddDodge","int32"},
		{"nAddHide","int32"},
		{"nAddNightBattle","int32"},
		{"tEquipList","array","OneCardEquip"},
		{"nFeeling","int32"},
		{"bRing","bool"},
		{"tRingAttribute","array","OneRingAttribute"},
		{"nKillCount","int32"},
		{"nMountItemTemplateID","int32"},
		{"nSkinTemplateID","int32"},
	},
	OneProducingCard =
	{
		{"nID","int32"},
		{"nTemplateID","int32"},
		{"nEndTime","int32"},
		{"nIndex","int32"},
	},
	OneRepairingCard =
	{
		{"nID","int32"},
		{"nCardID","int32"},
		{"nEndTime","int32"},
		{"nRepairPosition","int32"},
	},
	CardStoreHouse =
	{
		{"nMaxSize","int32"},
		{"tCardList","array","OneCard"},
	},
	CardData =
	{
		{"tProducingList","array","OneProducingCard"},
		{"tDeadList","array","OneCard"},
		{"tStoreHouse","CardStoreHouse"},
		{"tRepairingList","array","OneRepairingCard"},
		{"tHistoricalCardID","array","int32"},
		{"tHistoricalMarriedList","array","int32"},
		{"nProduceCardTimes","int32"},
		{"nProduceOuHuangCardTimes","int32"},
		{"tProduceType","array","int32"},
	},
	OneTeam =
	{
		{"nIndex","int32"},
		{"tCardIDList","array","int32"},
		{"szName","bytes"},
	},
	TeamData =
	{
		{"nMaxCount","int32"},
		{"tTeamList","array","OneTeam"},
		{"nOpenCount","int32"},
		{"tRecordTeamList","array","OneTeam"},
	},
	OneAreaLastID =
	{
		{"nType","int32"},
		{"nTemplateID","int32"},
	},
	OneExpeditionData =
	{
		{"nType","int32"},
		{"nTemplateID","int32"},
		{"nEndTime","int32"},
		{"nTeamID","int32"},
		{"nResourceID","int32"},
	},
	ExpeditionData =
	{
		{"tAreaLastIDList","array","OneAreaLastID"},
		{"tExpeditionList","array","OneExpeditionData"},
		{"nRefreshTime","int32"},
		{"nLeftTimes","int32"},
		{"nLastRefreshTime","int32"},
	},
	OneRewardData =
	{
		{"nType","int32"},
		{"nID","int32"},
		{"nNum","int32"},
	},
	OneRewardStore =
	{
		{"nID","int32"},
		{"tRewardList","array","OneRewardData"},
	},
	OneMissionObjectives =
	{
		{"nID","int32"},
		{"nCompletedCount","int32"},
	},
	OneMission =
	{
		{"nID","int32"},
		{"tObjectivesList","array","OneMissionObjectives"},
	},
	MissionData =
	{
		{"tHistoricalMissionList","array","int32"},
		{"tMissionList","array","OneMission"},
	},
	BattleMap2ndDiffcultModeSpecialData =
	{
		{"nZoneID","int32"},
		{"nMapID","int32"},
		{"nDiffcult","int32"},
		{"bLevel1Pass","bool"},
		{"bLevel2Pass","bool"},
		{"bLevel3Pass","bool"},
	},
	BattleSpecialData =
	{
		{"t2ndDiffcultModeSpecialData","array","BattleMap2ndDiffcultModeSpecialData"},
	},
	OneBattleMapData =
	{
		{"nMapID","int32"},
		{"nProgress","int32"},
		{"tFinishFoothold","array","int32"},
		{"bPass","bool"},
		{"nWinCount","int32"},
		{"nLastWinDay","int32"},
		{"nGetedPassMapRewardID","int32"},
	},
	OneBattleZoneData =
	{
		{"nZoneID","int32"},
		{"tMaps","array","OneBattleMapData"},
		{"nOpenTime","int32"},
	},
	LaunchData =
	{
		{"nLaunchCount","int32"},
		{"nLaunchWinCount","int32"},
	},
	ExerciseData =
	{
		{"nExerciseCount","int32"},
		{"nExerciseWinCount","int32"},
	},
	RecordData =
	{
		{"tLaunchData","LaunchData"},
		{"tExerciseData","ExerciseData"},
	},
	OneLogData =
	{
		{"nID","int32"},
		{"nRoleID","int32"},
		{"szName","bytes"},
		{"nTemplateID","int32"},
		{"nOil","int32"},
		{"nAmmo","int32"},
		{"nSteel","int32"},
		{"nPeople","int32"},
	},
	LogData =
	{
		{"tCardLogCollect","array","OneLogData"},
		{"tEquipLogCollect","array","OneLogData"},
	},
	SignData =
	{
		{"nLastDay","int32"},
		{"nCount","int32"},
		{"nCleanDay","int32"},
	},
	OneFurnitureData =
	{
		{"nTemplateID","int32"},
		{"nCount","int32"},
	},
	OneRoleFurniture =
	{
		{"nType","int32"},
		{"nTemplateID","int32"},
	},
	FurnitureData =
	{
		{"tFurnitureList","array","OneFurnitureData"},
		{"tRoleFurniture","array","OneRoleFurniture"},
	},
	ExchangeTypeList =
	{
		{"tTypeList","array","int32"},
	},
	OneExercise =
	{
		{"nRoleID","int32"},
		{"nScore","int32"},
		{"nTemplateID","int32"},
		{"nSkinTemplateID","int32"},
	},
	ExerciseRoleData =
	{
		{"nNextTime","int32"},
		{"tExerciseList","array","OneExercise"},
	},
	PlunderData =
	{
		{"tOneTeam","OneTeam"},
		{"tEquipList","array","OneEquip"},
		{"tCardList","array","OneCard"},
	},
	OneGoods =
	{
		{"nID","int32"},
		{"nCount","int32"},
		{"nDayCount","int32"},
		{"nWeekCount","int32"},
	},
	ShopData =
	{
		{"tBuyGoods","array","OneGoods"},
		{"nLastClearWeekIndex","int32"},
	},
	MonthCard =
	{
		{"nLeftTimes","int32"},
		{"nLastTime","int32"},
	},
	ExpBuff =
	{
		{"nPercent","int32"},
		{"nExpireTime","int32"},
	},
	FoodHouseData =
	{
		{"nCookTimes","int32"},
		{"nCoinCookTimes","int32"},
	},
	OneMedalProgress =
	{
		{"nID","int32"},
		{"nValue","int32"},
	},
	OneMedal =
	{
		{"nID","int32"},
		{"tProgressList","array","OneMedalProgress"},
		{"nNum","int32"},
		{"nTime","int32"},
	},
	MedalData =
	{
		{"nValue","int32"},
		{"tMedalList","array","OneMedal"},
	},
	OneCardRank =
	{
		{"nID","int32"},
		{"tValueList","array","int32"},
	},
	SecretaryData =
	{
		{"nCardID","int32"},
		{"nType","int32"},
		{"nState","int32"},
	},
	SkinData =
	{
		{"tSkinList","array","int32"},
	},
	SPSignData =
	{
		{"nLastSignTime","int32"},
		{"nSignDay","int32"},
	},
	OneSkill =
	{
		{"nPos","int32"},
		{"nLeftTimes","int32"},
		{"nEquipID","int32"},
	},
	StoryData =
	{
		{"tGainRewardList","array","int32"},
	},
	OneTraining =
	{
		{"nTemplateID","int32"},
		{"tWarList","array","int32"},
	},
	RoleData =
	{
		{"nProgress","int32"},
		{"nPreResourceID","int32"},
		{"tItemData","ItemData"},
		{"tCardData","CardData"},
		{"tTeamData","TeamData"},
		{"tExpeditionData","ExpeditionData"},
		{"tRewardStoreList","array","OneRewardStore"},
		{"tMissionData","MissionData"},
		{"nLastUpdateTime","int32"},
		{"tBattleData","array","OneBattleZoneData"},
		{"nLastAddResourceTime","int32"},
		{"nRepairBarNum","int32"},
		{"nBuildBarNum","int32"},
		{"tRecordData","RecordData"},
		{"tLogData","LogData"},
		{"tSignData","SignData"},
		{"tFurnitureData","FurnitureData"},
		{"tExchangeTypeList","ExchangeTypeList"},
		{"tExerciseData","ExerciseRoleData"},
		{"tShopData","ShopData"},
		{"tMonthCardData","MonthCard"},
		{"nAddFeeling","int32"},
		{"tBattleSpecialData","BattleSpecialData"},
		{"tFoodHouseData","FoodHouseData"},
		{"tExpBuffData","ExpBuff"},
		{"tMedalData","MedalData"},
		{"tCardRankData","array","OneCardRank"},
		{"tSecretaryData","SecretaryData"},
		{"tSkinData","SkinData"},
		{"tSPSignData","SPSignData"},
		{"tStoryData","StoryData"},
		{"tSkillList","array","OneSkill"},
		{"tTrainingList","array","OneTraining"},
	},
}