return 
{
	['nDailyCookTimes'] = {['szName'] = [[nDailyCookTimes]],['nValue'] = 5,['szValue'] = [[]],['tValue'] = {},},
	['nFreeItemID'] = {['szName'] = [[nFreeItemID]],['nValue'] = 75,['szValue'] = [[]],['tValue'] = {},},
	['tCostCoin'] = {['szName'] = [[tCostCoin]],['nValue'] = 0,['szValue'] = [[]],['tValue'] = {10,20,20,20,20},},
	['tFoodDesc'] = {['szName'] = [[tFoodDesc]],['nValue'] = 0,['szValue'] = [[]],['tValue'] = {"英國的食材","敬請期待","美國的食材","中國的食材","敬請期待"},},
	['tFoodOpen'] = {['szName'] = [[tFoodOpen]],['nValue'] = 0,['szValue'] = [[]],['tValue'] = {1,0,1,1,0},},
}