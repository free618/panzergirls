return 
{
	[1] = {['nID'] = 1,['szName'] = [[壁紙]],['nInitID'] = 2,['nOrder'] = 1,},
	[2] = {['nID'] = 2,['szName'] = [[地板]],['nInitID'] = 4,['nOrder'] = 2,},
	[3] = {['nID'] = 3,['szName'] = [[掛飾]],['nInitID'] = 6,['nOrder'] = 3,},
	[4] = {['nID'] = 4,['szName'] = [[窗戶]],['nInitID'] = 8,['nOrder'] = 4,},
	[5] = {['nID'] = 5,['szName'] = [[地毯]],['nInitID'] = 10,['nOrder'] = 5,},
	[6] = {['nID'] = 6,['szName'] = [[角飾]],['nInitID'] = 12,['nOrder'] = 6,},
	[7] = {['nID'] = 7,['szName'] = [[左墻]],['nInitID'] = 14,['nOrder'] = 7,},
	[8] = {['nID'] = 8,['szName'] = [[桌椅]],['nInitID'] = 16,['nOrder'] = 9,},
	[9] = {['nID'] = 9,['szName'] = [[右墻]],['nInitID'] = 18,['nOrder'] = 8,},
}