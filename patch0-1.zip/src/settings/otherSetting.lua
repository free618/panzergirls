return 
{
	['nMaxChatMessageLen'] = {['szName'] = [[nMaxChatMessageLen]],['szValue'] = [[35]],},
	['nMaxChatInterval_PRIVATE'] = {['szName'] = [[nMaxChatInterval_PRIVATE]],['szValue'] = [[5]],},
	['nMaxChatInterval_GLOBAL'] = {['szName'] = [[nMaxChatInterval_GLOBAL]],['szValue'] = [[60]],},
	['nMaxChatCount_PRIVATE'] = {['szName'] = [[nMaxChatCount_PRIVATE]],['szValue'] = [[100]],},
	['nMaxChatCount_GLOBAL'] = {['szName'] = [[nMaxChatCount_GLOBAL]],['szValue'] = [[100]],},
	['tSelfSendMessageColor'] = {['szName'] = [[tSelfSendMessageColor]],['szValue'] = [[0,255,255]],},
	['tOtherSendMessageColor'] = {['szName'] = [[tOtherSendMessageColor]],['szValue'] = [[0,191,255]],},
}