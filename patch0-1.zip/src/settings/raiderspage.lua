return 
{
	[1] = {['nPage'] = 1,['szName'] = [[新手必看]],},
	[2] = {['nPage'] = 2,['szName'] = [[戰斗]],},
	[3] = {['nPage'] = 3,['szName'] = [[獲取坦克]],},
	[4] = {['nPage'] = 4,['szName'] = [[坦克培養]],},
}