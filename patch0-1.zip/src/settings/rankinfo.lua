return 
{
	[1] = {['nID'] = 1,['nRankPercent'] = 1,['szName'] = [[元帥]],['szImagePath'] = [[fieldmarshal]],},
	[2] = {['nID'] = 2,['nRankPercent'] = 5,['szName'] = [[上將]],['szImagePath'] = [[general]],},
	[3] = {['nID'] = 3,['nRankPercent'] = 10,['szName'] = [[中將]],['szImagePath'] = [[lieutenantgeneral]],},
	[4] = {['nID'] = 4,['nRankPercent'] = 20,['szName'] = [[少將]],['szImagePath'] = [[majorgeneral]],},
	[5] = {['nID'] = 5,['nRankPercent'] = 40,['szName'] = [[上校]],['szImagePath'] = [[colonel]],},
	[6] = {['nID'] = 6,['nRankPercent'] = 55,['szName'] = [[中校]],['szImagePath'] = [[lieutenantcolonel]],},
	[7] = {['nID'] = 7,['nRankPercent'] = 65,['szName'] = [[少校]],['szImagePath'] = [[major]],},
	[8] = {['nID'] = 8,['nRankPercent'] = 70,['szName'] = [[上尉]],['szImagePath'] = [[captain]],},
	[9] = {['nID'] = 9,['nRankPercent'] = 75,['szName'] = [[中尉]],['szImagePath'] = [[lieutenant]],},
	[10] = {['nID'] = 10,['nRankPercent'] = 80,['szName'] = [[少尉]],['szImagePath'] = [[secondlieutenant]],},
	[11] = {['nID'] = 11,['nRankPercent'] = 85,['szName'] = [[上士]],['szImagePath'] = [[staffsergeant]],},
	[12] = {['nID'] = 12,['nRankPercent'] = 90,['szName'] = [[中士]],['szImagePath'] = [[sergeant]],},
	[13] = {['nID'] = 13,['nRankPercent'] = 95,['szName'] = [[下士]],['szImagePath'] = [[corporal]],},
	[14] = {['nID'] = 14,['nRankPercent'] = 100,['szName'] = [[新兵]],['szImagePath'] = [[private]],},
}