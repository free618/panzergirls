return 
{
	[1] = {['nDay'] = 1,['szTitle'] = [[第1天]],['szResPath'] = [[]],['nRewardID'] = 362,['otOpenTimes'] = [[openTime = '2015-5-24 0:0:0', closeTime = '2015-6-30 0:0:0']],},
	[2] = {['nDay'] = 2,['szTitle'] = [[第2天]],['szResPath'] = [[box1]],['nRewardID'] = 363,['otOpenTimes'] = [[]],},
	[3] = {['nDay'] = 3,['szTitle'] = [[第3天]],['szResPath'] = [[box2]],['nRewardID'] = 364,['otOpenTimes'] = [[]],},
	[4] = {['nDay'] = 4,['szTitle'] = [[第4天]],['szResPath'] = [[box3]],['nRewardID'] = 365,['otOpenTimes'] = [[]],},
	[5] = {['nDay'] = 5,['szTitle'] = [[第5天]],['szResPath'] = [[box4]],['nRewardID'] = 366,['otOpenTimes'] = [[]],},
	[6] = {['nDay'] = 6,['szTitle'] = [[第6天]],['szResPath'] = [[box5]],['nRewardID'] = 367,['otOpenTimes'] = [[]],},
	[7] = {['nDay'] = 7,['szTitle'] = [[第7天]],['szResPath'] = [[box6]],['nRewardID'] = 368,['otOpenTimes'] = [[]],},
}