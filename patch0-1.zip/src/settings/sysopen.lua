return 
{
	['lizhi'] = {['szSysName'] = [[lizhi]],['szTime'] = [[%Y%m%d%H%M%S]],['nStartTime'] = 0,['nEndTime'] = 20160621055960,['nShowType'] = 1,['szShowID'] = [[exercise.selectFormation]],},
	['story'] = {['szSysName'] = [[story]],['szTime'] = [[%Y%m%d%H%M%S]],['nStartTime'] = 0,['nEndTime'] = 20160621055960,['nShowType'] = 2,['szShowID'] = [[sysopen.notopen]],},
}