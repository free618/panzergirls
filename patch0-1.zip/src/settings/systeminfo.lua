return 
{
	['rank'] = {['szKey'] = [[rank]],['tValue'] = {120,840},},
	['maxExpeditionExtraHour'] = {['szKey'] = [[maxExpeditionExtraHour]],['tValue'] = {24},},
	['refreshPlunderMinute'] = {['szKey'] = [[refreshPlunderMinute]],['tValue'] = {10},},
	['maxPlunderTimes'] = {['szKey'] = [[maxPlunderTimes]],['tValue'] = {5},},
	['refreshPlunderTimesMinute'] = {['szKey'] = [[refreshPlunderTimesMinute]],['tValue'] = {120,840},},
	['equipMaxResource'] = {['szKey'] = [[equipMaxResource]],['tValue'] = {599},},
}