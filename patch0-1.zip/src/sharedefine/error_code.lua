ERROR_CODE = {
    -- base
    CARDFULL                 = 1,  --卡牌空间不足
    EQUIPFULL                = 2,  --装备空间不足
    ITEMFULL                 = 3,  --物品空间不足
    COIN_NOT_ENOUGH          = 4,  --司令,钻石不足
    OIL_NOT_ENOUGH           = 5,  --司令,油料不足
    AMMO_NOT_ENOUGH          = 6,  --司令,弹药不足
    STEEL_NOT_ENOUGH         = 7,  --司令,钢材不足
    PEOPLE_NOT_ENOUGH        = 8,  --司令,人力不足
    ITEM_NOT_ENOUGH          = 9,  --司令,物品不足
    IS_FULL                  = 10, --司令,仓库容量不足
    FURNITURE_NOT_ENOUGH     = 11,  --司令,家具币不足
    FURNITURE_FULL           = 12,  --司令,家具币已经达到上限
    RESOURCE_NOT_ENOUGH      = 13,  --司令,资源不足
    CARD_NOT_EXIST           = 14,  --司令,卡牌不存在
    -- repairing
    CARD_REPAIRING                = 100,  --司令,修理卡牌不可以远征
    CARD_NOT_EXIST                = 101,  --司令,修理卡牌不存在
    CARD_IN_REPAIRING             = 102,  --司令,坦克正在修理中
    CARD_POSITON_REPAIRING        = 103,  --司令,修理栏已经有坦克正在修理中
    --supply
    CARD_CANNOT_SUPPLY            = 110,  --司令,远征的卡牌不可以补给
    TEAM_CANNOT_SUPPLY            = 111,  --司令,远征的队伍不可以补给
    -- team
    TEAM_CONVERT_CARD_EXPEDITION       = 120,  --司令,远征的卡牌不可以改造
    TEAM_SELECTED_CARD_EXPEDITION      = 121,  --司令,选择的卡牌在远征
    TEAM_SELECTED_CARD_IN_TEAM         = 122,  --司令,选择的卡牌在队伍中
    TEAM_SELECTED_CARD_IN_REPAIRING    = 123,  --司令,选择的卡牌在修理
    TEAM_FIRST_LEADER                  = 124,  --司令,第一队的队长不可离队
    TEAM_CAN_NOT_SAME                  = 125,  --司令，同个队伍不能有同样坦克
    --rank
    RANK_HAVE_GET_REWARD               = 130,  --司令,奖励已经领取
    -- log
    COLLECT_HOUSE_FULL                 = 140,  --司令,收藏仓库已满
    COLLECT_HOUSE_EXIST                = 141,  --司令,该记录收藏仓库存在
    -- furniture
    FURNITURE_EXIST                    = 150,  --司令,仓库已经有了该家具
    -- mail
    MAIL_NO_ERROR                      = 160,
    MAIL_HAVE_GET_REWARD               = 161,  --司令,奖励已经领取
    MAIL_NOT_EXIST                     = 162,  --司令,邮件不存在
    MAIL_POOL_FULL                     = 163,  --司令,邮件池容量不足
    MAIL_BOX_FULL                      = 164,  --司令,邮箱已满,快去清理邮件吧
    -- card
    FEELING_MAX                        = 170,  --司令,好感度已经达到上限了
    NOT_SUITABLE_RING                  = 171,  --司令,没有合适的戒指结婚!
    CARD_LEVEL_NOT_ENOUGH              = 172,  --司令,卡牌等级不足!
    CARD_NOT_IN_TEAM                   = 173,  --司令,卡牌已经不在队伍里!
    CARD_POSITION_PRODUCING            = 174,  --司令,建造栏已经有坦克正在建造中
    CARD_POSITION_NO_CARD              = 175,  --司令,该建造栏没有坦克可以领取
    CARD_NOT_FINISH_PRODUCING          = 176,  --司令,卡牌还没建造完成
    CARD_HAVE_MARRIED                  = 177,  --司令,卡牌已经结婚
    -- expedition
    EXPEDITION_COUNT_NOT_ENNOGH        = 180,  --司令,远征队伍成员数量不足
    EXPEDITION_LEADER_LEVEL            = 181,  --司令,队长等级不足
    EXPEDITION_LEADER_TYPE             = 182,  --司令,队长类型不对
    EXPEDITION_MENBER_TYPE             = 183,  --司令,队伍成员类型不对应
    EXPEDITION_AVERAGE_LEVEL           = 184,  --司令,队伍平均等级不足
    EXPEDITION_NOT_EXIST               = 185,  --司令,远征不存在
    EXPEDITION_NOT_FINISH              = 186,  --司令,远征还没结束
    EXPEDITION_CD_TIME                 = 187,  --司令,刷新CD时间还没有结束
    EXPEDITION_FIGHT_TIME              = 188,  --司令,抢夺次数不足
    EXPEDITION_HAVE_FIGHT              = 189,  --司令,当前远征点已经抢夺过了
    EXPEDITION_CACHE_INVALID           = 190,  --司令,缓存已经过期,请重新刷新
    EXPEDITION_IS_ENTER                = 191,  --司令,远征点已经有队伍在远征中
    EXPEDITION_NODE_NOT_EXIST          = 192,  --司令,远征点暂无队伍远征中
    --exercise
    EXERCISE_TARGET_FIGHTED            = 200,  --司令,对方角色已经挑战过
    --skill
    SKILL_NOT_FULL                     = 210,  --司令,需要补给满才可交换
    SKILL_SAME_EXIST                   = 211,  --司令,相同类型的技能已经存在
    SKILL_IS_ENTER                     = 212,  --司令,选择技能已经在司令部上
    --streng
    STRENG_COST_CARD_NOT_EXIST         = 220,  --司令,卡牌已经销毁了
    -- equip
    EQUIP_IN_CARD                      = 230,  --司令,装备已经在其他的坦克中
    EQUIP_CANNOT_BREAK                 = 231,  --司令,存在装备不可废弃
    EQUIP_DEVELOP_NOT_SUITABLE         = 232,  --司令,资源公式无法产生装备
    CARD_HAS_EQUIP                     = 233,  --司令,该位置已有装备 
    EQUIP_NOT_EXIST                    = 234,  --司令,装备已经不存在
    -- sign
    TODAY_ALREADY_SIGN                 = 240,  --司令，您本日已经签过到了
    -- item equip
    CARD_HAS_ITEM_EQUIP                = 250,  --司令,道具已经在坦克中
    CARD_MOUNT_ITEM_EXPEDITION         = 251,  --司令,坦克还在远征中
    CARD_NOT_EXIST                     = 252,  --司令,卡牌不存在
    CARD_NOT_MOUNT_ITEM                = 253,  --司令,还没有挂载道具呢
    CARD_ITEM_NOT_MOUNT_TYPE           = 254,  --司令,道具能不挂载哟
    CARD_MOUNT_ITEM_COST_FAIL          = 255,  --司令,道具使用失败
    --food
    NO_COOK_TIMES                      = 256,   --司令，次数不足

    --skin
    SKIN_ALREADY_BUY                   = 257,   --司令，皮肤已经购买过
    -- shop
    SHOP_BUY_TIMES_LIMITED             = 260,   --司令，商品购买数量不足
    --secertary
    IS_SECRETARY_CARD                  = 270,   --司令,该坦克已被指定
    ALREADY_SIGN_IN                    = 271,   --司令,今日已签到过了
    -- training
    TRAINING_IS_FIGHT                  = 280,   --司令,当前卡牌已经经过训练了
    TRAINING_NOT_CARD                  = 281,   --司令,您还没获取卡牌，不可训练
}
