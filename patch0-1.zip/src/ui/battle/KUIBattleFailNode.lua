--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBattleFailNode.lua
--  Creator     : Jiang XuFeng
--  Date        : 2015/08/31   16:12
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIBattleFailNode = class(
    "KUIBattleFailNode" , function() return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBattleFailNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIBattleFailNode.create(owner, leftTeam)
    local currentNode = KUIBattleFailNode.new()
    
    currentNode._parent     = owner
    currentNode._leftTeam   = leftTeam
    currentNode._uiPath     = "res/ui/battle_fail.csb"
    currentNode:init()
    
    return currentNode
end

local function refreshDamagedImage(self)
    local leftTeam          = self._leftTeam
    local leaderName        = leftTeam[1].nTemplateID
    local cardImagePath
    if leftTeam[1].bIsRole then
        cardImagePath       = KUtil.getCardImagePathByConfigID(leaderName, true, leftTeam[1].nSkinTemplateID)
    else
        cardImagePath       = KUtil.getMonsterImagePathByConfigID(leaderName, false, leftTeam[1].nCurrentHP)
    end
    local mainNode          = self._mainLayout
    local panelDamagedImage = mainNode:getChildByName("Panel_damagedimage")
    local imageDamaged      = panelDamagedImage:getChildByName("Image_damagedimage")
    imageDamaged:loadTexture(cardImagePath)
end

local function refreshTextArea(self)
    local leftTeam          = self._leftTeam
    local leaderName        = leftTeam[1].nTemplateID
    local cardImagePath     = KUtil.getCardImagePathByConfigID(leaderName, true, leftTeam[1].nSkinTemplateID)
    local mainNode          = self._mainLayout
    local imageFailBase     = mainNode:getChildByName("Image_fail_base")
    local textLeaderName    = imageFailBase:getChildByName("Text_leader_name")
    local textTeamName      = imageFailBase:getChildByName("Text_team_name")
    if leftTeam.teamIndex then
        local teamName = KUtil.getTeamName(leftTeam.teamIndex)
        textTeamName:setString(teamName)
        textLeaderName:setString(KConfig["cardInfo"][leaderName]["szName"])
    else
        local tMonsterGroupSetting = KConfig:getLine("monstergroup", leftTeam.nMonsterGroupID)
        textTeamName:setString(tMonsterGroupSetting.szName)
        textLeaderName:setString(KConfig["monster"][leaderName]["szName"])
    end
    local textDialog        = imageFailBase:getChildByName("Text_dialog")
    textDialog:setString("司令……我们已经无法前进了……")
end

function KUIBattleFailNode:refreshUI()
    refreshDamagedImage(self)
    refreshTextArea(self)
end

function KUIBattleFailNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local buttonClose   = mainNode:getChildByName("Button_close")
    
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            local officeScene = require("src/ui/office/KUIOfficeScene").create("BattleFail")
            KUtil.replaceSceneAndRemoveAllTexture(officeScene)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

return KUIBattleFailNode