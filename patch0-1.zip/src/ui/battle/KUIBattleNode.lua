--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBattleNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/20   16:21
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************

local m_tButtonStateTexture = {
    ["buttonNormalTexture"]   = "res/ui/ui_material/battle/button_skills1_v1.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/battle/button_skills2_v1.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/battle/button_skills3_v1.png"
}

local MAX_CARD_COUNT_PER_TEAM = 6
local KUIBattleNode = class(
    "KUIBattleNode" , function() return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBattleNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    
    self._backgroundType = nil
end

function KUIBattleNode.create(owner, userData)
    local currentNode = KUIBattleNode.new()
    local fnEndCallback = userData.endCallback
    
    local function endCallback(tBattleResult)
        if fnEndCallback then
            fnEndCallback(tBattleResult)
        else
            owner:removeNode("Battle")
        end
    end

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/battle.csb"
    currentNode._tBattleManager = require("src/battle/KBattleManager").new(userData, currentNode, endCallback)
    currentNode:init()
    
    return currentNode
end

function KUIBattleNode:setNightBattleCallBack(fnCallback)
    self._nightBattleCallback = fnCallback
end

function KUIBattleNode:setBattleBackground(backgroundType, isNight)
    local mainNode          = self._mainLayout
    local nodeBackGround    = mainNode:getChildByName("Node_backgrond")
    local imageBackground   = nodeBackGround:getChildByName("Image_backgrond")
    local imagePath         = KUtil.getBattleBackgroundImagePath(backgroundType, isNight)
    local curPixeQuality    = KUtil.getPixelQuality()
    if curPixeQuality ~= KUtil.PIXEL_QUALITY.HIGH then
        local imageBackgroundShadow = nodeBackGround:getChildByName("Image_background_shaow")
        imageBackgroundShadow:setVisible(false)
    end
    imageBackground:loadTexture(imagePath)
    self._backgroundType = backgroundType

    -- reset background music
    local musicPath = self._tBattleManager.fightMusic
    if isNight then
        musicPath = self._tBattleManager.nightFightMusic
    end
    KSound.playBattleMusic(musicPath)
end

local function initTeamAction(self, nodeTeamUnit, actionArrayName, battleUnitName)
    print("-----> initTeamAction", nodeTeamUnit, actionArrayName, battleUnitName)
    for index = 1, MAX_CARD_COUNT_PER_TEAM do
        print("--> index", index, "start")
        -- card action
        local projectNodeTeamUnit   = nodeTeamUnit:getChildByName("ProjectNode_unit_" .. index)
        --projectNodeTeamUnit:setVisible(false)
        --projectNodeTeamUnit:setPosition(cc.p(projectNodeTeamUnit:getPositionX() - 900, projectNodeTeamUnit:getPositionY()))
        local actionTeam       = cc.CSLoader:createTimeline("res/ui/" .. battleUnitName .. ".csb")
        projectNodeTeamUnit:stopAllActions()
        projectNodeTeamUnit:runAction(actionTeam)
        if not self[actionArrayName] then self[actionArrayName] = {} end
        if not self[actionArrayName][index] then self[actionArrayName][index] = {} end
        local cardInitPositionFrame = 5
        local cardHideFrame = 0
        self[actionArrayName][index].actionCard = actionTeam
        self[actionArrayName][index].actionCard.actionNode = projectNodeTeamUnit
        self[actionArrayName][index].actionCard:gotoFrameAndPause(cardHideFrame)
        --self[actionArrayName][index].actionCard:gotoFrameAndPause(30)

        -- detect exclamation action
        local panelUnit = projectNodeTeamUnit:getChildByName("Panel_unit")
        local projectNodeExclamation = panelUnit:getChildByName("ProjectNode_exclamation")
        projectNodeExclamation:setVisible(false)
        local actionExclamation     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_exclamation.csb")
        projectNodeExclamation:stopAllActions()
        projectNodeExclamation:runAction(actionExclamation)
        self[actionArrayName][index].actionExclamation = actionExclamation
        self[actionArrayName][index].actionExclamation.actionNode = projectNodeExclamation
        self[actionArrayName][index].actionExclamation:gotoFrameAndPause(0)

        if battleUnitName == "battle_unit" then
            -- skill supply animation
            local projectNodeSkillSupply = panelUnit:getChildByName("ProjectNode_ani_skill_supply_value")
            projectNodeSkillSupply:setVisible(false)
            local actionSkillSupply     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skill_supply_value.csb")
            projectNodeSkillSupply:stopAllActions()
            projectNodeSkillSupply:runAction(actionSkillSupply)
            self[actionArrayName][index].actionSkillSupply = actionSkillSupply
            self[actionArrayName][index].actionSkillSupply.actionNode = projectNodeSkillSupply
            self[actionArrayName][index].actionSkillSupply:gotoFrameAndPause(0)

            -- lack supply notice
            local projectNodeLackSupply = panelUnit:getChildByName("ProjectNode_ani_skill_lack_supply")
            projectNodeLackSupply:setVisible(false)
            local actionLackSupply     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_skill_lack_supply.csb")
            projectNodeLackSupply:stopAllActions()
            projectNodeLackSupply:runAction(actionLackSupply)
            self[actionArrayName][index].actionLackSupply = actionLackSupply
            self[actionArrayName][index].actionLackSupply.actionNode = projectNodeLackSupply
            self[actionArrayName][index].actionLackSupply:gotoFrameAndPause(0)

            -- skill repair white light
            local projectNodeRepairBrushLight = panelUnit:getChildByName("ProjectNode_ani_battle_skill_repair_HP")
            projectNodeRepairBrushLight:setVisible(false)
            local actionRepairBrushLight     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_repair_brushlight.csb")
            projectNodeRepairBrushLight:stopAllActions()
            projectNodeRepairBrushLight:runAction(actionRepairBrushLight)
            self[actionArrayName][index].actionRepairBrushLight = actionRepairBrushLight
            self[actionArrayName][index].actionRepairBrushLight.actionNode = projectNodeRepairBrushLight
            self[actionArrayName][index].actionRepairBrushLight:gotoFrameAndPause(0)

            -- skill repair hp word
            local projectNodeRepairHpWord = panelUnit:getChildByName("ProjectNode_ani_battle_skill_repair_HP_word")
            projectNodeRepairHpWord:setVisible(false)
            local actionRepairHpWord     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_skill_repair_HP_word.csb")
            projectNodeRepairHpWord:stopAllActions()
            projectNodeRepairHpWord:runAction(actionRepairHpWord)
            self[actionArrayName][index].actionRepairHpWord = actionRepairHpWord
            self[actionArrayName][index].actionRepairHpWord.actionNode = projectNodeRepairHpWord
            self[actionArrayName][index].actionRepairHpWord:gotoFrameAndPause(0)  
        end

        -- card critical action
        local projectNodeCritical   = projectNodeTeamUnit:getChildByName("ProjectNode_critical")
        projectNodeCritical:setVisible(false)
        local actionCritical        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ap_critical.csb")
        projectNodeCritical:stopAllActions()
        projectNodeCritical:runAction(actionCritical)
        self[actionArrayName][index].actionCritical = actionCritical
        self[actionArrayName][index].actionCritical.actionNode = projectNodeCritical
        self[actionArrayName][index].actionCritical:gotoFrameAndPause(0)

        -- left damage
        local projectNodeLeftHurt   = projectNodeTeamUnit:getChildByName("ProjectNode_left")
        projectNodeLeftHurt:setVisible(false)
        local actionLeftHurt        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ap_left.csb")
        projectNodeLeftHurt:stopAllActions()
        projectNodeLeftHurt:runAction(actionLeftHurt)
        self[actionArrayName][index].actionLeftHurt = actionLeftHurt
        self[actionArrayName][index].actionLeftHurt.actionNode = projectNodeLeftHurt
        self[actionArrayName][index].actionLeftHurt:gotoFrameAndPause(0)

        -- middle   damage
        local projectNodeMiddleHurt = projectNodeTeamUnit:getChildByName("ProjectNode_middle")
        projectNodeMiddleHurt:setVisible(false)
        local actionMiddleHurt      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ap_middle.csb")
        projectNodeMiddleHurt:stopAllActions()
        projectNodeMiddleHurt:runAction(actionMiddleHurt)
        self[actionArrayName][index].actionMiddleHurt = actionMiddleHurt
        self[actionArrayName][index].actionMiddleHurt.actionNode = projectNodeMiddleHurt
        self[actionArrayName][index].actionMiddleHurt:gotoFrameAndPause(0)

        -- normal   damage
        local projectNodeNormalHurt = projectNodeTeamUnit:getChildByName("ProjectNode_normal")
        projectNodeNormalHurt:setVisible(false)
        local actionNormalHurt      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ap_normal.csb")
        projectNodeNormalHurt:stopAllActions()
        projectNodeNormalHurt:runAction(actionNormalHurt)
        self[actionArrayName][index].actionNormalHurt = actionNormalHurt
        self[actionArrayName][index].actionNormalHurt.actionNode = projectNodeNormalHurt
        self[actionArrayName][index].actionNormalHurt:gotoFrameAndPause(0)

        -- right    damage
        local projectNodeRightHurt  = projectNodeTeamUnit:getChildByName("ProjectNode_right")
        projectNodeRightHurt:setVisible(false)
        local actionRightHurt       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ap_right.csb")
        projectNodeRightHurt:stopAllActions()
        projectNodeRightHurt:runAction(actionRightHurt)
        self[actionArrayName][index].actionRightHurt = actionRightHurt
        self[actionArrayName][index].actionRightHurt.actionNode = projectNodeRightHurt
        self[actionArrayName][index].actionRightHurt:gotoFrameAndPause(0)

        -- card explosion action
        local projectNodeExplosion  = projectNodeTeamUnit:getChildByName("ProjectNode_explosion")
        projectNodeExplosion:setVisible(false)
        local actionExplosion       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_baozha.csb")
        projectNodeExplosion:stopAllActions()
        projectNodeExplosion:runAction(actionExplosion)
        self[actionArrayName][index].actionExplosion = actionExplosion
        self[actionArrayName][index].actionExplosion.actionNode = projectNodeExplosion
        self[actionArrayName][index].actionExplosion:gotoFrameAndPause(0)

        -- normal fire action
        local panelUnit             = projectNodeTeamUnit:getChildByName("Panel_unit")
        local projectNodeNormalFire = panelUnit:getChildByName("ProjectNode_Fire_1")
        projectNodeNormalFire:setVisible(false)
        local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_tankekaipao.csb")
        projectNodeNormalFire:stopAllActions()
        projectNodeNormalFire:runAction(actionNormalFire)
        self[actionArrayName][index].actionNormalFire = actionNormalFire
        self[actionArrayName][index].actionNormalFire.actionNode = projectNodeNormalFire
        self[actionArrayName][index].actionNormalFire:gotoFrameAndPause(0)
        --self[actionArrayName][index].actionNormalFire:gotoFrameAndPlay(0, 20, true)
	
        -- card explosion2 action
        local projectNodeExplosionBig  = projectNodeTeamUnit:getChildByName("ProjectNode_explosion_1")
        projectNodeExplosionBig:setVisible(false)
        local actionExplosionBig       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_baozha_2.csb")
        projectNodeExplosionBig:stopAllActions()
        projectNodeExplosionBig:runAction(actionExplosionBig)
        self[actionArrayName][index].actionExplosionBig = actionExplosionBig
        self[actionArrayName][index].actionExplosionBig.actionNode = projectNodeExplosionBig
        self[actionArrayName][index].actionExplosionBig:gotoFrameAndPause(0)

        -- huopao fire action
        local projectNodeHuoPaoFire = projectNodeTeamUnit:getChildByName("ProjectNode_Fire_2")
        projectNodeHuoPaoFire:setVisible(false)
        local actionHuoPaoFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_huopaokaipao.csb")
        projectNodeHuoPaoFire:stopAllActions()
        projectNodeHuoPaoFire:runAction(actionHuoPaoFire)
        self[actionArrayName][index].actionHuoPaoFire = actionHuoPaoFire
        self[actionArrayName][index].actionHuoPaoFire.actionNode = projectNodeHuoPaoFire
        self[actionArrayName][index].actionHuoPaoFire:gotoFrameAndPause(0)
        --self[actionArrayName][index].actionHuoPaoFire:gotoFrameAndPlay(0, 20, true)
        
        -- ricochet action
        local projectNodeRicochet = projectNodeTeamUnit:getChildByName("ProjectNode_ricochet")
        projectNodeRicochet:setVisible(false)
        local actionRicochet
        if actionArrayName == "_actionLeftTeam" then 
            actionRicochet  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ricochet_2.csb")
        else
            actionRicochet  = cc.CSLoader:createTimeline("res/ui/animation_node/ani_ricochet_1.csb")
        end
        projectNodeRicochet:stopAllActions()
        projectNodeRicochet:runAction(actionRicochet)
        self[actionArrayName][index].actionRicochet = actionRicochet
        self[actionArrayName][index].actionRicochet.actionNode = projectNodeRicochet
        self[actionArrayName][index].actionRicochet:gotoFrameAndPause(0)

        -- smoke action
        local projectNodeSmoke   = projectNodeTeamUnit:getChildByName("ProjectNode_bomb_smoke")
        projectNodeSmoke:setVisible(false)
        local actionSmoke        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_bomb_smoke.csb")
        projectNodeSmoke:stopAllActions()
        projectNodeSmoke:runAction(actionSmoke)
        self[actionArrayName][index].actionSmoke = actionSmoke
        self[actionArrayName][index].actionSmoke.actionNode = projectNodeSmoke
        self[actionArrayName][index].actionSmoke:gotoFrameAndPause(0)
        print("--> index", index, "end")

        -- emergency repair
        local projectNodeEmergencyRepair = projectNodeTeamUnit:getChildByName("ProjectNode_emergency_repair")
        projectNodeEmergencyRepair:setVisible(false)
        local actionEmergencyRepair      
        if actionArrayName == "_actionLeftTeam" then
            actionEmergencyRepair = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_emergency_repair_v2.csb")
        else
            actionEmergencyRepair = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_emergency_repair_v2_enemy.csb")
        end
        projectNodeEmergencyRepair:stopAllActions()
        projectNodeEmergencyRepair:runAction(actionEmergencyRepair)
        self[actionArrayName][index].actionEmergencyRepair = actionEmergencyRepair
        self[actionArrayName][index].actionEmergencyRepair.actionNode = projectNodeEmergencyRepair
        self[actionArrayName][index].actionEmergencyRepair:gotoFrameAndPause(0)

        -- strike target 
        local panelBattleSkill = panelUnit:getChildByName("Panel_battle_skill")
        local projectNodeStrikeTarget = panelBattleSkill:getChildByName("ProjectNode_strike_target")
        projectNodeStrikeTarget:setVisible(false)
        local actionStrikeTarget
        actionStrikeTarget = cc.CSLoader:createTimeline("res/ui/animation_node/ani_strike_target.csb")
        projectNodeStrikeTarget:stopAllActions()
        projectNodeStrikeTarget:runAction(actionStrikeTarget)
        self[actionArrayName][index].actionStrikeTarget = actionStrikeTarget
        self[actionArrayName][index].actionStrikeTarget.actionNode = projectNodeStrikeTarget
        self[actionArrayName][index].actionStrikeTarget:gotoFrameAndPause(0)

        -- graze spark action
        local projectNodeGrazeSpark = projectNodeTeamUnit:getChildByName("ProjectNode_graze_spark")
        projectNodeGrazeSpark:setVisible(false)
        local actionGrazeSpark
        if actionArrayName == "_actionLeftTeam" then 
            actionGrazeSpark = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_graze_spark.csb")
        else
            actionGrazeSpark = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_graze_spark_enemy.csb")
        end
        projectNodeGrazeSpark:stopAllActions()
        projectNodeGrazeSpark:runAction(actionGrazeSpark)
        self[actionArrayName][index].actionGrazeSpark = actionGrazeSpark
        self[actionArrayName][index].actionGrazeSpark.actionNode = projectNodeGrazeSpark
        self[actionArrayName][index].actionGrazeSpark:gotoFrameAndPause(0)

        -- skill buff
        local panelBattleSkill = panelUnit:getChildByName("Panel_battle_skill")
        local ProjectNodeSkillBuff = panelBattleSkill:getChildByName("ProjectNode_skill_buff")
        ProjectNodeSkillBuff:setVisible(false)

        -- skill light
        local panelBattleSkill = panelUnit:getChildByName("Panel_battle_skill")
        local ProjectNodeSkillBuff = panelBattleSkill:getChildByName("ProjectNode_skill_light")
        ProjectNodeSkillBuff:setVisible(false)
    end
end

local function initUIAction(self)
    local mainNode  = self._mainLayout
    
    -- character heavy hurt action
    local projectNodeCharacterHeavyHurt = mainNode:getChildByName("ProjectNode_destruction")
    projectNodeCharacterHeavyHurt:setVisible(false)
    local actionCharacterHeavyHurt      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_destruction.csb")
    projectNodeCharacterHeavyHurt:stopAllActions()
    projectNodeCharacterHeavyHurt:runAction(actionCharacterHeavyHurt)
    self._actionCharacterHeavyHurt = actionCharacterHeavyHurt
    self._actionCharacterHeavyHurt.actionNode = projectNodeCharacterHeavyHurt
    self._actionCharacterHeavyHurt:gotoFrameAndPause(0)

    -- start game text action
    local projectNodeStartBattle   = mainNode:getChildByName("ProjectNode_start_battle")
    projectNodeStartBattle:setVisible(false)
    local actionStartBattle = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_start.csb")
    projectNodeStartBattle:stopAllActions()
    projectNodeStartBattle:runAction(actionStartBattle)
    self._actionStartBattle = actionStartBattle
    self._actionStartBattle.actionNode = projectNodeStartBattle
    self._actionStartBattle:gotoFrameAndPause(0)
    
    -- detect action
    local projectNodeDetect = mainNode:getChildByName("ProjectNode_detect")
    projectNodeDetect:setVisible(false)
    local actionDetect      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_detect.csb")
    projectNodeDetect:stopAllActions()
    projectNodeDetect:runAction(actionDetect)
    self._actionDetect = actionDetect
    self._actionDetect.actionNode = projectNodeDetect
    self._actionDetect:gotoFrameAndPause(0)
    
    -- gate action
    local projectNodeGate   = mainNode:getChildByName("ProjectNode_gate")
    --projectNodeGate:setVisible(false)
    local actionNodeGate    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_gate.csb")
    local gateClosedFrame = 30
    projectNodeGate:stopAllActions()
    projectNodeGate:runAction(actionNodeGate)
    self._actionNodeGate = actionNodeGate
    self._actionNodeGate.actionNode = projectNodeGate
    self._actionNodeGate:gotoFrameAndPause(gateClosedFrame)
    --self._actionNodeGate:gotoFrameAndPause(0)
    
    -- attack action
    local nodeAttack            = mainNode:getChildByName("Node_cross")
    local projectNodeLeftAttack = nodeAttack:getChildByName("ProjectNode_cross_ally")
    projectNodeLeftAttack:setVisible(false)
    local actionLeftAttack      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_bule_cross.csb")
    projectNodeLeftAttack:stopAllActions()
    projectNodeLeftAttack:runAction(actionLeftAttack)
    self._actionLeftAttack = actionLeftAttack
    self._actionLeftAttack.actionNode = projectNodeLeftAttack
    self._actionLeftAttack:gotoFrameAndPause(0)
    
    local projectNodeRightAttack    = nodeAttack:getChildByName("ProjectNode_cross_enemy")
    projectNodeRightAttack:setVisible(false)
    local actionRightAttack         = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_red_cross.csb")
    projectNodeRightAttack:stopAllActions()
    projectNodeRightAttack:runAction(actionRightAttack)
    self._actionRightAttack = actionRightAttack
    self._actionRightAttack.actionNode = projectNodeRightAttack
    self._actionRightAttack:gotoFrameAndPause(0)

    -- ability action 
    local nodeAbility   = mainNode:getChildByName("ProjectNode_train_buff")
    nodeAbility:setVisible(false)
    local actionAbility = cc.CSLoader:createTimeline("res/ui/animation_node/ani_train_battle_buff.csb")
    nodeAbility:stopAllActions()
    nodeAbility:runAction(actionAbility)
    self._actionUseAbility = actionAbility
    self._actionUseAbility.actionNode = nodeAbility
    self._actionUseAbility:gotoFrameAndPause(0)

    -- combo action
    local nodeCombo             = mainNode:getChildByName("Node_skill")
    local projectNodeLeftCombo  = nodeCombo:getChildByName("ProjectNode_skill_ally")
    projectNodeLeftCombo:setVisible(false)
    local actionLeftCombo       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_night_skill_v1.csb")
    projectNodeLeftCombo:stopAllActions()
    projectNodeLeftCombo:runAction(actionLeftCombo)
    self._actionLeftCombo = actionLeftCombo
    self._actionLeftCombo.actionNode = projectNodeLeftCombo
    self._actionLeftCombo:gotoFrameAndPause(0)
    
    local projectNodeRightCombo = nodeCombo:getChildByName("ProjectNode_skill_enemy")
    projectNodeRightCombo:setVisible(false)
    local actionRightCombo      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_night_skill_v1_enemy.csb")
    projectNodeRightCombo:stopAllActions()
    projectNodeRightCombo:runAction(actionRightCombo)
    self._actionRightCombo = actionRightCombo
    self._actionRightCombo.actionNode = projectNodeRightCombo
    self._actionRightCombo:gotoFrameAndPause(0)
    
    -- lineup action
    local nodeLineup            = mainNode:getChildByName("Node_below")
    local projectNodeLeftLineup = nodeLineup:getChildByName("ProjectNode_below_ally")
    projectNodeLeftLineup:setVisible(false)
    local actionLeftLineup      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_blue_below.csb")
    projectNodeLeftLineup:stopAllActions()
    projectNodeLeftLineup:runAction(actionLeftLineup)
    self._actionLeftLineup = actionLeftLineup
    self._actionLeftLineup.actionNode = projectNodeLeftLineup
    self._actionLeftLineup:gotoFrameAndPause(0)
    
    local projectNodeRightLineup    = nodeLineup:getChildByName("ProjectNode_below_enemy")
    projectNodeRightLineup:setVisible(false)
    local actionRightLineup         = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_red_upper.csb")
    projectNodeRightLineup:stopAllActions()
    projectNodeRightLineup:runAction(actionRightLineup)
    self._actionRightLineup = actionRightLineup
    self._actionRightLineup.actionNode = projectNodeRightLineup
    self._actionRightLineup:gotoFrameAndPause(0)

    -- lineup text action
    local projectNodeLineupText = mainNode:getChildByName("ProjectNode_character")
    projectNodeLineupText:setVisible(false)
    local actionLineupText      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_character.csb")
    projectNodeLineupText:stopAllActions()
    projectNodeLineupText:runAction(actionLineupText)
    self._actionLineupText = actionLineupText
    self._actionLineupText.actionNode = projectNodeLineupText
    self._actionLineupText:gotoFrameAndPause(0)

    -- radar action
    local nodeRadar             = mainNode:getChildByName("Node_radar_base")
    local projectNodeLeftRadar  = nodeRadar:getChildByName("ProjectNode_radar_ally")
    --projectNodeLeftRadar:setVisible(false)
    local actionLeftRadar       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_radar_ally.csb")
    projectNodeLeftRadar:stopAllActions()
    projectNodeLeftRadar:runAction(actionLeftRadar)
    self._actionLeftRadar = actionLeftRadar
    self._actionLeftRadar.actionNode = projectNodeLeftRadar
    self._actionLeftRadar:gotoFrameAndPause(0)

    local projectNodeRightRadar = nodeRadar:getChildByName("ProjectNode_radar_enemy")
    --projectNodeRightRadar:setVisible(false)
    local actionRightRadar      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_radar_enemy.csb")
    projectNodeRightRadar:stopAllActions()
    projectNodeRightRadar:runAction(actionRightRadar)
    self._actionRightRadar = actionRightRadar
    self._actionRightRadar.actionNode = projectNodeRightRadar
    self._actionRightRadar:gotoFrameAndPause(0)

    -- skill action
    local projectNodeSkill      = mainNode:getChildByName("ProjectNode_active_skills")
    --projectNodeSkill:setVisible(false)
    local actionSkill           = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_active_skills_v1.csb")
    projectNodeSkill:stopAllActions()
    projectNodeSkill:runAction(actionSkill)
    self._actionSkill = actionSkill
    self._actionSkill.actionNode = projectNodeSkill
    local actionSkillDuration = self._actionSkill:getDuration()
    --self._actionSkill:gotoFrameAndPlay(0, actionSkillDuration, false)
    self._actionSkill:gotoFrameAndPause(0)

    -- left card unit action
    local nodeLeftTeamUnit  = mainNode:getChildByName("Node_ally_unit")
    initTeamAction(self, nodeLeftTeamUnit, "_actionLeftTeam", "battle_unit")

    -- right card unit action
    local nodeRightTeamUnit = mainNode:getChildByName("Node_enemy_unit")
    initTeamAction(self, nodeRightTeamUnit, "_actionRightTeam", "battle_unit_1")
    --local actionEndFrame = self._actionRightTeam[3].actionNormalFire:getDuration()
    --self._actionRightTeam[3].actionNormalFire:gotoFrameAndPlay(0, actionEndFrame, true)
    --local actionEndFrame = self._actionRightTeam[6].actionNormalFire:getDuration()

    -- battle title
    local projectNodeBattleStep = mainNode:getChildByName("ProjectNode_title_base")
    --projectNodeBattleStep:setVisible(false)
    local actionBattleStep      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_title.csb")
    projectNodeBattleStep:stopAllActions()
    projectNodeBattleStep:runAction(actionBattleStep)
    self._actionBattleStep = actionBattleStep
    self._actionBattleStep.actionNode = projectNodeBattleStep
    self._actionBattleStep:gotoFrameAndPause(0)

    local nodeDistanceRuler     = mainNode:getChildByName("Node_distance_ruler")
    -- tank distance ruler
    local projectNodeDistanceRuler  = nodeDistanceRuler:getChildByName("ProjectNode_distance_ruler")
    --projectNodeDistanceRuler:setVisible(false)
    local actionDistanceRuler   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_distance_ruler.csb")
    projectNodeDistanceRuler:stopAllActions()
    projectNodeDistanceRuler:runAction(actionDistanceRuler)
    self._actionDistanceRuler   = actionDistanceRuler
    self._actionDistanceRuler.actionNode   = projectNodeDistanceRuler
    self._actionDistanceRuler:gotoFrameAndPause(0)

    -- tank distance text
    local projectNodeDistanceText   = nodeDistanceRuler:getChildByName("ProjectNode_burning_track")
    --projectNodeDistanceText:setVisible(false)
    local actionDistanceText    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_battle_track.csb")
    projectNodeDistanceText:stopAllActions()
    projectNodeDistanceText:runAction(actionDistanceText)
    self._actionDistanceText    = actionDistanceText
    self._actionDistanceText.actionNode = projectNodeDistanceText
    self._actionDistanceText:gotoFrameAndPause(0)
end

local function initSkillButtonUI(self)
    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local tSrcTeam         = self._tBattleManager:getData():getLeftTeamData()
    local tSkillList       = tSrcTeam.tSkillList
    local nSkillCount      = #tSkillList

    for i = 1, MAX_SKILL_COUNT do
        local oneSkill = tSkillList[i]
        if not oneSkill then
            for j = i, MAX_SKILL_COUNT do
                local nButtonIndex = j
                local buttonSkill = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
                buttonSkill:setVisible(false)
            end
            break
        else
            local nButtonIndex = i
            local buttonSkill  = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
            buttonSkill:setVisible(true)

            for _, oneImage in ipairs(buttonSkill:getChildren()) do
                oneImage:setVisible(false)
            end

            local szEquipImagePath  = KUtil.getEquipImagePathByID(oneSkill.nEquipTemplateID)
            local nSkillID          = KUtil.getSkillID(oneSkill)
            local skillInfo         = KConfig.skill[nSkillID]
            local szSkillResPath    = skillInfo.szResPath
            local nLeftUseTimes     = oneSkill.nLeftTimes

            local imageSkillIcon = buttonSkill:getChildByName("image_skills_icon")
            imageSkillIcon:setVisible(true)
            imageSkillIcon:loadTexture(szEquipImagePath)

            local szSkillNodeName   = "Image_skill_" .. szSkillResPath
            local imageSkillName  = buttonSkill:getChildByName(szSkillNodeName)
            imageSkillName:setVisible(true)

            local textLeftTimes = buttonSkill:getChildByName("Text_remaining_number")
            textLeftTimes:setVisible(true)
            textLeftTimes:setString(nLeftUseTimes)
        end
    end
end

function KUIBattleNode:refreshSkillButtonUI(nPosition)
    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local tBattleManager   = self._tBattleManager
    local tBattleData      = tBattleManager:getData()
    local tSkillList       = tBattleData:getLeftTeamSkillList()
    local nSkillCount      = #tSkillList

    if nPosition then
        local oneSkill          = tSkillList[nPosition]
        local nEquipTemplateID  = oneSkill.nEquipTemplateID
        local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
        local nSkillID          = equipConfig.nSkill
        local nLeftUseTimes     = oneSkill.nLeftTimes

        local nButtonIndex  = nPosition
        local buttonSkill   = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
        local textLeftTimes = buttonSkill:getChildByName("Text_remaining_number")
        textLeftTimes:setString(nLeftUseTimes)

        local bIsLeftTeam  = true
        local bCanUseSkill = (tBattleData:canUseSkill(oneSkill, bIsLeftTeam) and tBattleManager:canUseSkill(bIsLeftTeam, nSkillID, tBattleData))
        if bCanUseSkill then
            KUtil.setTouchEnabled(buttonSkill, true)
        elseif oneSkill.nState == SKILL_STATE.UNUSED then
            KUtil.setTouchEnabled(buttonSkill, false)
        end
        return
    end

    for i = 1, MAX_SKILL_COUNT do
        local oneSkill = tSkillList[i]
        if not oneSkill then
            break
        else
            local nEquipTemplateID  = oneSkill.nEquipTemplateID
            local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
            local nSkillID          = equipConfig.nSkill
            local nLeftUseTimes     = oneSkill.nLeftTimes

            local nButtonIndex  = i
            local buttonSkill   = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
            local textLeftTimes = buttonSkill:getChildByName("Text_remaining_number")
            textLeftTimes:setString(nLeftUseTimes)

            local bIsLeftTeam  = true
            local bCanUseSkill = (tBattleData:canUseSkill(oneSkill, bIsLeftTeam) and tBattleManager:canUseSkill(bIsLeftTeam, nSkillID, tBattleData))
            if bCanUseSkill then
                KUtil.setTouchEnabled(buttonSkill, true)
            elseif oneSkill.nState == SKILL_STATE.UNUSED then
                KUtil.setTouchEnabled(buttonSkill, false)
            end
        end
    end

    return 
end

function KUIBattleNode:refreshSkillUseTimeUI(nPosition)
    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local tBattleManager   = self._tBattleManager
    local tBattleData      = tBattleManager:getData()
    local tSkillList       = tBattleData:getLeftTeamSkillList()

    local oneSkill          = tSkillList[nPosition]
    local nEquipTemplateID  = oneSkill.nEquipTemplateID
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local nSkillID          = equipConfig.nSkill
    local nLeftUseTimes     = oneSkill.nLeftTimes

    local nButtonIndex  = nPosition
    local buttonSkill   = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
    local textLeftTimes = buttonSkill:getChildByName("Text_remaining_number")
    textLeftTimes:setString(nLeftUseTimes)
    return
end

function KUIBattleNode:readySkillButtonUI(nPosition)
    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local nButtonIndex     = nPosition
    local buttonSkill      = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
    buttonSkill:setTouchEnabled(false)

    local imageSkillIcon = buttonSkill:getChildByName("image_skills_icon")
    imageSkillIcon:setVisible(true)
    local nodeReady = buttonSkill:getChildByName("ProjectNode_skill_ready")
    nodeReady:setVisible(true)
    local nodeBuff = buttonSkill:getChildByName("ProjectNode_skill_buff")
    nodeBuff:setVisible(false)
    return
end

function KUIBattleNode:buffSkillButtonUI(nPosition, szBuffType)
    if not szBuffType then return end

    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local nButtonIndex     = nPosition
    local buttonSkill      = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)
    buttonSkill:setTouchEnabled(false)

    local imageSkillIcon = buttonSkill:getChildByName("image_skills_icon")
    imageSkillIcon:setVisible(false)
    local nodeReady = buttonSkill:getChildByName("ProjectNode_skill_ready")
    nodeReady:setVisible(false)
    local nodeBuff = buttonSkill:getChildByName("ProjectNode_skill_buff")
    nodeBuff:setVisible(true)

    for _, node in ipairs(nodeBuff:getChildren()) do
        node:setVisible(false)
    end
    local panelEffect = nodeBuff:getChildByName("Panel_ef")
    panelEffect:setVisible(true)
    local buffName = "Image_buff_" .. szBuffType .. "_active"
    local nodeActiveBuff = nodeBuff:getChildByName(buffName)
    nodeActiveBuff:setVisible(true)

    buttonSkill:loadTextures(
        m_tButtonStateTexture.buttonPressTexture,
        m_tButtonStateTexture.buttonPressTexture,
        m_tButtonStateTexture.buttonPressTexture
    )

    return
end 

function KUIBattleNode:unabledSkillButtonUI(nPosition)
    local mainNode         = self._mainLayout
    local projectNodeSkill = mainNode:getChildByName("ProjectNode_active_skills")
    local panelSkillBase   = projectNodeSkill:getChildByName("Panel_skills_Base_2")
    local imageSkillBase   = panelSkillBase:getChildByName("image_skills_Base")
    local nButtonIndex     = nPosition
    local buttonSkill      = imageSkillBase:getChildByName("button_skills_" .. nButtonIndex)

    local imageSkillIcon = buttonSkill:getChildByName("image_skills_icon")
    imageSkillIcon:setVisible(true)
    local nodeReady = buttonSkill:getChildByName("ProjectNode_skill_ready")
    nodeReady:setVisible(false)
    local nodeBuff = buttonSkill:getChildByName("ProjectNode_skill_buff")
    nodeBuff:setVisible(false)

    buttonSkill:setTouchEnabled(false)
    buttonSkill:loadTextures(
        m_tButtonStateTexture.buttonDisableTexture,
        m_tButtonStateTexture.buttonDisableTexture,
        m_tButtonStateTexture.buttonDisableTexture
    )

    return
end

function KUIBattleNode:refreshDisenableArea()
    local mainNode = self._mainLayout
    local projectNodeActiveSkill    = mainNode:getChildByName("ProjectNode_active_skills")
    local panelActiveSkill          = projectNodeActiveSkill:getChildByName("Panel_skills_Base_2")
    local imageActiveSkill          = panelActiveSkill:getChildByName("image_skills_Base")
    for i = 1, MAX_SKILL_COUNT do
        local buttonActiveSkill         = imageActiveSkill:getChildByName("button_skills_" .. i)
        buttonActiveSkill:setVisible(false)
        buttonActiveSkill:setTouchEnabled(false)
    end
    
    for _, imageIcon in pairs(projectNodeActiveSkill:getChildren()) do
        imageIcon:setVisible(false)
        imageIcon:setOpacity(0)
    end
    projectNodeActiveSkill:setVisible(false)
    projectNodeActiveSkill:setOpacity(0)
end

function KUIBattleNode:changeNightBattleMenuVisible(isVisible)
    local mainNode = self._mainLayout
    local projectNodeNightFight = mainNode:getChildByName("ProjectNode_night_battle")
    projectNodeNightFight:setVisible(isVisible)

    self:changeNightBattleMenuTouchEnable(isVisible)
end

function KUIBattleNode:changeNightBattleMenuTouchEnable(isTouchEnable)
    local mainNode = self._mainLayout
    local projectNodeNightFight = mainNode:getChildByName("ProjectNode_night_battle")
    local nodeGiveUp = projectNodeNightFight:getChildByName("Node_give_up_pursuit")
    local buttonGiveUp = nodeGiveUp:getChildByName("Button_give_up_pursuit")
    buttonGiveUp:setTouchEnabled(isTouchEnable)

    local nodeStartNightFight = projectNodeNightFight:getChildByName("Node_start_night_battle")
    local buttonStartNightFight = nodeStartNightFight:getChildByName("Button_start_night_battle")
    buttonStartNightFight:setTouchEnabled(isTouchEnable)
end

function KUIBattleNode:startNightFight()
    KSound.playEffect("enterNightFight")
    assert(self._nightBattleCallback, "battleCallback is not set~")
    self:changeNightBattleMenuVisible(false)

    local cardList = self._tBattleManager:getData():getLeftTeamData()
    KSound.playTalk(KSound.TALK.NIGHTFIGHT, cardList[1].nTemplateID, not cardList[1].bIsRole)
    cclog("----------> onStartNightFight~")

    self._nightBattleCallback(true)
end

function KUIBattleNode:giveUpNightFight()
    KSound.playEffect("retreat")
    self:changeNightBattleMenuVisible(false)
    self._nightBattleCallback(false)
end

function KUIBattleNode:refreshUI()
    local mainNode          = self._mainLayout
    
    -- you can't refresh battle ui . Don't rewrite this but you know.
    -- If you have any problem, please email to : sunxun@kingsoft.com
    
    initUIAction(self)
    initSkillButtonUI(self)
    self:refreshSkillButtonUI()
    self:changeNightBattleMenuVisible(false)

    self._tBattleManager:resume()
end

function KUIBattleNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNodeNightFight         = mainNode:getChildByName("ProjectNode_night_battle")
    local nodeGiveUp                    = projectNodeNightFight:getChildByName("Node_give_up_pursuit")
    local buttonGiveUpNightFight        = nodeGiveUp:getChildByName("Button_give_up_pursuit")
    local nodeStartNightFight           = projectNodeNightFight:getChildByName("Node_start_night_battle")
    local buttonStartNightFight         = nodeStartNightFight:getChildByName("Button_start_night_battle")
    
    local function onStartNightFight(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        self:startNightFight()
    end
    buttonStartNightFight:addTouchEventListener(onStartNightFight)
    
    local function onGiveUpNightFight(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        self:giveUpNightFight()
    end
    buttonGiveUpNightFight:addTouchEventListener(onGiveUpNightFight)

    local projectNodeActiveSkill    = mainNode:getChildByName("ProjectNode_active_skills")
    local panelActiveSkill          = projectNodeActiveSkill:getChildByName("Panel_skills_Base_2")
    local imageActiveSkill          = panelActiveSkill:getChildByName("image_skills_Base")

    for i = 1, MAX_SKILL_COUNT do
        local nButtonIndex      = i
        local buttonActiveSkill = imageActiveSkill:getChildByName("button_skills_" .. nButtonIndex)

        local function onActiveSkill(sender, type)
            if type ~= ccui.TouchEventType.ended then return end

              self:castSkillByPosition(i)
        end
        buttonActiveSkill:addTouchEventListener(onActiveSkill)
    end
end

function KUIBattleNode:castSkillByPosition(nPosition)
    local tBattleManager    = self._tBattleManager
    if not tBattleManager.bSkillEnable then return end

    local bIsLeftTeam       = true
    local tBattleData       = tBattleManager:getData()
    local tSkillList        = tBattleData:getLeftTeamSkillList()
    local tOneSkill         = tSkillList[nPosition]

    local nEquipTemplateID  = tOneSkill.nEquipTemplateID
    local equipConfig       = KConfig.equipInfo[nEquipTemplateID]
    local nSkillID          = equipConfig.nSkill

    if tBattleData:canUseSkill(tOneSkill, bIsLeftTeam) and tBattleManager:canUseSkill(bIsLeftTeam, nSkillID, tBattleData) then
        tBattleData:useSkill(tOneSkill, bIsLeftTeam)
        self:refreshSkillUseTimeUI(nPosition)
        self:readySkillButtonUI(nPosition)
        tBattleManager:castSkill(bIsLeftTeam, nSkillID, nEquipTemplateID, nPosition)
        return
    end
end

function KUIBattleNode:registerAllCustomEvent()
end

function KUIBattleNode:runEnterAction()
end

return KUIBattleNode
