--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBattleReportNode_v4.lua
--  Creator     : HUANGYIXIN
--  Date        : 2015/12/24   15:30
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local PURSUE_TIP_LEVEL = 5
local moveActionTime   = 0.4

local KUIBattleReportNode = class(
    "KUIBattleReportNode" , function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBattleReportNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._cardList       = nil
    self._addMaxExp      = nil
    self._resultID       = nil 
    self._awardList      = nil
    self._greenPercent   = nil
    self._addRoleExp     = nil
    self._redPercent     = nil
    self._isPursue       = nil
    self._callback       = nil
    self._clickPanelCall = nil
    self._cardExpList    = nil
    self._tSrcTeam       = nil
    self._tDstTeam       = nil
    self._tNewCardList   = nil
    self._passMapAward   = nil
    self._mapID          = nil
    self._zoneID         = nil
    self._cardFeeling    = nil
end

function KUIBattleReportNode.create(owner)
    local currentNode = KUIBattleReportNode.new()
    currentNode._parent       = owner
    currentNode._addMaxExp    = 0
    currentNode._greenPercent = 0
    currentNode._redPercent   = 0
    currentNode._addRoleExp   = 0
    currentNode._isPursue     = false
    currentNode._uiPath = "res/ui/battle_report.csb"

    currentNode:init()
    return currentNode
end

local function getAliveOrDeadCard(cardID)
    local currentCard = KUtil.getCardById(cardID)

    if not currentCard then
        local tDeadCardList = KPlayer.tCardData.tDeadList
        currentCard = HArray.FindFirstByID(tDeadCardList, cardID)
    end
    return currentCard
end

local function getAddFeeling(self, cardID, isDead)
    if not self._cardFeeling then return 0 end
    if isDead then return 0 end
    return self._cardFeeling[cardID] or 0
end

local function setExpCoeUIVisible(self, expUIRoot, visible)
    local imageExpWithoutCoe = expUIRoot:getChildByName("Image_exp_message")
    local imageExpWithCoe    = expUIRoot:getChildByName("Image_exp_message_coe")
    local textUnitMultilple  = expUIRoot:getChildByName("Text_unit_multiple")

    textUnitMultilple:setVisible(visible)
    imageExpWithCoe:setVisible(visible)
    imageExpWithoutCoe:setVisible(not visible)
end

function KUIBattleReportNode:hideUI()
    local mainNode = self._mainLayout
    
    local imageEnemyBase = mainNode:getChildByName("Image_bg_report_base")
    imageEnemyBase:setVisible(false)

    local imageExpeditionBase = mainNode:getChildByName("Image_bg_expedition_base")
    mainNode:removeChild(imageExpeditionBase)

    local imageHpBase = mainNode:getChildByName("Image_bg_hp_base")
    imageHpBase:setVisible(false)

    local imagePointBg  = mainNode:getChildByName("Image_bg_point")
    imagePointBg:setVisible(false)

    local imageRankBase = mainNode:getChildByName("Image_rank_base")
    imageRankBase:setVisible(false)
    
    local buttonPursue = imageRankBase:getChildByName("Button_zhuji")
    buttonPursue:setVisible(false)

    local aniPursue = imageRankBase:getChildByName("ProjectNode_ani_choose_1")
    aniPursue:setVisible(false)

    local buttonRetreat = imageRankBase:getChildByName("Button_chetui")
    buttonRetreat:setVisible(false)

    local aniRetreat = imageRankBase:getChildByName("ProjectNode_ani_choose_2")
    aniRetreat:setVisible(false)
 end

local function playAudioEffect(self)
    local function playEffect()
        if self._resultID > FIGHT_SCORE.C then
            KSound.playEffect("battleWin")
        else
            KSound.playEffect("battleLose")
        end
    end
    delayExecute(self._mainLayout, playEffect, 2.5)
end

function KUIBattleReportNode:initAllyUnit(useUnit, data)
    local imageMvpBase = useUnit:getChildByName("Image_bg_mvp_base")
    local imageChara   = useUnit:getChildByName("ProjectNode_card")
    local textName     = useUnit:getChildByName("Text_tank_name")
    
    -- KUtil.onlyUpdateCardHeadBase(imageChara, tHeadInfo)
    local nCurrentHP
    local maxHp
    local tMonsterSetting
    if data.nID then
        local currentCard  = getAliveOrDeadCard(data.nID)
        local str = string.format("card not found, cardID:%d", data.nID)
        assert(currentCard, str)
        
        maxHp = KUtil.getCardMaxHp(currentCard)
        nCurrentHP = data.nHp or currentCard.nCurrentHP
        
        local tHeadInfo     = {["nID"] = currentCard.nID, ["nTemplateID"] = currentCard.nTemplateID, ["nSkinTemplateID"] = currentCard.nSkinTemplateID,
                                ["nCurrentHP"] = nCurrentHP, ["bRing"] = currentCard.bRing, ["nMaxHP"] = maxHp}
        KUtil.onlyUpdateCardHeadBase(imageChara, tHeadInfo)

        local tCardConfig = KUtil.getCardConfig(currentCard.nTemplateID)
        assert(tCardConfig, currentCard.nTemplateID)
        textName:setString(tCardConfig.szName)
    else
        tMonsterSetting = KConfig.monster[data.nTemplateID]
        assert(tMonsterSetting)
        -- local tOneCard  = HArray.FindFirstByID(self._tSrcTeam, data.nID)
        maxHp           = tMonsterSetting.nMaxHP

        nCurrentHP      = data.nHp
        KUtil.onlyUpdateCardHeadBaseByMonsterTemplateID(imageChara, data.nTemplateID, nCurrentHP)

        textName:setString(tMonsterSetting.szName)
    end

    if not data.bMVP then 
        useUnit:removeChild(imageMvpBase)
    else
        KSound.playTalk(KSound.TALK.MPV, data.nTemplateID, not data.nID)
    end

    local cardHPPercent = nCurrentHP / maxHp * 100

    local imageDamageBase = useUnit:getChildByName("Panel_common_damage")
    
    local hpName    = {nil, nil, nil, nil, nil}
    local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", "Image_common_damage_broken"}
    KUtil.drawCardState(nil, imageDamageBase, hpName, stateName, cardHPPercent)

    local smokeLevel = 50
    if cardHPPercent > smokeLevel then
        local projectNodeSmokeLeft = useUnit:getChildByName("ProjectNode_smoke_1")
        projectNodeSmokeLeft:stopAllActions()
        useUnit:removeChild(projectNodeSmokeLeft)

        local projectNodeSmokeRight = useUnit:getChildByName("ProjectNode_smoke_2")
        projectNodeSmokeRight:stopAllActions()
        useUnit:removeChild(projectNodeSmokeRight)
    end

    

    local textLevel = useUnit:getChildByName("Text_level_data")

    if data.nID then
        for _, var in ipairs(self._cardExpList) do
            if var.nID == data.nID then
                textLevel:setString(var.batteBeforeLevel)
                break
            end
        end
    else
        assert(tMonsterSetting)
        textLevel:setString(tMonsterSetting.nLevel)
    end

    local addFeeling = 0
    if data.nID then
        addFeeling = getAddFeeling(self, data.nID, data.bDead)
    end
    local projectNodeHeart = useUnit:getChildByName("ProjectNode_heart")
    local textNumber = projectNodeHeart:getChildByName("Text_num_1")
    textNumber:setString("+" .. addFeeling)
    projectNodeHeart:setVisible(addFeeling > 0)
end

function KUIBattleReportNode:refreshAllyBase()
    local mainNode = self._mainLayout   
    local imageAllyBase = mainNode:getChildByName("Image_bg_ally_base")

    local upLevelNode = imageAllyBase:getChildByName("ProjectNode_levelup")
    upLevelNode:setVisible(false)
    upLevelNode:stopAllActions()
    if not KPlayer.exp then
        imageAllyBase:removeChild(upLevelNode)
    elseif KPlayer.exp - self._addRoleExp >= 0 then 
        imageAllyBase:removeChild(upLevelNode)
    end

    local textLevel = imageAllyBase:getChildByName("Text_player_level")
    textLevel:setString(KPlayer.level)

    local textPlayerName  = imageAllyBase:getChildByName("Text_player_name")
    textPlayerName:setString(KPlayer.name)

    local textTeamName = imageAllyBase:getChildByName("Text_team_name")
    if self._tSrcTeam.teamIndex then
        local teamName = KUtil.getTeamName(self._tSrcTeam.teamIndex)
        textTeamName:setString(teamName)
    else
        local tMonsterGroupSetting = KConfig:getLine("monstergroup", self._tSrcTeam.nMonsterGroupID)
        assert(tMonsterGroupSetting, self._tSrcTeam.monsterGroupID)
        textTeamName:setString(tMonsterGroupSetting.szName)
    end

    for key, data in ipairs(self._cardList) do
        local useProjectNode = imageAllyBase:getChildByName("Node_army_unit_" .. key)
        self:initAllyUnit(useProjectNode, data)
    end

    local maxUnitNum = 6
    if #self._cardList < maxUnitNum then
        local index = #self._cardList + 1
        for var=index, maxUnitNum do
            local unusableUnit = imageAllyBase:getChildByName("Node_army_unit_" .. var)
            imageAllyBase:removeChild(unusableUnit)
        end
    end

    local imageExpBuff     = imageAllyBase:getChildByName("Image_exp_buff_base")
    local percentText      = imageExpBuff:getChildByName("BitmapFontLabel_exp")
    local expBuffData      = KPlayer.tExpBuffData
    local serverTime       = KUtil.getServerTime(os.time())
    local hasExpBuff       = false
    if expBuffData.nPercent > 0 and expBuffData.nExpireTime > serverTime then
        hasExpBuff    = true
    end
    
    imageExpBuff:setVisible(hasExpBuff)
    if hasExpBuff then
        percentText:setString(string.format(KUtil.getStringByKey("common.percent"), math.floor(expBuffData.nPercent)))
    end
end

local function initEnemyUnit(useUnit, data, self)
    local textName = useUnit:getChildByName("Text_enemy_tank_name")
    local textLevel = useUnit:getChildByName("Text_enemy_level_value")

    if data.bIsRole then
        local cardSetting = KConfig:getLine("cardInfo", data.nTemplateID)
        textLevel:setString(data.nLevel)
        textName:setString(cardSetting.szName)
    else
        local monsterSetting = KConfig:getLine("monster", data.nTemplateID)
        textLevel:setString(monsterSetting.nLevel)
        textName:setString(monsterSetting.szName)
    end

    local imageChara  = useUnit:getChildByName("ProjectNode_card")
    local tHeadInfo   = {["nTemplateID"] = data.nTemplateID, ["nCurrentHP"] = data.nCurrentHP, ["bRing"] = data.bRing, ["bIsRole"] = data.bIsRole, ["nMaxHP"] = data.nMaxHP}
    local isMonster   = not data.bIsRole
    KUtil.updateRightTeamHeadBase(imageChara, tHeadInfo, isMonster)
    
    local imageDamageBase  = useUnit:getChildByName("Panel_common_damage")
    
    local cardHPPercent = data.nCurrentHP / data.nMaxHP * 100    
    local hpName    = {nil, nil, nil, nil, nil}
    local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", "Image_common_damage_broken"}
    KUtil.drawCardState(nil, imageDamageBase, hpName, stateName, cardHPPercent)
end

function KUIBattleReportNode:refreshEnemyBase()
    local mainNode  = self._mainLayout   
    local imageEnemyBase = mainNode:getChildByName("Image_bg_enemy_base")
    
    local textName  = imageEnemyBase:getChildByName("Text_enemy_name")
    textName:setString(self._tDstTeam.name)
        
    local textTeamName  = imageEnemyBase:getChildByName("Text_enemy_team_name")
    textTeamName:setString(self._tDstTeam.teamName)       
    
    local textLevel    = imageEnemyBase:getChildByName("Text_enemy_level")
    textLevel:setString(self._tDstTeam.currentLevel)     
    
    local index = 0
    for key, data in ipairs(self._tDstTeam) do
        local useUnit = imageEnemyBase:getChildByName("Node_enemy_unit_" .. key)
        index = index + 1
        initEnemyUnit(useUnit, data, self)
    end
    
    local maxUnitNum = MAX_TEAM_CARD_COUNT
    if index < maxUnitNum then
        local key = index + 1
        for var = key, maxUnitNum do
            local unusableUnit = imageEnemyBase:getChildByName("Node_enemy_unit_" .. var)
            imageEnemyBase:removeChild(unusableUnit)
        end
    end

    imageEnemyBase:setVisible(false)
end

local function showEnemyBaseUI(self)
    local mainNode  = self._mainLayout   
    local imageEnemyBase = mainNode:getChildByName("Image_bg_enemy_base")
    
    local enemyPositionX = imageEnemyBase:getPositionX()
    local enemyPositionY = imageEnemyBase:getPositionY()
    local enemyWidth     = imageEnemyBase:getContentSize().width    
    imageEnemyBase:setPositionX(enemyPositionX + enemyWidth)  
    imageEnemyBase:setVisible(true)
    
    local moveDuration = 0.4
    imageEnemyBase:runAction(
        cc.MoveTo:create(moveDuration, cc.p(enemyPositionX, enemyPositionY))
    )

    local waitTime = moveDuration + 0.5
    self:nextStep(waitTime)
end

local function showBattleRankUI(self)
    local mainNode = self._mainLayout    
    local imageRankBase = mainNode:getChildByName("Image_rank_base")
    imageRankBase:setVisible(true)
     
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    imageRankBase:setPosition(cc.p(visibleSize.width/2, visibleSize.height/2))
    imageRankBase:setAnchorPoint(0.5, 0.5)
    
    local resultIDName    = string.lower(table.getkey(FIGHT_SCORE, self._resultID))
    local projectNodePath = "res/ui/animation_node/ani_rank_" .. resultIDName .. ".csb"
    local projectNodeRank = cc.CSLoader:createNode(projectNodePath)
    projectNodeRank:setPosition(cc.p(visibleSize.width/2, visibleSize.height/2))
    imageRankBase:addChild(projectNodeRank)
    projectNodeRank:setName("projectNodeRank")
    
    imageRankBase:setScale(2.5)
    
    local firstDuration  = 0.5
    local delayTime      = 0.5
    local secondDuration = 0.5
    imageRankBase:runAction(
        cc.Sequence:create(
            cc.ScaleTo:create(firstDuration, 1),
            cc.CallFunc:create(function()
                local rankLevelAction = cc.CSLoader:createTimeline(projectNodePath)
                rankLevelAction:gotoFrameAndPlay(0, true)
                projectNodeRank:runAction(rankLevelAction)
            end),
            cc.DelayTime:create(delayTime),
            cc.ScaleTo:create(secondDuration, 1, 0.005)
        )
    )

    local waitTime = firstDuration + delayTime + secondDuration
    self:nextStep(waitTime)
end

local function hideBattleRankUI(self)
    local mainNode = self._mainLayout    
    local imageRankBase = mainNode:getChildByName("Image_rank_base")
    imageRankBase:setVisible(false)

    local projectNodeRank = imageRankBase:getChildByName("projectNodeRank")
    projectNodeRank:stopAllActions()
    imageRankBase:removeChild(projectNodeRank)
    self:nextStep()
end

local function moveDamageBarWheelToCenter(self)
    local mainNode     = self._mainLayout 
    local imagePointBg = mainNode:getChildByName("Image_bg_point") 
    local imageHpBase  = mainNode:getChildByName("Image_bg_hp_base")
    local imageGreenHP = imageHpBase:getChildByName("Image_bg_hp_green")

    local endPoint     = cc.p(imagePointBg:getPositionX(), imagePointBg:getPositionY())
    local startPoint   = cc.p(endPoint.x - imageGreenHP:getContentSize().width, endPoint.y)
    imagePointBg:setPosition(startPoint)

    local duration = 0.5
    imagePointBg:setVisible(true)
    imagePointBg:runAction(
        cc.Spawn:create(
            cc.MoveTo:create(duration, endPoint),
            cc.RotateTo:create(duration, 720)
        )
    )

    local waitTime = duration + 0.2
    self:nextStep(waitTime)
end

local function showDamageBarUIGreen(self, duration)
    local mainNode = self._mainLayout 
    local imageHpBase = mainNode:getChildByName("Image_bg_hp_base")
    imageHpBase:setVisible(true)
    
    local greenHPPath  = "res/ui/ui_material/report/bg_hp_green.png"
    local imageGreenHP = imageHpBase:getChildByName("Image_bg_hp_green")
    local greenHPPoint = cc.p(imageGreenHP:getPositionX(), imageGreenHP:getPositionY())
    local localZOrder  = imageGreenHP:getLocalZOrder()
    imageGreenHP:setVisible(false)
    
    local spriteGreen = cc.Sprite:create(greenHPPath)
    spriteGreen:setFlippedX(true)
    local progress    = cc.ProgressTimer:create(spriteGreen)
    progress:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    progress:setMidpoint(cc.p(1, 1))
    progress:setBarChangeRate(cc.p(1, 0))
    progress:setPercentage(0)
    progress:setName("greenHP")
    progress:setPosition(greenHPPoint)
    progress:setLocalZOrder(localZOrder)
    imageHpBase:addChild(progress)
    progress:runAction(cc.ProgressTo:create(duration, self._greenPercent))
end

local function showDamageBarUIRed(self, duration)
    local mainNode = self._mainLayout 
    local imageHpBase = mainNode:getChildByName("Image_bg_hp_base")
    imageHpBase:setVisible(true)

    local redHPPath   = "res/ui/ui_material/report/bg_hp_red.png"
    local imageRedHP  = imageHpBase:getChildByName("Image_bg_hp_red")
    local redHPPoint  = cc.p(imageRedHP:getPositionX(), imageRedHP:getPositionY())
    local localZOrder = imageRedHP:getLocalZOrder()
    imageRedHP:setVisible(false)
    
    local spriteRed   = cc.Sprite:create(redHPPath)
    local redProgress = cc.ProgressTimer:create(spriteRed)
    redProgress:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    redProgress:setMidpoint(cc.p(0, 1))
    redProgress:setBarChangeRate(cc.p(1, 0))
    redProgress:setPercentage(0)
    redProgress:setPosition(redHPPoint)
    redProgress:setName("redHP")
    redProgress:setLocalZOrder(localZOrder)
    imageHpBase:addChild(redProgress)
    redProgress:runAction(cc.ProgressTo:create(duration, self._redPercent))
end

local function showDamageBarUI(self)
    local duration = 0.5
    showDamageBarUIRed(self, duration)
    showDamageBarUIGreen(self, duration)

    local waitTime = duration + 0.5
    self:nextStep(waitTime)
end

local function hideDamageBarUI(self)
    local mainNode = self._mainLayout 
    local imageHpBase = mainNode:getChildByName("Image_bg_hp_base")    
    
    local duration = 0.5
    local greenProgess = imageHpBase:getChildByName("greenHP")
    greenProgess:runAction(cc.ProgressTo:create(duration, 0))
    
    local redProgess  = imageHpBase:getChildByName("redHP")
    redProgess:runAction(cc.ProgressTo:create(duration, 0))

    local waitTime = duration + 0.2
    local function actionEnd()
        imageHpBase:setVisible(false)
        self:nextStep()
    end
    delayExecute(mainNode, actionEnd, waitTime)
end

local function moveDamageBarWheelToEnd(self)
    local mainNode     = self._mainLayout
    local imagePointBg = mainNode:getChildByName("Image_bg_point")
    local imageHpBase  = mainNode:getChildByName("Image_bg_hp_base")    
    local imageRedHP   = imageHpBase:getChildByName("Image_bg_hp_red")
    local imageGreenHP = imageHpBase:getChildByName("Image_bg_hp_green")
    local distanceX    = imageGreenHP:getContentSize().width
    local imageRedHP   = imageHpBase:getChildByName("Image_bg_hp_red")
    
    local moveDuration   = 0.5
    local rotateDuration = 0.5 
    imagePointBg:runAction(
        cc.Spawn:create(
            cc.MoveBy:create(moveDuration, cc.p(distanceX, 0)), 
            cc.RotateTo:create(rotateDuration, 720)
        )
    )

    local waitTime = math.max(moveDuration, rotateDuration)
    self:nextStep(waitTime)
end

local function hideEnemyBaseUI(self)
    local mainNode       = self._mainLayout
    local imageEnemyBase = mainNode:getChildByName("Image_bg_enemy_base")
    local imageHPBase    = mainNode:getChildByName("Image_bg_hp_base")    
    local imagePointBg   = mainNode:getChildByName("Image_bg_point")
    local screenWidth    = cc.Director:getInstance():getVisibleSize().width
    local panelHalfWidth = imageEnemyBase:getContentSize().width / 2
    
    local pointCurX      = imagePointBg:getPositionX()
    local pointCurY      = imagePointBg:getPositionY()

    local enemyCurX      = imageEnemyBase:getPositionX()
    local enemyCurY      = imageEnemyBase:getPositionY()
    
    local distance       = screenWidth + panelHalfWidth - enemyCurX 

    local duration = 0.5
    imagePointBg:runAction(
        cc.MoveTo:create(duration, cc.p(pointCurX + distance, pointCurY))
    )

    imageEnemyBase:runAction(
        cc.MoveTo:create(duration , cc.p(screenWidth + panelHalfWidth, enemyCurY))
    )

    local waitTime = duration + 0.1

    local function enemyBaseUIActionEnd()
        mainNode:removeChild(imageEnemyBase)
        mainNode:removeChild(imagePointBg)
        mainNode:removeChild(imageHPBase)
        self:nextStep()
    end

    delayExecute(mainNode, enemyBaseUIActionEnd, waitTime)
end

local function refreshReportBaseUI(self)
    local mainNode        = self._mainLayout
    local imageReportBase = mainNode:getChildByName("Image_bg_report_base")
    imageReportBase:setVisible(true)
          
    local cardList    = self._cardList
    local cardExpList = self._cardExpList

    local i = 0
    while true do
        i = i + 1
        local expUnitUI = imageReportBase:getChildByName("Panel_exp_" .. i)
        if not expUnitUI then
            break
        end

        local cardData  = cardList[i]
        if not cardData then
            expUnitUI:setVisible(false)
        else
            expUnitUI:setVisible(true)
            local expBase = cardData.nBaseExp
            local expAdd  = cardData.nAddExp
            local expCoe  = cardData.nExpCoe


            local textExp = expUnitUI:getChildByName("Text_unit_exp")
            local textCoe = expUnitUI:getChildByName("Text_unit_multiple")
            local enableCoe
            if not expCoe or expCoe == 1 or expAdd == 0 then
                enableCoe = false
                textExp:setString(math.floor(expAdd))
            else
                enableCoe = true

                local formatCoe = string.format("%0.2f", expCoe)
                textCoe:setString(formatCoe)
                textExp:setString(math.floor(expBase))
            end
            setExpCoeUIVisible(self, expUnitUI, enableCoe)            

            local textRemaindExp = expUnitUI:getChildByName("Text_unit_exp_left")
            local expData        = cardExpList[i]
            local remainExpValue = expData.upLevelExp - expData.batteBeforeExp
            textRemaindExp:setString(remainExpValue)
        end
    end
    
    for key, var in ipairs(cardList) do
        self._addMaxExp = math.max(self._addMaxExp, var.nAddExp)
    end
    
    local textAllExp = imageReportBase:getChildByName("Text_exp_all_gain")
    textAllExp:setString(self._addRoleExp)
end

local function showReportBaseUI(self)
    local mainNode        = self._mainLayout
    local imageReportBase = mainNode:getChildByName("Image_bg_report_base")
    local reportPositionX = imageReportBase:getPositionX()
    local reportPositionY = imageReportBase:getPositionY()
    local reportWidth     = imageReportBase:getContentSize().width    

    refreshReportBaseUI(self)
    
    imageReportBase:setPositionX(reportPositionX + reportWidth)  
    local duration = 0.5
    imageReportBase:runAction(
        cc.MoveTo:create(duration, cc.p(reportPositionX, reportPositionY))
    )

    local waitTime = duration + 0.5
    self:nextStep(waitTime)
end

local function refreshLevel(nCardID, nLevel, self)
    local mainNode      = self._mainLayout   
    local imageAllyBase = mainNode:getChildByName("Image_bg_ally_base")
    for key, card in ipairs(self._cardList) do
        local useUnit       = imageAllyBase:getChildByName("Node_army_unit_" .. key)
        local textLevel     = useUnit:getChildByName("Text_level_data")
        if card.nID then
            if card.nID == nCardID then
                textLevel:setString(nLevel)
                break
            end
        else
            local tMonsterSetting = KConfig.monster[data.nTemplateID]
            textLevel:setString(tMonsterSetting.nLevel)
        end
    end    
end

local function playReportExpMulCoe(self)
    local mainNode        = self._mainLayout    
    local reportBase      = mainNode:getChildByName("Image_bg_report_base")

    local cardList        = self._cardList
    local cardExpList     = self._cardExpList

    local costTimes      = 100
    local costInterval   = 0.01
    local costDuration   = costTimes * costInterval

    local expInfoList     = {}
    local enableCoeEffect = false

    for i, v in ipairs(cardList) do
        local enableCoe 
        local expCoe  = v.nExpCoe
        local expBase = v.nBaseExp
        local expAdd  = v.nAddExp
        if not expCoe or expCoe == 1 then
            enableCoe = false
            expCoe    = 1
        else
            enableCoe = true
            enableCoeEffect = true
        end

        local expUIRoot = reportBase:getChildByName("Panel_exp_" .. i)
        expInfoList[i] = {
            expCoe      = expCoe,
            addExp      = expAdd,
            baseExp     = expBase,
            expUI       = expUIRoot,
            expBaseUI   = expUIRoot:getChildByName("Text_unit_exp"),
            expCoeUI    = expUIRoot:getChildByName("Text_unit_multiple"),
            enableCoe   = enableCoe,
            curCoe      = expCoe,
            curExp      = expBase, 
            costCoePerTimes = expCoe / costTimes,
        }

        assert(expInfoList[i].expUI)
    end

    if not enableCoeEffect then
        self:nextStep()
        return
    end

    local function updateUnit(expInfo)
        expBaseUI = expInfo.expBaseUI
        expCoeUI  = expInfo.expCoeUI

        expCoe = expInfo.expCoe

        local costCoe = expInfo.costCoePerTimes
        local curCoe  = expInfo.curCoe
        local curExp  = expInfo.curExp
        curCoe = curCoe - costCoe
        if curCoe <= 1 or curExp >= expInfo.addExp then
            expBaseUI:setString(expInfo.addExp)
            expInfo.enableCoe = false
            setExpCoeUIVisible(self, expInfo.expUI, enableCoe)
            return
        end

        local curExp = math.ceil(expCoe * expInfo.baseExp / curCoe)
        local formatCoe = string.format("%0.2f",curCoe)
        expBaseUI:setString(curExp)
        expCoeUI:setString(formatCoe)

        expInfo.curCoe = curCoe
        expInfo.curExp = curExp
    end

    local function update()
        for i, v in ipairs(expInfoList) do
            local expInfo = expInfoList[i]
            if expInfo.enableCoe then
                updateUnit(expInfo)
            end
        end
    end    

    reportBase:runAction(
        cc.Repeat:create(
            cc.Sequence:create(
                cc.CallFunc:create(update),
                cc.DelayTime:create(costInterval)
            )
        , costTimes)
    )

    KSound.playEffect("winExperience")

    local delayTime = 0.8
    local waitTime  = costDuration + delayTime
    self:nextStep(waitTime)
end

local function playReportExpEffect(self)
    local mainNode        = self._mainLayout    
    local reportBase      = mainNode:getChildByName("Image_bg_report_base")

    local cardList        = self._cardList
    local cardExpList     = self._cardExpList
    local nCostTimes      = 100
    local nCostTimeOffset = 0.01
    local downExp         = math.ceil(self._addMaxExp / nCostTimes)

    local function updateOneExp(index, expUI, cardData, cardExp)
        if cardData.nAddExp <= 0 then return end

        local exp = math.min(cardData.nAddExp, downExp)
        cardData.nAddExp = cardData.nAddExp - exp

        local textExp = expUI:getChildByName("Text_unit_exp")
        textExp:setString(math.floor(cardData.nAddExp))

        cardExp.batteBeforeExp = cardExp.batteBeforeExp + exp
        local upExp = cardExp.upLevelExp - cardExp.batteBeforeExp
        if upExp <= 0 then  --up level
            cardExp.batteBeforeLevel = cardExp.batteBeforeLevel + 1  
            cardExp.upLevelExp       = KConfig["levelInfo"][cardExp.batteBeforeLevel]["nCardExp"]
            refreshLevel(cardData.nID, cardExp.batteBeforeLevel, self)
            cardExp.batteBeforeExp = math.abs(upExp)
        end
        
        local textRemaindExp = expUI:getChildByName("Text_unit_exp_left")
        local RemaindExp     = cardExp.upLevelExp - cardExp.batteBeforeExp
        textRemaindExp:setString(math.ceil(RemaindExp))
    end

    local expUIList = {}
    local haveAddExp = false
    local i = 0
    while true do
        i = i + 1
        local expUI = reportBase:getChildByName("Panel_exp_" .. i)
        if not expUI then break end

        local cardData = cardList[i]
        local cardExp  = cardExpList[i]
        if cardData and cardExp then
            haveAddExp = haveAddExp or (cardData.nAddExp > 0)
            table.insert(expUIList, expUI)
        end
    end

    local function updateExp()
        for index, expUI in ipairs(expUIList) do
            local cardData = cardList[index]
            local cardExp  = cardExpList[index]
            updateOneExp(index, expUI, cardData, cardExp)
        end
    end
    
    local costExpSequence = cc.Sequence:create(
        cc.CallFunc:create(updateExp),
        cc.DelayTime:create(nCostTimeOffset)
    )

    local repeatAction = cc.Repeat:create(costExpSequence, nCostTimes)
    reportBase:runAction(repeatAction)
    if haveAddExp then
        KSound.playEffect("winExperience")
    end

    local waitTime = nCostTimes * nCostTimeOffset
    self:nextStep(waitTime)
end

local function showAwardCard(self, cardTemplateID, endCallback)
    local mainNode     = self._mainLayout
    local newCardID    = nil
    local bIsNew       = false
    local tNewCardList = self._tNewCardList
    for index, oneCardData in ipairs(tNewCardList) do
        local cardID   = oneCardData.cardID
        local tOneCard = KUtil.getCardById(cardID)
        if cardTemplateID == tOneCard.nTemplateID then
            newCardID = cardID
            bIsNew    = oneCardData.isNew
        table.remove(self._tNewCardList, index)
            break
        end
    end
    KUtil.playGetCardAnimation(newCardID, bIsNew, endCallback, nil)

    if self._battleType == BATTLE_TYPE.GUIDE then
        require("src/logic/KGuideEnv").addNextGuideNode()
    end
end

local function showAwardItem(self, awardList, endCallback)
    local rewardItemUI = self._parent:addNode("Reward", {tResultList = awardList})
    rewardItemUI:setCallback(endCallback)

    if self._battleType == BATTLE_TYPE.GUIDE then
        require("src/logic/KGuideEnv").addNextGuideNode()
    end   
end

local function getFirstAwardCardID(self, awardList)
    for _, awardItem in ipairs(awardList) do
        if awardItem.nType == ITEM_TYPE.CARD then
            return awardItem.nID
        end
    end
    return nil
end

local function showAwardUI(self)
    local clickUI = false
    local function resumeCallback()
        if clickUI then return end

        clickUI = true
        self:nextStep()
    end

    local awardList = self._awardList
    local cardID    = getFirstAwardCardID(self, awardList)
    if cardID then
        showAwardCard(self, cardID, resumeCallback)
    elseif awardList ~= nil and #awardList ~= 0 then
        showAwardItem(self, awardList, resumeCallback)
    else
        self:nextStep()
    end
end

local function showPersueHandlerUI(self)
    if not self._isPursue then 
        self:nextStep()
        return
    end

    local mainNode      = self._mainLayout    
    local imageRankBase = mainNode:getChildByName("Image_rank_base")
    imageRankBase:setScale(1)
    imageRankBase:setVisible(true)

    local buttonPursue = imageRankBase:getChildByName("Button_zhuji")
    buttonPursue:setVisible(true)

    local nodeLinght   = buttonPursue:getChildByName("ProjectNode_pursuit_linght")
    -- local isBrokenCard = KUtil.isHaveBrokenCard(self._teamIndex)
    local isBrokenCard = KUtil.isHaveBrokenCardInCardList(self._tSrcTeam)
    local isLinght = (not isBrokenCard) and KPlayer.level <= PURSUE_TIP_LEVEL
    nodeLinght:setVisible(isLinght)
    nodeLinght:stopAllActions()
    if isLinght then
        local pursueLinghtAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_pursuit_linght.csb")
        assert(pursueLinghtAction ~= nil,"Create pursueLinghtAction Failed~")
        nodeLinght:runAction(pursueLinghtAction)
        pursueLinghtAction:gotoFrameAndPlay(0, true)
    end

    local buttonRetreat = imageRankBase:getChildByName("Button_chetui")
    buttonRetreat:setVisible(true)
    
    local aniPursue = imageRankBase:getChildByName("ProjectNode_ani_choose_1")
    aniPursue:setVisible(true)

    local aniRetreat = imageRankBase:getChildByName("ProjectNode_ani_choose_2")
    aniRetreat:setVisible(true)
    self:nextStep()

    if self._battleType == BATTLE_TYPE.GUIDE then
        require("src/logic/KGuideEnv").addNextGuideNode()
    end
end

function KUIBattleReportNode:persue(roundList)
    local function callPersue(roundList)
        self._isPursue = true
        self:nextStep(nil, roundList)
    end

    cclog("click Pursue zhuiji")
    KSound.playEffect("followUp")
    self._parent:removeNode("Battle") 

    -- local isBrokenCard = KUtil.isHaveBrokenCard(self._teamIndex)
    local isBrokenCard = KUtil.isHaveBrokenCardInCardList(self._tSrcTeam)
    if isBrokenCard then
        local confirmationInfo = KUtil.getStringByKey("battle.hasBrokenCard")
        showConfirmation(confirmationInfo, callPersue)
    else
        callPersue(roundList)
    end
end

local function waitAskPersueResult(self)
    if not self._isPursue then 
        self:nextStep()
    end

    local mainNode = self._mainLayout
    local rankBase = mainNode:getChildByName("Image_rank_base")

    

    local function callRetreat()
        KSound.playEffect("retreat")
        local leader = self._cardList[1] or {}
        -- local leader = self._tSrcTeam[1] or {}
        KSound.playTalk(KSound.TALK.FINISHFIGHT, leader.nTemplateID, not leader.nID)
        local officeScene = require("src/ui/office/KUIOfficeScene").create()
        KUtil.replaceSceneAndRemoveAllTexture(officeScene)
   end

    local buttonPursue = rankBase:getChildByName("Button_zhuji")
    local function onPursueClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        self:persue()
    end
    buttonPursue:addTouchEventListener(onPursueClick)

    local buttonRetreat = rankBase:getChildByName("Button_chetui")    
    local function onRetreatClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click Pursue chetui")
        callRetreat()        
    end
    buttonRetreat:addTouchEventListener(onRetreatClick)
end

local function showPassMapRewardUIItem(self)
    local passMapAward = self._passMapAward
    if not passMapAward or #passMapAward == 0 then
        self:nextStep()
        return
    end

    local function resumeCallback()
        self:nextStep()
    end

    local node = self._parent:addNode("PassMapReward", {tResultList = passMapAward})
    node:setCallback(resumeCallback)
end

local function showPassMapRewardUICard(self)
    local passMapAward = self._passMapAward
    if not passMapAward or #passMapAward == 0 then
        self:nextStep()
        return
    end

    local function resumeCallback()
        self:nextStep()
    end

    local cardID = getFirstAwardCardID(self, passMapAward)
    if cardID then
        showAwardCard(self, cardID, resumeCallback)
    else
        self:nextStep()
    end
end

local function showPassMapSpecialRewardUIItem(self)
    local passMapAward = self._passMapExtraAward
    if not passMapAward or #passMapAward == 0 then
        self:nextStep()
        return
    end

    local function resumeCallback()
        self:nextStep()
    end

    local node = self._parent:addNode("PassMapSpecialReward", {tResultList = passMapAward, nZoneID = self._zoneID, nMapID = self._mapID})
    node:setCallback(resumeCallback)
end

local function showPassMapSpecialRewardUICard(self)
    local passMapAward = self._passMapExtraAward
    if not passMapAward or #passMapAward == 0 then
        self:nextStep()
        return
    end

    local function resumeCallback()
        self:nextStep()
    end

    local cardID = getFirstAwardCardID(self, passMapAward)
    if cardID then
        showAwardCard(self, cardID, resumeCallback)
    else
        self:nextStep()
    end
end

local function showPassMapUI(self)
    if self._passMapAward == nil then 
        self:nextStep()
        return 
    end

    local mainNode = self._mainLayout
    local zoneID   = self._zoneID
    local mapID    = self._mapID

    local battleSetting     = KConfig:getLine("battle", zoneID, mapID, 1)
    local nPassMapAnimation = battleSetting.nPassMapAnimation

    if not nPassMapAnimation or nPassMapAnimation == 0 then 
        self:nextStep()
        return
    end
    
    local passMap               = cc.CSLoader:createNode("res/ui/animation_node/ani_victory_clearance_v5.csb")
    local passMapAction         = cc.CSLoader:createTimeline("res/ui/animation_node/ani_victory_clearance_v5.csb")
    local panelClearanceBase    = passMap:getChildByName("Panel_clearance_base")
    mainNode:addChild(passMap)

    local passMapStart          = 0 
    local passMapEnd            = passMapAction:getDuration()
    passMap:stopAllActions() 
    passMap:runAction(passMapAction)
    passMapAction:gotoFrameAndPlay(passMapStart, passMapEnd, false)
    
    local i = 0
    while true do
        i = i + 1
        local imageName = "Image_base_" .. i
        local imageBase = panelClearanceBase:getChildByName(imageName)
        if not imageBase then break end

        imageBase:setVisible(false)
    end
    local imageBase = panelClearanceBase:getChildByName("Image_base_" .. mapID)
    imageBase:setVisible(true)
    
    local GAME_FPS = 60
    local waitTime = passMapEnd / GAME_FPS
    self:nextStep(waitTime)
end

local function initUIActionStep(self)
    local tStepFuncList = { 
        showEnemyBaseUI,
        moveDamageBarWheelToCenter,
        showDamageBarUI,
        showBattleRankUI,
        hideBattleRankUI,
        hideDamageBarUI,
        moveDamageBarWheelToEnd,
        hideEnemyBaseUI,
        showReportBaseUI,
        playReportExpMulCoe,
        playReportExpEffect,    
        showAwardUI,
        showPersueHandlerUI,
        waitAskPersueResult,
        showPassMapUI,
        showPassMapRewardUIItem,
        showPassMapRewardUICard,
        showPassMapSpecialRewardUIItem,
        showPassMapSpecialRewardUICard,
    }

    local stepCount       = 0
    local bForceStop      = false
    local stepExecutor    = {}
    local node            = self._mainLayout

    local function exit()
        if self._callback then
            self._callback(self._isPursue)
        end
    end

    local function nextStep(delayTime)
        stepCount = stepCount + 1
        if bForceStop or stepCount > #tStepFuncList then
            exit()
            return
        end

        local func = tStepFuncList[stepCount]
        local function executeNextFunc()
            func(self)
        end

        if delayTime then
            delayExecute(node, executeNextFunc, delayTime)
        else
            delayExecute(node, executeNextFunc, 0)
        end
    end

    function stepExecutor:nextStep(delayTime)
        nextStep(delayTime)
    end

    function stepExecutor:start()
        self:nextStep()
    end

    self._stepExecutor = stepExecutor
end

local function runUIActionStep(self)
    self._stepExecutor:start()
end

function KUIBattleReportNode:nextStep(delayTime)
    self._stepExecutor:nextStep(delayTime)
end

function KUIBattleReportNode:run()
    local stepExecutor = self._stepExecutor
    if stepExecutor:isRunning() then
        stepExecutor:restart()
    else
        stepExecutor:run()
    end
end

function KUIBattleReportNode:refreshUI()
    self:hideUI()
    self:refreshAllyBase()
    self:refreshEnemyBase()
    playAudioEffect(self)
    initUIActionStep(self)
    runUIActionStep(self)
end

function KUIBattleReportNode:registerAllCustomEvent()
end

function KUIBattleReportNode:setReportData(reportData)
    self._zoneID         = reportData.zoneID
    self._mapID          = reportData.mapID
    self._footholdID     = reportData.footholdID
    self._callback       = reportData.endCallback
    self._cardList       = reportData.cardExpAward
    self._awardList      = reportData.awardList
    self._tNewCardList   = reportData.tNewCardList
    self._addRoleExp     = reportData.roleExp
    self._resultID       = reportData.resultType
    self._greenPercent   = reportData.srcDamagePercent
    self._redPercent     = reportData.dstDamagePercent
    self._cardExpList    = reportData.cardExpList
    self._tSrcTeam       = reportData.srcTeam
    self._tDstTeam       = reportData.dstTeam
    self._isPursue       = reportData.showIfContinueFightUI
    self._passMapAward   = reportData.mapPassAward
    self._passMapExtraAward = reportData.mapPassExtraAward
    self._clickPanelCall = reportData.clickPanelCall
    self._cardFeeling    = reportData.cardFeeling
    self._battleType     = reportData.battleType
end

function KUIBattleReportNode:autoHandler()   
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        end
        if "exit" == event then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    assert(self._mainLayout)
    self:addChild(self._mainLayout, 1)

    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

function KUIBattleReportNode:runEnterAction()
end

function KUIBattleReportNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local rankBase = mainNode:getChildByName("Image_rank_base")   

    local buttonShadow = mainNode:getChildByName("Image_bg_shadow") 
    buttonShadow:setTouchEnabled(true)

    local function onPanelClick(sender, type)
        if type == ccui.TouchEventType.ended then          
            cclog("click panel")
            if self._clickPanelCall then
                local leader = self._cardList[1] or {}
                local nTemplateID = leader.nTemplateID
                self._clickPanelCall(nTemplateID)
            end
        end
    end
    buttonShadow:addTouchEventListener(onPanelClick)
end

return KUIBattleReportNode
