--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBattleScene.lua
--  Creator     : SunXun
--  Date        : 2015/07/20   16:21
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIBattleScene = class(
    "KUIBattleScene" , function () return cc.Scene:create() end
)

KUIBattleScene._currentScene  = nil
KUIBattleScene._createCount   = 0
KUIBattleScene._enterCount    = 0

function KUIBattleScene:ctor()
    self._nodeList      = {}
    self._nodeZOrder    = 1
end

KUIBattleScene.NodeType = {
    ["BattlePrepare"]       = "src/ui/battle/KUIBattlePrepareNode",
    ["Battle"]              = "src/ui/battle/KUIBattleNode",
    ["BattleReport"]        = "src/ui/battle/KUIBattleReportNode",
    ["BattleFail"]          = "src/ui/battle/KUIBattleFailNode",
    ["ExercisePrepare"]     = "src/ui/battle/KUIExercisePrepareNode",
    ["ExpeditionPrepare"]   = "src/ui/battle/KUIExpeditionPrepareNode",
    ["Reward"]              = "src/ui/office/expedition/KUIRewardNode",
    ["PlunderReward"]       = "src/ui/office/expedition/KUIPlunderRewardNode",
    ["PassMapReward"]       = "src/ui/office/expedition/KUIPassMapRewardNode", 
    ["PassMapSpecialReward"]= "src/ui/office/expedition/KUIPassMapSpecialRewardNode",
    ["AwardTank"]           = "src/ui/office/awardtank/KUIAwardTankNode",
}

function KUIBattleScene.create(userData, szReason)
    if KUIBattleScene._currentScene and not tolua.isnull(KUIBattleScene._currentScene) then 
        return KUIBattleScene._currentScene 
    end
    require("src/logic/KLogGather").addLog("EventBug", "scene create battle", szReason)
    local currentScene = KUIBattleScene.new()
    currentScene:autoHandler()
    currentScene:enterPreparePanel(userData)
    KUIBattleScene._currentScene = currentScene
    KUIBattleScene._createCount  = KUIBattleScene._createCount + 1
    return currentScene
end

function KUIBattleScene:enterPreparePanel(userData)
    self.userData = userData
    if userData.battleType == BATTLE_TYPE.NORMAL or userData.battleType == BATTLE_TYPE.GUIDE then
        self:addNode("BattlePrepare", userData)
        
    elseif userData.battleType == BATTLE_TYPE.EXERCISE then
        self:addNode("ExercisePrepare", userData)
        
    elseif userData.battleType == BATTLE_TYPE.EXPEDITION then
        self:addNode("ExpeditionPrepare", userData)
    end
end

function KUIBattleScene:autoHandler()
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        elseif "exit" == event then
            -- self:onExit()
        elseif "cleanup" == event then
            self:onCleanup()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end

function KUIBattleScene:onEnter()
    KUIBattleScene._currentScene = nil
    KUIBattleScene._enterCount   = KUIBattleScene._enterCount + 1
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "battle scene enter")
    if KUIBattleScene._enterCount ~= KUIBattleScene._createCount then
        local str = string.format("battle scene enter error, create:%d, enter:%d", KUIBattleScene._createCount, KUIBattleScene._enterCount)
        KLogGather.addLog("EventBug", str)
        KLogGather.sendLog("EventBug")
    end
    KLogGather.deleteLog("EventBug", "scene create")

    if KUtil.isGuide() then 
        require("src/logic/KGuideEnv").addCurrentGuideNode()
    end
end

function KUIBattleScene:onCleanup()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "battle scene cleanup")
end

function KUIBattleScene:addNode(nodeType, ...)
    local filePath = KUIBattleScene.NodeType[nodeType]
    assert(filePath, nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
    
    local uiNode = require(filePath).create(self, ...)
    table.insert(self._nodeList, {["nodeType"] = nodeType, ["uiNode"] = uiNode})
    self:addChild(uiNode, self._nodeZOrder)
    self._nodeZOrder = self._nodeZOrder + 1

    return uiNode
end

function KUIBattleScene:removeNode(nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then
            self:removeChild(v["uiNode"], true)
            table.remove(self._nodeList, k)
            return
        end
    end
    
    assert(0, "try remove a unexisted node ! nodeType:%s", nodeType)
    return 0
end

function KUIBattleScene:getNode(nodeType)
    local filePath = KUIBattleScene.NodeType[nodeType]
    assert(filePath)
   
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
    assert(false)
end

function KUIBattleScene:gotoUI(nodeType, ...)
    local filePath = KUIBattleScene.NodeType[nodeType]
    if filePath then
        self:addNode(nodeType, ...)
    else
        self:returnOffice()
    end
end

function KUIBattleScene:returnOffice()
    local officeScene = require("src/ui/office/KUIOfficeScene").create("returnOffice")
    KUtil.replaceSceneAndRemoveAllTexture(officeScene)
end

return KUIBattleScene
