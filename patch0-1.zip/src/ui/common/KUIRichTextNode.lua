--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIChatNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/1/8   9:35
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  ********************************************************************


local KUIRichTextNode = class(
    "KUIRichTextNode", function () return cc.Layer:create() end
)

KUIRichTextNode.NodeType = 
{
    IMAGE  = "image",
    TEXT   = "text",
    SPAN   = "span",
    BR     = "br",
    CUSTOM = "custom",
}

function KUIRichTextNode:ctor()
    self._lineNodes      = {}
    self._leftSpaceWidth = 0
    self._contentHeight  = 0
    self._contentWidth   = 0
    self._tempText       = nil

    self._initWidth      = 0
    self._initHeight     = 0
    self._dataList       = {}

    self._verticalSpace  = 0
    self._callback       = nil
end

function KUIRichTextNode.create(contentWidth, verticalSpace)
    local currentNode = KUIRichTextNode.new()
    currentNode:ctor()

    assert(contentWidth)
    currentNode._initWidth     = contentWidth
    currentNode._verticalSpace = verticalSpace or currentNode._verticalSpace
    currentNode._tempText      = ccui.Text:create()
    return currentNode
end

local function getLineCount(self)
    return #self._lineNodes
end

local function addNewLine(self)
    local currentCount  = getLineCount(self)
    local nextIndex     = currentCount + 1
    local newLineNode   = {}
    self._lineNodes[nextIndex] = newLineNode
    self._leftSpaceWidth       = self._initWidth

    return newLineNode
end

local function addNode(self, node)
    local currentCount = getLineCount(self)
    if currentCount <= 0 then
        assert(false)
        return
    end
    local lastLine = self._lineNodes[currentCount]

    lastLine[#lastLine + 1] = node
end

local function addTouchCall(self, node, funCallBack)
    node:setTouchEnabled(true)
    node:setSwallowTouches(false)
    local function onButtonCall(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        funCallBack()
    end
    node:addTouchEventListener(onButtonCall)
end

function KUIRichTextNode:addNewNode(node)
    local size = node:getContentSize()
    self._leftSpaceWidth = self._leftSpaceWidth - size.width
    if self._leftSpaceWidth < 0 then
        addNewLine(self)
        addNode(self, node)
        self._leftSpaceWidth = self._leftSpaceWidth - size.width
    else
        addNode(self, node)
    end
end

function KUIRichTextNode:addImage(path, scale, funCallBack)
    local node = ccui.ImageView:create(path)
    if scale then node:setScale(scale) end
    addTouchCall(self, node, funCallBack)
    self.addNewNode(node)
end

local function getTextFromTable(tTextTable, nStrat, nEnd)
    local str = ""
    for i = nStrat, nEnd do
        if not tTextTable[i] then break end
        str = str .. tTextTable[i].word
    end
    return str
end

local BMFONT_BORDER_WIDTH = 7
local function getNodeWidth(node)
    if node._type == "BMFont" then
        return node:getContentSize().width - BMFONT_BORDER_WIDTH
    end
    return node:getContentSize().width
end  


function KUIRichTextNode:addTextByBMFont(text, fontFilePath, color)
    local tempTextNode  = cc.LabelBMFont:create()
    tempTextNode._type  = "BMFont"
    tempTextNode:setFntFile(fontFilePath)
    tempTextNode:setString(text)

    local textWidth      = getNodeWidth(tempTextNode)
    local charList       = KUtil.splitChinese(text)
    local charCount      = #charList
    local enchCharWidth  = textWidth / charCount
    local leftCharCount  = charCount
    local beginCharIndex = 1
    if getLineCount(self) == 0 then addNewLine(self) end
    while leftCharCount > 0 do
        local showCharCount = math.floor(self._leftSpaceWidth / enchCharWidth)
        local endCharIndex  = beginCharIndex + showCharCount - 1
        endCharIndex        = math.min(endCharIndex, charCount)
        if endCharIndex < beginCharIndex then
            endCharIndex = beginCharIndex
        end
        local showText      = getTextFromTable(charList, beginCharIndex, endCharIndex)
        tempTextNode:setString(showText)
        local realWidth     = getNodeWidth(tempTextNode)
        local changeWidth   = 0
        if realWidth ~= self._leftSpaceWidth then
            while true do
                if realWidth > self._leftSpaceWidth then
                    endCharIndex = endCharIndex - 1
                    if endCharIndex < beginCharIndex then break end
                    tempTextNode:setString(getTextFromTable(charList, endCharIndex + 1, endCharIndex + 1))
                    changeWidth = changeWidth + getNodeWidth(tempTextNode)
                    if realWidth - changeWidth < self._leftSpaceWidth then break end
                else 
                    if endCharIndex == charCount then break end
                    endCharIndex = endCharIndex + 1
                    tempTextNode:setString(getTextFromTable(charList, endCharIndex, endCharIndex))
                    changeWidth = changeWidth + getNodeWidth(tempTextNode)
                    if realWidth + changeWidth > self._leftSpaceWidth then
                        endCharIndex = endCharIndex - 1
                        break
                    end
                end
            end
        end

        if endCharIndex >= beginCharIndex then 
            local showText = getTextFromTable(charList, beginCharIndex, endCharIndex)
            leftCharCount  = leftCharCount - (endCharIndex - beginCharIndex + 1)
            beginCharIndex = endCharIndex + 1
            local node  = cc.LabelBMFont:create()
            node._type  = "BMFont"
            node:setFntFile(fontFilePath)
            node:setString(showText)
            node:setColor(color)
            addNode(self, node)
            self._leftSpaceWidth = self._leftSpaceWidth - getNodeWidth(node)
        end
        if leftCharCount > 0 then
            addNewLine(self)
        end
    end 
end

-- labelname,content
local function getSpanNode()
    local spanNode = {isSpan = true}
    function spanNode:setContentSize(contentSize)
        self._contentSize = contentSize
    end
    function spanNode:getContentSize()
        return self._contentSize
    end
    return spanNode
end

function KUIRichTextNode.addSpan(width, height)
    local node = getSpanNode()
    local currentCount = getLineCount(self)
    node:setContentSize(cc.size(width, height))
    addNode(self, node)
    self._leftSpaceWidth = self._leftSpaceWidth - nodeInfo.content
    if self._leftSpaceWidth < 0 then
        addNewLine(self)
    end
end

function KUIRichTextNode:addLine()
    addNewLine(self)
end

function KUIRichTextNode.addNode(_node)
    local size = _node:getContentSize()
    self._leftSpaceWidth = self._leftSpaceWidth - size.width
    if self._leftSpaceWidth < 0 then
        addNewLine(self)
        addNode(self, _node)
        self._leftSpaceWidth = self._leftSpaceWidth - size.width
    else
        addNode(self, _node)
    end
end

function KUIRichTextNode:formarRenderers()
    local newContentSizeHeight = 0
    local maxHeights           = {}
    for lineIndex, lines in ipairs(self._lineNodes) do
        local maxHeight = 0
        for nodeIndex, node in ipairs(lines) do
            maxHeight = math.max(node:getContentSize().height, maxHeight);
        end
        maxHeights[lineIndex] = maxHeight
        newContentSizeHeight = newContentSizeHeight + maxHeights[lineIndex]
    end

    newContentSizeHeight = newContentSizeHeight + (self._verticalSpace * getLineCount(self))
    local nextPosY = 0
    for lineIndex, lines in ipairs(self._lineNodes) do
        local nextPosX = 0
        for nodeIndex, node in ipairs(lines) do
            if not node.isSpan then
                node:setAnchorPoint(0, 1)
                node:setPosition(nextPosX, nextPosY)
                self:addChild(node, 1)
            end
            nextPosX = nextPosX + getNodeWidth(node)
            print("node width", getNodeWidth(node))
        end
        nextPosY = nextPosY - (maxHeights[lineIndex] + self._verticalSpace)
    end
    self._contentHeight = newContentSizeHeight
end

function KUIRichTextNode:getHeight()
    return self._contentHeight
end

return KUIRichTextNode
