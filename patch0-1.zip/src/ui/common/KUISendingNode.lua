--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUISendingNode.lua
--  Creator     : Han Ruofei 
--  Date        : 2015/09/14 
--  Comment     :
--  *********************************************************************

if C_TcpClient.SetTargetAddress ~= nil then
	return require "src/ui/common/KUISendingNode_v2"
end


local KUISendingNode = class(
    "KUISendingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISendingNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUISendingNode.create(owner, requestID)
    local currentNode = KUISendingNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/animation_node/ani_loading.csb"
    currentNode._requestID = requestID 
    currentNode:init()
    
    return currentNode
end

function KUISendingNode:refreshUI()
end

function KUISendingNode:registerAllTouchEvent()
	local eventDispatch = require("src/logic/KEventDispatchCenter")
end

function KUISendingNode:registerAllCustomEvent()
	local function removeSelf()
		local parent = self._parent
		if parent then
		  parent:removeChild(self)
		end
	end

	local eventDispatch = require("src/logic/KEventDispatchCenter")

	local function onRespond(requestID)
		print("----> OnRequest Respond: ", requestID, self._requestID)
		if self._requestID ~= requestID then return end

		removeSelf()
	end

	local function onSendTimeout(requestID)
		print("----> onSendTimeout: ", requestID, self._requestID)

		showNoticeByID("common.time_out")
        if KUtil.isGuide() then return end
	    local currentScene = cc.Director:getInstance():getRunningScene()
	    if currentScene.__cname == "KUIBattleScene" then
			local officeScene = require("src/ui/office/KUIOfficeScene").create("SendingNode")
            KUtil.replaceSceneAndRemoveAllTexture(officeScene)
			return
	    end
	    removeSelf()
	end


    self:addCustomEvent(eventDispatch.EventType.RESPOND, onRespond)
    self:addCustomEvent(eventDispatch.EventType.SENDING_TIME_OUT, onSendTimeout)
end

function KUISendingNode:runEnterAction()

end

function KUISendingNode:runExitAction()
end

return KUISendingNode
