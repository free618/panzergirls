--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUISendingNode.lua
--  Creator     : Han Ruofei 
--  Date        : 2015/09/14 
--  Comment     :
--  *********************************************************************
local KUISendingNode = class(
    "KUISendingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISendingNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUISendingNode.create(owner)
    local currentNode = KUISendingNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/animation_node/ani_loading.csb"
    currentNode:init()
    
    return currentNode
end

function KUISendingNode:refreshUI()
end

function KUISendingNode:registerAllTouchEvent()
	local eventDispatch = require("src/logic/KEventDispatchCenter")
end

function KUISendingNode:registerAllCustomEvent()
	local function removeSelf()
		local parent = self._parent
		if parent then
		  parent:removeChild(self)
		end
	end

	local eventDispatch = require("src/logic/KEventDispatchCenter")

	local function onNetActionEnd(nEndType)
		print("----> onNetActionEnd: ", nEndType)

		removeSelf()

		if nEndType == NET_ACTION_END_TYPE.CONNECTION_FAILED then
			showNoticeByID("common.connect_to_gs.failed")
			return
		end

		if nEndType == NET_ACTION_END_TYPE.TIME_OUT then
			showNoticeByID("common.time_out")
			return
		end
	end

    self:addCustomEvent(eventDispatch.EventType.NET_ACTION_END_TYPE, onNetActionEnd)
end

function KUISendingNode:runEnterAction()

end

function KUISendingNode:runExitAction()
end

return KUISendingNode
