--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowAnnounceNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/11/18   16:23
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local QUEUE_MAX = 5000
local SHOW_SIZE = 1
local OFF_X     = 10

local t_mMessageQueue = {}
local KUIShowAnnounceNode = class(
    "KUIShowAnnounceNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowAnnounceNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._nodeList      = {}
    self._showList      = {}
    self._contentSize   = nil
    self._isShowMessage = false
end

function KUIShowAnnounceNode.create(owner)
    local currentNode = KUIShowAnnounceNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_notice_base.csb"
    currentNode:init()

    return currentNode
end

function KUIShowAnnounceNode.insertMessage(message)
    if not message then return end
    if not message.nTimes or not message.nInterval or not message.szDetail then
        return
    end
    if message.nTimes > QUEUE_MAX then
        return 
    end

    local startTime = KUtil.getCurrentServerTime()
    for i = 1, message.nTimes do
        local showTime = message.nInterval * (i - 1) + startTime
        local messageInfo = {}
        messageInfo.showTime = showTime
        messageInfo.detail = message.szDetail
        if #t_mMessageQueue < QUEUE_MAX then
            t_mMessageQueue[#t_mMessageQueue + 1] = messageInfo
        end
    end

    local function funSort(message1, message2)
        return message1.showTime < message2.showTime
    end
    table.sort(t_mMessageQueue, funSort)
end

local function addNoticeNode(self)
    for _, nodeInfo in pairs(self._nodeList) do
        if nodeInfo.isShow == false then
            nodeInfo.isShow = true
            nodeInfo.node:setVisible(true)
            return nodeInfo.node
        end
    end
end

local function removeNoticeNode(self)
    local firstNode = self._showList[1]
    for _, nodeInfo in pairs(self._nodeList) do
        if nodeInfo.node == firstNode then
            nodeInfo.isShow = false
            firstNode:setVisible(false)
            break
        end
    end
    table.remove(self._showList, 1)
end

local function moveNoticeNode(self, nowTime)
    -- remove first
    local firstNode  = self._showList[1]
    if firstNode then
        local positionX = firstNode:getPositionX()
        local width = firstNode:getContentSize().width
        if positionX < -width then
            removeNoticeNode(self)
        end
    end

    -- add node
    local lastNode  = self._showList[#self._showList]
    local firstNode  = self._showList[1]
    local messageInfo = t_mMessageQueue[1]
    local showNewMessage = (messageInfo and messageInfo.showTime < KUtil.getServerTime(nowTime))
    if #self._showList < SHOW_SIZE and showNewMessage then
        table.remove(t_mMessageQueue, 1)
        local showNode = addNoticeNode(self)
        assert(showNode)
        self._showList[#self._showList + 1] = showNode
        showNode:setString(messageInfo.detail)
        if not firstNode then
            local positionY = showNode:getPositionY()
            showNode:setPosition(self._contentSize.width, positionY)
        elseif lastNode then
            local contentSize = lastNode:getContentSize()
            local positionX = lastNode:getPositionX()
            local positionY = lastNode:getPositionY()
            local endPositionX = positionX + contentSize.width + OFF_X
            if endPositionX > self._contentSize.width then
                showNode:setPosition(endPositionX, positionY)
            else
                showNode:setPosition(self._contentSize.width, positionY)
            end
        end
    end
    -- move node
    for _, node in ipairs(self._showList) do
        local positionX = node:getPositionX()
        local positionY = node:getPositionY()
        node:setPosition(positionX - 2, positionY)
    end
    -- check show panel
    local showAnnounce = (#self._showList > 0)
    if showAnnounce == self._isShowMessage then
        return 
    end
    self._isShowMessage = showAnnounce
    self._mainLayout:setVisible(showAnnounce)
end

local function initUI(self)
    local mainLayout  = self._mainLayout
    local baseNode    = mainLayout:getChildByName("Image_notice_base")
    local panelNotice = baseNode:getChildByName("Panel_notice")
    local baseControl = panelNotice:getChildByName("Text_notice")
    baseControl:setVisible(false)

    self._isShowMessage = false
    self._mainLayout:setVisible(false)

    self._contentSize = panelNotice:getContentSize()

    for i = 1, SHOW_SIZE do
        local newTextNotice = baseControl:clone()
        newTextNotice:setVisible(false)
        panelNotice:addChild(newTextNotice)
        table.insert(self._nodeList, {node = newTextNotice, isShow = false})
    end
end

function KUIShowAnnounceNode:runEnterAction()
    return 0.0
end

function KUIShowAnnounceNode:runExitAction()
    return 0.0
end

function KUIShowAnnounceNode:activate(nowTime)
    moveNoticeNode(self, nowTime)
end

function KUIShowAnnounceNode:refreshUI()
    initUI(self)
end

function KUIShowAnnounceNode:registerAllTouchEvent()
end

function KUIShowAnnounceNode:registerAllCustomEvent()
end

return KUIShowAnnounceNode
