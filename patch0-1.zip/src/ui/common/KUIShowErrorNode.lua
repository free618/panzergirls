--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowErrorNode.lua
--  Creator     : SunXun
--  Date        : 2015/04/30   16:00
--  Contact     : sunxun@kingsoft.com
--  Comment     : 
--  *********************************************************************


local MAX_GUIDE_ERROR_COUNT = 2
local KUIShowErrorNode = class(
    "KUIShowErrorNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowErrorNode:ctor()
end

function KUIShowErrorNode.create(owner)
    local currentNode = KUIShowErrorNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_caution.csb"
    currentNode:init()

    return currentNode
end

function KUIShowErrorNode:setErrorInfo(errorMsg, stackInfo)
    --cclog("-------------------->KUIShowErrorNode:setErrorInfo Start")
    assert(errorMsg, " errorMsg is nil")
    assert(stackInfo, " stackInfo is nil")

    local mainNode = self._mainLayout
    local imageControl = mainNode:getChildByName("Image_common_caution_base")
    local scrollControl = imageControl:getChildByName("ScrollView_textfield")
    local infoLabel = scrollControl:getChildByName("Text_content")
    
    local errorHeadString = "Sorry for this problem.\nWe will solve this problem as soon as possible.\nThank you very much!^_^\n\n"
    local stackErrorInfo = "\n--------------------\n" .. stackInfo .. "\n--------------------"
    --cclog("********stackErrorInfo:%s", stackErrorInfo)
    local errorInfoFinal = errorHeadString .. errorMsg .. stackErrorInfo
    infoLabel:setString(errorInfoFinal)
    --cclog("-------------------->KUIShowErrorNode:setErrorInfo End Info:\n%s", errorInfoFinal)
end

function KUIShowErrorNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local imageControl = mainNode:getChildByName("Image_common_caution_base")
    
    local buttonControl = imageControl:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~") 
            KPlayer.nErrorCount = KPlayer.nErrorCount + 1
            if KUtil.isGuide() and KPlayer.nErrorCount >= MAX_GUIDE_ERROR_COUNT then
                KPlayer.progressID  = ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_END
                local nIndex = ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_END - ROLE_PROCESS_TYPE.ROLE_PROGRESS_GUIDE_BEGIN
                require("src/network/KC2SProtocolManager"):updateGuide(nIndex, "跳过新手", nil)
            end            
            local officeScene = require("src/ui/office/KUIOfficeScene").create("ShowErrorNode")
            KUtil.replaceSceneAndRemoveAllTexture(officeScene)
            require("src/logic/KGuideEnv").init()
        end
    end
    buttonControl:addTouchEventListener(onConfirmClick)
end

function KUIShowErrorNode:registerAllCustomEvent()
end

return KUIShowErrorNode
