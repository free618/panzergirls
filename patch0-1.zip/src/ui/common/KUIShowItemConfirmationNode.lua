--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowItemConfirmationNode.lua
--  Creator     : HuangZhiLong
--  Date        : 2015/09/11   11:23
--  Contact     : huangzhilong1@kingsoft.com
--  Comment     :
--  *********************************************************************


local ENTER_ACTION_DURATION = 0.3
local CENTER_POSITION       = cc.p(0, 0)

local KUIShowItemConfirmationNode = class(
    "KUIShowItemConfirmationNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowItemConfirmationNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIShowItemConfirmationNode.create(owner)
    local currentNode = KUIShowItemConfirmationNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_confirm_demand.csb"
    currentNode:init()
       
    return currentNode
end

function KUIShowItemConfirmationNode:setConfirmationInfo(confirmationInfo)
    local mainNode        = self._mainLayout
    local imageConfirm    = mainNode:getChildByName("Image_confirm")
    local textInformation = imageConfirm:getChildByName("Text_information")

    textInformation:setString(confirmationInfo)
end

local function getImageItem(self, imagePath)
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local imageBase     = imageConfirm:getChildByName("Image_text_base")
    local panelIcon     = imageBase:getChildByName("Panel_icon")
    local imageIcon     = panelIcon:getChildByName("Image_icon")

    local iconWidth     = panelIcon:getContentSize().width
    local iconHeight    = panelIcon:getContentSize().height
    local scaleX        = panelIcon:getScaleX()
    local scaleY        = panelIcon:getScaleY()
    iconWidth  = scaleX * iconWidth
    iconHeight = scaleY * iconHeight

    imageIcon:loadTexture(imagePath)
    local imageWidth    = imageIcon:getContentSize().width
    local imageHeight   = imageIcon:getContentSize().height

    local scaleWidth    = iconWidth / imageWidth
    local scaleHeight   = iconHeight / imageHeight

    local scaleNum      = scaleWidth
    if scaleNum > scaleHeight then scaleNum = scaleHeight end

    panelIcon:setClippingEnabled(true)
    imageIcon:setScale(scaleNum)
end

function KUIShowItemConfirmationNode:setCostItem(nID)
    local mainNode      = self._mainLayout
    local itemInfo      = KConfig["itemInfo"][nID]
    
    local textItemName  = mainNode:getChildByName("Text_name")
    textItemName:setString(itemInfo.szName)
    
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local imageBase     = imageConfirm:getChildByName("Image_text_base")
    local panelIcon     = imageBase:getChildByName("Panel_icon")
    local imageIcon     = panelIcon:getChildByName("Image_icon")
    
    local itemIconPath  = "res/images/item/" .. itemInfo.szResPath .. "/1.png"
    local imageScale    = getImageItem(self, itemIconPath)
end

function KUIShowItemConfirmationNode:setOnTouchEvent(fnConfirm, fnCancel)
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_confirm")
    local buttonConfirm = imageConfirm:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~")

            if fnConfirm ~= nil then
                fnConfirm()
            end

            self:removeFromParent()
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel = imageConfirm:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCancelClick~")

            if fnCancel ~= nil then
                fnCancel()
            end

            self:removeFromParent()
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local buttonClose  = imageConfirm:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")

            if fnCancel ~= nil then
                fnCancel()
            end

            self:removeFromParent()
        end
    end    
    buttonClose:addTouchEventListener(onCloseClick)
end

function KUIShowItemConfirmationNode:refreshUI()
    local mainNode      = self._mainLayout
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    mainNode:setPosition(cc.p(0, visibleSize.height))
end

function KUIShowItemConfirmationNode:runEnterAction()
    local mainNode           = self._mainLayout
    local actionMoveToCenter = cc.MoveTo:create(ENTER_ACTION_DURATION, CENTER_POSITION)
    mainNode:runAction(actionMoveToCenter)
end

return KUIShowItemConfirmationNode
