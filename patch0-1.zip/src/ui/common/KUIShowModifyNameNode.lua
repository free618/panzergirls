--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowModifyNameNode.lua
--  Creator     : GuoWeiQiang
--  Date        : 2016/01/15   11:11
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local NAME_MIN_LENGTH       = 2
local NAME_MAX_LENGTH       = 8

local ENTER_ACTION_DURATION = 0.3
local CENTER_POSITION       = cc.p(0, 0)

local KUIShowModifyNameNode = class(
    "KUIShowModifyNameNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowModifyNameNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIShowModifyNameNode.create(owner)
    local currentNode = KUIShowModifyNameNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_modify_name.csb"
    currentNode:init()
       
    return currentNode
end

function KUIShowModifyNameNode:setOnTouchEvent(fnConfirm, fnCancel)
    local mainNode      = self._mainLayout
    local imageConfirm  = mainNode:getChildByName("Image_modify_name")
    local textName      = imageConfirm:getChildByName("Text_name")
    textName:setString(KPlayer.name)

    local buttonConfirm = imageConfirm:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~")

            local textName1   = imageConfirm:getChildByName("TextField_name_1")
            local textName2   = imageConfirm:getChildByName("TextField_name_2")
            local newName     = textName1:getString()
            local comfirName  = textName2:getString()

            if newName ~= comfirName then
                showNoticeByID("common.renamefailed.no_same")
                return 
            end

            if KUtil.hasSensitiveWord(newName) or KUtil.hasIllegalChar(newName) then
                showNoticeByID("common.renamefailed.use_illega_name")
                return 
            end

            if string.utf8Len(newName) < NAME_MIN_LENGTH then
                showNoticeByID("common.renamefailed.short")
                return 
            end
            
            if string.utf8Len(newName) > NAME_MAX_LENGTH then
                showNoticeByID("common.renamefailed.long")
                return 
            end

            if fnConfirm ~= nil then
                fnConfirm(newName)
            end

            self:removeFromParent()
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel = imageConfirm:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCancelClick~")

            if fnCancel ~= nil then
                fnCancel()
            end

            self:removeFromParent()
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local buttonclose = imageConfirm:getChildByName("Button_close")
    buttonclose:addTouchEventListener(onCancelClick)
end

function KUIShowModifyNameNode:refreshUI()
    local mainNode      = self._mainLayout
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    mainNode:setPosition(cc.p(0, visibleSize.height))
end

function KUIShowModifyNameNode:runEnterAction()
    local mainNode           = self._mainLayout
    local actionMoveToCenter = cc.MoveTo:create(ENTER_ACTION_DURATION, CENTER_POSITION)
    mainNode:runAction(actionMoveToCenter)
end

return KUIShowModifyNameNode
