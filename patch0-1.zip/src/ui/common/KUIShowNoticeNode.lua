--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShowNoticeNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/22   14:17
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIShowNoticeNode = class(
    "KUIShowNoticeNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShowNoticeNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIShowNoticeNode.create(owner)
    local currentNode = KUIShowNoticeNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign_up_prompt.csb"
    currentNode:init()
    
    return currentNode
end

function KUIShowNoticeNode:setNoticeInfo(noticeInfo, type)
    cclog("--------------------> KUIShowNoticeNode:setNoticeInfo : %s", noticeInfo)
    local mainNode      = self._mainLayout
    local textPrompt    = mainNode:getChildByName("Text_prompt")
    
    textPrompt:setString(noticeInfo)
    
    local panelIcon    = mainNode:getChildByName("Panel_icon")
    local iconName = "Image_"..(type or "")
    for _, imageIcon in pairs(panelIcon:getChildren()) do
        imageIcon:setVisible(imageIcon:getName() == iconName)
    end
end

function KUIShowNoticeNode:refreshUI()
    local mainNode      = self._mainLayout
    local visibleSize   = cc.Director:getInstance():getVisibleSize()
    local prepareAction = cc.FadeOut:create(0.01)
    mainNode:runAction(prepareAction)
    
    mainNode:setPosition(cc.p(visibleSize.width / 2, visibleSize.height / 2))
    
    cclog("----------> KUIShowNoticeNode:refreshUI")
end

function KUIShowNoticeNode:registerAllTouchEvent()
end

function KUIShowNoticeNode:registerAllCustomEvent()
end

function KUIShowNoticeNode:runEnterAction()
    local mainNode      = self._mainLayout
    
    local actionSequence = cc.Sequence:create(
        cc.FadeIn:create(1.0),
        cc.DelayTime:create(1.5),
        cc.FadeOut:create(1.0),
        cc.CallFunc:create(
            function () 
                mainNode:removeFromParent() 
                --cclog("----------> mainNode:removeFromParent")
            end
        )
    )
    mainNode:runAction(actionSequence)
    
    cclog("----------> KUIShowNoticeNode:runEnterAction")
end

function KUIShowNoticeNode:runExitAction()
end

return KUIShowNoticeNode
