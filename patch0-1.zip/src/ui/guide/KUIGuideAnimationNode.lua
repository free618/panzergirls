--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIGuideAnimationNode.lua.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/20   11:50
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIGuideAnimationNode = class(
    "KUIGuideAnimationNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIGuideAnimationNode:ctor()
    self._parent          = nil
    self._mainLayout      = nil
    self._eventList       = {}
    self._guideIndex      = nil
    self._delayTime       = nil
    self._isValid         = true
end

function KUIGuideAnimationNode.create(owner, guideIndex, delayTime)
    local currentNode       = KUIGuideAnimationNode.new()
    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_bovice_circle.csb"
    currentNode._guideIndex = guideIndex
    currentNode._delayTime  = delayTime
    currentNode:init()
    return currentNode
end

function KUIGuideAnimationNode:refreshAnimation(gudieConfig)
    local mainNode       = self._mainLayout
    
    local imageCircle    = mainNode:getChildByName("Image_battle_circle")
    imageCircle:setVisible(gudieConfig.bMask)

    local imageAnimation = mainNode:getChildByName("Image_scene_graph")
    local resourcesPath  = "res/ui/ui_material/guide/"
    
    if string.len(gudieConfig.szImage) > 0 then
        imageAnimation:loadTexture(resourcesPath..gudieConfig.szImage..".png")
        imageAnimation:setVisible(true)
    end
    
    local nodeAnimation = imageAnimation:getChildByName("ProjectNode_explosion")
    if string.len(gudieConfig.szAnimation) > 0 then
        nodeAnimation:setVisible(true)
    else
        nodeAnimation:setVisible(false)
    end
    
    if string.len(gudieConfig.szAction) > 0 then
        local stringBase = [[ local node = select(2,...); setfenv(1, select(1,...)); local function nextGuide() if node._isValid then addNextGuideNode() end; node._isValid = false; end; return Sequence(%s, CallFunc(nextGuide)) ]]

        local sequence = assert(loadstring(string.format(stringBase, gudieConfig.szAction)), gudieConfig.szAction)
        imageAnimation:runAction(sequence(require("src/logic/KGuideEnv"), self))
    end
    
    local buttonSkip  = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(gudieConfig.bSkip)
end

function KUIGuideAnimationNode:refreshUI()
    local mainNode       = self._mainLayout
    local imageAnimation    = mainNode:getChildByName("Image_scene_graph")
    imageAnimation:setVisible(false)
    local imageCircle    = mainNode:getChildByName("Image_battle_circle")
    imageCircle:setVisible(false)
    local buttonSkip  = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(false)
    
    local gudieConfig = KConfig:getLine("guide", self._guideIndex)
    assert(gudieConfig)
    
    if not self._delayTime then
        self._delayTime = gudieConfig.nDelayTime
    end
    
    local function delayRefresh()
        if not self._delayTime or self._delayTime == 0 then
            self:refreshAnimation(gudieConfig) 
        elseif self._delayTime > 0 then
            delayExecute(
                self,  
                function () 
                    self:refreshAnimation(gudieConfig) 
                end, 
                self._delayTime
            )
        end
    end

    if self._delayTime < 0 then
        local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
        local function onEvent(nGuideIndex)
            cclog("onEvent ------------> onRefreshDialogue", nGuideIndex)
            if nGuideIndex == self._guideIndex then
                self._delayTime = math.abs(self._delayTime)
                delayRefresh()
            end
        end
        if require("src/logic/KGuideEnv")._guideIndex == self._guideIndex then
            onEvent(self._guideIndex)
        else
            self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_GUIDE, onEvent)
        end
    else
        delayRefresh()
    end

    if not self._delayTime or self._delayTime == 0 then
        self:refreshAnimation(gudieConfig)
    elseif self._delayTime > 0 then
        delayExecute(
            self,  
            function () 
                self:refreshAnimation(gudieConfig) 
            end, 
            self._delayTime
        )
    elseif self._delayTime == -1 then
        local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
        local function onRefreshAnimation(nGuideIndex)
            cclog("onEvent ------------> onRefreshAnimation", nGuideIndex)
            if nGuideIndex == self._guideIndex then
                self:refreshAnimation(gudieConfig)
            end
        end
        if require("src/logic/KGuideEnv")._guideIndex == self._guideIndex then
            onRefreshAnimation(self._guideIndex)
        else
            self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_GUIDE, onRefreshAnimation)
        end
    end
end

function KUIGuideAnimationNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    local buttonSkip    = mainNode:getChildByName("Button_pass")
    local function onSkip(sender, type)
        if type == ccui.TouchEventType.ended then
            if not self._isValid then return end
            self._isValid = false
            KSound.playEffect("click")
            require("src/logic/KGuideEnv").addNextGuideNode(nil, true)
        end
    end
    buttonSkip:addTouchEventListener(onSkip)
end

function KUIGuideAnimationNode:onEnter()
    require("src/logic/KMainLoop"):addActivateObject(self)
    self:onNodeEnter()
end

function KUIGuideAnimationNode:onExit()
    self:unregisterAllCustomEvent()
    require("src/logic/KMainLoop"):removeActivateObject(self)
end

return KUIGuideAnimationNode
