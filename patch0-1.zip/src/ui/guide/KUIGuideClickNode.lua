--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIGuideClickNode.lua.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/19   09:40
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_RowSpacing       = 10
local m_DefaultFontSize  = 26
local m_DefaultFontColor = cc.c3b(97, 104, 171)

local KUIGuideClickNode = class(
    "KUIGuideClickNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIGuideClickNode:ctor()
    self._parent          = nil
    self._mainLayout      = nil
    self._eventList       = {}
    self._guideIndex      = nil
    self._delayTime       = nil
    self._isValid         = true
end

function KUIGuideClickNode.create(owner, guideIndex, delayTime)
    local currentNode       = KUIGuideClickNode.new()
    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_bovice_guide.csb"
    currentNode._guideIndex = guideIndex
    currentNode._delayTime  = delayTime
    currentNode:init()
    return currentNode
end

function KUIGuideClickNode:refreshTip(gudieConfig)
    local resourcesPath  = "res/ui/ui_material/guide/"
    local mainNode = self._mainLayout
    
    local nodeTip    = mainNode:getChildByName("Node_guide")
    nodeTip:setVisible(true)
    local direction 
    if gudieConfig.lszTipBoxPosition then
        direction = gudieConfig.lszTipBoxPosition.direction
    end
    local szTipName  = "Panel_guide_"..(direction or "default")
    for _, panelTip in ipairs(nodeTip:getChildren()) do
        if panelTip:getName() == szTipName then
            panelTip:setVisible(true)
            panelTip:setPosition(cc.p((gudieConfig.lszTipBoxPosition.x or 0), (gudieConfig.lszTipBoxPosition.y or 0)))
            local fntTip    = panelTip:getChildByName("BitmapFontLabel_guide_text")
            fntTip:setString("")

            local nodeRichText = require("src/ui/common/KUIRichTextNode").create(fntTip:getContentSize().width, m_RowSpacing)

            for i, tText in ipairs(gudieConfig.lszTip) do
                local szText    = tText
                local color     = m_DefaultFontColor
                if type(tText) == "table" then
                    szText      = tText[1]
                    if tText[2] then color     = cc.c3b(unpack(tText[2], 1, table.maxn(tText[2]))) end
                end
                nodeRichText:addTextByBMFont(szText, resourcesPath.."xs_font_small.fnt", color)
            end

            panelTip:addChild(nodeRichText)
            nodeRichText:setAnchorPoint(0, 1)
            nodeRichText:setPosition(fntTip:getPosition())
            nodeRichText:formarRenderers()
 
            local imageDialog = panelTip:getChildByName("Image_dialog_small")
            local panelHead   = imageDialog:getChildByName("Panel_cartoon_avatar")
            local displayCard = KUtil.getTeamLeaderCard()
            local resPath     = KUtil.getCardConfig(displayCard.nTemplateID).szResPath
            local szHeadName  = "Image_avatar_"..resPath
            for _, imageHead in ipairs(panelHead:getChildren()) do
                imageHead:setVisible(imageHead:getName() == szHeadName)
            end
        else
            panelTip:setVisible(false)
        end
    end

    local buttonSkip = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(gudieConfig.bSkip)
    
    local buttonBase = mainNode:getChildByName("Button_base")
    buttonBase:retain()
    mainNode:removeChild(buttonBase)
    
    local clickX = gudieConfig.lszButtonPosition.x
    local clickY = gudieConfig.lszButtonPosition.y
    local clickRadius = gudieConfig.lszButtonPosition.radius
    local clickWidth = gudieConfig.lszButtonPosition.width
    local clickHeight = gudieConfig.lszButtonPosition.height

    local imageMask
    if gudieConfig.szButtonPath and string.len(gudieConfig.szButtonPath) > 0 then
        print(gudieConfig.szButtonPath)
        imageMask = cc.Sprite:create(gudieConfig.szButtonPath)
        local size = imageMask:getContentSize()
        if not clickWidth then clickWidth  = size.width end
        if not clickHeight then clickHeight = size.height end
        imageMask:setScale(clickWidth / size.width, clickHeight / size.height)
        imageMask:setPosition(cc.p(clickX + clickWidth / 2, clickY + clickHeight / 2))
    elseif clickRadius then
        imageMask = cc.Sprite:create(resourcesPath.."circular_mask.png")
        local size = imageMask:getContentSize()
        imageMask:setScale(clickRadius*2 / size.width, clickRadius*2 / size.height)
        imageMask:setPosition(cc.p(clickX, clickY))
    else
        imageMask = cc.Sprite:create(resourcesPath.."square_mask.png")
        local size = imageMask:getContentSize()
        imageMask:setScale(clickWidth / size.width, clickHeight / size.height)
        imageMask:setPosition(cc.p(clickX + clickWidth / 2, clickY + clickHeight / 2))
    end
    assert(imageMask)
    local clipNode = cc.ClippingNode:create()
    clipNode:setInverted(true)
    clipNode:setAlphaThreshold(0)
    clipNode:addChild(buttonBase)
    buttonBase:release()
    clipNode:setStencil(imageMask)
    self:addChild(clipNode)
    
    local stringBase  = [[ setfenv(1, select(1,...)); %s ]]
    local funCallBack = assert(loadstring(string.format(stringBase, gudieConfig.szCallBack)), gudieConfig.szCallBack)
    
    local viewSize = cc.Director:getInstance():getWinSize()
    local layer = cc.Layer:create()
    layer:setContentSize(cc.size(viewSize.width, viewSize.height))
    layer:setTouchEnabled(true)
    self:addChild(layer, 20)

    local eventDispatcher = layer:getEventDispatcher()
    self.m_touch_listener = cc.EventListenerTouchOneByOne:create()
    local OnTouchBegan = function(touch, event)
        return true
    end
    local OnTouchMoved = function(touch, event)
        return true
    end

    local OnTouchEnded = function(touch, event)
        if not self._isValid then return end
        local location = touch:getLocation() 
        print("ontouchended", location.x, location.y)
        if (clickRadius and math.pow((location.x - clickX), 2) + math.pow((location.y - clickY), 2) <= math.pow(clickRadius, 2))
            or (not clickRadius and location.x >= clickX and location.x <= clickX + clickWidth 
            and location.y >= clickY and location.y <= clickY + clickHeight) then
            self._isValid = false
            funCallBack(require("src/logic/KGuideEnv"))
            require("src/logic/KGuideEnv").addNextGuideNode()
            eventDispatcher:removeEventListener(self.m_touch_listener)
        end
        return true
    end
    
    self.m_touch_listener:setSwallowTouches(true)
    self.m_touch_listener:registerScriptHandler(OnTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    self.m_touch_listener:registerScriptHandler(OnTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
    self.m_touch_listener:registerScriptHandler(OnTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    
    eventDispatcher:addEventListenerWithSceneGraphPriority(self.m_touch_listener, layer)   
end

function KUIGuideClickNode:refreshUI()
    local mainNode = self._mainLayout
    local nodeTip    = mainNode:getChildByName("Node_guide")
    nodeTip:setVisible(false)
    local buttonSkip  = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(false)
    
    local gudieConfig = KConfig:getLine("guide", self._guideIndex)
    assert(gudieConfig)
    
    if string.len(gudieConfig.szAction) > 0 then
        local stringBase  = [[ setfenv(1, select(1,...)); %s ]]
        local funDispatch = assert(loadstring(string.format(stringBase, gudieConfig.szAction)), gudieConfig.szAction)
        funDispatch(require("src/logic/KGuideEnv"))
    end
    
    if not self._delayTime then
        self._delayTime = gudieConfig.nDelayTime
    end
    
    local function delayRefresh()
        if not self._delayTime or self._delayTime == 0 then
            self:refreshTip(gudieConfig) 
        elseif self._delayTime > 0 then
            delayExecute(
                self,  
                function () 
                    self:refreshTip(gudieConfig) 
                end, 
                self._delayTime
            )
        end
    end

    if self._delayTime < 0 then
        local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
        local function onEvent(nGuideIndex)
            cclog("onEvent ------------> delayRefresh", nGuideIndex, self._guideIndex)
            if nGuideIndex == self._guideIndex then
                self._delayTime = math.abs(self._delayTime)
                delayRefresh()
            end
        end
        if require("src/logic/KGuideEnv")._guideIndex == self._guideIndex then
            onEvent(self._guideIndex)
        else
            self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_GUIDE, onEvent)
        end
    else
        delayRefresh()
    end
end

function KUIGuideClickNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    local buttonSkip    = mainNode:getChildByName("Button_pass")
    local function onSkip(sender, type)
        if type == ccui.TouchEventType.ended then
            if not self._isValid then return end
            self._isValid = false
            KSound.playEffect("click")
            require("src/logic/KGuideEnv").addNextGuideNode(nil, true)
        end
    end
    buttonSkip:addTouchEventListener(onSkip)
end

function KUIGuideClickNode:onEnter()
    require("src/logic/KMainLoop"):addActivateObject(self)
    self:onNodeEnter()
end

function KUIGuideClickNode:onExit()
    self:unregisterAllCustomEvent()
    require("src/logic/KMainLoop"):removeActivateObject(self)
end

return KUIGuideClickNode
