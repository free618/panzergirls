--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIGuideDialogueNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/19   17:00
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_RowSpacing       = 10
local m_DefaultFontSize  = 26
local m_DefaultFontColor = cc.c3b(97, 104, 171)

local KUIGuideDialogueNode = class(
    "KUIGuideDialogueNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIGuideDialogueNode:ctor()
    self._mainLayout      = nil
    self._parent          = nil
    self._uiPath          = nil
    self._eventList       = {}
    self._guideIndex      = nil
    self._funCallBack     = nil
    self._delayTime       = nil
    self._isValid         = true
end

function KUIGuideDialogueNode.create(owner, guideIndex, delayTime)
    local currentNode   = KUIGuideDialogueNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_bovice_guidelines.csb"
    currentNode._guideIndex = guideIndex
    currentNode._delayTime  = delayTime
    currentNode:init()
    
    return currentNode
end

function KUIGuideDialogueNode:refreshDialogue(gudieConfig)
    local resourcesPath  = "res/ui/ui_material/guide/"
    local mainNode      = self._mainLayout
    local nodeCard      = mainNode:getChildByName("Node_chara_expression")
    nodeCard:setVisible(true)
    local displayCard   = KUtil.getTeamLeaderCard()
    assert(displayCard, "can not find card for displaying")
    local resPath = KUtil.getCardConfig(displayCard.nTemplateID).szResPath
    
    local szNodeName    = "Panel_chara_"..resPath
    local tNodeCardchild = nodeCard:getChildren()
    for _, v in ipairs(tNodeCardchild) do
        if v:getName() == szNodeName then
            v:setVisible(true)
            local cardImagePath = KUtil.getCardImagePath(displayCard, false, gudieConfig.bBreak)
            local imageCard     = v:getChildByName("Image_chara")
            imageCard:loadTexture(cardImagePath)
    
            local szHeadNodeName = "Image_chara_"..gudieConfig.szFace
            for _, head in ipairs(imageCard:getChildren()) do
                head:setVisible(head:getName() == szHeadNodeName)
            end
        else
            v:setVisible(false)
        end
    end

    local panelDialog   = mainNode:getChildByName("Panel_dialog_big")
    panelDialog:setVisible(true)

    local nodeNext      = panelDialog:getChildByName("ProjectNode_arrow")
    local labelName     = panelDialog:getChildByName("Text_name")
    labelName:setString( gudieConfig.bRoleDialogue and KPlayer.name or KUtil.getCardConfig(displayCard.nTemplateID).szName )

    local dialogueInfo = gudieConfig.lszDialogue[resPath]
    local tDialogue    = {}
    if dialogueInfo then
        if type(dialogueInfo) == 'table' then
            for i, v in ipairs(dialogueInfo) do
                if type(v) == 'table' then
                    tDialogue[i]    = string.split(v[1], "|") 
                    if v[2] then
                        tDialogue[i].color = cc.c3b(unpack(v[2], 1, table.maxn(v[2]))) 
                    end
                else
                    tDialogue[i]    = string.split(v, "|") 
                end
            end
        else
            tDialogue[1]      = string.split(dialogueInfo, "|")
        end
        
    end

    local nLanguageSpeed = gudieConfig.nLanguageSpeed == 0 and 0.2 or gudieConfig.nLanguageSpeed
    local fntDialogue    = panelDialog:getChildByName("BitmapFontLabel_dialogue")
    fntDialogue:setString("")
    local width    = fntDialogue:getContentSize().width
    local positionX = fntDialogue:getPositionX()
    local positionY = fntDialogue:getPositionY()

  
    local lableCount, wordCount = 0, 0
    local lableIndex, wordIndex = 0, 0
    lableCount  = #tDialogue
    local tText = {}
    local nodeRichText
    local isEnd 
    local function setString()
        wordIndex = wordIndex + 1 
        if lableIndex == 0 or wordIndex > wordCount then
            if lableIndex >= lableCount then
                panelDialog:stopAllActions()
                return
            end
            lableIndex  = lableIndex + 1
            wordIndex   = 1
            wordCount   = #tDialogue[lableIndex]
        end

        if isEnd then
            for i = lableIndex, lableCount do
                local wordIndexBegin = 1
                local wordIndexEnd   = #tDialogue[i]
                if i == lableIndex then
                    wordIndexBegin = wordIndex
                end
                for j = wordIndexBegin, wordIndexEnd do
                    tText[i] = (tText[i] or "") .. tDialogue[i][j]
                end
            end
        else
            tText[lableIndex] = (tText[lableIndex] or "") .. tDialogue[lableIndex][wordIndex]
        end

        if nodeRichText then
            panelDialog:removeChild(nodeRichText)
        end
        nodeRichText = require("src/ui/common/KUIRichTextNode").create(width, m_RowSpacing)

        for i, v in ipairs(tText) do
            local szText    = v
            local color     = tDialogue[i].color or m_DefaultFontColor
            nodeRichText:addTextByBMFont(szText, resourcesPath .. "xs_font_big.fnt", color)
        end

        panelDialog:addChild(nodeRichText)
        nodeRichText:setAnchorPoint(0, 1)
        nodeRichText:setPosition(cc.p(positionX, positionY))
        nodeRichText:formarRenderers()

        if isEnd or (lableIndex == lableCount and wordIndex == wordCount) then
            isEnd = true
            nodeNext:setVisible(true)
            panelDialog:stopAllActions()
        end
    end
    panelDialog:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.CallFunc:create(setString), cc.DelayTime:create(nLanguageSpeed))))

    local buttonSkip    = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(gudieConfig.bSkip)
    
    local buttonBase    = mainNode:getChildByName("Button_base")
    if string.len(gudieConfig.szImage) > 0 then
        local imagePath = resourcesPath..gudieConfig.szImage..".png"
        print("imagePath:",imagePath)
        buttonBase:setOpacity(255)
        buttonBase:loadTextures(imagePath, imagePath, imagePath)
    end

    local function onClick(sender, type)
        if type == ccui.TouchEventType.ended then
            if not self._isValid then return end
            if not isEnd then
                isEnd = true
                setString()
                nodeNext:setVisible(true)
            else
                self._isValid = false
            	if self._funCallBack then
                    self._funCallBack(require("src/logic/KGuideEnv"))
                end
                require("src/logic/KGuideEnv").addNextGuideNode()
            end
        end
    end
    buttonBase:addTouchEventListener(onClick)
end

function KUIGuideDialogueNode:refreshUI()
    local gudieConfig = KConfig:getLine("guide", self._guideIndex)
    assert(gudieConfig)
    
    if string.len( gudieConfig.szCallBack ) > 0 then
        local stringBase  = [[ setfenv(1, select(1,...)); %s ]]
        self._funCallBack = assert(loadstring(string.format(stringBase, gudieConfig.szCallBack)), gudieConfig.szCallBack)
    end

    local mainNode = self._mainLayout

    local nodeCard    = mainNode:getChildByName("Node_chara_expression")
    nodeCard:setVisible(false)
    local panelDialog = mainNode:getChildByName("Panel_dialog_big")
    panelDialog:setVisible(false)
    local buttonSkip  = mainNode:getChildByName("Button_pass")
    buttonSkip:setVisible(false)
    local nodeNext    = panelDialog:getChildByName("ProjectNode_arrow")
    nodeNext:setVisible(false)
    
    if not self._delayTime then
        self._delayTime = gudieConfig.nDelayTime
    end
    
    local function delayRefresh()
        if not self._delayTime or self._delayTime == 0 then
            self:refreshDialogue(gudieConfig) 
        elseif self._delayTime > 0 then
            delayExecute(
                self,  
                function () 
                    self:refreshDialogue(gudieConfig) 
                end, 
                self._delayTime
            )
        end
    end
    
    if self._delayTime < 0 then
        local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
        local function onEvent(nGuideIndex)
            cclog("onEvent ------------> delayRefresh", nGuideIndex, self._guideIndex)
            if nGuideIndex == self._guideIndex then
                self._delayTime = math.abs(self._delayTime)
                delayRefresh()
            end
        end
        if require("src/logic/KGuideEnv")._guideIndex == self._guideIndex then
            onEvent(self._guideIndex)
        else
            self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_GUIDE, onEvent)
        end
    else
        delayRefresh()
    end
end

local function callBack()

end

function KUIGuideDialogueNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    
    local buttonSkip    = mainNode:getChildByName("Button_pass")
    local function onSkip(sender, type)
        if type == ccui.TouchEventType.ended then
            if not self._isValid then return end
            self._isValid = false
            KSound.playEffect("click")
            require("src/logic/KGuideEnv").addNextGuideNode(nil, true)
        end
    end
    buttonSkip:addTouchEventListener(onSkip)
end

function KUIGuideDialogueNode:onEnter()
    require("src/logic/KMainLoop"):addActivateObject(self)
    self:onNodeEnter()
end

function KUIGuideDialogueNode:onExit()
    self:unregisterAllCustomEvent()
    require("src/logic/KMainLoop"):removeActivateObject(self)
end

return KUIGuideDialogueNode
