--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIConfigLoadingNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   22:33
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIConfigLoadingNode = class(
    "KUIConfigLoadingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local function reloadOne(moduleName)
    if package.loaded[moduleName] then
        package.loaded[moduleName] = nil
        require(moduleName)

        cclog("reload " .. moduleName)
    end
end

local function tryReloadAll()
    reloadOne("src/base/KGlobalFunction")
    --reloadOne("src/main.lua") loop
    reloadOne("src/ui/common/KUIShowConfirmationNode")
    reloadOne("src/ui/uibase/KUINodeBase")
    reloadOne("src/ui/login/KUILoginScene")
end

function KUIConfigLoadingNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._loadFileIndex  = nil
    self._fileTotalCount = nil
    self._fileNameList   = nil
    self._isLoadComplete = nil
    self._beginLoading   = nil
end

function KUIConfigLoadingNode.create(owner)
    local currentNode = KUIConfigLoadingNode.new()
    
    currentNode._parent              = owner
    currentNode._uiPath              = "res/ui/layout_sign_up_loading.csb"
    currentNode._loadFileIndex       = 1
    currentNode._fileTotalCount      = 0
    currentNode._fileNameList        = {}
    currentNode._isLoadingConfig     = false
    currentNode:init()
    
    return currentNode
end

local function loadFile(self)
    local mainNode          = self._mainLayout
    local textInfo          = mainNode:getChildByName("Text_information")
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")

    local fileName = self._fileNameList[self._loadFileIndex]
    local fileInfo = KConfig._loadTable[fileName]
    local loadInfo = string.format("Config Loading ... %s (%d/%d)", fileInfo.path, self._loadFileIndex, self._fileTotalCount)
    textInfo:setString(loadInfo)

    local tTabFile = require("src/settings/" .. fileInfo.path)
    assert(tTabFile)

    if not KConfig[fileName] then 
         KConfig[fileName] = tTabFile
         KUtil.specialHandle(fileName)
    end

    self._loadFileIndex = self._loadFileIndex + 1
    local loadPercent   = self._loadFileIndex / self._fileTotalCount * 100
    loadingBarPercent:setPercent(loadPercent)

    if self._loadFileIndex > self._fileTotalCount then
        textInfo:setString("All Config Loaded Completely~ ")
        local function onAnnounce(isGet, szText)
            local function addNode( ... )
                self._parent:addNode("LoginAndRegister")
                if isGet and szText and string.len(szText) > 0 then
                    self._parent:addNode("Announce", szText)
                end
            end
                
            delayExecute(self, addNode, 0.3)
        end 
        httpGet(INFO_GATHER_SERVER .. "Announce", onAnnounce)
    end 
end

function KUIConfigLoadingNode:playAnimation()
    local panelBase      = self._panelTipBase:getChildByName("Panel_base")
    local panelImageBase = panelBase:getChildByName("Image_Base")
    local fadeInTime, delayTime, fadeOutTime = 0.2, 0.5, 0.3
    for _, text in pairs(panelImageBase:getChildren()) do
        text:setOpacity(0)
        local actionSequence = cc.Sequence:create(
            cc.FadeIn:create(fadeInTime),
            cc.DelayTime:create(delayTime),
            cc.FadeOut:create(fadeOutTime)
        )
        text:runAction(actionSequence)
    end

    local function callBack()
        self._beginLoading = true
        self._panelTipBase:setVisible(false)
    end

    local allTime = fadeInTime + delayTime + fadeOutTime
    delayExecute(self._panelTipBase, callBack, allTime)
end

function KUIConfigLoadingNode:refreshUI()
    local mainNode = self._mainLayout
    
    local textInfo     = mainNode:getChildByName("Text_information")
    textInfo:setString("Config Loading (99/99)")
    
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")
    loadingBarPercent:setPercent(0)

    self._panelTipBase = cc.CSLoader:createNode("res/ui/layout_notice_healthy.csb")
    mainNode:addChild(self._panelTipBase)
    self:playAnimation()

    local textVersion  = mainNode:getChildByName("Text_version_number")
    textVersion:setString(VERSION)
end

function KUIConfigLoadingNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local textInfo          = mainNode:getChildByName("Text_information")
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")
    local loadingBase       = mainNode:getChildByName("Image_besd")

    local panelTipBase      = self._panelTipBase:getChildByName("Panel_base")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmClick~")
            self._beginLoading = true
            self._panelTipBase:setVisible(false)
        end
    end
    panelTipBase:addTouchEventListener(onConfirmClick)
end

function KUIConfigLoadingNode:registerAllCustomEvent()  
    local eventDispatchCenter   = require("src/logic/KEventDispatchCenter")
    local function oneFileLoadComplete()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.LOAD_FILE_COMPLETE, oneFileLoadComplete)
end

function KUIConfigLoadingNode:runEnterAction()
    local mainNode          = self._mainLayout
    local textInfo          = mainNode:getChildByName("Text_information")
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")

    for key, fileInfo in pairs(KConfig._loadTable) do 
        self._fileTotalCount = self._fileTotalCount + 1 
        table.insert(self._fileNameList, key)
    end

end

function KUIConfigLoadingNode:activate(nowTime)
    if not self._beginLoading then return end
    if self._isLoadingConfig then return end

    if self._loadFileIndex <= self._fileTotalCount then
        self._isLoadingConfig = true
        loadFile(self)
        self._isLoadingConfig = false
    end 
end

function KUIConfigLoadingNode:runExitAction()
end

function KUIConfigLoadingNode:onNodeEnter()
    tryReloadAll()
end


return KUIConfigLoadingNode
