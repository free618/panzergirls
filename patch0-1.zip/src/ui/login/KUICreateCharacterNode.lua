--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUICreateCharacterNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   14:33
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_tInitCardInfo = {
    {
        ["buttonName"]      = "Button_bt2", 
        ["normalTexture"]   = "res/ui/ui_material/start_character/dl_bt2.png", 
        ["pressTexture"]    = "res/ui/ui_material/start_character/dl_bt2_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/start_character/dl_bt2.png",
        ["descName"]        = "Image_dl_decipt_bt2",
        ["characterImage"]  = "res/images/initcharacter/character_bt2.png",
        ["cardIndex"]       = 1,
    },
    {
        ["buttonName"]      = "Button_i", 
        ["normalTexture"]   = "res/ui/ui_material/start_character/dl_i.png", 
        ["pressTexture"]    = "res/ui/ui_material/start_character/dl_i_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/start_character/dl_i.png",
        ["descName"]        = "Image_dl_decipt_i",
        ["characterImage"]  = "res/images/initcharacter/character_i.png",
        ["cardIndex"]       = 11,
    },
    {
        ["buttonName"]      = "Button_m2", 
        ["normalTexture"]   = "res/ui/ui_material/start_character/dl_m2.png", 
        ["pressTexture"]    = "res/ui/ui_material/start_character/dl_m2_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/start_character/dl_m2.png",
        ["descName"]        = "Image_dl_decipt_m2",
        ["characterImage"]  = "res/images/initcharacter/character_m2.png",
        ["cardIndex"]       = 19,
    },
    {
        ["buttonName"]      = "Button_nc31", 
        ["normalTexture"]   = "res/ui/ui_material/start_character/dl_nc31.png", 
        ["pressTexture"]    = "res/ui/ui_material/start_character/dl_nc31_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/start_character/dl_nc31.png",
        ["descName"]        = "Image_dl_decipt_nc31",
        ["characterImage"]  = "res/images/initcharacter/character_nc31.png",
        ["cardIndex"]       = 25,
    }
}

local NAME_MIN_LENGTH       = 2
local NAME_MAX_LENGTH       = 8

local KUICreateCharacterNode = class(
    "KUICreateCharacterNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)


function KUICreateCharacterNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._chooseCardIndex   = 1
end

function KUICreateCharacterNode.create(owner)
    local currentNode = KUICreateCharacterNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_create_character.csb"
    currentNode:init()

    KUtil.addRegisterRecord("createPanel")

    return currentNode
end

local function hideAllUI(self)
    local mainNode          = self._mainLayout
    local panelChoose       = mainNode:getChildByName("Panel_choose_character")
    local imageCharacter    = mainNode:getChildByName("Image_character_1")
    local panelDesc         = mainNode:getChildByName("Panel_desc_image")
    local buttonConfirm     = mainNode:getChildByName("Button_confirm")
    local buttonStart       = mainNode:getChildByName("Button_start_button")
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    
    panelChoose:setVisible(false)
    imageCharacter:setVisible(false)
    panelDesc:setVisible(false)
    buttonConfirm:setVisible(false)
    buttonStart:setVisible(false)
    imageNameInput:setVisible(false)
end

local function updateChooseCharacterUI(self)
    local playerProgress = KPlayer.progressID
    if playerProgress ~= ROLE_PROCESS_TYPE.ROLE_PROGRESS_CHOOSE_CARD then
        return
    end
    
    local mainNode          = self._mainLayout
    local panelChoose       = mainNode:getChildByName("Panel_choose_character")
    local imageCharacter    = mainNode:getChildByName("Image_character_1")
    local panelDesc         = mainNode:getChildByName("Panel_desc_image")
    local buttonConfirm     = mainNode:getChildByName("Button_confirm")
    local buttonStart       = mainNode:getChildByName("Button_start_button")
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    
    panelChoose:setVisible(true)
    imageCharacter:setVisible(true)
    panelDesc:setVisible(true)
    buttonStart:setVisible(true)
    
    -- reset buttonCard texture change choose buttonCard texture
    for k, v in pairs(m_tInitCardInfo) do
        local isChooseFlag = false
        if self._chooseCardIndex == k then isChooseFlag = true end
        
        -- button control
        local buttonControl     = panelChoose:getChildByName(v.buttonName)
        local normalTexture     = v.normalTexture
        local pressTexture      = v.pressTexture
        local disableTexture    = v.disableTexture
        if isChooseFlag then normalTexture = pressTexture end
        
        buttonControl:loadTextures(normalTexture, pressTexture, disableTexture)
        
        local canTouchFlag      = true
        if isChooseFlag then canTouchFlag = false end
        buttonControl:setTouchEnabled(canTouchFlag)
        
        -- desc control
        local imageDesc = panelDesc:getChildByName(v.descName)
        imageDesc:setVisible(isChooseFlag)
        
        --update imageCharacter
        if isChooseFlag then
            --print("-----> imageCharacter:loadTexture", v.characterImage)
            imageCharacter:loadTexture(v.characterImage)
        end
        --print("----------> k, isChooseFlag, canTouchFlag", k, isChooseFlag, canTouchFlag)
    end
end

local function updateRenameUI(self)
    local playerProgress = KPlayer.progressID
    if playerProgress ~= ROLE_PROCESS_TYPE.ROLE_PROGRESS_RENAME_NAME 
        and playerProgress ~= ROLE_PROCESS_TYPE.ROLE_PROGRESS_OLD_RENAME_NAME then
        return
    end
    
    local mainNode          = self._mainLayout
    local panelChoose       = mainNode:getChildByName("Panel_choose_character")
    local imageCharacter    = mainNode:getChildByName("Image_character_1")
    local panelDesc         = mainNode:getChildByName("Panel_desc_image")
    local buttonConfirm     = mainNode:getChildByName("Button_confirm")
    local buttonStart       = mainNode:getChildByName("Button_start_button")
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    local textName          = imageNameInput:getChildByName("Input_name")
    
    buttonConfirm:setVisible(true)
    imageNameInput:setVisible(true)
    textName:setMaxLength(NAME_MAX_LENGTH)

    self:hideRenameText()
end

function KUICreateCharacterNode:onNodeEnter()
    require("src/network/KC2SProtocolManager"):GenerateName()
    KUtil.addRegisterRecord("selectPanel")
end

function KUICreateCharacterNode:refreshUI()
    --cclog("----------> KUICreateCharacterNode:refreshUI currentPlayerProgress:%d", KPlayer.processID)
    hideAllUI(self)
    updateChooseCharacterUI(self)
    updateRenameUI(self)
end

function KUICreateCharacterNode:showRenameText(str)
    local mainNode          = self._mainLayout
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    local textName          = imageNameInput:getChildByName("Text_registered_tips")
    textName:setVisible(true)
    textName:setString(str)
end

function KUICreateCharacterNode:hideRenameText()
    local mainNode          = self._mainLayout
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    local textName          = imageNameInput:getChildByName("Text_registered_tips")
    textName:setVisible(false)
end

function KUICreateCharacterNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local panelChoose       = mainNode:getChildByName("Panel_choose_character")
    local imageCharacter    = mainNode:getChildByName("Image_character_1")
    local panelDesc         = mainNode:getChildByName("Panel_desc_image")
    local buttonConfirm     = mainNode:getChildByName("Button_confirm")
    local buttonStart       = mainNode:getChildByName("Button_start_button")
    local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
    
    local function onStartClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("---------->onConfirmClick")
        KSound.playEffect("click")
        -- send protocol apply to choose card
        local cardIndex = m_tInitCardInfo[self._chooseCardIndex].cardIndex
        cclog("-----> cardIndex : %d", cardIndex)
        require("src/network/KC2SProtocolManager"):applyChooseInitCard(cardIndex)
        hideAllUI(self)
    end
    buttonStart:addTouchEventListener(onStartClick)
    
    local function onConfirmClick (sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("---------->onStartClick")
        KSound.playEffect("click")
        self:hideRenameText()
        -- send protocol apply to rename
        local textName = imageNameInput:getChildByName("Input_name")
        local newName = textName:getString()
        
        if KUtil.hasSensitiveWord(newName) or KUtil.hasIllegalChar(newName) then
            showNoticeByID("common.renamefailed.illega_name")
            textName:setString("")
            require("src/network/KC2SProtocolManager"):GenerateName()
            return 
        end

        if string.utf8Len(newName) < NAME_MIN_LENGTH then
            showNoticeByID("common.renamefailed.short")
            textName:setString("")
            return 
        end
        
        if string.utf8Len(newName) > NAME_MAX_LENGTH then
            showNoticeByID("common.renamefailed.long")
            textName:setString("")
            return 
        end
        
        require("src/network/KC2SProtocolManager"):applyRename(newName)
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)
    
    -- register button for choose character
    for k, v in pairs(m_tInitCardInfo) do
        local buttonControl = panelChoose:getChildByName(v.buttonName)
        local function onChooseCardClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("----------> onChooseCardClick")
            KSound.playEffect("click")
            self._chooseCardIndex = k
            KUtil.addRegisterRecord("clickCard", k)
            self:refreshUI()
            print("----------> current currentCardIndex = ", k)
        end
        buttonControl:addTouchEventListener(onChooseCardClick)
    end
    
    local buttonDice        = imageNameInput:getChildByName("Button_dice")
    local function onDiceClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("---------->onDiceClick")
        KSound.playEffect("click")
        self:hideRenameText()
        require("src/network/KC2SProtocolManager"):GenerateName()

        buttonDice:setTouchEnabled(false)
        delayExecute(self._mainLayout, function ()
            buttonDice:setTouchEnabled(true)
        end, 1)
    end
    buttonDice:addTouchEventListener(onDiceClick)
end

function KUICreateCharacterNode:registerAllCustomEvent()
    local eventDispatch = require("src/logic/KEventDispatchCenter")

    local function onRenameFailed(nRetCode)
        local errortype         = string.lower(table.getkey(RENAME_RET, nRetCode))
        
        if nRetCode == RENAME_RET.USED then
            self:showRenameText(KUtil.getStringByKey("common.renamefailed.isUsed"))
        else
            showNoticeByID("common.renamefailed." .. errortype)
            self:hideRenameText()
        end
    end
    eventDispatch:registerEvent(eventDispatch.EventType.RENAME_FAILED, onRenameFailed)

    local function onGenerateName(szName)
        cclog("----------> onGenerateName, length:%d, name:%s, ", string.len(szName), szName)
        local mainNode          = self._mainLayout
        local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
        local textName          = imageNameInput:getChildByName("Input_name")
        textName:setString(szName)

        local imageNameInput    = mainNode:getChildByName("Image_dl_name_base")
        local buttonDice        = imageNameInput:getChildByName("Button_dice")
        buttonDice:setTouchEnabled(true)
    end
    eventDispatch:registerEvent(eventDispatch.EventType.NET_GENERATE_NAME_RET, onGenerateName)
end

function KUICreateCharacterNode:runEnterAction()
end

function KUICreateCharacterNode:runExitAction()
end

return KUICreateCharacterNode
