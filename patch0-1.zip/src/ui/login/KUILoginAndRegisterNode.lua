--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginAndRegisterNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   11:57
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local ACCOUNT_MAX_LENGTH    = 10
local ACCOUNT_MIN_LENGTH    = 4
local PASSWORD_MAX_LENGTH   = 10
local PASSWORD_MIN_LENGTH   = 4

local KUILoginAndRegisterNode = class(
    "KUILoginAndRegisterNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILoginAndRegisterNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._account       = nil
    self._password      = nil
    self._isVersionError = false
end

function KUILoginAndRegisterNode.create(owner)
    local currentNode = KUILoginAndRegisterNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign_up_registered.csb"
    if IS_BIND_ACCOUNT then
        currentNode._uiPath = "res/ui/layout_sign_up_registered_v2.csb"
    elseif IS_REGISTER_ACTIVATION then
        currentNode._uiPath = "res/ui/layout_sign_up_registered_v1.csb"
    end
    currentNode:init()
    
    return currentNode
end

local function checkRegularText(text, minLen, maxLen)
    if text == "" then
        local errorMsg = string.format(KUtil.getStringByKey("common.register.short"), minLen)
        return false, errorMsg    
    end
        
    local len = string.len(text)
    if len < minLen then 
        local errorMsg = string.format(KUtil.getStringByKey("common.register.short"), minLen)
        return false, errorMsg
    end
    
    if len > maxLen then 
        local errorMsg = string.format(KUtil.getStringByKey("common.register.long"), maxLen)
        return false, errorMsg
    end
    
    local fstart, fend, illegalChar = string.find(text, "([^0-9a-zA-Z_@%.])")
    if fstart ~= nil then
        local errorMsg = KUtil.getStringByKey("common.register.illegalCharacter")
        return false, errorMsg
    end

    return true, ""
end

local function checkAccount(account)
    local passed, errorMsg = checkRegularText(account, ACCOUNT_MIN_LENGTH, ACCOUNT_MAX_LENGTH)
    return passed, KUtil.getStringByKey("common.account") .. errorMsg
end

local function checkPassword(password)
    local passed, errorMsg = checkRegularText(password, PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH)
    if not passed then
        return false, KUtil.getStringByKey("common.password") .. errorMsg
    end
    
    local fstart, fend = string.find(password, "([^%w])")
    if fstart ~= nil then
        errorMsg = KUtil.getStringByKey("common.register.illegalPassword")
        passed = false
    end
     
    return passed, KUtil.getStringByKey("common.password") .. errorMsg
end

function KUILoginAndRegisterNode:setLoginButtonEnable(enable)
    local mainNode          = self._mainLayout
    local imageLoginBase    = mainNode:getChildByName("Image_login_base")
    local imageLogin        = imageLoginBase:getChildByName("Image_dl_login_base")
    local buttonLogin       = imageLogin:getChildByName("Button_login_button")
    buttonLogin:setTouchEnabled(enable)
end

function KUILoginAndRegisterNode:activate(nowTime)
    --cclog("-----> KUILoginAndRegisterNode nowTime:%d", nowTime)
end

function KUILoginAndRegisterNode:refreshAccountBindUI()
    local mainNode          = self._mainLayout
    local imageBindBase     = mainNode:getChildByName("Image_Bingding_base")
    imageBindBase:setVisible(true)
    local panelRoleInfo     = imageBindBase:getChildByName("Panel_Problem")

    local kSetting = require("src/logic/KSetting")

    local textServerName   = panelRoleInfo:getChildByName("TextField_1")
    textServerName:setString(kSetting.getString(kSetting.Key.SERVERNAME, ""))

    local textRoleName     = panelRoleInfo:getChildByName("TextField_2")
    textRoleName:setString(kSetting.getString(kSetting.Key.ROLE_NAME, ""))

    local textRoleLevel    = panelRoleInfo:getChildByName("TextField_3")
    textRoleLevel:setString(kSetting.getString(kSetting.Key.ROLE_LEVEL, ""))

    local textCoinCount    = panelRoleInfo:getChildByName("TextField_4")
    textCoinCount:setString(kSetting.getString(kSetting.Key.COIN_COUNT, ""))

    local textExchangeCode = panelRoleInfo:getChildByName("TextField_5")
    textExchangeCode:setString("")
end

function KUILoginAndRegisterNode:bindAccount()
    local mainNode          = self._mainLayout
    local imageBindBase     = mainNode:getChildByName("Image_Bingding_base")
    local panelRoleInfo     = imageBindBase:getChildByName("Panel_Problem")
    local panelAccountInfo  = imageBindBase:getChildByName("Panel_New")

    local tInfo = {}
    local textAccount       = panelAccountInfo:getChildByName("Input_account")
    tInfo.szAccountName     = textAccount:getString()
    local bPassed, nErrorMsg  = checkAccount(tInfo.szAccountName)
    if not bPassed then 
        return showNotice(nErrorMsg, "ban")
    end

    local textPassword        = panelAccountInfo:getChildByName("Input_new_password")
    local textConfirmPassword = panelAccountInfo:getChildByName("Input_confirm_password")
    tInfo.szPassword          = textPassword:getString()
    local szComfirmPassword   = textConfirmPassword:getString()

    local bPassed, nErrorMsg  = checkPassword(tInfo.szPassword)
    if not bPassed then
        return showNotice(nErrorMsg, "ban")
    end

    if tInfo.szPassword ~= szComfirmPassword then
        local nErrorMsg = KUtil.getStringByKey("common.register.notSamePassword")
        return showNotice(nErrorMsg, "ban")
    end

    local textServerName   = panelRoleInfo:getChildByName("TextField_1")
    tInfo.szServerName = textServerName:getString()
    if string.len(tInfo.szServerName) == 0 then
        return showNoticeByID(bindAccount.serverNameError)
    end

    local textRoleName     = panelRoleInfo:getChildByName("TextField_2")
    tInfo.szRoleName = textRoleName:getString()
    if string.len(tInfo.szRoleName) == 0 then
        return showNoticeByID(bindAccount.roleNameError)
    end

    local nErrorCount = 0
    local textRoleLevel    = panelRoleInfo:getChildByName("TextField_3")
    local szRoleLevel = textRoleLevel:getString()
    if string.len(szRoleLevel) == 0 then
        nErrorCount = nErrorCount + 1
    else
        tInfo.nRoleLevel = tonumber(szRoleLevel)
    end

    local textCoinCount    = panelRoleInfo:getChildByName("TextField_4")
    local szCoinCount = textCoinCount:getString()
    if string.len(szCoinCount) == 0 then
        nErrorCount = nErrorCount + 1
    else
        tInfo.nCoinCount = tonumber(szCoinCount)
    end

    local textExchangeCode = panelRoleInfo:getChildByName("TextField_5")
    local szExchangeCode = textExchangeCode:getString()
    if string.len(szExchangeCode) == 0 then
        nErrorCount = nErrorCount + 1
    else
        tInfo.szExchangeCode = szExchangeCode
    end
    
    if nErrorCount > 1 then
        return showNoticeByID(bindAccount.roleInfoError)
    end

    local kSetting = require("src/logic/KSetting")
    if tInfo.szServerName == kSetting.getString(kSetting.Key.SERVERNAME) and
       tInfo.szRoleName == kSetting.getString(kSetting.Key.ROLE_NAME) then
        local szRoleID = kSetting.getString(kSetting.Key.ROLE_ID)
        if string.len(szRoleID) ~= 0 then
            tInfo.nRoleID = tonumber(szRoleID)
            tInfo.szToken = kSetting.getString(kSetting.Key.TOKEN)
        end
    end

    KGameServer:BindAccount(tInfo)
end

function KUILoginAndRegisterNode:refreshUI()
    local mainNode      = self._mainLayout
    local imageRegisterBase = mainNode:getChildByName("Image_registerd_base")
    local imageRegister     = imageRegisterBase:getChildByName("Image_registered")
    imageRegisterBase:setVisible(false)
    
    local imageChangeBase = mainNode:getChildByName("Image_change_base")
    local imageChange     = imageChangeBase:getChildByName("Image_change")
    imageChangeBase:setVisible(false)
    
    local projectNodeTips = mainNode:getChildByName("ProjectNode_prompt")
    projectNodeTips:setVisible(false)

    local imageBindBase   = mainNode:getChildByName("Image_Bingding_base")
    if imageBindBase then
        imageBindBase:setVisible(false)
    end
    
    local buttonLogin   = mainNode:getChildByName("Button_login")
    
    local setting = require("src/logic/KSetting")
    local userAccount    = setting.getString(setting.Key.ACCOUNT)
    local userPassword   = setting.getString(setting.Key.PASSWORD)
    local imageLoginBase = mainNode:getChildByName("Image_login_base")
    local imageDlLoginBase = imageLoginBase:getChildByName("Image_dl_login_base")
    -- local buttonBinding    = imageDlLoginBase:getChildByName("Button_Binding")
    -- buttonBinding:setVisible(false)
    -- buttonBinding:setTouchEnabled(false)
    if PLAT_ID == PLAT_SELF then
        imageLoginBase:setVisible(true)
        if buttonLogin then
            buttonLogin:setVisible(false)
        end
        local imageLogin     = imageLoginBase:getChildByName("Image_dl_login_base")
        local textAccount    = imageLogin:getChildByName("Input_account")
        local textPassword   = imageLogin:getChildByName("Input_password")
        textAccount:setString(userAccount)
        textPassword:setString(userPassword)
    else
        imageLoginBase:setVisible(false)
        buttonLogin:setVisible(true)
    end

    local textVersion = mainNode:getChildByName("Text_version_number")
    textVersion:setString(VERSION)
end

function KUILoginAndRegisterNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    
    local imageRegisterBase         = mainNode:getChildByName("Image_registerd_base")
    local imageRegister             = imageRegisterBase:getChildByName("Image_registered")
    local buttonCloseRegister       = imageRegister:getChildByName("Button_close")
    local buttonCancelRegister      = imageRegister:getChildByName("Button_cancel_button")
    local function onCloseRegisterClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("on click close button~")
        KSound.playEffect("click")
        imageRegisterBase:setVisible(false)
    end
    buttonCloseRegister:addTouchEventListener(onCloseRegisterClick)
    buttonCancelRegister:addTouchEventListener(onCloseRegisterClick)
    
    local imageChangeBase           = mainNode:getChildByName("Image_change_base")
    local imageChange               = imageChangeBase:getChildByName("Image_change")
    local buttonCloseChangePassword = imageChange:getChildByName("Button_close")
    local function onClosePasswordClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("on click close button~")
        KSound.playEffect("click")
        imageChangeBase:setVisible(false)
    end
    buttonCloseChangePassword:addTouchEventListener(onClosePasswordClick)
    
    local buttonConfirmRegister = imageRegister:getChildByName("Button_sign_up_button")
    local function onConfirmRegisterClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("on click confirm register button~")
        KSound.playEffect("click")
        local textAccount           = imageRegister:getChildByName("Input_account")
        local textPassword          = imageRegister:getChildByName("Input_password")
        local textConfirmPassword   = imageRegister:getChildByName("Input_confirm_password")
        
        local account           = textAccount:getString()
        local password          = textPassword:getString()
        local comfirmPassword   = textConfirmPassword:getString()
        local szActivationCode
        
        local passed, errorMsg = checkAccount(account)
        if not passed then 
            showNotice(errorMsg, "ban")
            return
        end

        local passed, errorMsg = checkPassword(password)
        if not passed then
            showNotice(errorMsg, "ban")
            return 
        end

        if password ~= comfirmPassword then
            local errorMsg = KUtil.getStringByKey("common.register.notSamePassword")
            showNotice(errorMsg, "ban")
            return
        end
        
        if IS_REGISTER_ACTIVATION then
            local textActivationCode    = imageRegister:getChildByName("Input_activation_code")
            szActivationCode = textActivationCode:getString()
            local errorMsgID = KUtil.checkActivationCode(szActivationCode)
            if errorMsgID then
                showNoticeByID(errorMsgID)
                return
            end
        end
        self._account  = account
        self._password = password
        KGameServer:Register(account, password, szActivationCode)
        imageRegisterBase:setVisible(false)
    end
    buttonConfirmRegister:addTouchEventListener(onConfirmRegisterClick)
    
    local buttonConfirmChangePassword = imageChange:getChildByName("Button_sign_up_button")
    local function onConfirmChangePassword(sender, type)
        if type ~= ccui.TouchEventType.ended then return end    
        cclog("on click confirm change password button ~")
        KSound.playEffect("click")
        local textAccount           = imageChange:getChildByName("Input_account")
        local textOldPassword       = imageChange:getChildByName("Input_old_password")
        local textNewPassword       = imageChange:getChildByName("Input_new_password")
        local textConfirmPassword   = imageChange:getChildByName("Input_confirm_password")
        
        local account           = textAccount:getString()
        local oldPassword       = textOldPassword:getString()
        local newPassword       = textNewPassword:getString()
        local confirmPassword   = textConfirmPassword:getString()
        
        local passed, errorMsg = checkPassword(newPassword)
        if not passed then 
            showNotice(errorMsg, "ban")
            return
        end
        
        if newPassword ~= confirmPassword then 
            local errorMsg = KUtil.getStringByKey("common.register.notSamePassword")
            showNotice(errorMsg, "ban")
            return
        end
        
        self._account   = account
        self._password  = newPassword 
        KGameServer:ChangePassword(account, oldPassword, newPassword)
        imageChangeBase:setVisible(false)
    end
    buttonConfirmChangePassword:addTouchEventListener(onConfirmChangePassword)
   
    local buttonCancelButton = imageChange:getChildByName("Button_cancel_button") 
    local function onCancelChangePassword(sender, eventType)
        if eventType ~= ccui.TouchEventType.ended then return end
        cclog("on click close button~")
        KSound.playEffect("click")
        imageChangeBase:setVisible(false)
    end
    buttonCancelButton:addTouchEventListener(onCancelChangePassword)

    local imageLoginBase    = mainNode:getChildByName("Image_login_base")
    local imageLogin        = imageLoginBase:getChildByName("Image_dl_login_base")
    local buttonLogin       = imageLogin:getChildByName("Button_login_button")
    local function onLoginClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._isVersionError then 
            showNoticeByID("common.versionError")
            return
        end
        --showNotice("Click Login Button")
        cclog("on click login button~")
        KSound.playEffect("click")
        local textAccount   = imageLogin:getChildByName("Input_account")
        local textPassword  = imageLogin:getChildByName("Input_password")
        
        local account   = textAccount:getString()
        if not account or string.len(account) == 0 then return end
        local password  = textPassword:getString()
        if not password or string.len(password) == 0 then return end
        KGameServer:Login(account, password)
    end
    buttonLogin:addTouchEventListener(onLoginClick)
    
    local buttonRegister = imageLogin:getChildByName("Button_sign_up_button")
    local function onRegisterClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("on click register button~")
        KSound.playEffect("click")
        imageRegisterBase:setVisible(true)
    end
    buttonRegister:addTouchEventListener(onRegisterClick)
    
    local buttonChange = imageLogin:getChildByName("Button_change")
    local function onChangePassword(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("on click change password button~")
        KSound.playEffect("click")
        imageChangeBase:setVisible(true)
    end
    buttonChange:addTouchEventListener(onChangePassword)

    -- local buttonBind   = imageLogin:getChildByName("Button_Binding")
    -- if buttonBind then
    --     local function onBind(sender, type)
    --         if type ~= ccui.TouchEventType.ended then return end
    --         cclog("on click bind account button~")
    --         KSound.playEffect("click")
    --         self:refreshAccountBindUI()
    --     end
    --     buttonBind:addTouchEventListener(onBind)
    -- end

    local imageBindBase     = mainNode:getChildByName("Image_Bingding_base")
    if imageBindBase then
        local buttonBindConfirm = imageBindBase:getChildByName("Button_sign_up_button")
        local function onBindConfirm(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("on click bind confirm button~")
            KSound.playEffect("click")
            self:bindAccount()
        end
        buttonBindConfirm:addTouchEventListener(onBindConfirm)

        local buttonBindClose = imageBindBase:getChildByName("Button_close")
        local function onBindClose(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("on click bind confirm button~")
            KSound.playEffect("click")
            imageBindBase:setVisible(false)
        end
        buttonBindClose:addTouchEventListener(onBindClose)
    end

    local buttonSDKLogin = mainNode:getChildByName("Button_login")
    if buttonSDKLogin then
        local function onSDKLoginClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            if PLAT_ID == PLAT_SELF then return end
            if self._isVersionError then 
                showNoticeByID("common.versionError")
                return
            end
            cclog("on click login button~")
            cclog("-----> Call C_SDKAgent.Login")
            
            C_SDKAgent.Login("S1")

            buttonSDKLogin:setTouchEnabled(false)
        end
        buttonSDKLogin:addTouchEventListener(onSDKLoginClick)
    end
end

function KUILoginAndRegisterNode:registerAllCustomEvent()
    --self:addCustomEvent(eventType, callbackFunc)
    local eventDispatch = require("src/logic/KEventDispatchCenter")

    local mainNode          = self._mainLayout
    local imageLoginBase    = mainNode:getChildByName("Image_login_base")
    local imageLogin        = imageLoginBase:getChildByName("Image_dl_login_base")
    local textLoginAccount  = imageLogin:getChildByName("Input_account")
    local textLoginPassword = imageLogin:getChildByName("Input_password")
    
    local function onRegisterResult(retCode)
        cclog("----------> onEvent NET_REGISTER_RESULT %d", retCode)
        if retCode == REG_ACCOUNT_RET.SUCCESS then
            showNotice("Register Success~", "success")
            textLoginAccount:setString(self._account)
            textLoginPassword:setString(self._password)
            return
        end
        
        if retCode == REG_ACCOUNT_RET.EXISTED_ACCOUNT then
            showNotice("Account is existed~", "ban")
        elseif retCode == REG_ACCOUNT_RET.ACTIVATION_CODE_ERROR then
            showNoticeByID("common.register.activationCodeError")
        elseif retCode == REG_ACCOUNT_RET.ACTIVATION_CODE_USED then
            showNoticeByID("common.register.activationCodeUsed")
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_REGISTER_RESULT, onRegisterResult)

    local function onLoginResult(retCode)
        cclog("----------> onEvent NET_LOGIN_RESULT %s", tostring(retCode))
        if retCode == LOGIN_RET.SUCCESS then
            showNotice("Login Success~", "success")
            local userAccount    = textLoginAccount:getString()
            local userPassword   = textLoginPassword:getString()
            KUtil.switchAccountClean(userAccount)

            local setting = require("src/logic/KSetting")
            setting.setString(setting.Key.ACCOUNT, userAccount)
            setting.setString(setting.Key.PASSWORD, userPassword)
            return
        end

        local buttonSDKLogin = mainNode:getChildByName("Button_login")
        if buttonSDKLogin and buttonSDKLogin:isVisible() then 
            buttonSDKLogin:setTouchEnabled(true)
        end

        if retCode == LOGIN_RET.NOT_ACTIVE then
            self._parent:addNode("Activate")
            return 
        end
        
        if retCode == LOGIN_RET.INVALID_ACCOUNT then
            showNotice("Account is not existed~", "ban")
            return 
        end
        
        if retCode == LOGIN_RET.PASSWORD_ERROR then
            showNotice("Password is error~", "ban")
            return
        end

        if retCode == LOGIN_RET.AUTH_SERVER_BUSY then
            showNotice("Authentication server is busy~", "ban")
            return
        end

        if retCode == LOGIN_RET.GS_BUSY then
            showNotice("Game server is busy~", "ban")
            return
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_LOGIN_RESULT, onLoginResult)
    
    local function onChangePasswordResult(retCode) 
        cclog("----------> onEvent NET_CHANGE_PASSWORD_RESULT %d", retCode)
        if retCode == CHANGE_PASSWORD_RET.SUCCESS then
            showNotice("Change Password Success~", "success")
            textLoginAccount:setString(self._account)
            textLoginPassword:setString(self._password)
            return
        end
        
        if retCode == CHANGE_PASSWORD_RET.NOT_EXISTED_ACCOUNT then
            showNotice("Account is not existed~", "ban")
        elseif retCode == CHANGE_PASSWORD_RET.OLD_PASSWORD_ERROR then
            showNotice("Old password input is not correct~", "ban")
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_CHANGE_PASSWORD_RESULT, onChangePasswordResult) 
    
    local function onSyncServerList(serverList)
        cclog("----------> onEvent NET_SYNC_SERVER_LIST")
        local serverListNode = self._parent:addNode("ServerList")
        serverListNode:setServerList(serverList)
    end
    self:addCustomEvent(eventDispatch.EventType.NET_SYNC_SERVER_LIST, onSyncServerList)

    local function onLSHandshake(nRetCode, szServerVersion)
        cclog("----------> onEvent NET_LS_HANDSHAKE: %d", nRetCode)
        local setting       = require("src/logic/KSetting")
        setting.setString(setting.Key.SERVER_VERSION, szServerVersion)
        if nRetCode == LS_HANDSHAKE_RESPOND_RET.VERSION_ERROR then
            self._isVersionError = true
            local function closeGame()
                cc.Director:getInstance():endToLua() 
            end
            showConfirmation(KUtil.getStringByKey("common.versionError"), closeGame, closeGame)
        else
            assert(nRetCode == LS_HANDSHAKE_RESPOND_RET.SUCCESS)
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_LS_HANDSHAKE, onLSHandshake)

    local function onBindAccount(nRetCode)
        cclog("----------> onEvent NET_BIND_ACCOUNT_RESULT")
        local tTipID = {
            [BIND_ACCOUNT_RET.SUCCESS]                 = 'bindAccount.success',
            [BIND_ACCOUNT_RET.SERVER_NOT_EXIST]        = 'bindAccount.serverNameError',
            [BIND_ACCOUNT_RET.ACCOUNT_NOT_EXIST]       = 'common.accountNotExist',
            [BIND_ACCOUNT_RET.ROLE_NOT_EXIST]          = 'errorCode14',
            [BIND_ACCOUNT_RET.ACCOUNT_NAME_REPETITION] = 'common.accountRepetition',
            [BIND_ACCOUNT_RET.BOUND]                   = 'bindAccount.bound',
            [BIND_ACCOUNT_RET.INFO_ERROR]              = 'bindAccount.roleInfoError',
        }
        assert(tTipID[nRetCode], nRetCode)
        showNoticeByID(tTipID[nRetCode])

        if nRetCode == BIND_ACCOUNT_RET.SUCCESS then
            local imageBindBase     = mainNode:getChildByName("Image_Bingding_base")
            imageBindBase:setVisible(false)
        end
    end
    self:addCustomEvent(eventDispatch.EventType.NET_BIND_ACCOUNT_RESULT, onBindAccount)
end

function KUILoginAndRegisterNode:runEnterAction()
end

function KUILoginAndRegisterNode:runExitAction()
end

return KUILoginAndRegisterNode
