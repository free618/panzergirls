--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginLoadingNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   14:22
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUILoginLoadingNode = class(
    "KUILoginLoadingNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILoginLoadingNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._syncCount     = 0
end

function KUILoginLoadingNode.create(owner)
    local currentNode = KUILoginLoadingNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign_up_loading.csb"
    currentNode:init()
    
    return currentNode
end

function KUILoginLoadingNode:refreshUI()
    local mainNode          = self._mainLayout
    local textInfo          = mainNode:getChildByName("Text_information")
    textInfo:setString("")
    
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")
    loadingBarPercent:setPercent(0)

    local textVersion       = mainNode:getChildByName("Text_version_number")
    textVersion:setString(VERSION)
end

function KUILoginLoadingNode:registerAllTouchEvent()
end

local function updatePlayerProgress(self)
    local playerProgress = KPlayer.progressID
    cclog("----------> onEvent NET_SYNC_DATA_END %d", playerProgress)
    if playerProgress == ROLE_PROCESS_TYPE.ROLE_PROGRESS_CHOOSE_CARD then
        -- jump to create character ui . create page .
        local createCharacterNode = self._parent:addNode("CreateCharacter")
        createCharacterNode:refreshUI()
        return
    end
    
    if playerProgress == ROLE_PROCESS_TYPE.ROLE_PROGRESS_RENAME_NAME 
        or playerProgress == ROLE_PROCESS_TYPE.ROLE_PROGRESS_OLD_RENAME_NAME then
        -- jump to create character ui . rename name page .
        local createCharacterNode = self._parent:addNode("CreateCharacter")
        createCharacterNode:refreshUI()
        return
    end
    
    if playerProgress >= ROLE_PROCESS_TYPE.ROLE_PROGRESS_READY then
        -- jump to create character ui . office scene page .
        KUtil.configPixelQuality()
        require("src/logic/KGuideEnv").init()
        local officeScene = require("src/ui/office/KUIOfficeScene").create("login")
        KUtil.replaceSceneAndRemoveAllTexture(officeScene)
        return 
    end
end

function KUILoginLoadingNode:registerAllCustomEvent()
    --self:addCustomEvent(eventType, callbackFunc)
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    local function onUpdatePlayerProgress()
        if self._syncCount ~= #SYNC_LIST then return end
        updatePlayerProgress(self)
    end
    self:addCustomEvent(eventDispatch.EventType.NET_UPDATE_PLAYER_PROGRESS, onUpdatePlayerProgress)
end

function KUILoginLoadingNode:runEnterAction()
    local mainNode          = self._mainLayout
    local textInfo          = mainNode:getChildByName("Text_information")
    local loadingBarPercent = mainNode:getChildByName("LoadingBar_loading")
    
    local function updateLoadingBar()
        if self._syncCount == #SYNC_LIST then
            self:stopAllActions()
            updatePlayerProgress(self)
            return
        end

        local nOldSyncCount   = self._syncCount
        if KPlayer.nSyncCount > self._syncCount then
            self._syncCount   = KPlayer.nSyncCount--self._syncCount + 1
        end
        assert(self._syncCount <= #SYNC_LIST, "" .. self._syncCount .. "/" .. #SYNC_LIST)
        if self._syncCount == #SYNC_LIST then
            textInfo:setString(KConfig:getLine("string", "sync.end").szText)
        else
            local szDataName
            if self._syncCount == 0 then
                szDataName = SYNC_LIST[1][2]
            else
                szDataName = SYNC_LIST[self._syncCount][2]
            end
            
            if szDataName then
                textInfo:setString(string.format(KConfig:getLine("string", "sync.begin").szText, szDataName))
            end 
        end

        local percent = loadingBarPercent:getPercent()
        percent = percent + 2
        local nMinPercent = (self._syncCount) / #SYNC_LIST * 100
        if nMinPercent > percent then
            percent = nMinPercent
        end

        local nMaxPercent = 100
        if self._syncCount < #SYNC_LIST then
            nMaxPercent = (self._syncCount + 1) / #SYNC_LIST * 100
        end
        if percent > nMaxPercent then
            percent = nMaxPercent
        end
        loadingBarPercent:setPercent(percent)     
    end
    local actionSequene = cc.Sequence:create(
        -- cc.DelayTime:create(0.01), 
        cc.CallFunc:create(updateLoadingBar)
    )
    local action = cc.RepeatForever:create(actionSequene)
    self:runAction(action)
end

function KUILoginLoadingNode:runExitAction()
end

return KUILoginLoadingNode
