--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginScene.lua
--  Creator     : SunXun
--  Date        : 2015/07/20   21:17
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local KSetting = require("src/logic/KSetting")
VERSION = KSetting.getString(KSetting.Key.VERSION, VERSION)
assert(VERSION) 

local KUILoginScene = class(
    "KUILoginScene", function() return cc.Scene:create()end
)

function KUILoginScene:ctor()
    self._nodeList      = {}
    self._nodeZOrder    = 1
end

KUILoginScene.NodeType = {
    ["LoginAndRegister"]    = "src/ui/login/KUILoginAndRegisterNode",
    ["ServerList"]          = "src/ui/login/KUIServerListNode",
    ["LoginLoading"]        = "src/ui/login/KUILoginLoadingNode",
    ["CreateCharacter"]     = "src/ui/login/KUICreateCharacterNode",
    ["ConfigLoading"]       = "src/ui/login/KUIConfigLoadingNode",
    ["AutoUpdate"]          = "src/ui/login/KUIAutoUpdateNode",
    ["Activate"]            = "src/ui/login/KUILoginActivateNode",
    ["Announce"]            = "src/ui/login/KUILoginAnnounceNode",
}

function KUILoginScene.create()
    local currentScene = KUILoginScene.new()

    local isAutoUpdate = false
    if not (C_AsyncDownloadFile and UPDATE_V2_ENABLE) then
        isAutoUpdate = false
        local targetPlatform = cc.Application:getInstance():getTargetPlatform()
        if targetPlatform ~= cc.PLATFORM_OS_WINDOWS and 
            targetPlatform ~= cc.PLATFORM_OS_LINUX and
            targetPlatform ~= cc.PLATFORM_OS_MAC then
            isAutoUpdate = true -- close auto updte for Full Client
        end 
    end
    
    if not isAutoUpdate then
        require("src/logic/KMainLoop"):start()
        currentScene:addNode("ConfigLoading")
    else
        currentScene:addNode("AutoUpdate")
    end

    AudioEngine.stopMusic(false)
    
    return currentScene
end

function KUILoginScene:addNode(nodeType, ...)
    local filePath = KUILoginScene.NodeType[nodeType]
    assert(filePath)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
    
    local uiNode = require(filePath).create(self, ...)
    table.insert(self._nodeList, {["nodeType"] = nodeType, ["uiNode"] = uiNode})
    self:addChild(uiNode, self._nodeZOrder)
    self._nodeZOrder = self._nodeZOrder + 1
    return uiNode
end

function KUILoginScene:getNode(nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
end

function KUILoginScene:removeNode(nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then
            self:removeChild(v["uiNode"], true)
            table.remove(self._nodeList, k)
            return
        end
    end
    
    assert(0, "try remove a unexisted node ! nodeType:%s", nodeType)
    return 0
end

return KUILoginScene
