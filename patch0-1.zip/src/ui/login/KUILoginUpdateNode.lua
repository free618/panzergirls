--  ********************************************************************
--  Copyright(c) Capricegame
--  FileName    : KUILoginUpdateNode.lua
--  Creator     : hanruofei
--  Date        : 2016/11/05   23:09
--  Contact     : free618@126.com
--  Comment     : 
--  *********************************************************************


require "src/lib/lib"

local versionInfo = require("src/version")
local knowHow = require("src/settings/knowhow")
local newestVersionUrls = 
{
	--"https://github.com/free618/panzergirls/files/577540/"
	"https://raw.githubusercontent.com/free618/panzergirls/master/"
    --"http://103.238.227.24:21000/tankgirl/update_v2/",
}

local function printValue(value)
	for k, v in pairs(value) do
		C_Log(string.format("k: %s v:%s", tostring(k), tostring(v)))
	end
end

local PATCH_FILE_STATE = {
	TO_DOWNLOAD    = "TO_DOWNLOAD",
	DOWNLOADING    = "DOWNLOADING",
	DOWNLOADED     = "DOWNLOADED",
	UNZIPPING      = "UNZIPPING",
	DONE           = "DONE",
	DOWNLOAD_ERROR = "DOWNLOAD_ERROR",
	UNZIP_ERROR    = "UNZIP_ERROR",
}

local STATE = {
	INVALID       = "INVALID",
	CHECK_VRESION = "CHECK_VRESION",
	DOWNLOADING   = "DOWNLOADING",
	UNZIPPING     = "UNZIPPING",
	ERROR         = "ERROR",
	END   = "END",
	NEWEST 		  = "NEWEST",
}

local STATE_DECRIPTION  = {
	[STATE.INVALID]       = "Preparing ...",
	[STATE.CHECK_VRESION] = "Checking version",
	[STATE.DOWNLOADING]   = "Downloading",
	[STATE.UNZIPPING]     = "Unziping:",
	[STATE.ERROR]         = "A error occur:",
	[STATE.END]           = "Update finished~",
	[STATE.NEWEST]        = "Client is newest~",
}

local ERROR_DETAIL = {
	ALL_RIGHT = "All right~",
	DOWNLOAD_ERROR = "Download error~",
	UNZIP_ERROR = "Unzip error~",
}

local CARD_SATE_PATH 	 = {
	COMMON = "res/ui/ui_material/update/update_card.png",
	UPPER  = "res/ui/ui_material/update/update_card_2s.png",
	LOWER  = "res/ui/ui_material/update/update_card_1s.png",
}

local KUILoginUpdateNode = class(
    "KUILoginUpdateNode", function () return cc.Node:create() end
)

KUILoginUpdateNode.STATE = STATE
KUILoginUpdateNode.newestVersionUrls = newestVersionUrls
KUILoginUpdateNode.STATE_DECRIPTION = STATE_DECRIPTION
KUILoginUpdateNode.ERROR_DETAIL = ERROR_DETAIL
KUILoginUpdateNode.MAX_HIT_COUNT     = 999
KUILoginUpdateNode.CUT_OFF_COUNT     = 3
KUILoginUpdateNode.RESTORE_TIME      = 3000
KUILoginUpdateNode.MIN_NORMAL_SPEED  = 1024 * 5
KUILoginUpdateNode.FONT_PATH     	 = "res/ui/ui_material/update/updated_words_chinese.fnt"
KUILoginUpdateNode.CARD_SATE_PATH 	 = CARD_SATE_PATH

function KUILoginUpdateNode:getSizeString(nSize)
    local tUnitList  = {"B", "KB", "MB", "GB"}
    local nUnitIndex = 1
    while nSize > 1024 do
        nSize = nSize / 1024
        nUnitIndex = nUnitIndex + 1
        if nUnitIndex == #tUnitList then
            break
        end
    end
    return string.format("%.2f%s", nSize, tUnitList[nUnitIndex])
end

function KUILoginUpdateNode:setSettingString(key, value)
    cc.UserDefault:getInstance():setStringForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KUILoginUpdateNode:getSettingString(key, default)
    return cc.UserDefault:getInstance():getStringForKey(key, default)
end

function KUILoginUpdateNode:setSettingBool(key, value)
    cc.UserDefault:getInstance():setBoolForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

function KUILoginUpdateNode:getSettingBool(key, default)
    local _default = default or false
    return cc.UserDefault:getInstance():getBoolForKey(key, _default)
end

function KUILoginUpdateNode:ctor()
    self._parent          = nil
    self._mainLayout      = nil
    self._uiPath       	  = "res/ui/layout_updated.csb"

	self.state 			  = STATE.INVALID
	self.localVersion 	  = tonumber(self:getSettingString("versionNumber", "")) or  versionInfo.versionNumber
	self.remoteVersion 	  = nil
	self.patchFiles 		= {}

	self.cardState 			= "COMMON" 
	self.lastHitTime 		=  nil
	self.totalHitCount 		= 0
	self.partHitCount		= {}

    self.shownKnowIndex   	= 1
    self.labelKnowHow    	= nil

	self.sendedErrorList 	= {}

	local writablePath      = cc.FileUtils:getInstance():getWritablePath()
    self.storagePath       	= writablePath .. "load/update/"
    self.srcPath            = writablePath .. "s1_update/"
end

function KUILoginUpdateNode.create(owner)
    local currentNode          = KUILoginUpdateNode.new()
    currentNode._parent        = owner
    currentNode:init()
    return currentNode
end


function KUILoginUpdateNode:sendError(k, v)
	if not sendInfoGatherServer then return end
	if self.sendedErrorList[k] then return end
    self.sendedErrorList[k] = true
    sendInfoGatherServer(k .. tostring(v))
end

function KUILoginUpdateNode:reloadOne(moduleName)
    if package.loaded[moduleName] then
        package.loaded[moduleName] = nil
        require(moduleName)
    end
end

function KUILoginUpdateNode:tryReloadAll()
    self:reloadOne("src/base/KGlobalFunction")
    self:reloadOne("src/ui/common/KUIShowConfirmationNode")
    self:reloadOne("src/version")
    self:reloadOne("src/ui/login/KUILoginUpdateNode")
end

function KUILoginUpdateNode:beginGame()
    self:tryReloadAll()
    local gameScene = require("src/ui/login/KUILoginScene").create()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(gameScene)
    else
        cc.Director:getInstance():runWithScene(gameScene)
    end
end

function KUILoginUpdateNode:showDialog(content)
    local mainNode = self._mainLayout
    local nodeTips = mainNode:getChildByName("Image_update_information")
    nodeTips:setVisible(true)

    local scrollView = nodeTips:getChildByName("ScrollView_update_information")
    local textInfo   = scrollView:getChildByName("BitmapFontLabel_update_information")
    textInfo:setString(content)
end

function KUILoginUpdateNode:showknowHow()
	local mainNode      = self._mainLayout
    local imageknowHow  = mainNode:getChildByName("Image_dialog_box")
    local labelknowHow  = imageknowHow:getChildByName("BitmapFontLabel_text")
	local szText        = knowHow[self.shownKnowIndex].szText
    assert(szText)
	labelknowHow:setString(szText)
	do return end


    if self.labelKnowHow then
		if self.labelKnowHow.name == "knowHowLabel_" .. self.shownKnowIndex then
			return
		end
        imageknowHow:removeChild(self.labelKnowHow)
		self.labelKnowHow = nil
    end

	local label = cc.LabelBMFont:create(szText, self.FONT_PATH)
    label:setWidth(labelknowHow:getContentSize().width)
    label:setAnchorPoint(0, 1)            
    label:setPosition(labelknowHow:getPosition())
    imageknowHow:addChild(label)
    self.labelKnowHow = label
	label.name = "knowHowLabel_" .. self.shownKnowIndex
end

function KUILoginUpdateNode:refreshVerionInfo()
	local mainNode      = self._mainLayout
    local textVersion = mainNode:getChildByName("Text_version_number")
	textVersion:setString(tostring(self.localVersion))
end

function KUILoginUpdateNode:setCardState(newState)
	if self.cardState == newState then return end
    self.cardState = newState
    local mainNode    = self._mainLayout
    local imageCard   = mainNode:getChildByName("Image_update_card")
    imageCard:loadTexture(CARD_SATE_PATH[self.cardState])
end

function KUILoginUpdateNode:showHitCount()
    local mainNode      = self._mainLayout
    local panelTipPlate = mainNode:getChildByName("Panel_countdown")
    local labelHitCount = panelTipPlate:getChildByName("BitmapFontLabel_girl_digital")
    labelHitCount:setString(tostring(self.totalHitCount))
end

function KUILoginUpdateNode:hit(part)
    self.lastHitTime 	= C_GetTickCount()
    self.totalHitCount  = self.totalHitCount + 1
    if self.totalHitCount > self.MAX_HIT_COUNT then
        self.totalHitCount = self.MAX_HIT_COUNT
    end
    self:showHitCount()

	self.shownKnowIndex = self.shownKnowIndex + 1
    if self.shownKnowIndex > #knowHow then
        self.shownKnowIndex = 1
    end

    self:showknowHow()
	self.partHitCount[part] = (self.partHitCount[part] or 0) + 1 
    if self.partHitCount[part] >= self.CUT_OFF_COUNT then
        self.partHitCount[part] = 0
        self:setCardState(part)
    end
end

function KUILoginUpdateNode:downloadFile(remoteUrls, file, localPath, enableResume, fnOnSuccess, fnOnFailed, fnOnProgress, fnCheckFile)
	local urls = {}
	for _, v in ipairs(remoteUrls) do
		table.insert(urls, v)
	end
	
	local function tryDownloadFileOnce(url, triedCount, localPath, enableResume)
		local remoteUrl = url .. file
		local curSpeed = 0
		local calcStartTickCount = C_GetTickCount()
		local calcStartLoadSize = 0
		local CALC_INTERVAL = 500
		local function onProgress(remoteUrl, fileSize, loadSize)
			local curTickCount = C_GetTickCount()
			if curTickCount - calcStartTickCount > CALC_INTERVAL then
				curSpeed = (loadSize - calcStartLoadSize) / ((curTickCount - calcStartTickCount) / 1000)
				calcStartLoadSize = loadSize
				calcStartTickCount = curTickCount
			end

			C_Log(string.format("DownloadFile:%s speed:%d loadSize:%d fnOnProgress:%s", file, curSpeed, loadSize, tostring(fnOnProgress)))
			if fnOnProgress then
				fnOnProgress(curSpeed, loadSize)
			end
		end

		local function onEnd(remoteUrl, result, fileSize, loadSize, szError)
			if result then
				if not fnCheckFile or fnCheckFile() then
					fnOnSuccess(file, fileSize, loadSize)
					return
				end
				C_Log("Failed to CheckFile:" .. localPath)
			end

			triedCount = triedCount + 1
			if triedCount < 3 then
				tryDownloadFileOnce(url, triedCount, localPath, enableResume)
				return
			end

			if #urls == 0 then
				fnOnFailed(file, szError)
				return
			end
			local url = table.remove(urls, 1)
			tryDownloadFileOnce(url, 0, localPath, enableResume)
		end

		local connectTimeout = 10
		local result = C_AsyncDownloadFile(remoteUrl, localPath, connectTimeout, enableResume, onEnd, onProgress)
		assert(result)
		C_Log(string.format("C_AsyncDownloadFile: %s %s %s %s", remoteUrl, localPath, tostring(connectTimeout), tostring(enableResume)))
	end
	local url = table.remove(urls, 1)
	tryDownloadFileOnce(url, 0, localPath, enableResume)
end

KUILoginUpdateNode["active_" .. STATE.INVALID] = function(self)
	assert(self.state == STATE.INVALID)
	local file      = "newestversion.txt"
	if C_AsyncDownloadFile_V2 then
		file = "newestversion_v2.txt"
	end
	local localPath = self.storagePath .. file
	local urls      = self.newestVersionUrls

	local function onSuccess()
		assert(self.state == STATE.INVALID or self.state == STATE.CHECK_VRESION)
		local data = cc.FileUtils:getInstance():getStringFromFile(localPath)
		local versionData  = loadstring(data)()
		self.remoteVersion = versionData.versionNumber
		C_Log(string.format("LocalVersion:%d RemoteVersion:%d", self.localVersion, self.remoteVersion))
		if self.remoteVersion <= self.localVersion then
			self.state = STATE.NEWEST
			local function delayBeginGame()
				C_StopAllDownload()
            	self:stopAllActions()
				self:beginGame()
			end
            delayExecute(self, delayBeginGame, 1)
			return
		end

		self.patchFiles = {}
		for i = self.localVersion + 1 , self.remoteVersion do
			local patchFile = versionData.patchFiles[i]
			patchFile.state = PATCH_FILE_STATE.TO_DOWNLOAD
			patchFile.downloadedSize = 0
			patchFile.speed = 0
			patchFile.uncompressCount = 0
			patchFile.localPath = self.storagePath .. patchFile.file
			table.insert(self.patchFiles, patchFile)
		end
		self.state = STATE.DOWNLOADING
	end
	local function onFailed()
		assert(self.state == STATE.INVALID or self.state == STATE.CHECK_VRESION)
		self.state = STATE.ERROR
	end

	self:downloadFile(urls, file, localPath, false, onSuccess, onFailed)

	assert(self.state == STATE.INVALID)
	self.state = STATE.CHECK_VRESION
end

KUILoginUpdateNode["active_" .. STATE.DOWNLOADING] = function(self)
	assert(self.state == STATE.DOWNLOADING)
	if HArray.FindFirst(self.patchFiles, "state", PATCH_FILE_STATE.DOWNLOADING) then
		return
	end

	local fileInfo = HArray.FindFirst(self.patchFiles, "state", PATCH_FILE_STATE.TO_DOWNLOAD)
	if fileInfo then
		local urls = fileInfo.urls
		local file = fileInfo.file
		local localPath = fileInfo.localPath
		local function onSuccess(file, fileSize, loadSize)
			assert(fileInfo.state == PATCH_FILE_STATE.DOWNLOADING)
			fileInfo.state          = PATCH_FILE_STATE.DOWNLOADED
			fileInfo.speed          = 0
			fileInfo.downloadedSize = loadSize
			C_Log(string.format("onSucces downloaded:%d fileSize:%d", loadSize, fileSize))
		end

		local function onFailed(file, errorInfo)
			assert(fileInfo.state == PATCH_FILE_STATE.DOWNLOADING)
			fileInfo.state          = PATCH_FILE_STATE.TO_DOWNLOAD
			fileInfo.downloadedSize = 0
			fileInfo.speed          = 0
		end

		local function onProgress(curSpeed, loadSize)
			assert(fileInfo.state == PATCH_FILE_STATE.DOWNLOADING)
			fileInfo.speed 		= curSpeed
			fileInfo.downloadedSize = loadSize
			C_Log(string.format("onProgress speed:%d downloaded:%d", curSpeed, loadSize))
		end

		local function checkFile()
        	local fileMD5 = C_MD5File(localPath)
			C_Log(string.format("CheckMD5, rightMD5:%s realMD5:%s", fileInfo.md5, fileMD5))
			return fileInfo.md5 == fileMD5	
		end

		self:downloadFile(urls, file, localPath, true, onSuccess, onFailed, onProgress, checkFile)
		assert(fileInfo.state == PATCH_FILE_STATE.TO_DOWNLOAD)
		fileInfo.state = PATCH_FILE_STATE.DOWNLOADING
		return
	end

	self.state = STATE.UNZIPPING
end

KUILoginUpdateNode["active_" .. STATE.UNZIPPING] = function(self)
	if HArray.FindFirst(self.patchFiles, "state", PATCH_FILE_STATE.UNZIPPING) then
		return
	end

	local fileInfo = HArray.FindFirst(self.patchFiles, "state", PATCH_FILE_STATE.DOWNLOADED)
	if fileInfo then
		local function onUncompress(storagePath, result, errorInfo)
			assert(fileInfo.state == PATCH_FILE_STATE.UNZIPPING)
			C_Log(string.format("File:%s uncompressEnd:%s", fileInfo.file, tostring(result)))
			if result then
				fileInfo.state = PATCH_FILE_STATE.DONE
				return
			end

			fileInfo.state = PATCH_FILE_STATE.DOWNLOADED
		end

		local function onUncompressProgress(storagePath, fileCount, uncompressCount)
			assert(fileInfo.state == PATCH_FILE_STATE.UNZIPPING)
			fileInfo.uncompressCount = uncompressCount
		end

		local result = C_AsyncUncompress(fileInfo.localPath, self.srcPath, true, onUncompress, onUncompressProgress)
		assert(result)
		assert(fileInfo.state == PATCH_FILE_STATE.DOWNLOADED)
		fileInfo.state = PATCH_FILE_STATE.UNZIPPING
		return	
	end

	for _, v in pairs(self.patchFiles) do
		if v.state ~= PATCH_FILE_STATE.DONE then
			return
		end
	end
	
	self.state = STATE.END
	local function delayBeginGame()
		C_StopAllDownload()
		self:stopAllActions()
		self:beginGame()
	end
	delayExecute(self, delayBeginGame, 1)
end

function KUILoginUpdateNode:active()
	local fn = self["active_" .. self.state]
	if fn then
		fn(self)
	end
	self:refreshUI()
end

function KUILoginUpdateNode:getStateData()
	local totalDownloadedSize = 0
	local totalToDownloadSize = 0 
	local downloadSpeed = 0
	local totalFileCount = 0
	local uncompressCount = 0
	for _, v in ipairs(self.patchFiles) do
		totalDownloadedSize = totalDownloadedSize + v.downloadedSize
		totalToDownloadSize = totalToDownloadSize + v.size
		downloadSpeed = downloadSpeed + v.speed
		totalFileCount = totalFileCount + v.fileCount
		uncompressCount = uncompressCount + v.uncompressCount
	end

	local downloadPercent = 0
	if totalToDownloadSize > 0  then
		downloadPercent = math.floor(totalDownloadedSize / totalToDownloadSize * 100)
	end

	local remainingTime = -1
	if downloadSpeed > 0 then
		local leftSize = totalToDownloadSize - totalDownloadedSize
		remainingTime = math.ceil(leftSize / downloadSpeed)
		C_Log(string.format("LeftSize:%d, downloadSpeed:%d, remainingTime:%d", leftSize, downloadSpeed, remainingTime))
	end

	local statusInfo = STATE_DECRIPTION[self.state]
	if self.state == STATE.UNZIPPING then
		statusInfo = statusInfo .. uncompressCount .. "/" .. totalFileCount
	end

	return {
		totalSize = totalToDownloadSize,
		downloadedSize = totalDownloadedSize,
		downloadSpeed = downloadSpeed,
		downloadPercent = downloadPercent,
		remainingTime = remainingTime,
		statusInfo = statusInfo,
	}
end

function KUILoginUpdateNode:time2str(t, prefix)
	prefix = prefix or ""
	if t < 0 then
		return prefix
	end
	t = math.floor(t)

	local result = prefix
	local nHour =  math.floor(t / 3600)
	if nHour > 0 then
		result  = result .. nHour .. "小時"
	end

	t = t % 3600
	local nMinute = math.floor(t / 60)
	local nSecond = math.ceil(t % 60)
	if nMinute > 0 then
		result = result .. nMinute .. "分"
	end
	if nSecond > 0 then
		result = result .. nSecond .. "秒"
	end

	return result
end

function KUILoginUpdateNode:refreshDialog()
	local mainNode      = self._mainLayout
	local imageTips     = mainNode:getChildByName("Image_update_information")
	imageTips:setVisible(false)
    local imageSelect = mainNode:getChildByName("Image_audio_download")
    imageSelect:setVisible(false)
end

function KUILoginUpdateNode:refreshUI()
	self:showHitCount()
	self:showknowHow()
	self:refreshVerionInfo()
	self:refreshDialog()

	local stateData = self:getStateData()

	local mainNode       = self._mainLayout
	local imageBase      = mainNode:getChildByName("Image_loading_base")
	local loadingBar     = imageBase:getChildByName("LoadingBar_loading")
	loadingBar:setPercent(stateData.downloadPercent)
	local imageIconTank  = loadingBar:getChildByName("Image_icon_tank")
	local nBarWidth      = loadingBar:getContentSize().width
	local szPercent      = string.format("%.3f%%", stateData.downloadPercent)
	imageIconTank:setPosition(nBarWidth * stateData.downloadPercent / 100, imageIconTank:getPositionY())

	local textBMFont     = imageBase:getChildByName("BitmapFontLabel_2")
	textBMFont:setString(szPercent)

	local labelRemainingTime = imageBase:getChildByName("Text_remain_time")
	if stateData.remainingTime <= 0 then
		labelRemainingTime:setString("")
	else
		labelRemainingTime:setString(self:time2str(stateData.remainingTime, "剩余時間:"))
	end

	local textTotalSize  = imageBase:getChildByName("BitmapFontLabel_total_number")
	textTotalSize:setString(self:getSizeString(stateData.totalSize))

	local textLoadSize   = imageBase:getChildByName("BitmapFontLabel_file_percent")
	textLoadSize:setString(self:getSizeString(stateData.downloadedSize))

	local textLoadSpeed  = imageBase:getChildByName("BitmapFontLabel_download_speed")
	textLoadSpeed:setString(string.format("%s/S", self:getSizeString(stateData.downloadSpeed)))

	local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")
	textLog:setString(stateData.statusInfo)
end

function KUILoginUpdateNode:registerAllTouchEvent()
	local mainNode      = self._mainLayout
	local imageTips     = mainNode:getChildByName("Image_update_information")
	local buttonConfirm = imageTips:getChildByName("Button_update_confirm")
	local function onConfirmClick(sender, type)
		if type ~= ccui.TouchEventType.ended then return end
	end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel    = imageTips:getChildByName("Button_update_cancel")
    local function onCancelClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
	end
    buttonCancel:addTouchEventListener(onCancelClick)

    local imageSelect   = mainNode:getChildByName("Image_audio_download")
    local buttonTotal   = imageSelect:getChildByName("Button_all_download")
    local function onTotalClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
    end
    buttonTotal:addTouchEventListener(onTotalClick)

    local buttonPart    = imageSelect:getChildByName("Button_part_download")
    local function onPartClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
	end
    buttonPart:addTouchEventListener(onPartClick)
    
    local buttonUpperBody = mainNode:getChildByName("Button_upper_part")
    local function onUpperBodyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        self:hit("UPPER")
    end
    buttonUpperBody:addTouchEventListener(onUpperBodyClick)

    local buttonLowerBody = mainNode:getChildByName("Button_lower_part")
    local function onLowerBodyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        self:hit("LOWER")
    end
    buttonLowerBody:addTouchEventListener(onLowerBodyClick)
end

function KUILoginUpdateNode:registerAllCustomEvent()
end

function KUILoginUpdateNode:onEnter()
end

function KUILoginUpdateNode:onExit()
    C_StopAllDownload()
end

function KUILoginUpdateNode:init()
    assert(self._uiPath ~= nil, "uiResPath is not config~")
    self._mainLayout = cc.CSLoader:createNode(self._uiPath)
    self:autoHandler()
end

function KUILoginUpdateNode:autoHandler()
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        end
        if "exit" == event then
            self:onExit()
        end
		if "cleanup" == event then
			self:onExit()
		end
    end
    self:registerScriptHandler(onNodeEvent)

    assert(self._mainLayout)
    self:addChild(self._mainLayout, 1)

    self:refreshUI()

 	local actionSequene = cc.Sequence:create(
        cc.DelayTime:create(0.1), 
        cc.CallFunc:create(function() self:active() end)
    )
    self:runAction(cc.RepeatForever:create(actionSequene))
   
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end


function addUpdateScene()
    local updateScene = cc.Scene:create()
    assert(updateScene)
    local node = KUILoginUpdateNode.create(updateScene)

    updateScene:addChild(node)
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(updateScene)
    else
        cc.Director:getInstance():runWithScene(updateScene)
    end
end
