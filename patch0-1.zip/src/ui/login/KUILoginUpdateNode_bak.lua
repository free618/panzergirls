--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILoginUpdateNode.lua
--  Creator     : liulingli
--  Date        : 2015/11/19   11:29
--  Contact     : liulingli@kingsoft.com
--  Comment     : 
--  *********************************************************************

require("src/version")
local MAX_THREAD_COUNT = 5

local NEWEST_VERSION   = 1
local NEXT_VERSION     = 2
local UPDATE_INFO      = 3
local ZIP              = 4

local PRIORITY_REMOVE     = 1
local PRIORITY_UNCOMPRESS = 2
local PRIORITY_LOAD       = 3
--local m_szNewstVersionUrl = "http://42.62.15.200:11000/net/"  -- For Net
--local m_szNewstVersionUrl = "http://172.18.69.110:21000/lan/"    -- For Lan
--local m_szNewstVersionUrl = "http://172.18.69.110:21000/xiaomi/"  -- For XiaoMi
local m_tUrlList = 
{
    "http://103.238.227.24:21000/tankgirl/hk/",
    --"http://xsjdl.kssws.ks-cdn.com/tankgirl/net/", -- For Net
    --"http://update.panzergirls.kingsoft.com/net/",--CDN By chinanet
    --"http://120.92.9.223:21000/tankgirl/net/", -- CDN Bak_Server
}  
--local m_szNewstVersionUrl = "http://xsjdl.kssws.ks-cdn.com/tankgirl/xiaomi/"  -- For XiaoMi
--local m_szNewstVersionUrl = "http://xsjdl.kssws.ks-cdn.com/tankgirl/channeltest/"  -- For ChannelTest
--local m_szNewstVersionUrl = "http://xsjdl.kssws.ks-cdn.com/tankgirl/kingsoft/"  -- For Kingsoft
if cc.FileUtils:getInstance():isFileExist("src/network/KNewestVersionUrl.lua") or cc.FileUtils:getInstance():isFileExist("src/network/KNewestVersionUrl.luac") then
    m_tUrlList = require("src/network/KNewestVersionUrl")
end

local m_tErrorList = {}
local function sendError(szText)
    if sendInfoGatherServer then sendInfoGatherServer(szText) end
end

local function addError(szName, value)
    if m_tErrorList[szName] then return end
    if not value then value = true end
    m_tErrorList[szName] = value
    if type(value) == "string" then
        sendError(szName .. value)
    else
        sendError(szName)
    end
end

local function setSettingString(key, value)
    cc.UserDefault:getInstance():setStringForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

local function getSettingString(key, default)
    return cc.UserDefault:getInstance():getStringForKey(key, default)
end

local function setSettingBool(key, value)
    cc.UserDefault:getInstance():setBoolForKey(key, value)
    cc.UserDefault:getInstance():flush()
end

local function getSettingBool(key, default)
    local _default = default or false
    return cc.UserDefault:getInstance():getBoolForKey(key, _default)
end

local function myPrint( ... )
    local str = "" .. C_GetTickCount() .. "  "
    local tValues = {...}
    local nCount = select("#", ...)
    for i = 1, nCount do
        str = str .. "  " .. tostring(tValues[i])
    end
    cclog(str)
end

VERSION = getSettingString("srcversion", VERSION)
assert(VERSION) 

KThreadManager = {}
KThreadManager.tDisposeList = {}
KThreadManager.nFreeThreadCount = MAX_THREAD_COUNT
KThreadManager.applyCount = 0
KThreadManager.releaseCount = 0

function KThreadManager.applyThread(priority, subPriority, fun, ...)
    KThreadManager.applyCount = KThreadManager.applyCount + 1
    myPrint("applyThread------------", KThreadManager.applyCount, priority, subPriority, fun)
    if KThreadManager.nFreeThreadCount > 0 then
        local bSuccess = fun(...)
        assert(bSuccess)
        KThreadManager.nFreeThreadCount = KThreadManager.nFreeThreadCount - 1
    else
        if KThreadManager.tDisposeList[priority] == nil then
            KThreadManager.tDisposeList[priority] = {}
        end
        if KThreadManager.tDisposeList[priority][subPriority] == nil then
            KThreadManager.tDisposeList[priority][subPriority] = {}
        end
        local t = {fun = fun, args = {...}}
        table.insert(KThreadManager.tDisposeList[priority][subPriority], t)
    end
end

function KThreadManager.releaseThread()
    KThreadManager.releaseCount = KThreadManager.releaseCount + 1
    KThreadManager.nFreeThreadCount = KThreadManager.nFreeThreadCount + 1
    myPrint("releaseThread1--------------", KThreadManager.releaseCount, KThreadManager.nFreeThreadCount)
    assert(KThreadManager.nFreeThreadCount <= MAX_THREAD_COUNT)
    local nMinPriority
    local nCount = 0
    for nPriority, _ in pairs(KThreadManager.tDisposeList) do
        nCount = nCount + 1
        if nMinPriority == nil or nPriority < nMinPriority then 
            nMinPriority = nPriority
        end
    end
    myPrint("releaseThread2--------------", KThreadManager.nFreeThreadCount, nCount)

    if not nMinPriority then return end
    local nSubCount = 0
    local nMinSubPriority
    for nSubPriority, v in pairs(KThreadManager.tDisposeList[nMinPriority]) do
        nSubCount = nSubCount + 1
        if nMinSubPriority == nil or nSubPriority < nMinSubPriority then 
            nMinSubPriority = nSubPriority
        end
    end
    myPrint("releaseThread3--------------", KThreadManager.nFreeThreadCount, nSubCount)

    if not nMinSubPriority then return end
    local tDispose = table.remove(KThreadManager.tDisposeList[nMinPriority][nMinSubPriority], 1)
    assert(tDispose)
    if #KThreadManager.tDisposeList[nMinPriority][nMinSubPriority] == 0 then
        KThreadManager.tDisposeList[nMinPriority][nMinSubPriority] = nil
        if nSubCount == 1 then
            KThreadManager.tDisposeList[nMinPriority] = nil
        end
    end

    local bSuccess, szError = tDispose.fun(unpack(tDispose.args, 1, table.maxn(tDispose.args)))
    myPrint("releaseThread4--------------", nMinPriority, nMinSubPriority, bSuccess, szError)
    assert(bSuccess, "" .. nMinPriority .. nMinSubPriority)
    KThreadManager.nFreeThreadCount = KThreadManager.nFreeThreadCount - 1
end

function KThreadManager.release()
    myPrint("KThreadManager.release--------------------")
    KThreadManager.tDisposeList = {}
    KThreadManager.nFreeThreadCount = MAX_THREAD_COUNT
end

function GetUrlList(szDirectory)
    if not szDirectory then return m_tUrlList end
    
    local tUrlList = {}
    for _, szUrl in ipairs(m_tUrlList) do
        table.insert(tUrlList, szUrl .. szDirectory .. "/")
    end
    return tUrlList
end

function CreateUpdateManager(szUpdateName, nPriority, tUrlList, szDefaultVersion, bDefaultMini, bBeginLoad, nMaxLoadCount)
    myPrint("CreateUpdateManager", szUpdateName, nPriority, tUrlList, szDefaultVersion, bDefaultMini, bBeginLoad, nMaxLoadCount)
    local KUpdate = {}

    function KUpdate.applyThread(nPriority, fun, ...)
        KThreadManager.applyThread(KUpdate.nPriority, nPriority, fun, ...)
    end

    function KUpdate.releaseThread()
        KThreadManager.releaseThread()
    end

    function KUpdate.setSettingString(key, value)
        cc.UserDefault:getInstance():setStringForKey(KUpdate.szName .. key, value)
        cc.UserDefault:getInstance():flush()
    end

    function KUpdate.getSettingString(key, default)
        return cc.UserDefault:getInstance():getStringForKey(KUpdate.szName .. key, default)
    end

    function KUpdate.getFileDirectory(nFileType, szVersion)
        local szFileDirectory = ""
        if nFileType == UPDATE_INFO or nFileType == ZIP then
            if KUpdate.bMini then
                szFileDirectory = "full/" .. szVersion .. "/"
            else
                szFileDirectory = "update/" .. szVersion .. "/"
            end
        end
        return szFileDirectory
    end

    function KUpdate.getPathByUrl(strRemoteUrl)
        local tList = {KUpdate.szStoragePath}
        for i, szUrl in ipairs(tUrlList) do
            tList[i + 1] = szUrl
        end
        local szPath
        for _, szUrl in pairs(tList) do 
            local len   = string.len(szUrl)
            local szSub = string.sub(strRemoteUrl, 1, len)

            if szSub   == szUrl then
                szPath  = string.sub(strRemoteUrl, len + 1, -1)
                break
            end
        end
        return szPath
    end

    function KUpdate.setFileInfo(szFileName, nFileType, szVersion)
        local szFileDirectory = KUpdate.getFileDirectory(nFileType, szVersion)
        local szFilePath      = szFileDirectory .. szFileName
        if not KUpdate.tFileInfoList[szFilePath] then
            KUpdate.tFileInfoList[szFilePath] = 
            {
                path            = szFilePath, 
                directory       = szFileDirectory,
                name            = szFileName, 
                fileType        = nFileType, 
                version         = szVersion,
                loadSize        = 0,
                loadCount       = 0,
                uncompressCount = 0,
                bLoadFinish     = false,
                bUncompress     = false,
                nUrlIndex       = 1,
                nCurrentUrlErrorCount = 0,
            }
        end 
        myPrint("setFileInfo", szFilePath)
        return KUpdate.tFileInfoList[szFilePath]
    end

    function KUpdate.changeUrl(tFileInfo)
        local nOldUrlIndex = tFileInfo.nUrlIndex
        tFileInfo.nUrlIndex = tFileInfo.nUrlIndex + 1
        if tFileInfo.nUrlIndex > #tUrlList then
            tFileInfo.nUrlIndex = 1
        end

        if nOldUrlIndex ~= tFileInfo.nUrlIndex then
            tFileInfo.nCurrentUrlErrorCount = 0
            tFileInfo.bReload = true
        end
    end

    function KUpdate.getFileInfoByUrl(szUrl)
        local szFilePath = KUpdate.getPathByUrl(szUrl)
        local tFileInfo  = KUpdate.tFileInfoList[szFilePath]
        assert(tFileInfo, szFilePath)
        return tFileInfo
    end

    function KUpdate.getUrl(tFileInfo)
        assert(tFileInfo.nUrlIndex ~= 0 and tFileInfo.nUrlIndex <= #tUrlList, "" .. tFileInfo.nUrlIndex .. "/" .. #tUrlList)
        return tUrlList[tFileInfo.nUrlIndex] .. tFileInfo.path
    end

    function KUpdate.downLoadFileByInfo(tFileInfo, bReload)
        if KUpdate.nMaxLoadCount and tFileInfo.loadCount >= KUpdate.nMaxLoadCount then
            KUpdate.szLoadState   = "fail"
            KUpdate.bUpdateFinish = true
            return false
        end
        
        if tFileInfo.bReload then
            bReload = true
            tFileInfo.bReload = nil
        end
        
        if bReload then
            KUpdate.nFileSize  = KUpdate.nFileSize - tFileInfo.loadSize
            tFileInfo.loadSize = 0
        end
        tFileInfo.loadCount = tFileInfo.loadCount + 1

        local szRemoteUrl = KUpdate.getUrl(tFileInfo)
        local szLocalPath = KUpdate.szStoragePath .. tFileInfo.path
        local bEnableResume = not bReload
        KUpdate.applyThread(PRIORITY_LOAD, C_AsyncDownloadFile, szRemoteUrl, szLocalPath, 10, bEnableResume, KUpdate.onLoad, KUpdate.onLoadProgress)
        myPrint("C_DownloadFile---------------", szRemoteUrl, szLocalPath, bEnableResume, nResult)
        return true
    end

    function KUpdate.downLoadFile(szFileName, nFileType, szVersion, bReload)
        local tFileInfo = KUpdate.setFileInfo(szFileName, nFileType, szVersion)
        KUpdate.downLoadFileByInfo(tFileInfo, bReload)
    end

    function KUpdate.uncompressZipByFileInfo(tFileInfo)
        myPrint("uncompressZipByFileInfo----------------", KUpdate.szStoragePath .. tFileInfo.path)
        KUpdate.applyThread(PRIORITY_UNCOMPRESS, C_AsyncUncompress, KUpdate.szStoragePath .. tFileInfo.path, KUpdate.szSrcPath, true, KUpdate.onUncompress, KUpdate.onUncompressProgress)
    end

    function KUpdate.getStringFromFile(szFilePath)
        local szData = cc.FileUtils:getInstance():getStringFromFile(KUpdate.szStoragePath .. szFilePath)
        return szData
    end

    function KUpdate.setUncompressCount(tFileInfo, nUncompressCount)
        assert(KUpdate.nUncompressFileCount >= tFileInfo.uncompressCount)
        KUpdate.nUncompressFileCount = KUpdate.nUncompressFileCount - tFileInfo.uncompressCount + nUncompressCount
        tFileInfo.uncompressCount = nUncompressCount
    end

    function KUpdate.updateLoadSize(tFileInfo, fileSize)
        if tFileInfo.fileType ~= ZIP  or fileSize == tFileInfo.loadSize then return end
        myPrint("KUpdate.updateLoadSize", fileSize, tFileInfo.loadSize)
        assert(fileSize >= tFileInfo.loadSize)
        assert(KUpdate.nLoadSize >= tFileInfo.loadSize)
        KUpdate.nLoadSize  = KUpdate.nLoadSize - tFileInfo.loadSize + fileSize
        assert(KUpdate.nFileSize >= tFileInfo.loadSize)
        KUpdate.nFileSize  = KUpdate.nFileSize - tFileInfo.loadSize + fileSize
        tFileInfo.loadSize = fileSize
    end

    function KUpdate.getFileLen(szFilePath)
        local fileHand = io.open(szFilePath, "rb")
        if not fileHand then
            szFilePath = szFilePath .. ".temp"
            fileHand = io.open(szFilePath, "rb")
        end
        if not fileHand then return 0 end
        local nLen = fileHand:seek("end")
        myPrint("getFileLen-------------", nLen)
        assert(nLen, szFilePath)
        fileHand:close()
        return nLen
    end

    function KUpdate.run()
        KUpdate.loadNewstVersion()
    end

    function KUpdate.initDate(szUpdateName, nPriority, szNewstVersionUrl, szDefaultVersion, bDefaultMini, bBeginLoad, nMaxLoadCount)
        KUpdate.szName                 = szUpdateName
        KUpdate.nPriority              = nPriority
        KUpdate.bBeginLoad             = bBeginLoad
        KUpdate.nMaxLoadCount          = nMaxLoadCount
        KUpdate.szNewstVersionUrl      = szNewstVersionUrl  
        KUpdate.szWritablePath         = cc.FileUtils:getInstance():getWritablePath()
        KUpdate.szStoragePath          = KUpdate.szWritablePath .. "load/" .. szUpdateName .. "/"
        KUpdate.szSrcPath              = KUpdate.szWritablePath .. "s1_update/"
        KUpdate.szNowVersion           = KUpdate.getSettingString("version")
        KUpdate.bMini                  = false
        if KUpdate.szNowVersion == "" then
            KUpdate.szNowVersion       = szDefaultVersion or ""
            KUpdate.bMini              = bDefaultMini
        end
        myPrint("initDate--------", szUpdateName, KUpdate.szNowVersion, KUpdate.bMini)
        KUpdate.szOldVersion           = KUpdate.szNowVersion
        KUpdate.szNewestVersion        = nil
        KUpdate.tVersionList           = {}
        KUpdate.tVersionInfoList       = {}
        KUpdate.tFileInfoList          = {}
        KUpdate.nVersionIndex          = 0
        KUpdate.nUpdateInfoCount       = 0
        KUpdate.nTotalSize             = 0
        KUpdate.nFileSize              = 0
        KUpdate.nLoadSize              = 0
        KUpdate.nTotalFileCount        = 0
        KUpdate.nLoadFileCount         = 0
        KUpdate.nBeCompressedFileCount = nil
        KUpdate.nUncompressFileCount   = 0
        KUpdate.nRemoveFileTotalCount  = nil
        KUpdate.nRemoveFileCount       = 0
        KUpdate.nZipCount              = 0
        KUpdate.nLoadZipCount          = nil
        KUpdate.szLoadState            = "coming"
        KUpdate.szUncompressState      = nil
        KUpdate.szRemoveFileState      = nil
        KUpdate.bUpdateFinish          = false
        KUpdate.szLoadFinishVersion    = KUpdate.getSettingString("loadFinishVersion")
        myPrint("initDate---------------", KUpdate.szLoadFinishVersion)
    end

    function KUpdate.loadNewstVersion()
        KUpdate.szLoadState       = "check"
        KUpdate.downLoadFile("newestversion.lua", NEWEST_VERSION, nil, true)
    end

    function KUpdate.disposeNewstVersion(tFileInfo)
        local szFilePath = "newestversion.lua"
        local szData     = KUpdate.getStringFromFile(szFilePath)
        local szInfo     = string.match(szData, "(.+)\n[^\n]+[\n]*$")
        local szNewestVersion = loadstring(szData)()
        local nNewestVersion  = tonumber(szNewestVersion)
        local nServerNewestVersion = tonumber(KUpdate.getSettingString("ServerVersion", KUpdate.szNowVersion))
        C_Log("RemoteVersion:" .. tostring(szNewestVersion))
        C_Log("LocalVersion:" .. tostring(KUpdate.szNowVersion))
        myPrint("disposeNewstVersion---------------", nNewestVersion, nServerNewestVersion, szNewestVersion, KUpdate.szNowVersion)
        if not nNewestVersion or nNewestVersion < 0 or (nServerNewestVersion and nNewestVersion < nServerNewestVersion) then
            addError(KUpdate.getUrl(tFileInfo) .. "newestversion error:", tostring(szNewestVersion) .. " " .. type(szNewestVersion))
            KUpdate.changeUrl(tFileInfo)
            KUpdate.downLoadFileByInfo(tFileInfo, true)
            return
        end
        if szNewestVersion == KUpdate.szNowVersion then 
            KUpdate.szNewestVersion     = szNewestVersion
            return KUpdate.updateFinish() 
        end
        KUpdate.initNewstVersion(szNewestVersion)
        if KUpdate.bMini then
            KUpdate.addNewVersion(KUpdate.szNewestVersion)
        else
            KUpdate.loadNextVersion()
        end
    end

    function KUpdate.initNewstVersion(szNewestVersion)
        KUpdate.szNewestVersion        = szNewestVersion
        KUpdate.szLoadState            = "find"
        KUpdate.tVersionList           = {}
        KUpdate.tVersionInfoList       = {}
        KUpdate.tFileInfoList          = {}
        KUpdate.nVersionIndex          = 1
        KUpdate.nUpdateInfoCount       = 0
        KUpdate.nTotalSize             = 0
        KUpdate.nFileSize              = 0
        KUpdate.nLoadSize              = 0
        KUpdate.nTotalFileCount        = 0
        KUpdate.nLoadFileCount         = 0
        KUpdate.nUncompressFileCount   = 0
        KUpdate.nBeCompressedFileCount = 0
        KUpdate.nRemoveFileTotalCount  = 0
        KUpdate.nRemoveFileCount       = 0
        KUpdate.nZipCount              = 0
        KUpdate.nLoadZipCount          = 0
        KUpdate.szUncompressState      = ""
        KUpdate.szRemoveFileState      = ""
    end

    function KUpdate.loadNextVersion(tFileInfo)
        local szNextVersion = KUpdate.szNowVersion
        if tFileInfo then
            szNextVersion = KUpdate.getStringFromFile(tFileInfo.path)
            KUpdate.addNewVersion(szNextVersion)
        end
        if szNextVersion ~= KUpdate.szNewestVersion then
            KUpdate.downLoadFile(szNextVersion .. ".next", NEXT_VERSION)
        end 
    end

    function KUpdate.addNewVersion(szVersion)
        local tVersionInfo = KUpdate.addVersionInfo(szVersion)
        KUpdate.downLoadFile("updateinfo.lua", UPDATE_INFO, szVersion)
        return tVersionInfo
    end

    function KUpdate.addVersionInfo(szVersion)
        table.insert(KUpdate.tVersionList, szVersion)
        local szPath = "update/"..szVersion .. "/"
        if KUpdate.bMini then
            szPath = "full/"..szVersion .. "/"
        end
        KUpdate.tVersionInfoList[szVersion] = {path = szPath, loadZipCount = 0}
        return KUpdate.tVersionInfoList[szVersion]
    end

    function KUpdate.disposeUpdateInfo(tFileInfo)
        myPrint("disposeUpdateInfo-------------------", tFileInfo.version)
        local szFilePath   = tFileInfo.path
        local szVersion    = tFileInfo.version
        local szData       = KUpdate.getStringFromFile(szFilePath)
        local szInfo       = string.match(szData, "(.+)\n[^\n]+[\n]*$")
        local szNowMD5     = C_MD5(szInfo)
        local tInfo, szMD5 = loadstring(szData)()
        if string.lower(szNowMD5) ~= string.lower(szMD5) then
            myPrint("disposeUpdateInfo---------------", szNowMD5, tInfo.md5)
            addError(KUpdate.getUrl(tFileInfo) .. "MD5 error")
            KUpdate.changeUrl(tFileInfo)
            KUpdate.downLoadFileByInfo(tFileInfo, true)
            return
        end
        KUpdate.initVersionInfo(szVersion, tInfo)
        if KUpdate.nUpdateInfoCount == #KUpdate.tVersionList 
            and KUpdate.tVersionInfoList[KUpdate.szNewestVersion] then
            KUpdate.initAllZipInfo()
            if KUpdate.szLoadState == "find" then
                KUpdate.szLoadState = "findEnd"
            end
            KUpdate.tryDisposeZip()
            if KUpdate.bBeginLoad then
                KUpdate.loadZip()
            end
        end
    end

    function KUpdate.initVersionInfo(szVersion, tInfo)
        KUpdate.nUpdateInfoCount = KUpdate.nUpdateInfoCount + 1
        KUpdate.tVersionInfoList[szVersion]["info"] = tInfo
        KUpdate.nTotalSize       = KUpdate.nTotalSize + tInfo.totalsize
        KUpdate.nTotalFileCount  = KUpdate.nTotalFileCount + tInfo.totalfilecount
        myPrint("initVersionInfo-----------------", KUpdate.nTotalSize)
    end

    function KUpdate.initAllZipInfo()
        for i = 1, #KUpdate.tVersionList do
            local szVersion      = KUpdate.tVersionList[i]
            local tVersionInfo   = KUpdate.tVersionInfoList[szVersion]
            if szVersion  == KUpdate.szLoadFinishVersion then
                KUpdate.nFileSize = KUpdate.nFileSize + tVersionInfo.info.totalsize
            end
            for szZipName, tZipInfo in pairs(tVersionInfo.info.ziplist) do
                KUpdate.nZipCount = KUpdate.nZipCount + 1
                local tFileInfo   = KUpdate.setFileInfo(szZipName, ZIP, szVersion)
                assert(tFileInfo)
                local nFileLen = tZipInfo.filesize or 0
                if szVersion  ~= KUpdate.szLoadFinishVersion then
                    nFileLen   = KUpdate.getFileLen(KUpdate.szStoragePath .. tVersionInfo.path .. szZipName)
                    if nFileLen > 0 then
                        KUpdate.updateLoadSize(tFileInfo, nFileLen)
                    end
                else
                    assert(i == 1)
                    tFileInfo.bLoadFinish     = true
                    KUpdate.nLoadZipCount     = KUpdate.nLoadZipCount + 1
                    tVersionInfo.loadZipCount = tVersionInfo.loadZipCount + 1
                end
            end
        end

        myPrint("initAllZipInfo-----------", KUpdate.nZipCount, KUpdate.nLoadZipCount)
        if KUpdate.nLoadZipCount == KUpdate.nZipCount then
            KUpdate.szLoadState = "completely"
        end
    end

    function KUpdate.loadZip()
        if KUpdate.szLoadState == "completely" or KUpdate.szLoadState == "newest" then return end
        myPrint("loadZip---------------", KUpdate.szName)
        KUpdate.bBeginLoad      = true
        KUpdate.szLoadState     = "downloading"
        for i = 1, #KUpdate.tVersionList do
            local szVersion      = KUpdate.tVersionList[i]
            local tVersionInfo   = KUpdate.tVersionInfoList[szVersion]
            for szZipName, tZipInfo in pairs(tVersionInfo.info.ziplist) do
                local szFileName = tVersionInfo.path .. szZipName
                local tFileInfo  = KUpdate.tFileInfoList[szFileName]
                assert(tFileInfo)
                if not tFileInfo.bLoadFinish then
                    KUpdate.downLoadFileByInfo(tFileInfo)
                end
            end
        end
    end

    function KUpdate.checkZip(tFileInfo)
        local szFilePath     = tFileInfo.path
        myPrint("checkZip--------------------", szFilePath)
        local szNowMD5       = C_MD5File(KUpdate.szStoragePath .. szFilePath)
        assert(szNowMD5)
        local tVersionInfo   = KUpdate.tVersionInfoList[tFileInfo.version]
        local tInfo          = tVersionInfo["info"]["ziplist"][tFileInfo.name]
        if string.lower(szNowMD5) ~= string.lower(tInfo.md5) then
            myPrint("checkZip-------------", szNowMD5, tInfo.md5, KUpdate.szStoragePath .. szFilePath)
            addError(KUpdate.getUrl(tFileInfo) .. "MD5 error")
            KUpdate.changeUrl(tFileInfo)
            KUpdate.downLoadFileByInfo(tFileInfo, true)
        else
            tFileInfo.bLoadFinish     = true
            tVersionInfo.loadZipCount = tVersionInfo.loadZipCount + 1
            KUpdate.nLoadFileCount    = KUpdate.nLoadFileCount + tInfo["filecount"]
            KUpdate.nLoadZipCount     = KUpdate.nLoadZipCount + 1
            if KUpdate.nLoadZipCount == KUpdate.nZipCount then 
                KUpdate.szLoadState   = "completely"
            end
            if tFileInfo.version     == KUpdate.tVersionList[KUpdate.nVersionIndex] then
                KUpdate.tryDisposeZip()
            end
        end
    end

    function KUpdate.tryDisposeZip()
        local szVersion     = KUpdate.tVersionList[KUpdate.nVersionIndex]
        local tVersionInfo  = KUpdate.tVersionInfoList[szVersion]
        myPrint("tryDisposeZip--------------------", tVersionInfo.loadZipCount, tVersionInfo.info.zipcount)
        if tVersionInfo.loadZipCount < tVersionInfo.info.zipcount then return end
        myPrint("DisposeZip--------------------", szVersion)
        KUpdate.setSettingString("loadFinishVersion", szVersion)
        KUpdate.deleteFile()
        KUpdate.uncompressZip()
        KUpdate.tryUpdateVersion()
    end

    function KUpdate.deleteFile()
        KUpdate.szRemoveFileState     = "begin"
        local tDeleteList             = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]["info"]["deletelist"]
        KUpdate.nRemoveFileTotalCount = #tDeleteList
        KUpdate.nRemoveFileCount      = 0
        if KUpdate.nRemoveFileTotalCount == 0 then
            local tVersionInfo        = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]
            tVersionInfo.bRemoveFile  = true
            KUpdate.szRemoveFileState = "end"
            return true
        end
        KUpdate.applyThread(PRIORITY_REMOVE, C_AsyncRemoveFiles, tDeleteList, KUpdate.onRemoveFile, KUpdate.onRemoveFileProgress)
        myPrint("deleteFile-----------", KUpdate.nVersionIndex)
        return true
    end

    function KUpdate.uncompressZip()
        KUpdate.szUncompressState        = "begin"
        KUpdate.nBeCompressedFileCount   = 0
        KUpdate.nUncompressFileCount     = 0
        local tVersionInfo               = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]
        tVersionInfo.zipCount            = 0
        tVersionInfo.uncompressZipCount  = 0
        for szZipName, tInfo in pairs(tVersionInfo.info.ziplist) do
            local szFileName = tVersionInfo.path .. szZipName
            local tFileInfo  = KUpdate.tFileInfoList[szFileName]
            assert(tFileInfo)
            if cc.FileUtils:getInstance():isFileExist(KUpdate.szStoragePath .. szFileName) then
                KUpdate.nBeCompressedFileCount = KUpdate.nBeCompressedFileCount + tInfo.filecount
                tVersionInfo.zipCount = tVersionInfo.zipCount + 1
                KUpdate.uncompressZipByFileInfo(tFileInfo)
            end
        end

        if tVersionInfo.zipCount == 0 then
            KUpdate.szUncompressState = "end"
        end
    end

    function KUpdate.tryUpdateVersion()
        myPrint("tryUpdateVersion-----------------", KUpdate.nVersionIndex, #KUpdate.tVersionList)
        local tVersionInfo    = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]
        myPrint("tryUpdateVersion-----------------", tVersionInfo.uncompressZipCount, tVersionInfo.zipCount, tVersionInfo.bRemoveFile)
        if tVersionInfo.uncompressZipCount < tVersionInfo.zipCount then return end
        KUpdate.szUncompressState = "end"
        if not tVersionInfo.bRemoveFile then  return end
        KUpdate.szNowVersion  = KUpdate.tVersionList[KUpdate.nVersionIndex]
        KUpdate.bMini         = false
        KUpdate.nVersionIndex = KUpdate.nVersionIndex + 1
        KUpdate.setSettingString("version", KUpdate.szNowVersion)
        myPrint("tryUpdateVersion success", KUpdate.nVersionIndex, #KUpdate.tVersionList)
        if KUpdate.nVersionIndex > #KUpdate.tVersionList then
            KUpdate.loadNewstVersion()
        else
            KUpdate.tryDisposeZip()
        end
        return
    end

    function KUpdate.updateFinish()
        local result = KUpdate.applyThread(PRIORITY_REMOVE, C_AsyncRemoveDir, KUpdate.szStoragePath, KUpdate.onRemoveDir)
        myPrint("updateFinish-----------", KUpdate.szStoragePath, result)
        KUpdate.szLoadState   = "newest"
        KUpdate.bUpdateFinish = true
    end

    function KUpdate.resetLoadCount()
        if KUpdate.szLoadState == "newest" then return end
        myPrint("resetLoadCount----------------------")
        
        KUpdate.bUpdateFinish   = false
        local nReloadCount = 0
        local nUncompressCount = 0
        for _, tFileInfo in pairs(KUpdate.tFileInfoList) do
            local nLoadCount = tFileInfo.loadCount
            tFileInfo.loadCount = 0
            if not tFileInfo.bLoadFinish then 
                if nLoadCount >= KUpdate.nMaxLoadCount then
                    KUpdate.downLoadFileByInfo(tFileInfo)
                    nReloadCount = nReloadCount + 1
                end
            elseif tFileInfo.bUncompressFail then
                tFileInfo.bUncompressFail = false
                KUpdate.uncompressZipByFileInfo(tFileInfo)
                nUncompressCount = nUncompressCount + 1
            end
        end

        if nReloadCount > 0 then
            KUpdate.szLoadState     = "downloading"
        end
        if nUncompressCount > 0 then
            KUpdate.szUncompressState = "begin"
        end
    end

    function KUpdate.getUpdateInfo()
        local tInfo = 
        {
            totalSize            = KUpdate.nTotalSize,
            fileSize             = KUpdate.nFileSize,
            loadSize             = KUpdate.nLoadSize,
            totalFileCount       = KUpdate.nTotalFileCount,
            loadFileCount        = KUpdate.nLoadFileCount,
            beCompressedCount    = KUpdate.nBeCompressedFileCount,
            uncompressCount      = KUpdate.nUncompressFileCount,
            removeFileTotalCount = KUpdate.nRemoveFileTotalCount,
            removeFileCount      = KUpdate.nRemoveFileCount,
            isFinish             = KUpdate.bUpdateFinish,
            loadState            = KUpdate.szLoadState,
            uncompressState      = KUpdate.szUncompressState,
            removeFileState      = KUpdate.szRemoveFileState,
            newestVersion        = KUpdate.szNewestVersion,
        }
        return tInfo
    end

    function KUpdate.onLoadProgress(strRemoteUrl, fileSize, loadSize)
        myPrint("onLoadProgress---------------", strRemoteUrl, fileSize, loadSize)
        local tFileInfo = KUpdate.getFileInfoByUrl(strRemoteUrl)
        KUpdate.updateLoadSize(tFileInfo, fileSize)
    end

    function KUpdate.onLoad(strRemoteUrl, result, fileSize, loadSize, szError)
        KUpdate.releaseThread()
        
        local tFileInfo = KUpdate.getFileInfoByUrl(strRemoteUrl)
        myPrint("onLoad---------------", strRemoteUrl, result, fileSize, loadSize, szError)
        if not result then
            addError(KUpdate.getUrl(tFileInfo) .. szError)
            tFileInfo.nCurrentUrlErrorCount = tFileInfo.nCurrentUrlErrorCount + 1
            local szShortError = string.match(szError, ":([%w%s]-)$")
            if szShortError == "Timeout was reached" then
                if tFileInfo.nCurrentUrlErrorCount >= 3 then
                    KUpdate.changeUrl(tFileInfo)
                end
            elseif szShortError ~= "Out of memory" then
                KUpdate.changeUrl(tFileInfo)
            end

            return KUpdate.downLoadFileByInfo(tFileInfo)
        end
        KUpdate.updateLoadSize(tFileInfo, fileSize)
        local nFileType  = tFileInfo.fileType
        if nFileType == NEWEST_VERSION then
            return KUpdate.disposeNewstVersion(tFileInfo)
        end

        if nFileType == NEXT_VERSION then
            return KUpdate.loadNextVersion(tFileInfo)
        end

        if nFileType == UPDATE_INFO then
            return KUpdate.disposeUpdateInfo(tFileInfo)
        end

        if nFileType == ZIP then
            return KUpdate.checkZip(tFileInfo)
        end
    end

    function KUpdate.onUncompressProgress(storagePath, nFileCount, nUncompressCount)
        myPrint("onUncompressProgress---------------", storagePath, nUncompressCount, nFileCount)
        local tFileInfo = KUpdate.getFileInfoByUrl(storagePath)
        KUpdate.setUncompressCount(tFileInfo, nUncompressCount)
    end

    function KUpdate.onUncompress(storagePath, result, szError)
        KUpdate.releaseThread()
        local nTime = C_GetTickCount()
        myPrint("onUncompress---------------", KUpdate.nVersionIndex, storagePath, result, szError)
        local tFileInfo      = KUpdate.getFileInfoByUrl(storagePath)
        if not result then
            KUpdate.szUncompressState = "fail"
            KUpdate.bUpdateFinish     = true
            tFileInfo.bUncompressFail = true
            addError(szError)
            return
        end

        local tVersionInfo                  = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]
        tVersionInfo.uncompressZipCount     = tVersionInfo.uncompressZipCount + 1
        tFileInfo.bUncompress  = true
        local nUncompressCount = tVersionInfo["info"]["ziplist"][tFileInfo.name]["filecount"]
        KUpdate.setUncompressCount(tFileInfo, nUncompressCount)
        KUpdate.tryUpdateVersion()
        C_RemoveFile(storagePath)
        -- myPrint("onUncompress--------------- 5555555555555", C_GetTickCount() - nTime)
    end

    function KUpdate.onRemoveFileProgress(nSuccessCount)
        myPrint("onRemoveFileProgress-------------", nSuccessCount)
        KUpdate.nRemoveFileTotalCount = nSuccessCount
    end

    function KUpdate.onRemoveFile(nSuccessCount, nFailCount)
        KUpdate.releaseThread()
        myPrint("onRemoveFile-------------", nSuccessCount, nFailCount)
        KUpdate.nRemoveFileTotalCount = nSuccessCount
        local tVersionInfo            = KUpdate.tVersionInfoList[KUpdate.tVersionList[KUpdate.nVersionIndex]]
        tVersionInfo.bRemoveFile      = true
        KUpdate.szRemoveFileState     = "end"
        KUpdate.tryUpdateVersion()
    end

    function KUpdate.onRemoveDir(szPath, nResult)
        KUpdate.releaseThread()
    end

    KUpdate.initDate(szUpdateName, nPriority, szNewstVersionUrl, szDefaultVersion, bDefaultMini, bBeginLoad, nMaxLoadCount)
    return KUpdate
end 

--************************************************************************************
local MAX_HIT_COUNT     = 999
local CUT_OFF_COUNT     = 3
local RESTORE_TIME      = 3000
local MIN_NORMAL_SPEED  = 1024 * 5
local STAGNANCY_TIME    = 60000
local FONT_PATH     = "res/ui/ui_material/update/updated_words_chinese.fnt"
local m_Logs    = {
    coming      = "Please waiting~",
    check       = "Check the version~",
    find        = "Found new version, please waiting~",
    findEnd     = "",
    downloading = "Downloading the files, please waiting~",
    completely  = "Download completes, Unzip the files~",
    newest      = "The client version is newest~",
    fail        = "Download failed!",
}

local m_CardStatePath = 
{
    common = "res/ui/ui_material/update/update_card.png",
    upper  = "res/ui/ui_material/update/update_card_2s.png",
    lower  = "res/ui/ui_material/update/update_card_1s.png",
}

local m_knowHow = require("src/settings/knowhow")

local KUILoginUpdateNode = class(
    "KUILoginUpdateNode", function () return cc.Node:create() end
)

function KUILoginUpdateNode:ctor()
    self._beginLoadTime   = nil
    self._parent          = nil
    self._mainLayout      = nil
    self._uiPath          = nil
    self._lastUpdateTime  = nil
    self._loadSize        = nil
    self._tipState        = nil
    self._srcUpdate       = nil
    self._talkUpdate      = nil
    self._szCardState     = "common"
    self._nLastHitTime    = nil
    self._nHitCount       = 0
    self._tHitCount       = {}
    self._nknowHowIndex   = 0
    self._labelknowHow    = nil
    self._nErrorTime      = nil
    self._isDownloadStagnation = getSettingBool("isDownloadStagnation")
    self._szSrcVersion    = nil
end

function KUILoginUpdateNode.create(owner)
    local currentNode          = KUILoginUpdateNode.new()
    currentNode._parent        = owner
    currentNode._uiPath        = "res/ui/layout_updated.csb"
    currentNode._loadSize      = 0
    
    local tUrlList             = GetUrlList() --"http://172.18.69.110:21000/lan/"
    currentNode._srcUpdate     = CreateUpdateManager("src", 1, tUrlList, VERSION, IS_MINI, false, 10)
    if getSettingBool("isLoadTalk") or not getSettingBool("isPromptLoadTalk") then
        --tUrlList               = GetUrlList("talk") --"http://172.18.69.110:21000/lan/talk/"
        --currentNode._talkUpdate= CreateUpdateManager("talk", 2, tUrlList, "", true, false, 10)
        setSettingBool("isLoadTalk", true)
        setSettingBool("isPromptLoadTalk", true)
    end
    currentNode:init()

    return currentNode
end

local function getSizeString(nSize)
    local tUnitList  = {"B", "KB", "MB", "GB"}
    local nUnitIndex = 1
    while nSize > 1024 do
        nSize = nSize / 1024
        nUnitIndex = nUnitIndex + 1
        if nUnitIndex == #tUnitList then
            break
        end
    end
    return string.format("%.2f%s", nSize, tUnitList[nUnitIndex])
end

local function reloadOne(moduleName)
    if package.loaded[moduleName] then
        package.loaded[moduleName] = nil
        require(moduleName)
    end
end

local function tryReloadAll()
    reloadOne("src/base/KGlobalFunction")
    reloadOne("src/ui/common/KUIShowConfirmationNode")
    -- reloadOne("src/version")
    reloadOne("src/ui/login/KUILoginUpdateNode")
end

local function beginGame()
    VERSION = getSettingString("srcversion", VERSION)
    myPrint("beginGame---------------", VERSION)
    tryReloadAll()
    local gameScene = require("src/ui/login/KUILoginScene").create()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(gameScene)
    else
        cc.Director:getInstance():runWithScene(gameScene)
    end
end

local function showTip(self, szName, szText)
    self._tipState = szName
    local mainNode = self._mainLayout
    local nodeTips = mainNode:getChildByName("Image_update_information")
    nodeTips:setVisible(true)

    local scrollView = nodeTips:getChildByName("ScrollView_update_information")
    local textInfo   = scrollView:getChildByName("BitmapFontLabel_update_information")
    textInfo:setString(szText)
end

local function showknowHow(self)
    self._nknowHowIndex = self._nknowHowIndex + 1
    if self._nknowHowIndex > #m_knowHow then
        self._nknowHowIndex = 1
    end
    local mainNode      = self._mainLayout
    local imageknowHow  = mainNode:getChildByName("Image_dialog_box")
    local labelknowHow  = imageknowHow:getChildByName("BitmapFontLabel_text")
    if self._labelknowHow then
        imageknowHow:removeChild(self._labelknowHow)
    end
    local szText        = m_knowHow[self._nknowHowIndex]
    assert(szText)
    local label = cc.LabelBMFont:create(szText.szText, FONT_PATH)
    label:setWidth(labelknowHow:getContentSize().width)
    label:setAnchorPoint(0, 1)            
    label:setPosition(labelknowHow:getPosition())
    imageknowHow:addChild(label)
    self._labelknowHow = label
end

local function setCardState(self, szState)
    if self._szCardState == szState then return end
    self._szCardState = szState
    local mainNode    = self._mainLayout
    local imageCard   = mainNode:getChildByName("Image_update_card")
    imageCard:loadTexture(m_CardStatePath[self._szCardState])
end

local function showHitCount(self)
    local mainNode      = self._mainLayout
    local panelTipPlate = mainNode:getChildByName("Panel_countdown")
    local labelHitCount = panelTipPlate:getChildByName("BitmapFontLabel_girl_digital")
    labelHitCount:setString(tostring(self._nHitCount))
end

local function hit(self, szPart)
    self._nLastHitTime = C_GetTickCount()
    self._nHitCount    = self._nHitCount + 1
    if self._nHitCount > MAX_HIT_COUNT then
        self._nHitCount = MAX_HIT_COUNT
    end
    showHitCount(self)
    showknowHow(self)

    self._tHitCount[szPart]     = (self._tHitCount[szPart] or 0) + 1
    if self._tHitCount[szPart] >= CUT_OFF_COUNT then
        self._tHitCount[szPart] = 0
        setCardState(self, szPart)
    end
end

local function getInfo(tSrcInfo, tTalkInfo)
    if tSrcInfo.loadState == "newest" then return tTalkInfo end
    if tTalkInfo.loadState == "newest" then return tSrcInfo end
    if tSrcInfo.loadState == "findEnd"
       and tSrcInfo.uncompressState ~= "begin" 
       and tSrcInfo.removeFileState ~= "begin" then 
       return tTalkInfo 
    end
    return tSrcInfo
end

local function refreshUpdateInfo(self)
    local function updateInfo()
        local nowTime        =  C_GetTickCount()
        if not self._lastUpdateTime then
            self._lastUpdateTime = nowTime
        end
        local oldTime       = self._lastUpdateTime
        local tSrcInfo      = self._srcUpdate.getUpdateInfo()
        myPrint("updateInfo-----------tSrcInfo", tSrcInfo.isFinish, tSrcInfo.loadState, getSettingString("srcversion", VERSION), tSrcInfo.newestVersion, tSrcInfo.totalSize)
        local tinfo
        local tTalkInfo
        if self._talkUpdate then
            tinfo     = {}
            tTalkInfo = self._talkUpdate.getUpdateInfo()
            myPrint("updateInfo-----------tTalkInfo", tTalkInfo.isFinish, tTalkInfo.loadState, getSettingString("talkversion"), tTalkInfo.newestVersion, tTalkInfo.totalSize)
            local t = getInfo(tSrcInfo, tTalkInfo)
            for i, v in pairs(t) do
                tinfo[i] = v
            end

            tinfo.newestVersion  = tSrcInfo.newestVersion
            tinfo.totalFileCount = tSrcInfo.totalFileCount + tTalkInfo.totalFileCount
            if tSrcInfo.totalSize or tTalkInfo.totalSize then
                tinfo.totalSize  = (tSrcInfo.totalSize or 0) + (tTalkInfo.totalSize or 0)
            end
            if tSrcInfo.fileSize or tTalkInfo.fileSize then
                tinfo.fileSize   = (tSrcInfo.fileSize or 0) + (tTalkInfo.fileSize or 0)
            end
            if tSrcInfo.loadSize or tTalkInfo.loadSize then
                tinfo.loadSize   = (tSrcInfo.loadSize or 0) + (tTalkInfo.loadSize or 0)
            end
        else
            tinfo = tSrcInfo
        end

        myPrint("updateInfo-----------", tinfo.loadState, tinfo.totalFileCount, nowTime, self._lastUpdateTime, self._loadSize, tinfo.loadSize, tinfo.totalSize)
        local nLoadSpeed     = 0
        if tinfo.loadSize then
            if nowTime > self._lastUpdateTime then
                if tinfo.loadSize < self._loadSize then
                    addError("loadSize error")
                else
                    nLoadSpeed           = (tinfo.loadSize - self._loadSize) / (nowTime - self._lastUpdateTime) *1000
                    self._lastUpdateTime = nowTime
                end
            end
            self._loadSize   = tinfo.loadSize
        end
        if not self._isDownloadStagnation 
            and tinfo.loadState == "downloading" 
            and nLoadSpeed < MIN_NORMAL_SPEED 
            and self._nErrorTime then
            self._nErrorTime = self._nErrorTime + nowTime - oldTime
            if self._nErrorTime > STAGNANCY_TIME then
                addError("Download stagnation:", string.format("Download time:%d, Downloaded size:%d, Current Speed:%d", nowTime - self._beginLoadTime, tinfo.totalSize, nLoadSpeed))
                self._isDownloadStagnation = true
                setSettingBool("isDownloadStagnation", true)
            end
        else
            self._nErrorTime = 0
        end

        local nPercent       = 0
        if tinfo.fileSize and tinfo.totalSize and tinfo.totalSize > 0 then
            nPercent = tinfo.fileSize * 100 / tinfo.totalSize
        end

        local nRemainingTime
        local szRemainingTime = "剩余時間:"
        if nLoadSpeed > 0 then
            nRemainingTime = (tinfo.totalSize - tinfo.fileSize) / nLoadSpeed
            local nHour =  math.floor(nRemainingTime / 3600)
            nRemainingTime = nRemainingTime % 3600
            local nMinute = math.floor(nRemainingTime / 60)
            local nSecond = math.ceil(nRemainingTime % 60)
            if nHour > 0 then
                szRemainingTime = szRemainingTime .. nHour .. "小時"
            end
            if nMinute > 0 then
                szRemainingTime = szRemainingTime .. nMinute .. "分"
            end
            if nSecond > 0 then
                szRemainingTime = szRemainingTime .. nSecond .. "秒"
            end
        end

        myPrint("updateInfo-----------RemainingTime", tinfo.loadState, nLoadSpeed, szRemainingTime)

        local mainNode       = self._mainLayout
        local imageBase      = mainNode:getChildByName("Image_loading_base")
        local loadingBar     = imageBase:getChildByName("LoadingBar_loading")
        loadingBar:setPercent(nPercent)
        local imageIconTank  = loadingBar:getChildByName("Image_icon_tank")
        local nBarWidth      = loadingBar:getContentSize().width
        local szPercent      = string.format("%.3f%%", nPercent)
        imageIconTank:setPosition(nBarWidth * nPercent / 100, imageIconTank:getPositionY())

        local textBMFont     = imageBase:getChildByName("BitmapFontLabel_2")
        textBMFont:setString(szPercent)

        local labelRemainingTime = imageBase:getChildByName("Text_remain_time")
        labelRemainingTime:setString(szRemainingTime)

        local textTotalSize  = imageBase:getChildByName("BitmapFontLabel_total_number")
        if tinfo.totalSize then
            textTotalSize:setString(getSizeString(tinfo.totalSize))
        else
            textTotalSize:setString("")
        end

        local textLoadSize   = imageBase:getChildByName("BitmapFontLabel_file_percent")
        if tinfo.fileSize then
            textLoadSize:setString(getSizeString(tinfo.fileSize))
        else
            textLoadSize:setString("")
        end

        local textLoadSpeed  = imageBase:getChildByName("BitmapFontLabel_download_speed")
        textLoadSpeed:setString(string.format("%s/S", getSizeString(nLoadSpeed)))

        myPrint("updateInfo-----------tinfo", tinfo.isFinish, tinfo.loadState)

        local szLog = ""
        if tinfo.uncompressState == "begin" then
            szLog = string.format("Unzip the files~ (%d/%d)", tinfo.uncompressCount, tinfo.beCompressedCount)
        elseif tinfo.removeFileState == "begin" then
            szLog = string.format("Remove the files~ (%d/%d)", tinfo.removeFileCount, tinfo.removeFileTotalCount)
        elseif tinfo.loadState == "findEnd" and not tinfo.bBeginLoad and not self._tipState then
            if not getSettingBool("isPromptLoadTalk") then
                self._tipState        = "first"
                local imageSelect     = mainNode:getChildByName("Image_audio_download")
                local lableTotalSize1 = imageSelect:getChildByName("BitmapFontLabel_1")
                local lableTotalSize2 = imageSelect:getChildByName("BitmapFontLabel_2")
                lableTotalSize1:setString(getSizeString(tinfo.totalSize))
                lableTotalSize2:setString(getSizeString(tSrcInfo.totalSize))
                imageSelect:setVisible(true)
            else
                local szVersion = getSettingString("srcversion", VERSION)
                local szNewestVersion = tinfo.newestVersion
                myPrint("updateInfo--------", szVersion, szNewestVersion)
                if szVersion == szNewestVersion then
                    szVersion = getSettingString("talkversion")
                    if tTalkInfo then
                        szNewestVersion = tTalkInfo.newestVersion
                    else
                        addError("tTalkInfo is nil")
                    end
                end
                if szNewestVersion ~= szVersion then
                    local szText   = string.format("司令司令~要更新了哦~\n版本號：   %s -> %s\n文件數量：%d\n大小：      %s\n請問現在就更新嗎？", szVersion, szNewestVersion, tinfo.totalFileCount, getSizeString(tinfo.totalSize))
                    showTip(self, "updateInfo", szText)
                else
                    addError("Version is same " .. szVersion)
                end
            end
        else
            szLog = m_Logs[tinfo.loadState]
        end

        local textLog      = imageBase:getChildByName("BitmapFontLabel_current_file")
        textLog:setString(szLog)


        if tinfo.isFinish then
            if tinfo.uncompressState     == "fail" then
                local szText = string.format("司令~解壓失敗了!請保證有足夠磁盤空間\n選擇“確定”會繼續嘗試解壓\n選擇“取消”會嘗試直接進入游戲，但一些功能可能會運行不正常")
                showTip(self, "updateFail", szText)
            elseif tinfo.loadState       == "fail" then
                local szText = string.format("司令~更新失敗了!是否繼續更新？\n選擇“確定”會繼續嘗試更新\n選擇“取消”會嘗試直接進入游戲，但一些功能可能會運行不正常") 
                showTip(self, "updateFail", szText)
            else
                self:stopAllActions()
                delayExecute(self, beginGame, 1)
            end
        end

        if self._nLastHitTime and self._nLastHitTime + RESTORE_TIME <= nowTime then
            setCardState(self, "common")
        end

        VERSION = getSettingString("srcversion", VERSION)
        if self._szSrcVersion ~= VERSION then
            self._szSrcVersion = VERSION
            local textVersion = mainNode:getChildByName("Text_version_number")
            textVersion:setString(self._szSrcVersion)
        end
    end

    updateInfo()
    local actionSequene = cc.Sequence:create(
        cc.DelayTime:create(2), 
        cc.CallFunc:create(updateInfo)
    )
    self:runAction(cc.RepeatForever:create(actionSequene))
end

function KUILoginUpdateNode:refreshUI()
    local mainNode    = self._mainLayout
    local imageTips   = mainNode:getChildByName("Image_update_information")
    imageTips:setVisible(false)
    local imageSelect = mainNode:getChildByName("Image_audio_download")
    imageSelect:setVisible(false)

    local imageknowHow = mainNode:getChildByName("Image_dialog_box")
    local labelknowHow = imageknowHow:getChildByName("BitmapFontLabel_text")
    labelknowHow:setString("")

    showHitCount(self)
    showknowHow(self)
    refreshUpdateInfo(self)
end

function KUILoginUpdateNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local imageTips     = mainNode:getChildByName("Image_update_information")
    local buttonConfirm = imageTips:getChildByName("Button_update_confirm")
    local function onConfirmClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._tipState     == "updateFail"   then
            self._srcUpdate.resetLoadCount()
            if self._talkUpdate then
                self._talkUpdate.resetLoadCount()
            end
        elseif self._tipState == "updateInfo"   then
            self._srcUpdate.loadZip()
            if self._talkUpdate then
                self._talkUpdate.loadZip()
            end
            self._beginLoadTime = C_GetTickCount()
        end
        self._tipState = nil
        imageTips:setVisible(false)
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonCancel    = imageTips:getChildByName("Button_update_cancel")
    local function onCancelClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._tipState     == "updateFail" then
            C_StopAllDownload()
            self:stopAllActions()
            beginGame()
        elseif self._tipState == "updateInfo" then
            cc.Director:getInstance():endToLua() 
        end
        self._tipState = nil
        imageTips:setVisible(false)
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local imageSelect   = mainNode:getChildByName("Image_audio_download")
    local buttonTotal   = imageSelect:getChildByName("Button_all_download")
    local function onTotalClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        myPrint("onTotalClick------------")
        setSettingBool("isPromptLoadTalk", true)
        setSettingBool("isLoadTalk", true)
        self._srcUpdate.loadZip()
        assert(self._talkUpdate)
        self._talkUpdate.loadZip()
        imageSelect:setVisible(false)
        self._tipState      = nil
        self._beginLoadTime = C_GetTickCount()
    end
    buttonTotal:addTouchEventListener(onTotalClick)

    local buttonPart    = imageSelect:getChildByName("Button_part_download")
    local function onPartClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        setSettingBool("isPromptLoadTalk", true)
        self._srcUpdate.loadZip()
        self._talkUpdate    = nil
        imageSelect:setVisible(false)
        self._tipState      = nil
        self._beginLoadTime = C_GetTickCount()
    end
    buttonPart:addTouchEventListener(onPartClick)
    
    local buttonUpperBody = mainNode:getChildByName("Button_upper_part")
    local function onUpperBodyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        hit(self, "upper")
    end
    buttonUpperBody:addTouchEventListener(onUpperBodyClick)

    local buttonLowerBody = mainNode:getChildByName("Button_lower_part")
    local function onLowerBodyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        hit(self, "lower")
    end
    buttonLowerBody:addTouchEventListener(onLowerBodyClick)
end

function KUILoginUpdateNode:registerAllCustomEvent()
end

function KUILoginUpdateNode:onEnter()
    self._srcUpdate.run()
    if self._talkUpdate then
        self._talkUpdate.run()
    end
end

function KUILoginUpdateNode:onExit()
    myPrint("KUILoginUpdateNode:onExit--------------")
    C_StopAllDownload()
    self._srcUpdate  = nil
    self._talkUpdate = nil
    KThreadManager.release()

    local bSuccess, KHotFix = pcall(require, "src/logic/KHotFix")
    if bSuccess and KHotFix then
        KHotFix.init(m_tUrlList)
        KHotFix.loadVersion()
    end
end

function KUILoginUpdateNode:init()
    assert(self._uiPath ~= nil, "uiResPath is not config~")
    self._mainLayout = cc.CSLoader:createNode(self._uiPath)
    self:autoHandler()
end

function KUILoginUpdateNode:autoHandler()
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        end
        if "exit" == event then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

    assert(self._mainLayout)
    self:addChild(self._mainLayout, 1)

    self:refreshUI()
    
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

function addUpdateScene()
    local updateScene = cc.Scene:create()
    assert(updateScene)
    local node = KUILoginUpdateNode.create(updateScene)

    updateScene:addChild(node)
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(updateScene)
    else
        cc.Director:getInstance():runWithScene(updateScene)
    end
end
