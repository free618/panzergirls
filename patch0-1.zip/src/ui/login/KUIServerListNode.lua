--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIServerListNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/21   14:07
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_tUnitTexturePath = {
    ["buttonNormalTexture"]  = "res/ui/ui_material/sign_up/dl_server_bg.png",
    ["buttonPressTexture"]   = "res/ui/ui_material/sign_up/dl_server_bg_active.png",
    ["buttonDisableTexture"] = "res/ui/ui_material/sign_up/dl_server_bg_disable.png"
}

local m_tConnectState = {
    ["STATE_INVALID"]         = "STATE_INVALID",
    ["STATE_WAIT_ENTER_GS"]   = "STATE_WAIT_ENTER_GS",
    ["STATE_LS_DISCONNECTED"] = "STATE_LS_DISCONNECTED",
    ["STATE_ENTERED_GS"]      = "STATE_ENTERED_GS",
}

local KUIServerListNode = class(
    "KUIServerListNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIServerListNode:ctor()
    self._mainLayout       = nil
    self._parent           = nil
    self._uiPath           = nil
    self._serverList       = {}
    self._selectedServerID = nil
    self._selectedIndex    = nil
    self._buttonServerUnit = nil
    self._connectState     = m_tConnectState.STATE_INVALID
end

function KUIServerListNode.create(owner)
    local currentNode = KUIServerListNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign_up_server.csb"
    currentNode:init()
    
    return currentNode
end

local function getServerNameByID(serverList, serverID)
    for index, oneServerInfo in ipairs(serverList) do
        if serverID == oneServerInfo.nServerID then
            return oneServerInfo.szServerName
        end
    end
end

local function generateButtonServerBase(self)
    local mainNode          = self._mainLayout
    local imageChooseBase   = mainNode:getChildByName("Image_server_choose_base")
    local scrollServerList  = imageChooseBase:getChildByName("ScrollView_server_list")
    local buttonServer      = scrollServerList:getChildByName("Button_server_button")

    self._buttonServerUnit  = buttonServer:clone()
    self._buttonServerUnit:retain()
    buttonServer:removeFromParent()
end

local function checkServerMaintain(self)
    local mainNode          = self._mainLayout
    local buttonStart       = mainNode:getChildByName("Button_start")
    local buttonMaintain    = mainNode:getChildByName("Button_maintain")

    local imageDisable  = "res/ui/ui_material/sign_up/maintain_button_disable.png"
    buttonMaintain:loadTextureNormal(imageDisable)
    buttonMaintain:setTouchEnabled(false)

    local ifOnline = self._serverList[self._selectedIndex].bOnline
    buttonStart:setVisible(ifOnline)
    buttonMaintain:setVisible(not ifOnline)
end

local function refreshServerListUI(self)
    local mainNode          = self._mainLayout
    local imageChooseBase   = mainNode:getChildByName("Image_server_choose_base")
    local scrollServerList  = imageChooseBase:getChildByName("ScrollView_server_list")

    
    for index, oneServerInfo in ipairs(self._serverList) do
        local oneButtonUnit  = scrollServerList:getChildByName("button_server_" .. index)

        local textServerName = oneButtonUnit:getChildByName("Text_server_name")
        textServerName:setString(oneServerInfo.szServerName)

        if index == self._selectedIndex then
            oneButtonUnit:loadTextures(m_tUnitTexturePath.buttonPressTexture,
                                       m_tUnitTexturePath.buttonPressTexture,
                                       m_tUnitTexturePath.buttonPressTexture)
        else
            oneButtonUnit:loadTextures(m_tUnitTexturePath.buttonNormalTexture,
                                       m_tUnitTexturePath.buttonPressTexture,
                                       m_tUnitTexturePath.buttonPressTexture)
        end

        local panelStatus = oneButtonUnit:getChildByName("Panel_status_image")
        local allState    = panelStatus:getChildren()
        for _, imageState in pairs(allState) do imageState:setVisible(false) end

        local imageMaintain    = panelStatus:getChildByName("Image_maintenance")
        local imageNew         = panelStatus:getChildByName("Image_newcity")
        local imageRecommended = panelStatus:getChildByName("Image_recommended")
        local imageSmooth      = panelStatus:getChildByName("Image_smooth")
        local imageHot         = panelStatus:getChildByName("Image_hot")
    
        if not oneServerInfo.bOnline then 
            imageMaintain:setVisible(true)
            oneButtonUnit:setTouchEnabled(false)
            oneButtonUnit:loadTextures(m_tUnitTexturePath.buttonDisableTexture,
                                       m_tUnitTexturePath.buttonDisableTexture,
                                       m_tUnitTexturePath.buttonDisableTexture)
        elseif oneServerInfo.bNew then
            imageNew:setVisible(true)
        --elseif oneServerInfo.bBusy then
        elseif oneServerInfo.bHot then
            imageHot:setVisible(true)
        elseif oneServerInfo.bRecommend then
            imageRecommended:setVisible(true)
        else
            imageSmooth:setVisible(true)
        end

        local function onButtonClick(sender, type)
            if type == ccui.TouchEventType.ended then
                self._selectedIndex    = index
                self._selectedServerID = oneServerInfo.nServerID
                local buttonServer     = mainNode:getChildByName("Button_server")
                buttonServer:setTitleText(oneServerInfo.szServerName)
                refreshServerListUI(self)
            end
        end
        oneButtonUnit:addTouchEventListener(onButtonClick)
    end
    checkServerMaintain(self)
end

local function getTheBestServer(self)
    local mainNode = self._mainLayout
    local setting = require("src/logic/KSetting")
    local function changeServer(index, serverInfo)
        self._selectedIndex    = index
        self._selectedServerID = serverInfo.nServerID
        local buttonServer     = mainNode:getChildByName("Button_server")
        buttonServer:setTitleText(serverInfo.szServerName)
        refreshServerListUI(self)
    end

    local defaultServerID = setting.getInt(setting.Key.SERVERID)
    if defaultServerID and defaultServerID ~= 0 then
        for index, serverInfo in ipairs(self._serverList) do
            if defaultServerID == serverInfo.nServerID then
                changeServer(index, serverInfo)
                return
            end
        end
    else
        for index,serverInfo in ipairs(self._serverList) do
            if serverInfo.bNew and serverInfo.bOnline then
                changeServer(index, serverInfo)
                return
            end
        end

        for index,serverInfo in ipairs(self._serverList) do
            if serverInfo.bRecommend and serverInfo.bOnline then
                changeServer(index, serverInfo)
                return
            end
        end

        for index,serverInfo in ipairs(self._serverList) do
            if serverInfo.bOnline then
                changeServer(index, serverInfo)
                return
            end
        end
    end
end

local function initServerListUI(self)
    local mainNode          = self._mainLayout
    local imageChooseBase   = mainNode:getChildByName("Image_server_choose_base")
    local scrollServerList  = imageChooseBase:getChildByName("ScrollView_server_list")
    scrollServerList:removeAllChildren()

    local buttonServerUnit  = self._buttonServerUnit
    local scrollViewWidth   = scrollServerList:getContentSize().width
    local scrollViewHeight  = scrollServerList:getContentSize().height
    local basePositionX     = buttonServerUnit:getPositionX()
    local basePositionY     = buttonServerUnit:getPositionY()
    local baseContentHeight = buttonServerUnit:getContentSize().height

    local realScrollHeight = baseContentHeight * (#self._serverList)
    if realScrollHeight < scrollViewHeight then realScrollHeight = scrollViewHeight end
    scrollServerList:setInnerContainerSize(cc.size(scrollViewWidth, realScrollHeight))

    local heightOffset = realScrollHeight - scrollViewHeight
    basePositionY      = basePositionY + heightOffset

    for index, oneServerInfo in ipairs(self._serverList) do
        local newButtonUnit = self._buttonServerUnit:clone()
        local unitPositionX = basePositionX
        local unitPositionY = basePositionY - (index - 1) * baseContentHeight
        newButtonUnit:setPosition(cc.p(unitPositionX, unitPositionY))
        newButtonUnit:setName("button_server_" .. index)
        scrollServerList:addChild(newButtonUnit)
    end
    
    scrollServerList:jumpToTop()
    refreshServerListUI(self)
    getTheBestServer(self)
end

local function logoutAndBackToLoginNode(self)
    local loginNode = self._parent:getNode("LoginAndRegister")
    assert(loginNode)

    loginNode:setLoginButtonEnable(true)
    KGameServer:Logout()
    self._parent:removeNode("ServerList")    
end

function KUIServerListNode:setServerList(serverList)
    table.sort(serverList, function (a, b) return a.nServerID > b.nServerID end)
    self._serverList = serverList
    self:refreshUI()
    initServerListUI(self)
end

function KUIServerListNode:refreshUI()
    if not self._serverList then return end
    if #self._serverList == 0 then return end

    self._selectedIndex   = 1

    local mainNode          = self._mainLayout
    local imageChooseBase   = mainNode:getChildByName("Image_server_choose_base")
    imageChooseBase:setVisible(false)

    local textVersion       = mainNode:getChildByName("Text_version_number")
    textVersion:setString(VERSION)
end

function KUIServerListNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local buttonStart       = mainNode:getChildByName("Button_start")
    local buttonServer      = mainNode:getChildByName("Button_server")
    local imageChooseBase   = mainNode:getChildByName("Image_server_choose_base")
    local buttonCloseChoose = imageChooseBase:getChildByName("Button_close")
    

    local function onStartClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("----------> onStartClick")
        KSound.playEffect("click")

        if self._connectState == m_tConnectState.STATE_WAIT_ENTER_GS or
            self._connectState == m_tConnectState.STATE_ENTERED_GS then
            return
        end

        if self._connectState == m_tConnectState.STATE_LS_DISCONNECTED then
            showNoticeByID("common.connect.timeoutTip")
            local showNoticeTime = 2.0
            KUtil.setTouchEnabled(buttonStart, false)

            local function goBackToLoginNode()
                logoutAndBackToLoginNode(self)
            end

            delayExecute(self._parent, goBackToLoginNode, showNoticeTime)
            return
        end

        if self._connectState == m_tConnectState.STATE_INVALID then
            local serverID   = self._selectedServerID
            KPlayer.serverName = getServerNameByID(self._serverList, serverID)
            self._connectState = m_tConnectState.STATE_WAIT_ENTER_GS        
            buttonStart:setTouchEnabled(false)
            KGameServer:EnterServer(serverID)
            return
        end
    end
    buttonStart:addTouchEventListener(onStartClick)
    
    local function onServerClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("----------> onServerClick")
        KSound.playEffect("click")
        imageChooseBase:setVisible(true)
        buttonServer:setTouchEnabled(false)
        refreshServerListUI(self)
    end
    buttonServer:addTouchEventListener(onServerClick)
    
    local function onCloseChooseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("----------> onCloseChooseClick")
        KSound.playEffect("click")
        imageChooseBase:setVisible(false)
        buttonServer:setTouchEnabled(true)
    end
    buttonCloseChoose:addTouchEventListener(onCloseChooseClick)
end

function KUIServerListNode:registerAllCustomEvent()
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    --eventDispatch:dispatchEvent(eventDispatch.EventType.NET_ENTER_SERVER_RESULT, nRetCode)
    local function onEnterServerResult(retCode, roleID)
        cclog("----------> onEvent NET_ENTER_SERVER_RESULT")

        self:unregisterAllCustomEvent()

        if retCode == ENTER_SERVER_RET.SUCCESS then
            local setting = require("src/logic/KSetting")
            setting.setInt(setting.Key.SERVERID, self._selectedServerID)
            
            local defaultServerInfo = self._serverList[self._selectedIndex]
            local serverName = defaultServerInfo.szServerName
            setting.setString(setting.Key.SERVERNAME, serverName)
            self._connectState = m_tConnectState.STATE_ENTERED_GS
            self._parent:addNode("LoginLoading")
            return
        end

        local reloginTip = KUtil.getStringByKey("common.connect.reloginTip")
        local detailMsg  = KUtil.getStringByKey("common.connect_to_gs.unknow")
        if retCode == ENTER_SERVER_RET.SERVER_BUSY then
            detailMsg = KUtil.getStringByKey("common.connect_to_gs.busy")
        elseif retCode == ENTER_SERVER_RET.SERVER_NOT_EXIST then
            detailMsg = KUtil.getStringByKey("common.connect_to_gs.noExist")
        elseif retCode == ENTER_SERVER_RET.SERVER_OFFLINE then
            detailMsg = KUtil.getStringByKey("common.connect_to_gs.offline")
        elseif retCode == ENTER_SERVER_RET.TIME_OUT then
            detailMsg = KUtil.getStringByKey("common.connect_to_gs.timeout")
        elseif retCode == ENTER_SERVER_RET.FROZEN then
            local nFrozen = roleID
            if nFrozen > 0 then
                detailMsg = KUtil.formatStringByKey("login.frozen1", KUtil.formatTime(nFrozen))
            elseif nFrozen < 0 then
                detailMsg = KUtil.getStringByKey("login.frozen2")
            end
            reloginTip = ""
        end

        local function onConfirm()
            logoutAndBackToLoginNode(self)             
        end

        local confirmText = detailMsg .. reloginTip
        showConfirmation(confirmText, onConfirm, onConfirm)            

        self._connectState = m_tConnectState.STATE_INVALID
    end
    self:addCustomEvent(eventDispatch.EventType.NET_ENTER_SERVER_RESULT, onEnterServerResult)

    local function onLSDisconnect()
        cclog("----------> onEvent NET_LS_DISCONNECT")
        if self._connectState == m_tConnectState.STATE_INVALID or
            self._connectState == m_tConnectState.STATE_WAIT_ENTER_GS then
            local function onConfirm()
                logoutAndBackToLoginNode(self)             
            end

            local confirmText = KUtil.getStringByKey("common.connect.timeoutTip")
            showConfirmation(confirmText, onConfirm, onConfirm)
        end

        self._connectState = m_tConnectState.STATE_LS_DISCONNECTED
    end
    self:addCustomEvent(eventDispatch.EventType.NET_LS_DISCONNECT, onLSDisconnect)
end

function KUIServerListNode:runEnterAction()
end

function KUIServerListNode:runExitAction()
end

function KUIServerListNode:init()
    -- load csb file
    assert(self._uiPath ~= nil, "uiResPath is not config~")
    self._mainLayout = cc.CSLoader:createNode(self._uiPath)

    generateButtonServerBase(self)
    
    -- set autoHandler()
    self:autoHandler()
end

function KUIServerListNode:onCleanup()
    self._buttonServerUnit:release()
end

return KUIServerListNode
