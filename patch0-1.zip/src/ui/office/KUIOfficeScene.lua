--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIOfficeScene.lua
--  Creator     : SunXun
--  Date        : 2015/07/20   22:28
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIOfficeScene = class(
    "KUIOfficeScene", function() return cc.Scene:create() end
)

KUIOfficeScene._currentScene  = nil
KUIOfficeScene._createCount       = 0
KUIOfficeScene._enterCount        = 0

function KUIOfficeScene:ctor()
    self._mainLayer         = nil
    self._nodeList          = {}
    self._nodeZOrder        = 2 -- mainLayer is 1 so we start from 2
end

KUIOfficeScene.NodeType = {
    ["Launch"]               = "src/ui/office/launch/KUILaunchNode",
    ["LaunchTeam"]           = "src/ui/office/launch/KUILaunchTeamNode",
    ["QuickRepair"]          = "src/ui/office/launch/KUIQuickRepairNode",
    ["LaunchMaps"]           = "src/ui/office/launch/KUILaunchMapsNode",
    ["SelectionDifficulty"]  = "src/ui/office/launch/KUISelectionDifficultyNode",
    ["Mission"]              = "src/ui/office/mission/KUIMissionListNode",
    ["Factory"]              = "src/ui/office/factory/KUIFactoryNode",
    -- ["Abandon"]              = "src/ui/office/factory/KUIFactoryAbandonNode",
    ["GearMultiChoose"]      = "src/ui/office/factory/KUIFactoryGearMultiChooseNode",
    -- ["Break"]                = "src/ui/office/factory/KUIFactoryBreakCardNode",
    ["CardChoose"]           = "src/ui/office/factory/KUIFactoryChooseCardNode",
    -- ["Build"]                = "src/ui/office/factory/KUIFactoryBuildCardNode",
    -- ["Develop"]              = "src/ui/office/factory/KUIFactoryDevelopNode",
    ["EquipLog"]             = "src/ui/office/factory/KUIFactoryEquipLogNode",
    ["CardLog"]              = "src/ui/office/factory/KUIFactoryCardLogNode",
    -- ["FactoryAwardTank"]     = "src/ui/office/factory/KUIFactoryAwardTankNode",
    ["AwardEquip"]           = "src/ui/office/factory/KUIFactoryAwardEquipNode",
    ["BuildUnlock"]          = "src/ui/office/factory/KUIFactoryBuildUnlock",
    ["Team"]                 = "src/ui/office/team/KUITeamNode",
    ["TeamCharacter"]        = "src/ui/office/team/KUITeamCharacterNode",
    ["TeamChangeSkill"]      = "src/ui/office/team/KUITeamChangeSkillNode",
    ["TeamChangeEquip"]      = "src/ui/office/team/KUITeamChangeEquipNode",
    ["TeamChangeCard"]       = "src/ui/office/team/KUITeamChangeCardNode",
    ["TeamRecord"]           = "src/ui/office/team/KUITeamRecordNode",
    ["Strengthen"]           = "src/ui/office/team/KUITeamStrengthenNode",
    ["Repair"]               = "src/ui/office/repair/KUIRepairNode",
    ["Convert"]              = "src/ui/office/team/KUITeamConvertNode",
    ["RepairUnitChoose"]     = "src/ui/office/repair/KUIRepairUnitChooseNode",
    ["Supply"]               = "src/ui/office/repair/KUIRepairSupplyNode",
    ["Reborn"]               = "src/ui/office/repair/KUIRepairRebornNode",
    ["Collection"]           = "src/ui/office/collection/KUICollectionNode",
    ["CollectionFullScreen"] = "src/ui/office/collection/KUICollectionFullScreenNode",
    ["Expedition"]           = "src/ui/office/expedition/KUIExpeditionNode",
    ["ExpeditionChooseTeam"] = "src/ui/office/expedition/KUIExpeditionChooseTeamNode",
    ["Reward"]               = "src/ui/office/expedition/KUIRewardNode",
    ["ExpeditionReward"]     = "src/ui/office/expedition/KUIExpeditionRewardNode",
    ["Plunder"]              = "src/ui/office/expedition/KUIPlunderNode",
    ["PlunderDetail"]        = "src/ui/office/expedition/KUIPlunderDetailNode",
    ["Shop"]                 = "src/ui/office/shop/KUIShopNode",
    ["ShopSpring"]           = "src/ui/office/shop/KUIShopSpringNode",
    ["ExchangeShop"]         = "src/ui/office/shop/KUIExchangeShopNode",
    ["Item"]                 = "src/ui/office/item/KUIItemNode",
    ["BattlePrepare"]        = "src/ui/battle/KUIBattlePrepareNode",
    ["Battle"]               = "src/ui/battle/KUIBattleNode",
    ["BattleReport"]         = "src/ui/battle/KUIBattleReportNode",
    ["Rank"]                 = "src/ui/office/rank/KUIRankNode",
    ["Sign"]                 = "src/ui/office/sign/KUISignNode",   
    ["Announce"]             = "src/ui/office/announce/KUIAnnounceNode",
    ["Furniture"]            = "src/ui/office/furniture/KUIFurnitureNode",
    ["FurnitureShop"]        = "src/ui/office/shop/KUIFurnitureShopNode", 
    ["Exchange"]             = "src/ui/office/exchange/KUIExchangeNode",
    ["Raiders"]              = "src/ui/office/raiders/KUIRaidersNode",
    ["MailList"]             = "src/ui/office/mail/KUIMailListNode",
    ["Mail"]                 = "src/ui/office/mail/KUIMailNode",
    ["Food"]                 = "src/ui/office/food/KUIFoodNode",
    ["FoodMedal"]            = "src/ui/office/food/KUIFoodMedalNode",
    ["ExerciseRoleList"]     = "src/ui/office/exercise/KUIExerciseRoleListNode",
    ["ExerciseRoleDetail"]   = "src/ui/office/exercise/KUIExerciseRoleDetailNode",
    ["FirstRecharge"]        = "src/ui/office/recharge/KUIFirstRechargeNode",
    ["AwardTank"]            = "src/ui/office/awardtank/KUIAwardTankNode",
    ["Medal"]                = "src/ui/office/medal/KUIMedalNode",
    ["MedalHelp"]            = "src/ui/office/medal/KUIMedalGuideNode",
    ["MedalDetail"]          = "src/ui/office/medal/KUIMedalDetailNode",
    ["ServiceActivity"]      = "src/ui/office/serviceactivity/KUIServiceActivityNode",
    ["SecretaryChoose"]      = "src/ui/office/secretary/KUISecretaryChooseNode", 
    ["SPSign"]               = "src/ui/office/spSign/KUISPSignNode",
    ["TankWedding"]          = "src/ui/office/wedding/KUIWeddingNode",
    ["BuildActivityPoster"]  = "src/ui/office/buildactivityposter/KUIBuildActivityPosterNode",
    ["Story"]                = "src/ui/office/story/KUIStoryNode",
    ["StoryPlay"]            = "src/ui/office/story/KUIStoryPlayNode",
    ["Training"]             = "src/ui/office/training/KUITrainingNode",
    ["TrainingComplete"]     = "src/ui/office/training/KUITrainingCompleteNode",
}

local NotHideNode = 
{
    ["PlunderDetail"]      = true,
    ["Expedition"]         = true,
    ["ExerciseRoleDetail"] = true,
    ["Factory"]            = true,
    ["LaunchTeam"]         = true,
    ["Team"]               = true,
    ["Medal"]              = true,
}

function KUIOfficeScene.create(szReason)
    if KUIOfficeScene._currentScene and not tolua.isnull(KUIOfficeScene._currentScene) then 
        return KUIOfficeScene._currentScene 
    end
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "scene create office", szReason)
    local currentScene = KUIOfficeScene.new()
    currentScene:autoHandler()
    local mainLayer = require("src/ui/office/KUIOfficeMainLayer").create(currentScene)
    currentScene._mainLayer = mainLayer
    currentScene:addChild(mainLayer)
    KUIOfficeScene._currentScene = currentScene

    showAnnounce(currentScene)
    
    if KPlayer.progressID < require("src/logic/KGuideEnv").FIRST_FIGHT_END then
        KSound.playMusic("fight")
    else
        KSound.playMusic("base")
    end
    KUIOfficeScene._createCount = KUIOfficeScene._createCount + 1
    return currentScene
end

function KUIOfficeScene:autoHandler()
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        elseif "exit" == event then
            -- self:onExit()
        elseif "cleanup" == event then
            self:unregisterScriptHandler()
            self:onCleanup()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end

function KUIOfficeScene:onEnter()
    KUIOfficeScene._currentScene = nil
    KUIOfficeScene._enterCount = KUIOfficeScene._enterCount + 1
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office scene enter")
    if KUIOfficeScene._enterCount ~= KUIOfficeScene._createCount then
        local str = string.format("office scene enter error, create:%d, enter:%d", KUIOfficeScene._createCount, KUIOfficeScene._enterCount)
        KLogGather.addLog("EventBug", str)
        KLogGather.sendLog("EventBug")
    end
    KLogGather.deleteLog("EventBug", "scene create")

    if KUtil.isGuide() then 
        require("src/logic/KGuideEnv").addCurrentGuideNode()
    end
end

function KUIOfficeScene:onCleanup()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", "office scene cleanup")
end

function KUIOfficeScene:addNode(nodeType, nodeData, ...)
    local filePath = KUIOfficeScene.NodeType[nodeType]
    assert(filePath, nodeType)
    for k, v in pairs(self._nodeList) do
        assert(type(v) == "table", "module not table: " .. nodeType)
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
    
    local mod    = require(filePath)
    assert(type(mod) == "table", "module not table: " .. filePath)
    local uiNode = mod.create(self, nodeData, ...)
    table.insert(self._nodeList, {["nodeType"] = nodeType, ["uiNode"] = uiNode, ["localZOrder"] = self._nodeZOrder})
    self:addChild(uiNode, self._nodeZOrder)
    self._nodeZOrder = self._nodeZOrder + 1

    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.UI_OPEN_PANEL)
    
    if #self._nodeList == 1 then    
        self._mainLayer:uiCutOff()
    end
    return uiNode
end

function KUIOfficeScene:removeNode(nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then
            KUtil.removeNodeAllEventListeners(v["uiNode"])
            local exitActionWasteTime = v["uiNode"]:runExitAction()
            local currentNodeCount = #self._nodeList            
            local function removeNodeCallBack()
                self:removeChild(v["uiNode"], true)
                if currentNodeCount == 1 then
                    self._mainLayer:uiCutIn()
                end 
            end
            table.remove(self._nodeList, k)
            delayExecute(self, removeNodeCallBack, exitActionWasteTime)
            return exitActionWasteTime
        end
    end
    
    assert(0, "try remove a unexisted node ! nodeType:%s", nodeType)
    return 0
end

function KUIOfficeScene:getNode(nodeType)
    local filePath = KUIOfficeScene.NodeType[nodeType]
    assert(filePath, nodeType)
    for k, v in pairs(self._nodeList) do
        if v["nodeType"] == nodeType then return v["uiNode"] end
    end
end

function KUIOfficeScene:returnOffice()
    -- remove all uiNode and reset ZOrder
    local currentNodeCount = #self._nodeList
    local count = 0
    for k, v in pairs(self._nodeList) do
        KUtil.removeNodeAllEventListeners(v["uiNode"])
        local exitActionWasteTime = v["uiNode"]:runExitAction()
        local nodeCount = count + 1
        local function removeNodeCallBack()
            self:removeChild(v["uiNode"], true)
            if currentNodeCount == nodeCount then
                self._mainLayer:uiCutIn()
            end            
        end
        count = nodeCount
        delayExecute(self, removeNodeCallBack, exitActionWasteTime)
    end
    self._nodeList = {}
    
    self._nodeZOrder = 2; -- mainLayer is 1 so we start from 2
end

function KUIOfficeScene:gotoUI(nodeType, ...)
    local filePath = KUIOfficeScene.NodeType[nodeType]
    if filePath then
        self:addNode(nodeType, ...)
    else
        self:returnOffice()
    end
end

function KUIOfficeScene:onNodeEnterActionFinished(targetNode)
    if not targetNode:isCovered() then return end
    local nodeList          = self._nodeList
    local topZOrder         = nil
    for k, v in pairs(nodeList) do
        if v["uiNode"] == targetNode then
            topZOrder = v["localZOrder"]
            break
        end
    end
    if topZOrder == nil then return end

    for k, v in pairs(nodeList) do
        if v["localZOrder"] < topZOrder and not NotHideNode[v.nodeType] then
            local node = v["uiNode"]
            node:setVisible(false)
        end
    end
end

function KUIOfficeScene:onNodeExitActionStarted(targetNode)
    if not targetNode:isCovered() then return end
    local nodeList          = self._nodeList
    local topZOrderNode     = nil
    local topZOrder         = 2 -- mainLayer is 1 so we start from 2
    for k, v in pairs(nodeList) do
        local localZOrder = v["localZOrder"]
        if v["uiNode"] ~= targetNode and localZOrder >= topZOrder then
            topZOrder = localZOrder
            topZOrderNode = v["uiNode"]
        end
    end

    if topZOrderNode then
        topZOrderNode:setVisible(true)
    end
end

return KUIOfficeScene
