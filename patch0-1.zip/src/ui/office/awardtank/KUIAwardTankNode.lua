--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIAwardTankNode.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/04/27   16:50
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIAwardTankNode = class(
    "KUIAwardTankNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIAwardTankNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._cardID       = 0
    self._isNewCard      = false
    self._awardAction   = nil
    self._effect        = nil
    self._callbcak      = nil
    self._callbackParam = nil
    self._isCovered   = false
end

function KUIAwardTankNode.create(owner, userData)
    local currentNode = KUIAwardTankNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_award_tank.csb"
    currentNode._cardID        = userData.nCardID
    currentNode._isNewCard       = userData.bNewCard

    currentNode:init()

    return currentNode
end

local function runGetCardEffect(imageCardChara)
    local effectUtil = require("src/base/KEffectUtil") 
    local param = {}
    param.tintColor              = cc.c4f(1.0, 1.0, 1.0, 1.0)
    param.outGlowColor           = cc.c4f(1.0, 1.0, 1.0, 1.0)
    param.outGlowRadius          = 0.15
    param.outGlowIntensity       = 3.0
    param.frameInterval          = 0.03

    local framesPerSecond        = 60
    param.tintInDelay            = 65 / framesPerSecond
    param.tintInDuration         = 50 / framesPerSecond
    param.tintFadeDuration       = 30 / framesPerSecond
    
    param.outGlowInDelay         = 55 / framesPerSecond
    param.outGlowInDuration      = 60 / framesPerSecond
    param.outGlowFadeDelay       = 30 / framesPerSecond
    param.outGlowFadeDuration    = 45 / framesPerSecond
    return effectUtil.runOutGlowEffect(imageCardChara, param)
end

local function refreshAnimation(self)
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")
    local panelBase     = projectNode:getChildByName("Panel_ani_award_tank")

    local oneCard        = KUtil.getCardById(self._cardID)
    assert(oneCard)
    local cardTemplateID = oneCard.nTemplateID
    local tCardConfig    = KUtil.getCardConfig(cardTemplateID)
    local tankImagePath  = KUtil.getCardImageByTemplateID(cardTemplateID)
    local tankName       = tCardConfig["szName"]
    local tankType       = CARD_TYPE_NAME[tCardConfig["nTankType"]]
    local tankStarLevel  = tCardConfig.nQuality
    local tankDialogue   = tCardConfig["szOpeningDialogue"]

    local bNewCard     = self._isNewCard
    local panelNewBase  = panelBase:getChildByName("Panel_new")
    panelNewBase:setVisible(bNewCard)

    local panelBackground = panelBase:getChildByName("Panel_bg")
    local imageBackground = panelBackground:getChildByName("Image_jl_bg")
    local backgroundPath  = KUtil.getCardBackImagePath(cardTemplateID)
    imageBackground:loadTexture(backgroundPath)

    local imageCardChara = panelBase:getChildByName("Image_tank")
    imageCardChara:loadTexture(tankImagePath)

    self._effect = runGetCardEffect(imageCardChara)

    local panelDialoag   = panelBase:getChildByName("Panel_jl_dialog")
    local textName       = panelDialoag:getChildByName("Text_tank_name")
    textName:setString(tankName)

    local textType       = panelDialoag:getChildByName("Text_tank_type")
    textType:setString(tankType)

    local textDialoag    = panelDialoag:getChildByName("Text_dialog")
    textDialoag:setString(tankDialogue)

    local panelStar
    if tankStarLevel % 2 == 0 then
        local panelStar1       = panelDialoag:getChildByName("Panel_star_1")
        local panelStar2       = panelDialoag:getChildByName("Panel_star_2")
        panelStar1:setVisible(true)
        panelStar2:setVisible(false)
        panelStar = panelStar1
    else
        local panelStar1       = panelDialoag:getChildByName("Panel_star_1")
        local panelStar2       = panelDialoag:getChildByName("Panel_star_2")
        panelStar1:setVisible(false)
        panelStar2:setVisible(true)
        panelStar = panelStar2
    end

    local i = 0
    while true do
        i = i + 1
        local imageStar = panelStar:getChildByName("Image_star_" .. i)
        if not imageStar then break end
        imageStar:setVisible(tankStarLevel >= i)
    end

    self._awardAction = KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_award_tank.csb")
    KUtil.animationGotoFrameAndPlay(self._awardAction, 0, 200, false)

    KSound.playEffect("getCardPrompt")
    local function delayTalk()
        KSound.playTalk(KSound.TALK.GETCARD, cardTemplateID)
    end

    delayExecute(mainNode, delayTalk, 2.0)
end

function KUIAwardTankNode:refreshUI()
    refreshAnimation(self)
end

function KUIAwardTankNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")
    local panelBase     = projectNode:getChildByName("Panel_ani_award_tank")

    local buttonScreen  = panelBase:getChildByName("Button_screen")    

    local function onClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click KUIAwardTankNode~")
            KSound.playEffect("click")

            local awardAction    = self._awardAction
            if awardAction:isPlaying() then
                local endFrame       = 200
                awardAction:setCurrentFrame(endFrame)
                self._effect:stopEffect()
            else
                local cardID        = self._cardID
                local oneCard       = KUtil.getCardById(cardID)
                assert(oneCard)

                local function onCloseEvent()
                    KSound.stopSameCaseTalk(KSound.TALK.GETCARD, oneCard.nTemplateID)
                    
                    local callback = self._callback  
                    local cbParam  = self._callbackParam

                    local currentScene = cc.Director:getInstance():getRunningScene()
                    currentScene:removeNode("AwardTank")

                    if callback then
                        if cbParam then
                            callback(unpack(cbParam, 1, table.maxn(cbParam)))
                        else
                            callback()
                        end
                    end
                end

                if self._isNewCard and not oneCard.bLock then
                    local function lockCard()
                        require("src/network/KC2SProtocolManager"):lockCard(cardID, true)
                        onCloseEvent()
                    end
                    showConfirmation(KUtil.getStringByKey("card.lock.tip"), lockCard, onCloseEvent)
                else
                    onCloseEvent()
                end
            end
        end
    end
    buttonScreen:addTouchEventListener(onClick)
end

function KUIAwardTankNode:registerAllCustomEvent()
end

function KUIAwardTankNode:setCallback(callback, callbackParam)
    self._callback      = callback
    self._callbackParam = callbackParam
end

return KUIAwardTankNode