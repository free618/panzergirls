--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBuildActivityPosterNode.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/06/24   16:40
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIBuildActivityPosterNode = class(
    "KUIBuildActivityPosterNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBuildActivityPosterNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIBuildActivityPosterNode.create(owner, userData)
    local currentNode = KUIBuildActivityPosterNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_build_activity_poster.csb"

    currentNode:init()

    return currentNode
end

local function playAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")

    local openEndFrame    = 25
    local closeStartFrame = 50
    local animationName   = "ani_build_activity_poster"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "BuildActivityPoster", callBacks, isReturnOffice)
end

local function getBuildActivityCardList(nID)
    local buildActivityInfo         = KConfig.buildactivity[nID]
    if not buildActivityInfo then return end

    if not buildActivityInfo.tList then
        local tempList = {}
        for i = 1, 100 do
            local cardID    = buildActivityInfo["nCardID"..i]
            if not cardID then break end
            if cardID ~= 0 then
                table.insert(tempList, cardID)
            end
        end
        buildActivityInfo.tList = tempList
    end

    return buildActivityInfo.tList
end

local function initData(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_1")
    local imageBgBase = projectNode:getChildByName("Image_bg_base")
    local scrollView  = imageBgBase:getChildByName("ScrollView_1")
    local panelUnit   = scrollView:getChildByName("Panel_unit")
    self._basePanelUnit    = panelUnit:clone()
    self._basePanelUnit:retain()
end

local function initPanelUnit(self, control, dataInfo)
    local panelTank         = control:getChildByName("Panel_tank")
    local imageTankChara    = panelTank:getChildByName("Image_tank_chara")

    local imageTankNameBase = control:getChildByName("Image_tank_name_base") 
    local textTankName      = imageTankNameBase:getChildByName("Text_tank_name")

    local cardID            = dataInfo
    local cardConfigInfo    = KUtil.getCardConfig(cardID)
    assert(cardConfigInfo)

    local cardImagePath = KUtil.getCardImageByTemplateID(cardID)
    imageTankChara:loadTexture(cardImagePath)
    textTankName:setString(cardConfigInfo.szName)
end

local function refreshScrollView(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBgBase       = projectNode:getChildByName("Image_bg_base")
    local scrollView        = imageBgBase:getChildByName("ScrollView_1")
    scrollView:removeAllChildren()

    local isOpenedBuildActivity, openedBuildActivity = KUtil.isOpenedBuildActicity()
    if not isOpenedBuildActivity then return end

    local buildCardList = getBuildActivityCardList(openedBuildActivity.nID)
    local showListUI = {}
    for _,v in ipairs(buildCardList) do
        local newPanelUnit = self._basePanelUnit:clone()
        initPanelUnit(self, newPanelUnit, v)

        table.insert(showListUI, newPanelUnit)
    end

    KUtil.addScrollView(scrollView, showListUI, false, nil, false, true)

end

local function refreshActivityData(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBgBase       = projectNode:getChildByName("Image_bg_base")
    local labelTime1        = imageBgBase:getChildByName("BitmapFontLabel_time_1")
    local labelTime2        = imageBgBase:getChildByName("BitmapFontLabel_time_2")
    local labelTime3        = imageBgBase:getChildByName("BitmapFontLabel_time_3")
    local labelTime4        = imageBgBase:getChildByName("BitmapFontLabel_time_4")

    local isOpenedBuildActivity, openedBuildActivity = KUtil.isOpenedBuildActicity()
    if not isOpenedBuildActivity then return end
    
    local startData = os.date("*t", openedBuildActivity.otOpenTimes.nOpenTime)
    local endData   = os.date("*t", openedBuildActivity.otOpenTimes.nCloseTime)
   
    labelTime1:setString(startData.month)
    labelTime2:setString(startData.day)
    labelTime3:setString(endData.month)
    labelTime4:setString(endData.day)
end

function KUIBuildActivityPosterNode:onInitUI()
    initData(self)
    stopAllAnimation(self)
end

function KUIBuildActivityPosterNode:refreshUI()
    refreshActivityData(self)
    refreshScrollView(self)
end

function KUIBuildActivityPosterNode:onEnterActionFinished()
    playAnimation(self, true)
end

function KUIBuildActivityPosterNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_1")
    local imageBgBase   = projectNode:getChildByName("Image_bg_base")

    local buttonClose   = imageBgBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonFactory = imageBgBase:getChildByName("Button_factory")
    local function onGotoFactoryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._parent:addNode("Factory")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonFactory:addTouchEventListener(onGotoFactoryClick)
end

function KUIBuildActivityPosterNode:registerAllCustomEvent()

end


return KUIBuildActivityPosterNode