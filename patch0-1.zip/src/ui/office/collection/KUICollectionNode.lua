--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUICollectionNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/16   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local TANK_GRAPH_FILL_COLOR      = cc.c4f(0.9765, 0.9765, 0.7031, 0.8)
local TANK_GRAPH_ATTRIBUTE_COUNT = 6
local MAX_TANK_GRAPH_RADIUS      = 80

local PAGE_SIZE = 12
local m_tTankAttributeTextName = {
    "Text_naijiu_value",
    "Text_huoli_value",
    "Text_chuantou_value",
    "Text_sudu_value",
    "Text_huibi_value",
    "Text_qianjia_value",
}

local m_tTankAttributeInfoName = {
    "nBaseHP",
    "nBaseAttack",
    "nBasePenetrate",
    "nBaseSpeed",
    "nBaseDodge",
    "nBaseFrontArmour",
}

local m_szEquipSpecsName = {
    [ATTRIBUTE.HP]         =  "attribute.duration",
    [ATTRIBUTE.ATTACK]     =  "attribute.attack",
    [ATTRIBUTE.PENETRATE]  =  "attribute.penetrate",
    [ATTRIBUTE.SPEED]      =  "attribute.speed",
    [ATTRIBUTE.FRONTARMOUR]=  "attribute.frontArmour",
    [ATTRIBUTE.REARARMOUR] =  "attribute.rearArmour",
    [ATTRIBUTE.SCOUT]      =  "attribute.scout",
    [ATTRIBUTE.DODGE]      =  "attribute.dodge",
    [ATTRIBUTE.HIDE]       =  "attribute.hide",
    [ATTRIBUTE.NIGHTBATTLE]=  "attribute.nightBattle",
    [ATTRIBUTE.RANGE]      =  "attribute.range",
    [ATTRIBUTE.ACCURACY]   =  "attribute.rating",
    [ATTRIBUTE.CRIT]       =  "attribute.crit",
}

local m_tTankAttributeMaxLimit = {
    100,
    150,
    150,
    100,
    100,
    100,
}

local KUICollectionNode = class(
    "KUICollectionNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUICollectionNode:ctor()
    self._parent            = nil
    self._mainLayout        = nil
    self._uiPath            = nil
    self._isCardPanel       = true
    self._updateTime        = 1
    -- card
    self._cardPageInfo      = nil
    self._cardBase          = nil
    self._cardDetail        = nil
    self._cardLoadList      = {}
    self._currentCardIndex  = 0
    -- gear
    self._gearPageInfo      = nil
    self._gearBase          = nil
    self._gearDetail        = nil
    self._currentGearIndex  = 0
end

function KUICollectionNode.create(owner)
    local currentNode = KUICollectionNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_collection_card.csb"
    currentNode:init()
    
    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_bottom")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_collection_bottom"
    local delayFrame      = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    return delayFrame
end

local function playCardAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local panelBase     = mainNode:getChildByName("Image_collection_base")
    local projectNode   = panelBase:getChildByName("ProjectNode_card")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_collection_card"
    local delayFrame      = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    return delayFrame
end

local function playGearAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local panelBase     = mainNode:getChildByName("Image_collection_base")
    local projectNode   = panelBase:getChildByName("ProjectNode_gear")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_collection_gear"
    local delayFrame      = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    return delayFrame
end

local function playStoryAnimation(self, isOpen)
    local mainNode      = self._mainLayout
    local panelBase     = mainNode:getChildByName("Image_detail_base")
    local projectNode   = panelBase:getChildByName("ProjectNode_studio_theatre")

    local openEndFrame    = 40
    local closeStartFrame = 50
    local animationName   = "ani_collection_studio_button"
    local delayFrame      = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    return delayFrame
end

local function stopGearAnimationToFrame(self)
    local mainNode        = self._mainLayout
    local panelBase       = mainNode:getChildByName("Image_collection_base")
    local projectNode     = panelBase:getChildByName("ProjectNode_gear")

    local openEndFrame    = 20
    local animationPath   = KUtil.getAnimationPath("ani_collection_gear")

    projectNode:stopAllActions()
    local animationAction = cc.CSLoader:createTimeline(animationPath)
    projectNode:runAction(animationAction)
    animationAction:gotoFrameAndPause(openEndFrame)
end

local function playClosePageAnimation(self)
    if self._isCardPanel then
        return playCardAnimation(self, false)
    else
        return playGearAnimation(self, false)
    end
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        table.insert(framesList, playClosePageAnimation(self, false))
        table.insert(framesList, playStoryAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Collection", callBacks, isReturnOffice)
end

local function stopAllAnimation(self)
    local mainNode    = self._mainLayout
    local panelBase   = mainNode:getChildByName("Image_collection_base")
    local projectNode = panelBase:getChildByName("ProjectNode_card")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function hideCardPanelDetail(self)
    local mainNode          = self._mainLayout
    local panelDetailBase   = mainNode:getChildByName("Image_detail_base")
    panelDetailBase:setVisible(false)
end

local function showCardPanelPage(self, isShow)
    local mainNode    = self._mainLayout
    local panelBase   = mainNode:getChildByName("Image_collection_base")
    local projectNode = panelBase:getChildByName("ProjectNode_card")
    projectNode:setVisible(isShow)
end

local function getPageListNextInfo(self, pageInfo, currentIndex)
    assert(pageInfo, "have not create the scrollview")
    local dataList    = pageInfo.dataList
    local listSize    = #dataList
    local targetIndex = 0
    for i = currentIndex + 1, listSize do
        local itemData = dataList[i]
        if itemData.haveGet then targetIndex = i break end
    end
    if targetIndex == 0 then
        for i = 1, listSize do
            local itemData = dataList[i] 
            if itemData.haveGet then targetIndex = i break end
        end
    end
    assert(targetIndex > 0, "not target index")
    return dataList[targetIndex]
end

local function getPageListPretIndex(self, pageInfo, currentIndex)
    assert(pageInfo, "have not create the scrollview")
    local dataList    = pageInfo.dataList
    local listSize    = #dataList
    local targetIndex = 0
    for i = currentIndex - 1, 1, -1 do
        local itemData = dataList[i]
        if itemData.haveGet then targetIndex = i break end
    end
    if targetIndex == 0 then
        for i = listSize, 1, -1 do
            local itemData = dataList[i] 
            if itemData.haveGet then targetIndex = i break end
        end
    end
    assert(targetIndex > 0, "not target index")
    return dataList[targetIndex]
end

local function getDrawNodeTankAttributeGraph(self)
    local mainNode        = self._mainLayout
    local imageTankDetail = mainNode:getChildByName("Image_detail_base")
    local drawNodeGraph   = self._drawNodeTankGraph
    local nodeMiddle      = mainNode:getChildByName("node_middle")

    local positionX = nodeMiddle:getPositionX()
    local positionY = nodeMiddle:getPositionY()
    if drawNodeGraph == nil then
        drawNodeGraph = cc.DrawNode:create()
        drawNodeGraph:setName("draw_node_tank_graph")
        imageTankDetail:addChild(drawNodeGraph)
        drawNodeGraph:setPosition(positionX, positionY)
        self._drawNodeTankGraph = drawNodeGraph
    end

    return drawNodeGraph
end

local function refreshDrawNodeTankAttributeGraph(self, attributeList)
    local drawNodeGraph     = getDrawNodeTankAttributeGraph(self)
    local attributeCount    = TANK_GRAPH_ATTRIBUTE_COUNT
    local spanAngleRadians  = math.pi * 2 / attributeCount
    local startAngleRadians = 0
    local pointArray        = {}

    for i = 1, attributeCount do
        local attribValue         = attributeList[i]
        local currentAngleRadians = startAngleRadians - ( i - 1 ) * spanAngleRadians
        local attributeWiegth     = math.min(1.0, attribValue / m_tTankAttributeMaxLimit[i] )
        local attribRadius        = attributeWiegth * MAX_TANK_GRAPH_RADIUS
        local attribPointX        = attribRadius * math.sin(currentAngleRadians)
        local attribPointY        = attribRadius * math.cos(currentAngleRadians)
        table.insert(pointArray, i, cc.p(attribPointX, attribPointY))
    end
    
    table.insert(pointArray, attributeCount + 1, pointArray[1])
    drawNodeGraph:stopAllActions()
    drawNodeGraph:clear()
    
    local tranglePoint  = {}
    local centerPoint   = cc.p(0, 0)
    
    for i = 1, attributeCount do
        tranglePoint[1] = centerPoint
        tranglePoint[2] = pointArray[i]
        tranglePoint[3] = pointArray[i + 1]
        drawNodeGraph:drawSolidPoly(tranglePoint, #tranglePoint, TANK_GRAPH_FILL_COLOR)
    end
end

local function getPageListNextConvertInfo(self, pageInfo, cardConfig)
    assert(pageInfo, "have not create the scrollview")
    local nConvertTemplateID    = cardConfig.nConvertID
    if nConvertTemplateID == 0 then
        nConvertTemplateID      = cardConfig.nCardType
    end
    
    if nConvertTemplateID == cardConfig.nID then
        return
    end
    
    local dataList    = pageInfo.dataList
    local itemData    = dataList[nConvertTemplateID]
    if itemData.haveGet then 
        return itemData
    end

    if cardConfig.nCardType ~= cardConfig.nID then
        itemData = dataList[cardConfig.nCardType]
        if itemData.haveGet then 
            return itemData
        end
    end

    return
end

local function refreshCardDetailPanel(self, cardInfo)
    local mainNode          = self._mainLayout
    local panelDetailBase   = mainNode:getChildByName("Image_detail_base")
    panelDetailBase:setVisible(true)
    panelDetailBase:setLocalZOrder(10)

    local nTemplateID   = cardInfo.index
    local cardConfig    = KConfig.cardInfo[nTemplateID]
    local isShowCard    = cardInfo.haveGet and cardConfig
    assert(isShowCard, "can not show nTemplateID=:" .. nTemplateID)

    local projectCard    = panelDetailBase:getChildByName("ProjectNode_tank_card")

    local panelCharacter = projectCard:getChildByName("Panel_card_chara")
    local imageCharacter = panelCharacter:getChildByName("Image_card_chara")
    local cardHeadPath   = KUtil.getCardImagePathByConfigID(nTemplateID, false)
    imageCharacter:loadTexture(cardHeadPath)

    local panelCardMedal = projectCard:getChildByName("Panel__card_meda")
    local qualityNum = 0
    while true do
        qualityNum      = qualityNum + 1
        local imageMedal = panelCardMedal:getChildByName("Image_card_medal_" .. qualityNum)
        if not imageMedal then break end
        imageMedal:setVisible(qualityNum == cardConfig.nQuality)    
    end

    local imageChange1 = projectCard:getChildByName("Image_card_kai_1")
    imageChange1:setVisible(cardConfig.nChangeTimes == 1)

    local imageChange1 = projectCard:getChildByName("Image_card_kai_2")
    imageChange1:setVisible(cardConfig.nChangeTimes == 2)

    -- update card type
    local panelCardType = projectCard:getChildByName("Panel__card_type")
    local tankTypeNum = 0
    while true do
        tankTypeNum = tankTypeNum + 1
        local imageCardType = panelCardType:getChildByName("Image_card_type_" .. tankTypeNum)
        if not imageCardType then break end
        imageCardType:setVisible(tankTypeNum == cardConfig.nTankType)    
    end

    local textName = projectCard:getChildByName("Text_tank_name")
    textName:setString(cardConfig.szName)

    local textLevelName = projectCard:getChildByName("BitmapFontLabel_level")
    textLevelName:setVisible(false)

    local textLevel = projectCard:getChildByName("BitmapFontLabel_tank_level")
    textLevel:setVisible(false)

    local panelFriendDegree   = projectCard:getChildByName("Panel_friend_degree")
    local buttonPalyAnimation = panelFriendDegree:getChildByName("Image_play")
    local buttonMarried       = panelFriendDegree:getChildByName("Image_married")
    local buttonFriendDegree  = panelFriendDegree:getChildByName("Button_friend_degree")

    buttonPalyAnimation:setVisible(cardInfo.isMarried)
    buttonPalyAnimation:setTouchEnabled(cardInfo.isMarried)
    buttonMarried:setVisible(false)
    panelFriendDegree:setVisible(true)
    buttonFriendDegree:setVisible(false)

    -- update star
    local panelStar = projectCard:getChildByName("Panel_card_star")
    local qualityNum = 0
    while true do
        qualityNum = qualityNum + 1
        local imageStar = panelStar:getChildByName("Image_common_star_" .. qualityNum)
        if not imageStar then break end
        imageStar:setVisible(qualityNum <= cardConfig.nQuality)    
    end
   
   local imageCardBase = projectCard:getChildByName("Image_card_base")
   local backPath      = KUtil.getCardBackImagePath(nTemplateID, cardInfo.isMarried)
   imageCardBase:loadTexture(backPath)

    local scrollVeiwDescription = panelDetailBase:getChildByName("ScrollView_descrition")
    local textDescription       = scrollVeiwDescription:getChildByName("Text_descrition")
    textDescription:setVisible(false)
    local textClone = scrollVeiwDescription:getChildByName("Text_descrition_clone")
    if textClone then
        scrollVeiwDescription:removeChild(textClone)
    end

    local text                 = cardConfig.szIntroduction
    local textDescriptionClone = textDescription:clone()
    textDescriptionClone:setVisible(true)
    textDescriptionClone:setString(text)
    textDescriptionClone:setName("Text_descrition_clone")
    scrollVeiwDescription:addChild(textDescriptionClone)

    local textTankNumber = panelDetailBase:getChildByName("Text_tank_number")
    textTankNumber:setString(string.format("%03d", cardInfo.index))

    local textTankName = panelDetailBase:getChildByName("Text_tank_name")
    textTankName:setString(cardConfig.szName)

    local tankAttributeList = {}
    for i = 1, #m_tTankAttributeTextName do
        local textAttributeValue = panelDetailBase:getChildByName(m_tTankAttributeTextName[i])
        local attributeName      = m_tTankAttributeInfoName[i]
        local attributeValue     = cardConfig[attributeName]
        textAttributeValue:setString(attributeValue)
        table.insert(tankAttributeList, attributeValue)
    end
    refreshDrawNodeTankAttributeGraph(self, tankAttributeList)

    local storyNode     = panelDetailBase:getChildByName("ProjectNode_studio_theatre")
    local storyPanel    = storyNode:getChildByName("Panel_1")
    local storyGirl     = storyPanel:getChildByName("Image_girl")
    local storyDialog   = storyPanel:getChildByName("Image_dialog")
    self._canGainStory  = KUtil.checkStoryReward()
    local showTip       = self._canGainStory ~= nil
    storyGirl:setVisible(showTip)
    storyDialog:setVisible(showTip)
    playStoryAnimation(self, true)

   local function onPlayAnimation(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        local cardDataInfo      = {nTemplateID = nTemplateID}
        local hideAttribute = true
        KUtil.playMarryAnimation(cardDataInfo, hideAttribute)
   end
   buttonPalyAnimation:addTouchEventListener(onPlayAnimation)


   local buttonTankSound    = panelDetailBase:getChildByName("Button_sound")
   local function onTankSoundClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
       KSound.playEffect("click")
       KSound.playTalk(KSound.TALK.GETCARD, nTemplateID)
   end
   buttonTankSound:addTouchEventListener(onTankSoundClick)

    local buttonClose = panelDetailBase:getChildByName("Button_close_detail")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            hideCardPanelDetail(self)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonLeft = panelDetailBase:getChildByName("Button_left_detail")
    local function onLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onLeftClick~")
            KSound.playEffect("click")
            local cardInfo = getPageListPretIndex(self, self._cardPageInfo, self._currentCardIndex)
            refreshCardDetailPanel(self, cardInfo)
        end
    end
    buttonLeft:addTouchEventListener(onLeftClick)

    local buttonRight = panelDetailBase:getChildByName("Button_right_detail")
    local function onRightClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onRightClick~")
            KSound.playEffect("click")
            local cardInfo = getPageListNextInfo(self, self._cardPageInfo, self._currentCardIndex)
            refreshCardDetailPanel(self, cardInfo)
        end
    end
    buttonRight:addTouchEventListener(onRightClick)

    local panelCardBase = projectCard:getChildByName("Panel_card_chara")
    local function onImageTankDetailClick(sender, type)
       if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onImageTankDetailClick~")
        local userData  = {cardID = cardInfo.index, isMarried = cardInfo.isMarried}
        local fullViewNode = self._parent:getNode("CollectionFullScreen")
        if fullViewNode == nil then
            self._parent:addNode("CollectionFullScreen", userData)
        else
            fullViewNode:setDisplayCardID(userData)
        end
    end
    panelCardBase:addTouchEventListener(onImageTankDetailClick)

    local buttonReview  = panelDetailBase:getChildByName("Button_review")
    local convertInfo   = getPageListNextConvertInfo(self, self._cardPageInfo, cardConfig)
    buttonReview:setVisible(convertInfo ~= nil)
    if convertInfo then
        local function onReviewClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onReviewClick~")
                KSound.playEffect("click")
                refreshCardDetailPanel(self, convertInfo)
            end
        end
        buttonReview:addTouchEventListener(onReviewClick)
    end

    local buttonStory = storyPanel:getChildByName("Button_video")
    local function onStoryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onStoryClick~")
            KSound.playEffect("click")
            local openInfo = {}
            if self._canGainStory then
                local storyConfig = KConfig.story[self._canGainStory]
                if storyConfig.nCardID == nTemplateID then
                    openInfo.chapterID = storyConfig.nChapterID
                else
                    openInfo.cardID = nTemplateID
                end
            else
                openInfo.cardID = nTemplateID
            end
            self._parent:addNode("Story", openInfo)
        end
    end
    --buttonStory:addTouchEventListener(onStoryClick)
    KUtil.addTouchEventWithSysOpen(buttonStory, onStoryClick, "story")

    local stringConfig     = KConfig:getLine("string", "card.convert"..cardConfig.nChangeTimes)
    local textButton       = buttonReview:getChildByName("Text_button")
    textButton:setString(stringConfig.szText)

    self._currentCardIndex = cardInfo.index
end

local function getCardPageDataList()
    local maxID = 0
    for id, card in pairs(KConfig.cardInfo) do
        maxID = math.max(maxID, id)
    end

    local cardList = {}
    local cardMap  = {}
    for index = 1, maxID do
        local cardDetail = {index = index, haveGet = false, isMarried = false,}
        table.insert(cardList, cardDetail)
        cardMap[index] = cardDetail
    end
    -- get card data
    local haveCardList = KPlayer.tCardData.tHistoricalCardID
    for _, cardID in ipairs(haveCardList) do
        if cardMap[cardID] then 
            cardMap[cardID].haveGet = true
        end
    end
    -- check married
    local marriedIDList = KUtil.getMarriedCardIDList()
    for _, cardID in ipairs(marriedIDList) do
        if cardMap[cardID] then 
            cardMap[cardID].isMarried = true
        end
    end
    return cardList
end

local function getGearPageDataList()
    local gearMap  = {}

    for id, gear in pairs(KConfig.equipInfo) do
        if gear.bCollectable then
            table.insert(gearMap, gear)
        end
    end

    local function sortFunc(v1, v2)
        if v1.nID == v2.nID then
            return false
        else
            return v1.nID < v2.nID
        end
    end

    table.sort(gearMap, sortFunc)

    local gearList = {}
    local index = 1
    local haveGearList = KPlayer.tItemData.tHistoricalEquipID

    for _,v in pairs(gearMap) do
        local gearDetail = {index = index, id = v.nID, haveGet = false, }

        if HArray.FindFirstByValue(haveGearList, v.nID) then
            gearDetail.haveGet = true
        end

        table.insert(gearList, gearDetail)
        index = index + 1
    end
    
    return gearList
end

local function initGearInfo(self)
    if self.gearInfo ~= nil then return end

    local historicalGearList = getHistoricalGearList()
    local gearInfo           = {}
    for _, equipID in ipairs(historicalGearList) do
        gearInfo[equipID] = { id = equipID, info = nil,}
    end
    self._gearInfo = gearInfo


    if self._collectableGearList ~= nil then return end

    local configList = KConfig.equipInfo
    local gearList   = {}
    for _, equipConfig in ipairs(configList) do
        if equipConfig["bCollectable"] == true then
            table.insert(gearList, equipConfig.nID)
        end
    end
    self._collectableGearList = gearList
end

local function updateOneCard(self, cardInfo, panelCard)
    if not cardInfo then
        panelCard:setVisible(false)
        return
    end
    panelCard:setVisible(true)

    local textTankNumber = panelCard:getChildByName("Text_tank_number")
    textTankNumber:setString(string.format("%03d", cardInfo.index))
    textTankNumber:setLocalZOrder(1)

    local nTemplateID   = cardInfo.index
    local cardConfig    = KConfig.cardInfo[nTemplateID]
    local panelCardBase = panelCard:getChildByName("Panel_card_base")
    local isShowCard    = cardInfo.haveGet and cardConfig
    if not isShowCard then
        if panelCardBase then panelCardBase:setVisible(false) end
        return
    end
    
    if not panelCardBase then 
        panelCardBase = self._cardBase:clone()
        panelCard:addChild(panelCardBase)
        panelCardBase:setName("Panel_card_base")
    end
    panelCardBase:setVisible(true)
    
    local imageCardMedal = panelCardBase:getChildByName("Image_card_medal")
    local medalPath      = KUtil.getCardMedalPath(nTemplateID)
    imageCardMedal:loadTexture(medalPath)

    local imageCharaCard = panelCardBase:getChildByName("Image_card_chara")
    local card = {nTemplateID = nTemplateID, nMaxHP = cardConfig.nMaxHP, nCurrentHP = cardConfig.nMaxHP}
    local cardHeadPath   = KUtil.getScaleCardImagePath(card)
    imageCharaCard:setVisible(false)
    KUtil.asynLoadTexture(imageCharaCard, cardHeadPath)
    
    -- update backGround
    local tankRarity      = cardConfig.nQuality
    local imageBackGround = panelCardBase:getChildByName("Image_card_base_1")
    local filePath        = KUtil.getCardBaseBackGround(nTemplateID, cardInfo.isMarried)
    imageBackGround:loadTexture(filePath)

    local tankType        = cardConfig.nTankType
    local imageCardType   = panelCardBase:getChildByName("Image_card_type_1")
    local filePath        = "res/ui/ui_material/cardbase/card_type_" .. tankType .. ".png"
    imageCardType:loadTexture(filePath)

    local panelCompBase  = panelCardBase:getChildByName("Panel_comp_base_2")
    local textCardName   = panelCompBase:getChildByName("Text_tank_name")
    textCardName:setString(cardConfig.szName)

    local panelStar = panelCompBase:getChildByName("Panel_stars")
    for num = 1, KUtil.MAX_STAR do
        local imageName = "Image_stars" .. num
        local imageStar = panelStar:getChildByName(imageName)
        imageStar:setVisible(num <= tankRarity)
    end

    local buttonDetail  = panelCardBase:getChildByName("Image_card_frame_button")
    buttonDetail:setTouchEnabled(true)
    local function onCardDetailClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            refreshCardDetailPanel(self, cardInfo)
        end
    end
    buttonDetail:addTouchEventListener(onCardDetailClick)
end

local function refreshCardPage(self, pageList, onePageUI)
    local panelIndex = 0
    while true do
        panelIndex = panelIndex + 1
        local panelCard = onePageUI:getChildByName("Image_card_unit_" .. panelIndex)
        if not panelCard then break end
        local cardInfo = pageList[panelIndex]
        updateOneCard(self, cardInfo, panelCard)
    end
end

local function initCardPageView(self)
    assert(self._cardPageInfo == nil, "try to add addCardPageView again!")
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_collection_base")
    local projectListCard  = imageCommon:getChildByName("ProjectNode_card")
    local panelCardList    = projectListCard:getChildByName("Panel_collection_card")
    local pageView         = panelCardList:getChildByName("PageView_tank_list")
    local onePage          = pageView:getChildByName("Panel_1")

    local panelUnitOne     = onePage:getChildByName("Image_card_unit_1")
    local projectOneCard   = panelUnitOne:getChildByName("ProjectNode_tank_card")
    local panelOneCardBase = projectOneCard:getChildByName("Panel_card_base")

    local imageRateBase    = panelCardList:getChildByName("Image_rate_base")
    local labelRate        = imageRateBase:getChildByName("BitmapFontLabel_rate")

    local collectRate  = KUtil.getCardCollectRate()
    labelRate:setString(string.format("%.2f%%", collectRate))

    self._cardBase = panelOneCardBase
    self._cardBase:retain()
    panelUnitOne:removeChild(projectOneCard)

    local cardList = getCardPageDataList()
    local function moveCall(pageList, onePageUI)
        refreshCardPage(self, pageList, onePageUI)
    end

    local pageData = {
        pageView  = pageView,
        onePage   = onePage,
        unitBase  = panelOneCardBase,
        moveCall  = moveCall,
        dataList  = cardList,
        pageSize  = PAGE_SIZE,
        pageIndex = 1,
    } 

    self._cardPageInfo = KUtil.addDynamicPageView(pageData)
end

-- gear 
local function hideGearPanelDetail(self)
    local mainNode          = self._mainLayout
    local panelDetailBase   = mainNode:getChildByName("Image_gear_base")
    panelDetailBase:setVisible(false)
end

local function showGearPanelPage(self, isShow)
    local mainNode    = self._mainLayout
    local panelBase   = mainNode:getChildByName("Image_collection_base")
    local projectNode = panelBase:getChildByName("ProjectNode_gear")
    projectNode:setVisible(isShow)
end

local function refreshGearDetailPanel(self, gearInfo)
    local mainNode          = self._mainLayout
    local panelDetailBase   = mainNode:getChildByName("Image_gear_base")
    panelDetailBase:setVisible(true)
    panelDetailBase:setLocalZOrder(10)

    local nTemplateID     = gearInfo.id
    local equipConfig     = KConfig.equipInfo[nTemplateID]
    local projectNodeGear = panelDetailBase:getChildByName("ProjectNode_gear_card")
    
    -- update project node
    local panelGearCharacter = projectNodeGear:getChildByName("Panel_gear")
    local imageGearCharacter = panelGearCharacter:getChildByName("Image_gear")
    local gearFilePath = KUtil.getEquipImagePathByID(nTemplateID) 
    imageGearCharacter:loadTexture(gearFilePath)

    local panelGearMadal = projectNodeGear:getChildByName("Panel__gear_meda")
    local qualityNum     = 0
    while true do
        qualityNum       = qualityNum + 1
        local imageMedal = panelGearMadal:getChildByName("Image_card_medal_" .. qualityNum)
        if not imageMedal then break end
        imageMedal:setVisible(qualityNum == equipConfig.nGrade)    
    end

    local panelGearType = projectNodeGear:getChildByName("Panel_gear_type")
    panelGearType:setVisible(false)

   local imageCardBase = projectNodeGear:getChildByName("Image_card_base")
   local backPath      = KUtil.getCardBackImagePathByQuality(equipConfig.nGrade) 
   imageCardBase:loadTexture(backPath)

    local textGearName = projectNodeGear:getChildByName("Text_gear_name")
    textGearName:setString(equipConfig.szName)

    local panelGearStar = projectNodeGear:getChildByName("Panel_gear_star")
    local gradeNum = 0
    while true do
        gradeNum = gradeNum + 1
        local imageStar = panelGearStar:getChildByName("Image_star_" .. gradeNum)
        if not imageStar then break end
        imageStar:setVisible(gradeNum <= equipConfig.nGrade)    
    end

    local scrollGearDescription = panelDetailBase:getChildByName("ScrollView_descrition")
    local textGearDescription   = scrollGearDescription:getChildByName("Text_descrition")
    local tableDescription      = {}
    local gearType              = KUtil.getEquipTypeByID(nTemplateID)
    local stringTypeName        = KUtil.getStringByKey("collect.equipType" .. gearType) or " "
    table.insert(tableDescription, stringTypeName)

    if KUtil.isSkillEquip(nTemplateID) then
        local strNowProp = KUtil.getSkillDescriptionList(nTemplateID)
        strNowProp       = KUtil.skillAttributeListForamtValue(strNowProp, nTemplateID)
        for _, attribute in ipairs(strNowProp) do
            local tmpAttribute = "\n" .. attribute[1] .. (attribute[2] or "")
            table.insert(tableDescription, tmpAttribute)
        end
    else
        local gearAttribute         = KUtil.getEquipAttributeByID(nTemplateID)
        for k, attribute in ipairs(gearAttribute) do
            if attribute > 0 then
                local attributeName = KUtil.getStringByKey(m_szEquipSpecsName[k])
                local tmpAttribute = "\n" .. attributeName .. "+" .. attribute
                table.insert(tableDescription, tmpAttribute)
            end 
        end
    end

    tableDescription = table.concat(tableDescription) .. "\n" .. KUtil.getExtDescription(nTemplateID)
    textGearDescription:setString(tableDescription)

    local equipIntroduce = KUtil.getStringByKey("collect.equipIntroduce")
    local textGearDescription = panelDetailBase:getChildByName("Text_descrition")
    textGearDescription:setString(equipIntroduce)

    local shortName = KUtil.shortString(equipConfig.szName, 6)
    local textGearName = panelDetailBase:getChildByName("Text_gear_name")
    textGearName:setString(shortName)

    local textGearNumber = panelDetailBase:getChildByName("Text_gear_number")
    textGearNumber:setString(string.format("%03d", nTemplateID))

    local buttonClose = panelDetailBase:getChildByName("Button_close_gear")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            hideGearPanelDetail(self)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonLeft = panelDetailBase:getChildByName("Button_left_gear")
    local function onLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onLeftClick~")
            KSound.playEffect("click")
            local gearInfo = getPageListPretIndex(self, self._gearPageInfo, self._currentGearIndex)
            refreshGearDetailPanel(self, gearInfo)
        end
    end
    buttonLeft:addTouchEventListener(onLeftClick)

    local buttonRight = panelDetailBase:getChildByName("Button_right_gear")
    local function onRightClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onRightClick~")
            KSound.playEffect("click")
            local cardInfo = getPageListNextInfo(self, self._gearPageInfo, self._currentGearIndex)
            refreshGearDetailPanel(self, cardInfo)
        end
    end
    buttonRight:addTouchEventListener(onRightClick)

    self._currentGearIndex = gearInfo.index
end

local function updateOneGear(self, gearInfo, panelGear)
    if not gearInfo then
        panelGear:setVisible(false)
        return
    end
    panelGear:setVisible(true)

    local textTankNumber = panelGear:getChildByName("Text_tank_number")
    textTankNumber:setString(string.format("%03d", gearInfo.index))
    textTankNumber:setLocalZOrder(1)

    local nTemplateID = gearInfo.id
    local equipConfig = KConfig.equipInfo[nTemplateID]

    local panelGearBase = panelGear:getChildByName("Panel_gear_base")
    if not gearInfo.haveGet then
        if panelGearBase then panelGearBase:setVisible(false) end
        return
    end
    
    if not panelGearBase then 
        panelGearBase = self._gearBase:clone()
        panelGear:addChild(panelGearBase)
        panelGearBase:setName("Panel_gear_base")
    end
    panelGearBase:setVisible(true)

    local panelGearType  = panelGearBase:getChildByName("Panel_gear_base")
    local panelGearMedal = panelGearBase:getChildByName("Panel_card_meda")
    local gradeNum       = 0
    while true do
        gradeNum = gradeNum + 1
        local imageGearBase = panelGearType:getChildByName("Image_gear_base_" .. gradeNum)
        local imageGearMedal = panelGearMedal:getChildByName("Image_medal_" .. gradeNum)
        if not imageGearBase or not imageGearMedal then break end
        imageGearBase:setVisible(gradeNum == equipConfig.nGrade)    
        imageGearMedal:setVisible(gradeNum == equipConfig.nGrade) 
    end

    local imageGear = panelGearBase:getChildByName("Image_gear")
    local gearFilePath = KUtil.getEquipImagePathByID(nTemplateID) 
    imageGear:setVisible(false)
    KUtil.asynLoadTexture(imageGear, gearFilePath)

    local gradeNum = 0
    local panelStar = panelGearBase:getChildByName("Panel_stars")
    while true do
        gradeNum = gradeNum + 1
        local imageStar = panelStar:getChildByName("Image_star_" .. gradeNum)
        if not imageStar then break end
        imageStar:setVisible(gradeNum <= equipConfig.nGrade)
    end

    local shortName = KUtil.shortString(equipConfig.szName, 7)
    local textGearName = panelGearBase:getChildByName("Text_gear_name")
    textGearName:setString(shortName)

    local buttonDetail  = panelGearBase:getChildByName("Panel_gear_base")
    buttonDetail:setTouchEnabled(true)
    local function onGearDetailClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            refreshGearDetailPanel(self, gearInfo)
        end
    end
    buttonDetail:addTouchEventListener(onGearDetailClick)
end

local function refreshGearPage(self, gearList, oneGearUI)
    local panelIndex = 0
    while true do
        panelIndex = panelIndex + 1
        local panelGear = oneGearUI:getChildByName("Image_card_unit_" .. panelIndex)
        if not panelGear then break end
        local gearInfo = gearList[panelIndex]
        updateOneGear(self, gearInfo, panelGear)
    end
end

local function initGearPageView(self)
    assert(self._gearPageInfo == nil, "try to add initGearPageView again!")
    local layerGearNew           = cc.CSLoader:createNode("res/ui/layout_collection_gear.csb")
    local imageCollectionBaseNew = layerGearNew:getChildByName("Image_collection_base")
    local projectGear            = imageCollectionBaseNew:getChildByName("ProjectNode_gear")
    local imageGearBaseNew       = layerGearNew:getChildByName("Image_gear_base")

    local mainNode               = self._mainLayout
    local layerGearOld           = mainNode:getChildByName("Image_collection_base")

    projectGear:stopAllActions()
    projectGear:retain()
    imageCollectionBaseNew:removeChild(projectGear)
    layerGearOld:addChild(projectGear)
    projectGear:release()

    imageGearBaseNew:retain()
    layerGearNew:removeChild(imageGearBaseNew)
    mainNode:addChild(imageGearBaseNew)
    imageGearBaseNew:release()

    stopGearAnimationToFrame(self)

    local projectListGear  = layerGearOld:getChildByName("ProjectNode_gear")
    local panelGearList    = projectListGear:getChildByName("Panel_collection_gear")
    local pageView         = panelGearList:getChildByName("PageView_gear_list")
    local onePage          = pageView:getChildByName("Panel_1")

    local panelUnitOne     = onePage:getChildByName("Image_card_unit_1")
    local projectOneGear   = panelUnitOne:getChildByName("ProjectNode_gear")
    local panelOneGearBase = projectOneGear:getChildByName("Panel_gear_base")

    local imageRateBase    = panelGearList:getChildByName("Image_rate_base")
    local labelRate        = imageRateBase:getChildByName("BitmapFontLabel_rate")

    local collectRate  = KUtil.getEquipCollectRate()
    labelRate:setString(string.format("%.2f%%", collectRate))

    self._gearBase = panelOneGearBase
    self._gearBase:retain()
    panelUnitOne:removeChild(projectOneGear)

    local gearList = getGearPageDataList(self)
    local function moveCall(pageList, onePageUI)
        refreshGearPage(self, pageList, onePageUI)
    end

    local pageData = {
        pageView   = pageView,
        onePage    = onePage,
        unitBase   = panelOneGearBase,
        moveCall   = moveCall,
        dataList   = gearList,
        pageSize   = PAGE_SIZE,
        pageIndex  = 1,
    } 

    self._gearPageInfo = KUtil.addDynamicPageView(pageData)
end

local function refreshButtonStatus(self, isCard)
    local mainNode              = self._mainLayout
    local projectBottom         = mainNode:getChildByName("ProjectNode_bottom")
    local panelCollectionBottom = projectBottom:getChildByName("Panel_collection_bottom")
    local imageCollectionBase   = panelCollectionBottom:getChildByName("Image_button_base")
    local buttonGeer            = imageCollectionBase:getChildByName("Button_gear_sheet")
    local buttonCard            = imageCollectionBase:getChildByName("Button_tank_sheet")

    buttonGeer:setTouchEnabled(isCard)
    buttonCard:setTouchEnabled(not isCard)
    buttonGeer:setBrightStyle(ccui.BrightStyle.normal)
    buttonCard:setBrightStyle(ccui.BrightStyle.normal)
    if isCard then
        buttonCard:setBrightStyle(ccui.BrightStyle.highlight)
    else
        buttonGeer:setBrightStyle(ccui.BrightStyle.highlight)
    end
end

local function switchToCardPage(self)
    hideCardPanelDetail(self)
    hideGearPanelDetail(self)
    showCardPanelPage(self, true)
    showGearPanelPage(self, false)
    refreshButtonStatus(self, true)
    self._cardPageInfo.pageIndex   = 1
    self._cardPageInfo.uiPageIndex = 1
    KUtil.refreshDynamicPageView(self._cardPageInfo)
end

local function switchToGearPage(self)
    if not self._gearPageInfo then
        initGearPageView(self)
    end
    hideCardPanelDetail(self)
    hideGearPanelDetail(self)
    showCardPanelPage(self, false)
    showGearPanelPage(self, true)
    refreshButtonStatus(self, false)
    self._gearPageInfo.pageIndex   = 1
    self._gearPageInfo.uiPageIndex = 1
    KUtil.refreshDynamicPageView(self._gearPageInfo)
end

local function switchPage(self, isCard)
    if self._isCardPanel == isCard then return end
    self._isCardPanel = isCard
    if isCard then
        switchToCardPage(self)
    else
        switchToGearPage(self)
    end
end

function KUICollectionNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    hideCardPanelDetail(self)
end

function KUICollectionNode:refreshUI()
    initCardPageView(self)
    refreshButtonStatus(self, true)
end

function KUICollectionNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playBottomAnimation(self, true)
    playCardAnimation(self, true)
    playStoryAnimation(self, true)
end

function KUICollectionNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "tj_base")

    local mainNode              = self._mainLayout
    local projectBottom         = mainNode:getChildByName("ProjectNode_bottom")
    local panelCollectionBottom = projectBottom:getChildByName("Panel_collection_bottom")
    local imageCollectionBase   = panelCollectionBottom:getChildByName("Image_button_base")
    local buttonGeer            = imageCollectionBase:getChildByName("Button_gear_sheet")
    local buttonCard            = imageCollectionBase:getChildByName("Button_tank_sheet")
    local buttonStory           = imageCollectionBase:getChildByName("Button_stutio_theatre")

    local function onClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        switchPage(self, true)
    end
    buttonCard:addTouchEventListener(onClick)

    local function onClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        switchPage(self, false)
    end
    buttonGeer:addTouchEventListener(onClick)

    local function onStoryClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        self._parent:addNode("Story")
    end
    --buttonStory:addTouchEventListener(onStoryClick)
    KUtil.addTouchEventWithSysOpen(buttonStory, onStoryClick, "story")
end

function KUICollectionNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onResourceUpdate()
        cclog("----------> onEvent KUICollectionNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUICollectionNode:onCleanup()
    if self._cardBase then
        self._cardBase:release()
        self._cardBase = nil
    end
    if self._gearBase then
        self._gearBase:release()
        self._gearBase = nil
    end  
end

return KUICollectionNode
