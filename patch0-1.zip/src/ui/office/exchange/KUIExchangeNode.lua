--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExchangeNode.lua
--  Creator     : liulingli
--  Date        : 2015/11/24   15:22
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local EXCHANGE_CODE_LENGTH = 10

local KUIExchangeNode = class(
    "KUIExchangeNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExchangeNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
end

function KUIExchangeNode.create(owner)
    local currentNode   = KUIExchangeNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_package.csb"
    currentNode:init()

    return currentNode
end

local function isExchangeCodeValid(szExchangeCode)
    local len = string.len(szExchangeCode)
    if (len ~= EXCHANGE_CODE_LENGTH and len ~= 12) or not string.match(szExchangeCode, "^[%a%d]+$") then
        return false
    end
    return true
end

local function getFrameAction(self, startFrame, endedFrame)
    local duration   = (endedFrame - startFrame) / 60

    local function callAnimation()
        local mainNode = self._mainLayout
        local projectNode = mainNode:getChildByName("ProjectNode_package")
        local actionName = "ani_package"
        KUtil.playAnimation(projectNode,  actionName, startFrame, endedFrame)
    end
    
    local callAction  = cc.CallFunc:create(callAnimation)
    local frameDelay  = cc.DelayTime:create(duration)
    local frameAction = cc.Sequence:create(callAction, frameDelay)

    return frameAction, duration
end

function KUIExchangeNode:onInitUI()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_package")
    projectNode:stopAllActions()
end

function KUIExchangeNode:getEnterAction()
    local startFrame = 0
    local endedFrame = 27
    local enterAction, duration = getFrameAction(self, startFrame, endedFrame)
    return enterAction, duration
end

function KUIExchangeNode:getExitAction()
    local startFrame = 50
    local endedFrame = 65
    local exitAction, duration = getFrameAction(self, startFrame, endedFrame)
    return exitAction, duration
end

function KUIExchangeNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode   = mainNode:getChildByName("ProjectNode_package")
    -- confirm Button
    local imageBase     = projectNode:getChildByName("Image_package_base")
    local buttonConfirm = imageBase:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click") 
            local imageInput = imageBase:getChildByName("Image_input_box") 
            local textInput  = imageInput:getChildByName("TextField_1")
            local szCode     = textInput:getString()
            cclog("click onConfirmClick~ %s, %s", szCode, string.match(szCode, "^[%a%d]+$"))    
            if not isExchangeCodeValid(szCode) then
                showNoticeByID("exchange.codeError")
                return
            end      
            KUtil.setTouchEnabled(buttonConfirm, false)
            require("src/network/KC2SProtocolManager"):exchangeCode(szCode)
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    --cancel Button
    local buttonCancel  = imageBase:getChildByName("Button_cancel")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCancelClick~")    
            KSound.playEffect("click") 
            self._parent:removeNode("Exchange")
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    -- close Button
    local buttonClose = imageBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("close")
            self._parent:removeNode("Exchange")
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

function KUIExchangeNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onExchange(nReturnCode)
        cclog("onEvent ------------> onExchange")
        local mainNode      = self._mainLayout
        local projectNode   = mainNode:getChildByName("ProjectNode_package")
        local imageBase     = projectNode:getChildByName("Image_package_base")
        local buttonConfirm = imageBase:getChildByName("Button_confirm")
        local buttonCancel  = imageBase:getChildByName("Button_cancel")
        KUtil.setTouchEnabled(buttonConfirm, true)
        KUtil.setTouchEnabled(buttonCancel, true)

        if nReturnCode == EXCHANGE_CODE_RET.SUCCESS then 
            local imageInput = imageBase:getChildByName("Image_input_box") 
            local textInput  = imageInput:getChildByName("TextField_1")
            textInput:setString("")
            return 
        end
        local tTips = 
        {
            [EXCHANGE_CODE_RET.CODE_ERROR]    = "exchange.codeError", 
            [EXCHANGE_CODE_RET.CODE_USED]     = "exchange.codeUsed",
            [EXCHANGE_CODE_RET.BEEN_EXCHANGE] = "exchange.beenExchange",
            [EXCHANGE_CODE_RET.USE_MUCH]      = "exchange.useMuch",
            [EXCHANGE_CODE_RET.OVERDUE]       = "exchange.overdue",
        }
        showNoticeByID(tTips[nReturnCode])
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EXCHANGE, onExchange)
end

return KUIExchangeNode
