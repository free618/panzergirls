--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExerciseRoleDetailNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/9   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIExerciseRoleDetailNode = class(
    "KUIExerciseRoleDetailNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExerciseRoleDetailNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._battleRoleID  = 0
    self._teamIndex     = 1
    self._openTeamCount = KPlayer.tTeamData.nOpenCount
    assert(self._openTeamCount > 0)
end

function KUIExerciseRoleDetailNode.create(owner, userData)
    local currentNode = KUIExerciseRoleDetailNode.new()

    currentNode._parent       = owner
    currentNode._uiPath       = "res/ui/layout_exercise_preparation.csb"
    currentNode._battleRoleID = userData.roleID
    currentNode:init()

    return currentNode
end

local function enterPreparePanel(self)
    local teamIndex = self._teamIndex
    local roleID    = self._battleRoleID

    local userData = 
    {
        battleType = BATTLE_TYPE.EXERCISE,
        roleID     = roleID,
        teamIndex  = teamIndex,
    }
    
    local battleScene = require("src/ui/battle/KUIBattleScene").create(userData, "Exercise")
    KUtil.replaceSceneAndRemoveAllTexture(battleScene, "ExerciseRoleDetailNode")
end

local function refreshLeftTeamPanel(self)
    local mainNode      =  self._mainLayout
    local panelLeft     = mainNode:getChildByName("Image_bg_ally_base")

    local textPlayName  = panelLeft:getChildByName("Text_player_name")
    local ourTeamName   = KUtil.getStringByKey("exercise.ourTeam")
    textPlayName:setString(ourTeamName)

    local textTeamName = panelLeft:getChildByName("Text_team_name")
    local teamName     = KUtil.getTeamName(self._teamIndex)
    textTeamName:setString(teamName)

    local buttonSelect = panelLeft:getChildByName("Button_team_select")
    for teamIndex = 1, MAX_TEAM_COUNT do
        local imageTeamIndex = buttonSelect:getChildByName("Image_team_" .. teamIndex)
        imageTeamIndex:setVisible(self._teamIndex == teamIndex)
    end

    local textRoleLevel = panelLeft:getChildByName("Text_player_level")
    textRoleLevel:setString(KPlayer.level)

    local cardList = KUtil.getOneTeamCardList(self._teamIndex)
    for cardIndex = 1, MAX_TEAM_CARD_COUNT do
        local panelUnit   = panelLeft:getChildByName("Node_army_unit_" .. cardIndex)
        local card        = cardList[cardIndex] or {}
        local nTemplateID = card.nTemplateID or 0
        local cardConfig  = KConfig.cardInfo[nTemplateID]

        if cardConfig then
            panelUnit:setVisible(true) 
            local imageHead       = panelUnit:getChildByName("ProjectNode_card")
            KUtil.onlyUpdateCardHeadBase(imageHead, card)

            local textCardLevel   = panelUnit:getChildByName("Text_level_data")
            textCardLevel:setString(card.nLevel)

            local textTankName    = panelUnit:getChildByName("Text_tank_name")
            textTankName:setString(cardConfig.szName)

            local imageOil        = panelUnit:getChildByName("Image_oil_warning")
            local maxCarryOil     = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
            imageOil:setVisible(maxCarryOil > card.nCurrentOil)

            local imageAmmo       = panelUnit:getChildByName("Image_ammo_warning")
            local maxCarryAmmo    = KConfig["cardInfo"][card.nTemplateID]["nCarryAmmo"]
            imageAmmo:setVisible(maxCarryAmmo > card.nCurrentAmmo)

            local panelDamage     = panelUnit:getChildByName("Panel_common_damage")
            local imageRepairing  = panelDamage:getChildByName("Image_common_repairing")
            local isCardRepair    = KUtil.isCardRepair(card.nID)
            imageRepairing:setVisible(isCardRepair)

            local maxHp           = KUtil.getCardMaxHp(card)
            local currentHP       = card.nCurrentHP
            local cardHPPercent   = currentHP / maxHp * 100
         
            local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
            KUtil.drawCardState(nil, panelDamage, {}, stateName, cardHPPercent)
        else
            panelUnit:setVisible(false) 
        end
    end

    local panelVS      = mainNode:getChildByName("Image_vs_base")
    local textRoleName = panelVS:getChildByName("Text_vs_name_1")
    textRoleName:setString(KPlayer.name)

    local panelWinRate = mainNode:getChildByName("Image_winrate_base")
    local textWinRate  = panelWinRate:getChildByName("Text_percentage_1")

    local totalExerciseCount = KPlayer.tRecordData.tExerciseData.nExerciseCount
    local exerciseWinCount   = KPlayer.tRecordData.tExerciseData.nExerciseWinCount
    local exerciseWinRate    = 0
    if totalExerciseCount ~= 0 then
        exerciseWinRate = math.floor(exerciseWinCount * 100 / totalExerciseCount)
    end
    textWinRate:setString(exerciseWinRate .. "%")

    local rankPath  = KUtil.getRankImagePath(1)
    local imageRank = mainNode:getChildByName("Image_rank_1") 
    imageRank:loadTexture(rankPath)
end

local function refreshRightTeamPanel(self)
    local mainNode   = self._mainLayout
    local panelRight = mainNode:getChildByName("Image_bg_enemy_base")
    local roleDetail = HArray.FindFirst(KPlayer.tExerciseData.tRoleList, "nRoleID", self._battleRoleID)
    if not roleDetail then panelRight:setVisible(false) return end
    local exerciseData = roleDetail.tExercise

    local textPlayName = panelRight:getChildByName("Text_enemy_name")
    local ourTeamName  = KUtil.getStringByKey("exercise.enemyTeam")
    textPlayName:setString(ourTeamName)

    local textTeamName     = panelRight:getChildByName("Text_enemy_team_name")
    local exerciseTeamName = exerciseData.szName
    local teamName = KUtil.getStringByKey("common.team") .. self._teamIndex
    if exerciseTeamName and string.len(exerciseTeamName) > 0 then 
        teamName = exerciseTeamName
    end
    textTeamName:setString(teamName)

    local textRoleLevel =panelRight:getChildByName("Text_enemy_level")
    textRoleLevel:setString(roleDetail.nLevel)

    local cardList = exerciseData.tCardList
    for cardIndex = 1, MAX_TEAM_CARD_COUNT do
        local panelUnit   = panelRight:getChildByName("Node_enemy_unit_" .. cardIndex)
        local cardData    = cardList[cardIndex] or {}
        local nTemplateID = cardData.nTemplateID or 0
        local cardConfig  = KConfig.cardInfo[nTemplateID]

        if cardConfig then
            panelUnit:setVisible(true) 
            local imageHead       = panelUnit:getChildByName("ProjectNode_card")
            local maxHP = KUtil.getCardMaxHp(cardData)
            local card  = {["nTemplateID"] = cardData.nTemplateID, ["nSkinTemplateID"] = cardData.nSkinTemplateID,
                            ["nCurrentHP"] = maxHP, ["bRing"] = cardData.bRing, ["nMaxHP"] = maxHP}
            KUtil.onlyUpdatePlayerCardHeadBase(imageHead, card)

            local textCardLevel = panelUnit:getChildByName("Text_level_data")
            textCardLevel:setString(cardData.nLevel)

            local textTankName = panelUnit:getChildByName("Text_tank_name")
            textTankName:setString(cardConfig.szName)
        else
            panelUnit:setVisible(false) 
        end
    end

    local panelVS      = mainNode:getChildByName("Image_vs_base")
    local textRoleName = panelVS:getChildByName("Text_vs_name_2")
    textRoleName:setString(roleDetail.szName)

    local panelWinRate  = mainNode:getChildByName("Image_winrate_base")
    local textWinRate   = panelWinRate:getChildByName("Text_percentage_2")
    local winRateString = string.format("%d", exerciseData.nWinRate)
    textWinRate:setString(winRateString .. "%")

    local rankSize = KPlayer.tRankData.nCount or 1
    local rankSize = math.max(rankSize, 1)
    local percert  = roleDetail.nRank / rankSize

    local rankPath  = KUtil.getRankImagePathByPercert(percert, 1)
    local imageRank = mainNode:getChildByName("Image_rank_2") 
    imageRank:loadTexture(rankPath)
end

local function changeSelectTeam(self, selectIndex)
    local teamCount = KUtil.getTeamSize(selectIndex)
    if teamCount <= 0 then
        showNoticeByID("expedition.teamEmpty")
        return
    end

    local isTeamExpedition = KUtil.isTeamInExpedition(selectIndex)
    if isTeamExpedition then
        showNoticeByID("common.team_in_expedition")
        return
    end

    if self._teamIndex == selectIndex then return end
    self._teamIndex = selectIndex
    refreshLeftTeamPanel(self)
end

local function refreshTeamName(self)
    local mainNode  = self._mainLayout
    local panelMenu = mainNode:getChildByName("Image_menu_team")

    for teamIndex = 1, MAX_TEAM_COUNT do
        local buttonSelect = panelMenu:getChildByName("Button_team_" .. teamIndex)
        local textName     = buttonSelect:getChildByName("Text_team_name")
       textName:setString(KUtil.getTeamName(teamIndex))
    end

    -- refresh select team name
    local panelLeft    = mainNode:getChildByName("Image_bg_ally_base")
    local textTeamName = panelLeft:getChildByName("Text_team_name")
    local teamName     = KUtil.getTeamName(self._teamIndex)
    textTeamName:setString(teamName)
end

function KUIExerciseRoleDetailNode:refreshUI()
    refreshLeftTeamPanel(self)
    refreshRightTeamPanel(self)
    refreshTeamName(self)
end

function KUIExerciseRoleDetailNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local buttonControl = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("ExerciseRoleDetail")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local buttonStart = mainNode:getChildByName("Button_start")
    local function onStartClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onStartClick~")
            KSound.playEffect("click")
            local cardList = KUtil.getOneTeamCardList(self._teamIndex)
            if #cardList == 0 then
                showNoticeByID("common.empty_team")
                return
            end
            
            local isRepairCard = nil
            for key, card in ipairs(cardList) do
                if KUtil.isCardInRepairList(card.nID) then
                    isRepairCard = card 
                    break  
                end
            end
            if isRepairCard then
                local cardName = KConfig["cardInfo"][isRepairCard.nTemplateID]["szName"]
                showNoticeByID("repairecard.repairing", cardName)
                return
            end
            
            local isTeamExpedition = KUtil.isTeamInExpedition(self._teamIndex)
            if isTeamExpedition then
                showNoticeByID("common.team_in_expedition")
                return
            end
        
            enterPreparePanel(self)
        end
    end
    buttonStart:addTouchEventListener(onStartClick)

    local buttonSupply = mainNode:getChildByName("Button_quick_supply")
    local function onSupplyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSupplyClick~")
            KSound.playEffect("click")
            KUtil.supplyTeamCard(self._teamIndex)
        end
    end
    buttonSupply:addTouchEventListener(onSupplyClick)

    local buttonTeam = mainNode:getChildByName("Button_contingent_adjustment")
    local function onTeamClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onTeamClick~")
            KSound.playEffect("click")
            local userData = {teamID = self._teamIndex}
            self._parent:addNode("Team", userData)
        end
    end
    buttonTeam:addTouchEventListener(onTeamClick)

    local buttonScreen = mainNode:getChildByName("Panel_screen")
    local panelMenu    = mainNode:getChildByName("Image_menu_team")
    buttonScreen:setSwallowTouches(false)
    buttonScreen:setVisible(false)

    local function hideButtonScreen()
        buttonScreen:setVisible(false)
        if panelMenu:isVisible() then
            KUtil.showUiScale(panelMenu, false)
        end
    end
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            hideButtonScreen()
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)

    panelMenu:setVisible(false)
    for teamIndex = 1, MAX_TEAM_COUNT do
        local buttonSelect = panelMenu:getChildByName("Button_team_" .. teamIndex)
        local selectIndex  = teamIndex
        local function onSelectItemClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KUtil.showUiScale(panelMenu, false)
                changeSelectTeam(self, selectIndex)
            end
        end
        KUtil.setTouchEnabled(buttonSelect, (teamIndex <= self._openTeamCount))
        buttonSelect:addTouchEventListener(onSelectItemClick)
    end

    local panelLeft    = mainNode:getChildByName("Image_bg_ally_base")
    local buttonSelect = panelLeft:getChildByName("Button_team_select")
    local function onSelectClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local isVisible = not panelMenu:isVisible()
            KUtil.showUiScale(panelMenu, isVisible)
            buttonScreen:setVisible(isVisible)
        end
    end
    buttonSelect:addTouchEventListener(onSelectClick)
end

function KUIExerciseRoleDetailNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRefreshLeftPanel()
        cclog("onEvent ------------> KUIExerciseRoleDetailNode onRefreshLeftPanel")
        -- reset team index
        local teamCount = KUtil.getTeamSize(self._teamIndex)
        if teamCount <= 0 then self._teamIndex = 1 end
        -- refresh team list
        refreshLeftTeamPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onRefreshLeftPanel)

    local function onSupplyTeamFinish()
        showNoticeByID("supply.teamSuccess")
        refreshLeftTeamPanel(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish) 

    local function onTeamRename()
        refreshTeamName(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_TEAM_RENAME, onTeamRename) 
end

return KUIExerciseRoleDetailNode
