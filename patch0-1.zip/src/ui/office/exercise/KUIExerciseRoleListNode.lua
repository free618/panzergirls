--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExerciseRoleListNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/14   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_EXERCISE_SIZE = 5
local DELAY_SECOND      = 60
local MAX_LOAD_TIME     = 15

local KUIExerciseRoleListNode = class(
    "KUIExerciseRoleListNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExerciseRoleListNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._oldPanel      = false
    self._loadingBar    = nil
    self._beginLoadTime = 0
    self._isLoadind     = false
end

function KUIExerciseRoleListNode.create(owner, userData)
    local currentNode = KUIExerciseRoleListNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_exercise.csb"
    if userData then
        currentNode._oldPanel = userData.oldPanel
    end
    currentNode:init()

    return currentNode
end

local function playExerciseAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local panelBase   = mainNode:getChildByName("Image_common_base")
    local projectNode = panelBase:getChildByName("ProjectNode_card")

    local openEndFrame    = 35
    local closeStartFrame = 50
    local animationName   = "ani_exercise_card"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playExerciseAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "ExerciseRoleList", callBacks, isReturnOffice)
end

local function stopAllAnimation(self)
    local mainNode    = self._mainLayout
    local panelBase   = mainNode:getChildByName("Image_common_base")
    local projectNode = panelBase:getChildByName("ProjectNode_card")
    projectNode:stopAllActions()
    
    KUtil.stopCommonAnimation(self)
end

local function setLoadingVisible(self, isVisible)
    if not self._loadingBar then return end
    self._isLoadind = isVisible
    if isVisible then
        self._beginLoadTime = KUtil.getLocalTime()
    end
    self._loadingBar:setVisible(isVisible)
end

local function checkOpenDetailPanel(self, nBattleRoleID)
    if not KPlayer.tExerciseData.tRoleList then return end
    local roleData = HArray.FindFirst(KPlayer.tExerciseData.tRoleList, "nRoleID", nBattleRoleID)
    if not roleData then return end

    if roleData.tExercise then
        local userData = {roleID = nBattleRoleID,}
        self._parent:addNode("ExerciseRoleDetail", userData)
        setLoadingVisible(self, false)
    else
        setLoadingVisible(self, true)
        require("src/network/KC2SProtocolManager"):requestExerciseRoleDetail(nBattleRoleID)
    end
end

local function checkOpenPanel(self)
    if self._oldPanel then return true end

    local serverTime     = KUtil.getCurrentServerTime()
    local nextUpdateTime = KPlayer.tExerciseData.nNextTime
    if nextUpdateTime and serverTime < nextUpdateTime + DELAY_SECOND then
        return true
    end

    require("src/network/KC2SProtocolManager"):requestExerciseRoleList()
    return false
end

local function getSortListData()
    local dataList = KPlayer.tExerciseData.tRoleList or {}
    local function funSort(item1, item2)
       return item1.nRank < item2.nRank
    end
    table.sort(dataList, funSort)
    return dataList
end

local function refreshDisableArea(self)
    local mainNode          = self._mainLayout
    local panelBase         = mainNode:getChildByName("Image_common_base")
    local projectCardList   = panelBase:getChildByName("ProjectNode_card")
    local panelExerciseCard = projectCardList:getChildByName("Panel_exercise_card")
    local dataList  = getSortListData()
    for index = 1, MAX_EXERCISE_SIZE do
        local panelItemBase = panelExerciseCard:getChildByName("Node_unit_" .. index)
        local itemControl   = panelItemBase:getChildByName("Image_yx_unit_base")
        itemControl:setVisible(false)
    end
end

local function updateItemView(self, itemControl, itemData)
    if not itemData then
        itemControl:setVisible(false)
        return
    end
    local nTemplateID = itemData.nTemplateID
    local cardConfig  = KConfig.cardInfo[nTemplateID]
    if not cardConfig then
        itemControl:setVisible(false)
        return
    end
    itemControl:setVisible(true)
    -- update head
    local filePath = KUtil.getScaleImagePathByConfigID(nTemplateID, false, itemData.nSkinTemplateID)
    local panelCharacter = itemControl:getChildByName("Panel_chara")
    local imageCharacter = panelCharacter:getChildByName("Image_common_chara")
    imageCharacter:setVisible(false)
    KUtil.asynLoadTexture(imageCharacter, filePath)

    local textPlayerWord = itemControl:getChildByName("Text_player_word")
    textPlayerWord:setString(itemData.szMessage)

    local filePath        = KUtil.getCardBackGround(cardConfig.nTankType)
    local imageCommonType = itemControl:getChildByName("Image_common_type")
    imageCommonType:loadTexture(filePath)

    local buttonExercise   = itemControl:getChildByName("Button_exercise")
    local panelFightResult = itemControl:getChildByName("Panel_rank_icon")
    panelFightResult:setVisible(false)
    buttonExercise:setVisible(false)
    buttonExercise:setTouchEnabled(false)
    if itemData.nScore ~= 0 then
        panelFightResult:setVisible(true)
        for key, value in pairs(FIGHT_SCORE) do
            local imageName = FIGHT_SCORE.SS - value + 1
            imageName = "Image_yx_rank_" .. imageName
            local imageItem = panelFightResult:getChildByName(imageName)
            imageItem:setVisible(itemData.nScore == value)
        end
    else
        buttonExercise:setVisible(true)
        buttonExercise:setTouchEnabled(true)
    end

    local wordLimit = 8
    local textPlayName = itemControl:getChildByName("Text_player_name")
    textPlayName:setString(KUtil.handleChineseWidth(itemData.szName, wordLimit))

    local textLevel = itemControl:getChildByName("Text_level_data")
    textLevel:setString(itemData.nLevel)

    local rankSize = KPlayer.tRankData.nCount or 1
    local rankSize = math.max(rankSize, 1)
    local percert  = itemData.nRank / rankSize

    local rankPath  = KUtil.getRankImagePathByPercert(percert, 1)
    local imageRank = itemControl:getChildByName("Image_yxxx_rank_colonel")
    imageRank:loadTexture(rankPath)

    local imageCardBase = itemControl:getChildByName("Image_common_chara_bg")
    local backPath  = KUtil.getCardBaseBackGround(itemData.nTemplateID)
    imageCardBase:loadTexture(backPath)

    local roleID = itemData.nRoleID
    local function oneExerciseDetail(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click oneExerciseDetail~")
            KSound.playEffect("click")
            checkOpenDetailPanel(self, roleID)
        end
    end
    buttonExercise:addTouchEventListener(oneExerciseDetail)

    --update frame
    local frameButtomFormat = "Button_%s_frame_buttom"
    local countryType       = cardConfig.nCountryType
    KUtil.setCardHeadBack(itemControl, countryType, frameButtomFormat)
end

local function refreshList(self)
    local mainNode  = self._mainLayout
    local mainNode          = self._mainLayout
    local panelBase         = mainNode:getChildByName("Image_common_base")
    local projectCardList   = panelBase:getChildByName("ProjectNode_card")
    local panelExerciseCard = projectCardList:getChildByName("Panel_exercise_card")

    local dataList  = getSortListData()
    for index = 1, MAX_EXERCISE_SIZE do
        local panelItemBase = panelExerciseCard:getChildByName("Node_unit_" .. index)
        local itemControl   = panelItemBase:getChildByName("Image_yx_unit_base")
        local itemData      = dataList[index]
        updateItemView(self, itemControl, itemData)
    end
end

local function openPanel(self)
    local canRefresh = checkOpenPanel(self)
    if canRefresh then
        refreshList(self)
    end
end

function KUIExerciseRoleListNode:activate(nowTime)
    if self._isLoadind then
        if nowTime - self._beginLoadTime > MAX_LOAD_TIME then
            setLoadingVisible(self, false)
        end
    end
end

function KUIExerciseRoleListNode:InitUI()
    local mainNode   = self._mainLayout
    self._loadingBar = cc.CSLoader:createNode("res/ui/animation_node/ani_loading.csb")
    mainNode:addChild(self._loadingBar)
    self._loadingBar:setVisible(false)
end

function KUIExerciseRoleListNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
end

function KUIExerciseRoleListNode:refreshUI()
    self:InitUI()
    refreshDisableArea(self)
    openPanel(self)
end

function KUIExerciseRoleListNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playExerciseAnimation(self, true)
end

function KUIExerciseRoleListNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "yx_base")
end

function KUIExerciseRoleListNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRoleList()
        cclog("onEvent ------------> KUIExerciseRoleListNode onRoleList")
        refreshList(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EXERCISE_ROLE_LIST, onRoleList)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EXERCISE_BATTLE_FINISH, onRoleList)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIExerciseRoleListNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)

    local function onRoleDetail(nBattleRoleID, tExercise)
        cclog("onEvent ------------> KUIExerciseRoleListNode onRoleDetail")
        checkOpenDetailPanel(self, nBattleRoleID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EXERCISE_ROLE_DETAIL, onRoleDetail)
end

function KUIExerciseRoleListNode:getEnterAction()
    if not self._oldPanel then
        return require("src/ui/uibase/KUINodeBase").getEnterAction(self)
    end
end

return KUIExerciseRoleListNode
