--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExpeditionNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/28   9:20
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAP_PATH    = "res/ui/ui_material/launch_maps/"
local MAX_PAGE    = 6
local ICON_SIZE   = 4

local m_tAreaInfo = {
    [1] = {buttonName = "Button_area_slbzb",   normal = "cj_map_slbzb.png",   press = "cj_map_slbzb_active.png"},
    [2] = {buttonName = "Button_area_nbzx",    normal = "cj_map_nbzx.png",    press = "cj_map_nbzx_active.png"},
    [3] = {buttonName = "Button_area_dbzx",    normal = "cj_map_dbzx.png",    press = "cj_map_dbzx_active.png"},
    [4] = {buttonName = "Button_area_dbfg",    normal = "cj_map_dbfg.png",    press = "cj_map_dbfg_active.png"},
    [5] = {buttonName = "Button_area_xbzx",    normal = "cj_map_xbzx.png",    press = "cj_map_xbzx_active.png"},
    [6] = {buttonName = "Button_area_berlin",  normal = "cj_map_berlin.png",  press = "cj_map_berlin_active.png"},
}

local m_tStatusAction = {
    [2] = {"ani_expedition_mark.csb", "ani_expedition_mark_1.csb"},
    [3] = {"ani_expedition_mark2.csb", "ani_expedition_mark2_1.csb"},
    [4] = {"ani_expedition_mark3.csb", "ani_expedition_mark3_1.csb"},
}

local KUIExpeditionNode = class(
    "KUIExpeditionNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExpeditionNode:ctor()
    self._mainLayout          = nil
    self._parent              = nil
    self._uiPath              = nil
    self._selectType          = 1
    self._lastUpdateTime      = 0
    self._baseControl         = nil
    self._iConPosition        = {}
    self._showMapData         = {}
    self._expeditionList      = {}
end

function KUIExpeditionNode.create(owner)
    local currentNode = KUIExpeditionNode.new()

    currentNode._parent      = owner
    currentNode._uiPath      = "res/ui/layout_expedition.csb"
    local showTab = KUtil.getExpeditionFinishArea() 
    if showTab ~= 0 then currentNode._selectType = showTab end
    currentNode:init()

    return currentNode
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Expedition", callBacks, isReturnOffice)
end

local function openRewardPanel(self, tResultList, tExtraResource, szNameList, nFightCount)
    local tDesciptionList = {}
    if nFightCount > 0 then
        local white  = cc.c3b(98, 124, 146)
        local yellow = cc.c3b(255, 87, 87)
        local blue   = cc.c3b(98, 124, 146)
        local szNameList = szNameList
        local text = KUtil.getStringByKey("expedition.nameTip1")
        table.insert(tDesciptionList, {text = text, color = white})
        
        table.insert(tDesciptionList, {text = szNameList, color = yellow})

        local text = KUtil.getStringByKey("expedition.nameTip2")
        table.insert(tDesciptionList, {text = text, color = white})

        table.insert(tDesciptionList, {text = nFightCount, color = blue})

        local text = KUtil.getStringByKey("expedition.nameTip3")
        table.insert(tDesciptionList, {text = text, color = white})
    end

    local userData = {tResultList = tResultList, tExtraResource = tExtraResource, tDesciptionList = tDesciptionList}
    self._parent:addNode("ExpeditionReward", userData)
end

local function getOneBaseControl(self, nType, nTemplateID)
    local mainNode    = self._mainLayout
    local pageView    = mainNode:getChildByName("PageView_map")
    local pageControl = pageView:getChildByName("Panel_map_" .. nType)
    local baseControl = pageControl:getChildByName("Panel_architecture_" .. nTemplateID)
    return baseControl
end

local function refreshExpeditionList(self)
    self._expeditionList = {}
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList or {}
    for _, expedition in ipairs(expeditionList) do
        table.insert(self._expeditionList, expedition)
    end
end

local function removeOneFromList(self, nType, nTemplateID)
    for i, expedition in ipairs(self._expeditionList) do
        if expedition.nType == nType and expedition.nTemplateID == nTemplateID then
            table.remove(self._expeditionList, i)
            break
        end
    end
end

local function addOneToList(self, nType, nTemplateID)
    local expeditionData  = KUtil.getOneExpeditionData(nType, nTemplateID)
    if not expeditionData then return end
    removeOneFromList(self, nType, nTemplateID)
    table.insert(self._expeditionList, expeditionData)
end

local function openDetailPanel(self, nType, nTemplateID)
    local expeditionStatus = KUtil.getExpeditionStatus(nType, nTemplateID)
    if expeditionStatus == EXPEDITION_STATUS.CANGET then
        require("src/network/KC2SProtocolManager"):getExpeditionReward(nType, nTemplateID)
        return
    end
    local userData = {nTemplateID = nTemplateID, nAreaID = nType,}
    self._parent:addNode("ExpeditionChooseTeam", userData)
end

local function refreshDisableArena(self)
    local mainNode        = self._mainLayout
    local imageBase       = mainNode:getChildByName("Image_epedition_base")
    local buttonRefresh   = imageBase:getChildByName("Button_refresh")
    local buttonReturn    = imageBase:getChildByName("button_return")
    local projectTopNode  = mainNode:getChildByName("ProjectNode_top")
    buttonRefresh:setVisible(false)
    buttonReturn:setVisible(false)
    projectTopNode:setVisible(false)
end

local function updateResourceIcon(self, unitControl, expeditionConfig)
    if not expeditionConfig then return end
    local rewardID   = expeditionConfig.nRewardID
    local itemList   = {}
    local showItems  = {}
    local rewardInfo = KConfig.reward[rewardID]
    if rewardInfo then itemList = rewardInfo.tList end
    for _, item in pairs(itemList) do
        if item.nType == ITEM_TYPE.CURRENCY and item.nRate ~= 0 and item.nNum ~= 0 then
            table.insert(showItems, item)
        end
    end
    local funSort = function(item1, item2)
        return item1.nID > item2.nID
    end
    table.sort(showItems, funSort)

    local imageIcon2     = unitControl:getChildByName("Image_icon_2")
    local imageIcon3     = unitControl:getChildByName("Image_icon_3")
    local positionX2     = self._iConPosition[2].x
    local positionX3     = self._iConPosition[3].x
    local positionY      = self._iConPosition[1].y
    local itemContenSize = imageIcon2:getContentSize()
    local middleX        = (positionX2 + positionX3) /2
    local scale          = imageIcon2:getScale()
    local spanX          = itemContenSize.width * scale
    local itemSize       = #showItems
    local radix          = 0
    if itemSize % 2 == 0 then
        radix = math.floor(itemSize / 2) - 0.5
    else
        radix = math.floor(itemSize / 2)
    end
    local startX = middleX - radix * spanX + 5
     for iconIndex = 1, ICON_SIZE do
        local imageIcon = unitControl:getChildByName("Image_icon_" .. iconIndex)
        local textCount = unitControl:getChildByName("Text_resource_" .. iconIndex)
        local itemInfo = showItems[iconIndex]
        if itemInfo then
            imageIcon:setVisible(true)
            local positionX = startX + (iconIndex - 1) * spanX
            imageIcon:setPosition(positionX, positionY)
            local itemPath = KUtil.getRewardItemPathAndScale(itemInfo.nType, itemInfo.nID)
            imageIcon:loadTexture(itemPath)

            textCount:setVisible(true)
            textCount:setPosition(positionX, textCount:getPositionY())
            textCount:setString(tostring(itemInfo.nNum))
        else
            textCount:setVisible(false)
            imageIcon:setVisible(false)
        end
    end
end

local function showRedPoint(self, unitControl, isVisible)
    local imageWordBase         = unitControl:getChildByName("Image_words_base")
    local imageExpeditionNotice = imageWordBase:getChildByName("Image_expedition_notice")
    local projectRedNode        = imageWordBase:getChildByName("red_point")
    if isVisible then
        if not projectRedNode then
            local positionX = imageExpeditionNotice:getPositionX()
            local positionY = imageExpeditionNotice:getPositionY()

            local projectRedNode         = cc.CSLoader:createNode("res/ui/animation_node/ani_expedition_notice.csb")
            local actionProjectRedNode   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_expedition_notice.csb")
            projectRedNode:stopAllActions()
            projectRedNode:runAction(actionProjectRedNode)

            imageWordBase:addChild(projectRedNode, 1)
            projectRedNode:setPosition(positionX, positionY)
            projectRedNode:setName("red_point")
            local endFrame     = actionProjectRedNode:getDuration()
            actionProjectRedNode:gotoFrameAndPlay(0, endFrame, true)
        end
    else
        if projectRedNode then 
            imageWordBase:removeChild(projectRedNode)
        end
    end
end

local function showLeftTime(self, unitControl, config, status)
    local textTime       = unitControl:getChildByName("Text_time")
    textTime:setVisible(status ~= EXPEDITION_STATUS.NOTSTART)
    if status == EXPEDITION_STATUS.NOTSTART then return end

    local leftTime       = KUtil.getExpeditionLeftTime(config.nType, config.nID)
    local leftTimeString = KUtil.getLeftTime(leftTime)
    textTime:setString(leftTimeString)
end

local function showRunRole(self, unitControl, isVisible, status, teamID)
    local imageWordBase       = unitControl:getChildByName("Image_words_base")
    local imageExpeditionMark = imageWordBase:getChildByName("Image_expedition_mark")
    local projectRoleNode     = imageWordBase:getChildByName("run_role")
    if not unitControl.expeditionStatus then unitControl.expeditionStatus = 0 end
    if isVisible then

        if status ~= unitControl.expeditionStatus and projectRoleNode then
            imageWordBase:removeChild(projectRoleNode)
            projectRoleNode = nil
        end

        if not projectRoleNode then
            local positionX = imageExpeditionMark:getPositionX()
            local positionY = imageExpeditionMark:getPositionY()
            local actionPath = "res/ui/animation_node/" .. m_tStatusAction[teamID][status]
            local projectRoleNode         = cc.CSLoader:createNode(actionPath)
            local actionProjectRoleNode   = cc.CSLoader:createTimeline(actionPath)
            projectRoleNode:stopAllActions()
            projectRoleNode:runAction(actionProjectRoleNode)

            imageWordBase:addChild(projectRoleNode, 1)
            projectRoleNode:setPosition(positionX, positionY)
            projectRoleNode:setName("run_role")
            local endFrame     = actionProjectRoleNode:getDuration()
            actionProjectRoleNode:gotoFrameAndPlay(0, endFrame, true)
            unitControl.expeditionStatus = status
        end
    else
        if projectRoleNode then 
            imageWordBase:removeChild(projectRoleNode)
            unitControl.expeditionStatus = 0
        end
    end
end

local function updateExpeditionStatus(self, unitControl, config)
    if not unitControl then return end

    local imageWordBase   = unitControl:getChildByName("Image_words_base")
    local expeditionData  = KUtil.getOneExpeditionData(config.nType, config.nID)
    if not expeditionData then
        if imageWordBase then
            unitControl:removeChild(imageWordBase)
        end
        showLeftTime(self, unitControl, config, EXPEDITION_STATUS.NOTSTART)
        return
    end

    if not imageWordBase then
        imageWordBase = self._baseControl:clone()
        unitControl:addChild(imageWordBase)
        imageWordBase:setName("Image_words_base")
    end

    local imageExpeditionMark = imageWordBase:getChildByName("Image_expedition_mark")
    imageExpeditionMark:setVisible(false)

    local imageExpeditionNotice = imageWordBase:getChildByName("Image_expedition_notice")
    imageExpeditionNotice:setVisible(false)

    local textComlete      = imageWordBase:getChildByName("Text_complete")
    local teamNameList     = {"I", "II", "III", "IV"}
    local expeditionStatus = KUtil.getExpeditionStatus(config.nType, config.nID)
    local teamIDString     = teamNameList[expeditionData.nTeamID] or " "

    local description = KUtil.getStringByKey("expedition.runingStatus")
    if expeditionStatus == EXPEDITION_STATUS.CANGET then
        description = KUtil.getStringByKey("expedition.finishStatus")
        showRedPoint(self, unitControl, true)
        showRunRole(self, unitControl, true, EXPEDITION_STATUS.CANGET, expeditionData.nTeamID)
    else
        showRedPoint(self, unitControl, false)
        showRunRole(self, unitControl, true, EXPEDITION_STATUS.RUNNING, expeditionData.nTeamID)
    end
    showLeftTime(self, unitControl, config, expeditionStatus)
    description = string.format(description, teamIDString)
    textComlete:setString(description)
end

local function updateScrollItem(self, unitControl, config)
    if not config then
        unitControl:setVisible(false)
        return
    else
        unitControl:setVisible(true)
    end
    local key                = KUtil.getExpeditionTableKey(config.nType, config.nID)
    local buttonArchitecture = unitControl:getChildByName("Button_architecture")

    local isOpen = (self._showMapData[key] ~= nil)
    if not isOpen then
        KUtil.setTouchEnabled(buttonArchitecture, false)
        showLeftTime(self, unitControl, config, EXPEDITION_STATUS.NOTSTART)
        return
    end

    local expeditionType = config.nType
    local expeditionID   = config.nID
    local function onClickButton()
        KSound.playEffect("click")
        openDetailPanel(self, expeditionType, expeditionID)
    end
    KUtil.setTouchEnabled(buttonArchitecture, true)
    KUtil.setButtonTouch(buttonArchitecture, onClickButton)

    updateExpeditionStatus(self, unitControl, config)
end

local function removeStartRole(self, pageControl, key)
    local projectRoleNode = pageControl:getChildByName("start_role" .. key)
    if projectRoleNode then
        pageControl:removeChild(projectRoleNode)
    end
end

local function refreshPageView(self, isRefreshIcon)
    local mainNode = self._mainLayout
    local pageView = mainNode:getChildByName("PageView_map")
    refreshExpeditionList(self)

    self._showMapData = KUtil.getExpeditionMap()
    for nType = 1, MAX_PAGE do
        local pageControl = pageView:getChildByName("Panel_map_" .. nType)
        pageControl:getChildByName("Image_expedition_mark"):setVisible(false)
        local nTemplateID = 0
        while (true) do
            nTemplateID = nTemplateID + 1
            local baseControl = pageControl:getChildByName("Panel_architecture_" .. nTemplateID)
            if not baseControl then break end
            local config = KUtil.getExpeditionConfig(nType, nTemplateID)
            updateScrollItem(self, baseControl, config)
            local key = KUtil.getExpeditionTableKey(nType, nTemplateID)
            removeStartRole(self, pageControl, key)
            if isRefreshIcon then
                updateResourceIcon(self, baseControl, config)
            end
        end
    end
end

local function removeOneExpedition(self, nType, nTemplateID)
    local mainNode    = self._mainLayout
    local pageView    = mainNode:getChildByName("PageView_map")
    local baseControl = getOneBaseControl(self, nType, nTemplateID)
    if not baseControl then return end

    local config      = KUtil.getExpeditionConfig(nType, nTemplateID)
    removeOneFromList(self, nType, nTemplateID)
    updateExpeditionStatus(self, baseControl, config)

    local key = KUtil.getExpeditionTableKey(nType, nTemplateID)
    local pageControl = pageView:getChildByName("Panel_map_" .. nType)
    removeStartRole(self, pageControl, key)
end

local function addOneExpedition(self, nType, nTemplateID, nTeamID)
    local mainNode = self._mainLayout
    local pageView = mainNode:getChildByName("PageView_map")
    local pageControl = pageView:getChildByName("Panel_map_" .. nType)
    if not pageControl then return end
    local key = KUtil.getExpeditionTableKey(nType, nTemplateID)

    local moveFinish = function()
        local pageControl = pageView:getChildByName("Panel_map_" .. nType)
        if not pageControl then return end
        removeStartRole(self, pageControl, key)
        addOneToList(self, nType, nTemplateID)
    end
    
    local imageExpeditionMark = pageControl:getChildByName("Image_expedition_mark")
    local positionX  = imageExpeditionMark:getPositionX()
    local positionY  = imageExpeditionMark:getPositionY() - 50
    local statusInfo = m_tStatusAction[nTeamID]
    local filePath   = "res/ui/animation_node/" .. statusInfo[1]
    local projectRoleNode         = cc.CSLoader:createNode(filePath)
    local actionProjectRoleNode   = cc.CSLoader:createTimeline(filePath)
    projectRoleNode:stopAllActions()
    projectRoleNode:runAction(actionProjectRoleNode)

    pageControl:addChild(projectRoleNode, 1)
    projectRoleNode:setPosition(positionX, positionY)
    projectRoleNode:setName("start_role" .. key)
    local endFrame = actionProjectRoleNode:getDuration()
    actionProjectRoleNode:gotoFrameAndPlay(0, endFrame, true)

    local itemNode = getOneBaseControl(self, nType, nTemplateID)
    local targetPositionX = 0
    local targetPositionY = 0
    if itemNode then
        targetPositionX = itemNode:getPositionX() 
        targetPositionY = itemNode:getPositionY() - 50
    end
    local distance = math.sqrt(math.pow((targetPositionY - positionY), 2) + math.pow((targetPositionX - positionX), 2))
    local speed    = 100
    local moveTime = distance / speed
    if targetPositionX > positionX then
        projectRoleNode:setScaleX(-1)
    end
    local actionSequence = cc.Sequence:create(
        cc.MoveTo:create(moveTime, cc.p(targetPositionX, targetPositionY)),
        cc.CallFunc:create(moveFinish)
    )
    projectRoleNode:runAction(actionSequence)
end

local function refreshExpeditionStatus(self)
    for _, expedition in ipairs(self._expeditionList) do
        local unitControl = getOneBaseControl(self, expedition.nType, expedition.nTemplateID)
        local config      = KUtil.getExpeditionConfig(expedition.nType, expedition.nTemplateID)
        updateExpeditionStatus(self, unitControl, config)
    end
end

local function refreshFinishRedPoint(self)
    local mainNode       = self._mainLayout
    local imageBase      = mainNode:getChildByName("Image_epedition_base")
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    local expeditionMap  = {}
    for _, expedition in ipairs(expeditionList) do
        local expeditionStatus = KUtil.getExpeditionStatus(expedition.nType, expedition.nTemplateID)
        if expeditionStatus == EXPEDITION_STATUS.CANGET then
            expeditionMap[expedition.nType] = true
        end
    end
    
    for tType, tInfo in ipairs(m_tAreaInfo) do
        local buttonType    = tType
        local buttonTab     = imageBase:getChildByName(tInfo.buttonName)
        local projectNotice = buttonTab:getChildByName("ProjectNode_notice")
        projectNotice:setVisible(expeditionMap[tType] ~=  nil)
     end 
end

local function refreshTabSelectChange(self, buttonType)
    local mainNode = self._mainLayout
     --update bottom button
    local imageBase = mainNode:getChildByName("Image_epedition_base")
    for tType, tInfo in ipairs(m_tAreaInfo) do
        local buttonControl = imageBase:getChildByName(tInfo.buttonName)
        if tType == buttonType then
            buttonControl:loadTextures(MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.press)
        else
            buttonControl:loadTextures(MAP_PATH .. tInfo.normal, MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.normal)
        end
    end
end

local function refreshBySelectChange(self, buttonType, isDelay)
    refreshTabSelectChange(self, buttonType)
    local mainNode = self._mainLayout
    local pageView = mainNode:getChildByName("PageView_map")

    if isDelay then 
        local func = function()
            pageView:scrollToPage(buttonType - 1)
        end
        delayExecute(pageView, func, 0)
    else
        pageView:scrollToPage(buttonType - 1)
    end
end

function KUIExpeditionNode:activate(nowTime)
    if self._lastUpdateTime ~= nowTime then
        refreshExpeditionStatus(self)
        refreshFinishRedPoint(self)
    end
    self._lastUpdateTime = nowTime
end

local function initUI(self)
    local mainNode    = self._mainLayout
    local pageView    = mainNode:getChildByName("PageView_map")
    local pageControl = pageView:getChildByName("Panel_map_1")
    local unitControl = pageControl:getChildByName("Panel_architecture_1")
    for iconIndex = 1, ICON_SIZE do
        local imageIcon = unitControl:getChildByName("Image_icon_" .. iconIndex)
        local positionX = imageIcon:getPositionX()
        local positionY = imageIcon:getPositionY()
        self._iConPosition[iconIndex] = {x = positionX, y = positionY}
    end

    self._baseControl = unitControl:getChildByName("Image_words_base")
    self._baseControl:retain()
    unitControl:removeChild(self._baseControl)

    local panelPortraitBase = unitControl:getChildByName("Image_portrait_base")
    unitControl:removeChild(panelPortraitBase)

    for nType = 1, MAX_PAGE do
        local pageControl = pageView:getChildByName("Panel_map_" .. nType)
        local imageMap    = pageControl:getChildByName("Image_map")
        local mapPath     = KUtil.getExpeditionBackGround(nType)
        KUtil.asynLoadTexture(imageMap, mapPath)
    end
end

function KUIExpeditionNode:onInitUI()
    stopAllAnimation(self)
    initUI(self)
end

function KUIExpeditionNode:refreshUI()
    refreshExpeditionList(self)
    refreshDisableArena(self)
    refreshPageView(self, true)
    refreshBySelectChange(self, self._selectType, true)
end

function KUIExpeditionNode:onEnterActionFinished()
end

function KUIExpeditionNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local buttonClose     = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local imageBase = mainNode:getChildByName("Image_epedition_base")

    local buttonPlunder = imageBase:getChildByName("Button_plunder")
    local function onPlunderClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPlunderClick~")
            KSound.playEffect("click")
            self._parent:removeNode("Expedition")
            self._parent:addNode("Plunder")
        end
    end
    buttonPlunder:addTouchEventListener(onPlunderClick)

    --bottom button
    for tType, tInfo in ipairs(m_tAreaInfo) do
        local buttonType    = tType
        local buttonTab = imageBase:getChildByName(tInfo.buttonName)
        local projectNotice = buttonTab:getChildByName("ProjectNode_notice")
        projectNotice:setVisible(false)
        local function onSelectClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                cclog("click onSelectClick %d~", buttonType)
                refreshBySelectChange(self, buttonType, false)
            end
        end
        buttonTab:addTouchEventListener(onSelectClick)
     end 

    local pageView = mainNode:getChildByName("PageView_map")
    pageView:setCustomScrollThreshold(100) -- 100 pixel
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then 
            local pageViewControl = sender
            local buttonType = pageView:getCurPageIndex() + 1
            refreshTabSelectChange(self, buttonType)
        end
    end
    pageView:addEventListener(onPageViewEvent)
end

function KUIExpeditionNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onAddExpedition(nType, nTemplateID, nTeamID)
        cclog("onEvent ------------> KUIExpeditionNode onAddExpedition")
        addOneExpedition(self, nType, nTemplateID, nTeamID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ADD_EXPEDITION, onAddExpedition)

    local function onRemoveExpedition(nType, nTemplateID)
        cclog("onEvent ------------> KUIExpeditionNode onRemoveExpedition")
        removeOneExpedition(self, nType, nTemplateID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_REMOVE_EXPEDITION, onRemoveExpedition)

    local function onExpeditionReward(nTemplateID, nAreaType, tResultList, tExtraResource, szNameList, nFightCount)
        cclog("onEvent ------------> KUIExpeditionNode onExpeditionReward")
        openRewardPanel(self, tResultList, tExtraResource, szNameList, nFightCount)
        refreshPageView(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_EXPEDITION_REWARD, onExpeditionReward)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIExpeditionNode onResourceUpdate")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIExpeditionNode:onCleanup()
    self._baseControl:release() 
end

return KUIExpeditionNode
