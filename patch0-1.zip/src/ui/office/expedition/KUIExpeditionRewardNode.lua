--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIExpeditionRewardNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/29   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_ITEM_COUNT = 5
local KUIExpeditionRewardNode = class(
    "KUIExpeditionRewardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIExpeditionRewardNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._resultList     = {}
    self._extraResource  = 0
    self._desciptionList = {}
    self._callback       = nil
    self._isCovered      = false
end

function KUIExpeditionRewardNode.create(owner, userData)
    local currentNode = KUIExpeditionRewardNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_war_reward_v1.csb"
    currentNode._resultList     = userData.tResultList
    currentNode._extraResource  = userData.tExtraResource
    currentNode._desciptionList = userData.tDesciptionList
    currentNode:init()

    return currentNode
end

local function getExtraResource(self, nID, nType)
    local tExtraResource = self._extraResource
    for _, v in ipairs(tExtraResource) do
        if v.nID == nID and v.nType == nType then
            return v.nNum
        end
    end
    return 0
end

local function getRewardData(self)
    local tResultList    = self._resultList
    local tExtraResource = self._extraResource
    -- reset reward list
    if #tExtraResource > 0 then
        for _, extra in ipairs(tExtraResource) do
            local canFind = false
            for _, v in ipairs(tResultList) do
                if v.nID == extra.nID and v.nType == ITEM_TYPE.CURRENCY then
                    canFind = true
                end
            end
            if not canFind then
                local item = {nID = extra.nID, nType = ITEM_TYPE.CURRENCY, nNum = 0}
                table.insert(tResultList, item)
            end
        end
    end

    return tResultList
end

local function refreshSingleRewardIcon(self, iconUI, item)
    local clippingPanel = iconUI:getChildByName("Panel_furniture_icon")
    local clippingIcon  = clippingPanel:getChildByName("Panel_icon")
    local imageGain     = clippingIcon:getChildByName("Image_icon")

    local textGain  = iconUI:getChildByName("Text_gain")
    local textName  = iconUI:getChildByName("Text_gain_name")

    local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, item.nID)
    clippingPanel:setClippingEnabled(clipping)
    clippingIcon:setClippingEnabled(clipping)

    local scale     = scaleRatio * 1.2 
    local awardName = KUtil.getItemName(item.nType, item.nID)
    imageGain:loadTexture(filePath)
    imageGain:setScale(scale)
    textName:setString(awardName)
    local itemNumString = tostring(item.nNum)
    local extraResource = getExtraResource(self, item.nID, item.nType)
    if extraResource > 0 then
        itemNumString = itemNumString .. "+" .. extraResource
    end
    textGain:setString(itemNumString)
end

local function hideRewardPanel(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v3")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")

    panelAwardList1:setVisible(false)
    panelAwardList2:setVisible(false)
end

local function hideRewardScrollView(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v3")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")

    scrollViewGain:setVisible(false)
end

local function showRewardWithPanel(self, rewardItemList)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v3")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")
    local panelAwardList  = panelAwardList1
    local itemCount       = #rewardItemList
    local viewCount       = 0 

    if itemCount % 2 == 0 then
        panelAwardList1:setVisible(false)
        panelAwardList2:setVisible(true)
        panelAwardList = panelAwardList2
        viewCount = MAX_ITEM_COUNT - 1
    else
        panelAwardList1:setVisible(true)
        panelAwardList2:setVisible(false)
        panelAwardList = panelAwardList1
        viewCount = MAX_ITEM_COUNT
    end

    for i = 1, viewCount do
        local imageAward = panelAwardList:getChildByName("Image_award_gain_"..i)
        if i <= itemCount then
            local item = rewardItemList[i]
            imageAward:setVisible(true)
            refreshSingleRewardIcon(self, imageAward, item)
        else
            imageAward:setVisible(false)
        end
    end
end

local function showRewardWithScrollView(self, rewardItemList)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v3")
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")

    local iconUIBase     = scrollViewGain:getChildByName("Image_award_gain_1")
    local showCount      = MAX_ITEM_COUNT
    local barList        = {}
    local isCutIn        = false
    local slideView      = nil
    local isTopAlignment = false
    local isHorizontal   = true
    local scaleX         = iconUIBase:getScaleX()
    local scaleY         = iconUIBase:getScaleY()
    local barWidth       = iconUIBase:getContentSize().width * scaleX
    local barHeight      = iconUIBase:getContentSize().height * scaleY
    local offset         = iconUIBase:getAnchorPointInPoints()
    local parameters = {
        barWidth     = barWidth,
        barHeight    = barHeight,
        paddingLeft  = iconUIBase:getPositionX() - barWidth / 2,
        paddingTop   = 0,
        offsetX      = offset.x * scaleX,
        offsetY      = offset.y * scaleY,
    }

    local count = #rewardItemList
    for i = 1, count do
        local item  = rewardItemList[i]
        local barUI 
        if i <= showCount then
            barUI = scrollViewGain:getChildByName("Image_award_gain_" .. i)
        else
            barUI = iconUIBase:clone()
            barUI:setVisible(true)
            scrollViewGain:addChild(barUI)
        end

        assert(barUI)
        table.insert(barList, barUI)
        refreshSingleRewardIcon(self, barUI, item)
    end
    KUtil.showScrollViewHorizontal(scrollViewGain, barList, parameters)   
    
    scrollViewGain:setBounceEnabled(false)
    scrollViewGain:setTouchEnabled(false)
end

local function refeshReward(self)
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")
    local panelMain = projectNode:getChildByName("Panel_mission_award_v3")
   
    local tResultList         = getRewardData(self)
    local itemCount           = #tResultList
    if itemCount > MAX_ITEM_COUNT then
        hideRewardPanel(self)
        showRewardWithScrollView(self, tResultList)        
    else
        hideRewardScrollView(self)
        showRewardWithPanel(self, tResultList)
    end

    local textInformation = panelMain:getChildByName("Text_information")
    local positionX = textInformation:getPositionX()
    local positionY = textInformation:getPositionY()
    local contentSize = textInformation:getContentSize()
    textInformation:setVisible(false)
    
    local textName = panelMain:getChildByName("Text_name")
    textName:setVisible(false)

    local textNumber = panelMain:getChildByName("Text_number")
    textNumber:setVisible(false)

    local richText = ccui.RichText:create()
    richText:setContentSize(contentSize.width, contentSize.height * 2)
    richText:setPosition(positionX, positionY + 100)
    
    KUtil.setRichItemList(richText, self._desciptionList, 25)
    panelMain:addChild(richText, 10)
    richText:setScaleY(0.01)
    richText:runAction(cc.ScaleTo:create(0.5, 1, 1))
    richText:runAction(cc.MoveTo:create(0.5 , cc.p(positionX, positionY)))
end

function KUIExpeditionRewardNode:onEnterActionFinished()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_award_v3.csb")
    projectNodeTransAction:stopAllActions()
    projectNodeTransAction:runAction(actionNormalFire)
    local startFrame = 60
    local endFrame   = 420
    actionNormalFire:gotoFrameAndPlay(startFrame, endFrame, true)
    local itemCount = #self._resultList
    local showCount = MAX_ITEM_COUNT
    if itemCount > showCount then
        local projectNode     = mainNode:getChildByName("ProjectNode_mission")
        local panelMain       = projectNode:getChildByName("Panel_mission_award_v3")
        local panelAward      = panelMain:getChildByName("Panel_award_gain")
        local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")
        scrollViewGain:setTouchEnabled(true)

        local unitPerTime   = 0.8
        local duration      = (itemCount - showCount) * unitPerTime
        local scrollPercent = 100
        scrollViewGain:scrollToPercentHorizontal(scrollPercent, duration, false)
    end
end

function KUIExpeditionRewardNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    projectNodeTransAction:stopAllActions()
end

function KUIExpeditionRewardNode:getEnterAction()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")

    local function callEnterAction()
        local startFrame = 0
        local endedFrame = 60
        local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_award_v3.csb")
        projectNodeTransAction:runAction(actionNormalFire)
        actionNormalFire:gotoFrameAndPlay(startFrame, endedFrame, false)
    end

    local function playEffect()
        KSound.playEffect("gainReward")
    end
    delayExecute(mainNode, playEffect, 0.2)

    local callAction   = cc.CallFunc:create(callEnterAction)
    local actionDelay1 = cc.DelayTime:create(0.2)
    local callEffect   = cc.CallFunc:create(playEffect)
    local actionDelay2 = cc.DelayTime:create(0.8)
    local enterAction  = cc.Sequence:create(callAction, actionDelay1, callEffect, actionDelay2)
    return enterAction, 1.0
end

function KUIExpeditionRewardNode:getExitAction()
    return nil, 0
end

function KUIExpeditionRewardNode:refreshUI()
    refeshReward(self)
end

function KUIExpeditionRewardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")
    --Confirm Button
    local panelMain = projectNode:getChildByName("Panel_mission_award_v3")
    local buttonControl = panelMain:getChildByName("Button_confirm_button")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("click")
            local callback = self._callback  
            local cbParam  = self._callbackParam
            self._parent:removeNode("ExpeditionReward")
            if callback then
                if cbParam then
                    callback(unpack(cbParam, 1, table.maxn(cbParam)))
                else
                    callback()
                end
            end
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUIExpeditionRewardNode:registerAllCustomEvent()
end

function KUIExpeditionRewardNode:setCallback(callback, callbackParam)
    self._callback      = callback
    self._callbackParam = callbackParam
end

return KUIExpeditionRewardNode
