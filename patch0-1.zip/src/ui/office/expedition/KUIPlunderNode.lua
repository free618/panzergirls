--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIPlunderNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/12/28   9:20
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAP_PATH      = "res/ui/ui_material/launch_maps/"
local MAX_PAGE      = 6
local ICON_SIZE     = 4
local MAX_LOAD_TIME = 15
local m_nSelectType = 1

local m_tButtonTexture = 
{
    ["normal"]   = "res/ui/ui_material/expedition/button_refresh.png",
    ["press"]    = "res/ui/ui_material/expedition/button_refresh_active.png",
    ["disable"]  = "res/ui/ui_material/expedition/button_refresh_disable.png"
}

local m_tAreaInfo = {
    [1] = {buttonName = "Button_area_slbzb",   normal = "cj_map_slbzb.png",   press = "cj_map_slbzb_active.png"},
    [2] = {buttonName = "Button_area_nbzx",    normal = "cj_map_nbzx.png",    press = "cj_map_nbzx_active.png"},
    [3] = {buttonName = "Button_area_dbzx",    normal = "cj_map_dbzx.png",    press = "cj_map_dbzx_active.png"},
    [4] = {buttonName = "Button_area_dbfg",    normal = "cj_map_dbfg.png",    press = "cj_map_dbfg_active.png"},
    [5] = {buttonName = "Button_area_xbzx",    normal = "cj_map_xbzx.png",    press = "cj_map_xbzx_active.png"},
    [6] = {buttonName = "Button_area_berlin",  normal = "cj_map_berlin.png",  press = "cj_map_berlin_active.png"},
}

local KUIPlunderNode = class(
    "KUIPlunderNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIPlunderNode:ctor()
    self._mainLayout          = nil
    self._parent              = nil
    self._uiPath              = nil
    self._baseControl         = nil
    self._selectType          = 1
    self._lastUpdateTime      = 0
    self._iConPosition        = {}
    self._buttonCanTouch      = false
    self._loadingBar          = nil
    self._isLoadind           = false
    self._beginLoadTime       = 0
end

function KUIPlunderNode.create(owner, userData)
    local currentNode = KUIPlunderNode.new()

    currentNode._parent      = owner
    if userData then
        currentNode._oldPanel   = userData.oldPanel
        currentNode._selectType = m_nSelectType
    end
    currentNode._uiPath      = "res/ui/layout_expedition.csb"
    currentNode:init()

    return currentNode
end

local function playTopAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_expedition_top"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playTopAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Plunder", callBacks, isReturnOffice)
end

local function setLoadingVisible(self, isVisible)
    if not self._loadingBar then return end
    self._isLoadind = isVisible
    if isVisible then
        self._beginLoadTime = KUtil.getLocalTime()
    end
    self._loadingBar:setVisible(isVisible)
end

local function checkRequestPanelData(self)
    if KPlayer.tPlunderData.tRolePlunderList then
        return
    end
    setLoadingVisible(self, true)
    require("src/network/KC2SProtocolManager"):requestPlunderExpeditionList(false)
end

local function openDetailPanel(self, nBattleRoleID, nExpeditionType, nExpeditionID)
    setLoadingVisible(self, false)
    local key = KUtil.getExpeditionTableKey(nExpeditionType, nExpeditionID)
    local dataInfo = KPlayer.tPlunderData.tRolePlunderDetail[key]
    local userData = {dataInfo = dataInfo}
    self._parent:addNode("PlunderDetail", userData)
end

local function refreshDisableArena(self)
    local mainNode        = self._mainLayout
    local imageBase       = mainNode:getChildByName("Image_epedition_base")
    local buttonPlunder   = imageBase:getChildByName("Button_plunder")
    buttonPlunder:setVisible(false)
end

local function getPlunderMap()
    return KPlayer.tPlunderData.tRolePlunderList or {}
end

local function refreshButtonStatus(self, nowTime)
    local serverTime  = KUtil.getServerTime(nowTime)
    local refreshTime = KPlayer.tPlunderData.nRefreshTime or 0
    local minute = KConfig.systeminfo["refreshPlunderMinute"].tValue[1] or 0
    minute = minute * 60
    local canTouch = false
    if serverTime > refreshTime + minute then
        canTouch = true
    end

    local mainNode        = self._mainLayout
    local imageBase       = mainNode:getChildByName("Image_epedition_base")
    local buttonRefresh   = imageBase:getChildByName("Button_refresh")
    local labelTime       = buttonRefresh:getChildByName("BitmapFontLabel_time")
         
    if not canTouch then
        local szLeftTime = KUtil.getLeftTime(refreshTime + minute - serverTime)
        labelTime:setString(szLeftTime)
    end

    if self._buttonCanTouch == canTouch then
        return 
    end
    self._buttonCanTouch = canTouch

    buttonRefresh:setTouchEnabled(canTouch)
    if canTouch then
        buttonRefresh:loadTextures(m_tButtonTexture.normal, m_tButtonTexture.press, m_tButtonTexture.disable)
        labelTime:setString(KUtil.getLeftTime(0))
    else
        buttonRefresh:loadTextures(m_tButtonTexture.disable, m_tButtonTexture.disable, m_tButtonTexture.disable)
    end
end

local function refreshLeftTimes(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")
    local imagePlunderBae = projectNode:getChildByName("Image_plunder_base")
    local leftNumber      = KPlayer.tPlunderData.nLeftTimes or 0
    local textNumber      = imagePlunderBae:getChildByName("BitmapFontLabel_digital")
    textNumber:setString(tostring(leftNumber))
end

local function updateResourceIcon(self, unitControl, expeditionConfig)
    if not expeditionConfig then return end
    local rewardID   = expeditionConfig.nRewardID
    local itemList   = {}
    local showItems  = {}
    local rewardInfo = KConfig.reward[rewardID]
    if rewardInfo then itemList = rewardInfo.tList end
    for _, item in pairs(itemList) do
        if item.nType == ITEM_TYPE.CURRENCY and item.nRate ~= 0 and item.nNum ~= 0 then
            table.insert(showItems, item)
        end
    end
    local funSort = function(item1, item2)
        return item1.nID > item2.nID
    end
    table.sort(showItems, funSort)

    local key                = KUtil.getExpeditionTableKey(expeditionConfig.nType, expeditionConfig.nID)
    local showMapData        = getPlunderMap()
    local plunderData        = showMapData[key] 
    local tResource          = {}
    if plunderData then
        tResource = plunderData.tResource
    end 

    local imageIcon2     = unitControl:getChildByName("Image_icon_2")
    local imageIcon3     = unitControl:getChildByName("Image_icon_3")
    local positionX2     = self._iConPosition[2].x
    local positionX3     = self._iConPosition[3].x
    local positionY      = self._iConPosition[1].y
    local itemContenSize = imageIcon2:getContentSize()
    local middleX        = (positionX2 + positionX3) /2
    local scale          = imageIcon2:getScale()
    local spanX          = itemContenSize.width * scale
    local itemSize       = #showItems
    local radix          = 0
    if itemSize % 2 == 0 then
        radix = math.floor(itemSize / 2) - 0.5
    else
        radix = math.floor(itemSize / 2)
    end
    local startX = middleX - radix * spanX + 5
     for iconIndex = 1, ICON_SIZE do
        local imageIcon = unitControl:getChildByName("Image_icon_" .. iconIndex)
        local textCount = unitControl:getChildByName("Text_resource_" .. iconIndex)
        local itemInfo = showItems[iconIndex]
        if itemInfo then
            imageIcon:setVisible(true)
            local positionX = startX + (iconIndex - 1) * spanX
            imageIcon:setPosition(positionX, positionY)
            local itemPath = KUtil.getRewardItemPathAndScale(itemInfo.nType, itemInfo.nID)
            imageIcon:loadTexture(itemPath)

            if tResource[itemInfo.nID] then
                textCount:setVisible(true)
                textCount:setPosition(positionX, textCount:getPositionY())
                textCount:setString(tostring(tResource[itemInfo.nID] or 0))
            else
                textCount:setVisible(false)
            end
        else
            textCount:setVisible(false)
            imageIcon:setVisible(false)
        end
    end
end

local function updateScrollItem(self, unitControl, config)
   if not config then
        unitControl:setVisible(false)
        return
    else
        unitControl:setVisible(true)
    end

    local textTime = unitControl:getChildByName("Text_time")
    textTime:setVisible(false)

    local key                = KUtil.getExpeditionTableKey(config.nType, config.nID)
    local buttonArchitecture = unitControl:getChildByName("Button_architecture")
    local imagePortrait      = unitControl:getChildByName("Image_portrait_base")

    local showMapData        = getPlunderMap()
    local plunderData        = showMapData[key]
    if not plunderData then
        KUtil.setTouchEnabled(buttonArchitecture, false)
        if imagePortrait then 
            unitControl:removeChild(imagePortrait) 
        end
        return
    end

    imagePortrait = self._baseControl:clone()
    unitControl:addChild(imagePortrait)
    imagePortrait:setName("Image_portrait_base")
    imagePortrait:setVisible(true)
    local textName = imagePortrait:getChildByName("Text_name")
    textName:setString(plunderData.szName)

    if plunderData.bBattle then
        KUtil.setTouchEnabled(buttonArchitecture, false)
        return
    end

    local nBattleRoleID   = plunderData.nRoleID
    local nExpeditionType = plunderData.nExpeditionType
    local nExpeditionID   = plunderData.nExpeditionID
    local function onClickButton()
        KSound.playEffect("click")
        setLoadingVisible(self, true)
        if KPlayer.tPlunderData.tRolePlunderDetail[key] then
            openDetailPanel(self, nBattleRoleID, nExpeditionType, nExpeditionID)
        else
            require("src/network/KC2SProtocolManager"):requestExpeditionBattleData(nBattleRoleID, nExpeditionType, nExpeditionID)
        end
    end
    KUtil.setTouchEnabled(buttonArchitecture, true)
    KUtil.setButtonTouch(buttonArchitecture, onClickButton)
end

local function refreshPageView(self)
    local mainNode = self._mainLayout
    local pageView = mainNode:getChildByName("PageView_map")
    for nType = 1, MAX_PAGE do
        local pageControl = pageView:getChildByName("Panel_map_" .. nType)
        pageControl:getChildByName("Image_expedition_mark"):setVisible(false)
        local nTemplateID = 0
        while (true) do
            nTemplateID = nTemplateID + 1
            local baseControl = pageControl:getChildByName("Panel_architecture_" .. nTemplateID)
            if not baseControl then break end
            local config = KUtil.getExpeditionConfig(nType, nTemplateID)
            updateScrollItem(self, baseControl, config)
            updateResourceIcon(self, baseControl, config) 
        end
    end
end

local function refreshTabSelectChange(self, buttonType)
    local mainNode = self._mainLayout
     --update bottom button
    local imageBase = mainNode:getChildByName("Image_epedition_base")
    for tType, tInfo in ipairs(m_tAreaInfo) do
        local buttonControl = imageBase:getChildByName(tInfo.buttonName)
        if tType == buttonType then
            buttonControl:loadTextures(MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.press)
        else
            buttonControl:loadTextures(MAP_PATH .. tInfo.normal, MAP_PATH .. tInfo.press, MAP_PATH .. tInfo.normal)
        end
    end
    m_nSelectType = buttonType
end

local function refreshBySelectChange(self, buttonType, isDelay)
    refreshTabSelectChange(self, buttonType)
    local mainNode = self._mainLayout
    local pageView = mainNode:getChildByName("PageView_map")
    if isDelay then 
        local func = function()
            pageView:scrollToPage(buttonType - 1)
        end
        delayExecute(pageView, func, 0)
    else
        pageView:scrollToPage(buttonType - 1)
    end
end

function KUIPlunderNode:activate(nowTime)
    if self._isLoadind then
        if nowTime - self._beginLoadTime > MAX_LOAD_TIME then
            setLoadingVisible(self, false)
        end
    end
    if self._lastUpdateTime ~= nowTime then
        refreshButtonStatus(self, nowTime)
    end
    self._lastUpdateTime = nowTime
end

local function initUI(self)
    local mainNode    = self._mainLayout
    local pageView    = mainNode:getChildByName("PageView_map")
    local pageControl = pageView:getChildByName("Panel_map_1")
    local unitControl = pageControl:getChildByName("Panel_architecture_1")
    for iconIndex = 1, ICON_SIZE do
        local imageIcon = unitControl:getChildByName("Image_icon_" .. iconIndex)
        local positionX = imageIcon:getPositionX()
        local positionY = imageIcon:getPositionY()
        self._iConPosition[iconIndex] = {x = positionX, y = positionY}
    end

    self._baseControl = unitControl:getChildByName("Image_portrait_base")
    self._baseControl:retain()
    unitControl:removeChild(self._baseControl)

    local panelWordBase = unitControl:getChildByName("Image_words_base")
    unitControl:removeChild(panelWordBase)

    self._loadingBar = cc.CSLoader:createNode("res/ui/animation_node/ani_loading.csb")
    mainNode:addChild(self._loadingBar)
    self._loadingBar:setVisible(false)

    for nType = 1, MAX_PAGE do
        local pageControl = pageView:getChildByName("Panel_map_" .. nType)
        local imageMap    = pageControl:getChildByName("Image_map")
        local mapPath     = KUtil.getExpeditionBackGround(nType)
        KUtil.asynLoadTexture(imageMap, mapPath)
    end
end

function KUIPlunderNode:onInitUI()
    stopAllAnimation(self)
    initUI(self)
end

function KUIPlunderNode:refreshUI()
    refreshPageView(self)
    refreshDisableArena(self)
    refreshBySelectChange(self, self._selectType, true)
    refreshLeftTimes(self)
    checkRequestPanelData(self)
end

function KUIPlunderNode:onEnterActionFinished()
    playTopAnimation(self, true)
end

function KUIPlunderNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
   --Close Button
    local buttonClose     = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local imageBase = mainNode:getChildByName("Image_epedition_base")
    for tType, tInfo in ipairs(m_tAreaInfo) do
        local buttonType = tType
        local buttonTab = imageBase:getChildByName(tInfo.buttonName)
        local projectNotice = buttonTab:getChildByName("ProjectNode_notice")
        projectNotice:setVisible(false)
        local function onSelectClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                cclog("click onSelectClick %d~", buttonType)
                refreshBySelectChange(self, buttonType, false)
            end
        end
        buttonTab:addTouchEventListener(onSelectClick)
     end 

    local buttonRefresh = imageBase:getChildByName("Button_refresh")
    local function onRefreshClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click onRefreshClick")
            setLoadingVisible(self, true)
            require("src/network/KC2SProtocolManager"):requestPlunderExpeditionList(true)
        end
    end
    buttonRefresh:setTouchEnabled(false)
    buttonRefresh:loadTextures(m_tButtonTexture.disable, m_tButtonTexture.disable, m_tButtonTexture.disable)
    buttonRefresh:addTouchEventListener(onRefreshClick)

    local buttonReturn = imageBase:getChildByName("button_return")
    local function onReturnClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click onReturnClick")
            self._parent:removeNode("Plunder")
            self._parent:addNode("Expedition")
        end
    end
    buttonReturn:addTouchEventListener(onReturnClick)

    local pageView = mainNode:getChildByName("PageView_map")
    pageView:setCustomScrollThreshold(100) -- 100 pixel
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then 
            local pageViewControl = sender
            local buttonType = pageView:getCurPageIndex() + 1
            refreshTabSelectChange(self, buttonType)
        end
    end
    pageView:addEventListener(onPageViewEvent)
end

function KUIPlunderNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onPlunderList(tRolePlunderData, nRefreshTime, nLeftTimes, bIsReload)
        cclog("onEvent ------------> KUIPlunderNode onPlunderList")
        setLoadingVisible(self, false)
        refreshPageView(self)
        refreshLeftTimes(self)
        refreshButtonStatus(self, KUtil.getLocalTime())
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_PLUNDER_LIST, onPlunderList)

    local function onPlunderDetail(tExpeditionInfo, nLeftTimes)
        cclog("onEvent ------------> KUIPlunderNode onPlunderDetail")
        refreshLeftTimes(self)   
        local nExpeditionType = tExpeditionInfo.tOne.expeditiontype
        local nExpeditionID   = tExpeditionInfo.tOne.expeditionid
        local nBattleRoleID   = tExpeditionInfo.tOne.roleid
        openDetailPanel(self, nBattleRoleID, nExpeditionType, nExpeditionID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_PLUNDER_DETAIL, onPlunderDetail)

    local function onAddPlunderTime(tExpeditionInfo, nLeftTimes)
        cclog("onEvent ------------> KUIPlunderNode onAddPlunderTime")
        refreshLeftTimes(self)   
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ADD_PLUNDER_TIME, onAddPlunderTime)

    local function onPlunderBattleFinish(nResultType, nBattleRoleID, nExpeditionType, nExpeditionID, tExtraResource, nLeftTimes)
        cclog("onEvent ------------> KUIPlunderNode onPlunderBattleFinish")
        refreshLeftTimes(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_PLUNDER_BATTLE_FINISH, onPlunderBattleFinish)

    local function onErrorCode(nErrorCode)
        setLoadingVisible(self, false)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ERROR_CODE, onErrorCode)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIPlunderNode onResourceUpdate")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIPlunderNode:getEnterAction()
    if not self._oldPanel then
        return require("src/ui/uibase/KUINodeBase").getEnterAction(self)
    end
end

function KUIPlunderNode:onCleanup()
    self._baseControl:release() 
end

return KUIPlunderNode
