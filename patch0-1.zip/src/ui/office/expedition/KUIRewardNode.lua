--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRewardNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/07   15:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_ITEM_COUNT = 5
local KUIRewardNode = class(
    "KUIRewardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRewardNode:ctor()
    self._mainLayout  = nil
    self._parent      = nil
    self._uiPath      = nil
    self._resultList  = {}
    self._callback    = nil
    self._isCovered   = false
end

function KUIRewardNode.create(owner, userData)
    local currentNode = KUIRewardNode.new()

    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_get_reward.csb"
    currentNode._resultList   = userData.tResultList

    currentNode:init()

    return currentNode
end

local function refreshSingleRewardIcon(self, iconUI, item)
    local clippingPanel = iconUI:getChildByName("Panel_furniture_icon")
    local clippingIcon  = clippingPanel:getChildByName("Panel_icon")
    local imageGain     = clippingIcon:getChildByName("Image_icon")

    local textGain  = iconUI:getChildByName("Text_gain")
    local textName  = iconUI:getChildByName("Text_gain_name")

    local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, item.nID)
    clippingPanel:setClippingEnabled(clipping)
    clippingIcon:setClippingEnabled(clipping)

    local scale     = scaleRatio * 1.2 
    local awardName = KUtil.getItemName(item.nType, item.nID)
    imageGain:loadTexture(filePath)
    imageGain:setScale(scale)
    textName:setString(awardName)
    textGain:setString(tostring(item.nNum))
end

local function hideRewardPanel(self)
    local mainNode        = self._mainLayout    
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v2") 
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")

    panelAwardList1:setVisible(false)
    panelAwardList2:setVisible(false)
end

local function hideRewardScrollView(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v2") 
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")

    scrollViewGain:setVisible(false)
end

local function showRewardWithPanel(self, rewardItemList)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v2") 
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local panelAwardList1 = panelAward:getChildByName("Panel_gain_1")
    local panelAwardList2 = panelAward:getChildByName("Panel_gain_2")
    local panelAwardList  = panelAwardList1
    local itemCount       = #rewardItemList
    local viewCount       = 0 

    if itemCount % 2 == 0 then
        panelAwardList1:setVisible(false)
        panelAwardList2:setVisible(true)
        panelAwardList  = panelAwardList2
        viewCount = MAX_ITEM_COUNT - 1
    else
        panelAwardList1:setVisible(true)
        panelAwardList2:setVisible(false)
        panelAwardList  = panelAwardList1
        viewCount = MAX_ITEM_COUNT
    end

    for i = 1, viewCount do
        local imageAward = panelAwardList:getChildByName("Image_award_gain_"..i)
        if i <= itemCount then
            local item = rewardItemList[i]
            imageAward:setVisible(true)
            refreshSingleRewardIcon(self, imageAward, item)
        else
            imageAward:setVisible(false)
        end
    end
end

local function showRewardWithScrollView(self, rewardItemList)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_mission")
    local panelMain       = projectNode:getChildByName("Panel_mission_award_v2") 
    local panelAward      = panelMain:getChildByName("Panel_award_gain")
    local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")

    local iconUIBase     = scrollViewGain:getChildByName("Image_award_gain_1")
    local showCount      = MAX_ITEM_COUNT
    local barList        = {}
    local isCutIn        = false
    local slideView      = nil
    local isTopAlignment = false
    local isHorizontal   = true
    local scaleX         = iconUIBase:getScaleX()
    local scaleY         = iconUIBase:getScaleY()
    local barWidth       = iconUIBase:getContentSize().width * scaleX
    local barHeight      = iconUIBase:getContentSize().height * scaleY
    local offset         = iconUIBase:getAnchorPointInPoints()
    local parameters = {
        barWidth     = barWidth,
        barHeight    = barHeight,
        paddingLeft  = iconUIBase:getPositionX() - barWidth / 2,
        paddingTop   = 0,
        offsetX      = offset.x * scaleX,
        offsetY      = offset.y * scaleY,
    }

    local count = #rewardItemList
    for i = 1, count do
        local item  = rewardItemList[i]
        local barUI 
        if i <= showCount then
            barUI = scrollViewGain:getChildByName("Image_award_gain_" .. i)
        else
            barUI = iconUIBase:clone()
            barUI:setVisible(true)
            scrollViewGain:addChild(barUI)
        end

        assert(barUI)
        table.insert(barList, barUI)
        refreshSingleRewardIcon(self, barUI, item)
    end
    KUtil.showScrollViewHorizontal(scrollViewGain, barList, parameters)   
    
    scrollViewGain:setVisible(true)
    scrollViewGain:setBounceEnabled(false)
    scrollViewGain:setTouchEnabled(false)
end

local function refeshReward(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")
    local tResultList = self._resultList
    
    local itemCount = #tResultList
    if itemCount > MAX_ITEM_COUNT then
        hideRewardPanel(self)
        showRewardWithScrollView(self, tResultList)
    else
        hideRewardScrollView(self)
        showRewardWithPanel(self, tResultList)
    end
end

function KUIRewardNode:onEnterActionFinished()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_award_v2.csb")
    projectNodeTransAction:stopAllActions()
    projectNodeTransAction:runAction(actionNormalFire)
    local startFrame = 60
    local endFrame   = 420
    actionNormalFire:gotoFrameAndPlay(startFrame, endFrame, true)

    local itemCount = #self._resultList
    local showCount = MAX_ITEM_COUNT
    if itemCount > showCount then
        local projectNode     = mainNode:getChildByName("ProjectNode_mission")
        local panelMain       = projectNode:getChildByName("Panel_mission_award_v2") 
        local panelAward      = panelMain:getChildByName("Panel_award_gain")
        local scrollViewGain  = panelAward:getChildByName("ScrollView_gain")
        scrollViewGain:setTouchEnabled(true)

        local unitPerTime   = 0.8
        local duration      = (itemCount - showCount) * unitPerTime
        local scrollPercent = 100
        scrollViewGain:scrollToPercentHorizontal(scrollPercent, duration, false)
    end
end

function KUIRewardNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")
    projectNodeTransAction:stopAllActions()
end

function KUIRewardNode:getEnterAction()
    local mainNode = self._mainLayout
    local projectNodeTransAction = mainNode:getChildByName("ProjectNode_mission")

    local function callEnterAction()
        local startFrame = 0
        local endedFrame = 60
        local actionNormalFire      = cc.CSLoader:createTimeline("res/ui/animation_node/ani_mission_award_v2.csb")
        projectNodeTransAction:runAction(actionNormalFire)
        actionNormalFire:gotoFrameAndPlay(startFrame, endedFrame, false)
    end

    local function playEffect()
        KSound.playEffect("gainReward")
    end
    delayExecute(mainNode, playEffect, 0.2)

    local callAction   = cc.CallFunc:create(callEnterAction)
    local actionDelay1 = cc.DelayTime:create(0.2)
    local callEffect   = cc.CallFunc:create(playEffect)
    local actionDelay2 = cc.DelayTime:create(0.8)
    local enterAction  = cc.Sequence:create(callAction, actionDelay1, callEffect, actionDelay2)
    return enterAction, 1.0
end

function KUIRewardNode:getExitAction()
    return nil, 0
end

function KUIRewardNode:refreshUI()
    refeshReward(self)
end

function KUIRewardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mission")
    local panelMain   = projectNode:getChildByName("Panel_mission_award_v2")
    --Confirm Button
    local buttonControl = panelMain:getChildByName("Button_confirm_button")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("click")
            local callback = self._callback  
            local cbParam  = self._callbackParam
            self._parent:removeNode("Reward")
            if callback then
                if cbParam then
                    callback(unpack(cbParam, 1, table.maxn(cbParam)))
                else
                    callback()
                end
            end
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)
end

function KUIRewardNode:registerAllCustomEvent()
end

function KUIRewardNode:setCallback(callback, callbackParam)
    self._callback      = callback
    self._callbackParam = callbackParam
end

return KUIRewardNode
