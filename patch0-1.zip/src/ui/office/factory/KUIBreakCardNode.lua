--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBreakCardNode.lua.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/04   14:40
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_KeyList        = {"nRecycleOil", "nRecycleAmmo", "nRecycleSteel", "nRecyclePeople"}
local m_LabelName      = {"Text_oil_data", "Text_ammo_data", "Text_steel_data", "Text_spammo_data"} 
local m_BouttonTexture = 
{
    ["normal"]   = "res/ui/ui_material/break/jt_xxzb_button.png", 
    ["press"]    = "res/ui/ui_material/break/jt_xxzb_button_active.png", 
    ["disable"]  = "res/ui/ui_material/break/jt_xxzb_button.png",
}

local KUIBreakCardNode = class(
    "KUIBreakCardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIBreakCardNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._baseCardBar           = nil
    self._cardIDList            = {}
    self._isUnloadingEquipment  = false
end

function KUIBreakCardNode.create(owner)
    local currentNode   = KUIBreakCardNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_break.csb"
    currentNode:init()

    return currentNode
end

local function initCardBar(self, index, cardBar, card)
    local imageBase     = cardBar:getChildByName("Image_jt_unit_base")
    imageBase:setVisible(true)
    local buttonAdd     = cardBar:getChildByName("Button_add_button")
    buttonAdd:setVisible(false)
    
    local imageHead     = imageBase:getChildByName("Image_common_chara")
    KUtil.drawRoleHeadUi(imageHead, card)
    
    local maxExp        = KUtil.getMaxExp(card.nLevel)
    local barExpLoading = imageBase:getChildByName("LoadingBar_common_exp")
    barExpLoading:setPercent(card.nCurrentExp / maxExp * 100)
    
    local labelLevel    = imageBase:getChildByName("Text_level_data")
    labelLevel:setString(card.nLevel)
    
    local cardConfig    = KUtil.getCardConfig(card.nTemplateID)
    local labelName     = imageBase:getChildByName("Text_tank_name")
    labelName:setString(cardConfig.szName)
    
    for i = 1, KUtil.MAX_STAR do
        local imageStar = imageBase:getChildByName("Image_common_star_"..i)
        imageStar:setVisible(i <= cardConfig.nQuality)
    end
    
    local buttonDelete  = imageBase:getChildByName("Button_jt_unit_unload")
    local function onDeleteClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        table.remove(self._cardIDList, index)
        self:refreshScrollView(false)
        self:refreshResourcesNum()
    end
    buttonDelete:addTouchEventListener(onDeleteClick)
end

local function initEmptyBar(self, cardBar)
    local imageBase    = cardBar:getChildByName("Image_jt_unit_base")
    imageBase:setVisible(false)
    local buttonAdd    = cardBar:getChildByName("Button_add_button")
    buttonAdd:setVisible(true)
    
    --Add Button
    local function onAddClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        self._parent:addNode("BreakChoose", self._cardIDList)
    end
    buttonAdd:addTouchEventListener(onAddClick)
end

local function getCardBreakResources(self, card)
    local cardBreakConfig = KUtil.getCardBreakConfig(card.nTemplateID)

    local resourcesList = {}
    for i = 1, #m_KeyList do
        resourcesList[i] = cardBreakConfig[m_KeyList[i]]
    end
    
    if not self._isUnloadingEquipment then
        for _, tEquip in ipairs(card.tEquipList) do
            local tOneEquip = KUtil.getEquipById(tEquip.nEquipID)
            assert(tOneEquip)
            local tEquipBreakDownConfig = KConfig.equipBreakDownInfo[tOneEquip.nTemplateID]
            assert(tEquipBreakDownConfig)
            for i = 1, #m_KeyList do
                resourcesList[i] = resourcesList[i] + tEquipBreakDownConfig[m_KeyList[i]]
                print("equip",tOneEquip.nTemplateID,m_KeyList[i],tEquipBreakDownConfig[m_KeyList[i]])
            end
        end
    end
    return resourcesList
end

function KUIBreakCardNode:refreshScrollView(isCutIn)
    local mainNode     = self._mainLayout
    local imageControl = mainNode:getChildByName("Image_common_base")
    local imageBase    = imageControl:getChildByName("Image_jt_base")
    local scrollView   = imageBase:getChildByName("Scrollview_break_list")
    local slideControl = imageControl:getChildByName("Slider_unit_list")

    scrollView:removeAllChildren()

    local barList = {}
    for index, cardID in pairs(self._cardIDList) do
        local card = KUtil.getCardById(cardID)
        if card ~= nil then
            local bar  = self._baseCardBar:clone()
            initCardBar(self, index, bar, card)
            table.insert(barList, bar)
        end
    end

    local bar = self._baseCardBar:clone()
    initEmptyBar(self, bar)
    table.insert(barList, bar)
    KUtil.addScrollView(scrollView, barList, isCutIn, slideControl)
    
    local buttonBreak  = imageBase:getChildByName("Button_start_break")
    buttonBreak:setEnabled(#self._cardIDList > 0)
end

function KUIBreakCardNode:refreshResourcesNum()
    local resourcesList = {}
    for index, cardID in pairs(self._cardIDList) do
        local card = KUtil.getCardById(cardID)
        resourcesList = HArray.numberAdd(resourcesList , getCardBreakResources(self, card))
    end
    
    for i, name in ipairs(m_LabelName) do
        local mainNode     = self._mainLayout
        local imageControl = mainNode:getChildByName("Image_common_base")
        local imageBase    = imageControl:getChildByName("Image_jt_base")
        local label        = imageBase:getChildByName(name)
        label:setString(resourcesList[i] or 0)
    end
end

local function refreshOther(self)
    local mainNode                 = self._mainLayout
    local imageControl             = mainNode:getChildByName("Image_common_base")
    local imageBase                = imageControl:getChildByName("Image_jt_base")
    local buttonUnloadingEquipment = imageBase:getChildByName("Button_jt_xxzb_button")
    if self._isUnloadingEquipment then
        buttonUnloadingEquipment:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
    else
        buttonUnloadingEquipment:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
    end
end

local function initData(self)
    local mainNode     = self._mainLayout
    local imageControl = mainNode:getChildByName("Image_common_base")
    local imageBase    = imageControl:getChildByName("Image_jt_base")
    local scrollView   = imageBase:getChildByName("Scrollview_break_list")
    local imageCardBar = scrollView:getChildByName("Image_jt_empty")
    self._baseCardBar = imageCardBar:clone()
    self._baseCardBar:retain()
end

function KUIBreakCardNode:refreshUI()
    initData(self)
    self:refreshScrollView(true)
    self:refreshResourcesNum()
    refreshOther(self)
end

function KUIBreakCardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    
    --Home Button
    local buttonHome = mainNode:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            if self._baseCardBar then
                self._baseCardBar:release()  
                self._baseCardBar = nil
            end
            self._parent:returnOffice()
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local imageControl = mainNode:getChildByName("Image_common_base")

    --Close Button
    local buttonClose  = imageControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            if self._baseCardBar then
                self._baseCardBar:release()  
                self._baseCardBar = nil
            end
            self._parent:removeNode("Break")
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
    
    local imageBase    = imageControl:getChildByName("Image_jt_base")
    
    --Unloading equipment Button
    local buttonUnloadingEquipment = imageBase:getChildByName("Button_jt_xxzb_button")
    local function onUnloadingEquipmentClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            self._isUnloadingEquipment = not self._isUnloadingEquipment
            if self._isUnloadingEquipment then
                buttonUnloadingEquipment:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
            else
                buttonUnloadingEquipment:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
            end      
            self:refreshResourcesNum()
        end
    end
    buttonUnloadingEquipment:addTouchEventListener(onUnloadingEquipmentClick)
    
    --Start Break Button
    local buttonStart  = imageBase:getChildByName("Button_start_break")
    local function onStartBreakClick(sender, type)
        if type == ccui.TouchEventType.ended and #self._cardIDList>0 then
            KSound.playEffect("click")
            require("src/network/KC2SProtocolManager"):breakDownCardList(self._cardIDList, self._isUnloadingEquipment)
            cclog("click onStartBreakButton~")            
        end
    end
    buttonStart:addTouchEventListener(onStartBreakClick)

    local scrollControl   = imageBase:getChildByName("Scrollview_break_list")
    local slideControl    = imageControl:getChildByName("Slider_unit_list")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)

end

function KUIBreakCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onCardBreak(cardIDList)
        cclog("onEvent ------------> onCardBreak")
        self._cardIDList = HArray.arraySub(self._cardIDList, cardIDList)
        self:refreshScrollView(false)
        self:refreshResourcesNum()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CARDS_BREAK, onCardBreak)
    
    local function onChooseFinish(cardIDList)
        self._cardIDList = {}
        HArray.inserArray(self._cardIDList, cardIDList)
        self:refreshScrollView(true)
        self:refreshResourcesNum()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_BREAK_CHOOSE_FINISH, onChooseFinish)
end

return KUIBreakCardNode
