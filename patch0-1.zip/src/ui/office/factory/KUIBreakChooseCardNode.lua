--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIBreakCardNode.lua.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/04   14:40
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_SortTypeList = {"Image_sort_level", "Image_sort_star", "Image_sort_type", "Image_sort_time", "Image_sort_name"}
local m_SortNameList = {"level", "star", "type", "createTime", "name"}

local KUIBreakChooseCardNode = class(
    "KUIBreakChooseCardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local m_BouttonTexture =
{
    ["normal"]   = "res/ui/ui_material/public/common_unlock.png", 
    ["press"]    = "res/ui/ui_material/public/common_lock.png", 
    ["disable"]  = "res/ui/ui_material/public/common_unlock.png",
}

local m_BouttonUnit =
{
    ["normal"]   = "res/ui/ui_material/tank_multi_choose/xztk_unit_base.png", 
    ["press"]    = "res/ui/ui_material/tank_multi_choose/xztk_unit_base_active.png", 
    ["disable"]  = "res/ui/ui_material/tank_multi_choose/xztk_unit_base.png",
}

function KUIBreakChooseCardNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._baseCardButton        = nil
    self._baseSelectedcardText  = nil
    self._SelectedcardIDList    = {}
end

function KUIBreakChooseCardNode.create(owner, arrayCards)
    local currentNode   = KUIBreakChooseCardNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_tank_multi_choose.csb"
    assert(arrayCards ~= nil)
    HArray.inserArray(currentNode._SelectedcardIDList, arrayCards)
    currentNode:init()
    return currentNode
end

local function isRepairList(cardID)
    local repairList    = KPlayer.tCardData.tRepairingList
    local repairFlag    = false

    for _, repairCard in ipairs(repairList) do
        if repairCard.nCardID == cardID then
            repairFlag = true
            break  
        end
    end

    return repairFlag
end

local function refreshSelectedScrollView(self, isCutIn)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageControl:getChildByName("Image_xztk_base")
    local scrollView     = imageBase:getChildByName("Scrollview_chosen_list")
    scrollView:removeAllChildren()

    local barList = {}
    for _, cardID in ipairs(self._SelectedcardIDList) do
        local card       = KUtil.getCardById(cardID)
        local cardConfig = KUtil.getCardConfig(card.nTemplateID)
        local textCardName = self._baseSelectedcardText:clone()
        textCardName:setString(cardConfig.szName)
        table.insert(barList, textCardName)
    end
    KUtil.addScrollView(scrollView, barList, isCutIn, nil, true)

    local selectedCount = #self._SelectedcardIDList
    local buttonCleanup = imageBase:getChildByName("Button_cleanup")
    buttonCleanup:setEnabled(selectedCount>0)

    local buttonConfirm = imageBase:getChildByName("Button_confirm")
    buttonConfirm:setEnabled(selectedCount>0)
end

local function setLockButton(button, isLock)
    if isLock then
        button:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
    else
        button:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
    end
    button.isLock = isLock
end

local function initCardBoutton(self, boutton, card)
    boutton:setName(tostring(card.nID))
    local imageHead     = boutton:getChildByName("Image_common_chara")
    KUtil.drawRoleHeadUi(imageHead, card)

    local maxExp = KUtil.getMaxExp(card.nLevel)
    local barExpLoading = boutton:getChildByName("LoadingBar_common_exp")
    barExpLoading:setPercent(card.nCurrentExp / maxExp * 100)

    local labelLevel    = boutton:getChildByName("Text_level_data")
    labelLevel:setString(card.nLevel)

    local cardConfig    = KUtil.getCardConfig(card.nTemplateID)
    local labelName     = boutton:getChildByName("Text_tank_name")
    labelName:setString(cardConfig.szName)
    
    for i = 1, KUtil.MAX_STAR do
        local imageStar = boutton:getChildByName("Image_common_star_"..i)
        imageStar:setVisible(i <= cardConfig.nQuality)
    end
    
    for i = 1, MAX_TEAM_COUNT do
        local imageTeam  = boutton:getChildByName("Image_common_team_"..i)
        imageTeam:setVisible(i == KUtil.getEnterTeamId(card.nID))
    end
    
    local imageShadow  = boutton:getChildByName("Image_xztk_unit_shadow")
    imageShadow:setVisible(false)

    local buttonLock  = boutton:getChildByName("Button_lock")
    setLockButton(buttonLock, card.bLock)
    buttonLock:setEnabled(false)
    
    assert(self._SelectedcardIDList)
    if HArray.FindFirstByValue(self._SelectedcardIDList, card.nID) then
        boutton.isSelected = true
        boutton:loadTextures(m_BouttonUnit["press"], m_BouttonUnit["normal"], m_BouttonUnit["disable"])
    else
        boutton.isSelected = false
        boutton:loadTextures(m_BouttonUnit["normal"], m_BouttonUnit["press"], m_BouttonUnit["disable"])
    end
    
    local function onSelectClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if card.bLock or KUtil.getEnterTeamId(card.nID)~=0 then return end
        KSound.playEffect("click")
        boutton.isSelected = not boutton.isSelected
        if boutton.isSelected then
            boutton:loadTextures(m_BouttonUnit["press"], m_BouttonUnit["normal"], m_BouttonUnit["disable"])
            local isInsert = true
            for i, _cardID in ipairs(self._SelectedcardIDList) do
                if _cardID == card.nID then
                    isInsert = false
                end
            end
            
            if isInsert then
                table.insert(self._SelectedcardIDList, card.nID)
            end
        else
            boutton:loadTextures(m_BouttonUnit["normal"], m_BouttonUnit["press"], m_BouttonUnit["disable"])
            for i, _cardID in ipairs(self._SelectedcardIDList) do
                if _cardID == card.nID then
                    table.remove(self._SelectedcardIDList, i)
                end
            end
        end
        refreshSelectedScrollView(self, false)
    end
    boutton:addTouchEventListener(onSelectClick)
end

local function getSortCardTable(sortType)
    local cardTable = {}
    for _, card in ipairs(KUtil.getCardList()) do
        if KUtil.getEnterTeamId(card.nID)==0 and not card.bLock then
            local cardConfig = KUtil.getCardConfig(card.nTemplateID)
            local cardSort = {}
            local key = card.nLevel
            if m_SortNameList[sortType]     == "star"       then
                key = cardConfig.nQuality
            elseif m_SortNameList[sortType] == "type"       then
                key = cardConfig.nTankType
            elseif m_SortNameList[sortType] == "createTime" then
                key = card.nCreateTime
            elseif m_SortNameList[sortType] == "name"       then
                key = cardConfig.szName
            end
            cardSort["sort"] = key
            cardSort["card"] = card
            table.insert(cardTable, cardSort)
        end
    end
    table.sort( cardTable,  
        function(i1, i2)
            if i1["sort"] < i2["sort"] then  return true end
            return false 
        end )
    return cardTable
end

local function refreshScrollView(self, sortType, isCutIn)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageControl:getChildByName("Image_xztk_base")
    local scrollView     = imageBase:getChildByName("Scrollview_tank_list")
    local slideControl   = imageControl:getChildByName("Slider_scroll")
    scrollView:removeAllChildren()
    
    local cardTable = getSortCardTable(sortType)
    local barList = {}
    for _, cardSort in pairs(cardTable) do
        if not isRepairList(cardSort["card"].nID) then
            local boutton = self._baseCardButton:clone()
            initCardBoutton(self, boutton, cardSort["card"])
            table.insert(barList, boutton)
        end
    end
    KUtil.addScrollView(scrollView, barList, isCutIn, slideControl)
end

local function refreshOther(self)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageControl:getChildByName("Image_xztk_base")
    local labelCardCount = imageBase:getChildByName("Text_contant_value")
    labelCardCount:setString("".. KUtil.getCardCount() .. "/" .. KUtil.getCardStoreSize())
    
    --Sort Button 
    local mainNode     = self._mainLayout
    local imageControl = mainNode:getChildByName("Image_common_base")
    local imageBase    = imageControl:getChildByName("Image_xztk_base")
    local buttonSort   = imageBase:getChildByName("Button_common_sort")
    for i = 1, #m_SortTypeList do
        local imageSort = buttonSort:getChildByName(m_SortTypeList[i])
        imageSort:setVisible(i==1)
    end
end

local function refreshCardList(self, sortType, isCutIn)
    refreshScrollView(self, sortType, isCutIn)
end

local function initData(self)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageControl:getChildByName("Image_xztk_base")
    local scrollViewList = imageBase:getChildByName("Scrollview_tank_list")
    local buttonCardInfo = scrollViewList:getChildByName("Button_unit")
    self._baseCardButton = buttonCardInfo:clone()
    self._baseCardButton:retain()

    local scrollViewList = imageBase:getChildByName("Scrollview_chosen_list")
    local textCardName   = scrollViewList:getChildByName("Text_chosen_tank")
    self._baseSelectedcardText = textCardName:clone()
    self._baseSelectedcardText:retain()
end

function KUIBreakChooseCardNode:refreshUI()
    initData(self)
    refreshCardList(self, nil, true)
    refreshSelectedScrollView(self, true)
    refreshOther(self)
end

function KUIBreakChooseCardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    --Home Button
    local buttonHome = mainNode:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")
            if self._baseCardButton then
                self._baseCardButton:release()  
                self._baseCardButton = nil
            end
            if self._baseSelectedcardText then
                self._baseSelectedcardText:release()  
                self._baseSelectedcardText = nil
            end
            self._parent:returnOffice()
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local imageControl = mainNode:getChildByName("Image_common_base")

    --Close Button
    local buttonClose = imageControl:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            if self._baseCardButton then
                self._baseCardButton:release()  
                self._baseCardButton = nil
            end
            if self._baseSelectedcardText then
                self._baseSelectedcardText:release()  
                self._baseSelectedcardText = nil
            end
            self._parent:removeNode("BreakChoose")
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
    
    local imageBase     = imageControl:getChildByName("Image_xztk_base")
    local buttonConfirm = imageBase:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmButton~")
            KSound.playEffect("click")
            local eventCenter = require("src/logic/KEventDispatchCenter")
            eventCenter:dispatchEvent(eventCenter.EventType.UI_BREAK_CHOOSE_FINISH, self._SelectedcardIDList)
             
            self._parent:removeNode("BreakChoose")
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)
    
    local buttonClean = imageBase:getChildByName("Button_cleanup")
    local function onCleanClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            for _, cardID in pairs(self._SelectedcardIDList) do
                local mainNode       = self._mainLayout
                local imageControl   = mainNode:getChildByName("Image_common_base")
                local imageBase      = imageControl:getChildByName("Image_xztk_base")
                local scrollView     = imageBase:getChildByName("Scrollview_tank_list")
                local buttonCardInfo = scrollView:getChildByName(tostring(cardID))
                buttonCardInfo:loadTextures(m_BouttonUnit["normal"], m_BouttonUnit["press"], m_BouttonUnit["disable"])
                buttonCardInfo.isSelected = false
            end
            self._SelectedcardIDList = {}
            refreshSelectedScrollView(self, true)
            cclog("onCleanUpClick button~")
        end
    end
    buttonClean:addTouchEventListener(onCleanClick)
    
    local buttonSort = imageBase:getChildByName("Button_common_sort")
    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            buttonSort.sortType = buttonSort.sortType or 1
            local imageSort = buttonSort:getChildByName(m_SortTypeList[buttonSort.sortType])
            imageSort:setVisible(false)
            buttonSort.sortType = buttonSort.sortType + 1
            if buttonSort.sortType > #m_SortTypeList then
                buttonSort.sortType = 1
            end
            imageSort = buttonSort:getChildByName(m_SortTypeList[buttonSort.sortType])
            imageSort:setVisible(true)
            
            refreshCardList(self, buttonSort.sortType, true)
        end
    end
    buttonSort:addTouchEventListener(onSortClick)

    local scrollControl  = imageBase:getChildByName("Scrollview_tank_list")
    local slideControl   = imageControl:getChildByName("Slider_scroll")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)
end

function KUIBreakChooseCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onCardLock(cardID, isLock)
        local mainNode       = self._mainLayout
        local imageControl   = mainNode:getChildByName("Image_common_base")
        local imageBase      = imageControl:getChildByName("Image_xztk_base")
        local scrollView     = imageBase:getChildByName("Scrollview_tank_list")
        local buttonCardInfo = scrollView:getChildByName(tostring(cardID))
        
        local buttonLock     = buttonCardInfo:getChildByName("Button_lock")
        setLockButton(buttonLock, isLock)
        
        buttonCardInfo.isSelected = false
        buttonCardInfo:loadTextures(m_BouttonUnit["normal"], m_BouttonUnit["press"], m_BouttonUnit["disable"])
        
        local id = HArray.RemoveFirstByValue(self._SelectedcardIDList, cardID)
        if id ~= nil then
            refreshSelectedScrollView(self, false)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CARD_LOCK, onCardLock)
end

return KUIBreakChooseCardNode
