--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryAbandonNode.lua
--  Creator     : HuangYiXin
--  Date        : 2015/08/01   11:00
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local GEAR_MAX_LEVEL = 6
local ACTION_SCROLL_ITEM_EFFECT_DURATION = 0.3

local m_tRecycleItemName = {
    [1] = "oil",
    [2] = "ammo",
    [3] = "steel",
    [4] = "spammo"
}

local m_tItemBreakDownInfoName = {        
    [1] = "nRecycleOil",
    [2] = "nRecycleAmmo",
    [3] = "nRecycleSteel",
    [4] = "nRecyclePeople"
}

local KUIFactoryAbandonNode = class("KUIFactoryAbandonNode")

function KUIFactoryAbandonNode:ctor(owner, node)
    self._mainLayout            = node
    self._parent                = owner
    self._originScrollHeight    = nil
    self._imageEquipUnitBase    = nil
    self._chosenEquipIDList     = {}
    self._waiting               = false
    self._animationList         = {}
    self:initData()
    self:refreshUI()
end

function KUIFactoryAbandonNode:calculateRecycleItemCount()
    local recycleItemCount = {} 
    local equipBreakDownInfo = KConfig.equipBreakDownInfo
    for _, equipID in pairs(self._chosenEquipIDList) do
        local oneEquip = HArray.FindFirstByID(KPlayer.tItemData.tEquipStoreHouse.tEquipList, equipID) 
        for i, szName in pairs(m_tItemBreakDownInfoName) do
            recycleItemCount[i] = (recycleItemCount[i] or 0) + equipBreakDownInfo[oneEquip.nTemplateID][szName]        
        end
    end

    return recycleItemCount
end

function KUIFactoryAbandonNode:refreshResourcesNum()
    local mainNode          = self._mainLayout
    local animationLeft     = mainNode:getChildByName("ProjectNode_left")
    local panelLeft         = animationLeft:getChildByName("Panel_abandon_left")

    local recycleItemCount = self:calculateRecycleItemCount()

    for i, v in ipairs(m_tRecycleItemName) do
        local textItemData = panelLeft:getChildByName("Text_" .. v .. "_data")
        print("refreshResourcesNum", "Text_" .. v .. "_data", recycleItemCount[i])
        textItemData:setString(recycleItemCount[i])
    end
end

function KUIFactoryAbandonNode:initEmptyBar(bar)
    local imageBase    = bar:getChildByName("Image_fq_unit_base")
    imageBase:setVisible(false)
    local buttonAdd    = bar:getChildByName("Button_add_button")
    buttonAdd:setVisible(true)
end

function KUIFactoryAbandonNode:refreshStartButton()
    local mainNode          = self._mainLayout
    local animationRight    = mainNode:getChildByName("ProjectNode_right")
    local panelRight        = animationRight:getChildByName("Panel_abandon_right")
    local imageAbandonBase  = panelRight:getChildByName("Image_abandon_base2")
    local buttonAbandon     = imageAbandonBase:getChildByName("Button_start_abandon") 
    KUtil.setTouchEnabledAndDisable(buttonAbandon, #self._chosenEquipIDList > 0)
end

function KUIFactoryAbandonNode:removeBar(nID)
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local panelRight     = animationRight:getChildByName("Panel_abandon_right")
    local scrollControl  = panelRight:getChildByName("Scrollview_abandon_list")
    local nIndex         = KUtil.getBarIndexFromScrollViewByID(scrollControl, nID)
    assert(nIndex)
    KUtil.removeBarFromScrollView(scrollControl, nIndex)

    self:refreshStartButton()
end

function KUIFactoryAbandonNode:initEquipBar(bar, oneEquip)
    local equipConfig        = KConfig.equipInfo[oneEquip.nTemplateID]
    assert(equipConfig)
    local imageAbandonBase   = bar:getChildByName("Image_fq_unit_base")
    imageAbandonBase:setVisible(true)
    local textGearName       = imageAbandonBase:getChildByName("Text_gear_name")
    textGearName:setString(equipConfig["szName"])
    
    -- equip panel
    local nGrade = equipConfig["nGrade"]
    local panelGearIcon     = imageAbandonBase:getChildByName("Panel_gear_icon")
    for i = 1, GEAR_MAX_LEVEL do
        local imageLevel   = panelGearIcon:getChildByName("Image_common_gear_level_" .. i)
        imageLevel:setVisible(nGrade == i) 
    end

    local buttonDelete  = imageAbandonBase:getChildByName("Button_jt_unit_unload")
    local function onDeleteClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._waiting then return end
        if not HArray.FindFirstByValue(self._chosenEquipIDList, oneEquip.nID) then return end
        KSound.playEffect("click")
        HArray.RemoveFirstByValue(self._chosenEquipIDList, oneEquip.nID)
        self:removeBar(oneEquip.nID)
        self:refreshResourcesNum()
        self:refreshStartButton()
    end
    buttonDelete:addTouchEventListener(onDeleteClick)
    
    -- equip image
    local imageGear = panelGearIcon:getChildByName("Image_gear")
    local realImagePath = KUtil.getEquipImagePathByID(oneEquip.nTemplateID)
    imageGear:loadTexture(realImagePath, ccui.TextureResType.localType)
end

function KUIFactoryAbandonNode:refreshScrollView(isCutIn)
    local mainNode          = self._mainLayout
    local animationRight    = mainNode:getChildByName("ProjectNode_right")
    local panelRight        = animationRight:getChildByName("Panel_abandon_right")
    local sliderControl     = panelRight:getChildByName("Slider_scroll")
    local scrollControl     = panelRight:getChildByName("Scrollview_abandon_list")

    local tData = {}
    HArray.inserArray(tData, self._chosenEquipIDList)
    table.insert(tData, 0)

    local function getID(equipID)
        return equipID
    end 

    local function funInit(bar, equipID)
        print("funInit-----", equipID)
        if equipID == 0 then
            self:initEmptyBar(bar)
            return true
        end
        local equip = HArray.FindFirstByID(KPlayer.tItemData.tEquipStoreHouse.tEquipList, equipID) 
        if not equip then return false end
        self:initEquipBar(bar, equip)
        return true
    end 

    local tParam      = {
        scrollView    = scrollControl,
        barBase       = self._imageEquipUnitBase,
        dataList      = tData,
        funInit       = funInit,
        funGetID      = getID,
        oneBatchCount = 4,
        isCutIn       = isCutIn,
        slideControl  = sliderControl}
    KUtil.batchAddScrollView(tParam)
end

function KUIFactoryAbandonNode:setChosenEquipIDList(equipIDList)
    self._chosenEquipIDList = {}
    HArray.inserArray(self._chosenEquipIDList, equipIDList)
    self:refreshUI()
end

function KUIFactoryAbandonNode:initData()
    local mainNode       = self._mainLayout
    local animationRight = mainNode:getChildByName("ProjectNode_right")
    local nodeUnitBase   = animationRight:getChildByName("Node_base")
    local imageEquipBar  = nodeUnitBase:getChildByName("Image_jt_empty")
    self._imageEquipUnitBase = imageEquipBar

    local buttonAddEquip     = self._imageEquipUnitBase:getChildByName("Button_add_button")
    local function onAddEquipClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._waiting then return end
        cclog("-----> onAddEquipClick~")
        KSound.playEffect("addMember")
        self._parent:addNode("GearMultiChoose",{["preNode"] = self, ["chosenEquipIDList"] = self._chosenEquipIDList})
    end
    buttonAddEquip:addTouchEventListener(onAddEquipClick)

    local nodeAbandonLeft      = self._mainLayout:getChildByName("ProjectNode_left")
    self._animationList.left   = KUtil.initAnimation(nodeAbandonLeft, "res/ui/animation_node/ani_abandon_left.csb")
    local nodeAbandonRight     = self._mainLayout:getChildByName("ProjectNode_right")
    self._animationList.right  = KUtil.initAnimation(nodeAbandonRight, "res/ui/animation_node/ani_abandon_right.csb")
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end


function KUIFactoryAbandonNode:enterAnimation()
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    for _, animation in pairs(self._animationList) do
        KUtil.playEnterAnimation(animation)
    end
end

function KUIFactoryAbandonNode:exitAnimation()
    local mainNode     = self._mainLayout
    mainNode:setVisible(false)

    local nDelayTime = 0
    for _, animation in pairs(self._animationList) do
        local nTime = KUtil.playQuitAnimation(animation)
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    return nDelayTime
end

function KUIFactoryAbandonNode:enter()
    self:enterAnimation()
end

function KUIFactoryAbandonNode:quit()
    return self:exitAnimation()
end

function KUIFactoryAbandonNode:refreshUI()      
    self:refreshScrollView()
    self:refreshResourcesNum()
    self:refreshStartButton()
end

function KUIFactoryAbandonNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local animationRight    = mainNode:getChildByName("ProjectNode_right")
    local panelRight        = animationRight:getChildByName("Panel_abandon_right")

    local imageAbandonBase  = panelRight:getChildByName("Image_abandon_base2")
    local buttonAbandon     = imageAbandonBase:getChildByName("Button_start_abandon")   
    local function onStartAbandonClick(sender, type)
    	if type ~= ccui.TouchEventType.ended then return end
    	cclog("-----> onStartAbandonClick~")
        KSound.playEffect("abandon")
        if not self._waiting then
            require("src/network/KC2SProtocolManager"):breakDownEquipList(self._chosenEquipIDList)
    	    -- startAbandonChosenEquip(self)
            self._waiting = true
            KUtil.setTouchEnabledAndDisable(buttonAbandon, false)
        end
    end
    buttonAbandon:addTouchEventListener(onStartAbandonClick)
    
    local scrollControl   = panelRight:getChildByName("Scrollview_abandon_list")
    local sliderControl   = panelRight:getChildByName("Slider_scroll")
    local function onSliderChanged(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(sliderControl:getPercent())
        end
    end
    sliderControl:addEventListener(onSliderChanged)

    local function onScrollChanged(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        sliderControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChanged)
end

function KUIFactoryAbandonNode:registerAllCustomEvent()
    local eventDispatcher = require("src/logic/KEventDispatchCenter")
    
    local function onBreakDownEqupList(tEquipIDList)
        cclog("onEvent ------------> onBeakDownEquipList")
        self._waiting = false
        self._chosenEquipIDList = HArray.arraySub(self._chosenEquipIDList, tEquipIDList)
        local sizeBase   = self._imageEquipUnitBase:getContentSize()

        local mainNode          = self._mainLayout
        local animationRight    = mainNode:getChildByName("ProjectNode_right")
        local panelRight        = animationRight:getChildByName("Panel_abandon_right")
        local scrollView        = panelRight:getChildByName("Scrollview_abandon_list")

        local delayTime = KUtil.PlayClearScrollViewAnimation(scrollView)
        local function delayRemove()
            self:refreshScrollView()
            self:refreshResourcesNum()
            self:refreshStartButton()
        end
        delayExecute(self._mainLayout, delayRemove, delayTime)
    end
    self._parent:addCustomEvent(eventDispatcher.EventType.NET_EQUIPS_BREAK, onBreakDownEqupList)

    local function onEquipChooseFinish(tEquipIDList)
        self:setChosenEquipIDList(tEquipIDList)
    end
    self._parent:addCustomEvent(eventDispatcher.EventType.UI_EQUIP_CHOOSE_FINISH, onEquipChooseFinish)

    local function onEquipLock(nID, bLock)
        if bLock then
            HArray.RemoveFirstByValue(self._chosenEquipIDList, nID)
            self:setChosenEquipIDList(self._chosenEquipIDList)
        end
    end
    self._parent:addCustomEvent(eventDispatcher.EventType.NET_EQUIP_LOCK, onEquipLock)
    
end

return KUIFactoryAbandonNode
