--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryAwardTankNode.lua
--  Creator     : Jiang Xufeng 
--  Date        : 2015/07/09   14:20
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_QUALITY = 6

local KUIFactoryAwardTankNode = class(
    "KUIFactoryAwardTankNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryAwardTankNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._cardID            = nil 
end

function KUIFactoryAwardTankNode.create(owner)
    local currentNode = KUIFactoryAwardTankNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/award_tank.csb"
    currentNode:init()

    return currentNode
end

local function refreshAnimation(self)
    if not self._cardID then
        -- data is not ready
        return
    end
    local mainNode              = self._mainLayout    
    local animationOrginFrame   = 0  
    local imageDialog           = mainNode:getChildByName("Image_jl_dialog")
    local cardID                = self._cardID
    local labelTankName         = imageDialog:getChildByName("Text_tank_name")

    local card                  = KUtil.getCardById(cardID)
    local cardConfig            = KConfig.cardInfo[card.nTemplateID]
    
    local cardInfo              = KConfig:getLine("cardInfo", cardID)
    local cardName              = cardInfo["szName"]
    labelTankName:setString(cardName)
    local labeltankType         = imageDialog:getChildByName("Text_tank_type")
    local tankType              = tonumber(cardInfo["nTankType"])
    local tankRange             = tonumber(cardInfo["nQuality"])
    local tankTypeName          = CARD_TYPE_NAME[tankType]
    local setCardImage          = KUtil.getCardImageByTemplateID(cardID)
    labeltankType:setString(tankTypeName)
    
    local labelTankDialog       = imageDialog:getChildByName("Text_dialog")
    labelTankDialog:setString(cardInfo["szOpeningDialogue"])
    
    local nodeCharacter         = mainNode:getChildByName("ProjectNode_character")
    nodeCharacter:stopAllActions()
    local imageCardChara        = nodeCharacter:getChildByName("Image_card_chara")
    imageCardChara:loadTexture(setCardImage)
    local cardNum               = imageCardChara:getScale()
    local characterAction       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_tank_translation.csb")
    assert(characterAction ~= nil, "Create characterAction Failed~")
    local animationStartFrame   = 0
    local characterActionAnimationEndFrame = 59   
    nodeCharacter:runAction(characterAction)
    characterAction:gotoFrameAndPlay(animationStartFrame, characterActionAnimationEndFrame, false)

    local nodeProjectTrans      = mainNode:getChildByName("ProjectNode_trans")
    nodeProjectTrans:stopAllActions()
    local projectCardNodeAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_award_trans.csb")
    local projceCardAcnimationEndFrame = 117
    assert(projectCardNodeAction ~= nil, "Create projectCardNodeAction Failed~")
    nodeProjectTrans:runAction(projectCardNodeAction)
    projectCardNodeAction:gotoFrameAndPlay(animationStartFrame, projceCardAcnimationEndFrame, false)

    local nodeProjectCard       = mainNode:getChildByName("ProjectNode_card")
    nodeProjectCard:setVisible(false)
    local panelCardDhara        = nodeProjectCard:getChildByName("Panel_card_chara")
    local imageCharaCard        = panelCardDhara:getChildByName("Image_card_chara")
    local animationTime         = projectCardNodeAction:getEndFrame() / 60

    imageCharaCard:loadTexture(setCardImage)
    local cardOneChange         = nodeProjectCard:getChildByName("Image_card_kai_1")
    cardOneChange:setVisible(cardConfig.nConvertID == 1)

    local cardTwoChange         = nodeProjectCard:getChildByName("Image_card_kai_2")
    cardTwoChange:setVisible(cardConfig.nConvertID == 2)

    local panelTypeCard = nodeProjectCard:getChildByName("Panel_card_base")
    for num = 1, MAX_QUALITY do 
        local imageName         = "Image_card_base_" .. num
        local image             = panelTypeCard:getChildByName(imageName)
        if num ~= tankRange then
            image:setVisible(false)
        end
    end
    
    local panelTypeCard         = nodeProjectCard:getChildByName("Panel__card_type")
    for num = 1, MAX_QUALITY do 
        local imageName         = "Image_card_type_" .. num
        local image             = panelTypeCard:getChildByName(imageName)
        image:setVisible(false)

        local tankImageVisibleName  = "Image_card_type_" .. tankType
        local imageTank             = panelTypeCard:getChildByName(tankImageVisibleName)
        imageTank:setVisible(true)
    end

    local labelTankName          = nodeProjectCard:getChildByName("Text_2")
    labelTankName:setString(cardName)
    local paneImedaCardPanel     = nodeProjectCard:getChildByName("Panel__card_meda")
    paneImedaCardPanel:setVisible(false)
    delayExecute(
        self, 
        function () 
            local eventCenter = require("src/logic/KEventDispatchCenter")
            eventCenter:dispatchEvent(eventCenter.EventType.UI_ACTION_FINISH) 
            nodeProjectCard:setVisible(true)
        end, 
        animationTime
    )

    local nodeTankLight       = mainNode:getChildByName("ProjectNode_tank_light")
    nodeTankLight:stopAllActions()
    local tankLightNodeAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_tank_light.csb")
    local tankLightNodeActionAnimationEndFrame = 59   
    assert(tankLightNodeAction ~= nil, "Create tankLightNodeAction Failed~")
    nodeTankLight:runAction(tankLightNodeAction)
    tankLightNodeAction:gotoFrameAndPlay(animationStartFrame, tankLightNodeActionAnimationEndFrame, false)
end

function KUIFactoryAwardTankNode:setCardInformation( cardID)
    self._cardID    = cardID 
    refreshAnimation(self)
end

function KUIFactoryAwardTankNode:refreshUI()
    refreshAnimation(self) 
end

function KUIFactoryAwardTankNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local buttonScreen  = mainNode:getChildByName("Button_screen")
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")
            self._parent:removeNode("FactoryAwardTank")
            cclog("onScreenClick~")
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)
end

return KUIFactoryAwardTankNode
