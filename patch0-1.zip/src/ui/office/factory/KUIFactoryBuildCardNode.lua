--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryBuildCardNode.lua
--  Creator     : SunXun
--  Date        : 2015/04/21   23:10
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local MIN_RESOURCE_COUNT        = 30
local MAX_NUMBER_COUNT          = 9
local MIN_NUMBER_COUNT          = 0
local MAX_PANEL_RESOURCES_COUNT = 4
local MAX_PANEL_BUTTON_COUNT    = 6
local MAX_PANEL_NUMBER_COUNT    = 3
local TOTAL_NUMBER_COUNT        = 10
local BUILDING_MATERIAL         = 1

local m_tDestResourceCount = 
{
    [1]   = {0, 3, 0},
    [2]   = {0, 3, 0},
    [3]   = {0, 3, 0},
    [4]   = {0, 3, 0}
}

local KUIFactoryBuildCardNode = class("KUIFactoryBuildCardNode")

function KUIFactoryBuildCardNode:ctor(owner, node)
    self._mainLayout        = node
    self._parent            = owner

    self._animationList     = {}
    self._eventList         = {}
    self:initData()
    self:refreshUI()
end

local function setNumber(panelSingleNumber, currentResourceValue)
    for numberIndex = 1, TOTAL_NUMBER_COUNT do
        local imageRealIndex    = numberIndex - 1
        local imageNumber       = panelSingleNumber:getChildByName("Image_number_" .. imageRealIndex)
        imageNumber:setVisible(imageRealIndex == currentResourceValue)
    end
end

local function refreshBottom(self)
    local mainNode              = self._mainLayout
    local animationBottom       = mainNode:getChildByName("ProjectNode_bottom_button")
    local panelBottom           = animationBottom:getChildByName("Panel_build_bottom")
    local buttonStart           = panelBottom:getChildByName("Button_start_build")

    -- calc current resource value
    local startBuildingButtonFlag = true
    for i, v in pairs(m_tDestResourceCount) do
        local currentResourceValue = v[1] * 100 + v[2] * 10 + v[3]
        if currentResourceValue < MIN_RESOURCE_COUNT then 
            startBuildingButtonFlag = false 
            break
        end
    end

    KUtil.setTouchEnabledAndDisable(buttonStart, startBuildingButtonFlag)
end

function KUIFactoryBuildCardNode:changeResourceByType(resourceType, resourceIndex, isAdd)
    local resourceInfo = m_tDestResourceCount[resourceType]
    assert(resourceInfo ~= nil, "Get resourceInfo Failed~")

    local resourceValue = resourceInfo[resourceIndex]
    assert(resourceValue ~= nil, "Get resourceValue Failed~")

    if not isAdd then    -- cut down
        resourceValue = resourceValue - 1
        if resourceValue < MIN_NUMBER_COUNT then resourceValue = MAX_NUMBER_COUNT end
    else                -- add
        resourceValue = resourceValue + 1
        if resourceValue > MAX_NUMBER_COUNT then resourceValue = MIN_NUMBER_COUNT end
    end
    resourceInfo[resourceIndex] = resourceValue
    local mainNode              = self._mainLayout
    local animationContent      = mainNode:getChildByName("ProjectNode_content")
    local panelContent          = animationContent:getChildByName("Panel_ani_build_content")
    local panelResource         = panelContent:getChildByName("Panel_resources_" .. resourceType)
    local panelNumber           = panelResource:getChildByName("Panel_number")
    local panelSingleNumber     = panelNumber:getChildByName("Panel_number_" .. resourceIndex)
    setNumber(panelSingleNumber, resourceValue)
    refreshBottom(self)
end

local function refreshTop(self)
    local mainNode      = self._mainLayout
    local animationTop  = mainNode:getChildByName("ProjectNode_top")
    local panelTop      = animationTop:getChildByName("Panel_1")

    local constructValue     = panelTop:getChildByName("Text_construct__value")
    local buildMaterialValue = KUtil.getItemCount(BUILDING_MATERIAL)
    constructValue:setString(buildMaterialValue)
    local labelContantValue  = panelTop:getChildByName("Text_contant_value")
    local allCardsCount      = KUtil.getCardCount()
    labelContantValue:setString("".. allCardsCount .. "/" .. KUtil.getCardStoreSize())
end

local function refreshContent(self)
    local mainNode              = self._mainLayout
    local animationContent      = mainNode:getChildByName("ProjectNode_content")
    local panelContent          = animationContent:getChildByName("Panel_ani_build_content")

    -- refresh resource image to ui
    for panelResouceIndex = 1, MAX_PANEL_RESOURCES_COUNT do
        local panelResourceName     = "Panel_resources_" .. panelResouceIndex
        local panelResource         = panelContent:getChildByName(panelResourceName)
        local panelNumber           = panelResource:getChildByName("Panel_number")
        for panelNumberIndex = 1, MAX_PANEL_NUMBER_COUNT do
            local currentResourceValue = m_tDestResourceCount[panelResouceIndex][panelNumberIndex]
            local panelSingleNumber    = panelNumber:getChildByName("Panel_number_" .. panelNumberIndex)
            setNumber(panelSingleNumber, currentResourceValue)
        end
    end
end

function KUIFactoryBuildCardNode:beganBuild()
    local isSuccess = true
    local consumeNum = {}
    for i = 1, MAX_PANEL_RESOURCES_COUNT do
        consumeNum[i] = m_tDestResourceCount[i][1] * 100 + m_tDestResourceCount[i][2] * 10 + m_tDestResourceCount[i][3]
        if consumeNum[i] > KPlayer[CURRENCY_KEY[i]] then
            isSuccess = false
            showNoticeByID("common.lessResource", KUtil.getStringByKey("common."..CURRENCY_KEY[i]))
            break
        end
    end
    if isSuccess and KUtil.getItemCount(BUILDING_MATERIAL) == 0 then
        isSuccess = false
        showNoticeByID("common.lessResource", KUtil.getItemConfigValue(BUILDING_MATERIAL, "szName"))
    end
    
    local allCardsCount = KUtil.getCardCount()
    local cardStoreSize = KUtil.getCardStoreSize() 
    if isSuccess and allCardsCount >= cardStoreSize then
        isSuccess = false
        showNoticeByID("produce.CardStoreNotEnough")
    end
    
    if isSuccess and not KUtil.isEnoughEquipStore(1) then
        isSuccess = false
        showNoticeByID("produce.EquipStoreNotEnough")
    end
     
    if isSuccess then
        require("src/network/KC2SProtocolManager"):produceCard(self._index, consumeNum[1], consumeNum[2], consumeNum[3], consumeNum[4])
        cclog("-------------------->KUIFactoryBuildCardNode:beganBuild" )
    end
end

function KUIFactoryBuildCardNode:resetResourceArea(nodeData)
    m_tDestResourceCount[1] = KUtil.getFormatResource(nodeData.oil)
    m_tDestResourceCount[2] = KUtil.getFormatResource(nodeData.ammo)
    m_tDestResourceCount[3] = KUtil.getFormatResource(nodeData.steel)
    m_tDestResourceCount[4] = KUtil.getFormatResource(nodeData.people)
    refreshContent(self)
    refreshBottom(self)
end

function KUIFactoryBuildCardNode:initData()
    local nodeBuildTop          = self._mainLayout:getChildByName("ProjectNode_top")
    self._animationList.top     = KUtil.initAnimation(nodeBuildTop, "res/ui/animation_node/ani_build_top.csb")
    local nodeButtonBottom      = self._mainLayout:getChildByName("ProjectNode_bottom_button")
    self._animationList.bottom  = KUtil.initAnimation(nodeButtonBottom, "res/ui/animation_node/ani_build_bottom.csb")
    local nodeBuildContent      = self._mainLayout:getChildByName("ProjectNode_content")
    self._animationList.content = KUtil.initAnimation(nodeBuildContent, "res/ui/animation_node/ani_build_content.csb")
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    for _, animation in pairs(self._animationList) do
        KUtil.playEnterAnimation(animation)
    end
end

local function exitAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(false)

    local nDelayTime = 0
    for _, animation in pairs(self._animationList) do
        local nTime = KUtil.playQuitAnimation(animation)
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    return nDelayTime
end

function KUIFactoryBuildCardNode:enter(nIndex, bInit)
    if nIndex then
        self._index = nIndex
    end
    if bInit then
        m_tDestResourceCount = 
        {
            [1]   = {0, 3, 0},
            [2]   = {0, 3, 0},
            [3]   = {0, 3, 0},
            [4]   = {0, 3, 0}
        }
    end
    assert(self._index)
    refreshTop(self)
    refreshBottom(self)
    enterAnimation(self)
end

function KUIFactoryBuildCardNode:quit()
    return exitAnimation(self)
end

function KUIFactoryBuildCardNode:refreshUI(nIndex, bInit)
    print("KUIFactoryBuildCardNode:refreshUI", nIndex)
    self._index = nIndex
    if bInit then
        m_tDestResourceCount = 
        {
            [1]   = {0, 3, 0},
            [2]   = {0, 3, 0},
            [3]   = {0, 3, 0},
            [4]   = {0, 3, 0}
        }
    end

    refreshTop(self)
    refreshContent(self)
    refreshBottom(self)
end

function KUIFactoryBuildCardNode:registerAllTouchEvent()
    local mainNode     = self._mainLayout

    local animationTop = mainNode:getChildByName("ProjectNode_top")
    local panelTop     = animationTop:getChildByName("Panel_1")
    --Log Button
    local buttonLog    = panelTop:getChildByName("Button_log_button")
    local function onLogClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onLogButton~") 
            KSound.playEffect("click") 
            self._parent:addNode("CardLog")
        end
    end
    buttonLog:addTouchEventListener(onLogClick)

    --Reset Button
    local buttonReset = panelTop:getChildByName("Button_reset")
    local function onResetClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            for k, v in pairs(m_tDestResourceCount) do 
                v[1] = 0
                v[2] = 3 
                v[3] = 0
            end   
            refreshContent(self)
            refreshBottom(self)
            cclog("click onResetButton~")            
        end
    end
    buttonReset:addTouchEventListener(onResetClick)

    --Start Build Button
    local animationBottom = mainNode:getChildByName("ProjectNode_bottom_button")
    local panelBottom     = animationBottom:getChildByName("Panel_build_bottom")
    local buttonStart     = panelBottom:getChildByName("Button_start_build")
    local function onStartBuildClick(sender, type)
        if type == ccui.TouchEventType.ended and KUtil.getProducingCardCount() < KUtil.getBuildBarCount() then
            cclog("click onStartBuildButton~") 
            KSound.playEffect("startBuilding")           
            self:beganBuild()
            KUtil.setTouchEnabledAndDisable(buttonStart, false)
        end
    end
    buttonStart:addTouchEventListener(onStartBuildClick)

    local animationContent      = mainNode:getChildByName("ProjectNode_content")
    local panelContent          = animationContent:getChildByName("Panel_ani_build_content")
    for panelResourcesID = 1, MAX_PANEL_RESOURCES_COUNT do
        local panelResource     = panelContent:getChildByName("Panel_resources_" .. panelResourcesID)
        for panelButtonID = 1, MAX_PANEL_BUTTON_COUNT do
            local panelButton   = panelResource:getChildByName("Panel_button")  
            local buttonControl = panelButton:getChildByName("Button_" .. panelButtonID) 
            local resourceType  = panelResourcesID
            local numberIndex   = panelButtonID
            local function onButtonClick(sender, type)
                if type == ccui.TouchEventType.ended then
                    KSound.playEffect("click")
                    local isAdd = true
                    local index = numberIndex
                    if numberIndex > MAX_PANEL_NUMBER_COUNT then
                        index = numberIndex - MAX_PANEL_NUMBER_COUNT
                        isAdd = false
                    end
                    self:changeResourceByType(resourceType, index, isAdd)
                end
            end
            buttonControl:addTouchEventListener(onButtonClick)
        end
    end
end

function KUIFactoryBuildCardNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onbeganBuild()
        cclog("onEvent ------------> onUninstallWeaponsFinish")
        self._parent:switchPage("ProjectNode_factory")
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_BEGAN_BUILD, onbeganBuild)
end

return KUIFactoryBuildCardNode
