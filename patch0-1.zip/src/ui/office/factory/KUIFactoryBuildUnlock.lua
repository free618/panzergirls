--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryBuildUnlock.lua
--  Creator     : LiuLingli
--  Date        : 2015/07/18   16:50
--  Contact     : LiuLingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIFactoryBuildUnlock = class(
    "KUIFactoryBuildUnlock", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryBuildUnlock:ctor()
    self._mainLayout          = nil
    self._parent              = nil
    self._uiPath              = nil
    self._tUnLockList         = {}
    self._animationCardUnlock = nil
    self._currentID           = nil
    self._isShow              = false
end

function KUIFactoryBuildUnlock.create(owner)
    local currentNode   = KUIFactoryBuildUnlock.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_mission_build_unlock.csb"

    currentNode:init()

    return currentNode
end

function KUIFactoryBuildUnlock:addCardUnlockType(nType)
    for nID, tConfig in pairs(KConfig["cardproduceinfo"]) do
        print("addCardUnlockType", nType, tConfig.nType)
        if tConfig.nType == nType then
            table.insert(self._tUnLockList, {["nID"] = nID, ["isCard"] = true})
        end
    end
    if not self._isShow then
        self:showUnlock()
    end
end

function KUIFactoryBuildUnlock:addEquipUnlockType(nType)
    for nID, tConfig in pairs(KConfig["equipproduceinfo"]) do
        if tConfig.nType == nType then
            table.insert(self._tUnLockList, {["nID"] = nID})
        end
    end
    if not self._isShow then
        self:showUnlock()
    end
end

function KUIFactoryBuildUnlock:onInitUI()
    local mainNode             = self._mainLayout
    local nodeAnimation        = mainNode:getChildByName("ProjectNode_1")
    self._animationCardUnlock  = KUtil.initAnimation(nodeAnimation, "res/ui/animation_node/ani_mission_build_unlock.csb")
end

function KUIFactoryBuildUnlock:showUnlock()
    assert(#self._tUnLockList > 0)
    if #self._tUnLockList == 0 then return end
    self._isShow = true
    local tInfo            = self._tUnLockList[1]
    
    local mainNode         = self._mainLayout
    local nodeAnimation    = mainNode:getChildByName("ProjectNode_1")
    local panelBase        = nodeAnimation:getChildByName("Panel_1")
    local imageBase        = panelBase:getChildByName("Image_unlock_base_2")
    local textName         = imageBase:getChildByName("Text_tank_name")
    local imageCardBase    = panelBase:getChildByName("Image_unlock_base_3")
    local imageCard        = imageCardBase:getChildByName("Image_card_chara")
    local imageEquip       = imageCardBase:getChildByName("Image_equip_gear")
    imageCard:setVisible(tInfo.isCard)
    imageEquip:setVisible(not tInfo.isCard)
    if tInfo.isCard then
        local tCardConfig  = KUtil.getCardConfig(tInfo.nID)
        assert(tCardConfig)
        textName:setString(string.format(KUtil.getStringByKey("build.unlock"), tCardConfig.szName))
        local szCardPath   = KUtil.getCardImagePathByConfigID(tInfo.nID)
        imageCard:loadTexture(szCardPath)
    else
        local tEquipConfig = KConfig.equipInfo[tInfo.nID]
        assert(tEquipConfig)
        textName:setString(string.format(KUtil.getStringByKey("build.unlock"), tEquipConfig.szName))
        local szEquipPath  = KUtil.getEquipImagePathByID(tInfo.nID)
        imageEquip:loadTexture(szEquipPath)
    end
    local nCutInFrameBegin  = 0
    local nCutInFrameEnd    = 70
    local nCutOutFrameBegin = 120
    local nCutOutFrameEnd   = 135
    if self._currentID then
        KUtil.animationGotoFrameAndPlay(self._animationCardUnlock, nCutOutFrameBegin, nCutOutFrameEnd, false)
        local function playAnimation()
            KUtil.animationGotoFrameAndPlay(self._animationCardUnlock, nCutInFrameBegin, nCutInFrameEnd, false)
        end
        delayExecute(self, playAnimation, (nCutOutFrameEnd - nCutOutFrameBegin) / 60 )
    else
        KUtil.animationGotoFrameAndPlay(self._animationCardUnlock, nCutInFrameBegin, nCutInFrameEnd, false)
    end
    self._currentID = tInfo.nID
end

function KUIFactoryBuildUnlock:refreshUI()
end

function KUIFactoryBuildUnlock:registerAllTouchEvent()
    local mainNode         = self._mainLayout
    local nodeAnimation    = mainNode:getChildByName("ProjectNode_1")
    local panelBase        = nodeAnimation:getChildByName("Panel_1")

    local function onClick(sender, type)
        if type ~= ccui.SliderEventType.percentChanged then return end
        assert(#self._tUnLockList > 0)
        table.remove(self._tUnLockList, 1)
        
        if #self._tUnLockList > 0 then
            self:showUnlock()
        else
            self._parent:removeNode("BuildUnlock") 
        end
    end
    panelBase:addTouchEventListener(onClick)
end

return KUIFactoryBuildUnlock
