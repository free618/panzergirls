--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryChooseCardNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/04   14:40
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local SHOW_LIST_SIZE    = 7
local MAX_CHECK_BOX     = 6
local CLICK_DELAY_FRAME = 30
local m_SortTypeList = {"Image_sort_name", "Image_sort_star", "Image_sort_level", "Image_sort_time","Image_sort_type"}
local m_SortNameList = {"name", "star", "level", "createTime"}
local m_SortButtonName = {"Button_name", "Button_star", "Button_level", "Button_time"}
local m_tButtonType = {"Button_light", "Button_tanzania", "Button_heavy", "Button_fighter", "Button_artillery", "Button_all"}
local m_tLabelTypeName  = {"Image_type_light", "Image_type_tanzania", "Image_type_heavy", "Image_type_fighter", "Image_type_artillery", "Image_type_all"}

local m_AttributeName = {"nAddAttack", "nAddPenetrate", "nAddSpeed", "nAddFrontArmour", "nAddRearArmour", "nAddScout", "nAddHide", "nAddNightBattle"}
local m_NodeName      = {"Image_qh_huoli", "Image_qh_chuantou", "Image_qh_sudu", "Image_qh_qianjia",
        "Image_qh_houjia", "Image_qh_zhencha", "Image_qh_yinbi", "Image_qh_yezhan"}
local KSetting = require("src/logic/KSetting")

local KUIFactoryChooseCardNode = class(
    "KUIFactoryChooseCardNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local m_BouttonUnit =
{
    ["normal"]   = "res/ui/ui_material/cardbase/card_%s_buttom.png", 
    ["press"]    = "res/ui/ui_material/cardbase/card_%s_buttom_active.png", 
    ["disable"]  = "res/ui/ui_material/cardbase/card_%s_buttom.png",
}

function KUIFactoryChooseCardNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._baseCardButton        = nil
    self._baseSelectedcardText  = nil
    self._cardList              = {}
    self._showCardList          = {}
    self._SelectedcardIDList    = {}
    self._updateTimes           = 0
    self._pageData              = {}
    self._pageDataChosen        = {}
    self._sortType              = KSetting.getInt(KSetting.Key.BREAK_COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    self._tankType              = KSetting.getInt(KSetting.Key.BREAK_TEAM_CHOOSE_TYPE, KUtil.CHOOSE_TANK_TYPE.ALL)
    self._animationList         = {}
end

local function getShowCardList(tCardList, nTeamType)
    local cardList = KUtil.getCardsByKey(tCardList, nTeamType)
    local secretaryCard = KUtil.getSecretaryCard()
    local showCardList = {}
    
    for _, oneCard in ipairs(cardList) do
        if oneCard.nID ~= secretaryCard.nID then
            table.insert(showCardList, oneCard)
        end
    end

    return showCardList
end

function KUIFactoryChooseCardNode.create(owner, tCardList, tSelectCardList, nTankType, nShortType, bShowStrengthAttribute)
    local currentNode   = KUIFactoryChooseCardNode.new()

    currentNode._parent = owner
    currentNode._isShowStrengthAttribute = bShowStrengthAttribute
    currentNode._uiPath = "res/ui/layout_tank_multi_choose.csb"
    assert(tCardList ~= nil)
    currentNode._cardList = tCardList

    if nTankType then
        currentNode._tankType = nTankType
    end

    if nShortType then
        currentNode._sortType = nShortType
    end

    if tSelectCardList then
        currentNode._SelectedcardIDList = {}
        HArray.inserArray(currentNode._SelectedcardIDList, tSelectCardList)
    end

    currentNode._showCardList = getShowCardList(tCardList, currentNode._tankType)
    currentNode:init()
    return currentNode
end

local function refreshSortButton(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local nodeBottom    = imageCommon:getChildByName("ProjectNode_bottom")
    local panelSelected = nodeBottom:getChildByName("Panel_tank_multi_choose_bottom")
    local buttonSort    = panelSelected:getChildByName("Button_common_sort")
    
    for sortType, textName in ipairs(m_SortTypeList) do
        local textSort  = buttonSort:getChildByName(textName)
        local textVisible = (sortType == self._sortType)
        textSort:setVisible(textVisible)
    end
end

local function refreshTypeButton(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local nodeBottom    = imageCommon:getChildByName("ProjectNode_bottom")
    local panelSelected = nodeBottom:getChildByName("Panel_tank_multi_choose_bottom")
    local buttonSort    = panelSelected:getChildByName("Button_common_type")
    
    for sortType, textName in ipairs(m_tLabelTypeName) do
        local textSort  = buttonSort:getChildByName(textName)
        local textVisible = (sortType == self._tankType)
        textSort:setVisible(textVisible)
    end
end

function KUIFactoryChooseCardNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIFactoryChooseCardNode:playCloseAnimation(isReturnOffice)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local delayTime1 = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        delayTime = math.max(delayTime, delayTime1)
    end
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "CardChoose", callBacks, isReturnOffice)
end

function KUIFactoryChooseCardNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")

    local list              = self._animationList
    local projectNode       = imageCommon:getChildByName("ProjectNode_bottom")
    list.buttom             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_tank_multi_choose_bottom.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_top")
    list.top                = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_tank_multi_choose_top.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_selected")
    list.selected           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_tank_multi_choose_selected.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_card")
    list.card               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_tank_multi_choose_card.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_star")
    list.star               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_tank_multi_choose_star.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_resource_base")
    list.resourceBase       = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_resource_base.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_button_home")
    list.home               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_home.csb"), {0, 30, 40, 65}}
end

function KUIFactoryChooseCardNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUIFactoryChooseCardNode:onInitUI()
    self:onInitAnimation()
end

local function getChooseIndexByID(self, nID)
    for index, nCardID in ipairs(self._SelectedcardIDList) do
        if nCardID == nID then return index end
    end
    return 0
end

local function UpdateShowList(self)
    self._showCardList = getShowCardList(self._cardList, self._tankType)
    refreshTypeButton(self)
end

function KUIFactoryChooseCardNode:refreshSelectedScrollView(isCutIn)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local nodeSelected   = imageControl:getChildByName("ProjectNode_selected")
    local panelMulti     = nodeSelected:getChildByName("Panel_multi_choose_selected")
    local scrollView     = panelMulti:getChildByName("Scrollview_chosen_list")

    -- store card list on map
    local cardMap = {}
    for i, v in ipairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        cardMap[v.nID] = v
    end

    -- check list
    local listSize = #self._SelectedcardIDList
    for i = listSize, 1, -1 do
        local card = cardMap[self._SelectedcardIDList[i]]
        if not card then
            table.remove(self._SelectedcardIDList, i)
        end
    end

    --format list
    local showListData = {}
    for i, v in ipairs(self._SelectedcardIDList) do
        local card     = cardMap[v] 
        local itemData = {nID = v, nTemplateID = card.nTemplateID}
        table.insert(showListData, itemData)
    end
    
    local refreshCall = function(control, dataInfo)
        local cardConfig   = KUtil.getCardConfig(dataInfo.nTemplateID)
        local textCardName = control:getChildByName("Text_tank_name")
        textCardName:setString(cardConfig.szName)
    end

    local parameters = {
        scrollView  = scrollView,
        itemBase    = self._baseSelectedcardText,
        dataList    = showListData,
        refreshCall = refreshCall,
        column      = 1,
        row         = 15,
    }
    self._pageDataChosen  = KUtil.addDynamicScrollView(parameters)
    scrollView:jumpToBottom()
    self._pageDataChosen.refreshList()

    local selectedCount = #self._SelectedcardIDList
    local nodeBottom    = imageControl:getChildByName("ProjectNode_bottom")
    local panelSelected = nodeBottom:getChildByName("Panel_tank_multi_choose_bottom")

    local buttonCleanup = panelMulti:getChildByName("Button_cleanup")
    KUtil.setTouchEnabled(buttonCleanup, selectedCount>0)

    local buttonConfirm = panelSelected:getChildByName("Button_confirm")
    KUtil.setTouchEnabled(buttonConfirm, selectedCount>0)
end

local function getAddAttribute(tOneCard)
    return KConfig["cardstrengthen"][tOneCard.nTemplateID]
end

local function getButtonUnitPath(cardID)
    local cardCountryName           = KUtil.getCardCountryName(cardID)
    local buttonUnitPressPath       = string.format(m_BouttonUnit["press"],cardCountryName)
    local buttonUnitNormalPath      = string.format(m_BouttonUnit["normal"],cardCountryName)
    local buttonUnitDisablePath     = string.format(m_BouttonUnit["disable"],cardCountryName)

    return buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath
end

local function initCardBoutton(self, boutton, card)
    KUtil.updateCardBase(boutton, card)

    if self._isShowStrengthAttribute then
        local panelAttribute   = boutton:getChildByName("Panel_strength_attribute")
        local panelHP          = boutton:getChildByName("Panel_HP")
        panelAttribute:setVisible(true)
        panelHP:setVisible(false)

        local tAttribute    = getAddAttribute(card)
        local nPanelIndex, nAttributeIndex = 1, 1
        while true do
            local panelAtrribute = panelAttribute:getChildByName("Panel_property_" .. nPanelIndex)
            if not panelAtrribute then break end
            panelAtrribute:setVisible(false)
            nPanelIndex = nPanelIndex + 1
            for index = nAttributeIndex, #m_AttributeName do 
                local nValue = tAttribute[m_AttributeName[index]]
                if nValue and nValue > 0 then
                    nAttributeIndex = index + 1
                    panelAtrribute:setVisible(true)
                    for i,nodeName in ipairs(m_NodeName) do
                        local image = panelAtrribute:getChildByName(nodeName)
                        if i == index then
                            image:setVisible(true)
                        else
                            image:setVisible(false)
                        end
                    end
                    
                    local label = panelAtrribute:getChildByName("BitmapFontLabel_number")
                    label:setString(nValue)

                    break
                end 
            end 
        end
    else
        local panelAttribute   = boutton:getChildByName("Panel_strength_attribute")
        local panelHP          = boutton:getChildByName("Panel_HP")
        panelAttribute:setVisible(false)
        panelHP:setVisible(true)
    end

    assert(self._SelectedcardIDList)
    local frameButtom               = KUtil.getCardBaseActiveFrameButtom(boutton, card.nID)
    local chooseIndex               = getChooseIndexByID(self, card.nID)

    local buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath = getButtonUnitPath(card.nID)

    if chooseIndex ~= 0 then
        frameButtom:loadTextures(buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath)
    else
        frameButtom:loadTextures(buttonUnitNormalPath, buttonUnitPressPath, buttonUnitDisablePath)
    end
    
    local function canClick(card)
        if card.bLock or KUtil.getEnterTeamId(card.nID)~=0 or KUtil.isCardRepair(card.nID) then
            return false
        end

        return true
    end

    local function onSelectClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if not canClick(card) then return end
        KSound.playEffect("click")

        self:SelectOneCard(card.nID)
    end
    KUtil.setTouchEnabled(frameButtom, canClick(card))
    frameButtom:addTouchEventListener(onSelectClick)
end

function KUIFactoryChooseCardNode:setCardButtomState(nID, isPress)
    if not self._pageData then return end
    local buttom        = self._pageData.scrollView:getChildByName(tostring(nID))
    if buttom then
        local frameButtom   = KUtil.getCardBaseActiveFrameButtom(buttom, nID)
        local buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath = getButtonUnitPath(nID)
        if isPress then
            frameButtom:loadTextures(buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath)
        else
            frameButtom:loadTextures(buttonUnitNormalPath, buttonUnitPressPath, buttonUnitDisablePath)
        end
    end
end

function KUIFactoryChooseCardNode:SelectOneCard(nID)
    local chooseIndex = getChooseIndexByID(self, nID)
    if chooseIndex ~= 0 then
        self:setCardButtomState(nID, false)
        table.remove(self._SelectedcardIDList, chooseIndex)
    else
        self:setCardButtomState(nID, true)
        table.insert(self._SelectedcardIDList, nID)
    end
    self:refreshSelectedScrollView(false)
end

function KUIFactoryChooseCardNode:SelectOneCardByIndex(index)
    local data = self._pageData.dataList[index]
    if not data then
        return false
    end

    local chooseIndex = getChooseIndexByID(self, data.nID)
    if chooseIndex ~= 0 then
        self:setCardButtomState(nID, false)
        table.remove(self._SelectedcardIDList, chooseIndex)
    else
        self:setCardButtomState(nID, true)
        table.insert(self._SelectedcardIDList, data.nID)
    end
    self:refreshSelectedScrollView(false)

    return true
end

local function addScrollPageView(self, sortType, isCutIn)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local projectNode    = imageControl:getChildByName("ProjectNode_card")
    local panelBase      = projectNode:getChildByName("Panel_1")
    local scrollViewList = panelBase:getChildByName("Scrollview_tank_list")
    local slideControl   = panelBase:getChildByName("Slider_tank_list")

    local showListData   =  KUtil.getUnitSelectSortList(self._showCardList, sortType, true)
    local refreshCall = function(control, dataInfo)
        initCardBoutton(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollViewList,
        slideView   = slideControl,
        itemBase    = self._baseCardButton,
        dataList    = showListData,
        refreshCall = refreshCall,
        column      = 5,
        row         = 4,
        isCutIn     = isCutIn,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function refreshOther(self)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local projectNode    = imageControl:getChildByName("ProjectNode_top")
    local panelBase      = projectNode:getChildByName("Panel_1")
    local labelCardCount = panelBase:getChildByName("Text_contant_value")
    labelCardCount:setString("".. KUtil.getCardCount() .. "/" .. KUtil.getCardStoreSize())
end

local function refreshCardList(self, sortType, isCutIn)
    addScrollPageView(self, sortType, isCutIn)
end

local function initData(self)
    local mainNode       = self._mainLayout
    local imageControl   = mainNode:getChildByName("Image_common_base")
    local projectNode    = imageControl:getChildByName("ProjectNode_card")
    local panelBase      = projectNode:getChildByName("Panel_1")
    local scrollViewList = panelBase:getChildByName("Scrollview_tank_list")
    local buttonCard     = scrollViewList:getChildByName("Button_unit_base1")
    local buttonCardInfo = buttonCard:getChildByName("Panel_base")
    
    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)
    buttonCardInfo:removeFromParent(false)
    buttonCard:removeFromParent()
    node:addChild(buttonCardInfo)
    buttonCardInfo:setScale(buttonCard:getScaleX(),  buttonCard:getScaleY())

    self._baseCardButton = buttonCardInfo

    local nodeSelected   = imageControl:getChildByName("ProjectNode_selected")
    local panelMulti     = nodeSelected:getChildByName("Panel_multi_choose_selected")
    local scrollViewList = panelMulti:getChildByName("Scrollview_chosen_list")
    local textCardName   = scrollViewList:getChildByName("Image_tank_base")
    self._baseSelectedcardText = textCardName
    textCardName:removeFromParent(false)
    node:addChild(textCardName)
end

function KUIFactoryChooseCardNode:activate(nowTime)
    self._updateTimes = self._updateTimes + 1
end

function KUIFactoryChooseCardNode:refreshUI()
    initData(self)
    refreshCardList(self, self._sortType, false)
    self:refreshSelectedScrollView(true)
    refreshSortButton(self)
    refreshTypeButton(self)
    refreshOther(self)
end

function KUIFactoryChooseCardNode:ConfirmChoose()
    local eventCenter = require("src/logic/KEventDispatchCenter")
    eventCenter:dispatchEvent(eventCenter.EventType.UI_BREAK_CHOOSE_FINISH, self._SelectedcardIDList)

    self:playCloseAnimation(false)
end

function KUIFactoryChooseCardNode:sortByChooseType(nType)
    local mainNode = self._mainLayout
    local imageControl        = mainNode:getChildByName("Image_common_base")
    local buttonScreen        = imageControl:getChildByName("Button_screen")

    self._sortType = nType
    KSetting.setInt(KSetting.Key.BREAK_COMMON_CHOOSE_TYPE, self._sortType)
    refreshSortButton(self)
    refreshCardList(self, self._sortType, true)
    buttonScreen:setVisible(false)
end

function KUIFactoryChooseCardNode:chooseCard(nID, isSelect)
    local chooseIndex = getChooseIndexByID(self, nID)
    if chooseIndex ~= 0 and not isSelect then
        self:setCardButtomState(nID, false)
        table.remove(self._SelectedcardIDList, chooseIndex)
    elseif chooseIndex == 0 and isSelect then
        self:setCardButtomState(nID, true)
        table.insert(self._SelectedcardIDList, nID)
    end
end

function KUIFactoryChooseCardNode:chooseCardByStar(star)
    local cardList = self._showCardList
    for _, card in ipairs(cardList) do
        local cardConfig   = KUtil.getCardConfig(card.nTemplateID)
        if cardConfig.nQuality == star then
            self:chooseCard(card.nID, true)
        end
    end
    self:refreshSelectedScrollView(false)
end

function KUIFactoryChooseCardNode:unChooseCardByStar(star)
    local cardList = self._showCardList
    for _, card in ipairs(cardList) do
        local cardConfig   = KUtil.getCardConfig(card.nTemplateID)
        if cardConfig.nQuality == star then
            self:chooseCard(card.nID, false)
        end
    end
    self:refreshSelectedScrollView(false)
end

function KUIFactoryChooseCardNode:registerAllTouchEvent()
    local mainNode = self._mainLayout

    --Home Button
    local nodeHome   = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome  = nodeHome:getChildByName("Panel_common_home")
    local buttonHome = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            buttonHome:setEnabled(false)
            self:playCloseAnimation(true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    --Close Button
    KUtil.updateResourceInfo(self, "xztk_base.png", function()
        self:playCloseAnimation(false)
    end )
    
    local imageControl        = mainNode:getChildByName("Image_common_base")
    local screenTypeButtons   = imageControl:getChildByName("Image_screen_base_1")
    screenTypeButtons:setVisible(false)
    local screenSortButtons   = imageControl:getChildByName("Image_screen_base_2")
    screenSortButtons:setVisible(false)

    local nodeBottomSelected  = imageControl:getChildByName("ProjectNode_selected")
    local panelSelected       = nodeBottomSelected:getChildByName("Panel_multi_choose_selected")

    local nodeBottom          = imageControl:getChildByName("ProjectNode_bottom")
    local panelBottom         = nodeBottom:getChildByName("Panel_tank_multi_choose_bottom")

    local buttonConfirm       = panelBottom:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmButton~")
            KSound.playEffect("click")
            self:ConfirmChoose()
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local buttonScreen        = imageControl:getChildByName("Button_screen")
    buttonScreen:setSwallowTouches(false)
    buttonScreen:setVisible(false)

    local function hideButtonScreen()
        buttonScreen:setVisible(false)
        if screenTypeButtons:isVisible() then
            KUtil.showUiScale(screenTypeButtons, false)
        end
        if screenSortButtons:isVisible() then
            KUtil.showUiScale(screenSortButtons, false)
        end
    end

    local buttonClean       = panelSelected:getChildByName("Button_cleanup")
    local function onCleanClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            for _, cardID in pairs(self._SelectedcardIDList) do
                local mainNode       = self._mainLayout
                local imageControl   = mainNode:getChildByName("Image_common_base")
                local projectNode    = imageControl:getChildByName("ProjectNode_card")
                local panelBase      = projectNode:getChildByName("Panel_1")
                local scrollViewList = panelBase:getChildByName("Scrollview_tank_list")
                local buttonCard     = scrollViewList:getChildByName(tostring(cardID))
                if buttonCard then
                    local frameButtom   = KUtil.getCardBaseActiveFrameButtom(buttonCard, cardID)
                    local buttonUnitPressPath, buttonUnitNormalPath, buttonUnitDisablePath = getButtonUnitPath(cardID)
                    frameButtom:loadTextures(buttonUnitNormalPath, buttonUnitPressPath, buttonUnitDisablePath)
                end
            end
            self._SelectedcardIDList = {}
            self:refreshSelectedScrollView(true)
            cclog("onCleanUpClick button~")
            hideButtonScreen()
        end
    end
    buttonClean:addTouchEventListener(onCleanClick)
    
    local buttonSort    = panelBottom:getChildByName("Button_common_sort")

    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(screenTypeButtons, false)
            local isVisible = not screenSortButtons:isVisible()
            KUtil.showUiScale(screenSortButtons, isVisible)
            KSound.playEffect("click")
            buttonScreen:setVisible(isVisible)
        end
    end
    buttonSort:addTouchEventListener(onSortClick)
    
    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            hideButtonScreen()
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)

    for type, button in pairs(m_SortButtonName) do
        local tempButton = screenSortButtons:getChildByName(button)
        local function onSortItemClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                KUtil.showUiScale(screenSortButtons, false)
                KSound.playEffect("click")
                self:sortByChooseType(type)
            end
        end
        tempButton:addTouchEventListener(onSortItemClick)
    end

    local buttonType = panelBottom:getChildByName("Button_common_type")
    local function onTypeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KUtil.showUiScale(screenSortButtons, false)
            local isVisible = not screenTypeButtons:isVisible()
            KUtil.showUiScale(screenTypeButtons, isVisible)
            KSound.playEffect("click")
            buttonScreen:setVisible(isVisible)
        end
    end
    buttonType:addTouchEventListener(onTypeClick)
    
    for type, button in pairs(m_tButtonType) do
        local tempButton = screenTypeButtons:getChildByName(button)
        local function onTypeItemClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                KUtil.showUiScale(screenTypeButtons, false)
                KSound.playEffect("click")
                self._tankType = type
                KSetting.setInt(KSetting.Key.BREAK_TEAM_CHOOSE_TYPE, self._tankType)
                UpdateShowList(self)
                refreshCardList(self, self._sortType, true)
                buttonScreen:setVisible(false)
            end
        end
        tempButton:addTouchEventListener(onTypeItemClick)
    end

    local projectNode    = imageControl:getChildByName("ProjectNode_star")
    local panelSarts     = projectNode:getChildByName("Panel_check_stars")
    for i = 1, MAX_CHECK_BOX do
        local panelClick = panelSarts:getChildByName("Panel_star_" .. i)
        local checkBox   = panelClick:getChildByName("CheckBox_stars")

        local star       = i
        local function onPanelClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                if checkBox:isSelected() then
                    checkBox:setSelected(false)
                    self:unChooseCardByStar(star)
                else
                    checkBox:setSelected(true)
                    self:chooseCardByStar(star)
                end
            end
        end
        panelClick:addTouchEventListener(onPanelClick)
    end
end

function KUIFactoryChooseCardNode:registerAllCustomEvent()
    local function onResourceUpdate()
        cclog("----------> onEvent onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIFactoryChooseCardNode:onCleanup()
end

return KUIFactoryChooseCardNode
