--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryDevelopLogNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/8/1  16:56
--  Contact     : liuzhen4@kingsoft.com
--  Comment     : 开发日志界面，暂时不需要
--  *********************************************************************


local KUIFactoryDevelopLogNode = class(
    "KUIFactoryDevelopLogNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryDevelopLogNode:ctor()
end

function KUIFactoryDevelopLogNode.create(owner)
    local currentNode = KUIFactoryDevelopLogNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_develop_log.csb"
    currentNode:init()

    return currentNode
end

function KUIFactoryDevelopLogNode:autoHandler()
    -- work for :
    -- 1.make self care about onEnter/onExit Event
    -- 2.run onEnter / onExit Action
    -- 3.addChild node to myself
    -- 4.call self:refreshUI()
    -- 5.register all touch event
    -- we must register all touch event after refreshUI(), because we could add item dynamic for scrollview list.
    --[[
    local function onNodeEvent(event)
        if "enter" == event then
            self:onEnter()
        end
        if "exit" == event then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
    ]]
    assert(self._mainLayout)
    self._mainLayout:setVisible(true)
    self:addChild(self._mainLayout, 1)

    --测试先忽略
    --self:refreshUI()
    --self:registerAllTouchEvent()
end

return KUIFactoryDevelopLogNode