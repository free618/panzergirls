--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryDevelopNode.lua
--  Creator     : LiuZhen
--  Date        : 2015/08/03   17:22
--  Contact     : liuzhen4@kingsoft.com
--  Comment     :
--  ********************************************************************


local MIN_RESOURCE_COUNT        = 10
local MAX_NUMBER_COUNT          = 9
local MIN_NUMBER_COUNT          = 0
local RESOURCES_TYPE_COUNT      = 4
local MAX_PANEL_BUTTON_COUNT    = 6
local MAX_PANEL_NUMBER_COUNT    = 3
local TOTAL_NUMBER_COUNT        = 10
local BUILDING_MATERIAL_ID      = 1
local maxEquipSize

local ADD_UNIT_FRAME            = 20
local REMOVE_UNIT_FRAME_START   = 50
local REMOVE_UNIT_FRAME         = 65

local GEAR_MAX_STAR_LEVEL       = 6
local MAX_RESOURCE_COUNT        = KConfig.systeminfo["equipMaxResource"].tValue[1]

local m_tDestResourceCount = {
        [1]   = {0, 1, 0},
        [2]   = {0, 1, 0},
        [3]   = {0, 1, 0},
        [4]   = {0, 1, 0},
}

local m_szGearTypeName     = {
    "主武器", 
    "副武器",
    "技能装备",
}

local KUIFactoryDevelopNode = class("KUIFactoryDevelopNode")

function KUIFactoryDevelopNode:ctor(owner, node)
    self._mainLayout        = node
    self._parent            = owner

    self._animationList     = {}
    self._eventList         = {}
    self._awardAction       = nil
    self:initData()
    self:refreshUI()
end

function KUIFactoryDevelopNode:initData()
    local nodeBuildTop          = self._mainLayout:getChildByName("ProjectNode_top")
    self._animationList.top     = KUtil.initAnimation(nodeBuildTop, "res/ui/animation_node/ani_develop_top.csb")
    local nodeButtonBottom      = self._mainLayout:getChildByName("ProjectNode_bottom")
    self._animationList.bottom  = KUtil.initAnimation(nodeButtonBottom, "res/ui/animation_node/ani_develop_buttom.csb")
    local nodeBuildContent      = self._mainLayout:getChildByName("ProjectNode_content")
    self._animationList.content = KUtil.initAnimation(nodeBuildContent, "res/ui/animation_node/ani_build_content.csb")

    self:registerAllTouchEvent()
    self:registerAllCustomEvent()
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    for _, animation in pairs(self._animationList) do
        KUtil.playEnterAnimation(animation)
    end
end

local function exitAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(false)

    local nDelayTime = 0
    for _, animation in pairs(self._animationList) do
        local nTime = KUtil.playQuitAnimation(animation)
        if nTime > nDelayTime then
            nDelayTime = nTime
        end
    end

    return nDelayTime
end

function KUIFactoryDevelopNode:enter()
    self:refreshMainInterface()
    enterAnimation(self)
end

function KUIFactoryDevelopNode:quit()
    return exitAnimation(self)
end

local function getBuildingMaterialCount()
    return KUtil.getItemCount(BUILDING_MATERIAL_ID)
end

local function getCurrentEquipCount()
    return #(KPlayer.tItemData.tEquipStoreHouse.tEquipList)
end

local function getAllGearInfo()
    return KConfig.equipInfo
end

local function getOneGearInfo(gearID)
    return getAllGearInfo()[gearID]
end

function KUIFactoryDevelopNode:refreshMainInterface()
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_top")
    local panelNode         = projectNode:getChildByName("Panel_1")

    local textBuildingMaterial = panelNode:getChildByName("Text_construct__value")
    textBuildingMaterial:setString("" .. getBuildingMaterialCount())

    local currentEquipCount = getCurrentEquipCount()
    local textStorageSize  = panelNode:getChildByName("Text_contant_value")
    textStorageSize:setString("".. currentEquipCount .. "/" .. maxEquipSize)
end

local function refreshResourceArea(self)
    local mainNode            = self._mainLayout
    local projectNodeBottom   = mainNode:getChildByName("ProjectNode_bottom")
    local panelBuild          = projectNodeBottom:getChildByName("Panel_1")
    local buttonStartBuilding = panelBuild:getChildByName("Button_start_build")
    local arrayResourceValue  = {}

    for k,v in pairs(m_tDestResourceCount) do
        local currentResourceValue = v[1] * 100 + v[2] * 10 + v[3]
        arrayResourceValue[k] = currentResourceValue
    end

    for panelResourceIndex = 1, RESOURCES_TYPE_COUNT do
        local panelResourceName   = "Panel_resources_" .. panelResourceIndex
        local projectNodeContent  = mainNode:getChildByName("ProjectNode_content")
        local panelContent        = projectNodeContent:getChildByName("Panel_ani_build_content")
        local panelResource       = panelContent:getChildByName(panelResourceName)
        local panelNumber         = panelResource:getChildByName("Panel_number")
        for panelNumberIndex = 1, MAX_PANEL_NUMBER_COUNT do
            local panelSingleNumberName = "Panel_number_" .. panelNumberIndex
            local panelSingleNumber     = panelNumber:getChildByName(panelSingleNumberName)
            local currentResourceValue  = m_tDestResourceCount[panelResourceIndex][panelNumberIndex]
            for numberIndex = 1, TOTAL_NUMBER_COUNT do
                local imageRealIndex    = numberIndex - 1
                local imageNumberName   = "Image_number_" .. imageRealIndex
                local imageNumber       = panelSingleNumber:getChildByName(imageNumberName)
                local imageVisible      = false
                if imageRealIndex == currentResourceValue then imageVisible = true end
                imageNumber:setVisible(imageVisible)
            end
        end
    end

    local tButtonTexturePath =
        {
            ["buttonNormalTexture"]  = "res/ui/ui_material/build/button_currency.png",
            ["buttonPressTexture"]   = "res/ui/ui_material/build/button_currency_active.png",
            ["buttonDisableTexture"] = "res/ui/ui_material/build/button_currency_disable.png"
        }

    local startBuildingButtonFlag = true
    for k, v in pairs(arrayResourceValue) do
        if v < MIN_RESOURCE_COUNT or v > MAX_RESOURCE_COUNT then
            startBuildingButtonFlag = false
        end
    end

    --KUtil.setTouchEnabled(buttonStartBuilding, startBuildingButtonFlag)

    if not startBuildingButtonFlag then
        buttonStartBuilding:loadTextures(tButtonTexturePath.buttonDisableTexture,
            tButtonTexturePath.buttonDisableTexture,
            tButtonTexturePath.buttonDisableTexture)
    else
        buttonStartBuilding:loadTextures(tButtonTexturePath.buttonNormalTexture,
            tButtonTexturePath.buttonPressTexture,
            tButtonTexturePath.buttonDisableTexture)
    end
end

local function hideAwardAnimation(self)
    local mainNode      = self._mainLayout
    local nodeAwardGear = mainNode:getChildByName("ProjectNode_award_gear")
    nodeAwardGear:setVisible(false)
    nodeAwardGear:stopAllActions()
end

local function isNewGear(gearID)
    local equipList = KPlayer.tItemData.tHistoricalEquipID
    local isNew = true

    for _, equipID in ipairs(equipList) do
        if equipID == gearID then
            isNew = false
            break
        end
    end
    return isNew
end

local function refreshGearbase(self, gearID)
    local awardGearInfo   = getOneGearInfo(gearID)
    local awardGearGrade  = awardGearInfo.nGrade
    local awardGearName   = awardGearInfo.szName
    local equipPath       = KUtil.getEquipImagePathByID(gearID)
    local mainNode        = self._mainLayout
    local nodeAwardGear   = mainNode:getChildByName("ProjectNode_award_gear")
    local panelAwardGear  = nodeAwardGear:getChildByName("Panel_ani_award_gear")
    local panelGear       = panelAwardGear:getChildByName("ProjectNode_gearbase")

    local gearBase        = panelAwardGear:getChildByName("Node_gearbase")
    local panelGear       = gearBase:getChildByName("Panel_gear")
    local imageGear       = panelGear:getChildByName("Image_gear")
    imageGear:loadTexture(equipPath, ccui.TextureResType.localType)

    local panelNewBase    = panelAwardGear:getChildByName("Panel_new")
    local newState        = isNewGear(gearID)
    panelNewBase:setVisible(newState)

    local panelBackground = panelAwardGear:getChildByName("Panel_bg")
    for num = 1, GEAR_MAX_STAR_LEVEL do
        local backgroundName  = "Image_jl_bg_" .. num
        local imageBackground = panelBackground:getChildByName(backgroundName)
        if num ~= awardGearGrade then
            imageBackground:setVisible(false)
        else
            imageBackground:setVisible(true)
        end
    end
end

local function refreshDialog(self, gearID)
    local mainNode        = self._mainLayout
    local nodeAwardGear   = mainNode:getChildByName("ProjectNode_award_gear")
    local panelAwardGear  = nodeAwardGear:getChildByName("Panel_ani_award_gear")
    local panelDialog     = panelAwardGear:getChildByName("Panel_card_frame_buttom")

    local awardGearInfo   = getOneGearInfo(gearID)
    local awardGearType   = awardGearInfo.nEquipType
    local awardGearName   = awardGearInfo.szName
    local awardGearGrade  = awardGearInfo.nGrade
    local attributeList   = {}
    
    if KUtil.isSkillEquip(gearID) then
        attributeList = KUtil.getSkillDescriptionList(gearID)
        attributeList = KUtil.skillAttributeListForamtValue(attributeList, gearID)
    else
        attributeList = KUtil.getEquipDescription(gearID)
    end

    local awardGearDesc   = KUtil.getEquipDescriptionFormat(attributeList, "  ")
    local textGearName    = panelDialog:getChildByName("Text_gear_name")
    textGearName:setString(awardGearName)

    local panelStar
    if awardGearGrade % 2 == 0 then
        local panelStar1       = panelDialog:getChildByName("Panel_gear_star_1")
        local panelStar2       = panelDialog:getChildByName("Panel_gear_star_2")
        panelStar1:setVisible(true)
        panelStar2:setVisible(false)
        panelStar = panelStar1
    else
        local panelStar1       = panelDialog:getChildByName("Panel_gear_star_1")
        local panelStar2       = panelDialog:getChildByName("Panel_gear_star_2")
        panelStar1:setVisible(false)
        panelStar2:setVisible(true)
        panelStar = panelStar2
    end

    for starCount = 1, GEAR_MAX_STAR_LEVEL do
        local starImageControl = panelStar:getChildByName("Image_star_" .. starCount)
        if starImageControl then
            starImageControl:setVisible(starCount <= awardGearGrade)
        end
    end

    local textDescription = panelDialog:getChildByName("Text_attribute_value")
    textDescription:setString(awardGearDesc)
end

local function runAwardAnimation(self)
    local mainNode      = self._mainLayout
    local nodeAwardGear = mainNode:getChildByName("ProjectNode_award_gear")
    nodeAwardGear:setVisible(true)
    local awardAction = cc.CSLoader:createTimeline("res/ui/animation_node/ani_award_gear.csb")
    self._awardAction = awardAction
    nodeAwardGear:stopAllActions()
    nodeAwardGear:runAction(awardAction)
    local endFrame = 200 
    awardAction:gotoFrameAndPlay(0, endFrame, false)
end

local function refreshAwardUI(self, gearID)
    self._parent:playQuitAnimation()
    local mainNode        = self._mainLayout
    local nodeAwardGear   = mainNode:getChildByName("ProjectNode_award_gear")
    nodeAwardGear:stopAllActions()

    local awardGearInfo   = getOneGearInfo(gearID)
    local awardGearGrade  = awardGearInfo.nGrade

    refreshGearbase(self, gearID)
    refreshDialog(self, gearID)
    runAwardAnimation(self)

    KSound.playEffect("getCardPrompt")
end

function KUIFactoryDevelopNode:resetResourceArea(nodeData)
    m_tDestResourceCount[1] = KUtil.getFormatResource(nodeData.oil)
    m_tDestResourceCount[2] = KUtil.getFormatResource(nodeData.ammo)
    m_tDestResourceCount[3] = KUtil.getFormatResource(nodeData.steel)
    m_tDestResourceCount[4] = KUtil.getFormatResource(nodeData.people)
    refreshResourceArea(self)
end

function KUIFactoryDevelopNode:refreshUI()
    maxEquipSize              = KPlayer.tItemData.tEquipStoreHouse.nMaxSize
    
    cclog("----------------refreshUI")
    self:refreshMainInterface()
    refreshResourceArea(self)
    hideAwardAnimation(self)
end

local function disableBuildingButton(self)
    local tButtonTexturePath =
        {
            ["buttonNormalTexture"]  = "res/ui/ui_material/build/jz_start_button.png",
            ["buttonPressTexture"]   = "res/ui/ui_material/build/jz_start_button_active.png",
            ["buttonDisableTexture"] = "res/ui/ui_material/build/jz_start_button_disable.png"
        }

    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local panelBuild        = projectNodeBottom:getChildByName("Panel_1")
    local buttonControl     = panelBuild:getChildByName("Button_start_build")
    --KUtil.setTouchEnabled(buttonControl, false)
    buttonControl:loadTextures(tButtonTexturePath.buttonPressTexture,
        tButtonTexturePath.buttonPressTexture,
        tButtonTexturePath.buttonPressTexture)
end

local function enableBuildingButton(self)
    local tButtonTexturePath =
        {
            ["buttonNormalTexture"]  = "res/ui/ui_material/build/jz_start_button.png",
            ["buttonPressTexture"]   = "res/ui/ui_material/build/jz_start_button_active.png",
            ["buttonDisableTexture"] = "res/ui/ui_material/build/jz_start_button_disable.png"
        }

    local mainNode          = self._mainLayout
    local projectNodeBottom = mainNode:getChildByName("ProjectNode_bottom")
    local panelBuild        = projectNodeBottom:getChildByName("Panel_1")
    local buttonControl     = panelBuild:getChildByName("Button_start_build")
    --KUtil.setTouchEnabled(buttonControl, true)
    buttonControl:loadTextures(tButtonTexturePath.buttonNormalTexture,
        tButtonTexturePath.buttonPressTexture,
        tButtonTexturePath.buttonDisableTexture)
    self._parent:enterAnimation()
end

function KUIFactoryDevelopNode:beganBuild()
    local isSuccess  = true
    for i = 1, RESOURCES_TYPE_COUNT do
        local consumeNum = m_tDestResourceCount[i][1] * 100 + m_tDestResourceCount[i][2] * 10 + m_tDestResourceCount[i][3]
        if MAX_RESOURCE_COUNT < consumeNum then
            isSuccess = false
            showNoticeByID("factorylog.cannot_exceed", MAX_RESOURCE_COUNT)
            break
        end
    end

    local consumeNum = {}
    for i = 1, RESOURCES_TYPE_COUNT do
        consumeNum[i] = m_tDestResourceCount[i][1] * 100 + m_tDestResourceCount[i][2] * 10 + m_tDestResourceCount[i][3]
        if KPlayer[CURRENCY_KEY[i]] < consumeNum[i] then
            isSuccess = false
            showNoticeByID("common.lessResource", KUtil.getStringByKey("common."..CURRENCY_KEY[i]))
            break
        end
    end
    cclog("beganBuild:",KUtil.getItemConfigValue(BUILDING_MATERIAL_ID, "szName"))

    if isSuccess and getBuildingMaterialCount() <= 0 then
        isSuccess = false
        showNoticeByID("common.lessResource", KUtil.getItemConfigValue(BUILDING_MATERIAL_ID, "szName"))
    end

    if isSuccess and getCurrentEquipCount() >= maxEquipSize then
        isSuccess = false
        showNoticeByID("common.EquipStoreFull")
    end

    if isSuccess then
        cclog("---------------------------> KUIBuildNode:beganBuild:")
        require("src/network/KC2SProtocolManager"):produceEquip(consumeNum[1], consumeNum[2], consumeNum[3], consumeNum[4])

        disableBuildingButton(self)
    end
end

local function changeResourceByKind(self, resourceType, resourceIndex, shouldAdd)
    local resourceInfo = m_tDestResourceCount[resourceType]
    assert(resourceInfo ~= nil, "Get resourceInfo Failed~")

    local resourceValue = resourceInfo[resourceIndex]
    assert(resourceValue ~= nil, "Get resourceValue Failed~")

    if not shouldAdd then
        resourceValue = resourceValue - 1
        if resourceValue < MIN_NUMBER_COUNT then resourceValue = MAX_NUMBER_COUNT end
    else
        resourceValue = resourceValue + 1
        if resourceValue > MAX_NUMBER_COUNT then resourceValue = MIN_NUMBER_COUNT end
    end
    resourceInfo[resourceIndex] = resourceValue

    refreshResourceArea(self)
end

function KUIFactoryDevelopNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_top")
    local panelNode         = projectNode:getChildByName("Panel_1")
    local buttonControl     = panelNode:getChildByName("Button_log_button")
    local function onLogClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onLogButton~")
            KSound.playEffect("click")
            self._parent._parent:addNode("EquipLog")
        end
    end
    buttonControl:addTouchEventListener(onLogClick)

    local projectNodeBottom   = mainNode:getChildByName("ProjectNode_bottom")
    local panelBuild          = projectNodeBottom:getChildByName("Panel_1")
    local buttonControl       = panelBuild:getChildByName("Button_start_build")
    local function onStartBuildClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("startBuilding")
            self:beganBuild()
            cclog("click onStartBuildButton~")
        end
    end
    buttonControl:addTouchEventListener(onStartBuildClick)

    local buttonControl       = panelNode:getChildByName("Button_reset")
    local function onResetClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            for k, v in pairs(m_tDestResourceCount) do
                v[1] = 0
                v[2] = 1
                v[3] = 0
            end
            refreshResourceArea(self)
        end
    end
    buttonControl:addTouchEventListener(onResetClick)

    for panelResourcesID = 1, RESOURCES_TYPE_COUNT do
        local panelResourcesName  = "Panel_resources_" .. panelResourcesID
        local projectNodeContent  = mainNode:getChildByName("ProjectNode_content")
        local panelContent        = projectNodeContent:getChildByName("Panel_ani_build_content")
        local panelResource       = panelContent:getChildByName(panelResourcesName)
        for panelButtonID = 1, MAX_PANEL_BUTTON_COUNT do
            local panelButton     = panelResource:getChildByName("Panel_button")
            local panelButtonName = "Button_" .. panelButtonID
            local buttonControl   = panelButton:getChildByName(panelButtonName)
            local function onButtonClick(sender, type)
                if type == ccui.TouchEventType.ended then
                    KSound.playEffect("click")
                    local resourceIndex = panelButtonID
                    local shouldAdd     = true
                    if resourceIndex > MAX_PANEL_NUMBER_COUNT then
                        resourceIndex = resourceIndex - MAX_PANEL_NUMBER_COUNT
                        shouldAdd     = false
                    end
                    changeResourceByKind(self, panelResourcesID, resourceIndex, shouldAdd)
                end
            end
            buttonControl:addTouchEventListener(onButtonClick)
        end
    end
    
    local nodeAwardGear     = mainNode:getChildByName("ProjectNode_award_gear")
    local panelAwardGear    = nodeAwardGear:getChildByName("Panel_ani_award_gear")
    local buttonScreen      = panelAwardGear:getChildByName("Button_screen")
    local function onScreenClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if not self._awardAction then return end
        if self._awardAction:isPlaying() then
            local endFrame       = 200
            self._awardAction:setCurrentFrame(endFrame)
        else
            nodeAwardGear:setVisible(false)
            self._awardAction = nil
            enableBuildingButton(self)
        end
    end
    buttonScreen:addTouchEventListener(onScreenClick)
end

function KUIFactoryDevelopNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onEquipBuild(gearID)
        cclog("onEvent ----------> onDevelopEquipsFinish")
        refreshAwardUI(self, gearID)
        self:refreshMainInterface()
    end
    self._parent:addCustomEvent(eventDispatchCenter.EventType.NET_BUILD_EQUIP, onEquipBuild)
end

return KUIFactoryDevelopNode
