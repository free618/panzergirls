--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryGearMultiChooseNode.lua
--  Creator     : HuangYiXin
--  Date        : 2015/08/02   10:20
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_EQUIP_LEVEL   = 6
local MAX_CHECK_BOX     = 6
local CLICK_DELAY_FRAME = 30

local m_tButtonName = {"Button_name", "Button_star", "Button_level", "Button_time"}
local KSetting = require("src/logic/KSetting")
local m_tEquipSortName = {
    [1] = "name",
    [2] = "star",
    [3] = "level",
    [4] = "time",
    [5] = "type",
}

local m_tEquipSortDataName = {
    [1] = "szName",
    [2] = "nGrade",
    [3] = "nGrade",
    [4] = "time",
}

local m_tEquipPropertyName = {
    [1] = "nAttack",
    [2] = "nPenetrate",
    [3] = "nSpeed",
    [4] = "nFrontArmour",
    [5] = "nRearArmour",
    [6] = "nScout",
    [7] = "nDodge",
    [8] = "nHide",
    [9] = "nNightBattle",
    [10] = "nRange",
    [11] = "nHitRate",
    [12] = "nCrit"
}

local m_tEquipPropertyDescription = {
    [1] = "火力",
    [2] = "穿透",
    [3] = "速度",
    [4] = "前甲",
    [5] = "后甲",
    [6] = "侦查",
    [7] = "回避",
    [8] = "隐蔽",
    [9] = "夜战",
    [10] = "射程",
    [11] = "命中",
    [12] = "暴击"
}

local m_tButtonStateTexture = {
    ["buttonNormalTexture"]   = "res/ui/ui_material/public/dj_unit_base.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/public/dj_unit_base_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/public/dj_unit_base.png",
}

local m_tBouttonTexture =
{
    ["normal"]   = "res/ui/ui_material/public/common_lock_open.png", 
    ["press"]    = "res/ui/ui_material/public/common_lock.png", 
    ["disable"]  = "res/ui/ui_material/public/common_lock_open.png",
}

local KUIFactoryGearMultiChooseNode = class(
    "KUIFactoryGearMultiChooseNode", function () return require("src/ui/uibase/KUINodeBase.lua").create() end
)

function KUIFactoryGearMultiChooseNode:ctor()
    self._mainLayout               = nil
    self._parent                   = nil
    self._uiPath                   = nil
    self._preNodeType              = nil

    self._originScrollChosenHeight = nil
    self._originScrollEquipHeight  = nil
    self._textChosenUnitBase       = nil
    self._buttonEquipUnitBase      = nil
    self._sortType                 = KSetting.getInt(KSetting.Key.EQUIP_BREAK_CHOOSE_COMMON, KUtil.CHOOSE_COMMON_TYPE.NAME)

    self._chosenEquipList          = {}
    self._oneEquipList             = {}
    self._updateTimes              = 0
    self._pageData                 = {}
    self._animationList            = {}
end

function KUIFactoryGearMultiChooseNode.create(owner, nodeData)
    local currentNode = KUIFactoryGearMultiChooseNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_gear_multi_choose.csb"
    currentNode._preNode = nodeData.preNode
    currentNode:setChosenEquipIDList(nodeData.chosenEquipIDList)
    currentNode:init()

    return currentNode
end

local function getEquipList()
    return KPlayer.tItemData.tEquipStoreHouse.tEquipList
end

local function getMaxEquipSize()
    return KPlayer.tItemData.tEquipStoreHouse.nMaxSize
end

local function getEquipInfoList()
    return KConfig.equipInfo
end

local function getEquipInfo(equipID)
    return KConfig.equipInfo[equipID]
end

local function getChooseIndexByID(self, nID)
    for index, oneEquipInfo in ipairs(self._chosenEquipList) do
        if oneEquipInfo.oneEquip.nID == nID then return index end
    end
    return 0
end

local function refreshTop(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_buttom")
    local aniPanel          = projectNode:getChildByName("Panel_1")

    local buttonCommonSort  = aniPanel:getChildByName("Button_zb_sort")
    local currentSortName   = "Image_sort_" .. m_tEquipSortName[self._sortType]
    buttonCommonSort:getChildByName(currentSortName):setVisible(true)

    local imageContant      = aniPanel:getChildByName("Image_contant_value")
    local textContantValue  = imageContant:getChildByName("Text_contant_quantity")
    local equipList         = getEquipList()
    local equipCount        = #equipList
    local maxEquipSize      = getMaxEquipSize()

    textContantValue:setString(equipCount .. "/" .. maxEquipSize)
end

local function refreshEquipItem(self, nID, isChoose)
    local  buttonEquipUnit  = self._scrollGearControl:getChildByName(tostring(nID)) 
    if not buttonEquipUnit then return end
    if isChoose then
        buttonEquipUnit:loadTextureNormal(m_tButtonStateTexture.buttonPressTexture, ccui.TextureResType.localType)
    else
        buttonEquipUnit:loadTextures(m_tButtonStateTexture.buttonNormalTexture, ccui.TextureResType.localType)
    end
end

local function unChooseAllEquip(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_top")
    local panelSarts        = projectNode:getChildByName("Panel_check_stars")

    -- reset check box
    for i = 1, MAX_CHECK_BOX do
        local checkBox = panelSarts:getChildByName("CheckBox_stars_" .. i)
        checkBox:setSelected(false)  
    end
    -- reset select list
    for _, oneEquip in ipairs(self._oneEquipList) do
        refreshEquipItem(self, oneEquip.nID, false)
    end
    self._chosenEquipList = {}
    self:refreshScrollControlChoose()
end

local function unChooseEquip(self, nID)
    local chosenEquipList = self._chosenEquipList
    local chosenIndex = getChooseIndexByID(self, nID)
    if chosenIndex == 0 then return end
    table.remove(chosenEquipList, chosenIndex)
    refreshEquipItem(self, nID, false)
    self:refreshScrollControlChoose()
end

local function chooseEquip(self, oneEquip, equipName)
    local chosenEquipList = self._chosenEquipList
    table.insert(chosenEquipList, { ["oneEquip"] = oneEquip, ["name"] = equipName, nID = oneEquip.nID})
    refreshEquipItem(self, oneEquip.nID, true)
    self:refreshScrollControlChoose()
end

function KUIFactoryGearMultiChooseNode:chooseEquipByStar(star)
    local chosenEquipList = self._chosenEquipList
    local insertMap       = {}
    for _, oneEquipInfo in ipairs(chosenEquipList) do
        insertMap[oneEquipInfo.oneEquip.nID] = true
    end
    for _, oneEquip in ipairs(self._oneEquipList) do
        local equipConfig = KConfig.equipInfo[oneEquip.nTemplateID]
        local equipName   = equipConfig.szName
        if equipConfig.nGrade == star and not insertMap[oneEquip.nID] and not oneEquip.bLock then
            table.insert(chosenEquipList, { ["oneEquip"] = oneEquip, ["name"] = equipName, nID = oneEquip.nID})
            refreshEquipItem(self, oneEquip.nID, true)
        end
    end
    self:refreshScrollControlChoose()
end

function KUIFactoryGearMultiChooseNode:unChooseEquipByStar(star)
    local chosenEquipList = self._chosenEquipList
    local insertMap       = {}
    local removeMap       = {}
    for index, oneEquipInfo in ipairs(self._chosenEquipList) do
        insertMap[oneEquipInfo.oneEquip.nID] = index
    end
    for _, oneEquip in ipairs(self._oneEquipList) do
        local equipConfig = KConfig.equipInfo[oneEquip.nTemplateID]
        local equipName   = equipConfig.szName
        if equipConfig.nGrade == star and insertMap[oneEquip.nID] then
            removeMap[oneEquip.nID] = true
            refreshEquipItem(self, oneEquip.nID, false)
        end
    end
    -- remove by list
    local length = #chosenEquipList
    for index = length, 1, -1 do
        local oneEquipInfo = chosenEquipList[index]
        if removeMap[oneEquipInfo.oneEquip.nID] then
            table.remove(chosenEquipList, index)
        end
    end
    self:refreshScrollControlChoose()
end

function KUIFactoryGearMultiChooseNode:setLockButton(buttonEquipUnit, isLock)
    if not buttonEquipUnit then return end
    local button = buttonEquipUnit:getChildByName("Button_lock")
    if isLock then
        button:loadTextures(m_tBouttonTexture["press"], m_tBouttonTexture["normal"], m_tBouttonTexture["disable"])
    else
        button:loadTextures(m_tBouttonTexture["normal"], m_tBouttonTexture["press"], m_tBouttonTexture["disable"])
    end
    buttonEquipUnit.bIsLock = isLock
    local imageDisable = buttonEquipUnit:getChildByName("Image_zb_gear_disable")
    imageDisable:setVisible(false)
end

function KUIFactoryGearMultiChooseNode:updateScrollEquipItemByEquip(buttonEquipUnit, oneEquip)
    assert(buttonEquipUnit, "buttonEquipUnit")
    assert(oneEquip, "oneEquip")

    buttonEquipUnit:setName(tostring(oneEquip.nID))
    -- update lock
    buttonEquipUnit.bIsLock = oneEquip.bLock
    self:setLockButton(buttonEquipUnit, oneEquip.bLock)
    -- get data
    local equipData         = getEquipInfo(oneEquip.nTemplateID)
    assert(equipData, "equipData,"..oneEquip.nTemplateID)
    
    local chosenIndex       = getChooseIndexByID(self, oneEquip.nID)

    -- equip name
    local panelEquipName    = buttonEquipUnit:getChildByName("Panel_gear_name")
    local textEquipName     = panelEquipName:getChildByName("Text_gear_name")
    local equipName         = equipData["szName"]
    textEquipName:setString(equipName)

    -- equip button click
    local function onEquipUnitClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if buttonEquipUnit.bIsLock then return end
        cclog("-----> onEquipUnitClick~")
        KSound.playEffect("click")
        local chosenIndex = getChooseIndexByID(self, oneEquip.nID)
        if chosenIndex ~= 0 then
            unChooseEquip(self, oneEquip.nID)
        else
            chooseEquip(self, oneEquip, equipName)
        end
    end
    buttonEquipUnit:addTouchEventListener(onEquipUnitClick)

    local panelGearIcon = buttonEquipUnit:getChildByName("Panel_gear_icon")
    for equipType = 1, MAX_EQUIP_LEVEL do
        local imageGearLevelName = "Image_common_gear_level" .. equipType
        local imageLevel = panelGearIcon:getChildByName(imageGearLevelName)
        imageLevel:setVisible(equipType == equipData.nGrade)
    end

    if chosenIndex ~= 0 then
        buttonEquipUnit:loadTextureNormal(m_tButtonStateTexture.buttonPressTexture, ccui.TextureResType.localType)
    else
        buttonEquipUnit:loadTextures(m_tButtonStateTexture.buttonNormalTexture, ccui.TextureResType.localType)
    end
    
    -- equip image
    local imageGear = panelGearIcon:getChildByName("Image_gear")
    local imagePath = equipData["szResPath"]
    local realImagePath = KUtil.getEquipImagePathByID(oneEquip.nTemplateID)
    imageGear:loadTexture(realImagePath, ccui.TextureResType.localType)

    -- equip data text
    local PanelGear     = buttonEquipUnit:getChildByName("Panel_gear_data")
    local tNatureText   = {}

    local nTemplateID = oneEquip.nTemplateID
    if KUtil.isSkillEquip(nTemplateID) then
        tNatureText = KUtil.getSkillDescriptionList(nTemplateID)
        KUtil.skillAttributeListForamtValue(tNatureText, nTemplateID)
    else
        tNatureText = KUtil.getEquipDescription(nTemplateID)
    end
    
    local textGearName   = PanelGear:getChildByName("Text_gear_attribute5")
    for i=1, 4 do
        local textGearData  = PanelGear:getChildByName("Text_gear_attribute"..i)
        local textGearValue  = PanelGear:getChildByName("Text_gear_attribute_value"..i)
        if tNatureText[i] then
            textGearData:setString(tNatureText[i][1])
            textGearData:setVisible(true)
            if tNatureText[i][2] then
                textGearValue:setString(tNatureText[i][2])
                textGearValue:setVisible(true)
            else
                textGearValue:setVisible(false)
            end
        else
            textGearData:setVisible(false)
            textGearValue:setVisible(false)
        end
        if i == 1 then
            if KUtil.isSkillEquip(nTemplateID) then
                textGearData:setVisible(false)
                textGearValue:setVisible(false)
                if tNatureText[i] then
                    textGearName:setString(tNatureText[i][1])
                    textGearName:setVisible(true)
                end
            else
                textGearName:setVisible(false)
            end
        end
    end

    --lock Click Event
    local buttonLock = buttonEquipUnit:getChildByName("Button_lock")
    local function onLockClick(sender, type)
        if ccui.TouchEventType.ended == type then
            KSound.playEffect("click")
            local isLock = not buttonEquipUnit.bIsLock
            self:setLockButton(buttonEquipUnit, isLock)
            if(isLock) then unChooseEquip(self, oneEquip.nID) end
            require("src/network/KC2SProtocolManager"):lockEquip(oneEquip.nID, not oneEquip.bLock)
        end
    end
    buttonLock:addTouchEventListener(onLockClick)
end

function KUIFactoryGearMultiChooseNode:getSortedOneEquipList(self, oneEquipList)
    local equipDataList     = getEquipInfoList()
    local currentSortName   = m_tEquipSortDataName[self._sortType]
    if currentSortName == "time" then
        -- sort by time
        local function sortByTime(first, second)
            local firstValue = first.nCreateTime
            local secondValue = second.nCreateTime
            if firstValue == nil or secondValue == nil then
                return true
            end
            return firstValue > secondValue
        end
        table.sort(oneEquipList, sortByTime)
        return oneEquipList
    end

    -- sort by indicated data type
    local function sortBy(first, second)
        local firstValue = equipDataList[first.nTemplateID][currentSortName]
        local secondValue = equipDataList[second.nTemplateID][currentSortName]
        return firstValue < secondValue
    end
    table.sort(oneEquipList, sortBy)
    return oneEquipList
end

local function addScrollPageView(self, isCutIn)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_gear_list")
    local panelNode         = projectNode:getChildByName("Panel_select_content")
    local slideView         = panelNode:getChildByName("Slider_scroll_list")

    local oneEquipList      = self:getSortedOneEquipList(self, self._oneEquipList)

    local refreshCall = function(control, dataInfo)
        self:updateScrollEquipItemByEquip(control, dataInfo)
    end

    local parameters = {
        scrollView  = self._scrollGearControl,
        slideView   = slideView,
        itemBase    = self._buttonEquipUnitBase,
        dataList    = oneEquipList,
        refreshCall = refreshCall,
        column      = 3,
        row         = 6,
        isCutIn     = isCutIn,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function addChooseScrollPageView(self, isCutIn)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectGearInfo   = imageCommonBase:getChildByName("ProjectNode_gear_info")
    local panelMultiChoose  = projectGearInfo:getChildByName("Panel_multi_choose_selected")

    local scrollViewChosen  = panelMultiChoose:getChildByName("Scrollview_chosen_list")

    local refreshCall = function(control, dataInfo)
        local textGearName  = control:getChildByName("Text_tank_name")
        textGearName:setString(dataInfo.name)
        local textTankNumber = control:getChildByName("Text_tank_number")
        textTankNumber:setVisible(false)
    end

    local parameters = {
        scrollView  = scrollViewChosen,
        slideView   = slideView,
        itemBase    = self._textChosenUnitBase,
        dataList    = self._chosenEquipList,
        refreshCall = refreshCall,
        column      = 1,
        row         = 15,
        isCutIn     = isCutIn,
    }
    self._choosePageData = KUtil.addDynamicScrollView(parameters)
end

function KUIFactoryGearMultiChooseNode:refreshScrollViewChosen(isCutIn)
    addChooseScrollPageView(self, isCutIn)
end

local function initEquipList(self)
    local canNotBreakMap = {}
    local cardList = KPlayer.tCardData.tStoreHouse.tCardList
    for _, oneCard in pairs(cardList) do
        for _, oneCardEquip in pairs(oneCard.tEquipList) do
            canNotBreakMap[oneCardEquip.nEquipID] = true
        end
    end

    for _, oneSkill in pairs(KPlayer.tSkillList) do
        canNotBreakMap[oneSkill.nEquipID] = true
    end

    self._oneEquipList = {}
    local allEquipList  = getEquipList()
    for index, oneEquip in ipairs(allEquipList) do
        if not canNotBreakMap[oneEquip.nID] and KConfig.equipBreakDownInfo[oneEquip.nTemplateID] then
            table.insert(self._oneEquipList, oneEquip)
        end
    end
end
local function initUI(self)
    local mainNode            = self._mainLayout
    local imageCommonBase     = mainNode:getChildByName("Image_common_base")

    local projectNode         = imageCommonBase:getChildByName("ProjectNode_gear_list")
    local panelNode           = projectNode:getChildByName("Panel_select_content")
    self._scrollGearControl   = panelNode:getChildByName("ScrollView_gear_list")
    self._buttonEquipUnitBase = self._scrollGearControl:getChildByName("Button_gear_unit")

    -- update equip is equiped image
    local panelGearIcon       = self._buttonEquipUnitBase:getChildByName("Panel_gear_icon")
    local imageEquipWord      = panelGearIcon:getChildByName("Image_zb_equip_word")
    imageEquipWord:setVisible(false)

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)
    self._buttonEquipUnitBase:removeFromParent(false)
    node:addChild(self._buttonEquipUnitBase)

    -- retain selected scroll
    local projectGearInfo     = imageCommonBase:getChildByName("ProjectNode_gear_info")
    local panelMultiChoose    = projectGearInfo:getChildByName("Panel_multi_choose_selected")

    local scrollViewChosen    = panelMultiChoose:getChildByName("Scrollview_chosen_list")
    self._textChosenUnitBase  = scrollViewChosen:getChildByName("Image_tank_base")
    self._textChosenUnitBase:removeFromParent(false)
    node:addChild(self._textChosenUnitBase)

    local screenTypeButtons   = imageCommonBase:getChildByName("Image_screen_base_1")
    screenTypeButtons:setVisible(false)
    local screenSortButtons   = imageCommonBase:getChildByName("Image_screen_base_2")
    screenSortButtons:setVisible(false)
end

local function hideAllUI(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_buttom")
    local aniPanel          = projectNode:getChildByName("Panel_1")
    local buttonCommonSort  = aniPanel:getChildByName("Button_zb_sort")

    for i = 1 , #m_tEquipSortName do
        local imageSortName = "Image_sort_" .. m_tEquipSortName[i]
        local imageSort     = buttonCommonSort:getChildByName(imageSortName)
        imageSort:setVisible(false)
    end
end

local function refreshList(self, isCutIn)
    hideAllUI(self)
    refreshTop(self)
    addScrollPageView(self, isCutIn)
    self:refreshScrollViewChosen()
end

function KUIFactoryGearMultiChooseNode:setChosenEquipIDList(chosenEquipIDList)
    self._chosenEquipList = {}
    local chosenEquipList = self._chosenEquipList
    local oneEquipList    = getEquipList()
    local equipDataList   = getEquipInfoList()
    for _, nID in pairs(chosenEquipIDList) do
        local oneEquip = HArray.FindFirst(oneEquipList, "nID", nID)
        local equipName = equipDataList[oneEquip.nTemplateID]["szName"]
        table.insert(chosenEquipList, { ["oneEquip"] = oneEquip, ["name"] = equipName, nID = nID})
    end
end

function KUIFactoryGearMultiChooseNode:refreshScrollControlChoose()
    self:refreshScrollViewChosen()    
end

function KUIFactoryGearMultiChooseNode:activate(nowTime)
    self._updateTimes = self._updateTimes + 1
end

function KUIFactoryGearMultiChooseNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIFactoryGearMultiChooseNode:closeAnimation(isReturnOffice)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local delayTime1 = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        delayTime = math.max(delayTime, delayTime1)
    end
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "GearMultiChoose", callBacks, isReturnOffice)
end

function KUIFactoryGearMultiChooseNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")

    local list              = self._animationList
    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_list")
    list.gearList           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_content.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_top")
    list.top                = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_top.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_info")
    list.gearSelected       = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_multi_choose_selected.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_buttom")
    list.buttom             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_multi_choose_bottom.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_resource_base")
    list.resourceBase       = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_resource_base.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_button_home")
    list.home               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_home.csb"), {0, 30, 40, 65}}
end

function KUIFactoryGearMultiChooseNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUIFactoryGearMultiChooseNode:onInitUI()
    self:onInitAnimation()
end

function KUIFactoryGearMultiChooseNode:refreshUI()
    initEquipList(self)
    initUI(self)
    refreshList(self, false)
end

function KUIFactoryGearMultiChooseNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")

    --Home Button
    local nodeHome          = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome         = nodeHome:getChildByName("Panel_common_home")
    local buttonControl     = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            self:closeAnimation(true)
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    KUtil.updateResourceInfo(self, "xzzb_base.png", function()
        self:closeAnimation(false)
    end)

    -- sort button
    local projectNode  = imageCommon:getChildByName("ProjectNode_buttom")
    local panelNode    = projectNode:getChildByName("Panel_1")
    local buttonSort   = panelNode:getChildByName("Button_zb_sort")
    --local screenTypeButtons = imageCommon:getChildByName("Image_screen_base_1")
    local screenSortButtons = imageCommon:getChildByName("Image_screen_base_2")
    local buttonsScreen = imageCommon:getChildByName("Button_screen")
    buttonsScreen:setSwallowTouches(false)
    buttonsScreen:setVisible(false)

    local function onCommonSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            --KUtil.showUiScale(screenTypeButtons, false)
            KUtil.showUiScale(screenSortButtons, not screenSortButtons:isVisible())
            KSound.playEffect("click")
        end
    end
    buttonSort:addTouchEventListener(onCommonSortClick)

    for type, button in pairs(m_tButtonName) do
        local tempButton = screenSortButtons:getChildByName(button)
        local function onSortItemClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                KUtil.showUiScale(screenSortButtons, false)
                KSound.playEffect("click")
                self._sortType = type
                KSetting.setInt(KSetting.Key.EQUIP_BREAK_CHOOSE_COMMON, self._sortType)
                refreshList(self, true)
            end
        end
        tempButton:addTouchEventListener(onSortItemClick)
    end

    --confirm Button
    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_info")
    local panelGear         = projectNode:getChildByName("Panel_multi_choose_selected")
    local buttonControl     = panelGear:getChildByName("Button_confirm")

    local function onConfirmClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onConfirmClick~")
        KSound.playEffect("click")
        local equipIDList = {}
        for _, v in pairs(self._chosenEquipList) do
            table.insert(equipIDList, v["oneEquip"].nID)
        end
        self._parent:removeNode("GearMultiChoose")
        local eventCenter = require("src/logic/KEventDispatchCenter")
        eventCenter:dispatchEvent(eventCenter.EventType.UI_EQUIP_CHOOSE_FINISH, equipIDList)
    end
    buttonControl:addTouchEventListener(onConfirmClick)

    local buttonControl     = panelGear:getChildByName("Image_chosen_base")
    local function onCleanupClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        local beginPosition = buttonControl:getTouchBeganPosition()
        local endPosition   = buttonControl:getTouchEndPosition()
        if (math.abs(beginPosition.y - endPosition.y) < 15) then
            cclog("-----> onCleanupClick~")
            KSound.playEffect("click")
            unChooseAllEquip(self)
        end
    end
    buttonControl:setTouchEnabled(true)
    buttonControl:addTouchEventListener(onCleanupClick)
    local scrollControl      = panelGear:getChildByName("Scrollview_chosen_list")
    scrollControl:setSwallowTouches(false)

    local projectNode    = imageCommon:getChildByName("ProjectNode_top")
    local panelSarts     = projectNode:getChildByName("Panel_check_stars")
    for i = 1, MAX_CHECK_BOX do
        local checkBox   = panelSarts:getChildByName("CheckBox_stars_" .. i)
        local panelClick = checkBox:getChildByName("Panel_click")

        local star       = i
        local function onPanelClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                if checkBox:isSelected() then
                    checkBox:setSelected(false)
                    self:unChooseEquipByStar(star)
                else
                    checkBox:setSelected(true)
                    self:chooseEquipByStar(star)
                end
            end
        end
        panelClick:addTouchEventListener(onPanelClick)
    end
end

function KUIFactoryGearMultiChooseNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onEquipLock(equipID, isLock)
        local baseControl         = self._scrollGearControl:getChildByName(tostring(equipID))
        if not baseControl then return end
        self:setLockButton(baseControl, isLock)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EQUIP_LOCK, onEquipLock)

    local function onResourceUpdate()
        cclog("----------> onEvent onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)

    local function onBreakDownEqupList(tEquipIDList)
        cclog("onEvent ------------> onBeakDownEquipList KUIFactoryChooseCardNode")

        for k,v in pairs(tEquipIDList) do
            local chosenIndex = getChooseIndexByID(self, v)
            if chosenIndex ~= 0 then table.remove(self._chosenEquipList, chosenIndex) end
            HArray.RemoveFirstByID(self._oneEquipList, v)
        end

        refreshList(self, true)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EQUIPS_BREAK, onBreakDownEqupList)
end

function KUIFactoryGearMultiChooseNode:onCleanup()
    self._textChosenUnitBase  = nil
    self._buttonEquipUnitBase = nil
end

return KUIFactoryGearMultiChooseNode
