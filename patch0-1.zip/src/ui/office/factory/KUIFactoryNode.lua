--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFactoryNode.lua
--  Creator     : SunXun
--  Date        : 2015/04/17   0:01
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local HIGHSPEED_BUILD_COUNT = 2
local MAX_BUILD_BAR_COUNT   = 4
local STATE_FREE            = 1
local STATE_BUILDING        = 2
local STATE_COMPLETE        = 3
local EXPAND_REPAIR_BAR_ID  = 16
local BUTTON_LIST_ENTER_BEGIN_FRAME = 0
local BUTTON_LIST_ENTER_END_FRAME = 15
local BUTTON_LIST_QUIT_BEGIN_FRAME = 170
local BUTTON_LIST_QUIT_END_FRAME = 186
local ONE_BUTTON_FRAME_LEN = 40
local ONE_BUTTON_ENTER_BEGIN_FRAME = 0
local ONE_BUTTON_QUIT_BEGIN_FRAME = 14
local ONE_BUTTON_MOVE_LEN = 7
local arrayBarState = {}

local m_tPageNodeList   = { 
    ProjectNode_factory = {page = 1},
    ProjectNode_build   = {class = "KUIFactoryBuildCardNode", page = 0}, 
    ProjectNode_break   = {class = "KUIFactoryBreakCardNode", page = 2},
    ProjectNode_develop = {class = "KUIFactoryDevelopNode",   page = 3}, 
    ProjectNode_abandon = {class = "KUIFactoryAbandonNode",   page = 4} }

local KUIFactoryNode = class(
    "KUIFactoryNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFactoryNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._nowTime           = os.time()
    self._buildAction       = {}
    self._peopelAction      = {}
    self._highBuildAction   = {}
    self._awardAction       = nil
    self._viewNodeName      = "ProjectNode_factory"
    self._pageParams        = nil
    self._pageClassList   = {}
    self._animationHome      = nil
    self._animationResource  = nil
    self._animationButton    = nil
    self._animationBuildList = nil
    self._isTip              = nil
    self._showLoading        = true
end

function KUIFactoryNode.create(owner, szNodeName, ...)
    local currentNode   = KUIFactoryNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_factory.csb"
    if szNodeName then
        currentNode._viewNodeName = szNodeName
    end
    currentNode._pageParams = { ... }
    currentNode:init()

    return currentNode
end

function KUIFactoryNode:getNodeBuildBar(index)
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
    local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
	local nodeBuildBar     = panelBar:getChildByName("Node_unit" .. index)
    return nodeBuildBar
end

function KUIFactoryNode:initBuildBar(buildBar)
    local imageBarBase      = buildBar:getChildByName("Image_gc_unit_bg")
    imageBarBase:setVisible(true)
    
    local imageCloseBarBase = buildBar:getChildByName("Image_gc_unit_bg_close")
    imageCloseBarBase:setVisible(false)

    local buttonHighSpeed   = imageBarBase:getChildByName("Button_highspeed_button")
    buttonHighSpeed:setVisible(false)
    
    local buttonFinish      = imageBarBase:getChildByName("Button_finish_button")
    buttonFinish:setVisible(false)

    local buttonBuild       = imageBarBase:getChildByName("Button_build_button")
    buttonBuild:setVisible(false)
    
    local labelTime         = imageBarBase:getChildByName("Text_time_data")
    labelTime:setString("00:00:00")
    labelTime:stopAllActions()
    
    local nodeAnimationBuild            = imageBarBase:getChildByName("ProjectNode_building_ani")
    local nodeAnimationSpeedUpBuilding  = imageBarBase:getChildByName("ProjectNode_building_speedup_ani")
    local nodeAnimationSpeedHigh        = imageBarBase:getChildByName("ProjectNode_high_speed_ani")  
    nodeAnimationBuild:setVisible(false)
    nodeAnimationBuild:stopAllActions()
    nodeAnimationSpeedUpBuilding:setVisible(false)
    nodeAnimationSpeedUpBuilding:stopAllActions()
    nodeAnimationSpeedHigh:setVisible(false)
    nodeAnimationSpeedHigh:stopAllActions()
end

function KUIFactoryNode:updateFreeBarInfo(buildBar)
    self:initBuildBar(buildBar)
    local imageBarBase  = buildBar:getChildByName("Image_gc_unit_bg")
    local buttonBuild   = imageBarBase:getChildByName("Button_build_button")
    buttonBuild:setVisible(true)
end

function KUIFactoryNode:updateCompleteBarInfo(index, buildBar)
    self:initBuildBar(buildBar)
    local imageBarBase  = buildBar:getChildByName("Image_gc_unit_bg")
    local buttonFinish  = imageBarBase:getChildByName("Button_finish_button")
    buttonFinish:setVisible(true)
    KUtil.setTouchEnabled(buttonFinish, true)
end

function KUIFactoryNode:updateBuildingBarInfo(index, buildBar)
    self:initBuildBar(buildBar)
    local imageBarBase          = buildBar:getChildByName("Image_gc_unit_bg")
    -- update time per is
    local buildWork             = KUtil.getProducingCardByIndex(index)
    local endTime               = buildWork.nEndTime
    local labelTime             = imageBarBase:getChildByName("Text_time_data")
    labelTime:setString(KUtil.getLeftTime(endTime - KUtil.getServerTime(self._nowTime)))

    --update high speed button
    local buttonHighSpeed           = imageBarBase:getChildByName("Button_highspeed_button")
    if KUtil.getItemCount(HIGHSPEED_BUILD_COUNT) > 0 then
        buttonHighSpeed:setVisible(true)
        KUtil.setTouchEnabled(buttonHighSpeed, true)
    end
    
    --update animation 
    if not self._buildAction then self._buildAction = {} end
    if not self._buildAction[index] then self._buildAction[index] = {} end
    if not self._highBuildAction then self._highBuildAction = {} end
    if not self._highBuildAction[index] then self._highBuildAction[index] = {} end
    if not self._peopelAction then self._peopelAction = {} end
    if not self._peopelAction[index] then self._peopelAction[index] = {} end

    local nodeBuildAnimation        = imageBarBase:getChildByName("ProjectNode_building_ani")
    local buildAction               = cc.CSLoader:createTimeline("res/ui/animation_node/ani_building.csb")
    nodeBuildAnimation:setVisible(true)
    nodeBuildAnimation:stopAllActions()
    nodeBuildAnimation:runAction(buildAction)
    local buildActionAnimationEndFrame = 40 
    buildAction:gotoFrameAndPlay(0, buildActionAnimationEndFrame, true)
    self._buildAction[index].buildAction = buildAction

    local nodeSpeedUpBuildingAnimation  = imageBarBase:getChildByName("ProjectNode_building_speedup_ani")
    local speedUpBuildAction        = cc.CSLoader:createTimeline("res/ui/animation_node/ani_building_speedup.csb")
    nodeSpeedUpBuildingAnimation:setVisible(false)
    nodeSpeedUpBuildingAnimation:stopAllActions()
    nodeSpeedUpBuildingAnimation:runAction(speedUpBuildAction)
    local speedUpActionAnimationEndFrame = 20 
    speedUpBuildAction:gotoFrameAndPlay(0, speedUpActionAnimationEndFrame, true)
    self._buildAction[index].speedUpBuildAction = speedUpBuildAction

    local nodeSpeedHighAnimation    = imageBarBase:getChildByName("ProjectNode_high_speed_ani")      
    local speedHighAction           = cc.CSLoader:createTimeline("res/ui/animation_node/ani_building_high_speed.csb")
    nodeSpeedHighAnimation:setVisible(false)
    nodeSpeedHighAnimation:stopAllActions()
    nodeSpeedHighAnimation:runAction(speedHighAction)
    local speedHighActionAnimationEndFrame = 140 
    speedHighAction:gotoFrameAndPlay(0, speedHighActionAnimationEndFrame, false)
    self._peopelAction[index].speedHighAction = speedHighAction
end

function KUIFactoryNode:refreshOpenBuildBar(index, buildBar)
    assert(index, "index")
    assert(buildBar, "buildBar is nil, index:" .. index)
    
    local buildWork     = KUtil.getProducingCardByIndex(index)
    local state
    if buildWork == nil then
        self:updateFreeBarInfo(buildBar)
        state = STATE_FREE
    else
        if KUtil.getServerTime(self._nowTime) >= buildWork.nEndTime then
            self:updateCompleteBarInfo(index, buildBar)
            state = STATE_COMPLETE
        else
            self:updateBuildingBarInfo(index, buildBar)
            state = STATE_BUILDING
        end
    end
    arrayBarState[index] = state
end

function KUIFactoryNode:refreshCloseBuildBar(buildBar)
    local imageBarBase      = buildBar:getChildByName("Image_gc_unit_bg")
    local imageCloseBarBase = buildBar:getChildByName("Image_gc_unit_bg_close")

    imageBarBase:setVisible(false)
    imageCloseBarBase:setVisible(true)
end

function KUIFactoryNode:refreshBuildTip(isVisible)
    if not isVisible then
        isVisible = false
        for _, buildWorkData in ipairs(KUtil.getProducingCardList()) do
            if buildWorkData.nEndTime == 0 then
                isVisible = true
                break
            end
        end
    end
    if self._isTip == isVisible then return end
    self._isTip = isVisible
    local mainNode            = self._mainLayout
    local nodeButtonAnimation = mainNode:getChildByName("ProjectNode_left_buton")
    local imageBase           = nodeButtonAnimation:getChildByName("Image_label_base") 
    local buttonBuild         = imageBase:getChildByName("Button_1")
    local nodeNotice          = buttonBuild:getChildByName("ProjectNode_notice")
    nodeNotice:setVisible(isVisible)
end

function KUIFactoryNode:refreshAllBuildBar()
    arrayBarState          = {}
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
    local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")

    local buildBarCount    = KUtil.getBuildBarCount()
    for index = 1, MAX_BUILD_BAR_COUNT do
        local buildBar     = panelBar:getChildByName("Node_unit" .. index)
        ---use buildBarCount
        if KPlayer.nBuildBarNum >= index then 
            self:refreshOpenBuildBar(index, buildBar)
        else
            self:refreshCloseBuildBar(buildBar)
        end
    end
end


function KUIFactoryNode:hideHighSpeedButton()
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
    local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
    for _, tProducingCard in ipairs(KUtil.getProducingCardList()) do
        if tProducingCard.nEndTime ~= 0 then
            local nodeBuildBar      = panelBar:getChildByName("Node_unit" .. tProducingCard.nIndex)
            local imageBarBase      = nodeBuildBar:getChildByName("Image_gc_unit_bg")
            local buttonHighSpeed   = imageBarBase:getChildByName("Button_highspeed_button")
            buttonHighSpeed:setVisible(false)
        end
    end
end

function KUIFactoryNode:refreshHighSpeedCount(bfirst)
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
    local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
    local labelHighSpeedValueText   = panelBar:getChildByName("Text_highspeed_item_value")
    local nItemCount                = KUtil.getItemCount(HIGHSPEED_BUILD_COUNT)
    labelHighSpeedValueText:setString(nItemCount)
    if nItemCount == 0 and bfirst then
        self:hideHighSpeedButton()
    end
end

function KUIFactoryNode:hideAwardUI()
    KUtil.removeGetCardAnimation()
end

function KUIFactoryNode:refreshButton(szOldNodeName)
    if self._viewNodeName == "ProjectNode_build" then
        if not szOldNodeName then return end
        local nBeginFrame = BUTTON_LIST_ENTER_END_FRAME + ONE_BUTTON_FRAME_LEN * (m_tPageNodeList[szOldNodeName].page - 1) + ONE_BUTTON_QUIT_BEGIN_FRAME
        KUtil.animationGotoFrameAndPlay(self._animationButton, nBeginFrame, nBeginFrame + ONE_BUTTON_MOVE_LEN)
        return
    end
    local nBeginFrame = BUTTON_LIST_ENTER_END_FRAME + ONE_BUTTON_FRAME_LEN * (m_tPageNodeList[self._viewNodeName].page - 1) + ONE_BUTTON_ENTER_BEGIN_FRAME
    KUtil.animationGotoFrameAndPlay(self._animationButton, nBeginFrame, nBeginFrame + ONE_BUTTON_MOVE_LEN)
end

local function refreshBuildActivity(self)
    local mainNode              = self._mainLayout
    local imageControl          = mainNode:getChildByName("Image_common_base")
    local projectNodeFactory    = imageControl:getChildByName("ProjectNode_factory")
    local panelFactoryContent   = projectNodeFactory:getChildByName("Panel_factory_content")
    local projectNodeActivity   = panelFactoryContent:getChildByName("ProjectNode_activity")

    local isOpened              = KUtil.isOpenedBuildActicity()
    projectNodeActivity:setVisible(isOpened)
end

function KUIFactoryNode:refreshPage(...)
    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")
    local node = imageControl:getChildByName(self._viewNodeName)
    node:setVisible(true)
    if self._viewNodeName == "ProjectNode_factory" then
        self:refreshHighSpeedCount(true)
        refreshBuildActivity(self)
        return self:refreshAllBuildBar()
    end
    assert(self._pageClassList[self._viewNodeName])
    self._pageClassList[self._viewNodeName]:refreshUI(...)
end

function KUIFactoryNode:createPage(szNodeName)
    if szNodeName == "ProjectNode_factory" then
        self:refreshPage(szNodeName)
    elseif not self._pageClassList[self._viewNodeName] then
        local mainNode        = self._mainLayout
        local imageControl    = mainNode:getChildByName("Image_common_base")
        local node   = imageControl:getChildByName(szNodeName)
        local szPath = "src/ui/office/factory/" .. m_tPageNodeList[szNodeName].class
        self._pageClassList[szNodeName] = require(szPath).new(self, node)
    end
end

function KUIFactoryNode:buildListEnter()
    KUtil.playEnterAnimation(self._animationBuildList)
end

function KUIFactoryNode:getNode(nodeType)
    return self._pageClassList[nodeType]
end

function KUIFactoryNode:enterPage(...)
    if self._viewNodeName == "ProjectNode_factory" then

        self:buildListEnter()
        return
    end

    assert(self._pageClassList[self._viewNodeName])
    self._pageClassList[self._viewNodeName]:enter(...)
end

function KUIFactoryNode:quitPage(szNodeName)
    if szNodeName == "ProjectNode_factory" then
        return KUtil.playQuitAnimation(self._animationBuildList)
    end

    assert(self._pageClassList[szNodeName])
    return self._pageClassList[szNodeName]:quit()
end

function KUIFactoryNode:switchPage(szNewNodeName, ...)
    if szNewNodeName == self._viewNodeName then return end
    local szOldNodeName = self._viewNodeName
    self._viewNodeName  = szNewNodeName
    self:refreshButton(szOldNodeName)
    self._mainLayout:stopAllActions()
    self:createPage(szNewNodeName)
    local nDelayTime = self:quitPage(szOldNodeName)
    local tParam = {...}
    local function enter()
        self:enterPage(unpack(tParam, 1, table.maxn(tParam)))
    end
    delayExecute(self._mainLayout, enter, nDelayTime)
end

function KUIFactoryNode:enterAnimation()
    KUtil.playEnterAnimation(self._animationHome)
    KUtil.playEnterAnimation(self._animationResource)
    local nDelayTime = KUtil.playEnterAnimation(self._animationButton)
    -- KUtil.playEnterAnimation(self._animationButton, BUTTON_LIST_ENTER_BEGIN_FRAME, BUTTON_LIST_ENTER_END_FRAME + ONE_BUTTON_ENTER_BEGIN_FRAME + ONE_BUTTON_MOVE_LEN)

    local function playPageButton()
        self:refreshButton()
    end
    local mainNode            = self._mainLayout
    local nodeButtonAnimation = mainNode:getChildByName("ProjectNode_left_buton")
    local imageButtonBase     = nodeButtonAnimation:getChildByName("Image_label_base")
    delayExecute(imageButtonBase, playPageButton, nDelayTime)
    self:enterPage()
end

function KUIFactoryNode:playQuitAnimation()
    local delayTime1 = KUtil.playQuitAnimation(self._animationHome)
    local delayTime2 = KUtil.playQuitAnimation(self._animationResource)
    local delayTime3 = KUtil.playQuitAnimation(self._animationButton, BUTTON_LIST_QUIT_BEGIN_FRAME, BUTTON_LIST_QUIT_END_FRAME)
    return math.max(delayTime1, delayTime2, delayTime3)
end

function KUIFactoryNode:quitAnimation(isReturnOffice)
    local delayTime1, delayTime2 = self:playQuitAnimation(), 0
    if self._viewNodeName == "ProjectNode_factory" then
        delayTime2 = KUtil.playQuitAnimation(self._animationBuildList)
    else
        delayTime2 = self:quitPage(self._viewNodeName)
    end

    local delayTime = math.max(delayTime1, delayTime2)

    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Factory", callBacks, isReturnOffice)
end

function KUIFactoryNode:initData()
    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")

    local function closeCallBack(isReturnOffice)
        self:quitAnimation(self, isReturnOffice)
    end
    self._animationHome, self._animationResource = KUtil.initHomeAndResourceNode(self, closeCallBack, "gc_base")
    local nodeButtonAnimation = mainNode:getChildByName("ProjectNode_left_buton")
    self._animationButton     = KUtil.initAnimation(nodeButtonAnimation, "res/ui/animation_node/ani_factory_button_left.csb")
    local nodeBarAnimation    = imageControl:getChildByName("ProjectNode_factory")
    self._animationBuildList  = KUtil.initAnimation(nodeBarAnimation, "res/ui/animation_node/ani_factory_content.csb")
    for szNodeName, _ in pairs(m_tPageNodeList) do
        imageControl:getChildByName(szNodeName):setVisible(false)
    end 
end

function KUIFactoryNode:activate(nowTime)
    if nowTime ~= self._nowTime then
        local buildBarCount         = KUtil.getProducingCardCount()
        if buildBarCount > 0 then
            local mainNode         = self._mainLayout
            local imageControl     = mainNode:getChildByName("Image_common_base")
            local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
            local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
            local nServerTime      = KUtil.getServerTime(nowTime)
            for _, buildWorkData in ipairs(KPlayer.tCardData.tProducingList) do
                local index = buildWorkData.nIndex
                if arrayBarState[index] == STATE_BUILDING and buildWorkData.nEndTime ~= 0 then
                    if buildWorkData.nEndTime > nServerTime then
                        local nodeBuildBar  = panelBar:getChildByName("Node_unit" .. index)
                        local imageBarBase  = nodeBuildBar:getChildByName("Image_gc_unit_bg")
                        local labelTime     = imageBarBase:getChildByName("Text_time_data")
                        labelTime:setString( KUtil.getLeftTime(buildWorkData.nEndTime - nServerTime))
                    end
                end
            end
        end
        self._nowTime    = nowTime
    end
end

function KUIFactoryNode:onInitUI()
    self:initData()
end

function KUIFactoryNode:refreshUI()
    self:refreshBuildTip()
    self:createPage(self._viewNodeName)
    self:refreshPage(unpack(self._pageParams, 1, table.maxn(self._pageParams)))
end

function KUIFactoryNode:onEnterActionFinished()
    self:enterAnimation()
end

function KUIFactoryNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onBuildStart(index)
        cclog("onEvent ------------> onBuildStart")

        self:refreshOpenBuildBar(index, self:getNodeBuildBar(index))
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_BEGAN_BUILD, onBuildStart)
    
    local function onGetCard(index, cardTemplateID)
        cclog("onEvent ---------->onWorkBudingFinish")
        
        self:refreshOpenBuildBar(index, self:getNodeBuildBar(index))
        self:refreshBuildTip()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_DEL_PRODUCING_CARD, onGetCard)

    local function onGetProducedCard(cardID, isNewCard)
        local nodeAward       = KUtil.playGetCardAnimation(cardID, isNewCard)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_GET_PRODUCED_CARD, onGetProducedCard)

    local function onFinish(barIndex)
        cclog("click onFinish~ barIndex:%d", barIndex)
        assert(self, "self is nil")
        local mainNode         = self._mainLayout
        assert(mainNode, "mainNode is nil")
        local imageControl     = mainNode:getChildByName("Image_common_base")
        assert(imageControl, "imageControl is nil")
        local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
        assert(nodeBarAnimation, "nodeBarAnimation is nil")
        local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
        assert(panelBar, "panelBar is nil")
        local nodeControl                   = panelBar:getChildByName("Node_unit" .. barIndex)
        assert(nodeControl, "nodeControl is nil")
        local imageBarBase                  = nodeControl:getChildByName("Image_gc_unit_bg")
        assert(imageBarBase, "imageBarBase is nil")

        local nodeBuildingAnimationNode     = imageBarBase:getChildByName("ProjectNode_building_ani")
        local nodeSpeedUpBuildingAnimation  = imageBarBase:getChildByName("ProjectNode_building_speedup_ani") 
        local nodeHighSpeedAnimation        = imageBarBase:getChildByName("ProjectNode_high_speed_ani")
        assert(nodeBuildingAnimationNode, "nodeBuildingAnimationNode is nil")
        assert(nodeSpeedUpBuildingAnimation, "nodeSpeedUpBuildingAnimation is nil")
        assert(nodeHighSpeedAnimation, "nodeHighSpeedAnimation is nil")

        nodeBuildingAnimationNode:setVisible(false)
        nodeBuildingAnimationNode:stopAllActions()
        nodeSpeedUpBuildingAnimation:setVisible(true)
        nodeHighSpeedAnimation:setVisible(true)

        assert(self._buildAction, "self._buildAction is nil")
        assert(self._buildAction[barIndex], "self._buildAction[" .. barIndex .. "]")
        assert(self._buildAction[barIndex].speedUpBuildAction, "self._buildAction[" .. barIndex .. "].speedUpBuildAction")
        assert(self._peopelAction, "self._buildAction is nil")
        assert(self._peopelAction[barIndex], "self._peopelAction[" .. barIndex .. "]")
        assert(self._peopelAction[barIndex].speedHighAction, "self._peopelAction[" .. barIndex .. "].speedHighAction")
        
        local delayTime = self._buildAction[barIndex].speedUpBuildAction:getDuration() / 60 
        local speedUpActionAnimationEndFrame = 20 
        self._buildAction[barIndex].speedUpBuildAction:gotoFrameAndPlay(0, speedUpActionAnimationEndFrame, true)
        local speedHighanimationTime = self._peopelAction[barIndex].speedHighAction:getDuration() / 60
        local speedHighActionAnimationEndFrame = 140 
        self._peopelAction[barIndex].speedHighAction:gotoFrameAndPlay(0, speedHighActionAnimationEndFrame, false)
        if delayTime<speedHighanimationTime then
            delayTime = speedHighanimationTime
        end

        delayExecute(nodeControl, 
            function () 
                self:refreshOpenBuildBar(barIndex, nodeControl) 
            end, 
            delayTime)

        self:refreshBuildTip(true)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_FINISH_BUILD, onFinish)

    local function onUpdateItem(itemTemplateID)
        cclog("onEvent ---------->onUpdateItem:", itemTemplateID)
        if itemTemplateID == HIGHSPEED_BUILD_COUNT then
            self:refreshHighSpeedCount()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_UPDATE, onUpdateItem)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_ADD, onUpdateItem)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_REMOVE, onUpdateItem)
    
    local function expandBuildBar(nOneBuildBar)    
        local mainNode         = self._mainLayout
        local imageControl     = mainNode:getChildByName("Image_common_base")
        local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
        local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
        local nodeControl      = panelBar:getChildByName("Node_unit" .. KPlayer.nBuildBarNum)   
        self:refreshOpenBuildBar(KPlayer.nBuildBarNum, nodeControl)       
    end
    self:addCustomEvent(eventDispatchCenter.EventType.EXPAND_BUILDBAR, expandBuildBar)
end

function KUIFactoryNode:requestBuyExtend(goodConfig)
    local onConfirm = function ()
        if KPlayer.coin >= goodConfig.nPrice then
            require("src/network/KC2SProtocolManager"):ExpandBarByCoin(EXPAND_BAR_TYPE.BUILD)           
        else
            --show after this confirm
            delayExecute(self._mainLayout, function ()
                KUtil.showGotoBuyDiamondConfirmation(self._parent)
            end, 0.1) 
        end
    end

    local showString = string.format(KUtil.getStringByKey("factory.buyExtend"), goodConfig.nPrice)
    showConfirmation(showString, onConfirm)
end

function KUIFactoryNode:registerAllTouchEvent()
    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")

    local nodeButtonAnimation      = mainNode:getChildByName("ProjectNode_left_buton")
    local imageButtonAnimationBase = nodeButtonAnimation:getChildByName("Image_label_base")
    for szNodeName, tInfo in pairs(m_tPageNodeList) do
        local button     = imageButtonAnimationBase:getChildByName("Button_" .. tInfo.page)
        if button then
            local function onClick(sender, type)
                if type ~= ccui.TouchEventType.ended then return end
                cclog("click onClick~ %s %d", szNodeName, tInfo.page)
                KSound.playEffect("click")
                self:switchPage(szNodeName)
            end
            button:addTouchEventListener(onClick)
        end
    end

    local nodeBarAnimation = imageControl:getChildByName("ProjectNode_factory")
    local panelBar         = nodeBarAnimation:getChildByName("Panel_factory_content")
    for barIndex = 1, MAX_BUILD_BAR_COUNT do
        local nodeName     = "Node_unit" .. barIndex
        local nodeControl  = panelBar:getChildByName(nodeName)
        local imageBarBase = nodeControl:getChildByName("Image_gc_unit_bg")

        --GC Build Button
        local buttonControl = imageBarBase:getChildByName("Button_build_button")
        local function onGCBuildClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onGCBuildButton")
                KSound.playEffect("startBuilding")
                self:switchPage("ProjectNode_build", barIndex)
            end
        end
        buttonControl:addTouchEventListener(onGCBuildClick)

        --GC Finish Button
        local buttonControl = imageBarBase:getChildByName("Button_finish_button")
        local function onGCFinishClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("buildComplete")
            local tProducing = KUtil.getProducingCardByIndex(barIndex)
            if not tProducing then return end
            assert(KUtil.getServerTime(self._nowTime) >= tProducing.nEndTime)
            local szTipKey   = KUtil.CanAddCard(tProducing.nTemplateID)
            if szTipKey then
                showNoticeByID(szTipKey)
            else
                require("src/network/KC2SProtocolManager"):getProducedCard(barIndex)
                cclog("click onGCFinishButton~ barIndex:%d", barIndex)
                KUtil.setTouchEnabled(buttonControl, false)
            end
        end
        buttonControl:addTouchEventListener(onGCFinishClick)

        --GC HighSpeed Button
        local buttonControl = imageBarBase:getChildByName("Button_highspeed_button")
        local function onGCHighSpeedClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("highConstruction")
                require("src/network/KC2SProtocolManager"):finishProducingCardByCostItem(barIndex)
                KUtil.setTouchEnabled(buttonControl, false)
            end
        end
        buttonControl:addTouchEventListener(onGCHighSpeedClick)

        local imageCloseBarBase = nodeControl:getChildByName("Image_gc_unit_bg_close")

        --GC Expand Button
        local buttonControl = imageCloseBarBase:getChildByName("Button_expand_button")
        local function onGCExpandClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onGCExpandButton")
                KSound.playEffect("buildExtension")
                --self._parent:addNode("GCExpand")
                local itemNum    = KUtil.getItemCount(EXPAND_REPAIR_BAR_ID)
                local itemInfo   = KConfig["itemInfo"][EXPAND_REPAIR_BAR_ID]

                if itemNum <= 0 then 
                    local goodConfig = KUtil.getGoodConfigByItem(EXPAND_REPAIR_BAR_ID)
                    if goodConfig then
                        self:requestBuyExtend(goodConfig)
                    end
                    
                    return 
                end
                              
                local function sure()
                    require("src/network/KC2SProtocolManager"):ExpandBar(EXPAND_BAR_TYPE.BUILD)
                end
                local showString = string.format(KUtil.getStringByKey("repaircard.expandBar"), itemInfo.szName)
                KUtil.showCostItemComfirmation(showString, EXPAND_REPAIR_BAR_ID, sure)
            end
        end
        buttonControl:addTouchEventListener(onGCExpandClick)
    end
end

function KUIFactoryNode:addNode( ... )
    return self._parent:addNode( ... )
end

function KUIFactoryNode:onCleanup()
    for _, KUIClass in pairs(self._pageClassList) do
        if KUIClass.onCleanup then
            KUIClass:onCleanup()
        end
    end
end

return KUIFactoryNode
