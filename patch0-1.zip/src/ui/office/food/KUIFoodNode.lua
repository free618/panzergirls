--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFoodNode.lua
--  Creator     : ChenJiaLiang
--  Date        : 2016/04/13   14:23
--  Contact     : chenjialiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local KSetting = require("src/logic/KSetting")

local FOOD_COUNT        = 5

local KUIFoodNode = class(
    "KUIFoodNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFoodNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._currentLeaderCardID   = nil
    self._animationList         = {}
end

function KUIFoodNode.create(owner)
    local currentNode   = KUIFoodNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_food_house.csb"
    currentNode:init()

    return currentNode
end

local function initData(self)
    local mainNode    = self._mainLayout
    local imageBase   = mainNode:getChildByName("Image_base")

    self._imageBase                 = imageBase
    self._nodeChara                 = imageBase:getChildByName("ProjectNode_chara")
    self._nodeButton                = imageBase:getChildByName("ProjectNode_button")
    self._nodeDialog                = imageBase:getChildByName("ProjectNode_dialog")
    self._nodeTitle                 = imageBase:getChildByName("ProjectNode_title")
    
    self._animationList.title       = {ani = KUtil.initAnimation(self._nodeTitle, "res/ui/animation_node/ani_food_house_title.csb")}
    self._animationList.chara       = {ani = KUtil.initAnimation(self._nodeChara, "res/ui/animation_node/ani_food_house_chara.csb")}
    self._animationList.dialog      = {beginFrame = 0, endFrame = 26, delay = 0.2, ani = KUtil.initAnimation(self._nodeDialog, "res/ui/animation_node/ani_food_house_dialog.csb")}
    self._animationList.button      = {beginFrame = 0, endFrame = 40, ani = KUtil.initAnimation(self._nodeButton, "res/ui/animation_node/ani_food_house_button.csb")}

    FOOD_COUNT = #KConfig.foodsys.tFoodOpen.tValue
end

local function getCoinCost()
    local foodHouseData = KPlayer.tFoodHouseData
    local sysConfig     = KConfig.foodsys
    local costCoin      = 0
    local info          = sysConfig.tCostCoin.tValue
    assert(info, "no tCostCoin.tValue")
    costCoin = info[foodHouseData.nCoinCookTimes + 1]
    if not costCoin then
        costCoin = info[#info]
    end
    return costCoin
end

function KUIFoodNode:activate(nowTime)
end

function KUIFoodNode:onInitUI()
    initData(self)
    self:initFoodDescription()
end

function KUIFoodNode:refreshResource()
    local topNode           = self._nodeTitle:getChildByName("Image_title_base")
    local diamondNumText    = topNode:getChildByName("BitmapFontLabel_diamond")
    local ticketNumText     = topNode:getChildByName("BitmapFontLabel_food")
    local cookNumText       = topNode:getChildByName("BitmapFontLabel_number")
    local freeItemCount     = KUtil.getItemCount(KConfig.foodsys.nFreeItemID.nValue)
    local maxCookTimes      = KConfig.foodsys.nDailyCookTimes.nValue

    diamondNumText:setString(tostring(KPlayer.coin))
    ticketNumText:setString(tostring(freeItemCount))
    cookNumText:setString(string.format(KUtil.getStringByKey("common.rate"), maxCookTimes - KPlayer.tFoodHouseData.nCookTimes, maxCookTimes))
end

function KUIFoodNode:refreshCharacterImage()
    local  leaderCard = KUtil.getTeamLeaderCard()
    assert(leaderCard, "no leader card")

    local cardImagePath = KUtil.getCardImagePath(leaderCard, false)
    if self._currentLeaderCardID == leaderCard.nID and
        self._currentLeaderCardImage == cardImagePath then
        return
    end
    
    self._currentLeaderCardID    = leaderCard.nID
    self._currentLeaderCardImage = cardImagePath
    
    local imageBase      = self._imageBase 
    local projectNode    = imageBase:getChildByName("ProjectNode_chara")
    local imageCharacter = projectNode:getChildByName("Image_chara")
    imageCharacter:loadTexture(cardImagePath)
end

function KUIFoodNode:refreshUI()
    -- self:refreshCharacterImage()
    self:refreshResource()
end

function KUIFoodNode:registerAllTouchEvent()
    local mainNode    = self._mainLayout
    local imageBase   = mainNode:getChildByName("Image_base") 
    local nodeButton  = imageBase:getChildByName("ProjectNode_button")
    local buttonList = nodeButton:getChildByName("Panel_button")

    for i = 1, FOOD_COUNT do
        local foodButton = buttonList:getChildByName("Button_" .. i)
        local function onCookClick(sender, type)
            if type ~= ccui.TouchEventType.ended then
                return
            end

            if KPlayer.tFoodHouseData.nCookTimes < KConfig.foodsys.nDailyCookTimes.nValue then
                local onConfirm = function ()
                    if KPlayer.coin >= getCoinCost() then
                        require("src/network/KC2SProtocolManager"):Cook(i)
                        assert(self, "KUIFoodNode cook with no self")
                        assert(self.setAllFoodTouchState, "KUIFoodNode no setAllFoodTouchState, path:" .. tostring(self._uiPath))
                        self:setAllFoodTouchState(false)
                    else
                        showNotice(KUtil.getStringByKey("errorCode4"))
                    end 
                end

                if KUtil.getItemCount(KConfig.foodsys.nFreeItemID.nValue) < 1 then
                    local showString = string.format(KUtil.getStringByKey("food.costCoinTip"), getCoinCost())
                    showConfirmation(showString, onConfirm)
                else
                    require("src/network/KC2SProtocolManager"):Cook(i)
                    self:setAllFoodTouchState(false)
                end
            else
                showNotice(KUtil.getStringByKey("food.timesLimit")) 
            end
        end

        if KConfig.foodsys.tFoodOpen.tValue[i] == 1 then
            foodButton:addTouchEventListener(onCookClick)
        end
    end

    local titleBase         = self._nodeTitle:getChildByName("Image_title_base")
    local buttonClose       = titleBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self:playPanelCloseAnimation(true)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

function KUIFoodNode:setAllFoodTouchState(bEnabled)
    local buttonList = self._nodeButton:getChildByName("Panel_button")

    for i = 1, FOOD_COUNT do
        local foodButton = buttonList:getChildByName("Button_" .. i)
        foodButton:setTouchEnabled(bEnabled)
    end
end

function KUIFoodNode:getEnterAction()
    return nil, nil
end

function KUIFoodNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function ()
        self:enterAnimation()
    end, 0.1)
    
    self:showDialog(KConfig:getLine("string", "food.dayFirst").szText)
end

function KUIFoodNode:onNodeEnter()
    KSound.playMusic("food")
end

function KUIFoodNode:onNodeExit()
    KSound.playMusic("base")
end

function KUIFoodNode:enterAnimation()    
    for _, aniConfig in pairs(self._animationList) do
        if not aniConfig.delay or aniConfig.delay <= 0 then
            KUtil.playEnterAnimation(aniConfig.ani, aniConfig.beginFrame, aniConfig.endFrame)
        else
            delayExecute(self._mainLayout, function ()
                KUtil.playEnterAnimation(aniConfig.ani, aniConfig.beginFrame, aniConfig.endFrame)
            end, aniConfig.delay)
        end
    end
end

function KUIFoodNode:exitAnimation()
    local delayTime = 0
    for _, aniConfig in pairs(self._animationList) do
        local aniTime = KUtil.playQuitAnimation(aniConfig.ani)
        if aniTime > delayTime then
            delayTime = aniTime
        end
    end

    return delayTime
end

function KUIFoodNode:showOnMedalPanel(isFree, cookResultIdx, items)
    self._parent:addNode("FoodMedal", isFree, cookResultIdx, items)
end

function KUIFoodNode:showDialog(text)
    local dialog        = self._nodeDialog:getChildByName("Image_dialog") 
    local dialogText    = dialog:getChildByName("Text_dialog")
    local dialogTitle   = dialog:getChildByName("Text_title")
    local duration = 0.3

    dialogText:setString(text)
    dialogTitle:setString("")

    dialog:runAction(cc.Sequence:create(
        cc.FadeIn:create(duration)
        )
    )
end

function KUIFoodNode:hideDialog()
    self._nodeDialog:setVisible(false)
end

function KUIFoodNode:initFoodDescription()
    local buttonList = self._nodeButton:getChildByName("Panel_button")
    for i = 1, FOOD_COUNT do
        local button = buttonList:getChildByName("Button_" .. i)
        
        if KConfig.foodsys.tFoodOpen.tValue[i] == 0 then
            local panelDisable = button:getChildByName("Panel_disable")
            local disabledDesc = panelDisable:getChildByName("Text_food_descrition")
            disabledDesc:setString(KConfig.foodsys.tFoodDesc.tValue[i])
            button:setVisible(false)
        else
            local panelDisable = button:getChildByName("Panel_disable")
            panelDisable:setVisible(false)
            panelDisable:getChildByName("Text_food_descrition"):setString(KConfig.foodsys.tFoodDesc.tValue[i])

            local desc   = button:getChildByName("Text_food_descrition")
            desc:setString(KConfig.foodsys.tFoodDesc.tValue[i])
        end
    end
end

function KUIFoodNode:playPanelCloseAnimation(isReturnOffice)
    local delayTime = self:exitAnimation()
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Cook", callBacks, isReturnOffice)
end

function KUIFoodNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onCookResult(isFree, cookResultIdx, items)
        cclog("onEvent ---------->onCookResult")
        if cookResultIdx > 0 then
            self:showOnMedalPanel(isFree, cookResultIdx, items)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_COOK_RESULT, onCookResult)

    local function onUpdateCookData()
        local foodHouseData = KPlayer.tFoodHouseData
        if foodHouseData.nCookTimes < KConfig.foodsys.nDailyCookTimes.nValue then
            self:setAllFoodTouchState(true)
            self:initFoodDescription()
        else
            self:setAllFoodTouchState(false)
        end
        self:refreshResource()
        cclog("onEvent ---------->onUpdateCookData")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FOOD_DATA, onUpdateCookData)

    local function onCoinUpdate()
        cclog("onEvent ---------->KUIFoodNode onCoinUpdate")
        self:refreshResource()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_COIN, onCoinUpdate)
    
    local function onItemChange()
        cclog("onEvent ---------->KUIFoodNode onItemChange")
        self:refreshResource()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_ADD, onItemChange)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_UPDATE, onItemChange)
end

return KUIFoodNode