--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFurnitureNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/21   9:35
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  ********************************************************************


local m_tSelectTexture = 
{
    ["normal"]   = "res/ui/ui_material/public/dj_unit_base.png",
    ["press"]    = "res/ui/ui_material/public/dj_unit_base_active.png",
    ["disable"]  = "res/ui/ui_material/public/dj_unit_base.png"
}

local m_tHideTexture = 
{
    ["normal"]   = "res/ui/ui_material/furniture/jj_hide.png",
    ["press"]    = "res/ui/ui_material/furniture/jj_hide_active.png",
    ["disable"]  = "res/ui/ui_material/furniture/jj_hide_active.png"
}

local m_tShowTexture = 
{
    ["normal"]   = "res/ui/ui_material/furniture/jj_hide_1.png",
    ["press"]    = "res/ui/ui_material/furniture/jj_hide_1_active.png",
    ["disable"]  = "res/ui/ui_material/furniture/jj_hide_1_active.png"
}

local m_tLabelTexture = {
    ["highlight"] = "res/ui/ui_material/furniture/furniture_labeling.png",
    ["normal"]    = "res/ui/ui_material/furniture/furniture_labeling_2.png",
}

local KUIFurnitureNode = class(
    "KUIFurnitureNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFurnitureNode:ctor()
    self._parent                = nil
    self._mainLayout            = nil
    self._uiPath                = nil
    self._baseControl           = nil
    self._selectTab             = 0
    self._selectItem            = 0
    self._isShow                = true
    self._showDataList          = {}
    self._furnitureInfo         = {}
end

function KUIFurnitureNode.create(owner)
    local currentNode = KUIFurnitureNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_decoration.csb"
    currentNode:init()

    return currentNode
end

local function playFurnitureAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_furniture_base")

    local openEndFrame    = 15
    local closeStartFrame = 105
    local animationName   = "ani_decoration_furniture"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTitleAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_title")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_decoration_title"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playFurnitureSelectAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_furniture_base")

    projectNode:stopAllActions()
    local animationPath   = KUtil.getAnimationPath("ani_decoration_furniture")
    local animationAction = cc.CSLoader:createTimeline(animationPath)
    projectNode:runAction(animationAction)
    local startFrame, endFrame = 30, 50
    if isOpen then
        startFrame, endFrame = 70, 90
    end
    animationAction:gotoFrameAndPlay(startFrame, endFrame, false)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_furniture_base")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_title")
    projectNode:stopAllActions()
end

local function playItemAnimation(self, itemControl, isOpen)
    local projectNode     = itemControl:getChildByName("ProjectNode_button_unit_base")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_decoration_button"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playFurnitureAnimation(self, false))
        table.insert(framesList, playTitleAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Furniture", callBacks, isReturnOffice)
end

local function getCloneNode(self)
    local newControl  = self._baseControl:clone()

    local itemControl         = cc.CSLoader:createNode("res/ui/animation_node/ani_decoration_button.csb")
    local itemControlAction   = cc.CSLoader:createTimeline("res/ui/animation_node/ani_decoration_button.csb")
    newControl:addChild(itemControl)
    itemControl:setName("ProjectNode_button_unit_base")

    itemControl:stopAllActions()
    itemControl:runAction(itemControlAction)
    local endFrame = 65
    itemControlAction:gotoFrameAndPause(endFrame)
    
    local panelBase = self._baseControl:getChildByName("ProjectNode_button_unit_base")
    local positionX = panelBase:getPositionX()
    local positionY = panelBase:getPositionY()

    itemControl:setPosition(positionX, positionY)
    return newControl
end

local function initFurniturePosiTion(self)
    local mainNode              = self._mainLayout
    local projectFurnitureNode  = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture        = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local projectFurnitureBase  = panelFurniture:getChildByName("ProjectNode_furniture_base")
    self._furnitureInfo         = KUtil.getFurniturePosition(projectFurnitureBase)
end

local function refreshFurnitures(self)
    local mainNode              = self._mainLayout
    local projectFurnitureNode  = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture        = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local projectFurnitureBase  = panelFurniture:getChildByName("ProjectNode_furniture_base")
    KUtil.refreshFurnitures(projectFurnitureBase, self._furnitureInfo)
end

local function changeBackGround(self, templateID)
    refreshFurnitures(self)

    local mainNode              = self._mainLayout
    local projectFurnitureNode  = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture        = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local projectFurnitureBase  = panelFurniture:getChildByName("ProjectNode_furniture_base")
    local imageCommonBackground = projectFurnitureBase:getChildByName("Panel__furniture_background")

    local config = KConfig.furniture[templateID]
    if not config then return end
    local furnitureType = KConfig.furnitureType[config.nType]
    if not furnitureType then return end

    local folderName     = KUtil.getFurnitureFolderByType(config.nType)
    local uiName         = "Image_" .. folderName
    local imageFurniture = imageCommonBackground:getChildByName(uiName)
    if not imageFurniture then return end

    local filePath = KUtil.getFurniturePath(templateID)
    imageFurniture:loadTexture(filePath)

    local positionInfo = self._furnitureInfo[config.nType] 
    local positionX    = positionInfo.x + config.nOffX
    local positionY    = positionInfo.y + config.nOffY

    imageFurniture:setPosition(positionX, positionY)
end

local function hideOtherUi(self, isShow)
    local mainNode         = self._mainLayout
    local projectTitleNode = mainNode:getChildByName("ProjectNode_title")
    local panelHeaderBase  = projectTitleNode:getChildByName("Image_header_base")
    panelHeaderBase:setVisible(isShow)

    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelLabeling          = panelFurniture:getChildByName("Panel_labeling")
    panelLabeling:setVisible(isShow)

    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    local buttonHide             = panelDecorationBottom:getChildByName("Button_hide")
    if isShow then
        buttonHide:loadTextures(m_tHideTexture.normal, m_tHideTexture.press, m_tHideTexture.disable)
    else
        buttonHide:loadTextures(m_tShowTexture.normal, m_tShowTexture.press, m_tShowTexture.disable)
    end

    local panelScrollViewBase    = panelDecorationBottom:getChildByName("Image_base")
    local scrollView             = panelScrollViewBase:getChildByName("ScrollView_list")
    scrollView:setVisible(isShow)
end

local function getDataListByType(selectType)
    local showData = {}
    for _, oneFurniture in pairs(KPlayer.tFurnitureData.tFurnitureList) do
        local config = KConfig.furniture[oneFurniture.nTemplateID]
        if config.nType == selectType then
            table.insert(showData, {nTemplateID = oneFurniture.nTemplateID})
        end
    end

    local function funSort(config1, config2)
        return config1.nTemplateID > config2.nTemplateID
    end
    table.sort(showData, funSort)
    return showData
end

local function refreshLeftTab(self, selectType)
    local mainNode              = self._mainLayout
    local projectFurnitureNode  = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture        = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local projectFurnitureBase  = panelFurniture:getChildByName("ProjectNode_furniture_base")
    local imageCommonBackground = projectFurnitureBase:getChildByName("Panel__furniture_background")
    local panelLabeling         = panelFurniture:getChildByName("Panel_labeling")
    for nType = 1, MAX_FURNITURE_INDEX do
        local folderName = KUtil.getFurnitureFolderByType(nType)
        local uiName     = "Image_" .. folderName
        local buttonTab  = imageCommonBackground:getChildByName(uiName)
        if selectType == nType then
            KUtil.setWidgetBright(buttonTab)
        else
            KUtil.setWidgetNormal(buttonTab)
        end

        local imageLabel = panelLabeling:getChildByName("Image_labeling_" .. nType)
        if nType == selectType then
            imageLabel:loadTexture(m_tLabelTexture.highlight)
        else
            imageLabel:loadTexture(m_tLabelTexture.normal)
        end
    end
end

local function refreshItemSelect(self, lastID, currentID)
    -- reset touch enable
    local mainNode               = self._mainLayout
    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    local panelScrollViewBase    = panelDecorationBottom:getChildByName("Image_base")
    local scrollView             = panelScrollViewBase:getChildByName("ScrollView_list")

    local itemControl = ccui.Helper:seekWidgetByName(scrollView, tostring(lastID))
    if itemControl then
        local projectNode = itemControl:getChildByName("ProjectNode_button_unit_base") 
        local panelUnit   = projectNode:getChildByName("Button_unit_base") 
        panelUnit:loadTextures(m_tSelectTexture.normal, m_tSelectTexture.press, m_tSelectTexture.disable)
        panelUnit:setTouchEnabled(true)
        panelUnit:setSwallowTouches(false)
        playItemAnimation(self, itemControl, false)
    end
    local itemControl = ccui.Helper:seekWidgetByName(scrollView, tostring(currentID))
    if itemControl then
        local projectNode = itemControl:getChildByName("ProjectNode_button_unit_base") 
        local panelUnit   = projectNode:getChildByName("Button_unit_base") 
        panelUnit:loadTextures(m_tSelectTexture.press, m_tSelectTexture.press, m_tSelectTexture.disable)
        panelUnit:setTouchEnabled(false)
        panelUnit:setSwallowTouches(false)
        playItemAnimation(self, itemControl, true)
    end
end

local function refreshRightPanel(self, nTemplateID)
    local mainNode               = self._mainLayout
    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    
    local textName               = panelDecorationBottom:getChildByName("Text_name")
    local textIntroduction       = panelDecorationBottom:getChildByName("Text_introduction")
    local haveItem               = (nTemplateID ~= 0)
    local furnitureInfo          = KConfig.furniture[nTemplateID]

    textName:setVisible(haveItem)
    textIntroduction:setVisible(haveItem)

    if not (haveItem and furnitureInfo) then return end
    textName:setString(furnitureInfo.szName)
    textIntroduction:setString(furnitureInfo.szDescribe)
end

local function itemSelectChange(self, lastID, currentID)
    self._selectItem = currentID
    refreshItemSelect(self, lastID, self._selectItem)
    refreshRightPanel(self, self._selectItem)
    changeBackGround(self, self._selectItem)
end

local function updateItem(self, itemData, itemControl)
    if not itemData then
        itemControl:setVisible(false)
        return
    end
    itemControl:setName(tostring(itemData.nTemplateID))

    local projectNode = itemControl:getChildByName("ProjectNode_button_unit_base") 
    local panelUnit   = projectNode:getChildByName("Button_unit_base") 

    local furnitureInfo = KConfig.furniture[itemData.nTemplateID]
    local panelclipping = panelUnit:getChildByName("Panel_icon")
    local imageIcon     = panelclipping:getChildByName("Image_icon")
    local filePath = KUtil.getFurniturePath(itemData.nTemplateID)
    imageIcon:loadTexture(filePath)

    local filePath, scaleRatio  = KUtil.getRewardItemPathAndScale(ITEM_TYPE.FURNITURE, itemData.nTemplateID)
    imageIcon:setScale(scaleRatio * 1.3)

    local textTitle = panelUnit:getChildByName("Text_unit_title")
    textTitle:setString(furnitureInfo.szName)

    local nTemplateID = itemData.nTemplateID
    local function onDetail(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onDetail~")
            KSound.playEffect("click")
            itemSelectChange(self, self._selectItem, nTemplateID)
        end
    end
    panelUnit:addTouchEventListener(onDetail)
    panelUnit:setSwallowTouches(false)
    itemControl:setSwallowTouches(false)
end

local function refreshScrollView(self, selectType, isCutIn)
    local mainNode               = self._mainLayout
    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    local panelScrollViewBase    = panelDecorationBottom:getChildByName("Image_base")
    local scrollView             = panelScrollViewBase:getChildByName("ScrollView_list")
    scrollView:removeAllChildren()

    self._showDataList  = getDataListByType(selectType)
    local itemSize      = #self._showDataList
    local contentSize   = scrollView:getContentSize()

    local projectNode   = self._baseControl:getChildByName("ProjectNode_button_unit_base")
    local itemBaseNode  = projectNode:getChildByName("Button_unit_base")
    local barSize       = itemBaseNode:getContentSize()
    local positionX     = self._baseControl:getPositionX()
    local positionY     = self._baseControl:getPositionY()

    for index = 1, itemSize do
        local itemData    = self._showDataList[index]
        local newControl  = getCloneNode(self)
        updateItem(self, itemData, newControl)

        local tempPositionX = positionX + (index - 1) * barSize.width
        newControl:setPosition(cc.p(tempPositionX, positionY))
        scrollView:addChild(newControl)
    end

    local contentSize      = scrollView:getContentSize()
    local totalWidth       = math.max(contentSize.width, barSize.width * itemSize)

    local innerContainer   = scrollView:getInnerContainer()
    local innerContentSize = innerContainer:getContentSize()
    scrollView:setInnerContainerSize(cc.size(totalWidth, innerContentSize.height))
    scrollView:jumpToLeft()
end

local function refreshTabChange(self, selectType)
    if self._selectTab == selectType then return end

    refreshScrollView(self, selectType, false)
    refreshLeftTab(self, selectType)
    self._selectTab  = selectType
    m_nLastSelectType= selectType

    local currentInfo = HArray.FindFirst(KPlayer.tFurnitureData.tRoleFurniture, "nType", selectType)
    self._selectItem = 0
    for _, dataInfo in pairs(self._showDataList) do
        if currentInfo and currentInfo.nTemplateID == dataInfo.nTemplateID then
            self._selectItem = dataInfo.nTemplateID
        end
    end

    if #self._showDataList > 0 and self._selectItem == 0 then
        self._selectItem = self._showDataList[1].nID
    end

    itemSelectChange(self, 0, self._selectItem)
end

local function initUi(self)
    local mainNode               = self._mainLayout
    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    local panelScrollViewBase    = panelDecorationBottom:getChildByName("Image_base")
    local scrollView             = panelScrollViewBase:getChildByName("ScrollView_list")
    local panelUnitBase          = scrollView:getChildByName("Panel_unit_base")

    self._baseControl = panelUnitBase
    self._baseControl:retain()
    scrollView:removeChild(panelUnitBase)
end

function KUIFurnitureNode:onInitUI()
    stopAllAnimation(self)
    initUi(self)
end

function KUIFurnitureNode:refreshUI()
    initFurniturePosiTion(self)
    refreshTabChange(self, 1)
end

function KUIFurnitureNode:onEnterActionFinished()
    playFurnitureAnimation(self, true)
    playTitleAnimation(self, true)
end

function KUIFurnitureNode:registerAllTouchEvent()
    local mainNode         = self._mainLayout
    local projectTitleNode = mainNode:getChildByName("ProjectNode_title")
    local panelHeaderBase  = projectTitleNode:getChildByName("Image_header_base")
    local buttonClose      = panelHeaderBase:getChildByName("Button_close")

    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local mainNode               = self._mainLayout
    local projectFurnitureNode   = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture         = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local panelDecorationBottom  = panelFurniture:getChildByName("Panel_decoration_bottom")
    local buttonChange           = panelDecorationBottom:getChildByName("Button_change")

    local function onChangeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onChangeClick~") 
            KSound.playEffect("click")
            if self._selectItem == 0 then return end

            local haveExist = HArray.FindFirst(KPlayer.tFurnitureData.tRoleFurniture, "nTemplateID", self._selectItem)
            if haveExist then showNotice(KUtil.getStringByKey("furniture.notChange")) return end
            require("src/network/KC2SProtocolManager"):changeRoleFurniture(self._selectItem)
        end
    end
    buttonChange:addTouchEventListener(onChangeClick)

    local buttonHide = panelDecorationBottom:getChildByName("Button_hide")
    local function onHideClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._isShow = not self._isShow
            playFurnitureSelectAnimation(self, self._isShow)
            hideOtherUi(self, self._isShow)
        end
    end
    buttonHide:addTouchEventListener(onHideClick)
    buttonHide:loadTextures(m_tHideTexture.normal, m_tHideTexture.press, m_tHideTexture.disable)

    local projectFurnitureNode  = mainNode:getChildByName("ProjectNode_furniture_base")
    local panelFurniture        = projectFurnitureNode:getChildByName("Panel_decoration_furniture")
    local projectFurnitureBase  = panelFurniture:getChildByName("ProjectNode_furniture_base")
    local imageCommonBackground = projectFurnitureBase:getChildByName("Panel__furniture_background")
    local panelLabeling          = panelFurniture:getChildByName("Panel_labeling")
    local buttonFloor            = panelFurniture:getChildByName("Button_floor")
    
    for nType = 1, MAX_FURNITURE_INDEX do
        local folderName       = KUtil.getFurnitureFolderByType(nType)
        local uiName           = "Image_" .. folderName
        local buttonFurniture  = imageCommonBackground:getChildByName(uiName)
        buttonFurniture:setTouchEnabled(true)
        local tempType         = nType
        local function onClickCall()
            if self._selectTab == tempType then
                KUtil.setWidgetBright(buttonFurniture)
            end
            refreshTabChange(self, tempType)
            if self._isShow then return end
            self._isShow = true
            playFurnitureSelectAnimation(self, true)
            hideOtherUi(self, true)
        end

        local function onCancelCall()
            if self._selectTab == tempType then
                KUtil.setWidgetBright(buttonFurniture)
            end
        end
        
        local function onClick(sender, type)
            if type == ccui.TouchEventType.began then
                KUtil.setWidgetBright(buttonFurniture)
            elseif type == ccui.TouchEventType.ended then
                KUtil.setWidgetNormal(buttonFurniture)
                if onClickCall then onClickCall() end
            elseif type == ccui.TouchEventType.canceled then
                KUtil.setWidgetNormal(buttonFurniture)
                if onCancelCall then onCancelCall() end
            end
        end
        buttonFurniture:addTouchEventListener(onClick)

        local imageLabel = panelLabeling:getChildByName("Image_labeling_" .. nType)
        imageLabel:setTouchEnabled(true)
        imageLabel:addTouchEventListener(onClick)

        if nType == FURNITURE_TYPE.FLOOR then
            buttonFloor:addTouchEventListener(onClick)
        end
    end
end

function KUIFurnitureNode:registerAllCustomEvent()
    local function onChangeFurniture(tOne)
        showNotice(KUtil.getStringByKey("furniture.change"), "success")
        refreshFurnitures(self, tOne.nTemplateID)
    end
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CHANGE_FURNITURE, onChangeFurniture) 
end

function KUIFurnitureNode:onCleanup()
    self._baseControl:release() 
end

return KUIFurnitureNode
