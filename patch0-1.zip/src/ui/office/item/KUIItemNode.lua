--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIItemNode.lua
--  Creator     : Jiang XuFeng
--  Date        : 2016/03/17   9:35
--  Contact     : jianxufeng@kingsoft.com
--  Comment     :
--  ********************************************************************


local ITEM_COUNT_ONE_LINE = 4

local m_tSortTypeName = {
    "name",
    "time",
    "count",
}

local m_tSortDataName = {
    "szName",
    "time",
    "count",
}

local KUIItemNode = class(
    "KUIItemNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIItemNode:ctor()
    self._parent                = nil
    self._mainLayout            = nil
    self._uiPath                = nil
    self._currentItemTemplateID = nil
    self._currentSortTypeIndex  = 1
    self._itemList              = {}
    self._itemUnitBase          = nil
    self._originItemNodeSize    = {}
    self._originDetailImageSize = {}
end

function KUIItemNode.create(owner)
    local currentNode = KUIItemNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_item.csb"
    currentNode:init()

    return currentNode
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, self:playProjectNodeLeft(false))
        table.insert(framesList, self:playProjectNodeRight(false))
        table.insert(framesList, self:playProjectNodeButtom(false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Item", callBacks, isReturnOffice)
end

local function getItemCount(item)
    return KUtil.getItemCountExceptCardMountItem(item.nTemplateID)
end

local function getItemInfo()
    return KConfig.itemInfo
end

local function getItemName(item)
    local itemInfo = getItemInfo()
    local oneItemInfo = itemInfo[item.nTemplateID]
    return oneItemInfo.szName
end

local function getItemSubType(item)
    local itemInfo = getItemInfo()
    local oneItemInfo = itemInfo[item.nTemplateID]
    return oneItemInfo.nType
end


local function getItemList()
    return KPlayer.tItemData.tStoreHouse.tItemList
end

local function getItemDescription(item)
    local oneItemInfo = getItemInfo()[item.nTemplateID]
    return oneItemInfo.szDescription
end

local function getItemImageResPath(item)
    local oneItemInfo = getItemInfo()[item.nTemplateID]
    return "res/images/item/" .. oneItemInfo.szResPath .. "/1.png"
end

local function loadImageToItemNode(nodeImage, originSize, item)
    nodeImage:loadTexture(getItemImageResPath(item))
    local imageSize       = nodeImage:getContentSize()
    local scaleWidthSize  = nil
    local scaleHeightSize = nil
    if imageSize.width > originSize.width then
        scaleWidthSize = 1 / (imageSize.width / originSize.width)
    else
        scaleWidthSize = 1
    end
    if imageSize.height > originSize.height then
        scaleHeightSize = 1 / (imageSize.height / originSize.height)
    else
        scaleHeightSize = 1
    end

    local scaleSize = scaleWidthSize
    if scaleSize > scaleHeightSize then
        scaleSize = scaleHeightSize
    end
    nodeImage:setScale(scaleSize)
end

local function getItemTouchEnable(item)
    local oneItemInfo = getItemInfo()[item.nTemplateID]
    if not oneItemInfo.szUseAction or oneItemInfo.szUseAction == "" then
        return false
    else
        return true
    end 
end

local function getItemVisible(item)
    local itemCount = getItemCount(item)
    if itemCount <= 0 then
        return false
    else
        return true
    end
end

local function reverseItemList(self)
    self._itemList    = {}
    local allItemList = getItemList()
    for i = #allItemList, 1, -1 do
        local item = allItemList[i]
        if item ~= nil and getItemVisible(item) then
            table.insert(self._itemList, item)
        end
    end
end

local function generateItemUnit(self)
    local mainNode           = self._mainLayout
    local imageCommonBase    = mainNode:getChildByName("Image_common_base")
    local projectNodeRight   = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight     = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase      = panelItemRight:getChildByName("Image_dj_base")
    local scrollViewItemList = imageItemBase:getChildByName("Scrollview_tank_list")
    local nodeItemUnit       = scrollViewItemList:getChildByName("Button_unit")
    
    self._itemUnitBase       = nodeItemUnit:clone()
    self._itemUnitBase:retain()
    nodeItemUnit:removeFromParent()
    
    local projectNodeLeft       = imageCommonBase:getChildByName("ProjectNode_left")
    local panelItemLeft         = projectNodeLeft:getChildByName("Panel_item_left")
    local imageItemDetail       = panelItemLeft:getChildByName("Image_gear_choose")
    local imageItemNode         = nodeItemUnit:getChildByName("Image_gear")
    self._originItemNodeSize    = imageItemNode:getContentSize()
    self._originDetailImageSize = imageItemDetail:getContentSize()
end

local function clearItemUnit(self)
    local mainNode         = self._mainLayout
    local imageCommonBase  = mainNode:getChildByName("Image_common_base")
    local projectNodeRight = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight   = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase    = panelItemRight:getChildByName("Image_dj_base")
    local scrollViewItem   = imageItemBase:getChildByName("Scrollview_tank_list")
    local itemIndex        = nil
    local tUnitTexturePath = {
        ["buttonNormalTexture"]  = "res/ui/ui_material/public/dj_unit_base.png",
        ["buttonPressTexture"]   = "res/ui/ui_material/public/dj_unit_base_active.png",
        ["buttonDisableTexture"] = "res/ui/ui_material/public/dj_unit_base_disable.png"
    }

    for index, tItem in ipairs(self._itemList) do
        local itemUnitName    = "item_unit_" .. index
        local buttonItemUnit  = scrollViewItem:getChildByName(itemUnitName)
        buttonItemUnit:loadTextures(tUnitTexturePath.buttonNormalTexture,
            tUnitTexturePath.buttonPressTexture,
            tUnitTexturePath.buttonPressTexture)
    end
end

local function hideItemDetail(self)
    self._currentItemTemplateID = nil
    clearItemUnit(self)

    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNodeRight  = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight    = projectNodeRight:getChildByName("Panel_item_right")
    local projectNodeLeft   = imageCommonBase:getChildByName("ProjectNode_left")
    local panelItemLeft     = projectNodeLeft:getChildByName("Panel_item_left")
    local imageItemBase     = panelItemRight:getChildByName("Image_dj_base")
    local textItemIntroduce = panelItemLeft:getChildByName("Text_contant_introduce")
    local imageItemDetail   = panelItemLeft:getChildByName("Image_gear_choose")
    local textItemCount     = panelItemLeft:getChildByName("Text_contant_value")
    local textItemName      = panelItemLeft:getChildByName("Text_contant_name")
    local buttonComfirm     = panelItemLeft:getChildByName("Button_confirm")

    textItemIntroduce:setVisible(false)
    imageItemDetail:setVisible(false)
    textItemCount:setVisible(false)
    buttonComfirm:setVisible(false)
    textItemName:setVisible(false)
end

local function refreshItemUnit(self, item)
    local mainNode         = self._mainLayout
    local imageCommonBase  = mainNode:getChildByName("Image_common_base")
    local projectNodeRight = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight   = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase    = panelItemRight:getChildByName("Image_dj_base")
    local scrollViewItem   = imageItemBase:getChildByName("Scrollview_tank_list")
    local itemIndex        = nil
    local tUnitTexturePath = {
        ["buttonNormalTexture"]  = "res/ui/ui_material/public/dj_unit_base.png",
        ["buttonPressTexture"]   = "res/ui/ui_material/public/dj_unit_base_active.png",
        ["buttonDisableTexture"] = "res/ui/ui_material/public/dj_unit_base_disable.png"
    }

    for index, tItem in ipairs(self._itemList) do
        local itemUnitName    = "item_unit_" .. index
        local buttonItemUnit  = scrollViewItem:getChildByName(itemUnitName)
        buttonItemUnit:loadTextures(tUnitTexturePath.buttonNormalTexture,
            tUnitTexturePath.buttonPressTexture,
            tUnitTexturePath.buttonPressTexture)

        if item.nTemplateID == tItem.nTemplateID then
            itemIndex = index
        end 
    end

    local itemUnitName    = "item_unit_" .. itemIndex 
    local buttonItemUnit  = scrollViewItem:getChildByName(itemUnitName)
    buttonItemUnit:loadTextures(tUnitTexturePath.buttonPressTexture,
        tUnitTexturePath.buttonPressTexture,
        tUnitTexturePath.buttonPressTexture)
end

local function refreshItemDetail(self, item)
    assert(item, "error: item is not exist!!!")
    self._currentItemTemplateID = item.nTemplateID
    refreshItemUnit(self, item)

    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local imageItemBase   = imageCommonBase:getChildByName("Image_dj_base")
    local projectNodeLeft = imageCommonBase:getChildByName("ProjectNode_left")
    local panelItemLeft   = projectNodeLeft:getChildByName("Panel_item_left")
    local imageItemDetail = panelItemLeft:getChildByName("Image_gear_choose")
    imageItemDetail:setVisible(true)
    loadImageToItemNode(imageItemDetail, self._originDetailImageSize, item)

    local textItemCount   = panelItemLeft:getChildByName("Text_contant_value")
    textItemCount:setVisible(true)
    textItemCount:setString(getItemCount(item))

    local textItemName    = panelItemLeft:getChildByName("Text_contant_name")
    textItemName:setVisible(true)
    textItemName:setString(getItemName(item))

    local textItemIntroduce = panelItemLeft:getChildByName("Text_contant_introduce")
    textItemIntroduce:setVisible(true)
    textItemIntroduce:setString(getItemDescription(item))

    local buttonComfirm      = panelItemLeft:getChildByName("Button_confirm")
    buttonComfirm:setVisible(true)
    local usableFlag         = getItemTouchEnable(item)
    local tButtonTexturePath = {
        ["buttonNormalTexture"]  = "res/ui/ui_material/public/button_currency.png",
        ["buttonPressTexture"]   = "res/ui/ui_material/public/button_currency_active.png",
        ["buttonDisableTexture"] = "res/ui/ui_material/public/button_currency_disable.png"
    }
    if not usableFlag then
        buttonComfirm:loadTextures(tButtonTexturePath.buttonDisableTexture,
            tButtonTexturePath.buttonDisableTexture,
            tButtonTexturePath.buttonDisableTexture)
    else
        buttonComfirm:loadTextures(tButtonTexturePath.buttonNormalTexture,
            tButtonTexturePath.buttonPressTexture,
            tButtonTexturePath.buttonDisableTexture)
    end
    buttonComfirm:setTouchEnabled(usableFlag)
    local function onUseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click") 
            local function sure(newName)
                cclog("use item: " .. getItemName(item))
                require("src/network/KC2SProtocolManager"):useItem(item.nTemplateID, newName)
            end

            if getItemSubType(item) == ITEM_SMALL_TYPE.CHANGENAME then
                KUtil.showItemChangeNameComfirmation(item.nTemplateID, sure)
                return
            end
            
            local showString = string.format(KUtil.getStringByKey("repaircard.expandBar"), getItemName(item))
            KUtil.showCostItemComfirmation(showString, item.nTemplateID, sure)
        end
    end
    buttonComfirm:addTouchEventListener(onUseClick)
end

function KUIItemNode:refreshItemListUI(isJumpToTop)
    local mainNode           = self._mainLayout
    local imageCommonBase    = mainNode:getChildByName("Image_common_base")
    local projectNodeRight   = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight     = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase      = panelItemRight:getChildByName("Image_dj_base")
    local scrollViewItemList = imageItemBase:getChildByName("Scrollview_tank_list")
    if isJumpToTop then
        scrollViewItemList:jumpToTop()
    end

    for index, item in ipairs(self._itemList) do
        local itemUnitName = "item_unit_" .. index
        local itemUnit     = scrollViewItemList:getChildByName(itemUnitName)

        if itemUnit then
            local textItemName = itemUnit:getChildByName("Text_tank_name")
            textItemName:setString(getItemName(item))

            local imageItem    = itemUnit:getChildByName("Image_gear")
            loadImageToItemNode(imageItem, self._originItemNodeSize, item)

            local imageNumberBase = itemUnit:getChildByName("Image_number_base")
            local textItemNumber  = itemUnit:getChildByName("BitmapFontLabel_nunber")
            imageNumberBase:setVisible(true)
            textItemNumber:setString(getItemCount(item))

            local function onItemClick(sender, type)
                if type == ccui.TouchEventType.ended then
                    cclog("show item detail: " .. getItemName(item))
                    KSound.playEffect("click") 
                    refreshItemDetail(self, item)
                end
            end
            itemUnit:addTouchEventListener(onItemClick)
        end
    end
end

function KUIItemNode:sortItem()
    self:initItemList()
    local itemList          = self._itemList
    local szCurrentSortType = m_tSortDataName[self._currentSortTypeIndex]

    -- sort by dynamic data
    if szCurrentSortType == "time" then
        reverseItemList(self)

        return 
    elseif szCurrentSortType == "count" then
        local function sortByCount(item1, item2)
            assert(item1.nCount and item2.nCount, "you item is not exist~")
            return item1.nCount > item2.nCount
        end
        table.sort(itemList, sortByCount)

        return 
    end

    -- sort by static data
    local allItemInfo = getItemInfo()
    local function sortBy(item1, item2)
        local value1 = allItemInfo[item1.nTemplateID][szCurrentSortType]
        local value2 = allItemInfo[item2.nTemplateID][szCurrentSortType]
        return value1 > value2
    end
    table.sort(itemList, sortBy)
end

function KUIItemNode:refreshSortButton()
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNodeButtom = imageCommonBase:getChildByName("ProjectNode_buttom")
    local panelItemBottom   = projectNodeButtom:getChildByName("Panel_item_bottom")
    local buttonCommonSort  = panelItemBottom:getChildByName("Button_common_sort")
    for _, name in ipairs(m_tSortTypeName) do
        local imageSortName    = "Image_sort_" .. name
        local imageControlSort = buttonCommonSort:getChildByName(imageSortName)
        imageControlSort:setVisible(false)
    end

    local imageSortName    = "Image_sort_" .. m_tSortTypeName[self._currentSortTypeIndex]
    local imageControlSort = buttonCommonSort:getChildByName(imageSortName)
    imageControlSort:setVisible(true)
end

function KUIItemNode:initItemList()
    self._itemList    = {}
    local allItemList = getItemList()
    for _, item in ipairs(allItemList) do
        if item ~= nil and getItemVisible(item) then
            table.insert(self._itemList, item)
        end
    end
end

function KUIItemNode:initItemScrollView()
    local mainNode           = self._mainLayout
    local imageCommonBase    = mainNode:getChildByName("Image_common_base")
    local projectNodeRight   = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight     = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase      = panelItemRight:getChildByName("Image_dj_base")
    local scrollViewItemList = imageItemBase:getChildByName("Scrollview_tank_list")
    scrollViewItemList:removeAllChildren()
    local itemUnitBase       = self._itemUnitBase

    local scrollViewWidth   = scrollViewItemList:getContentSize().width
    local scrollViewHeight  = scrollViewItemList:getContentSize().height
    local basePositionX     = itemUnitBase:getPositionX()
    local basePositionY     = itemUnitBase:getPositionY()
    local baseContentWidth  = itemUnitBase:getContentSize().width
    local baseContentHeight = itemUnitBase:getContentSize().height

    local interval         = (scrollViewWidth - baseContentWidth * ITEM_COUNT_ONE_LINE) / (1.5 * ITEM_COUNT_ONE_LINE)
    local realScrollHeight = (interval + baseContentHeight) * math.ceil(#self._itemList / ITEM_COUNT_ONE_LINE)
    if realScrollHeight < scrollViewHeight then realScrollHeight = scrollViewHeight end
    scrollViewItemList:setInnerContainerSize(cc.size(scrollViewWidth, realScrollHeight))

    local heightOffset = realScrollHeight - scrollViewHeight
    basePositionY      = basePositionY + heightOffset

    for index, item in ipairs(self._itemList) do
        local newItemUnit    = itemUnitBase:clone()

        local lineIndex      = math.ceil(index / ITEM_COUNT_ONE_LINE)
        local positionInLine = (index - 1) % ITEM_COUNT_ONE_LINE + 1
        local itemPositionX  = basePositionX + (positionInLine - 1) * (baseContentWidth + interval)
        local itemPositionY  = basePositionY - (lineIndex - 1) * (baseContentHeight + interval)
        newItemUnit:setPosition(cc.p(itemPositionX, itemPositionY))

        newItemUnit:setName("item_unit_" .. index)
        scrollViewItemList:addChild(newItemUnit)
    end
end

function KUIItemNode:refreshUI()
    self:refreshSortButton()
    self:sortItem()
    self:refreshItemListUI(true)
end

function KUIItemNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNodeButtonHome = mainNode:getChildByName("ProjectNode_button_home")
    local panelCommonHome   = projectNodeButtonHome:getChildByName("Panel_common_home")

    local buttonControl = panelCommonHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._parent:returnOffice()
            KSound.playEffect("close") 
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    local function onCloseCallBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, onCloseCallBack, "dj_base")

    local projectNodeRight  = imageCommonBase:getChildByName("ProjectNode_right")
    local panelItemRight    = projectNodeRight:getChildByName("Panel_item_right")
    local imageItemBase     = panelItemRight:getChildByName("Image_dj_base")
    local projectNodeButtom = imageCommonBase:getChildByName("ProjectNode_buttom")
    local panelItemBottom   = projectNodeButtom:getChildByName("Panel_item_bottom")
    local buttonSort        = panelItemBottom:getChildByName("Button_common_sort")
    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click") 
            self._currentSortTypeIndex = self._currentSortTypeIndex + 1
            if self._currentSortTypeIndex > #m_tSortTypeName then
                self._currentSortTypeIndex = 1
            end

            hideItemDetail(self)
            self._currentItemTemplateID = nil
            self:refreshUI()
        end 
    end
    buttonSort:addTouchEventListener(onSortClick)

    local scrollControl   = imageItemBase:getChildByName("Scrollview_tank_list")
    local sliderControl   = imageItemBase:getChildByName("Slider_scroll")
    local function onSliderChanged(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(sliderControl:getPercent())
        end
    end
    sliderControl:addEventListener(onSliderChanged)

    local function onScrollChanged(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        sliderControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChanged)
end

function KUIItemNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onItemRemove()
        cclog("onEvent ----------> remove item")
        self:initItemList()
        self:initItemScrollView()
        hideItemDetail(self)
        self:refreshUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_REMOVE, onItemRemove)

    local function onItemAdd()
        cclog("onEvent ----------> add item")
        self:initItemList()
        self:initItemScrollView()
        self:refreshUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_ADD, onItemAdd)

    local function onItemUpdate(nTemplateID)
        cclog("onEvent ----------> update item count")
        self:refreshSortButton()
        self:sortItem()
        self:refreshItemListUI(false)

        local item = nil
        for _, v in ipairs(getItemList()) do
            if v.nTemplateID == self._currentItemTemplateID then
                item = v
            end
        end
        if item ~= nil then
            refreshItemDetail(self, item)
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ITEM_UPDATE, onItemUpdate)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIItemNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIItemNode:playProjectNodeRight(isOpenPanel)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_right")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_item_right.csb")
    local nStart            = 0
    local nMiddle           = 15
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

function KUIItemNode:playProjectNodeLeft(isOpenPanel)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_left")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_item_left.csb")
    local nStart            = 0
    local nMiddle           = 15
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

function KUIItemNode:playProjectNodeButtom(isOpenPanel)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommonBase:getChildByName("ProjectNode_buttom")
    local projectAction     = cc.CSLoader:createTimeline("res/ui/animation_node/ani_item_bottom.csb")
    local nStart            = 0
    local nMiddle           = 15
    local nMiddleStart      = 50
    local nEnd              = 65
    local FPS               = 60
    local actionTime        = 0
    projectNode:stopAllActions()
    projectNode:runAction(projectAction)
    if isOpenPanel then 
        projectAction:gotoFrameAndPlay(nStart, nMiddle, false)
        actionTime = (nMiddle - nStart) / FPS
    else
        projectAction:gotoFrameAndPlay(nMiddleStart, nEnd, false)
        actionTime = (nMiddleStart - nMiddle) / FPS
    end

    return actionTime
end

local function stopAllAnimation(self)
    KUtil.stopCommonAnimation(self)
end

function KUIItemNode:onInitUI()
    self:initItemList()
    generateItemUnit(self)
    self:initItemScrollView()
    hideItemDetail(self)
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
end

function KUIItemNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    self:playProjectNodeRight(true)
    self:playProjectNodeLeft(true)
    self:playProjectNodeButtom(true)
end

function KUIItemNode:onCleanup()
    if self._itemUnitBase then self._itemUnitBase:release() end
end

function KUIItemNode:getEnterAction()
end

return KUIItemNode
