--  Copyright(c) KingSoft
--  FileName    : KUILaunchMapsNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/28   15:26
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************


local PLAYER_TOUCH_EFFECT_OFFSET    = 100 -- pixel
local ACTIVITY_ZONE_UIINDEX         = 7
local DIFFICULTY_SELECTION_MODEL    = 2

local ZONEINFO = {
     {
        ["zoneID"]          = 1,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_slbzb", 
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_slbzb.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_slbzb_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_slbzb.png",
        ["titleName"]       = "Image_cj_title_slbzb",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    {   
        ["zoneID"]          = 2,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_nbzx", 
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_nbzx.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_nbzx_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_nbzx.png",
        ["titleName"]       = "Image_cj_title_nbzx",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    {
        ["zoneID"]          = 3,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_dbzx", 
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_dbzx.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_dbzx_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_dbzx.png",
        ["titleName"]       = "Image_cj_title_dbzx",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    {
        ["zoneID"]          = 4,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_dbfg", 
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_dbfg.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_dbfg_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_dbfg.png",
        ["titleName"]       = "Image_cj_title_dbfg",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    {
        ["zoneID"]          = 5,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_xbzx", 
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_xbzx.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_xbzx_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_xbzx.png",
        ["titleName"]       = "Image_cj_title_xbzx",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    {
        ["zoneID"]          = 6,
        ["isActivityZone"]  = false,
        ["controlName"]     = "Button_area_berlin",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_berlin.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_berlin_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_berlin.png",
        ["titleName"]       = "Image_cj_title_berlin",
        ["updateFunction"]  = "updateOneNormalPVEZone",
        ["registerTouchEventFunction"] = "registerNormalMapTouchEvent",
    },
    --[[
    {
        ["zoneID"]          = 7,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_newyear.png",
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_newyear_active.png",
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_newyear.png",
        ["titleName"]       = "Image_cj_title_newyear",
        ["updateFunction"]  = "updateOneActivityPVEZone",
    },
    {
        ["zoneID"]          = 8,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_christmas.png",
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_christmas_active.png",
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_christmas.png",
        ["titleName"]       = "Image_cj_title_typhoon",
        ["updateFunction"]  = "updateOneActivityPVEZone",
    },
    {
        ["zoneID"]          = 9,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_activity.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_activity_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_activity.png",
        ["titleName"]       = "Image_cj_title_yellow",
        ["updateFunction"]  = "updateOneActivityPVEZone",
    }, 
    {
        ["zoneID"]          = 10,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/dday_map_activity.png",
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/dday_map_activity_active.png",
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/dday_map_activity.png",
        ["titleName"]       = "Image_cj_title_dday",
        ["updateFunction"]  = "updateOneActivityPVEZone",
        ["registerTouchEventFunction"] = "registerActivityMapTouchEvent",
    }
    {
        ["zoneID"]          = 11,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_activity.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_activity_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_activity.png",
        ["titleName"]       = "Image_cj_title_yellow",
        ["updateFunction"]  = "updateOneActivityPVEZone",
        ["registerTouchEventFunction"]  = "registerActivityMapTouchEvent",
    },
    --]]
    {
        ["zoneID"]          = 13,
        ["isActivityZone"]  = true,
        ["controlName"]     = "Button_area_activity",
        ["normalTexture"]   = "res/ui/ui_material/launch_maps/cj_map_event.png", 
        ["pressTexture"]    = "res/ui/ui_material/launch_maps/cj_map_event_active.png", 
        ["disableTexture"]  = "res/ui/ui_material/launch_maps/cj_map_event.png",
        ["titleName"]       = "Image_cj_title_activity",
        ["updateFunction"]  = "updateOneActivityPVEZone",
        ["registerTouchEventFunction"]  = "registerActivityMapTouchEvent",
    },
}

local ACTIVITY_ZONE_ID = 13

local KUILaunchMapsNode = class(
    "KUILaunchMapsNode" , function () return require("src/ui/uibase/KUINodeBase").create() end
)

local function getBattleData()
    return KPlayer.tBattleData
end

local function getZoneData(zoneID)
    local battleData = getBattleData()
    return HArray.FindFirst(battleData, "nZoneID", zoneID)
end

local function getMapData(zoneID, mapID)
    local zoneData = getZoneData(zoneID)
    if not zoneData then
        return
    end

    return HArray.FindFirst(zoneData.tMaps, "nMapID", mapID)
end

local function getMapSpecialData(zoneID, mapID)
    return KPlayer:GetBattleMapSpecialData(zoneID, mapID)
end

local function isMapOpen(zoneID, mapID)
    return getMapData(zoneID, mapID) ~= nil
end

local function isActivityOpen()
    local zoneSetting = KConfig:getLine("battle", ACTIVITY_ZONE_ID, 1, 1)
    if not KUtil.isInOpenTime(zoneSetting.szOpenCondition) then
        return false
    end

    return  isMapOpen(ACTIVITY_ZONE_ID, 1)
end

function KUILaunchMapsNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._pageIndex     = 1 
end

function KUILaunchMapsNode.create(owner, info)
    local currentNode = KUILaunchMapsNode.new()
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_launch_maps_v5.csb"
    currentNode._info = info
    currentNode:init()

    return currentNode
end

local function isMapNew(zoneID, mapID)
    local mapData = getMapData(zoneID, mapID)
    return mapData ~= nil and #mapData.tFinishFoothold <= 1
end

local function isMapPass(zoneID, mapID)
    local mapData = getMapData(zoneID, mapID)
    return mapData and mapData.bPass
end

local function isMapPerfect(zoneID, mapID)
    local mapData = getMapData(zoneID, mapID)
    if not mapData then
        return false
    end

    local finishedfoothold = mapData.tFinishFoothold

    local processed     = {}
    local toprocessed   = {1}
    while #toprocessed > 0 do
        local footholdID = table.remove(toprocessed, 1)
        if not HArray.FindFirstByValue(finishedfoothold, footholdID) then
            return false
        end
        processed[footholdID] = true

        local footholdSetting = KConfig:getLine("battle", zoneID, mapID, footholdID)
        assert(footholdSetting)
        for _, branch in ipairs(footholdSetting.tBranches) do
            if not processed[branch[1]] then
                table.insert(toprocessed, branch[1])
            end
        end
    end
    
    local mapSetting = KConfig:getLine("battle", zoneID, mapID, 1)
    local nextMaps = mapSetting.tNextMap
    local battleData = getBattleData()
    local zoneData = HArray.FindFirst(battleData, "nZoneID", zoneID) 
    for _, nextMapID in ipairs(nextMaps) do
        if not HArray.FindFirst(zoneData.tMaps, "nMapID", nextMapID) then
            return false
        end
    end
    
    local nextZones = mapSetting.tNextZone
    for _, nextZoneID in ipairs(nextZones) do
        if not HArray.FindFirst(battleData, "nZoneID", nextZoneID) then
            return false
         end
    end
    
    return true
end

local function isLow(mapSpecialdata)
    if not mapSpecialdata then return false end
    return mapSpecialdata.bLevel1Pass
end

local function isMedian(mapSpecialdata)
    if not mapSpecialdata then return false end
    return mapSpecialdata.bLevel2Pass
end

local function isHigh(mapSpecialdata)
    if not mapSpecialdata then return false end
    return mapSpecialdata.bLevel3Pass
end

function KUILaunchMapsNode:updateOneActivityPVEZone(panelControl, panelIndex)
    local zoneID = ACTIVITY_ZONE_ID
    local uiMapIndex  = 0
    while true do 
        uiMapIndex           = uiMapIndex + 1
        local buttonMapBase  = panelControl:getChildByName("Button_map_base" .. uiMapIndex)
        if not buttonMapBase then break end

        local mapID          = uiMapIndex
        local mapData        = getMapData(zoneID, mapID)
        local mapSpecialdata = getMapSpecialData(zoneID, mapID)

        local textActivityTime = panelControl:getChildByName("Text_activity_time")
        local avtivityTimeText = KUtil.getStringByKey("activity.time")
        textActivityTime:setString(avtivityTimeText)

        local imageLock                 = buttonMapBase:getChildByName("Image_cj_lock")
        local buttonSelectionDifficulty = buttonMapBase:getChildByName("Button_selection_difficulty")
        local panelBadge                = buttonMapBase:getChildByName("Panel_badge")
        local imageBadgeLow             = panelBadge:getChildByName("Image_badge_general")
        local imageBadgeMedian          = panelBadge:getChildByName("Image_badge_admiral")
        local ImageBadgeHigh            = panelBadge:getChildByName("Image_badge_marshal")

        local isOpen            = isMapOpen(zoneID, mapID)
        local isClearance       = isMapPass(zoneID, mapID)
        local isLow             = isLow(mapSpecialdata)
        local isMedian          = isMedian(mapSpecialdata)
        local isHigh            = isHigh(mapSpecialdata)

        imageBadgeLow:setVisible(isLow and isClearance and not isMedian and not isHigh)
        imageBadgeMedian:setVisible(isMedian and isClearance and not isHigh)        
        ImageBadgeHigh:setVisible(isHigh and isClearance) 
    
        imageLock:setVisible(not isOpen)
        buttonSelectionDifficulty:setTouchEnabled(isOpen)

        local loadingBarBoss = buttonMapBase:getChildByName("LoadingBar_boss") 
        local mapSetting     = KConfig:getLine("battle", zoneID, mapID, 1)
        local nBossHP        = mapSetting.nBossHP
        if nBossHP == 0 then
            loadingBarBoss:setVisible(false)
        else
            loadingBarBoss:setVisible(true)
            if not mapData then 
                loadingBarBoss:setPercent(0) 
            else
                local percent = 100 - math.floor(mapData.nProgress / (nBossHP * 100) * 100)
                if percent < 0 then percent = 0 end 
                if percent > 100 then percent = 100 end
                loadingBarBoss:setPercent(percent)
            end
        end
    end
end

local function playBottomAnimation(self, isOpenPanel)
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_bottom_button")
    local middleFrame = 45
    local animationPath = "ani_launch_maps_bottom_v1"
    return KUtil.playPanelAnimation(projectNode, animationPath, middleFrame, middleFrame, isOpenPanel)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "LaunchMaps", callBacks, isReturnOffice)
end

local function updateBaseInfo(self)
    local mainNode              = self._mainLayout
    local imageBase             = mainNode:getChildByName("Image_common_base")
    local imageInfoBase         = imageBase:getChildByName("Image_cj_base")
    local pageViewMaps          = imageInfoBase:getChildByName("PageView_maps_list")
    local buttonMission         = imageInfoBase:getChildByName("Button_mission")
    local tZoneInfo             = self._showZoneList[self._pageIndex]
    -- buttonMission:setVisible(self._mapID and tZoneInfo and (not tZoneInfo.isActivityZone))
    buttonMission:setVisible(false)

    local buttonLeft            = mainNode:getChildByName("Button_common_left")
    local buttonRight           = mainNode:getChildByName("Button_common_right")
    buttonLeft:setVisible(self._pageIndex ~= 0)
    buttonRight:setVisible(self._pageIndex ~= 0)

    local projectBottomButton   = mainNode:getChildByName("ProjectNode_bottom_button")
    local imageBottomButtonBase = projectBottomButton:getChildByName("Image_bottom_button_base")
    local buttonAreaParent      = imageBottomButtonBase:getChildByName("ScrollView_button")
    for i, v in ipairs(self._showZoneList) do
        local buttonArea        = buttonAreaParent:getChildByName(v.controlName)
        local imageTitle        = imageInfoBase:getChildByName(v.titleName)
        local normalTexture     = v.normalTexture
        local pressTexture      = v.pressTexture
        local disableTexture    = v.disableTexture

        local isChoosePageFlag  = (i == self._pageIndex) 
        if isChoosePageFlag then normalTexture = pressTexture end
        imageTitle:setVisible(isChoosePageFlag)
        buttonArea:loadTextures(normalTexture, pressTexture, disableTexture)
    end

    local imageMissionTitle = imageInfoBase:getChildByName("Image_cj_extend_mission")
    imageMissionTitle:setVisible(self._pageIndex == 0)

    local imageTitleBase    = imageInfoBase:getChildByName("Image_hear_base")
    local imageLaunchTitle  = imageTitleBase:getChildByName("Image_title_baswe")
    imageLaunchTitle:setVisible(self._pageIndex ~= 0)
end

local function scrollToPage(self, pageIndex)
    self._pageIndex = pageIndex
    if pageIndex == 0 then
        return self:updateMissionMap()
    end
    self._pageScrollTo = pageIndex

    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")
    pageViewControl:setVisible(true)
    local panelMission      = imageInfoBase:getChildByName("Panel_mission")
    panelMission:setVisible(false)
    pageViewControl:scrollToPage(pageIndex - 1)
    updateBaseInfo(self)
end

local function updatePageInfo(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")

    local i = 0
    while true do
        i = i + 1
        local zoneInfo =  self._showZoneList[i]
        local panelControl = pageViewControl:getChildByName("Panel_" .. i)
        if not panelControl then
            assert(zoneInfo == nil)
            break 
        end

        if not zoneInfo then
            pageViewControl:removePage(panelControl)
            break
        end

        local updateFunc = zoneInfo.updateFunction
        self[updateFunc](self, panelControl, zoneInfo)
    end
    pageViewControl:setCustomScrollThreshold(PLAYER_TOUCH_EFFECT_OFFSET)
end

local function removeActivityZoneButtonIfNotOpen(self)
    local mainNode              = self._mainLayout
    local imageBase             = mainNode:getChildByName("Image_common_base")
    local imageInfoBase         = imageBase:getChildByName("Image_cj_base")

    local projectBottomButton = mainNode:getChildByName("ProjectNode_bottom_button")
    local imageBottomButtonBase = projectBottomButton:getChildByName("Image_bottom_button_base")
    local buttonAreaParent = imageBottomButtonBase:getChildByName("ScrollView_button")

    for _, v in ipairs(ZONEINFO) do
        local buttonArea        = buttonAreaParent:getChildByName(v.controlName)
        local imageTitle        = imageInfoBase:getChildByName(v.titleName)
        local isValid = HArray.FindFirstByValue(self._showZoneList, v)
        if buttonArea and not isValid then
            buttonAreaParent:removeChild(buttonArea, true)
        end
        if imageTitle and not isValid then
            imageInfoBase:removeChild(imageTitle, true)
        end
    end
end

local function updateMapNode(buttonMapBase, mapSetting)
    if not mapSetting then
        buttonMapBase:setVisible(false)
        return
    end

    local zoneID = mapSetting.nZoneID
    local mapID = mapSetting.nMapID

    buttonMapBase:setVisible(true)
    local imageLock     = buttonMapBase:getChildByName("Image_cj_lock")
    local imageNew      = buttonMapBase:getChildByName("Image_new")
    local panelClearanceBadge   = buttonMapBase:getChildByName("Panel_clearance_badge")
    local imageBadgeClearance   = panelClearanceBadge:getChildByName("Image_badge_1")
    local imageBadgePerfect     = panelClearanceBadge:getChildByName("Image_badge_2")
    local textNameUI   = buttonMapBase:getChildByName("Text_name")

    local isOpen        = isMapOpen(zoneID, mapID)
    local isNew         = isMapNew(zoneID, mapID)
    local isClearance   = isMapPass(zoneID, mapID)
    local isPerfect     = isMapPerfect(zoneID, mapID)
    imageLock:setVisible(not isOpen)
    imageNew:setVisible(isNew)
    imageBadgeClearance:setVisible(isClearance and not isPerfect)
    imageBadgePerfect:setVisible(isPerfect)
    textNameUI:setString(mapSetting.szMapName)

    local panelStar = buttonMapBase:getChildByName("Panel_star")
    local starCount = mapSetting.nStar
    local bigStar = panelStar:getChildByName("Image_star_big")
    if starCount >= 10  then
        bigStar:setVisible(true)
        starCount = starCount - 10
    else
        bigStar:setVisible(false)
    end
    local i = 0
    while true do
        i = i + 1
        local starUI = panelStar:getChildByName("Image_star_" .. i)
        if not starUI then break end
        starUI:setVisible(i <= starCount)
    end
end

function KUILaunchMapsNode:updateOneNormalPVEZone(panelControl, zoneInfo)
    local zoneID = zoneInfo.zoneID
    panelControl.zoneID = zoneID
    local uiMapIndex = 0
    while true do
        uiMapIndex = uiMapIndex + 1
        local mapID = uiMapIndex

        local buttonMapBase = panelControl:getChildByName("Button_map_base" .. uiMapIndex)
        if not buttonMapBase then break end
        local mapSetting = KConfig:getLine("battle", zoneID, mapID, 1)
        updateMapNode(buttonMapBase, mapSetting)

        if uiMapIndex > 1 and not mapSetting then
            local arrowUI = panelControl:getChildByName("Image_arrow_" .. (uiMapIndex - 1))
            arrowUI:setVisible(false)
        end
    end
end

function KUILaunchMapsNode:updateMissionMap()
    if not self._mapID or not self._oneMission then return end
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")
    pageViewControl:setVisible(false)
    local panelMission      = imageInfoBase:getChildByName("Panel_mission")
    panelMission:setVisible(true)
    updateBaseInfo(self)

    local tMissionConfig   = KUtil.getMissionConfig(self._oneMission.nID)
    assert(tMissionConfig)
    local imageBase        = panelMission:getChildByName("Image_special_mission_base")
    local imageMissionBase = imageBase:getChildByName("Image_description_base")
    local textDescribe     = imageMissionBase:getChildByName("Text_description_value")
    textDescribe:setString(tMissionConfig.szDescribe)

    local tReward          = KUtil.getRewardRandResult(tMissionConfig.nReward)
    local nMaxIconCount    = 4
    local nIconIndex       = 0
    for i, item in ipairs(tReward) do
        if nIconIndex >= nMaxIconCount then break end
        local rewardType = item.nType
        local nID        = item.nID
        local nNum       = item.nNum
        if nID ~= 0 and nNum ~= 0 then
            if rewardType ~= ITEM_TYPE.CURRENCY or nID == CURRENCY_TYPE.COIN then
                local panelItem = imageMissionBase:getChildByName("Panel_reward_" .. nIconIndex + 1)
                panelItem:setVisible(true)
                local panelClipping = panelItem:getChildByName("Panel_icon")
                local imageItemIcon = panelClipping:getChildByName("Image_icon")
                local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, nID)
                panelClipping:setClippingEnabled(clipping)
                local scale = scaleRatio * 1.42
                imageItemIcon:loadTexture(filePath)
                imageItemIcon:setScale(scale)
                nIconIndex = nIconIndex + 1
            end
        end
    end

    for i = nIconIndex + 1, nMaxIconCount do
        local panelItem = imageMissionBase:getChildByName("Panel_reward_" .. i)
        panelItem:setVisible(false)
    end

    local buttonLaunch  = imageMissionBase:getChildByName("Button_attack")
    local function onClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        local nLaunchID 
        if tMissionConfig.nlaunchMonsterGroupID ~= 0 then
            nLaunchID = tMissionConfig.nlaunchMonsterGroupID
        end
        print("LaunchTeam", MISSION_BATTLE_ZONE_ID, self._mapID, nLaunchID)
        self._parent:addNode("LaunchTeam", {MISSION_BATTLE_ZONE_ID, self._mapID, nLaunchID})
    end
    buttonLaunch:addTouchEventListener(onClick)
end

function KUILaunchMapsNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    playBottomAnimation(self, true)
    scrollToPage(self, self._pageIndex)
end

local function stopAllAnimations(self)
    local mainNode = self._mainLayout
    local projectHome = mainNode:getChildByName("ProjectNode_button_home")
    projectHome:stopAllActions()

    local projectBottom = mainNode:getChildByName("ProjectNode_bottom_button")
    projectBottom:stopAllActions()
end

local function initData(self)
    self._showZoneList = {}
    for _, v in ipairs(ZONEINFO) do
        if not v.isActivityZone then
            table.insert(self._showZoneList, v)
        elseif v.zoneID == ACTIVITY_ZONE_ID and isActivityOpen() then
            table.insert(self._showZoneList, v)
        end
    end

    local setting      = require("src/logic/KSetting")
    local lastPlayerId = setting.getInt(setting.Key.LAST_LAUNCH_PLAYER_ID)
    if KPlayer.id == lastPlayerId then
        local lastZoneID = setting.getInt(setting.Key.LAST_LAUNCH_ZONE_INDEX)
        if lastZoneID and lastZoneID > 0 then
            local index, zoneInfo = HArray.FindFirstEx(self._showZoneList, "zoneID", lastZoneID)
            if zoneInfo then
                self._pageIndex = index
            end
        end
    end
     
    local info = self._info
    if info and info.page and (info.page == 0 or self._showZoneList[info.page]) then  
        self._pageIndex = info.page 
    end

    self._mapID, self._oneMission = KUtil.getMissionMap()
end

function KUILaunchMapsNode:onInitUI()
    initData(self)
    stopAllAnimations(self)
    updatePageInfo(self)
    removeActivityZoneButtonIfNotOpen(self)
end

function KUILaunchMapsNode:registerNormalMapTouchEvent(panelControl, zoneInfo)
    local zoneID = zoneInfo.zoneID
    local uiMapIndex = 0
    while true do 
        uiMapIndex = uiMapIndex + 1
        local buttonMapBase = panelControl:getChildByName("Button_map_base" .. uiMapIndex)
        if not buttonMapBase then break end 
        local mapID = uiMapIndex 
        local function onMapBaseClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("click")
            cclog("-----> onMapBaseClick zoneID:%d mapID:%d", zoneID, mapID)

            if not isMapOpen(zoneID, mapID) then
                showNoticeByID("launch.map.lock")
                return
            end 
            self._parent:addNode("LaunchTeam", {zoneID, mapID})
        end
        buttonMapBase:addTouchEventListener(onMapBaseClick)
    end
end

function KUILaunchMapsNode:registerActivityMapTouchEvent(panelControl, zoneInfo)
    local zoneID = zoneInfo.zoneID
    local uiMapIndex = 0
    while true do 
        uiMapIndex = uiMapIndex + 1
        local buttonMapBase = panelControl:getChildByName("Button_map_base" .. uiMapIndex)
        if not buttonMapBase then break end 
        local mapID = uiMapIndex 
        local function onMapBaseClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("click")
            cclog("-----> onMapBaseClick zoneID:%d mapID:%d", zoneID, mapID)

            if not isMapOpen(zoneID, mapID) then
                showNoticeByID("launch.map.lock")
                return
            end 
            local mapSpecialData = getMapSpecialData(zoneID, mapID)
            if mapSpecialData.nDiffcult == 0 then
                local function onConfirmCallback()
                    self._parent:addNode("LaunchTeam", {zoneID, mapID})
                end
                self._parent:addNode("SelectionDifficulty", zoneID, mapID, onConfirmCallback)
            else
                self._parent:addNode("LaunchTeam", {zoneID, mapID})   
            end

        end
        buttonMapBase:addTouchEventListener(onMapBaseClick)

        local buttonSelectDiffcult = buttonMapBase:getChildByName("Button_selection_difficulty")
        local function onButtonSelectDiffcultClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("close")
            cclog("-----> LaunchMaps, onButtonSelectDiffcultClick~")
            self._parent:addNode("SelectionDifficulty", zoneID, mapID)
        end
        buttonSelectDiffcult:addTouchEventListener(onButtonSelectDiffcultClick)
    end
end

function KUILaunchMapsNode:registerMapTouchEvent()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")
    
    for panelIndex, zoneInfo in ipairs(self._showZoneList) do
        local panelControl = pageViewControl:getChildByName("Panel_" .. panelIndex)
        self[zoneInfo.registerTouchEventFunction](self, panelControl, zoneInfo)
    end
end

function KUILaunchMapsNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local buttonLeft        = mainNode:getChildByName("Button_common_left")
    local buttonRight       = mainNode:getChildByName("Button_common_right")
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")


    -- mission button
    -- local buttonMission         = imageInfoBase:getChildByName("Button_mission")
    -- local function onButtonMissionClick(sender, type)
    --     if type ~= ccui.TouchEventType.ended then return end
    --     KSound.playEffect("click")
    --     cclog("-----> LaunchMaps, onButtonMissionClick")
    --     scrollToPage(self, 0) 
    -- end
    -- buttonMission:addTouchEventListener(onButtonMissionClick)

    -- close button
    local buttonClose = imageBase:getChildByName("Button_close")
    local function onButtonCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("close")
        cclog("-----> LaunchMaps, onButtonCloseClick")
        playPanelCloseAnimation(self, false)
    end
    buttonClose:addTouchEventListener(onButtonCloseClick)

    -- home button
    local buttonProject = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome = buttonProject:getChildByName("Panel_common_home")
    local buttonHome = panelHome:getChildByName("Button_home")
    local function onButtonHomeClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        KSound.playEffect("click")
        cclog("-----> LaunchMaps, onButtonHomeClick")
        playPanelCloseAnimation(self, true)
    end
    buttonHome:addTouchEventListener(onButtonHomeClick)

    self:registerMapTouchEvent()

    local projectBottomButton = mainNode:getChildByName("ProjectNode_bottom_button")
    local imagebottomButtonBase = projectBottomButton:getChildByName("Image_bottom_button_base")
    local buttonAreaParent = imagebottomButtonBase:getChildByName("ScrollView_button")
    -- arena button
    for k, v in ipairs(self._showZoneList) do
        local buttonArea = buttonAreaParent:getChildByName(v.controlName)
        local function onArenaClick(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            cclog("-----> onArenaClick destPageIndex = %d", k)
            KSound.playEffect("click")
            scrollToPage(self, k) 
        end
        buttonArea:addTouchEventListener(onArenaClick)
    end

    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then
            local currentPage = pageViewControl:getCurPageIndex() + 1
            if self._pageScrollTo then
                if self._pageScrollTo ~= currentPage then
                    return
                end
                self._pageScrollTo = nil
                return
            end
            
            if self._pageIndex == currentPage then
                return
            end
            self._pageIndex = currentPage
            updateBaseInfo(self)
        end
    end
    pageViewControl:addEventListener(onPageViewEvent)
    
    local function onPageLeftClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onLeftClick~")
        KSound.playEffect("click")
        
        local prePageIndex = self._pageIndex - 1
        if prePageIndex < 1 then return end
        
        scrollToPage(self, prePageIndex)
    end
    buttonLeft:addTouchEventListener(onPageLeftClick)
    
    local function onPageRightClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRightClick~")
        KSound.playEffect("click")
        
        local nextPageIndex = self._pageIndex + 1
        if nextPageIndex > #self._showZoneList then return end

        scrollToPage(self, nextPageIndex)   
    end
    buttonRight:addTouchEventListener(onPageRightClick)

    --exchange shop
    local buttonExchange = imagebottomButtonBase:getChildByName("Button_exchange")
    local function onExchangeShopClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onExchangeShopClick")
        KSound.playEffect("click")

        self._parent:addNode("ExchangeShop")
    end
    buttonExchange:setVisible(KUtil.isShopOpen(KUtil.shopType.EXCHANGE))
    buttonExchange:addTouchEventListener(onExchangeShopClick)
end

function KUILaunchMapsNode:registerAllCustomEvent()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local imageInfoBase     = imageBase:getChildByName("Image_cj_base")
    local pageViewControl   = imageInfoBase:getChildByName("PageView_maps_list")
    
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRefreshBossHP(zoneID, mapID, nDiffcult, nProgress)
        if zoneID ~= ACTIVITY_ZONE_ID then
            return
        end

        local panelControl = nil
        for panelIndex, zoneInfo in ipairs(self._showZoneList) do
            if zoneInfo.zoneID == zoneID then
                panelControl = pageViewControl:getChildByName("Panel_" .. panelIndex)
                break
            end
        end

        if panelControl == nil then
            return
        end

        local uiMapIndex = mapID
        local buttonMapBase = panelControl:getChildByName("Button_map_base" .. uiMapIndex)
        local loadingBarBoss = buttonMapBase:getChildByName("LoadingBar_boss")
        local mapSetting     = KConfig:getLine("battle", zoneID, mapID, 1)
        local mapData        = getMapData(zoneID, mapID)
        local nBossHP        = mapSetting.nBossHP
        if nBossHP == 0 then
            loadingBarBoss:setVisible(false)
        else
            loadingBarBoss:setVisible(true)
            if not mapData then 
                loadingBarBoss:setPercent(0) 
            else
                local percent = 100 - math.floor(mapData.nProgress / (nBossHP * 100) * 100)
                if percent < 0 then percent = 0 end 
                if percent > 100 then percent = 100 end
                loadingBarBoss:setPercent(percent)
            end
        end
        cclog("----------> onEvent KUILaunchMapsNode onRefreshBossHP")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CHANGE_DIFFICULTY, onRefreshBossHP)
end

return KUILaunchMapsNode
