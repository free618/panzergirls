--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUILaunchTeamNode.lua
--  Creator     : SunXun
--  Date        : 2015/07/28   13:00
--  Contact     : sunxun@kingsoft.com
--  Comment     :
--  *********************************************************************

local m_szbuttonDisableTexture  = "res/ui/ui_material/public/common_team_button_disable.png"
local TANK_GRAPH_FILL_COLOR     = cc.c4f(0.4000, 0.8000, 1.0, 0.50)
local MAX_TANK_GRAPH_RADIUS     = 88

local KUILaunchTeamNode = class(
    "KUILaunchTeamNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUILaunchTeamNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._zoneID        = 0
    self._mapID         = 0
    self._teamIndex     = 1
    self._launchID       = nil
end

function KUILaunchTeamNode.create(owner, tUserData)
    local currentNode = KUILaunchTeamNode.new()

    currentNode._zoneID = tUserData[1]
    currentNode._mapID = tUserData[2]
    currentNode._launchID = tUserData[3]
    print("KUILaunchTeamNode.create", currentNode._zoneID, currentNode._mapID, currentNode.launchID)
  
    if not currentNode._launchID then
        local setting      = require("src/logic/KSetting")
        local lastPlayerId = setting.getInt(setting.Key.LAST_LAUNCH_PLAYER_ID)
        if lastPlayerId == KPlayer.id then
            local teamIndex = setting.getInt(setting.Key.LAST_LAUNCH_TEAM_INDEX)
            if teamIndex and (teamIndex <= KPlayer.tTeamData.nOpenCount) and (teamIndex > 0) then
                local cardList = KUtil.getOneTeamCardList(teamIndex)
                if #cardList > 0 then
                    currentNode._teamIndex = teamIndex
                end
            end
        end
    end

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_launch_team.csb"
    currentNode:init()

    return currentNode
end

function KUILaunchTeamNode:getLaunchCardList()
    local tTeam = {}
    if self._launchID then
        local tMonsterGroupConfig = KConfig:getLine("monstergroup", self._launchID)
        for i, nMonsterID in ipairs(tMonsterGroupConfig.tMonsterList) do
            local tMonsterConfig = KConfig:getLine("monster", nMonsterID)
            assert(tMonsterConfig)
            tTeam[i] = { tConfig = tMonsterConfig }
        end
    end

    if #tTeam == 0 then
        KUtil.getOneTeamCardList(self._teamIndex)

        local tTeamList = KPlayer.tTeamData.tTeamList
        local tTeamItem = HArray.FindFirst(tTeamList, "nIndex", self._teamIndex)
        if tTeamItem then
            for i,nCardID in ipairs(tTeamItem.tCardIDList) do
                local tCard = KUtil.getCardById(nCardID)
                if tCard then 
                    local tCardConfig = KUtil.getCardConfig(tCard.nTemplateID)
                    assert(tCardConfig)
                    local attribute = KUtil.getCurrentAttribute(tCard, true)
                    local currentHP = attribute[ATTRIBUTE.HP]
                    local tInfo = 
                        {
                            tConfig      = tCardConfig,
                            tCard        = tCard,
                        }
                    tTeam[i] = tInfo
                end
            end
        end
    end

    return tTeam
end

function KUILaunchTeamNode.getTankID(tInfo)
    if tInfo.tCard then
        return tInfo.tCard.nID
    else
        return
    end
end

function KUILaunchTeamNode.getTankTemplateID(tInfo)
    return tInfo.tConfig.nID
end

function KUILaunchTeamNode.getTankName(tInfo)
    return tInfo.tConfig.szName
end

function KUILaunchTeamNode.getTankQuality(tInfo)
    return tInfo.tConfig.nQuality
end

function KUILaunchTeamNode.getTankType(tInfo)
    if tInfo.tCard then
        return tInfo.tConfig.nTankType
    else
        return tInfo.tConfig.nType
    end
end

function KUILaunchTeamNode.getTankCountryType(tInfo)
    print(tInfo, tInfo.tConfig, tInfo.tConfig.szName)
    return tInfo.tConfig.nCountryType
end

function KUILaunchTeamNode.getTankLevel(tInfo)
    if tInfo.tCard then
        return tInfo.tCard.nLevel
    else
        return tInfo.tConfig.nLevel
    end
end

function KUILaunchTeamNode.getTankMaxHP(tInfo)
    if tInfo.tCard then
        return KUtil.getCardMaxHp(tInfo.tCard)
    else
        return tInfo.tConfig.nMaxHP
    end
end

function KUILaunchTeamNode.getTankHP(tInfo)
    if tInfo.tCard then
        local attribute = KUtil.getCurrentAttribute(tInfo.tCard, true)
        return attribute[ATTRIBUTE.HP]
    else
        return tInfo.tConfig.nMaxHP
    end
end

function KUILaunchTeamNode.getTankIsRing(tInfo)
    if tInfo.tCard then
        return tInfo.tCard.bRing
    else
        return false
    end
end

function KUILaunchTeamNode.getTankCarryOil(tInfo)
    if tInfo.tCard then
        return tInfo.tCard.nCurrentOil
    else
        return 0
    end
end

function KUILaunchTeamNode.getTankCarryAmmo(tInfo)
    if tInfo.tCard then
        return tInfo.tCard.nCurrentAmmo
    else
        return 0
    end
end

function KUILaunchTeamNode.getTankMaxOil(tInfo)
    return tInfo.tConfig.nCarryOil or 0
end

function KUILaunchTeamNode.getTankMaxAmmo(tInfo)
    return tInfo.tConfig.nCarryAmmo or 0
end

local function stopAllAnimation(self)
    local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam = imageBase:getChildByName("ProjectNode_team")
    projectNodeTeam:stopAllActions()

    local projectNodeBottom = imageBase:getChildByName("ProjectNode_bottom_button")
    projectNodeBottom:stopAllActions()

    local projectNodeTop = imageBase:getChildByName("ProjectNode_top")
    projectNodeTop:stopAllActions()

    local projectNodeRight = imageBase:getChildByName("ProjectNode_right")
    projectNodeRight:stopAllActions()

    local projectNodeChara = imageBase:getChildByName("ProjectNode_chara")
    projectNodeChara:stopAllActions()

    local projectHome = mainNode:getChildByName("ProjectNode_button_home")
    projectHome:stopAllActions()
end

local function playTeamLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam = imageCommon:getChildByName("ProjectNode_team")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_left"
    return KUtil.playPanelAnimation(projectNodeTeam, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeBottom = imageCommon:getChildByName("ProjectNode_bottom_button")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_bottom"
    return KUtil.playPanelAnimation(projectNodeBottom, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTopAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeTop  = imageCommon:getChildByName("ProjectNode_top")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_top"
    return KUtil.playPanelAnimation(projectNodeTop, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playLaunchInfoAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeRight = imageCommon:getChildByName("ProjectNode_right")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_right"
    return KUtil.playPanelAnimation(projectNodeRight, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playCharacterAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNodeChara = imageCommon:getChildByName("ProjectNode_chara")

    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_launch_team_chara"
    return KUtil.playPanelAnimation(projectNodeChara, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function initTeamTopUI(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")

    local nTeamCount = KPlayer.tTeamData.nOpenCount
    if self._launchID then
        nTeamCount = 1
    end
    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end

        local teamID = i
        if teamID > 1 then
            local teamSheetUI     = panelTop:getChildByName("Button_team_sheet_" .. teamID)
            local projectNodeMark = teamSheetUI:getChildByName("ProjectNode_mark")
            local isExpedition    = KUtil.isTeamInExpedition(teamID)
            projectNodeMark:setVisible(isExpedition)
        end

        if i > nTeamCount then
            teamSheetUI:loadTextures(m_szbuttonDisableTexture, m_szbuttonDisableTexture, m_szbuttonDisableTexture)
            teamSheetUI:setEnabled(false)
            local imageTeamIndex = teamSheetUI:getChildByName("Image_common_team" .. i)
            imageTeamIndex:setVisible(false)
        end
    end
end

local function getRewardItemList(self)
    local showRewardList = {} 
    local footholdID     = 1
    while true do
        local battleSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, footholdID)
        if battleSetting == nil then break end
        local footholdType = FOOTHOLD_TYPE[battleSetting.szFootholdType]
        
        if footholdType == FOOTHOLD_TYPE.RESOURCE then
            local rewardID   = battleSetting.tReward[1][1]
            local rewardList = KUtil.getRewardList(rewardID, ITEM_TYPE.OTHER)
            for i, rewardItem in ipairs(rewardList) do
                local existed = false
                for i, v in ipairs(showRewardList) do
                    if rewardItem.nID == v.nID then
                        existed = true
                        break
                    end
                end
                if not existed then
                    table.insert(showRewardList, rewardItem)
                end                
            end
        end
        
        footholdID = footholdID + 1
    end
    
    return showRewardList
end

local function initBattleInfoUI(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeRight  = imageBase:getChildByName("ProjectNode_right")
    local panelRight        = projectNodeRight:getChildByName("Panel_ani_launch_team_right")

    print("initBattleInfoUI", self._zoneID, self._mapID)
    local tSetting          = KConfig:getLine("battle", self._zoneID, self._mapID, 1)
    local szBattleName      = tSetting.szBattleName
    local textBattleName    = panelRight:getChildByName("Text_mission_name")
    textBattleName:setString(szBattleName)

    local szBattleDesc      = tSetting.szBattleDesc
    local textBattleDesc    = panelRight:getChildByName("Text_mission_description")
    textBattleDesc:setString(szBattleDesc)

    local rewardList        = getRewardItemList(self)
    local panelArticleFrame = panelRight:getChildByName("Panel_article_frame")
    local i = 0
    while true do
        i = i + 1
        local imageQuality = panelArticleFrame:getChildByName("Image_quality_" .. i)
        local rewardItem  = rewardList[i]
        if imageQuality == nil then break end

        if rewardItem ~= nil then
            local panelclipping  = imageQuality:getChildByName("Panel_icon")
            local imageAwardProp = panelclipping:getChildByName("Image_award_prop")
            local imagePath      = KUtil.getItemImagePathByID(rewardItem.nID)
            imageAwardProp:loadTexture(imagePath)
            
            local textName = imageQuality:getChildByName("Text_name")
            local itemName = KUtil.getItemConfigValue(rewardItem.nID, "szName")
            textName:setString(itemName)
            
            imageQuality:setVisible(true)
        else
            imageQuality:setVisible(false)
        end    
    end

    local imageCautionLog = panelRight:getChildByName("Image_caution_log")
    imageCautionLog:setVisible(false)
end

function KUILaunchTeamNode:onInitUI()
    stopAllAnimation(self)
    initTeamTopUI(self)
    initBattleInfoUI(self)
end

local function refreshTeamButton(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")

    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end
        if i == self._teamIndex then
            teamSheetUI:setTouchEnabled(false)
            teamSheetUI:setBrightStyle(1)
        else
            teamSheetUI:setTouchEnabled(true)
            teamSheetUI:setBrightStyle(0)
        end
    end
end

local function refreshOneCardUI(self, imageUnitBase, card)
    if not card then 
        imageUnitBase:setVisible(false)
        return
    end

    imageUnitBase:setVisible(true)
    local headBaseControl = imageUnitBase:getChildByName("Image_common_chara_base")
    local projectNodeCard = headBaseControl:getChildByName("ProjectNode_card")
    local nID             = KUILaunchTeamNode.getTankID(card)
    local nTemplateID     = KUILaunchTeamNode.getTankTemplateID(card)
    if card.tCard then
        KUtil.onlyUpdateCardHeadBase(projectNodeCard, card.tCard)
    else
        KUtil.onlyUpdateCardHeadBaseByMonsterTemplateID(projectNodeCard, nTemplateID)
    end

    local imageOil      = headBaseControl:getChildByName("Image_cj_oil_warning")
    imageOil:setVisible(KUILaunchTeamNode.getTankMaxOil(card) > KUILaunchTeamNode.getTankCarryOil(card))

    local imageAmmo     = headBaseControl:getChildByName("Image_cj_ammo_warning")
    imageAmmo:setVisible(KUILaunchTeamNode.getTankMaxAmmo(card) > KUILaunchTeamNode.getTankCarryAmmo(card))

    local imageRepairing = headBaseControl:getChildByName("Image_common_repairing")
    imageRepairing:setVisible(nID and KUtil.isCardRepair(nID))

    local labelTankName = headBaseControl:getChildByName("Text_tank_name")
    KUtil.cutTextLength(labelTankName, KUILaunchTeamNode.getTankName(card), 140)

    local labelTankLevel = headBaseControl:getChildByName("BitmapFontLabel_series")
    labelTankLevel:setString("lv." .. KUILaunchTeamNode.getTankLevel(card))

    local maxHp     = KUILaunchTeamNode.getTankMaxHP(card)
    local currentHP = KUILaunchTeamNode.getTankHP(card)

    local cardHPPercent = currentHP / maxHp * 100
 
    local hpName    = {nil, nil, nil, nil, nil}
    local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
    KUtil.drawCardState(nil, headBaseControl, hpName, stateName, cardHPPercent)
end

local function refreshTeamDetail(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTeam   = imageBase:getChildByName("ProjectNode_team")
    local panelTeam         = projectNodeTeam:getChildByName("Panel_launch_team_left")

    local cardList = self:getLaunchCardList()
    local i = 0
    while true do
        i = i + 1
        local imageUnitBase   = panelTeam:getChildByName("Node_cj_team_unit_" .. i)
        if not imageUnitBase then break end

        local card = cardList[i]
        refreshOneCardUI(self, imageUnitBase, card)
    end
end

local function refreshAttribteGraph(self, teamAttribute)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeRight  = imageBase:getChildByName("ProjectNode_right")
    local panelRight        = projectNodeRight:getChildByName("Panel_ani_launch_team_right")
    local teamAttributeUI   = panelRight:getChildByName("Image_cj_radar_net")
    local radarCenter       = teamAttributeUI:getChildByName("Node_radar_center")
    local drawNodeGraph     = radarCenter:getChildByName("drawNodeGraph")
    if not drawNodeGraph then
        drawNodeGraph = cc.DrawNode:create()
        drawNodeGraph:setName("drawNodeGraph")
        radarCenter:addChild(drawNodeGraph)
    end

    local attributeList = 
    {
        {teamAttribute[ATTRIBUTE.HP], MAX_TEAM_ATTRIBUTE.HP},
        {teamAttribute[ATTRIBUTE.FRONTARMOUR] + teamAttribute[ATTRIBUTE.REARARMOUR], MAX_TEAM_ATTRIBUTE.ARMOUR},
        {teamAttribute[ATTRIBUTE.DODGE], MAX_TEAM_ATTRIBUTE.DODGE},
        {teamAttribute[ATTRIBUTE.SPEED], MAX_TEAM_ATTRIBUTE.SPEED},
        {teamAttribute[ATTRIBUTE.PENETRATE], MAX_TEAM_ATTRIBUTE.PENETRATE},
        {teamAttribute[ATTRIBUTE.ATTACK], MAX_TEAM_ATTRIBUTE.ATTACK},
    }

    local attributeCount    = #attributeList
    local spanAngleRadians  = math.pi * 2 / attributeCount
    local startAngleRadians = 0
    local pointArray        = {}

    for i = 1, attributeCount do
        local attribValue         = attributeList[i][1]
        local attribMax           = attributeList[i][2]

        local currentAngleRadians = startAngleRadians + ( i - 1 ) * spanAngleRadians
        local attributeWeigth     = math.min(1.0, attribValue / attribMax )
        local attribRadius        = attributeWeigth * MAX_TANK_GRAPH_RADIUS
        local attribPointX        = attribRadius * math.sin(currentAngleRadians)
        local attribPointY        = attribRadius * math.cos(currentAngleRadians)

        table.insert(pointArray, i, cc.p(attribPointX, attribPointY))
    end

    drawNodeGraph:stopAllActions()
    drawNodeGraph:clear()
    drawNodeGraph:drawSolidPoly(pointArray, #pointArray, TANK_GRAPH_FILL_COLOR)
end

local function refreshTeamAttribte(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeRight  = imageBase:getChildByName("ProjectNode_right")
    local panelRight        = projectNodeRight:getChildByName("Panel_ani_launch_team_right")

    local teamAttribute   
    if self._launchID then
        teamAttribute   = {}
        local tTankList = self:getLaunchCardList()
        for _, tInfo in ipairs(tTankList) do
            local tAttribute = KUtil.getMonsterAttribute(tInfo.tConfig.nID)
            for k, v in pairs(tAttribute) do
                teamAttribute[k] = (teamAttribute[k] or 0) + v
            end
        end
    else
        teamAttribute = KUtil.getTeamAttribute(self._teamIndex, false)
    end
    local teamAttributeUI = panelRight:getChildByName("Image_cj_radar_net")

    local uiAttribteName2Value = 
    {
        Text_nj_value = teamAttribute[ATTRIBUTE.HP],
        Text_zj_value = teamAttribute[ATTRIBUTE.FRONTARMOUR] + teamAttribute[ATTRIBUTE.REARARMOUR],
        Text_hb_value = teamAttribute[ATTRIBUTE.DODGE],
        Text_sd_value = teamAttribute[ATTRIBUTE.SPEED],
        Text_ct_value = teamAttribute[ATTRIBUTE.PENETRATE],
        Text_hl_value = teamAttribute[ATTRIBUTE.ATTACK],
    }

    for k, v in pairs(uiAttribteName2Value) do
        local attributeUI = teamAttributeUI:getChildByName(k)
        attributeUI:setString(tostring(v))
    end
    
    refreshAttribteGraph(self, teamAttribute)
end

local function refreshCharacterImage(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeChara  = imageBase:getChildByName("ProjectNode_chara")
    local panelChara        = projectNodeChara:getChildByName("Panel_common_chara")
    local imageChara        = panelChara:getChildByName("Image_common_chara")

    local cardList = self:getLaunchCardList()
    local backgroundImagePath = "res/ui/ui_material/award/jl_background1.png"
    if #cardList == 0 then
        imageChara:setVisible(false)
        imageBase:loadTexture(backgroundImagePath)
        return 
    end
    imageChara:setVisible(true)
    local teamLeaderCard = cardList[1] --KUtil.getTeamLeaderCard(self._teamIndex)
    assert(teamLeaderCard, "can not find team leader in team " .. self._teamIndex)

    local nLeaderTemplateID = KUILaunchTeamNode.getTankTemplateID(teamLeaderCard)
    local cardImagePath
    if teamLeaderCard.tCard then
        cardImagePath = KUtil.getCardImagePath(teamLeaderCard.tCard, false)
    else
        cardImagePath = KUtil.getMonsterImagePathByConfigID(nLeaderTemplateID, false)
    end
    imageChara:loadTexture(cardImagePath)

    local cardConfig   = KUtil.getCardConfig(nLeaderTemplateID)
    local nQuality     = KUILaunchTeamNode.getTankQuality(teamLeaderCard)
    local bRing        = KUILaunchTeamNode.getTankIsRing(teamLeaderCard)

    backgroundImagePath = "res/ui/ui_material/award/jl_background" .. nQuality .. ".png"
    -- if bRing then
    --     backgroundImagePath = "res/ui/ui_material/award/jl_background_ring.png"
    -- end
    imageBase:loadTexture(backgroundImagePath)
end

function KUILaunchTeamNode:refreshBottom()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeBottom = imageBase:getChildByName("ProjectNode_bottom_button")
    local panelBottom       = projectNodeBottom:getChildByName("Panel_launch_team_bottom")
    local imageBottom       = panelBottom:getChildByName("Image_bottom_button")
    local buttonSupply      = imageBottom:getChildByName("Button_quick_supply_button")
    local buttonRepair      = imageBottom:getChildByName("Button_quick_repair")
    if self._launchID then
        KUtil.setTouchEnabledAndDisable(buttonSupply, false)
        KUtil.setTouchEnabledAndDisable(buttonRepair, false)
    end
end

function KUILaunchTeamNode:refreshUI()
    refreshTeamButton(self)
    refreshTeamDetail(self)
    refreshTeamAttribte(self)
    refreshCharacterImage(self)
    self:refreshBottom()
end

function KUILaunchTeamNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    playTeamLeftAnimation(self, true)
    playBottomAnimation(self, true)
    playTopAnimation(self, true)
    playLaunchInfoAnimation(self, true)
    playCharacterAnimation(self, true)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, playTeamLeftAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playLaunchInfoAnimation(self, false))
        table.insert(framesList, playCharacterAnimation(self, false))
        
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "LaunchTeam", callBacks, isReturnOffice)
end

local function registerTeamTopEvent(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeTop    = imageBase:getChildByName("ProjectNode_top")
    local panelTop          = projectNodeTop:getChildByName("Panel_launch_team_top")

    local buttonClose       = panelTop:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")       
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local i = 0
    while true do
        i = i + 1
        local teamSheetUI = panelTop:getChildByName("Button_team_sheet_" .. i)
        if not teamSheetUI then break end

        local teamIndex = i
        local function onTeamSheetClick(send, type)
            if type ~= ccui.TouchEventType.ended then return end
            KSound.playEffect("click")
            local cardList = self:getLaunchCardList()
            if #cardList == 0 then
                showNoticeByID("common.empty_team")
                return
            end

            self._teamIndex = teamIndex
            self:refreshUI()
        end
        teamSheetUI:addTouchEventListener(onTeamSheetClick)
    end
end

local function isCanLaunch(self)
    local cardList = self:getLaunchCardList()
    if #cardList == 0 then
        showNoticeByID("common.empty_team")
        return false
    end
    
    local captain    = cardList[1]--KUtil.getCaptainCard(self._teamIndex)
    -- local cardConfig = KConfig.cardInfo[captain.nTemplateID]
    local maxHP      = KUILaunchTeamNode.getTankMaxHP(captain) --KUtil.getCardMaxHp(captain)
    local percentage = KUILaunchTeamNode.getTankHP(captain) / maxHP
    local breakePercentage = 0.25
    if percentage <= breakePercentage then
        showNoticeByID("launch.team.damage")
        return false
    end
    
    local isRepairCard = nil
    for key, card in ipairs(cardList) do
        local nID = KUILaunchTeamNode.getTankID(card)
        if KUtil.isCardInRepairList(nID) then
            isRepairCard = card 
            break
        end
    end
    if isRepairCard then
        local cardName = KUILaunchTeamNode.getTankName(isRepairCard)  --KConfig["cardInfo"][isRepairCard.nTemplateID]["szName"]
        showNoticeByID("repairecard.repairing", cardName)
        return false
    end
    
    if not self._launchID then
        local isTeamExpedition = KUtil.isTeamInExpedition(self._teamIndex)
        if isTeamExpedition then
            showNoticeByID("common.team_in_expedition")
            return false
        end
    end
    
    local allCardsCount  = KUtil.getCardCount()
    local cardStoreSize  = KUtil.getCardStoreSize()
    local battleNeedCard = 5 
    if allCardsCount + 5 > cardStoreSize then
        showNoticeByID("launch.CardStoreNotEnough")
        return false
    end
    
    if not KUtil.isEnoughEquipStore(battleNeedCard) then
        showNoticeByID("launch.EquipStoreNotEnough")
        return false
    end
    
    for _, card in ipairs(cardList) do
        if card.tCard and 
            (KUILaunchTeamNode.getTankCarryOil(card) <= 0 or
             KUILaunchTeamNode.getTankCarryAmmo(card) <= 0) then
            showNoticeByID("launch.SupplyNotEnough", KUILaunchTeamNode.getTankName(card))
            return false
        end
    end

    if KUtil.getMapLaunchCount(self._zoneID, self._mapID) == 0 then
        local tSetting = KUtil.getBattleSetting(self._zoneID, self._mapID, 1)
        assert(tSetting)
        showNoticeByID("launch.maxCount", tSetting.nDayCount)
        return false
    end

    return true
end

local function registerTeamBottomEvent(self)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_common_base")
    local projectNodeBottom = imageBase:getChildByName("ProjectNode_bottom_button")
    local panelBottom       = projectNodeBottom:getChildByName("Panel_launch_team_bottom")
    local imageBottom       = panelBottom:getChildByName("Image_bottom_button")
    local buttonLaunch      = imageBottom:getChildByName("Button_launch_button")
    local function onLaunchClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> buttonLaunchClick~")
        KSound.playEffect("startLaunce")

        if not isCanLaunch(self) then return end

        local function battle()
            local cardList = self:getLaunchCardList()
            KSound.playTalk(KSound.TALK.LAUNCH, KUILaunchTeamNode.getTankTemplateID(cardList[1]), not cardList[1].tCard)
            
            local setting = require("src/logic/KSetting")
            setting.setInt(setting.Key.LAST_LAUNCH_ZONE_INDEX, self._zoneID)
            setting.setInt(setting.Key.LAST_LAUNCH_TEAM_INDEX, self._teamIndex)
            local lastPlayerId = setting.getInt(setting.Key.LAST_LAUNCH_PLAYER_ID)
            if lastPlayerId ~= KPlayer.id then
                setting.setInt(setting.Key.LAST_LAUNCH_PLAYER_ID, KPlayer.id)
            end
            local userData = 
            {
                battleType = BATTLE_TYPE.NORMAL,
                zoneID     = self._zoneID,
                mapID      = self._mapID,
                teamIndex  = self._teamIndex,
                launchID   = self._launchID
            }
            
            local battleScene = require("src/ui/battle/KUIBattleScene").create(userData, "Launch")
            KUtil.replaceSceneAndRemoveAllTexture(battleScene)
        end

        local isBrokenCard = KUtil.isHaveBrokenCard(self._teamIndex)
        if isBrokenCard then
            local confirmationInfo = KUtil.getStringByKey("battle.hasBrokenCard")
            showConfirmation(confirmationInfo, battle)
        else
            battle()
        end
    end
    buttonLaunch:addTouchEventListener(onLaunchClick)

    local buttonSupply = imageBottom:getChildByName("Button_quick_supply_button")
    local function onQuickSupplyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onSupplyClick~")
        KSound.playEffect("click")
        KUtil.supplyTeamCard(self._teamIndex)
    end
    buttonSupply:addTouchEventListener(onQuickSupplyClick)

    local buttonRepair = imageBottom:getChildByName("Button_quick_repair")
    local function onQuickRepairClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRepairClick~")
        KSound.playEffect("click")
        self._parent:addNode("QuickRepair", self._teamIndex)
    end
    buttonRepair:addTouchEventListener(onQuickRepairClick)
end

function KUILaunchTeamNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local buttonProject = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome     = buttonProject:getChildByName("Panel_common_home")
    local buttonHome    = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")       
            playPanelCloseAnimation(self, true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    registerTeamTopEvent(self)
    registerTeamBottomEvent(self)
end

function KUILaunchTeamNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onSupplyTeamFinish()
        refreshTeamDetail(self)
        refreshTeamAttribte(self)
        refreshCharacterImage(self)
        showNoticeByID("supply.teamSuccess")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_TEAM_FINISH, onSupplyTeamFinish) 

    local function onSupplyCardFinish(cardID)
        refreshTeamDetail(self)
        refreshTeamAttribte(self)
        refreshCharacterImage(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SUPPLY_CARD_FINISH, onSupplyCardFinish) 
    
    local function onCardRepairing(cardID)
        refreshTeamDetail(self)
        refreshTeamAttribte(self)
        refreshCharacterImage(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BEGAN_REPAIR_CARD, onCardRepairing) 
    
    local function onCardRepairFinish(cardID)
        refreshTeamDetail(self)
        refreshTeamAttribte(self)
        refreshCharacterImage(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CARD, onCardRepairing)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG, onCardRepairing)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG_ALLCARD, onCardRepairing)
end

return KUILaunchTeamNode
