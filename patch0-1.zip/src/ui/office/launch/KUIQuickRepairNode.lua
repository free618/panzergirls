--  *********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIQuickRepairNode.lua
--  Creator     : Jiang xufeng
--  Date        : 2016/03/20 10:00  
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************

local HIGHSPEED_ITEM                = 5

local KUIQuickRepairNode = class (
    "KUIQuickRepairNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIQuickRepairNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._animationList     = {}
end

function KUIQuickRepairNode.create(owner, teamIndex)
    local currentNode           = KUIQuickRepairNode.new()
    
    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_quick_repair.csb"

    currentNode._cardList       = KUtil.getOneTeamCardList(teamIndex)
    currentNode._teamIndex      = teamIndex
    
    currentNode:init()

    return currentNode
end

local function highSpeedItemCount()
    local highList              = KPlayer.tItemData.tStoreHouse.tItemList
    local item                  = HArray.FindFirst(highList, "nTemplateID", HIGHSPEED_ITEM)
    if item then
        return item.nCount
    end

    return 0
end

function KUIQuickRepairNode:refreshBaseInfo()
    local mainNode              = self._mainLayout
    local projectNode           = mainNode:getChildByName("ProjectNode_recharge")
    local panel                 = projectNode:getChildByName("Image_recharge")

    local imageCommonBase       = panel:getChildByName("Image_supply_value_base")
    local textHighSpeedCount    = imageCommonBase:getChildByName("Text_worker_number")
    
    textHighSpeedCount:setString(highSpeedItemCount())
end

function KUIQuickRepairNode:refreshUI()
    self:refreshBaseInfo()
    self:refreshRepairCards()
end

function KUIQuickRepairNode:needRepair(card)
    local maxHP     = KUtil.getCardMaxHp(card)
    local hurtHP    = maxHP  - card.nCurrentHP
    
    if hurtHP <= 0 then 
        return false
    end
     
    return true
end

function KUIQuickRepairNode:isEnoughCost(cards, showNotice)
    local costPeople   = 0
    local costSteel    = 0
    local itemNum      = KUtil.getItemCount(HIGHSPEED_ITEM)
    local itemInfo     = KConfig["itemInfo"][HIGHSPEED_ITEM]
    local needNum      = 0

    for k,card in pairs(cards) do
        local maxHP    = KUtil.getCardMaxHp(card)
        local hurtHP   = maxHP  - card.nCurrentHP
        if hurtHP > 0 then
            if not self:isInRepair(card) then
                local carryOil     = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
                costPeople   = costPeople + math.ceil(carryOil * 0.2 * 0.35 * hurtHP)
                costSteel    = costSteel + math.ceil(carryOil * 0.2 * 0.25 * hurtHP)
                
                if (KPlayer.people < costPeople or KPlayer.steel < costSteel) then
                    if showNotice then showNoticeByID("repaircard.cost") end
                    return false, costSteel, costPeople
                end
            end

            needNum = needNum + 1
            if itemNum < needNum then
                if showNotice then showNoticeByID("common.lessResource", itemInfo.szName) end
                return false, costSteel, costPeople
            end
        end
    end

    return needNum > 0, costSteel, costPeople
end

function KUIQuickRepairNode:isInRepair(card)
    local repairList = KPlayer.tCardData.tRepairingList
    local oneRepairCard = HArray.FindFirst(repairList, "nCardID", card.nID)
    if oneRepairCard then return true end
    return false
end

function KUIQuickRepairNode:refreshRepairCards()
    local mainNode              = self._mainLayout
    local projectNode           = mainNode:getChildByName("ProjectNode_recharge")
    local panel                 = projectNode:getChildByName("Image_recharge")
    local isHaveRepair          = false
    for nodeUnitID = 1, MAX_TEAM_CARD_COUNT do
        local nodeName          = "Panel_echarg_unit_" .. nodeUnitID
        local nodeUnit          = panel:getChildByName(nodeName)
        local buttonBase        = nodeUnit:getChildByName("Button_bj_unit_base")
    
        local card              = self._cardList[nodeUnitID]
        if card then
            buttonBase:setVisible(true)
            local buttonExpand  = buttonBase:getChildByName("Button_repair")
            local needRepair    = self:needRepair(card)
            if needRepair then isHaveRepair = true end
            KUtil.setTouchEnabled(buttonExpand, needRepair)

            local nodeCardBase  = buttonBase:getChildByName("ProjectNode_cardbase")
            local panelBase     = nodeCardBase:getChildByName("Panel_base")
            KUtil.updateCardBase(panelBase, card)

            local textSteel     = buttonBase:getChildByName("Text_steel")
            local textSpAmmo    = buttonBase:getChildByName("Text_sp_ammo")
            local _, costSteel, costPeople = self:isEnoughCost({card}, false)
            textSteel:setString(costSteel)
            textSpAmmo:setString(costPeople)
        else
            buttonBase:setVisible(false)
        end
    end

    local buttonAllRepair          = panel:getChildByName("Button_all_repair_button")
    KUtil.setTouchEnabled(buttonAllRepair, isHaveRepair)
end

function KUIQuickRepairNode:registerAllTouchEvent()
    local mainNode              = self._mainLayout
    
    local projectNode           = mainNode:getChildByName("ProjectNode_recharge")
    local panel                 = projectNode:getChildByName("Image_recharge")
    local buttonCancel          = panel:getChildByName("Button_all_cancel_button")
    local function onCancelClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            KSound.playEffect("close")
            self:playCloseAnimation(false)
        end
    end
    buttonCancel:addTouchEventListener(onCancelClick)

    local buttonClose           = panel:getChildByName("Button_close_button")
    buttonClose:addTouchEventListener(onCancelClick)

    local buttonAllRepair       = panel:getChildByName("Button_all_repair_button")
    local function onRepairAllClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onRepairAllClick")
            KSound.playEffect("click")
            if not self:isEnoughCost(self._cardList, true) then return end
            require("src/network/KC2SProtocolManager"):quickRepairAllCard(self._teamIndex)
        end
    end
    buttonAllRepair:addTouchEventListener(onRepairAllClick)
    
    for nodeUnitID = 1, MAX_TEAM_CARD_COUNT do
        local nodeName          = "Panel_echarg_unit_" .. nodeUnitID
        local nodeUnit          = panel:getChildByName(nodeName)
        local buttonBase        = nodeUnit:getChildByName("Button_bj_unit_base")
    
        local card              = self._cardList[nodeUnitID]
        local buttonRepair      = buttonBase:getChildByName("Button_repair")
        local function onRepairClick(sender, type)
            if type == ccui.TouchEventType.ended then
                if not card then
                    return
                end

                KSound.playEffect("quickRepair")
                cclog("click onQuickRepairClick~ nodeUnitID:%s", nodeName)

                if not self:needRepair(card) then return end
                if not self:isEnoughCost({card}, true) then return end

                if self:isInRepair(card) then
                    require("src/network/KC2SProtocolManager"):FinishRepairCardingByCostItem(card.nID)
                else
                    require("src/network/KC2SProtocolManager"):quickRepairCard(card.nID)
                end
            end
        end
        buttonRepair:addTouchEventListener(onRepairClick)
    end
end

function KUIQuickRepairNode:registerAllCustomEvent()
    local eventDispatchCenter   = require("src/logic/KEventDispatchCenter")
    local function finishRepairCard()
        self:refreshBaseInfo()
        self:refreshRepairCards()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_DEL_REPAIR_CARD, finishRepairCard)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CAR_COSTITEM, finishRepairCard)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CARD, finishRepairCard)

    local function finishQuickRepairCard()
        self:refreshBaseInfo()
        self:refreshRepairCards()
        showNoticeByID("repaircard.finish")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG, finishQuickRepairCard)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_QUICKREPAIRNG_ALLCARD, finishQuickRepairCard)
end

function KUIQuickRepairNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIQuickRepairNode:playCloseAnimation(isReturnOffice)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local delayTime1 = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        delayTime = math.max(delayTime, delayTime1)
    end
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "QuickRepair", callBacks, isReturnOffice)
end

function KUIQuickRepairNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout

    local list              = self._animationList
    local projectNode       = mainNode:getChildByName("ProjectNode_recharge")
    list.recharge           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_quick_repair.csb"), {0, 30, 40, 65}}
end

function KUIQuickRepairNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUIQuickRepairNode:onInitUI()
    self:onInitAnimation()
end

return KUIQuickRepairNode
