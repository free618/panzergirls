--  Copyright(c) KingSoft
--  FileName    : KUISelectionDifficultyNode.lua
--  Creator     : Jiang Xufeng 
--  Date        : 2015/12/09   16:58
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local checkBoxArray = {
    checkBoxlow,
    checkBoxMedian,
    checkBoxHigh,
}

local KUISelectionDifficultyNode  = class(
    "KUISelectionDifficultyNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISelectionDifficultyNode:ctor()
    self._mainLayout         = nil
    self._parent             = nil
    self._uiPath             = nil
    self._lastUpdateTime     = 0
end

function KUISelectionDifficultyNode.create(owner, zoneID, mapID, onConfirmCallback)
    local currentNode = KUISelectionDifficultyNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_difficulty_selection_v5.csb"
    currentNode._zoneID = zoneID
    currentNode._mapID  = mapID
    currentNode._onConfirmCallback = onConfirmCallback
    currentNode:init()

    return currentNode
end

function KUISelectionDifficultyNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    local imagedifficultyBase = mainNode:getChildByName("Image_difficulty_base")
    local buttonClose = imagedifficultyBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onCloseClick~")
        KSound.playEffect("close")
        self._parent:removeNode("SelectionDifficulty")
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonConfirm = imagedifficultyBase:getChildByName("Button_confirm")
    local function onConfirmClick(sender,type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onConfirmClick~") 
        KSound.playEffect("close")
        local checkBox1 = imagedifficultyBase:getChildByName("CheckBox_1")
        local checkBox2 = imagedifficultyBase:getChildByName("CheckBox_2")
        local checkBox3 = imagedifficultyBase:getChildByName("CheckBox_3")
        local curSelected = nil
        if checkBox1:isSelected() then
            curSelected = DIFFCULT_LEVEL.LEVEL_EASY
        elseif checkBox2:isSelected() then
            curSelected = DIFFCULT_LEVEL.LEVEL_MID
        elseif checkBox3:isSelected() then
            curSelected = DIFFCULT_LEVEL.LEVEL_HARD
        else
            assert(false)
        end
        assert(curSelected)

        local tOneMapSpecialData = KPlayer:GetBattleMapSpecialData(self._zoneID, self._mapID)
        assert(tOneMapSpecialData)


        local function changeDiffculty()
            require("src/network/KC2SProtocolManager"):selectMapDifficult(self._zoneID, self._mapID, curSelected)
        end

        if tOneMapSpecialData.nDiffcult == 0 then
            changeDiffculty()
            return
        end

        if tOneMapSpecialData.nDiffcult == curSelected then
            self._parent:removeNode("SelectionDifficulty")
            if self._onConfirmCallback then
                self._onConfirmCallback()
            end
            return
        end

        local confirmationInfo = KUtil.getStringByKey("battle.changeDifficulty")
        showConfirmation(confirmationInfo, changeDiffculty)
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)

    local checkBoxlow       = imagedifficultyBase:getChildByName("CheckBox_1")
    local checkBoxMedian    = imagedifficultyBase:getChildByName("CheckBox_2")
    local checkBoxHigh      = imagedifficultyBase:getChildByName("CheckBox_3")

    local checkBoxArray = {
        checkBoxlow,
        checkBoxMedian,
        checkBoxHigh,
    }
    
    KUtil.setSelectionDifficultyEvent(checkBoxArray)
end

local function refreshCheckBox(self)
    local mainNode = self._mainLayout
    local imagedifficultyBase = mainNode:getChildByName("Image_difficulty_base")
    local tOneMapSpecialData = KPlayer:GetBattleMapSpecialData(self._zoneID, self._mapID)

    local nSelectedDifficult = tOneMapSpecialData.nDiffcult

    if nSelectedDifficult == 0 then
        nSelectedDifficult = 1
    end

    for checkBoxID = 1, 3 do 
        local checkBoxName = "CheckBox_" .. checkBoxID
        local checkBox = imagedifficultyBase:getChildByName(checkBoxName)
        checkBox:setSelected(nSelectedDifficult == checkBoxID)
    end
end

function KUISelectionDifficultyNode:refreshUI()
    refreshCheckBox(self)
end

function KUISelectionDifficultyNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onChangeDifficulty(zoneID, mapID, nDiffcult, nProgress)
        self._parent:removeNode("SelectionDifficulty")
        if self._onConfirmCallback then
            self._onConfirmCallback()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_CHANGE_DIFFICULTY, onChangeDifficulty)
end

function KUISelectionDifficultyNode:onEnter()

end

function KUISelectionDifficultyNode:onExit()

end

return KUISelectionDifficultyNode