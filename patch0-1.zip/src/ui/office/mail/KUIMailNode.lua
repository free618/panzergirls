--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMailNode.lua
--  Creator     : huangyixin
--  Date        : 2015/11/24   12:00
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_REWARD_ICON_UI_COUNT = 5

local KUIMailNode = class(
    "KUIMailNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local m_szEmptyIconPath = "res/ui/ui_material/public/bg_item_base.png"

function KUIMailNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil

    self._mailID            = nil
    self._mailData          = nil
    self._mailStateChanged  = false
end

function KUIMailNode.create(owner, nodeData)
    local currentNode   = KUIMailNode.new()

    local mailData      = KUtil.getOneMailByID(nodeData.oneMailID)
    assert(mailData)

    currentNode._mailID   = nodeData.oneMailID
    currentNode._mailData = mailData
    
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/mailbox.csb"
    currentNode:init()

    return currentNode
end

local function setButtonReceiveState(self, isEnabled)    
    local mainNode       = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMailBase  = projectNode:getChildByName("Image_mail")
    local buttonReceive  = imageMailBase:getChildByName("Button_receive")
    KUtil.setTouchEnabled(buttonReceive, isEnabled)
end

local function clearRewardArea(self)
    local mainNode       = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMailBase  = projectNode:getChildByName("Image_mail")
    local panelIconBase1 = imageMailBase:getChildByName("Panel_icon_base_1")
    panelIconBase1:setVisible(false)
    local panelIconBase2 = imageMailBase:getChildByName("Panel_icon_base_2")
    panelIconBase2:setVisible(false)
    
    local buttonReceive = imageMailBase:getChildByName("Button_receive")
    buttonReceive:setVisible(false)

    local mainNode   = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMail  = projectNode:getChildByName("Image_mail")
    local scrollView = imageMail:getChildByName("ScrollView_icon")
    scrollView:setVisible(false)
end

local function initUIState(self)
    local mailData      = self._mailData
    self._oldOpenState  = mailData.bOpen
    self._oldAwardState = mailData.bAward

    setButtonReceiveState(self, not mailData.bAward)
end

local function refreshSingleRewardIcon(self, iconUI, rewardItem, isEmpty)
    local panelclipping     = iconUI:getChildByName("Panel_icon")
    local imageIcon         = panelclipping:getChildByName("Image_icon")
    local imageDigitalBase  = iconUI:getChildByName("Image_digital_base")
    local textDigital       = imageDigitalBase:getChildByName("Text_digital")
    local filePath, scaleRatio = m_szEmptyIconPath, 1.0
    
    if isEmpty == false then
        KUtil.setItemClippingEnabled(panelclipping, rewardItem.nType)
        filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(rewardItem.nType, rewardItem.nID)
        imageIcon:loadTexture(filePath)
        imageIcon:setScale(scaleRatio * 1.2)
        panelclipping:setClippingEnabled(clipping)
        textDigital:setString(rewardItem.nNum)
    end 

    local iconVisible = isEmpty == false
    panelclipping:setVisible(iconVisible)
    imageDigitalBase:setVisible(iconVisible)
end

local function refreshRewardPanel(self, rewardItemList, visible)
    local mainNode        = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMailBase   = projectNode:getChildByName("Image_mail")
    local panelIconBase1  = imageMailBase:getChildByName("Panel_icon_base_1")
    local panelIconBase2  = imageMailBase:getChildByName("Panel_icon_base_2")
    if not visible then
        panelIconBase1:setVisible(false)
        panelIconBase2:setVisible(false)
        return
    end

    local rewardItemCount = #rewardItemList
    panelIconBase1:setVisible(rewardItemCount % 2 == 1)
    panelIconBase2:setVisible(rewardItemCount % 2 == 0)

    local panelIconBase   = panelIconBase1
    local iconUICount     = MAX_REWARD_ICON_UI_COUNT
    if rewardItemCount % 2 == 0 then
        panelIconBase = panelIconBase2
        iconUICount   = iconUICount - 1
    end

    local bAward     = self._mailData.bAward
    local uiIndex    = 0
    local startIndex = (iconUICount - rewardItemCount) / 2 + 1
    local endIndex   = startIndex + rewardItemCount - 1
    self._rewardList = rewardItemList
    while true do
        uiIndex = uiIndex + 1
        local panelIcon = panelIconBase:getChildByName("Panel_" .. uiIndex)
        if panelIcon == nil then return end

        local visible = uiIndex >= startIndex and uiIndex <= endIndex
        panelIcon:setVisible(visible)
        if visible then
            local rewardItem = rewardItemList[uiIndex - startIndex + 1]
            refreshSingleRewardIcon(self, panelIcon, rewardItem, bAward)
        end
    end
end

local function refreshRewardList(self, rewardItemList, visible)
    local mainNode   = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMail  = projectNode:getChildByName("Image_mail")
    local scrollView = imageMail:getChildByName("ScrollView_icon")
    if not visible or #rewardItemList == 0 then
        scrollView:setVisible(false)
        return
    end

    local rewardCount   = #rewardItemList
    local isAward       = self._mailData.bAward
    local iconUIBase    = self._iconUIBase
    if not iconUIBase then
        iconUIBase = scrollView:getChildByName("Panel_1")
        assert(iconUIBase)
        self._iconUIBase = iconUIBase
        iconUIBase:retain()
    end

    local imageIconBase = iconUIBase:getChildByName("Image_icon_base") 
    local showCount   = 5
    local scaleX      = imageIconBase:getScaleX()
    local scaleY      = imageIconBase:getScaleY()
    local viewWidth   = scrollView:getContentSize().width
    local iconWidth   = imageIconBase:getContentSize().width * scaleX
    local paddingLeft = imageIconBase:getPositionX() - iconWidth / 2 
    local span        = (viewWidth - iconWidth * showCount - paddingLeft) / showCount
    local unitWidth   = iconWidth + span
    local unitHeight  = imageIconBase:getContentSize().height * scaleY
    local unitPosY    = iconUIBase:getPositionY()
    local unitCount   = rewardCount
    local offLeft     = iconUIBase:getAnchorPointInPoints().x * scaleX

    scrollView:removeAllChildren()

    local scrollWidth  = paddingLeft + unitCount * unitWidth
    local scrollHeight = unitHeight
    scrollWidth = math.max(scrollWidth, viewWidth)
    scrollView:setInnerContainerSize(cc.size(scrollWidth, scrollHeight))

    for index, rewardItem in ipairs(rewardItemList) do
        local newIconUI = iconUIBase:clone()
        local unitPosX  = paddingLeft + (index - 1) * unitWidth + offLeft
        local position  = cc.p(unitPosX ,unitPosY)
        scrollView:addChild(newIconUI)
        newIconUI:setPosition(position)
        newIconUI:setVisible(true)
        refreshSingleRewardIcon(self, newIconUI, rewardItem, isAward)
    end

    scrollView:setBounceEnabled(false)
    local bShowAction = not isAward
    if bShowAction then
        local unitPerTime   = 0.8
        local duration      = (unitCount - showCount) * unitPerTime
        local scrollPercent = 100
        scrollView:scrollToPercentHorizontal(scrollPercent, duration, false)
    end
end

local function refreshRewardArea(self, nRewardID, tRewardList)
    local mailData = self._mailData
    if tRewardList == nil and nRewardID == nil then
        tRewardList = mailData.tMailData.tRewardList
        nRewardID   = mailData.tMailData.nRewardID
    end

    local rewardItemList = tRewardList
    if nRewardID ~= 0 and (rewardItemList == nil or #rewardItemList == 0) then
        rewardItemList = KUtil.getRewardRandResult(nRewardID)
    end
    
    if rewardItemList == nil or #rewardItemList == 0 then 
        clearRewardArea(self)
        return 
    end

    local rewardItemCount = #rewardItemList
    local bUseList = rewardItemCount > MAX_REWARD_ICON_UI_COUNT
    refreshRewardPanel(self, rewardItemList, not bUseList)
    refreshRewardList(self, rewardItemList, bUseList)
end

local function refreshTextArea(self)
    if self._mailData == nil then return end
    local mainNode       = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMailBase  = projectNode:getChildByName("Image_mail")
    local scrollView     = imageMailBase:getChildByName("ScrollView_1")
    local textContent    = scrollView:getChildByName("Text_1")
    local mailData       = self._mailData
    assert(mailData.tMailData ~= nil, mailData.nID)
    local message        = mailData.tMailData.szSenderName .. "  :\n"
    textContent:setString(message .. mailData.tMailData.szContent)
end

local function goBackToMailListUI(self)
    local mailData      = self._mailData
    local mailListView  = self._parent:getNode("MailList")
    self._parent:removeNode("Mail")
    if not mailData then return end
    if not mailListView then return end

    local stateChangedOpen  = self._oldOpenState ~= mailData.bOpen
    local stateChangedAward = self._oldAwardState ~= mailData.bAward
    if stateChangedOpen or stateChangedAward then
        mailListView:updateMailState(mailData.nID)
    end
end

local function getFrameAction(self, startFrame, endedFrame)
    local duration   = (endedFrame - startFrame) / 60

    local function callAnimation()
        local mainNode = self._mainLayout
        local projectNode = mainNode:getChildByName("ProjectNode_mail")
        local actionName = "ani_mailbox"
        KUtil.playAnimation(projectNode,  actionName, startFrame, endedFrame)
    end
    
    local callAction  = cc.CallFunc:create(callAnimation)
    local frameDelay  = cc.DelayTime:create(duration)
    local frameAction = cc.Sequence:create(callAction, frameDelay)

    return frameAction, duration
end

function KUIMailNode:onInitUI()
    local mainNode = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_mail")
    projectNode:stopAllActions()
end

function KUIMailNode:getEnterAction()
    local startFrame = 0
    local endedFrame = 27
    local enterAction, duration = getFrameAction(self, startFrame, endedFrame)
    return enterAction, duration
end

function KUIMailNode:getExitAction()
    local startFrame = 50
    local endedFrame = 65
    local exitAction, duration = getFrameAction(self, startFrame, endedFrame)
    return exitAction, duration
end

function KUIMailNode:refreshUI()
    assert(self._mailData)
    initUIState(self)
    refreshTextArea(self)
    refreshRewardArea(self)
end

function KUIMailNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local projectNode    = mainNode:getChildByName("ProjectNode_mail")
    local imageMailBase = projectNode:getChildByName("Image_mail")
    local buttonClose   = imageMailBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onCloseButton~")   
        KSound.playEffect("close")
        goBackToMailListUI(self)
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonReceive = imageMailBase:getChildByName("Button_receive")
    local function onReceiveClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("click onRecievieButton")
        KSound.playEffect("getReward")
        if self._mailData.bAward then return end
        local tItemList = KUtil.getMailRewardList(self, self._mailData)
        if tItemList == nil then return end
        local tip = KUtil.CanSuperAddItems(tItemList)
        if tip then
            showNoticeByID(tip)
        else
            cclog("get mail reward mail.id:%d", self._mailData.nID)
            require("src/network/KC2SProtocolManager"):requestGetMailReward(self._mailData.nID)
            setButtonReceiveState(self, false)
        end
    end
    buttonReceive:addTouchEventListener(onReceiveClick)
end

function KUIMailNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    
    local function onGetMailReward(nID, nRewardID, tRewardList)
        cclog("onEvent ---------->onGetMailReward,mail.id:%d", nID)
        refreshRewardArea(self, nRewardID, tRewardList)
        
        local thisMail  = KUtil.getOneMailByID(self._mailID)
        local isEnabled = thisMail and (not thisMail.bAward)
        setButtonReceiveState(self, isEnabled)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MAIL_REWARD, onGetMailReward)
end

function KUIMailNode:onCleanup()
    if self._iconUIBase then
        self._iconUIBase:release()
    end
end

return KUIMailNode
