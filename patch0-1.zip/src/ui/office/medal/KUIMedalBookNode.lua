--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalBookNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local MAX_ITEM_NUM          = 10
local ONE_PAGE_NUM          = 5
local MAX_PAGE_LABEL_NUM    = 4
local MAX_GRADE_NUM         = 4
local MAX_REQUIRE_NUM       = 4

local m_tPageTexturePath = {
    ["normalTexture"]  = "res/ui/ui_material/public/common_label1_button.png",
    ["pressTexture"]   = "res/ui/ui_material/public/common_label1_button_active.png",
    ["disableTexture"] = "res/ui/ui_material/public/common_label1_button.png"
}

local m_tUnitTexturePath = {
    ["normalTexture"]  = "res/ui/ui_material/medal_wall/medal_book_button.png",
    ["pressTexture"]   = "res/ui/ui_material/medal_wall/medal_book_button_active.png",
    ["disableTexture"] = "res/ui/ui_material/medal_wall/medal_book_button_disable.png"
}

local KUIMedalBookNode = class(
    "KUIMedalBookNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalBookNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
    self._nPage          = 1
    self._pageIndex      = {}
    self._pageMap        = {}
    self._isInitLeft     = false
end

function KUIMedalBookNode.create(owner, nodeName, projectNode)
    local currentNode = KUIMedalBookNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/animation_node/ani_record_medal_book.csb"
    currentNode:init()

    currentNode:setName(nodeName)
    projectNode:addChild(currentNode)

    return currentNode
end

local function initUI(self)
    local mainNode        = self._mainLayout
    local imagePage       = mainNode:getChildByName("Image_medal_book_base")
    local scrollView      = imagePage:getChildByName("ScrollView_1")
    local imageUnit       = scrollView:getChildByName("Button_unit")

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)

    self._imageUnit      = imageUnit
    self._imageUnit:removeFromParent(false)
    node:addChild(self._imageUnit)
end

function KUIMedalBookNode:upMedal(unit, oneMedalConfig, oneMedal)
    local imageIcon            = unit:getChildByName("Image_icon")
    local textName             = unit:getChildByName("Text_name")
    local textDescription      = unit:getChildByName("Text_description")
    local panelMedalIcon       = unit:getChildByName("Panel_medal_icon")

    if oneMedal and oneMedal.nNum > 0 then
        unit.bGeted = true
        unit:loadTextureNormal(m_tUnitTexturePath.normalTexture)
    else
        unit.bGeted = false
        unit:loadTextureNormal(m_tUnitTexturePath.disableTexture)
    end

    if self._selected == oneMedalConfig.nID then
        unit:loadTextureNormal(m_tUnitTexturePath.pressTexture)
    end

    for i=1,MAX_GRADE_NUM do
        local ImageIconBase    = panelMedalIcon:getChildByName("Image_icon_base_"..i)
        if oneMedalConfig.nGrade == i then
            ImageIconBase:setVisible(true)
        else
            ImageIconBase:setVisible(false)
        end
    end
    
    imageIcon:loadTexture(KUtil.getMedalImagePath(oneMedalConfig))
    textName:setString(oneMedalConfig.szName)
    textDescription:setString(oneMedalConfig.szConditionDescribe)

    local function onUnitClick(sender, type)
        local selectUnit = self._pageData.scrollView:getChildByName(tostring(self._selected))
        if selectUnit then
            if selectUnit.bGeted then
                selectUnit:loadTextureNormal(m_tUnitTexturePath.normalTexture)
            else
                selectUnit:loadTextureNormal(m_tUnitTexturePath.disableTexture)
            end
        end
        self._selected = oneMedalConfig.nID
        self:refreshLeftInfo(oneMedalConfig, oneMedal)
        unit:loadTextureNormal(m_tUnitTexturePath.pressTexture)
    end
    unit:addTouchEventListener(onUnitClick)

    if not self._isInitLeft then
        self:refreshLeftInfo(oneMedalConfig, oneMedal)
        self._isInitLeft = true
    end
end

local function updateScrollRank(self, unit, data)
    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList
    local oneMedal   = HArray.FindFirst(tMedalList, "nID", data.nID)
    self:upMedal(unit, data, oneMedal)
end

local function addScrollPageView(self, isCutIn)
    if not self._medalList then
        return
    end

    local mainNode        = self._mainLayout
    local imageRankBase   = mainNode:getChildByName("Image_medal_book_base")
    local scrollView      = imageRankBase:getChildByName("ScrollView_1")
    local slider          = imageRankBase:getChildByName("Slider_1")

    local refreshCall = function(control, dataInfo)
        updateScrollRank(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = slider,
        itemBase    = self._imageUnit,
        dataList    = self._medalList,
        refreshCall = refreshCall,
        column      = 1,
        row         = 7,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

function KUIMedalBookNode:getMedalList(tMedalList)
    local list = {}
    for _, oneMedalConfig in pairs(KConfig.medalinfo) do
        if self._nPage == oneMedalConfig.nType then
            if oneMedalConfig.nHide ~= 0 then
                local oneMedal = HArray.FindFirst(tMedalList, "nID", oneMedalConfig.nID)
                if oneMedal and oneMedal.nNum > 0 then
                    table.insert(list, oneMedalConfig)
                end
            else
                table.insert(list, oneMedalConfig)
            end
        end
    end

    local function sortByOrder(a, b)
        return a.nOrder < b.nOrder
    end

    return list
end

function KUIMedalBookNode:refreshLeftInfo(oneMedalConfig, oneMedal)
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_medal_book_base")
    local panelMedalInfo    = imageBase:getChildByName("Panel_medal_info")

    local imageIcon         = panelMedalInfo:getChildByName("Image_icon")
    local textName          = panelMedalInfo:getChildByName("Text_name")
    local textDescrition    = panelMedalInfo:getChildByName("Text_descrition")

    local panelDescrition1  = panelMedalInfo:getChildByName("Panel_descrition_1")
    local panelDescrition2  = panelMedalInfo:getChildByName("Panel_descrition_2")
    local panelDescrition3  = panelMedalInfo:getChildByName("Panel_descrition_3")
    local imageScoreBase    = panelMedalInfo:getChildByName("Image_score_base")
    local textScore         = imageScoreBase:getChildByName("Text_score")

    imageIcon:loadTexture(KUtil.getMedalImagePath(oneMedalConfig))
    textName:setString(oneMedalConfig.szName)
    textScore:setString(oneMedalConfig.nAddMedalValue)

    -- cocos2dx has a bug,donot clone ,the show will error
    local testDescritionNew = textDescrition:clone()
    testDescritionNew:setString(oneMedalConfig.szConditionDescribe)
    testDescritionNew:setPosition(textDescrition:getPosition())
    testDescritionNew:setName("Text_descrition")
    panelMedalInfo:addChild(testDescritionNew)
    textDescrition:removeFromParent()

    if oneMedal and oneMedal.nNum > 0 and oneMedalConfig.nRepeat == 0 then
        panelDescrition1:setVisible(false)
        panelDescrition2:setVisible(false)
        panelDescrition3:setVisible(true)
        local textTime            = panelDescrition3:getChildByName("Text_time")
        local textDescription2    = panelDescrition3:getChildByName("Text_descrition_2")
        textDescription2:setString(oneMedalConfig.szDescribe)
        textTime:setString(os.date("%Y/%m/%d", oneMedal.nTime))
    else
        panelDescrition3:setVisible(false)
        local tConditionList = oneMedalConfig.anCondition
        local tMedalRequire  = HArray.FindFirst(KConfig.medalRequire, "nID", tConditionList[1])
        if tMedalRequire.nType == 1 then
            panelDescrition1:setVisible(true)
            panelDescrition2:setVisible(false)
            local textCondition       = panelDescrition1:getChildByName("Text_condition")
            local loadingBar          = panelDescrition1:getChildByName("LoadingBar_1")
            local textProgress        = panelDescrition1:getChildByName("Text_progress")

            for i, nID in ipairs(tConditionList) do
                local tMedalRequire = HArray.FindFirst(KConfig.medalRequire, "nID", nID)
                assert(tMedalRequire, nID)
                textCondition:setString(tMedalRequire.szDescribe)

                local nProgress = 0
                local tMedalProgress = HArray.FindFirst(oneMedal.tProgressList, "nID", nID)
                if tMedalProgress then
                    nProgress = tMedalProgress.nValue
                end
                loadingBar:setPercent(nProgress / tMedalRequire.nCount * 100)
                textProgress:setString(nProgress .."/".. tMedalRequire.nCount)
            end
        elseif tMedalRequire.nType == 2 then
            panelDescrition1:setVisible(false)
            panelDescrition2:setVisible(true)

            for i = 1, MAX_REQUIRE_NUM do
                local text          = panelDescrition2:getChildByName("Text_map_".. i)
                local image         = panelDescrition2:getChildByName("Image_".. i)

                local nID = tConditionList[i]
                if nID then
                    text:setVisible(true)

                    local tMedalRequire = HArray.FindFirst(KConfig.medalRequire, "nID", nID)
                    assert(tMedalRequire, nID)
                    text:setString(tMedalRequire.szDescribe)

                    local tMedalProgress = HArray.FindFirst(oneMedal.tProgressList, "nID", nID)
                    if tMedalProgress then
                        if tMedalProgress.nValue >= tMedalRequire.nCount then
                            image:setVisible(true)
                        else
                            image:setVisible(false)
                        end
                    end
                else
                    text:setVisible(false)
                    image:setVisible(false)
                end
            end
        elseif tMedalRequire.nType == 3 then
            panelDescrition1:setVisible(true)
            panelDescrition2:setVisible(false)
            local textCondition       = panelDescrition1:getChildByName("Text_condition")
            local loadingBar          = panelDescrition1:getChildByName("LoadingBar_1")
            local textProgress        = panelDescrition1:getChildByName("Text_progress")
            textCondition:setString(oneMedalConfig.szConditionDescribe)

            local nCount = 0
            local nMaxCount = 0
            for i, nID in ipairs(tConditionList) do
                local tMedalRequire = HArray.FindFirst(KConfig.medalRequire, "nID", nID)
                assert(tMedalRequire, nID)

                local nProgress = 0
                local tMedalProgress = HArray.FindFirst(oneMedal.tProgressList, "nID", nID)
                if tMedalProgress then
                    nProgress = tMedalProgress.nValue
                end

                nCount      = nCount + nProgress
                nMaxCount   = nMaxCount + tMedalRequire.nCount
            end

            loadingBar:setPercent(nCount / nMaxCount * 100)
            textProgress:setString(nCount .."/".. nMaxCount)
        end
    end
end

local function getMedalConfig(nID)
    local oneMedalConfig = HArray.FindFirst(KConfig.medalinfo, "nID", nID)
    return oneMedalConfig
end

function KUIMedalBookNode:refreshTop()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_medal_book_base")
    local panelData         = imageBase:getChildByName("Panel_data")

    local tMedalData        = KPlayer.tMedalData
    local tMedalList        = tMedalData.tMedalList
    local numList           = {0, 0, 0}

    for k, oneMedal in pairs(tMedalList) do
        if oneMedal.nNum > 0 then
            local oneMedalConfig = getMedalConfig(oneMedal.nID)
            numList[oneMedalConfig.nGrade] = numList[oneMedalConfig.nGrade] + oneMedal.nNum
        end
    end

    local panel             = panelData:getChildByName("Panel_1")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(numList[3])
    
    local panel             = panelData:getChildByName("Panel_2")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(numList[2])
    
    local panel             = panelData:getChildByName("Panel_3")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(numList[1])
    
    local panel             = panelData:getChildByName("Panel_4")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(tMedalData.nValue)
end

function KUIMedalBookNode:onEnterActionFinished()
end

function KUIMedalBookNode:onInitUI()
    self:onInitAnimation()
end

function KUIMedalBookNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local list              = self._animationList
    list.top                = {KUtil.initAnimation(mainNode, "res/ui/animation_node/ani_record_medal_book.csb"), {0, 30, 50, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_page")
    self._animationPage     = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_medal_page.csb"), {0, 23}}
end

function KUIMedalBookNode:refreshData()
    self:refreshTop()
end

function KUIMedalBookNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIMedalBookNode:closeAnimation(fun)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local time
        if name == "top" then
            time = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4], fun)
        else
            time = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        end

        if time > delayTime then
            delayTime = time
        end
    end

    return delayTime
end

local function enterAnimation(self)
    self._mainLayout:setVisible(true)
    self:playStartAnimation()
end

local function exitAnimation(self)
    return self:closeAnimation(function()
        self._mainLayout:setVisible(false)
    end)
end

function KUIMedalBookNode:enter()
    enterAnimation(self)
end

function KUIMedalBookNode:quit()
    return exitAnimation(self)
end

function KUIMedalBookNode:UpDateList()
    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList
    self._medalList  = self:getMedalList(tMedalList)
    addScrollPageView(self, false)
end

function KUIMedalBookNode:initData()
    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList
    local pageMap = {}
    for _, oneMedalConfig in pairs(KConfig.medalinfo) do
        local nType = oneMedalConfig.nType
        if oneMedalConfig.nHide ~= 0 then
            local oneMedal = HArray.FindFirst(tMedalList, "nID", oneMedalConfig.nID)
            if oneMedal and oneMedal.nNum > 0 then
                pageMap[nType] = true
            end
        else
            pageMap[nType] = true
        end
    end
    self._pageMap = pageMap

    local initPage
    for k,v in pairs(pageMap) do
        if not initPage then initPage = k end
        initPage = math.min(initPage, k)
    end
    self._nPage = math.max(initPage or 0, self._nPage)
end

function KUIMedalBookNode:refreshUI()
    initUI(self)
    self:initData()
    self:UpDateList()
    self:refreshData()
end

function KUIMedalBookNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("Image_medal_book_base")
    local imagePagebBase    = imageBase:getChildByName("Panel_type")
    local scrollView        = imageBase:getChildByName("ScrollView_1")
    local slider            = imageBase:getChildByName("Slider_1")
    for i = 1, MAX_PAGE_LABEL_NUM do
        local buttonType    = imagePagebBase:getChildByName("Button_type_"..i)
        local function onPageClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onPageClick~")
                KSound.playEffect("click")
                if self._nPage == i then
                    return
                end

                local buttonType    = imagePagebBase:getChildByName("Button_type_"..self._nPage)
                buttonType:loadTextureNormal(m_tPageTexturePath.normalTexture)
                sender:loadTextureNormal(m_tPageTexturePath.pressTexture)

                self._nPage = i
                self._isInitLeft = false
                self:UpDateList()

                KUtil.playAnimationByAnimation(self._animationPage[1], self._animationPage[2][1], self._animationPage[2][2])
            end
        end

        if self._nPage == i then
            buttonType:loadTextureNormal(m_tPageTexturePath.pressTexture)
        end

        if self._pageMap[i] then
            buttonType:addTouchEventListener(onPageClick)
        else
            KUtil.setTouchEnabled(buttonType, false)
        end
    end
end

function KUIMedalBookNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onUpdate()
        cclog("----------> onEvent onUpdate")
        self:UpDateList()
        self:refreshData()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MEDAL, onUpdate)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MEDAL_VALUE, onUpdate)
end

function KUIMedalBookNode:onCleanup()
end

return KUIMedalBookNode
