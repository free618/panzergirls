--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalDetailNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local MAX_REQUIRE_NUM       = 4
local KUIMedalDetailNode    = class(
    "KUIMedalDetailNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalDetailNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
end

function KUIMedalDetailNode.create(owner, oneMedalConfig)
    local currentNode = KUIMedalDetailNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_medal_detail.csb"
    currentNode._medalConfig = oneMedalConfig

    currentNode:init()

    return currentNode
end

function KUIMedalDetailNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIMedalDetailNode:closeAnimation(fun)
    for name, animation in pairs(self._animationList) do
        if name == "home" then
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4], fun)
        else
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        end
    end
end

function KUIMedalDetailNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local list              = self._animationList
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    list.top                = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_medal_detail.csb"), {10, 25, 50, 65}}
end

function KUIMedalDetailNode:onEnterActionFinished()
    self:playStartAnimation()
end

function KUIMedalDetailNode:onInitUI()
    self:onInitAnimation()
end

function KUIMedalDetailNode:refreshInfo(oneMedalConfig, oneMedal)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local popupBase         = imageBase:getChildByName("Image_popup_base")

    local imageIcon         = popupBase:getChildByName("Image_icon")
    local textName          = popupBase:getChildByName("Text_name")
    local textDescrition    = popupBase:getChildByName("Text_descrition_1")

    local panelDescrition1  = popupBase:getChildByName("Panel_description_1")
    local panelDescrition2  = popupBase:getChildByName("Panel_description_2")
    local panelDescrition3  = popupBase:getChildByName("Panel_description_3")
    local textScore         = popupBase:getChildByName("BitmapFontLabel_military")

    imageIcon:loadTexture(KUtil.getMedalImagePath(oneMedalConfig))
    textName:setString(oneMedalConfig.szName)
    textScore:setString(oneMedalConfig.nAddMedalValue)

    textDescrition:setString(oneMedalConfig.szConditionDescribe)

    if oneMedal and oneMedal.nNum > 0 and oneMedalConfig.nRepeat == 0 then
        panelDescrition1:setVisible(false)
        panelDescrition2:setVisible(false)
        panelDescrition3:setVisible(true)
        local textTime            = panelDescrition3:getChildByName("Text_time")
        local textDescription2    = panelDescrition3:getChildByName("Text_descrition_2")
        textDescription2:setString(oneMedalConfig.szDescribe)
        textTime:setString(os.date("%Y/%m/%d", oneMedal.nTime))
    else
        panelDescrition3:setVisible(false)
        local tConditionList = oneMedalConfig.anCondition
        local tMedalRequire  = HArray.FindFirst(KConfig.medalRequire, "nID", tConditionList[1])
        if tMedalRequire.nType == 1 then
            panelDescrition1:setVisible(true)
            panelDescrition2:setVisible(false)
            local textCondition       = panelDescrition1:getChildByName("Text_condition")
            local loadingBar          = panelDescrition1:getChildByName("LoadingBar_1")
            local textProgress        = panelDescrition1:getChildByName("Text_progress")

            for i, nID in ipairs(tConditionList) do
                local tMedalRequire = HArray.FindFirst(KConfig.medalRequire, "nID", nID)
                assert(tMedalRequire, nID)
                textCondition:setString(tMedalRequire.szDescribe)

                local nProgress = 0
                local tMedalProgress = HArray.FindFirst(oneMedal.tProgressList, "nID", nID)
                if tMedalProgress then
                    nProgress = tMedalProgress.nValue
                end
                loadingBar:setPercent(nProgress / tMedalRequire.nCount * 100)
                textProgress:setString(nProgress .."/".. tMedalRequire.nCount)
            end
        elseif tMedalRequire.nType == 2 then
            panelDescrition1:setVisible(false)
            panelDescrition2:setVisible(true)

            for i = 1, MAX_REQUIRE_NUM do
                local text          = panelDescrition2:getChildByName("Text_map_".. i)
                local image         = panelDescrition2:getChildByName("Image_".. i)

                local nID = tConditionList[i]
                if nID then
                    text:setVisible(true)

                    local tMedalRequire = HArray.FindFirst(KConfig.medalRequire, "nID", nID)
                    assert(tMedalRequire, nID)
                    text:setString(tMedalRequire.szDescribe)

                    local tMedalProgress = HArray.FindFirst(oneMedal.tProgressList, "nID", nID)
                    if tMedalProgress then
                        if tMedalProgress.nValue >= tMedalRequire.nCount then
                            image:setVisible(true)
                        else
                            image:setVisible(false)
                        end
                    end
                else
                    text:setVisible(false)
                    image:setVisible(false)
                end
            end
        end
    end
end

function KUIMedalDetailNode:refreshUI()
    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList
    local oneMedal   = HArray.FindFirst(tMedalList, "nID", self._medalConfig.nID)
    self:refreshInfo(self._medalConfig, oneMedal)
end

function KUIMedalDetailNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout

    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local imagePopupBase    = imageBase:getChildByName("Image_popup_base")
    local buttonClose       = imagePopupBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            self._parent:removeNode("MedalDetail")
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

function KUIMedalDetailNode:registerAllCustomEvent()
end

function KUIMedalDetailNode:onCleanup()
end

return KUIMedalDetailNode
