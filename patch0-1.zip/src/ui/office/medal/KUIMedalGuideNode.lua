--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalGuideNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUIMedalGuideNode = class(
    "KUIMedalGuideNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalGuideNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
end

function KUIMedalGuideNode.create(owner)
    local currentNode = KUIMedalGuideNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/animation_node/ani_medal_guide.csb"
    currentNode:init()

    return currentNode
end

function KUIMedalGuideNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIMedalGuideNode:closeAnimation(isReturnOffice)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local delayTime1 = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        delayTime = math.max(delayTime, delayTime1)
    end
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "MedalHelp", callBacks, isReturnOffice)
end

function KUIMedalGuideNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local list              = self._animationList
    list.top                = {KUtil.initAnimation(self._mainLayout, "res/ui/animation_node/ani_medal_guide.csb"), {0, 55, 75, 90}}
end

function KUIMedalGuideNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUIMedalGuideNode:onInitUI()
    self:onInitAnimation()
end

function KUIMedalGuideNode:refreshUI()
end

function KUIMedalGuideNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout

    local buttonClose       = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            self:closeAnimation(false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)
end

function KUIMedalGuideNode:registerAllCustomEvent()
end

function KUIMedalGuideNode:onCleanup()
end

return KUIMedalGuideNode
