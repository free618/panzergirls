--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local MAX_PAGE_NUM      = 4
local m_tPageNodeList   = { 
    {nodeName = "ProjectNode_record", class = "KUIRecordNode",   page = 1}, 
    {nodeName = "ProjectNode_wall",   class = "KUIMedalWallNode",  page = 2, showGuide = true}, 
    {nodeName = "ProjectNode_book",   class = "KUIMedalBookNode",  page = 3},
    {nodeName = "ProjectNode_rank",   class = "KUIMedalRankNode",  page = 4},
}

local KUIMedalNode = class(
    "KUIMedalNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
    self._currentPgae    = 1
    self._pageClassList  = {}
end

function KUIMedalNode.create(owner)
    local currentNode = KUIMedalNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_record.csb"
    currentNode:init()

    return currentNode
end

function KUIMedalNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIMedalNode:closeAnimation(fun)
    for name, animation in pairs(self._animationList) do
        if name == "home" then
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4], fun)
        else
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        end
    end
end

function KUIMedalNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout

    local list              = self._animationList
    local projectNode       = mainNode:getChildByName("ProjectNode_top")
    list.top                = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_record_top_button.csb"), {0, 30, 50, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_button")
    list.button             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_record_button_left.csb"), {0, 22, 171, 186}, 
        ActiveButton = {page1 ={16, 22, 30, 36}, page2 ={55, 62, 70, 76}, page3 ={96, 102, 110, 116}, page4 ={136, 142, 150, 156},},}

    local projectNode       = mainNode:getChildByName("ProjectNode_button_home")
    list.home               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_home.csb"), {0, 30, 40, 65}}
end

function KUIMedalNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
        delayExecute(self._mainLayout, function()
            self:switchPage(1)
        end, 0.1)
    end, 0.1)
end

function KUIMedalNode:onInitUI()
    self:onInitAnimation()
end


function KUIMedalNode:refreshUI()
end

local function createPage(self, nPage)
    if not self._pageClassList[nPage] then
        local szPath = "src/ui/office/medal/" .. m_tPageNodeList[nPage].class
        local projectNode       = self._mainLayout:getChildByName("Image_common_base")
        self._pageClassList[nPage] = require(szPath).create(self, m_tPageNodeList[nPage].nodeName, projectNode)
    end
end

local function quitPage(self, nPage)
    if not self._pageClassList[nPage] then
        return 0.03
    end

    return self._pageClassList[nPage]:quit()
end

local function enterPage(self, nPage)
    if not self._pageClassList[nPage] then
        return 0.03
    end

    self._pageClassList[nPage]:enter()
end

function KUIMedalNode:switchPage(nPage)
    local delayTime = quitPage(self, self._currentPgae)
    local animation = self._animationList.button
    KUtil.playAnimationByAnimation(animation[1], animation.ActiveButton["page"..self._currentPgae][3], animation.ActiveButton["page"..self._currentPgae][4], function()
        KUtil.playAnimationByAnimation(animation[1], animation.ActiveButton["page"..self._currentPgae][1], animation.ActiveButton["page"..self._currentPgae][2])
    end)
    self._currentPgae = nPage

    createPage(self, nPage)

    local function enter()
        enterPage(self, self._currentPgae)
    end

    self._mainLayout:stopActionByTag(66666)
    local delayAction = delayExecute(self._mainLayout, enter, delayTime)
    delayAction:setTag(66666)

    local mainNode          = self._mainLayout
    local nodeTop           = mainNode:getChildByName("ProjectNode_top")
    local Panel_help        = nodeTop:getChildByName("Panel_help")
    if m_tPageNodeList[nPage].showGuide then
        Panel_help:setVisible(true)
    else
        Panel_help:setVisible(false)
    end
end

function KUIMedalNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout

    --Home Button
    local buttonProject = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome     = buttonProject:getChildByName("Panel_common_home")
    local buttonHome    = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            sender:setEnabled(false)
            local delayTime = quitPage(self, self._currentPgae)
            delayExecute(self._mainLayout, function()
                self:closeAnimation(function()
                    self._parent:returnOffice()
                end)
            end, delayTime)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local imageBase         = mainNode:getChildByName("ProjectNode_top")
    local buttonClose       = imageBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("click")
            sender:setEnabled(false)
            local delayTime = quitPage(self, self._currentPgae)
            delayExecute(self._mainLayout, function()
                self:closeAnimation(function()
                    self._parent:removeNode("Medal")
                end)
            end, delayTime)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local Panel_help        = imageBase:getChildByName("Panel_help")
    local buttonHelp        = Panel_help:getChildByName("Button_help")
    local function onHelpClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHelpClick~")
            KSound.playEffect("click")
            self._parent:addNode("MedalHelp")
        end
    end
    buttonHelp:addTouchEventListener(onHelpClick)


    local imageBase         = mainNode:getChildByName("ProjectNode_button")
    local ImageLabelBase    = imageBase:getChildByName("Image_label_base")
    for i = 1, MAX_PAGE_NUM do
        local button        = ImageLabelBase:getChildByName("Button_"..i)
        local function onPageClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onDetailClick~")
                KSound.playEffect("click")
                self:switchPage(i)
            end
        end

        button:addTouchEventListener(onPageClick)
    end
end

function KUIMedalNode:registerAllCustomEvent()
end

function KUIMedalNode:onCleanup()
end

return KUIMedalNode
