--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalRankNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local RANK_NUM = 3

local KUIMedalRankNode = class(
    "KUIMedalRankNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalRankNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
    self._showRank       = false
    self._rankList       = nil
end

function KUIMedalRankNode.create(owner, nodeName, projectNode)
    local currentNode = KUIMedalRankNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/animation_node/ani_record_medal_rank.csb"
    currentNode:init()

    currentNode:setName(nodeName)
    projectNode:addChild(currentNode)

    return currentNode
end

function KUIMedalRankNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    self._animationList.top     = KUtil.initAnimation(self._mainLayout, "res/ui/animation_node/ani_record_medal_rank.csb")
end

local function enterAnimation(self)
    local mainNode     = self._mainLayout
    mainNode:setVisible(true)

    for _, animation in pairs(self._animationList) do
        KUtil.playEnterAnimation(animation)
    end
end

local function exitAnimation(self)
    local delayTime = 0
    for _, animation in pairs(self._animationList) do
        local time = KUtil.playQuitAnimation(animation)
        if time > delayTime then
            delayTime = time
        end
    end

    delayExecute(self._mainLayout, function()
        self._mainLayout:setVisible(false)
    end, delayTime)

    return delayTime
end

function KUIMedalRankNode:onEnterActionFinished()
end

function KUIMedalRankNode:enter()
    enterAnimation(self)
end

function KUIMedalRankNode:quit()
    return exitAnimation(self)
end

local function initUI(self)
    local mainNode        = self._mainLayout
    local imageRankBase   = mainNode:getChildByName("Image_medal_rank")
    local scrollView      = imageRankBase:getChildByName("ScrollView_1")
    local panelUnit       = scrollView:getChildByName("Image_unit")
    
    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)

    self._imageUnit       = panelUnit
    self._imageUnit:removeFromParent(false)
    node:addChild(self._imageUnit)
end

function KUIMedalRankNode:onInitUI()
    self:onInitAnimation()
    initUI(self)

    require("src/network/KC2SProtocolManager"):requestCardRankData()

    for i = 1, RANK_NUM do
        local layer          = ccui.Layout:create()
        local projectCard    = self._imageUnit:getChildByName("ProjectNode_card_"..i)
        local childrenList  = projectCard:getChildren()
        layer:setPosition(projectCard:getPositionX(), projectCard:getPositionY())
        layer:setName("ProjectNode_card_"..i)
        layer:setScale(projectCard:getScale())

        for _, v in pairs(childrenList) do
            v:removeFromParent(false)
            layer:addChild(v)
        end

        projectCard:removeFromParent()
        self._imageUnit:addChild(layer)
        local imageRank         = self._imageUnit:getChildByName("Image_rank_base_"..i)
        imageRank:setLocalZOrder(i + 10)
    end
end

local function getCardHistoricalList()
    local cardMap  = {}
    -- get card data
    local haveCardList = KPlayer.tCardData.tHistoricalCardID
    for _, cardID in ipairs(haveCardList) do
        cardMap[cardID] = {haveGet = true}
    end

    -- check married
    local marriedIDList = KUtil.getMarriedCardIDList()
    for _, cardID in ipairs(marriedIDList) do
        if cardMap[cardID] then 
            cardMap[cardID].isMarried = true
        end
    end

    return cardMap
end

local function getMaxConvertInfo(CardHistorical, cardConfig)
    assert(CardHistorical, "have not CardHistorical")
    local nConvertTemplateID    = cardConfig.nConvertID
    while CardHistorical[nConvertTemplateID] do
        cardConfig              = KConfig.cardInfo[nConvertTemplateID]
        nConvertTemplateID      = cardConfig.nConvertID
    end

    return cardConfig
end

local function getCardImagePath(cardConfig, isHead, cardHistorical)
    local ConvertConfig = getMaxConvertInfo(cardHistorical, cardConfig)
    local imageName = "/Normal"
    if isHead then
        imageName = imageName.."head.png"
    else
        imageName = imageName.."Image.png"
    end
    return "res/images/cards/"..ConvertConfig.szResPath..imageName
end

local RANK_TYPE_TEXT  =
{
    [OTHER_RANK_TYPE.MVP]       = "medal.rankMVP",
    [OTHER_RANK_TYPE.BROKEN]    = "medal.rankBroken",
    --[OTHER_RANK_TYPE.DIE]       = "死亡",
    [OTHER_RANK_TYPE.FIGHTING]  = "medal.rankLaunch",
    [OTHER_RANK_TYPE.BEHIT]     = "medal.rankBehit",
    [OTHER_RANK_TYPE.MISS]      = "medal.rankDodge",
}

local function updateScrollRank(self, unit, oneRank)
    local textType    = unit:getChildByName("Text_type")
    textType:setString(KUtil.getStringByKey(RANK_TYPE_TEXT[oneRank.nType]))
    
    for i = 1, RANK_NUM do
        local rankData = oneRank[i]
        local textRankResult    = unit:getChildByName("Text_count_"..i)
        local projectCard       = unit:getChildByName("ProjectNode_card_"..i)
        local imageRank         = unit:getChildByName("Image_rank_base_"..i)
        local imageFrequency    = unit:getChildByName("Image_frequency_base_"..i)

        if not rankData then
            projectCard:setVisible(false)
            textRankResult:setString("")
            imageRank:setVisible(false)
            imageFrequency:setVisible(false)
        else
            projectCard:setVisible(true)
            textRankResult:setString(rankData.nValue..KUtil.getStringByKey("common.num1"))
            imageRank:setVisible(true)
            imageFrequency:setVisible(true)

            local cardConfig  = KConfig.cardInfo[rankData.nID]

            local imageCardBase  = projectCard:getChildByName("Image_chara")
            local imageCardHead  = projectCard:getChildByName("Image_chara_head")
            local imageCardType  = projectCard:getChildByName("Image_chara_type")
            local imageCardMedal = projectCard:getChildByName("Image_card_medal")
            --local projectHeart   = projectCard:getChildByName("ProjectNode_heart")

            local backgroundPath = string.format("res/images/cards/type/basemap-%d.png", cardConfig.nQuality)
            local medalPath      = KUtil.getCardMedalPath(rankData.nID)
            local headTypePath   = KUtil.getCardBackGround(cardConfig.nTankType)
            local cardHeadPath   = getCardImagePath(cardConfig, true, self._cardHistorical)

            imageCardBase:loadTexture(backgroundPath)
            imageCardHead:loadTexture(cardHeadPath)
            imageCardType:loadTexture(headTypePath)
            imageCardMedal:loadTexture(medalPath)
            --projectHeart:setVisible(false)

            --update head back
            local countryType         = cardConfig.nCountryType
            local cardHeadBackFormat  = "Image_chara_%s"
            KUtil.setCardHeadBack(projectCard, countryType, cardHeadBackFormat)
        end
    end
end

local function addScrollPageView(self, isCutIn)
    if not self._rankList then
        return
    end

    for k,v in pairs(self._rankList) do
        v.nID = v.nType
    end

    local mainNode        = self._mainLayout
    local imageRankBase   = mainNode:getChildByName("Image_medal_rank")
    local scrollView      = imageRankBase:getChildByName("ScrollView_1")

    local refreshCall = function(control, dataInfo)
        updateScrollRank(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = nil,
        itemBase    = self._imageUnit,
        dataList    = self._rankList,
        refreshCall = refreshCall,
        column      = 1,
        row         = 6,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

function KUIMedalRankNode:refreshRank()
    self._cardHistorical = getCardHistoricalList()
    addScrollPageView(self, true)
end

function KUIMedalRankNode:refreshUI()
    self:refreshRank()
end

function KUIMedalRankNode:registerAllTouchEvent()
end

function KUIMedalRankNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onUpDateRank(tRankData)
        cclog("KUIMedalRankNode onEvent ---------->onUpDateRank")
        self._rankList = {}

        for k,v in pairs(tRankData) do
            table.insert(self._rankList, v)
        end
        self:refreshRank()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_OTHER_RANK_GET, onUpDateRank)
end

function KUIMedalRankNode:onCleanup()
end

return KUIMedalRankNode
