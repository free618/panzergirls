--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMedalWallNode.lua
--  Creator     : guoweiqiang
--  Date        : 2016/05/06   18:46
--  Contact     : guoweiqiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local BORDERDISTANCE  = 30

local KUIMedalWallNode = class(
    "KUIMedalWallNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMedalWallNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._animationList  = {}
end

function KUIMedalWallNode.create(owner, nodeName, projectNode)
    local currentNode = KUIMedalWallNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_record_medal_wall.csb"
    currentNode:init()

    currentNode:setName(nodeName)
    projectNode:addChild(currentNode)

    return currentNode
end

function KUIMedalWallNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUIMedalWallNode:closeAnimation(fun)
    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local time
        if name == "wall" then
            time = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4], fun)
        else
            time = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        end

        if time > delayTime then
            delayTime = time
        end
    end

    return delayTime
end

function KUIMedalWallNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local list              = self._animationList
    local projectNode       = mainNode:getChildByName("ProjectNode_wall")
    list.wall               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_record_medal_wall.csb"), {0, 30, 50, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_right_1")
    list.right1             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_record_medal_wall_right_1.csb"), {0, 15, 50, 65},
                                openAnimation = {0, 15, 50, 65}, closeAnimation = {0, 0, 0, 0}}

    local projectNode       = mainNode:getChildByName("ProjectNode_right_2")
    list.right2             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_record_medal_wall_right_2.csb"), {1, 1, 64, 65},
                                openAnimation = {1,15, 50, 65}, closeAnimation = {1, 1, 64, 65, 50, 64}}
end

function KUIMedalWallNode:onEnterActionFinished()
end

function KUIMedalWallNode:onInitUI()
    self:onInitAnimation()
    self._medalList  = self:getMedalList()
end

local function getMedalConfig(nID)
    local oneMedalConfig = HArray.FindFirst(KConfig.medalinfo, "nID", nID)
    return oneMedalConfig
end

local function initUI(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_wall")
    local imageBase       = projectNode:getChildByName("Image_medal_wall_base")
    local panelWall       = imageBase:getChildByName("Panel_wall")
    local imageUnit       = panelWall:getChildByName("Image_medal_icon")
    imageUnit:setVisible(false)

    self._imageUnitList   = {imageUnit}

    local imageBase         = mainNode:getChildByName("ProjectNode_right_2")
    local imageEditBase     = imageBase:getChildByName("Image_edit_base")
    local scrollView        = imageEditBase:getChildByName("ScrollView_1")
    local imageUnit         = scrollView:getChildByName("Panel_medal_icon")

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)

    self._imageUnit      = imageUnit
    self._imageUnit:removeFromParent(false)
    node:addChild(self._imageUnit)
end

function KUIMedalWallNode:upMedal(i, oneMedalConfig, placeInfo, index)
    local unit = self._imageUnitList[i]
    if not unit then
        self._imageUnitList[i] = self._imageUnitList[1]:clone()
        unit   = self._imageUnitList[i]
        self._imageUnitList[1]:getParent():addChild(unit)
    end

    unit:setVisible(true)
    unit:setPosition(placeInfo.x, placeInfo.y)
    unit:loadTexture(KUtil.getMedalImagePath(oneMedalConfig))

    local unitSize      = unit:getContentSize()
    local parentSize    = unit:getParent():getContentSize()
    local point
    local function onMedalClick(sender, type)
        if type == ccui.TouchEventType.moved then
            if not self._isMoveMode then
                return
            end

            local currentPos = sender:getTouchMovePosition()
            currentPos.x = currentPos.x - point.x + placeInfo.x
            currentPos.y = currentPos.y - point.y + placeInfo.y

            sender:setPosition(currentPos.x, currentPos.y)
        elseif type == ccui.TouchEventType.began then
            point = sender:getTouchBeganPosition()
        elseif type == ccui.TouchEventType.canceled then
            if not self._isMoveMode then
                return
            end

            table.remove(self._useList[oneMedalConfig.nID], index)
            self:saveSetting()
            if #self._imageUnitList > 1 then
                table.remove(self._imageUnitList, i)
                unit:removeFromParent()
            else
                unit:setVisible(false)
            end

            self:refreshList()
            self:updateScrollRankByID(oneMedalConfig.nID)
        elseif type == ccui.TouchEventType.ended then
            cclog("click onMedalClick~")
            if self._isMoveMode then
                local endPos = sender:getTouchEndPosition()
                endPos.x = endPos.x - point.x + placeInfo.x
                endPos.y = endPos.y - point.y + placeInfo.y

                if endPos.x < -unitSize.width / 2 or endPos.y < -unitSize.height / 2 or 
                    endPos.x > parentSize.width + unitSize.width / 2 or endPos.y > parentSize.height + unitSize.height / 2 then
                    table.remove(self._useList[oneMedalConfig.nID], index)
                    self:saveSetting()

                    if #self._imageUnitList > 1 then
                        table.remove(self._imageUnitList, i)
                        unit:removeFromParent()
                    else
                        unit:setVisible(false)
                    end

                    self:refreshList()
                    self:updateScrollRankByID(oneMedalConfig.nID)
                    return
                end

                if endPos.x < unitSize.width / 3 then
                    endPos.x = unitSize.width / 3
                end

                if endPos.x > parentSize.width - unitSize.width / 3 then
                    endPos.x = parentSize.width - unitSize.width / 3
                end

                if endPos.y < unitSize.height / 3 then
                    endPos.y = unitSize.height / 3
                end

                if endPos.y > parentSize.height - unitSize.height / 5 then
                    endPos.y = parentSize.height - unitSize.height / 5
                end

                sender:setPosition(endPos.x, endPos.y)

                placeInfo.x = endPos.x
                placeInfo.y = endPos.y
                self:saveSetting()
            else
                KSound.playEffect("click")
                self._parent._parent:addNode("MedalDetail", oneMedalConfig)
            end
        end
    end
    unit:addTouchEventListener(onMedalClick)
end

function KUIMedalWallNode:saveSetting()
    local setting = require("src/logic/KSetting")
    setting.setString(setting.Key.MEDAL_USE_INFO.."_"..KPlayer.id, tableToString(self._useList))
end

function KUIMedalWallNode:loadSetting()
    if self._useList then
        return self._useList
    end

    local setting = require("src/logic/KSetting")
    local str     = "return " .. setting.getString(setting.Key.MEDAL_USE_INFO.."_"..KPlayer.id, "{}")
    self._useList = loadstring(str)()
    return self._useList
end

function KUIMedalWallNode:refreshTop()
    local mainNode          = self._mainLayout
    local imageBase         = mainNode:getChildByName("ProjectNode_right_1")
    local panelData         = imageBase:getChildByName("Panel_data")

    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList
    local tNumList   = {0, 0, 0, 0}

    for k, oneMedal in pairs(tMedalList) do
        if oneMedal.nNum > 0 then
            local oneMedalConfig = getMedalConfig(oneMedal.nID)
            assert(oneMedalConfig.nGrade, oneMedal.nID)
            tNumList[oneMedalConfig.nGrade] = tNumList[oneMedalConfig.nGrade] + oneMedal.nNum
        end
    end

    local panel             = panelData:getChildByName("Panel_1")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(tNumList[3])
    
    local panel             = panelData:getChildByName("Panel_2")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(tNumList[2])
    
    local panel             = panelData:getChildByName("Panel_3")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(tNumList[1])
    
    local panel             = panelData:getChildByName("Panel_4")
    local Label             = panel:getChildByName("BitmapFontLabel_count")
    Label:setString(tMedalData.nValue)
end

function KUIMedalWallNode:getMedalList()
    local tMedalData = KPlayer.tMedalData
    local tMedalList = tMedalData.tMedalList

    local list = {}
    for _, oneMedalConfig in pairs(KConfig.medalinfo) do
        local oneMedal = HArray.FindFirst(tMedalList, "nID", oneMedalConfig.nID)
        if oneMedal and oneMedal.nNum > 0 then
            table.insert(list, {nID = oneMedalConfig.nID, oneMedalConfig = oneMedalConfig, num = oneMedal.nNum})
        end
    end

    return list
end

function KUIMedalWallNode:updateScrollRank(unit, data)
    local imageMedalIcon    = unit:getChildByName("Image_medal_icon")
    local textCount         = unit:getChildByName("Text_count")
    local textName          = unit:getChildByName("Text_name")

    imageMedalIcon:loadTexture(KUtil.getMedalImagePath(data.oneMedalConfig))
    local useNum  = 0
    local useInfo = self._useList[data.oneMedalConfig.nID]
    if useInfo then
        useNum = #useInfo
    end
    textCount:setString(data.num - useNum)
    textName:setString(data.oneMedalConfig.szName)

    if data.num - useNum < 1 then
        unit:setTouchEnabled(false)
        KUtil.setWidgetGray(imageMedalIcon)
    else
        unit:setTouchEnabled(true)
        KUtil.setWidgetNormal(imageMedalIcon)

        local point
        local moveUnit
        local placeInfo
        local panelWall     = self._imageUnitList[1]:getParent()

        local function onMedalClick(sender, type)
            if type == ccui.TouchEventType.moved then
                local currentPos = sender:getTouchMovePosition()
                currentPos.x = currentPos.x - point.x + placeInfo.x
                currentPos.y = currentPos.y - point.y + placeInfo.y

                moveUnit:setPosition(currentPos.x, currentPos.y)
            elseif type == ccui.TouchEventType.began then
                point = sender:getTouchBeganPosition()
                moveUnit = imageMedalIcon:clone()
                placeInfo   = imageMedalIcon:convertToWorldSpace({x = 0, y = 0})
                moveUnit:setPosition(placeInfo)
                self._mainLayout:addChild(moveUnit)
            elseif type == ccui.TouchEventType.canceled then
                local endPos = sender:getTouchEndPosition()

                local centerSize    = panelWall:getContentSize()
                local centerPoint   = {x = panelWall:getPositionX(), y = panelWall:getPositionY()}
                centerPoint = panelWall:convertToWorldSpace(centerPoint)

                if endPos.x < centerPoint.x + centerSize.width - BORDERDISTANCE and endPos.y < centerPoint.y + centerSize.height - BORDERDISTANCE and
                    endPos.x > centerPoint.x + BORDERDISTANCE and endPos.y > centerPoint.y + BORDERDISTANCE then

                    if not self._useList[data.nID] then
                        self._useList[data.nID] = {}
                    end

                    local info = self._useList[data.nID]
                    local place = panelWall:convertToNodeSpace({x = moveUnit:getPositionX(), y = moveUnit:getPositionY()})
                    table.insert(info, place)
                    self:saveSetting()

                    if data.num - #info < 1 then
                        unit:setTouchEnabled(false)
                        KUtil.setWidgetGray(imageMedalIcon)
                    end
                    textCount:setString(data.num - #info)
                    self:refreshList()
                end

                moveUnit:removeFromParent()
            elseif type == ccui.TouchEventType.ended then
                cclog("click onMedalClick~")
                KSound.playEffect("click")
                moveUnit:removeFromParent()
            end
        end
        unit:addTouchEventListener(onMedalClick)
    end
end

function KUIMedalWallNode:updateScrollRankByID(nID)
    local mainNode        = self._mainLayout
    local imageBase       = mainNode:getChildByName("ProjectNode_right_2")
    local imageEditBase   = imageBase:getChildByName("Image_edit_base")
    local scrollView      = imageEditBase:getChildByName("ScrollView_1")
    local control         = scrollView:getChildByName(tostring(nID))
    if control then
        for i, v in ipairs(self._medalList) do
            if v.nID == nID then
                self:updateScrollRank(control, v)
                break
            end
        end
    end
end

local function addScrollPageView(self, isCutIn)
    if not self._medalList then
        return
    end

    local mainNode        = self._mainLayout
    local imageBase       = mainNode:getChildByName("ProjectNode_right_2")
    local imageEditBase   = imageBase:getChildByName("Image_edit_base")
    local scrollView      = imageEditBase:getChildByName("ScrollView_1")

    local refreshCall = function(control, dataInfo)
        self:updateScrollRank(control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = nil,
        itemBase    = self._imageUnit,
        dataList    = self._medalList,
        refreshCall = refreshCall,
        column      = 2,
        row         = 6,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

function KUIMedalWallNode:refreshRigth()
    addScrollPageView(self, false)
end

function KUIMedalWallNode:refreshList()
    local index = 1
    for id, info in pairs(self._useList) do
        local oneMedalConfig = getMedalConfig(id)
        if oneMedalConfig then
            for i, place in ipairs(info) do
                self:upMedal(index, oneMedalConfig, place, i)
                index = index + 1
            end
        end
    end
end

function KUIMedalWallNode:enter()
    self._mainLayout:setVisible(true)
    self:playStartAnimation()
end

function KUIMedalWallNode:quit()
    return self:closeAnimation(function()
        self._mainLayout:setVisible(false)
    end)
end

function KUIMedalWallNode:refreshUI()
    initUI(self)

    self._useList = nil
    self:loadSetting()
    self:refreshList()
    self:refreshTop()
    self:refreshRigth()

    if not self._useList.noFristOpen then
        delayExecute(self._mainLayout, function()
            self._parent._parent:addNode("MedalHelp")
        end, 0.3)
        self._useList.noFristOpen = 1
        self:saveSetting()
    end
end

function KUIMedalWallNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout

    local projectNodeRight  = mainNode:getChildByName("ProjectNode_right_2")
    local projectNode       = projectNodeRight:getChildByName("Image_edit_base")
    local buttonEdit        = projectNode:getChildByName("Button_edit")
    local buttonSave        = projectNode:getChildByName("Button_save")
    buttonEdit:setVisible(not self._isMoveMode)
    buttonSave:setVisible(self._isMoveMode)

    local function onEditClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onEditClick~")
            KSound.playEffect("click")

            self._isMoveMode = true
            buttonEdit:setVisible(not self._isMoveMode)
            buttonSave:setVisible(self._isMoveMode)

            local animation = self._animationList.right1
            animation[2] = animation.closeAnimation
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])

            local animation = self._animationList.right2
            animation[2] = animation.openAnimation
            KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
        end
    end
    buttonEdit:addTouchEventListener(onEditClick)

    local function onSaveClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onEditClick~")
            KSound.playEffect("click")

            self._isMoveMode = false
            buttonEdit:setVisible(not self._isMoveMode)
            buttonSave:setVisible(self._isMoveMode)

            local animation = self._animationList.right1
            animation[2] = animation.openAnimation
            KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])

            local animation = self._animationList.right2
            animation[2] = animation.closeAnimation
            KUtil.playAnimationByAnimation(animation[1], animation[2][5], animation[2][6])
        end
    end
    buttonSave:addTouchEventListener(onSaveClick)
end

function KUIMedalWallNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onUpdate()
        cclog("----------> onEvent onUpdate")
        self._medalList  = self:getMedalList()
        self:refreshList()
        self:refreshTop()
        self:refreshRigth()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MEDAL, onUpdate)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MEDAL_VALUE, onUpdate)

end

function KUIMedalWallNode:onCleanup()
end

return KUIMedalWallNode
