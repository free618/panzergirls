--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIMissionListNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/08/11   09:26
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local BUTTON_LIST_ENTER_BEGIN_FRAME = 0
local BUTTON_LIST_ENTER_END_FRAME = 15
local BUTTON_LIST_QUIT_BEGIN_FRAME = 210
local BUTTON_LIST_QUIT_END_FRAME = 226
local ONE_BUTTON_FRAME_LEN = 40
local ONE_BUTTON_ENTER_BEGIN_FRAME = 0
local ONE_BUTTON_QUIT_BEGIN_FRAME = 14
local ONE_BUTTON_MOVE_LEN = 7
local EXTEND_MISSION_COUNT = 2
local BASE_PATH = "res/ui/ui_material/misson/img_misson_"
local m_BouttonTexture  = 
{
    ["normal"]   = "res/ui/ui_material/misson/extend_label.png", 
    ["press"]    = "res/ui/ui_material/misson/extend_label_active.png", 
    ["disable"]  = "res/ui/ui_material/misson/extend_label_disable.png",
}

local KUIMissionListNode = class(
    "KUIMissionListNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIMissionListNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._baseMissionBar        = nil
    self._nowTime               = os.time()
    self._nType                 = 0
    self._viewMissionList       = nil
    self._animationHome         = nil
    self._animationResource     = nil
    self._animationButton       = nil
    self._animationContent      = nil
    self._animationExtend       = nil
    self._animationExtendContent = nil
    self._isExtrndRed           = false
end

function KUIMissionListNode.create(owner, nType)
    local currentNode   = KUIMissionListNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_mission.csb"
    if nType then
        currentNode._nType  = nType
    end
    currentNode:init()

    return currentNode
end

function KUIMissionListNode:close()
    self._parent:removeNode("Mission") 
end

function KUIMissionListNode:getViewMissionListByType()
    assert(self._viewMissionList)
    if self._nType == MISSION_TYPE.EXTEND_JUNIOR then
        return self._viewMissionList.extend
    end
    local tMissionList = {}
    for _, tMissionInfo in ipairs(self._viewMissionList.common) do
        if self._nType == 0 or self._nType == tMissionInfo.config.nType then 
            table.insert(tMissionList, tMissionInfo)
        end
    end
    return tMissionList
end

function KUIMissionListNode:getViewMissionList()
    self._isExtrndRed   = false
    local tMissionList  = {}
    tMissionList.common = {}
    tMissionList.extend = {}
    local nCurrentNumero
     
    for i, tOneMission in ipairs(KPlayer.tMissionData.tMissionList) do
        local tMissionConfig = KUtil.getMissionConfig(tOneMission.nID)
        if tMissionConfig.nNumero ~= 0 then
            self._isExtrndRed = true
            if not nCurrentNumero then
                nCurrentNumero = tMissionConfig.nNumero
            elseif tMissionConfig.nNumero > nCurrentNumero then
                nCurrentNumero = tMissionConfig.nNumero
            end
        end
    end

    if not nCurrentNumero then
        nCurrentNumero = 1
        for _, nID in ipairs (KPlayer.tMissionData.tHistoricalMissionList) do
            local tMissionConfig = KUtil.getMissionConfig(nID)
            if tMissionConfig and tMissionConfig.nNumero >= nCurrentNumero then
                nCurrentNumero = nCurrentNumero + 1
            end
        end
    end

    for nMissionID, tMissionConfig in pairs(KConfig["mission"]) do
        if tMissionConfig.nNumero ~= 0 then
            if tMissionConfig.nNumero >= nCurrentNumero 
                and tMissionConfig.nNumero < (EXTEND_MISSION_COUNT + nCurrentNumero) then
                --and tMissionConfig.nType == nCurrentType then
                local nPercent = 0
                if tMissionConfig.nNumero == nCurrentNumero then
                    nPercent = KUtil.getMissionPercentCompleted(tMissionConfig)
                end
                table.insert(tMissionList.extend, {nID = nMissionID, config = tMissionConfig, percent = nPercent})
            end
        elseif KUtil.isMissionView(tMissionConfig) then
            local nPercent = KUtil.getMissionPercentCompleted(tMissionConfig)
            table.insert(tMissionList.common, {nID = nMissionID, config = tMissionConfig, percent = nPercent})
        end
    end
    table.sort(tMissionList.common, 
        function(i1, i2)
            if i1.percent > i2.percent then
                return true
            elseif i1.percent == i2.percent and i1.config.nID > i2.config.nID then
                return true
            end
            return false
        end)

    table.sort(tMissionList.extend, 
        function(i1, i2)
            if i1.config.nNumero < i2.config.nNumero then
                return true
            end
            return false
        end)

    local nCurrentType
    local i = 1
    while true do
        local tInfo = tMissionList.extend[i]
        if not tInfo then break end
        if not nCurrentType then
            nCurrentType = tInfo.config.nType
        elseif tInfo.config.nType ~= nCurrentType then
            table.remove(tMissionList.extend, i)
        end
        i = i + 1
    end
    return tMissionList
end

function KUIMissionListNode:initMissionBar(bar, missionInfo)
    --type icon
    local imageType     = {"Image_type_zr","Image_type_cj","Image_type_yx","Image_type_yz","Image_type_hq","Image_type_gc","Image_type_gz"}
    local imageTypeList = {"Image_type_zr","Image_type_cj","Image_type_yx","Image_type_yz","Image_type_hq","Image_type_hq",
                           "Image_type_gc","Image_type_gc","Image_type_gc","Image_type_gc","Image_type_gz"}
    
    local missionImageType = imageTypeList[missionInfo.config.nObjectType]
    local panelMissionIcon = bar:getChildByName("Panel_mission_icon")
    for i= 1, #imageType do 
        local imageMissionType = panelMissionIcon:getChildByName(imageType[i]) 
        imageMissionType:setVisible(imageType[i] == missionImageType)
    end
    
    --description
    local description = bar:getChildByName("Text_mission_description")
    description:setString((string.gsub(missionInfo.config.szDescribe, "\\n", "\n")))
    
    --reward      
    local currencyNums = {}     
    local tItemList    = {}
    local tReward      = KUtil.getRewardRandResult(missionInfo.config.nReward)
    
    local iconIndex, maxIconIndex = 1, 0
    while true do
        local clippingPanel = bar:getChildByName("Panel_icon_" .. maxIconIndex + 1)
        if clippingPanel then
            clippingPanel:setVisible(false)
            maxIconIndex = maxIconIndex + 1
        else
            break
        end
    end
    
    for i, item in ipairs(tReward) do
        if item["nID"] ~= 0 and item["nNum"] ~= 0 then
            local rewardType = item.nType
            local nID        = item.nID
            if rewardType == ITEM_TYPE.CURRENCY and nID ~= CURRENCY_TYPE.COIN then
                currencyNums[nID] = (currencyNums[nID] or 0) + item.nNum
            elseif iconIndex <= maxIconIndex then
                local clippingPanel = bar:getChildByName("Panel_icon_"..iconIndex)
                clippingPanel:setVisible(true)

                local clippingIcon = clippingPanel:getChildByName("Panel_icon_base")
                local imageIcon    = clippingIcon:getChildByName("Image_icon")

                local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, nID)
                --clippingPanel:setClippingEnabled(clipping)
                clippingIcon:setClippingEnabled(clipping)

                local scale = scaleRatio * 0.6
                imageIcon:loadTexture(filePath)
                imageIcon:setScale(scale)
                iconIndex = iconIndex + 1
            end
            table.insert(tItemList, item)
        end
    end
    
    local currencyName = {[CURRENCY_TYPE.OIL]    = "Text_oil_data", 
                          [CURRENCY_TYPE.AMMO]   = "Text_ammo_data", 
                          [CURRENCY_TYPE.STEEL]  = "Text_steel_data", 
                          [CURRENCY_TYPE.PEOPLE] = "Text_sp_ammo_data"}    
        
    for i,v in pairs(currencyName) do
        local text = bar:getChildByName(v)
        local count = (currencyNums[i] or 0)
        text:setString(count)
    end  

    local missionId       = missionInfo.config.nID
    bar.nMissionID        = missionId

    local imageFinish = bar:getChildByName("Image_mission_unit_finish") 
    finishButton  = imageFinish:getChildByName("Button_gain_button")
    local function onUnitClick(sender, type)
        if ccui.TouchEventType.ended == type then
            local tip = KUtil.CanSuperAddItems(tItemList)
            if tip then
                showNoticeByID(tip)
            else
                cclog("on mission on reward.id:%d click for team", missionId)
                require("src/network/KC2SProtocolManager"):getMissionReward(missionId)
            end
        end
    end
    finishButton:addTouchEventListener(onUnitClick)

    goButton   = bar:getChildByName("Button_go_button")
    local function onUnitClick(sender, type)
        if ccui.TouchEventType.ended == type then
            KSound.playEffect("goForward")
            cclog("on mission go button.id:%d click for team", missionId)
            self:close()
            local stringBase = [[ local scene = select(1,...); scene:gotoUI(%s) ]]
            local funcGotoUI = assert(loadstring(string.format(stringBase, missionInfo.config.szGotoUI)), missionInfo.config.szGotoUI)
            funcGotoUI(self._parent)
        end
    end
    goButton:addTouchEventListener(onUnitClick)

    self:initPercentComplete(bar, missionInfo)
    return bar
end

function KUIMissionListNode:initPercentComplete(bar, missionInfo)
    --percent complete ,title
    local percentComplete = missionInfo.percent
    bar.nPercentComplete  = percentComplete
    local imageFinish     = bar:getChildByName("Image_mission_unit_finish") 
    local title, button

    if percentComplete >= 100 then
        imageFinish:setVisible(true)
        title   = imageFinish:getChildByName("Text_mission_title_finish") 
    else
        imageFinish:setVisible(false)
        local buttonPercentComplete = bar:getChildByName("BitmapFontLabel_complete")
        buttonPercentComplete:setString(string.format(KUtil.getStringByKey("common.percent"), math.floor(missionInfo.percent)))
        title    = bar:getChildByName("Text_mission_title")
    end    
    title:setString(missionInfo.config.szName)
end

function KUIMissionListNode:refreshScrollView(isCutIn)
    local mainNode         = self._mainLayout
    
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local animationContent = imageControl:getChildByName("ProjectNode_rw_content")
    local animationExtend = imageControl:getChildByName("ProjectNode_rw_extend")
    animationContent:setVisible(true)
    animationExtend:setVisible(false)
    local imageBase        = animationContent:getChildByName("Image_rw_base")
    local scrollView       = imageBase:getChildByName("Scrollview_mission_list")
    local slideView        = imageBase:getChildByName("Slider_scroll")
    local tMissionList     = self:getViewMissionListByType()
    local function funInit(nodeBar, tMissionInfo)
        self:initMissionBar(nodeBar, tMissionInfo)
        return true
    end  

    local function funReInit(nodeBar, tMissionInfo)
        if nodeBar.nPercentComplete == tMissionInfo.percent then return end
        self:initPercentComplete(nodeBar, tMissionInfo)
    end

    local tParam      = {
        scrollView    = scrollView,
        barBase       = self._baseMissionBar,
        dataList      = tMissionList,
        funInit       = funInit,
        funReInit     = funReInit,
        oneBatchCount = 4,
        isCutIn       = isCutIn,
        slideControl  = slideView}
    KUtil.batchAddScrollView(tParam)
end

function KUIMissionListNode:refreshExtend()
    local tMissionList     = self:getViewMissionListByType()
    if #tMissionList <= 0 then
        showNoticeByID("mission.noExtend")
        return
    end
    assert(#tMissionList <= EXTEND_MISSION_COUNT)
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local animationContent = imageControl:getChildByName("ProjectNode_rw_content")
    local animationExtend  = imageControl:getChildByName("ProjectNode_rw_extend")
    animationContent:setVisible(false)
    animationExtend:setVisible(true)
    KUtil.playEnterAnimation(self._animationExtend)
    local panel1           = animationExtend:getChildByName("Panel_1")
    local imageBase        = panel1:getChildByName("Image_mission_extend_base")
    local panel2           = imageBase:getChildByName("Panel_1")
    local animationExtendContent = panel2:getChildByName("ProjectNode_mission_2")
    
    local panelButton      = panel1:getChildByName("Panel_button")
    local nType = tMissionList[1].config.nType - self._nType + 1
    local nIndex = 1
    while true do
        local buttonType = panelButton:getChildByName("Button_mission_type_" .. nIndex)
        if not buttonType then break end
        local text1 = buttonType:getChildByName("Text_mission_type_1")
        local text2 = buttonType:getChildByName("Text_mission_type_2")
        local bType = (nType == nIndex)
        text1:setVisible(not bType)
        text2:setVisible(bType)
        if bType then
            buttonType:loadTextures(m_BouttonTexture["press"], m_BouttonTexture["normal"], m_BouttonTexture["disable"])
        else
            buttonType:loadTextures(m_BouttonTexture["normal"], m_BouttonTexture["press"], m_BouttonTexture["disable"])
        end
        nIndex = nIndex + 1
    end

    local nOpenIndex = 1
    for i = 1, EXTEND_MISSION_COUNT do
        local panel     = animationExtendContent:getChildByName("Panel_" .. i)
        local panelBase = panel:getChildByName("Panel_mission_content")
        if tMissionList[i] then
            panel:setVisible(true)
            local tMissionConfig = tMissionList[i].config
            local nMissionID     = tMissionConfig.nID
            local tOneMission    = KUtil.getMission(nMissionID)
            local buttonTitle    = panelBase:getChildByName("Button_mission")
            local textNumero     = buttonTitle:getChildByName("Text_mission_number") 
            textNumero:setString(string.format(KUtil.getStringByKey("mission.numero"), tMissionConfig.nNumero))

            local nIndex = i
            local function onUnitClick(sender, type)
                if ccui.TouchEventType.ended ~= type then return end
                if nOpenIndex == nIndex then return end
                nOpenIndex = nIndex
                if nIndex == 1 then
                    KUtil.animationGotoFrameAndPlay(self._animationExtendContent, 44, 60, false)
                else
                    KUtil.animationGotoFrameAndPlay(self._animationExtendContent, 14, 30, false)
                end
            end
            buttonTitle:addTouchEventListener(onUnitClick)


            local panelContent   = panelBase:getChildByName("Panel_content")
            local imageContent   = panelContent:getChildByName("Image_mission_content")
            local textName       = imageContent:getChildByName("Text_mission_name")
            textName:setString(tMissionConfig.szName)

            local textDescribe   = imageContent:getChildByName("Text_mission_description")
            textDescribe:setString(tMissionConfig.szDescribe)

            local textCondition  = imageContent:getChildByName("Text_mission_condition")
            textCondition:setString(tMissionConfig.szConditionDescribe)
            local textNoCompletedCondition = buttonTitle:getChildByName("Text_mission_condition")
            textNoCompletedCondition:setVisible(false)
            if tOneMission then
                textCondition:setColor(cc.c3b(59, 117, 39))
            else
                textCondition:setColor(cc.c3b(140, 43, 43))
                -- textNoCompletedCondition:setVisible(true)
                -- textNoCompletedCondition:setString(tMissionConfig.szConditionDescribe)
            end

            local textTarget     = imageContent:getChildByName("Text_mission_target")
            textTarget:setString(tMissionConfig.szObjectDescribe)

            local imageIconBase  = imageContent:getChildByName("Image_special_base")
            local panelIcon      = imageIconBase:getChildByName("Panel_mission")
            local imageIcon      = panelIcon:getChildByName("Image_mission_icon")
            imageIcon:loadTexture(BASE_PATH .. tMissionConfig.szIconPath .. ".png")

            local imageRewardBase = imageContent:getChildByName("Image_reward_base")
            local tReward         = KUtil.getRewardRandResult(tMissionConfig.nReward)
            local tItemList       = {}
            local nIconIndex      = 0
            local nMaxIconCount   = 3
            local nIndex = 1
            while true do
                local panelResource = imageRewardBase:getChildByName("Panel_resource_" .. nIndex)
                if not panelResource then break end
                local textResource = panelResource:getChildByName("Text_resource_value")
                textResource:setString(0) 
                nIndex = nIndex + 1
            end

            for i, item in ipairs(tReward) do
                local rewardType = item.nType
                local nID        = item.nID
                local nNum       = item.nNum
                if nID ~= 0 and nNum ~= 0 then
                    if rewardType == ITEM_TYPE.CURRENCY and nID ~= CURRENCY_TYPE.COIN then
                        local panelResource = imageRewardBase:getChildByName("Panel_resource_" .. (nID - 1))
                        local textResource = panelResource:getChildByName("Text_resource_value")
                        textResource:setString(nNum)
                    elseif nIconIndex < nMaxIconCount then
                        local panelItem = imageRewardBase:getChildByName("Panel_item_" .. nIconIndex + 1)
                        panelItem:setVisible(true)
                        local panelClipping = panelItem:getChildByName("Panel_reward_icon")
                        local imageItemIcon = panelClipping:getChildByName("Image_reward_icon")
                        local filePath, scaleRatio, clipping = KUtil.getRewardItemPathAndScale(item.nType, nID)
                        panelClipping:setClippingEnabled(clipping)
                        local scale = scaleRatio * 1.74
                        imageItemIcon:loadTexture(filePath)
                        imageItemIcon:setScale(scale)
                        nIconIndex = nIconIndex + 1
                    end
                    table.insert(tItemList, item)
                end
            end 

            for i = nIconIndex + 1, nMaxIconCount do
                local panelItem = imageRewardBase:getChildByName("Panel_item_" .. i)
                panelItem:setVisible(false)
            end

            local buttonGo  = imageRewardBase:getChildByName("Button_go")
            local buttonGet = imageRewardBase:getChildByName("Button_get")
            if tMissionList[i].percent >= 100 then
                buttonGo:setVisible(false)
                buttonGet:setVisible(true)
                local function onUnitClick(sender, type)
                    if ccui.TouchEventType.ended == type then
                        local tip = KUtil.CanSuperAddItems(tItemList)
                        if tip then
                            showNoticeByID(tip)
                        else
                            cclog("on mission on reward.id:%d", nMissionID)
                            require("src/network/KC2SProtocolManager"):getMissionReward(nMissionID)
                        end
                    end
                end
                buttonGet:addTouchEventListener(onUnitClick)
            else
                buttonGo:setVisible(true)
                buttonGet:setVisible(false)
                local function onUnitClick(sender, type)
                    if ccui.TouchEventType.ended == type then
                        KSound.playEffect("goForward")
                        cclog("on mission go button.id:%d", nMissionID)
                        self:close()
                        local stringBase = [[ local scene = select(1,...); scene:gotoUI(%s) ]]
                        local funcGotoUI = assert(loadstring(string.format(stringBase, tMissionList[i].config.szGotoUI)), tMissionList[i].config.szGotoUI)
                        funcGotoUI(self._parent)
                    end
                end
                buttonGo:addTouchEventListener(onUnitClick)

                KUtil.setTouchEnabledAndDisable(buttonGo, (tOneMission ~= nil))
            end

            local imageTitleBase = panelBase:getChildByName("Image_mission_name_base")
            if imageTitleBase then
                local textName = imageTitleBase:getChildByName("Text_mission_name")
                textName:setString(tMissionConfig.szName)
            end
        else
            panel:setVisible(false)
        end
    end
end

function KUIMissionListNode:refreshContent(isCutIn)
    if self._nType < MISSION_TYPE.EXTEND_JUNIOR then
        self:refreshScrollView(isCutIn)
    else
        self:refreshExtend()
    end
end

function KUIMissionListNode:removeBar(nMissionID)
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local animationContent = imageControl:getChildByName("ProjectNode_rw_content")
    local imageBase        = animationContent:getChildByName("Image_rw_base")
    local scrollView       = imageBase:getChildByName("Scrollview_mission_list")
    local nIndex = KUtil.getBarIndexFromScrollViewByID(scrollView, nMissionID)
    if nIndex then
        KUtil.removeBarFromScrollView(scrollView, nIndex)
    end
end

-- function KUIMissionListNode:refreshExtendRedPoint()
    -- local mainNode         = self._mainLayout
    -- local imageControl     = mainNode:getChildByName("Image_common_base") 
    -- local nodeButtonAnimation = imageControl:getChildByName("ProjectNode_rw_button")
    -- local imageBase        = nodeButtonAnimation:getChildByName("Image_label_base")
    -- local panelButton      = imageBase:getChildByName("Panel_button")
    -- local buttonExtend     = panelButton:getChildByName("Button_mission_6")
    -- local imageRed1        = buttonExtend:getChildByName("Image_button_1")
    -- local nodeRed1         = imageRed1:getChildByName("ProjectNode_notice")
    -- local imageRed2        = buttonExtend:getChildByName("Image_button_2")
    -- local nodeRed2         = imageRed2:getChildByName("ProjectNode_notice")
    -- nodeRed1:setVisible(self._isExtrndRed)
    -- nodeRed2:setVisible(self._isExtrndRed)
-- end

function KUIMissionListNode:refreshButton()
    local nBeginFrame = BUTTON_LIST_ENTER_END_FRAME + ONE_BUTTON_FRAME_LEN * self._nType + ONE_BUTTON_ENTER_BEGIN_FRAME
    self._animationButton:gotoFrameAndPlay(nBeginFrame, nBeginFrame + ONE_BUTTON_MOVE_LEN, false) 

    -- self:refreshExtendRedPoint()
end

function KUIMissionListNode:enterAnimation()
    KUtil.playEnterAnimation(self._animationHome)
    KUtil.playEnterAnimation(self._animationResource)
    KUtil.playEnterAnimation(self._animationButton)
    KUtil.playEnterAnimation(self._animationContent)
end

function KUIMissionListNode:quitAnimation(isReturnOffice)
    local delayTime1 = KUtil.playQuitAnimation(self._animationHome)
    local delayTime2 = KUtil.playQuitAnimation(self._animationResource)
    local delayTime3 = KUtil.playQuitAnimation(self._animationButton, BUTTON_LIST_QUIT_BEGIN_FRAME, BUTTON_LIST_QUIT_END_FRAME)
    local delayTime4 = KUtil.playQuitAnimation(self._animationContent)
    local delayTime  = math.max(delayTime1, delayTime2, delayTime3, delayTime4)
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Mission", callBacks, isReturnOffice)
end

function KUIMissionListNode:initData()
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local animationContent = imageControl:getChildByName("ProjectNode_rw_content")
    local imageBase        = animationContent:getChildByName("Image_rw_base")
    local scrollView       = imageBase:getChildByName("Scrollview_mission_list")
    local imageMissionBar  = scrollView:getChildByName("Image_mission_unit_base")
    self._baseMissionBar   = imageMissionBar:clone()
    self._baseMissionBar:setVisible(false)
    self._baseMissionBar:retain()
    scrollView:removeAllChildren()

    local function closeCallBack(isReturnOffice)
        self:quitAnimation(isReturnOffice)
    end
    self._animationHome, self._animationResource = KUtil.initHomeAndResourceNode(self, closeCallBack, "rw_base")

    local nodeButtonAnimation = imageControl:getChildByName("ProjectNode_rw_button")
    self._animationButton     = KUtil.initAnimation(nodeButtonAnimation, "res/ui/animation_node/ani_mission_button_left.csb")

    local nodeContentAnimation = imageControl:getChildByName("ProjectNode_rw_content")
    self._animationContent     = KUtil.initAnimation(nodeContentAnimation, "res/ui/animation_node/ani_mission_content.csb")

    local nodeExtendAnimation = imageControl:getChildByName("ProjectNode_rw_extend")
    assert(nodeExtendAnimation)
    self._animationExtend     = KUtil.initAnimation(nodeExtendAnimation, "res/ui/animation_node/ani_mission_extend.csb")

    local panel1                 = nodeExtendAnimation:getChildByName("Panel_1")
    local imageBase              = panel1:getChildByName("Image_mission_extend_base")
    local panel2                 = imageBase:getChildByName("Panel_1")
    local nodeExtendContentAnimation = panel2:getChildByName("ProjectNode_mission_2")
    assert(nodeExtendContentAnimation)
    self._animationExtendContent = KUtil.initAnimation(nodeExtendContentAnimation, "res/ui/animation_node/ani_mission_extend_content.csb")

    self._viewMissionList = self:getViewMissionList()
end

function KUIMissionListNode:activate(nowTime)
    if nowTime ~= self._nowTime then
        self._nowTime = nowTime
    end
end

function KUIMissionListNode:onInitUI()
    self:initData()
end

function KUIMissionListNode:refreshUI()
    self:refreshContent(false)
end

function KUIMissionListNode:onEnterActionFinished()
    self:enterAnimation()
    self:refreshButton()
end

function KUIMissionListNode:registerAllTouchEvent()
    local mainNode         = self._mainLayout
    local imageControl     = mainNode:getChildByName("Image_common_base")
    local animationContent = imageControl:getChildByName("ProjectNode_rw_content")
    local imageBase        = animationContent:getChildByName("Image_rw_base")
    local scrollControl    = imageBase:getChildByName("Scrollview_mission_list")
    local slideControl     = imageBase:getChildByName("Slider_scroll")

    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)

    local nodeButtonAnimation = imageControl:getChildByName("ProjectNode_rw_button")
    local imageButtonAnimationBase = nodeButtonAnimation:getChildByName("Image_label_base")
    local panelButton         = imageButtonAnimationBase:getChildByName("Panel_button")
    local nIndex = 1
    while true do
        local buttonType = panelButton:getChildByName("Button_mission_" .. nIndex)
        if not buttonType then return end
        local i = nIndex - 1
        local function onSelectType(sender, type)
            if type ~= ccui.TouchEventType.ended then return end
            if i == self._nType then return end
            self._nType = i
            cclog("click onSelectType~ %d", i)
            self:refreshButton()
            self:refreshContent(false)
        end
        buttonType:addTouchEventListener(onSelectType)
        nIndex = nIndex + 1
    end
end

function KUIMissionListNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    
    local function delayRefresh()
        self._isWaitRefresh = false
        self._viewMissionList = self:getViewMissionList()
        self:refreshContent(false)
    end
    local function onUpdateMission(nMissionID)
        cclog("onEvent ---------->onMissionFinish", self._isWaitRefresh)
        if self._isWaitRefresh then return end
        self._isWaitRefresh = true
        delayExecute(self, delayRefresh, 1)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_MISSION, onUpdateMission)

    local function onGetReward(nMissionID)
        local tGetMissionConfig = KUtil.getMissionConfig(nMissionID)
        if tGetMissionConfig.nNumero == 0 then
            HArray.RemoveFirst(self._viewMissionList.common, "config", tGetMissionConfig)
            self:removeBar(nMissionID)
            if self._isWaitRefresh then return end
            self._isWaitRefresh = true
            delayExecute(self, delayRefresh, 1)
        else
            HArray.RemoveFirst(self._viewMissionList.extend, "config", tGetMissionConfig)
            self._viewMissionList = self:getViewMissionList()
            self:refreshExtend()
            -- self:refreshExtendRedPoint()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_GET_MISSION_REWARD, onGetReward)
end

function KUIMissionListNode:onCleanup()
    self._baseMissionBar:release() 
end

return KUIMissionListNode
