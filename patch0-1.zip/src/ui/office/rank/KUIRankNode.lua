--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRankNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/14   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_nTopBackGroundNumber = 3
local m_nCheckInterval       = 20
local m_nScoreFactor         = 1000
local m_nLoadingTimeOut      = 10
local m_nWordLimit           = 55
local m_nShowSize            = 4.5
local m_nNextOffset          = 4.5
local m_nPreviewOffset       = 0.9 
local m_nKeepSize            = 10

local m_nTopBackGroundTextures= {
    [1] = {"res/ui/ui_material/ranking/ph_1st.png","res/ui/ui_material/ranking/ph_number1_dialog.png",},
    [2] = {"res/ui/ui_material/ranking/ph_2nd.png","res/ui/ui_material/ranking/ph_number2_dialog.png",},
    [3] = {"res/ui/ui_material/ranking/ph_3rd.png","res/ui/ui_material/ranking/ph_number3_dialog.png",},
}

local m_nRowBackGroundTextures= {
    [0] = "res/ui/ui_material/ranking/ph_unit_base.png",
    [1] = "res/ui/ui_material/ranking/ph_unit_base_2.png",
}
local KUIRankNode = class(
    "KUIRankNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRankNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._baseControl    = nil
    self._pageSize       = 30
    self._pageCount      = 1
    self._pageIndex      = 1
    self._lastPageIndex  = 1
    self._allCount       = 0
    self._isLoading      = false
    self._isNewPage      = false
    self._isScrollTouch  = false
    self._beginTimes     = 0
    self._endTimes       = 0
    self._updateTimes    = 0
    self._lastLoadintime = 0
    self._loadingBar     = nil
    self._lastStartRank  = 0
    self._lastEndRank    = 0
end

function KUIRankNode.create(owner)
    local currentNode = KUIRankNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_ranking.csb"
    currentNode:init()

    return currentNode
end

local function playRankAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommonBase:getChildByName("ProjectNode_ranking")

    local openEndFrame    = 30
    local closeStartFrame = 60
    local animationName   = "ani_ranking_content"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playRankAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Rank", callBacks, isReturnOffice)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommonBase:getChildByName("ProjectNode_ranking")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function checkRequestNewData(self)
    if not (KPlayer.tRankData.tRoleRank and KPlayer.tRankData.tRankList) then
        return true
    end
    local nextUpdateTime = KPlayer.tRankData.nNextUpdateTime
    local nextMonthEndTime = KPlayer.tRankData.nNextMonthEndTime
    
    local currentServerTime = KUtil.getCurrentServerTime()
    if nextUpdateTime < currentServerTime or nextMonthEndTime < currentServerTime then
        return true
    end
    return false
end

local function calculatePageDetail(self, pageIndex, allCount)
    self._pageIndex = pageIndex
    self._allCount  = allCount
    self._pageCount = math.floor((allCount - 1)/self._pageSize) + 1
end

local function openPanelRequest(self)
    local isRequestNewData = checkRequestNewData(self)
    if isRequestNewData then
        KPlayer.tRankData = {}
        require("src/network/KC2SProtocolManager"):requestRoleRankData()
        require("src/network/KC2SProtocolManager"):requestRankPageData(self._pageIndex, self._pageSize)
    end
    calculatePageDetail(self, self._pageIndex, (KPlayer.tRankData.nCount or 0))
end

local function getPageData(self, pageIndex)
    local percert = 0
    local pageDataLIst = {}
    local startNum = (pageIndex - 1) * self._pageSize + 1
    local endNum   = startNum + self._pageSize - 1
    if not KPlayer.tRankData.tRankList then
        return pageDataLIst
    end
    --next page
    if self._lastPageIndex < pageIndex then
        local startNum, endNum = startNum - m_nKeepSize, startNum - 1
        for rankIndex = startNum, endNum do
            local rankData = KPlayer.tRankData.tRankList[rankIndex]
            if rankData then table.insert(pageDataLIst, rankData) end
            if not rankData then break end
        end
    end
    --current page
    for rankIndex = startNum, endNum do
        local rankData = KPlayer.tRankData.tRankList[rankIndex]
        if rankData then table.insert(pageDataLIst, rankData) end
        if not rankData then break end
    end
    --previou page
    if self._lastPageIndex > pageIndex then
        local startNum, endNum = endNum + 1, endNum + m_nKeepSize
        for rankIndex = startNum, endNum do
            local rankData = KPlayer.tRankData.tRankList[rankIndex]
            if rankData then table.insert(pageDataLIst, rankData) end
            if not rankData then break end
        end
    end
    return pageDataLIst
end

local function getRankScoreFormat(score)
    return math.floor(score / m_nScoreFactor)
end

local function setLoadingVisible(self, isVisible)
    if not self._loadingBar then return end
    self._loadingBar:setVisible(isVisible)
end

local function initUI(self)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local rankProjectNode = imageCommonBase:getChildByName("ProjectNode_ranking")
    local rankPanelBase   = rankProjectNode:getChildByName("Image_ph_base")
    local scrollControl   = rankPanelBase:getChildByName("ScrollView_ranking_list")
    self._baseControl     = scrollControl:getChildByName("Image_ph_gear_base")
    self._baseControl:retain()

    scrollControl:removeAllChildren()
    
    for i = 1, m_nKeepSize + self._pageSize do
        local node = self._baseControl:clone()
        node:setVisible(false)
        node:setName("0")
        scrollControl:addChild(node)
    end

    self._loadingBar = cc.CSLoader:createNode("res/ui/animation_node/ani_loading.csb")
    mainNode:addChild(self._loadingBar)
    self._loadingBar:setVisible(false)
end

local function refreshRankReward(self)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local rankProjectNode = imageCommonBase:getChildByName("ProjectNode_ranking")
    local rankPanelBase   = rankProjectNode:getChildByName("Image_ph_base")
    local buttonReward    = rankPanelBase:getChildByName("Button_reward")

    local haveReward = KUtil.checkRankRedPoint()
    buttonReward:setVisible(haveReward)
end

local function refreshRoleDetail(self)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local rankProjectNode = imageCommonBase:getChildByName("ProjectNode_ranking")
    local rankPanelBase   = rankProjectNode:getChildByName("Image_ph_base")
    local panelControl    = rankPanelBase:getChildByName("Panel_me_data")
    
    local textRanking = panelControl:getChildByName("Text_me_ranking")
    textRanking:setString("0")

    local textName = panelControl:getChildByName("Text_me_name")
    textName:setString(KUtil.getStringByKey("common.nothing"))

    local textTitle = panelControl:getChildByName("Text_me_title")
    textTitle:setString(KUtil.getRoleRankName())

    local textMilitary = panelControl:getChildByName("Text_me_military")
    textMilitary:setString("0")

    local leaderCard     = KUtil.getTeamLeaderCard(1)
    local cardHeadPath   = KUtil.getScaleCardImagePath(leaderCard)
    local imageCharacter = panelControl:getChildByName("Image_my_chara")
    imageCharacter:loadTexture(cardHeadPath)

    if not KPlayer.tRankData.tRoleRank then return end
    local roleName = KPlayer.tRankData.tRoleRank.name
    textName:setString(roleName)
    
    if KPlayer.tRankData.tRoleRank.enter == 0 then return end
    local roleRank = KPlayer.tRankData.tRoleRank.nRank
    local roleScore = KPlayer.tRankData.tRoleRank.lastscore
    textRanking:setString(roleRank)
    textMilitary:setString(getRankScoreFormat(roleScore))
end

local function updateScrollRank(self, newControl, rankInfo)
    if not rankInfo then
        newControl:setVisible(false)
        return
    end
    --update rank number
    local panelRankNumber = newControl:getChildByName("Panel_ph_rank")
    local imageRankNumber = panelRankNumber:getChildByName("Image_ph_1st")
    local textRank        = newControl:getChildByName("BitmapFontLabel_list_number")
    panelRankNumber:setVisible(false)
    textRank:setVisible(false)
    if rankInfo.nRank > m_nTopBackGroundNumber then
        textRank:setVisible(true)
        textRank:setString(rankInfo.nRank)
    else
        panelRankNumber:setVisible(true)
        local backGroundTexture = m_nTopBackGroundTextures[rankInfo.nRank][1]
        imageRankNumber:loadTexture(backGroundTexture)
    end
    --update rank name
    local textPlayerName  = newControl:getChildByName("Text_player_name")
    textPlayerName:setString(rankInfo.name)

    --update rank title
    local percert  = rankInfo.nRank/KPlayer.tRankData.nCount
    local rankName = KUtil.getRankName(percert)
    local textPlayerTitle  = newControl:getChildByName("Text_player_ranking")
    textPlayerTitle:setString(rankName)

    --update score
    local textPlayerScore = newControl:getChildByName("Text_player_value")
    textPlayerScore:setString(getRankScoreFormat(rankInfo.lastscore))
    
    --update msg
    local imageDialog = newControl:getChildByName("Image_ph_dialog")
    local textMessage = imageDialog:getChildByName("Text_player_message")
    textMessage:setString(KUtil.shortString(rankInfo.message, m_nWordLimit))
    if rankInfo.nRank <= m_nTopBackGroundNumber then
        local backGroundTexture = m_nTopBackGroundTextures[rankInfo.nRank][2]
        imageDialog:loadTexture(backGroundTexture)
    else
        imageDialog:loadTexture("res/ui/ui_material/ranking/ph_number_dialog.png")
    end
end

local function refreshRankPage(self, isCutIn)
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local rankProjectNode = imageCommonBase:getChildByName("ProjectNode_ranking")
    local rankPanelBase   = rankProjectNode:getChildByName("Image_ph_base")
    local slideControl    = rankPanelBase:getChildByName("Slider_scroll")
    local scrollControl   = rankPanelBase:getChildByName("ScrollView_ranking_list")

    scrollControl:setEnabled(false)

    local showListData = getPageData(self, self._pageIndex)
    local contentSize = scrollControl:getContentSize()
    local itemSize    = self._baseControl:getContentSize()
    local positionX   = (contentSize.width - itemSize.width) / 2

    local allHeight = itemSize.height * #showListData
    if allHeight < contentSize.height then allHeight = contentSize.height end
    scrollControl:setInnerContainerSize(cc.size(contentSize.width, allHeight))
    scrollControl:jumpToTop()
    
    local itemList = scrollControl:getChildren()
    for index = 1, m_nKeepSize + self._pageSize do
        local node     = itemList[index]
        local nodeData = showListData[index]
        node:setVisible(false)
        if nodeData then
            node:setVisible(true)
            node:setAnchorPoint(0, 0)
            local positionY = allHeight - index * itemSize.height
            node:setPosition(cc.p(positionX, positionY))
            updateScrollRank(self, node, nodeData)
        end
    end
    scrollControl:setEnabled(true)

    local currentPage    = self._pageIndex
    local lastPage       = self._lastPageIndex
    local listSize       = #showListData
    local lastStartRankIndex, lastEndRankIndex  = 0, 0
    for index, rankInfo in ipairs(showListData) do
        if rankInfo.nRank == self._lastStartRank then
            lastStartRankIndex = index
        end
        if rankInfo.nRank == self._lastEndRank then
            lastEndRankIndex   = index
        end
    end

    local callBack = function()
        local percert, percertRadix, showListSize = 0, 100, m_nShowSize
        if lastPage < currentPage and listSize > self._pageSize then
            percert = (lastEndRankIndex - m_nNextOffset) * percertRadix/(listSize - showListSize)
        elseif lastPage > currentPage and listSize > self._pageSize then
            percert = (lastStartRankIndex - m_nPreviewOffset) * percertRadix/(listSize - showListSize)
        end
        if percert < 0 then percert = 0 end
        if percert > percertRadix then percert = percertRadix end
        scrollControl:jumpToPercentVertical(percert)
        slideControl:setPercent(percert)
    end
    delayExecute(scrollControl, callBack, 0)
    self._lastStartRank  = 0
    self._lastEndRank    = 0
    if #showListData > 0 then
        self._lastStartRank  = showListData[1].nRank
        self._lastEndRank    = showListData[#showListData].nRank
    end
    self._lastPageIndex = self._pageIndex
end

local function checkNewPageData(self)
    if not KPlayer.tRankData.tRankList then
        return
    end
    local startNum = (self._pageIndex - 1) * self._pageSize + 1
    local rankData = KPlayer.tRankData.tRankList[startNum]
    if rankData then 
        self._isNewPage = true
        setLoadingVisible(self, true)
    else
        require("src/network/KC2SProtocolManager"):requestRankPageData(self._pageIndex, self._pageSize)
        self._lastLoadintime = os.time()
        self._isLoading = true
        setLoadingVisible(self, self._isLoading)
    end
end

local function changeToPreviouPage(self)
    if self._isLoading then return end
    if self._isScrollTouch then return end
    self._pageIndex = self._pageIndex - 1
    if self._pageIndex < 1 then 
        self._pageIndex = 1 
    end
    checkNewPageData(self)
end

local function changeToNextPage(self)
    if self._isLoading then return end
    if self._isScrollTouch then return end
    self._pageIndex = self._pageIndex + 1
    if self._pageIndex > self._pageCount then 
        self._pageIndex = self._pageCount 
    end
    checkNewPageData(self)
end

function KUIRankNode:activate(nowTime)
    self._updateTimes = self._updateTimes + 1
    if self._isNewPage then
        self._isNewPage = false
        setLoadingVisible(self, false)
        if self._lastPageIndex == self._pageIndex then return end
        refreshRankPage(self, false)
    end

    if nowTime - self._lastLoadintime > m_nLoadingTimeOut then
        self._isLoading = false
        setLoadingVisible(self, self._isLoading)
    end
end

function KUIRankNode:onInitUI()
    initUI(self)
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
end

local function refreshDisable(self)
    local mainNode              = self._mainLayout
    local imageCommonBase       = mainNode:getChildByName("Image_common_base")
    local projectNodeRanking    = imageCommonBase:getChildByName("ProjectNode_ranking")
    local imageBase             = projectNodeRanking:getChildByName("Image_ph_base")
    local imagePromt1           = imageBase:getChildByName("Image_promt_1")
    imagePromt1:setVisible(false)
end

function KUIRankNode:refreshUI()
    openPanelRequest(self)
    refreshRoleDetail(self)
    refreshRankReward(self)
    refreshDisable(self)
    refreshRankPage(self, true)
end

function KUIRankNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playRankAnimation(self, true)
end

function KUIRankNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "ph_base")
    --Get Reward Button
    local mainNode        = self._mainLayout
    local imageCommonBase = mainNode:getChildByName("Image_common_base")
    local rankProjectNode = imageCommonBase:getChildByName("ProjectNode_ranking")
    local rankPanelBase   = rankProjectNode:getChildByName("Image_ph_base")
    local buttonReward    = rankPanelBase:getChildByName("Button_reward")
    local function onGetRewardClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onGetRewardClick~")
            require("src/network/KC2SProtocolManager"):requestGetRankReward()
        end
    end
    buttonReward:addTouchEventListener(onGetRewardClick)

    local slideControl  = rankPanelBase:getChildByName("Slider_scroll")
    local scrollControl = rankPanelBase:getChildByName("ScrollView_ranking_list")

    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local passTime = self._endTimes - self._beginTimes
        if type == ccui.ScrollviewEventType.scrolling then
            local percent = KUtil.getScrollViewPercent(scrollControl)
            slideControl:setPercent(percent)
        elseif type == ccui.ScrollviewEventType.scrollToTop then
            if passTime >= m_nCheckInterval then
                changeToPreviouPage(self)
            end
        elseif type == ccui.ScrollviewEventType.scrollToBottom then
            if passTime >= m_nCheckInterval then
                changeToNextPage(self)
            end
        end
    end
    scrollControl:setSwallowTouches(false)
    scrollControl:addEventListener(onScrollChange)

    local function onScrollTouch(sender, type)
        if type == ccui.TouchEventType.began then
            self._isScrollTouch = true
            self._beginTimes    = self._updateTimes
            self._endTimes      = self._updateTimes
        elseif type == ccui.TouchEventType.ended then
            self._isScrollTouch = false
            self._endTimes      = self._updateTimes
        elseif type == ccui.TouchEventType.canceled then
            self._isScrollTouch = false
            self._endTimes      = self._updateTimes
        end
    end
    scrollControl:addTouchEventListener(onScrollTouch)
end

function KUIRankNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRoleRankDetail(tRoleRankData, nNextUpdateTime, nCount)
        refreshRoleDetail(self)
        refreshRankReward(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_ROLE_RANK, onRoleRankDetail)

    local function onRefeshRankPage(nPageIndex, nPageSize, nCount, tRankList)
        cclog("onEvent ------------> onRefeshRankPage")
        self._isLoading = false
        setLoadingVisible(self, self._isLoading)
        calculatePageDetail(self, nPageIndex, nCount)
        refreshRankPage(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_PAGE_RANK, onRefeshRankPage)

    local function onGetReward(nRoleID, nRewardID, tResultList)
        cclog("onEvent ------------> onGetReward")
        if nRewardID == 0 then return end
        local userData = {tResultList = tResultList,}
        self._parent:addNode("Reward", userData)
        refreshRankReward(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RANK_REWARD, onGetReward)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIRankNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIRankNode:onCleanup()
    self._baseControl:release() 
end

return KUIRankNode
