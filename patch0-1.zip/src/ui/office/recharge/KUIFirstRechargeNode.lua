--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFirstRechargeNode.lua
--  Creator     : Jiang Xufeng
--  Date        : 2016/3/22   18:46
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local RESOURCE_COUNT = 4
local FIRST_RECHARGE_REWARDID = 491
local KUIFirstRechargeNode = class(
    "KUIFirstRechargeNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFirstRechargeNode:ctor()
    self._mainLayout = nil
    self._parent     = nil
    self._uiPath     = nil
end

function KUIFirstRechargeNode.create(owner)
    local currentNode = KUIFirstRechargeNode.new()

    currentNode._parent   = owner
    currentNode._uiPath   = "res/ui/layout_first_charge.csb"
    currentNode:init()

    return currentNode
end

local function getFrameAction(self, startFrame, endedFrame)
    local duration   = (endedFrame - startFrame) / 60

    local function callAnimation()
        local mainNode = self._mainLayout
        local projectNode = mainNode:getChildByName("ProjectNode_first")
        local actionName = "ani_first_charge"
        KUtil.playAnimation(projectNode,  actionName, startFrame, endedFrame)
    end
    
    local callAction  = cc.CallFunc:create(callAnimation)
    local frameDelay  = cc.DelayTime:create(duration)
    local frameAction = cc.Sequence:create(callAction, frameDelay)

    return frameAction, duration
end

function KUIFirstRechargeNode:getEnterAction()
    local startFrame = 0
    local endedFrame = 26
    local enterAction, duration = getFrameAction(self, startFrame, endedFrame)
    return enterAction, duration
end

function KUIFirstRechargeNode:getExitAction()
    local startFrame = 50
    local endedFrame = 65
    local exitAction, duration = getFrameAction(self, startFrame, endedFrame)
    return exitAction, duration
end

local function getItemData()
    local rewardInfo = KConfig.reward[FIRST_RECHARGE_REWARDID]
    if not rewardInfo then 
        cclog("reward id not found id is:" .. FIRST_RECHARGE_REWARDID)
    end
    local feeling      = nil
    local ringInfo     = nil
    local cardInfo     = nil
    local resourceInfo = {}
    for _, itemInfo in ipairs(rewardInfo.tList) do
        if itemInfo.nType == ITEM_TYPE.CURRENCY then
            table.insert(resourceInfo, itemInfo)
        elseif itemInfo.nType == ITEM_TYPE.CARD then
            cardInfo = itemInfo
        elseif itemInfo.nType == ITEM_TYPE.OTHER then
            local itemConfig = KConfig.itemInfo[itemInfo.nID]
            if itemConfig.nType == ITEM_SMALL_TYPE.RING then
                ringInfo = itemInfo
            elseif itemConfig.nType == ITEM_SMALL_TYPE.FEELING then
                feeling = itemInfo
            end
        end
    end
    return feeling, ringInfo, cardInfo, resourceInfo
end

local function refreshOneItem(self, itemInfo, index)
    local mainNode          = self._mainLayout
    local projcetNodeFirst  = mainNode:getChildByName("ProjectNode_first")
    local imageBase         = projcetNodeFirst:getChildByName("Image_base")
    local imageSignBase     = imageBase:getChildByName("Image_sign_base")
    local itemPanel         = imageSignBase:getChildByName("Image_frame_" .. index)
    local iconPanel         = itemPanel:getChildByName("Panel_icon")
    local imageIcon         = iconPanel:getChildByName("Image_icon")

    local textNumber = itemPanel:getChildByName("Text_number")
    if itemInfo then
        local itemPath, scale = KUtil.getRewardItemPathAndScale(itemInfo.nType, itemInfo.nID)
        imageIcon:loadTexture(itemPath)
        imageIcon:setScale(scale)
        textNumber:setString(tostring(itemInfo.nNum))
    else
        textNumber:setString("0")
        imageIcon:setVisible(false)
    end
end

local function refreshItem(self)
    local mainNode          = self._mainLayout
    local projcetNodeFirst  = mainNode:getChildByName("ProjectNode_first")
    local imageBase         = projcetNodeFirst:getChildByName("Image_base")
    local imageSignBase     = imageBase:getChildByName("Image_sign_base")
    local feeling, ringInfo, cardInfo, resourceInfo = getItemData()
    -- update resource
    for i = 1, RESOURCE_COUNT do
        local itemInfo = resourceInfo[i]
        refreshOneItem(self, itemInfo, i)
    end

    -- update ring
    local ringIndex = 5
    refreshOneItem(self, ringInfo, ringIndex)
    
    -- update feeling
    local feelingIndex = 6
    refreshOneItem(self, feeling, feelingIndex)
end

function KUIFirstRechargeNode:refreshUI()
    refreshItem(self)
end

function KUIFirstRechargeNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local projcetNodeFirst  = mainNode:getChildByName("ProjectNode_first")
    local imageBase         = projcetNodeFirst:getChildByName("Image_base")
    --Close Button
    local imageSignBase     = imageBase:getChildByName("Image_sign_base")
    local buttonControl     = imageSignBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            self._parent:removeNode("FirstRecharge")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local buttonFirstControl = imageSignBase:getChildByName("Button_first_charge")
    local function onRechargeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("click")
            self._parent:removeNode("FirstRecharge")
            self._parent:addNode("Shop")
        end
    end
    buttonFirstControl:addTouchEventListener(onRechargeClick)
end

local function stopAllAnimation(self)
    local mainNode          = self._mainLayout
    local projectNodeFirst  = mainNode:getChildByName("ProjectNode_first")
    projectNodeFirst:stopAllActions()
end

function KUIFirstRechargeNode:onInitUI()
    stopAllAnimation(self)
end

return KUIFirstRechargeNode
