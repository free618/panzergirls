--  *********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairNode.lua
--  Creator     : Jiang xufeng
--  Date        : 2016/03/20 10:00  
--  Contact     : jiangxufeng@kingsoft.com
--  Comment     :
--  *********************************************************************


local ENUM_FACTORY_STATUS = {
    unused  = 1,
    empty   = 2,
    working = 3
}

local m_tButtonHighSpeedTextures = {
    ["buttonNormalTexture"]   = "res/ui/ui_material/repair/xl_highspeed.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/repair/xl_highspeed_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/repair/xl_highspeed_disable.png"
}

local MAX_SCALE                     = 100
local REPAIR_NUMBER                 = 4
local HIGHSPEED_ITEM                = 5
local INIT_TIME_STRING              = "00:00:00"
local TEXT_DATA_DELAY_TIME          = 0.1
local MAX_REPAIR_BAR_COUNT          = 4
local ANIMATION_START_FRAME         = 0
local CURRENT_MAX_REPAIR_WORK_COUNT = 2
local FPS                           = 60
local EXPAND_REPAIR_BAR_ID          = 16
local ONE_BUTTON_FRAME_LEN          = 40
local ONE_BUTTON_ENTER_BEGIN_FRAME  = 0
local ONE_BUTTON_QUIT_BEGIN_FRAME   = 13
local ONE_BUTTON_MOVE_LEN           = 7
local BUTTON_LIST_ENTER_BEGIN_FRAME = 0
local BUTTON_LIST_ENTER_END_FRAME   = 15
local BUTTON_LIST_QUIT_BEGIN_FRAME  = 130
local BUTTON_LIST_QUIT_END_FRAME    = 146

local m_tPageNodeList = {
    ProjectNode_xl      = {page = 1},
    ProjectNode_supply  = {class = "KUIRepairSupplyNode", page = 2},
    ProjectNode_reborn  = {class = "KUIRepairRebornNode", page = 3}
}

local KUIRepairNode = class (
    "KUIRepairNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRepairNode:ctor()
    self._carAction     = {}
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
    self._highSpeedflag = nil
    self._viewNodeName  = "ProjectNode_xl"
    self._animationList         = {}
    self._KUINodePageList       = {}
    self._animationRepairList   = nil
    self._animationHome         = nil
    self._animationResource     = nil
    self._animationButton       = nil
    self._showLoading           = true
end

function KUIRepairNode.create(owner, szNodeName)
    local currentNode           = KUIRepairNode.new()
    
    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_repair.csb"
    currentNode._highSpeedflag  = true
    if szNodeName then
        currentNode._viewNodeName = szNodeName
    end
    currentNode:init()
    
    return currentNode
end

local function getRepairPosition(position)
    if KPlayer.nRepairBarNum < position  then 
        return ENUM_FACTORY_STATUS.unused
    else
        local repairingList     = KPlayer.tCardData.tRepairingList
        local oneRepairFactory  = HArray.FindFirst(repairingList, "nRepairPosition", position)
        if oneRepairFactory then 
            return ENUM_FACTORY_STATUS.working 
        else
            return ENUM_FACTORY_STATUS.empty
        end
    end
end

local function updateHeadUIByIndex(self, imageUnitWorking, repairPosition)
    -- get cardf information
    local repairList    = KPlayer.tCardData.tRepairingList
    local repairOneCard = HArray.FindFirst(repairList, "nRepairPosition", repairPosition) 
    if not repairOneCard then return end
    local cardList      = KPlayer.tCardData.tStoreHouse.tCardList
    local cardData      = HArray.FindFirst(cardList, "nID", repairOneCard.nCardID)

    -- set card exp
    local cardExp           = cardData.nCurrentExp
    local cardMaxExp        = KConfig["levelInfo"][cardData.nLevel]["nCardExp"]
    local cardPercentExp    = cardExp / cardMaxExp * MAX_SCALE
    local loadingBarExp     = imageUnitWorking:getChildByName("LoadingBar_common_exp")
    loadingBarExp:setPercent(cardPercentExp)
    
    -- set card level
    local cardLevel         = cardData.nLevel
    local textLevelValue    = imageUnitWorking:getChildByName("Text_level_value")
    textLevelValue:setString(cardLevel)
    
    -- set card HP
    local cardCurrentHP = cardData.nCurrentHP 
    local cardMaxHP     = KUtil.getCardMaxHp(cardData)
    local cardPercentHP = cardCurrentHP / cardMaxHP * MAX_SCALE
    local textHPValue   = imageUnitWorking:getChildByName("Text_hp_value")
    textHPValue:setString(cardCurrentHP .. "/" .. cardMaxHP)

    local hpName    = {"LoadingBar_xl_hp_green", "LoadingBar_xl_hp_yellow", "LoadingBar_xl_hp_orange", "LoadingBar_xl_hp_red", nil}
    local stateName = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
    KUtil.drawCardState(imageUnitWorking, imageUnitWorking, hpName, stateName, cardPercentHP)

    local cardLevel       = cardData.nLevel
    local labelLevel      = imageUnitWorking:getChildByName("Text_level_value")
    labelLevel:setString(cardLevel)

    local imageHead       = imageUnitWorking:getChildByName("ProjectNode_card")
    KUtil.onlyUpdateCardHeadBase(imageHead, cardData)

    local cardExp         = cardData.nCurrentExp
    local cardMaxExp      = KConfig["levelInfo"][cardData.nLevel]["nCardExp"]
    local cardExpPercent  = cardExp / cardMaxExp * 100
    local expBarLoading   = imageUnitWorking:getChildByName("LoadingBar_common_exp")
    expBarLoading:setPercent(cardExpPercent)
end

local function getLeftTimeByIndex(self, index)
    local repairList        = KPlayer.tCardData.tRepairingList
    local repairPosition    = HArray.FindFirst(repairList, "nRepairPosition", index)
    
    if not repairPosition then return INIT_TIME_STRING end
    
    local endTime           = repairPosition.nEndTime
    local nowTime           = KUtil.getCurrentServerTime()
    local leftTime          = endTime - nowTime
    
    if leftTime <= 0 then leftTime = 0 end
    
    local hour  = math.floor(leftTime / (60 * 60))
    local min   = math.floor(leftTime / 60 % 60)
    local sec   = math.floor(leftTime % 60)
    
    local leftTimeString = string.format("%02d:%02d:%02d", hour, min, sec)
    return leftTimeString
end

local function highSpeedItemCount()
    local highList              = KPlayer.tItemData.tStoreHouse.tItemList
    local itemID                = HArray.FindFirst(highList, "nTemplateID", HIGHSPEED_ITEM)
    local highSpeedItemCount    = 0   
    
    if itemID then highSpeedItemCount = itemID.nCount end
    
    return highSpeedItemCount
end

local function actionControl(self, repairPosition, imageRepairPage) 
    if not self._carAction then self._carAction = {} end
    if not self._carAction[repairPosition] then self._carAction[repairPosition] = {} end
    
    local panelCarAnimation         = imageRepairPage:getChildByName("Panel_carRegion")
    local projectNodeCarAnimation   = panelCarAnimation:getChildByName("ProjectNode_ani_car")
    local repairCarAction           = cc.CSLoader:createTimeline("res/ui/animation_node/ani_repair_car.csb")
    projectNodeCarAnimation:setVisible(true)
    projectNodeCarAnimation:stopAllActions()
    repairCarAction:gotoFrameAndPlay(ANIMATION_START_FRAME, true) 
    projectNodeCarAnimation:runAction(repairCarAction)
    self._carAction[repairPosition].carAction = repairCarAction
    
    local projectNodeCarSpeedUp     = panelCarAnimation:getChildByName("ProjectNode_car_speedup_ani")
    local speedUpRepairCarAction    = cc.CSLoader:createTimeline("res/ui/animation_node/ani_repair_car_speedup.csb")
    projectNodeCarSpeedUp:setVisible(true)
    projectNodeCarSpeedUp:stopAllActions()
    projectNodeCarSpeedUp:runAction(speedUpRepairCarAction)
    speedUpRepairCarAction:gotoFrameAndPause(ANIMATION_START_FRAME)
    self._carAction[repairPosition].speedUpRepairCarAction = speedUpRepairCarAction
end

local function updateWorkingBarInfo(self, index, imageRepairPage, imageExtendPage)
    local imageUnitWorking  = imageRepairPage:getChildByName("Image_xl_unit_working")
    local imageUnitEmpty    = imageRepairPage:getChildByName("Image_xl_unit_empty")
    local repairPosition    = index
    
    imageRepairPage:setVisible(true)
    imageExtendPage:setVisible(false)
    imageUnitWorking:setVisible(true)
    imageUnitEmpty:setVisible(false)
    
    updateHeadUIByIndex(self, imageUnitWorking, repairPosition)
    
    local textTimeLabel          = imageRepairPage:getChildByName("Text_time_data")
    local timeSequenceAction     = cc.Sequence:create(
        cc.DelayTime:create(TEXT_DATA_DELAY_TIME), cc.CallFunc:create(function()
            local leftTimeString = getLeftTimeByIndex(self, index)
            textTimeLabel:setString(leftTimeString)
        end)
    )
    
    local timeRepeatAction = cc.RepeatForever:create(timeSequenceAction)
    textTimeLabel:runAction(timeRepeatAction)
    
    local buttonHighSpeed           = imageRepairPage:getChildByName("Button_highspeed_button")
    local highSpeedButtonVisible    = false
    local highSpeedItemCount        = highSpeedItemCount()
    if highSpeedItemCount > 0 then highSpeedButtonVisible = true end
    buttonHighSpeed:setVisible(highSpeedButtonVisible)
    
    actionControl(self, repairPosition, imageRepairPage)
end

local function refreshAllRepairBar(self)
    local mainNode          = self._mainLayout
    local imageCommonBase   = mainNode:getChildByName("Image_common_base") 
    local projectNodeXl     = imageCommonBase:getChildByName("ProjectNode_xl")    
    for index = 1, MAX_REPAIR_BAR_COUNT do
        self:refreshSingleRepairBar(index)
    end
end

local function refreshBaseInfo(self)
    local mainNode              = self._mainLayout
    local imageCommonBase       = mainNode:getChildByName("Image_common_base")
    local projectNodeXl         = imageCommonBase:getChildByName("ProjectNode_xl")
    local panelRepairContent    = projectNodeXl:getChildByName("Panel_repair_content")
    local textHighSpeedCount    = panelRepairContent:getChildByName("Text_highspeed_repair_value")
    
    textHighSpeedCount:setString(highSpeedItemCount())
    refreshAllRepairBar(self)
end

local function switchTabUI(self, fromNodeType, toNodeType)
    local parentNode    = self._parent
    local disappearTime = 0
    if fromNodeType ~= nil then
        disappearTime = parentNode:removeNode(fromNodeType)
    end

    local function addNode()
        parentNode:addNode(toNodeType)
    end

    delayExecute(self._parent, addNode, disappearTime)
end

local function refreshButton(self, szOldNodeName)
    local nBeginFrame = BUTTON_LIST_ENTER_END_FRAME + ONE_BUTTON_FRAME_LEN * (m_tPageNodeList[self._viewNodeName].page - 1) + ONE_BUTTON_ENTER_BEGIN_FRAME
    KUtil.animationGotoFrameAndPlay(self._animationButton, nBeginFrame, nBeginFrame + ONE_BUTTON_MOVE_LEN)
end

local function refreshPage(self, ...)
    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")
    local node = imageControl:getChildByName(self._viewNodeName)
    node:setVisible(true)
    if self._viewNodeName == "ProjectNode_xl" then
        return refreshAllRepairBar(self)
    end

    if not self._KUINodePageList[self._viewNodeName] then
        local szPath = "src/ui/office/repair/" .. m_tPageNodeList[self._viewNodeName].class
        self._KUINodePageList[self._viewNodeName] = require(szPath).new(self, node)
    end
    self._KUINodePageList[self._viewNodeName]:refreshUI(...)
end

local function createPage(self, szNodeName)
    if self._viewNodeName == "ProjectNode_xl" then
        refreshPage(self, szNodeName)
    elseif not self._KUINodePageList[self._viewNodeName] then
        local mainNode        = self._mainLayout
        local imageControl    = mainNode:getChildByName("Image_common_base")
        local node = imageControl:getChildByName(self._viewNodeName)
        local szPath = "src/ui/office/repair/" .. m_tPageNodeList[self._viewNodeName].class
        self._KUINodePageList[self._viewNodeName] = require(szPath).new(self, node)
    end
end

function KUIRepairNode:repairListEnter()
    KUtil.playEnterAnimation(self._animationRepairList)
end

function KUIRepairNode:getNode(nodeType)
      return self._KUINodePageList[nodeType]
end

local function enterPage(self)
    if self._viewNodeName == "ProjectNode_xl" then
        self:repairListEnter()
        return
    end

    assert(self._KUINodePageList[self._viewNodeName])
    self._KUINodePageList[self._viewNodeName]:enter()
end

local function quitPage(self, szNodeName)
    if szNodeName == "ProjectNode_xl" then
        return KUtil.playQuitAnimation(self._animationRepairList)
    end

    assert(self._KUINodePageList[szNodeName])
    return self._KUINodePageList[szNodeName]:quit()
end

local function requestBuyRepair(self, goodConfig)
    local onConfirm = function ()
        if KPlayer.coin >= goodConfig.nPrice then
            require("src/network/KC2SProtocolManager"):ExpandBarByCoin(EXPAND_BAR_TYPE.REPAIR)
        else
            --show after this confirm
            delayExecute(self._mainLayout, function ()
                KUtil.showGotoBuyDiamondConfirmation(self._parent)
            end, 0.1) 
        end
    end

    local showString = string.format(KUtil.getStringByKey("factory.buyRepair"), goodConfig.nPrice)
    showConfirmation(showString, onConfirm)
end

function KUIRepairNode:refreshRedPoint()
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNodeXl         = imageCommon:getChildByName("ProjectNode_xl")
    local panelRepairContent    = projectNodeXl:getChildByName("Panel_repair_content")

    for index = 1, 4 do
        local repairNode  = panelRepairContent:getChildByName("Node_unit_" .. index)
        local imageUnit   = repairNode:getChildByName("Image_xl_unit_bg")
        local imageEmpty  = imageUnit:getChildByName("Image_xl_unit_empty")
        local projectNode = imageEmpty:getChildByName("ProjectNode_notice")
        projectNode:setVisible(false)
    end

    KUtil.refreshRepairRedPoint(self)
end

function KUIRepairNode:refreshSingleRepairBar(index)
    local mainNode              = self._mainLayout
    local imageCommonBase       = mainNode:getChildByName("Image_common_base")
    local projectNodeXl         = imageCommonBase:getChildByName("ProjectNode_xl")
    local panelRepairContent    = projectNodeXl:getChildByName("Panel_repair_content")
    
    local nodeName              = "Node_unit_" .. index
    local nodeUIRepairControl   = panelRepairContent:getChildByName(nodeName)
    local imageRepairPage       = nodeUIRepairControl:getChildByName("Image_xl_unit_bg")
    local imageExtendPage       = nodeUIRepairControl:getChildByName("Image_xl_unit_bg_close")
    local imageUnitEmpty        = imageRepairPage:getChildByName("Image_xl_unit_empty")
    local imageUnitWorking      = imageRepairPage:getChildByName("Image_xl_unit_working")
    local buttonHighSpeed       = imageRepairPage:getChildByName("Button_highspeed_button")
    local repairState           = getRepairPosition(index)
    
    local repairList            = KPlayer.tCardData.tRepairingList
    local cardUnitID            = HArray.FindFirst(repairList, "nRepairPosition", index)
    if not cardUnitID then
        buttonHighSpeed:setTouchEnabled(false)
        buttonHighSpeed:loadTextures(
            m_tButtonHighSpeedTextures.buttonDisableTexture,
            m_tButtonHighSpeedTextures.buttonDisableTexture,
            m_tButtonHighSpeedTextures.buttonDisableTexture
        )
    else
        buttonHighSpeed:setTouchEnabled(true)
        buttonHighSpeed:loadTextures(
            m_tButtonHighSpeedTextures.buttonNormalTexture,
            m_tButtonHighSpeedTextures.buttonPressTexture,
            m_tButtonHighSpeedTextures.buttonDisableTexture
        )
    end
    
    if repairState == ENUM_FACTORY_STATUS.unused then 
        cclog("---------->repairState.state -> ENUM_FACTORY_STATUS.unused")    
        imageRepairPage:setVisible(false)
        imageExtendPage:setVisible(true)
    end
    
    if repairState == ENUM_FACTORY_STATUS.empty then
        cclog("---------->repairState.state -> ENUM_FACTORY_STATUS.empty")  
        imageRepairPage:setVisible(true)
        imageExtendPage:setVisible(false)
        imageUnitWorking:setVisible(false)
        imageUnitEmpty:setVisible(true)
        
        local panelCarAnimation             = imageRepairPage:getChildByName("Panel_carRegion")
        local panelNodeCarAnimation         = panelCarAnimation:getChildByName("ProjectNode_ani_car") 
        local panelNodeCarSpeedAnimation    = panelCarAnimation:getChildByName("ProjectNode_car_speedup_ani")
        panelNodeCarAnimation:setVisible(false)
        panelNodeCarAnimation:stopAllActions()
        panelNodeCarSpeedAnimation:setVisible(false)
        panelNodeCarSpeedAnimation:stopAllActions()
        
        local textTimeLabel = imageRepairPage:getChildByName("Text_time_data")
        textTimeLabel:setString(INIT_TIME_STRING)
        textTimeLabel:stopAllActions() 
    end
    
    if repairState == ENUM_FACTORY_STATUS.working then     
        cclog("---------->repairState.state -> ENUM_FACTORY_STATUS.working")  
        updateWorkingBarInfo(self, index, imageRepairPage, imageExtendPage)
    end
end

function KUIRepairNode:switchPage(szNewNodeName, ...)
    if szNewNodeName == self._viewNodeName then return end
    local szOldNodeName = self._viewNodeName
    self._viewNodeName  = szNewNodeName
    refreshButton(self, szOldNodeName)
    self._mainLayout:stopAllActions()
    createPage(self, szNewNodeName)
    local nDelayTime = quitPage(self, szOldNodeName)
    local tParam = {...}
    local function enter()
        enterPage(self, unpack(tParam, 1, table.maxn(tParam)))
    end
    delayExecute(self._mainLayout, enter, nDelayTime)
end

function KUIRepairNode:refreshUI()
    refreshBaseInfo(self)
    self:refreshRedPoint()
    refreshPage(self)
    createPage(self, self._viewNodeName)
end

function KUIRepairNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    
    -- home button
    local projectNodeButtonHome = mainNode:getChildByName("ProjectNode_button_home")
    local panelCommonHome       = projectNodeButtonHome:getChildByName("Panel_common_home")
    local buttonHome            = panelCommonHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            KSound.playEffect("close")
            self._parent:returnOffice()
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)
    
    local imageCommonBase = mainNode:getChildByName("Image_common_base")

    local projectNodeXl = imageCommonBase:getChildByName("ProjectNode_xl")
    local panelRepairContent = projectNodeXl:getChildByName("Panel_repair_content")
    for nodeUnitID = 1, REPAIR_NUMBER do
        local nodeName          = "Node_unit_" .. nodeUnitID
        local nodeUnit          = panelRepairContent:getChildByName(nodeName)
        local imageUnitClose    = nodeUnit:getChildByName("Image_xl_unit_bg_close")
    
        -- expand button
        local buttonExpand      = imageUnitClose:getChildByName("Button_expand_button")
        local function onExpandClick(sender, type)
            if type == ccui.TouchEventType.ended then 
                KSound.playEffect("repairExtension")
                cclog("click onExpandButton~ nodeUnitID:%d", nodeUnitID)
                local itemNum    = KUtil.getItemCount(EXPAND_REPAIR_BAR_ID)
                local itemInfo   = KConfig["itemInfo"][EXPAND_REPAIR_BAR_ID]
                
                if itemNum <= 0 then 
                    local goodConfig = KUtil.getGoodConfigByItem(EXPAND_REPAIR_BAR_ID)
                    if goodConfig then
                        requestBuyRepair(self, goodConfig)
                    end
                    
                    return 
                end
                              
                local function sure()
                    require("src/network/KC2SProtocolManager"):ExpandBar(EXPAND_BAR_TYPE.REPAIR)
                end
                local showString = string.format(KUtil.getStringByKey("repaircard.expandBar"), itemInfo.szName)
                KUtil.showCostItemComfirmation(showString, EXPAND_REPAIR_BAR_ID, sure)
            end
        end
        buttonExpand:addTouchEventListener(onExpandClick)
        
        -- hgih speed button
        local imageUnit         = nodeUnit:getChildByName("Image_xl_unit_bg")
        local buttonHighSpeed   = imageUnit:getChildByName("Button_highspeed_button")
        local function onHighSpeedClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("highRepair")
                local repairList    = KPlayer.tCardData.tRepairingList
                if not repairList then return end
                local cardUnitID    = HArray.FindFirst(repairList, "nRepairPosition", nodeUnitID)
                if not cardUnitID then return end
                require("src/network/KC2SProtocolManager"):FinishRepairCardingByCostItem(cardUnitID.nCardID)
            end
        end
        buttonHighSpeed:addTouchEventListener(onHighSpeedClick)
        
        local imageUnitEmpty = imageUnit:getChildByName("Image_xl_unit_empty")
        
        -- add button
        local buttonAdd      = imageUnitEmpty:getChildByName("Button_add_button")
        local function onAddClick(sender,type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("repair")
                local state = getRepairPosition(nodeUnitID)
                if state ~= ENUM_FACTORY_STATUS.working then 
                    local unitChooseNode = self._parent:addNode("RepairUnitChoose")
                    unitChooseNode:setRepairIndex(nodeUnitID)
                end
            end
        end
        buttonAdd:addTouchEventListener(onAddClick)        
    end
    
    local panelLabelButton = imageCommonBase:getChildByName("Panel_label_button")
    local imageLabelBase   = panelLabelButton:getChildByName("Image_label_base")
    for szNodeName, tInfo in pairs(m_tPageNodeList) do
        local button = imageLabelBase:getChildByName("Button_" .. tInfo.page)
        if button then
            local function onClick(sender, type)
                if type ~= ccui.TouchEventType.ended then return end
                cclog("click onClick ~ %s %d", szNodeName, tInfo.page)
                KSound.playEffect("click")
                self:switchPage(szNodeName)
            end
            button:addTouchEventListener(onClick)
        end
    end
end

function KUIRepairNode:registerAllCustomEvent()
    local eventDispatchCenter   = require("src/logic/KEventDispatchCenter")
    local function onStartRepair(nCardID)
        local repairList        = KPlayer.tCardData.tRepairingList
        local cardID            = HArray.FindFirst(repairList, "nCardID", nCardID)
        self:refreshSingleRepairBar(cardID.nRepairPosition)
        self:refreshRedPoint()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BEGAN_REPAIR_CARD, onStartRepair)

    local function onResourceUpdate()
        cclog("----------> onEvent KUIRecordNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
    
    local function finishRepairCard(repairIndex)
        if self._highSpeedflag then
            self:refreshSingleRepairBar(repairIndex)
        end 
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_DEL_REPAIR_CARD, finishRepairCard)
    
    local function onHighSpeedRepair(repairIndex)
        refreshBaseInfo(self)
        
        self._highSpeedflag                     = false
        local repairPosition                    = repairIndex.nRepairPosition
        local mainNode                          = self._mainLayout
        local imageCommonBase                   = mainNode:getChildByName("Image_common_base")
        local ProjectNodeXl                     = imageCommonBase:getChildByName("ProjectNode_xl")
        local panelRepairContent                = ProjectNodeXl:getChildByName("Panel_repair_content")
        local nodeName                          = "Node_unit_" .. repairPosition
        local imageUIRepairControl              = panelRepairContent:getChildByName(nodeName)
        local imageRepairPage                   = imageUIRepairControl:getChildByName("Image_xl_unit_bg")
        local panelCarAnimation                 = imageRepairPage:getChildByName("Panel_carRegion")
        local projectNodeCarAnimation           = panelCarAnimation:getChildByName("ProjectNode_ani_car")
        local projectNodeCarSpeedUpAnimation    = panelCarAnimation:getChildByName("ProjectNode_car_speedup_ani")
        projectNodeCarAnimation:setVisible(false)
        projectNodeCarAnimation:stopAllActions()
        projectNodeCarSpeedUpAnimation:setVisible(true)
        
        local animationTime = self._carAction[repairPosition].speedUpRepairCarAction:getDuration() / FPS
        self._carAction[repairPosition].speedUpRepairCarAction:gotoFrameAndPlay(ANIMATION_START_FRAME, false) 
        
        delayExecute(self, function() self:refreshSingleRepairBar(repairPosition) self._highSpeedflag = true end, animationTime)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_FINISH_REPAIR_CAR_COSTITEM, onHighSpeedRepair)   
    
    local function expandRepairBar(nOneRepairBar)       
        self:refreshSingleRepairBar(KPlayer.nRepairBarNum)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.EXPAND_REPAIRBAR, expandRepairBar)

    local function onAddCard()
        self:refreshRedPoint()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ADD_CARD, onAddCard)
end

local function enterAnimation(self)
    KUtil.playEnterAnimation(self._animationHome)
    KUtil.playEnterAnimation(self._animationResource)
    local nDelayTime = KUtil.playEnterAnimation(self._animationButton)

    local function playPageButton()
        refreshButton(self)
    end
    local mainNode            = self._mainLayout
    local imageCommonBase     = mainNode:getChildByName("Image_common_base")
    local nodeButtonAnimation = imageCommonBase:getChildByName("Panel_label_button")
    local imageButtonBase     = nodeButtonAnimation:getChildByName("Image_label_base")
    delayExecute(imageButtonBase, playPageButton, nDelayTime)
    enterPage(self)
end

function KUIRepairNode:playQuitAnimation()
    local delayTime1 = KUtil.playQuitAnimation(self._animationHome)
    local delayTime2 = KUtil.playQuitAnimation(self._animationResource)
    local delayTime3 = KUtil.playQuitAnimation(self._animationButton, BUTTON_LIST_QUIT_BEGIN_FRAME, BUTTON_LIST_QUIT_END_FRAME)
    return math.max(delayTime1, delayTime2, delayTime3)
end

local function quitAnimation(self, isReturnOffice)
    local delayTime1, delayTime2 = self:playQuitAnimation(), 0
    if self._viewNodeName == "ProjectNode_xl" then
        delayTime2 = KUtil.playQuitAnimation(self._animationRepairList)
    else
        delayTime2 = quitPage(self, self._viewNodeName)
    end
    local delayTime = math.max(delayTime1, delayTime2)

    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Repair", callBacks, isReturnOffice)
end

local function initData(self)
    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")

    local function  closeCallBack(isReturnOffice)
        quitAnimation(self, isReturnOffice)
    end
    self._animationHome, self._animationResource = KUtil.initHomeAndResourceNode(self, closeCallBack, "xl_base")
    local nodeButtonAnimation = imageControl:getChildByName("Panel_label_button")
    self._animationButton     = KUtil.initAnimation(nodeButtonAnimation, "res/ui/animation_node/ani_repair_button_left.csb")
    local nodeBarAnimation    = imageControl:getChildByName("ProjectNode_xl")
    self._animationRepairList = KUtil.initAnimation(nodeBarAnimation, "res/ui/animation_node/ani_repair_content.csb")
    for szNodeName, _ in pairs(m_tPageNodeList) do
        imageControl:getChildByName(szNodeName):setVisible(false)
    end
end

function KUIRepairNode:onInitUI()
    initData(self)
end

function KUIRepairNode:onEnterActionFinished()
    enterAnimation(self)
    enterPage(self)
end

return KUIRepairNode
