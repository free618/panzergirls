--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairRebornChoiceNode.lua
--  Creator     : HuangYiXin
--  Date        : 2015/08/21   14:30
--  Contact     : HUANGYIXIN@kingsoft.com
--  Comment     :
--  *********************************************************************


local SCROLLVIEW_CARD_COLUMN_COUNT   = 3
local MAX_TANK_TYPE_COUNT            = 6
local REBORN_ITEM_TEMPLATE_ID        = 3

local KUIRepairRebornChoiceNode = class(
    "KUIRepairRebornChoiceNode", function () return require("src/ui/uibase/KUINodeBase.lua").create() end 
)

function KUIRepairRebornChoiceNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil

    self._scrollCardInfoList   = {}

    self._scrollViewContainerWidth = nil
    self._scrollViewColumnSpan     = nil
    self._scrollViewOriginalSize   = nil
    self._panelCardSpanHorizontal  = nil
    self._panelCardSpanVertical    = nil

    self._isScrollViewDisplaying   = true  
end

function KUIRepairRebornChoiceNode.create(owner)
    local currentNode = KUIRepairRebornChoiceNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_reborn_choice.csb"
    currentNode:init()

    return currentNode
end

local function getOneCardDeathList()
    return KPlayer.tCardData.tDeadList
end

local function getScrollInfoIndexByCardID(self, cardID)
    local scrollInfoCardList = self._scrollCardInfoList
    for index, item in ipairs(scrollInfoCardList) do
        if item.cardID == cardID then
            return index
        end
    end
    return nil
end

local function getScrollViewRowCount(self)
    local scrollInfoCount = table.getn(self._scrollCardInfoList)
    return math.ceil(scrollInfoCount / SCROLLVIEW_CARD_COLUMN_COUNT)
end

local function playRebornCardEffect(self, nodeCardRoot)
    local rebornCardEffect = cc.CSLoader:createTimeline("res/ui/animation_node/ani_reborn.csb")
    local startFrameIndex  = 0
    local endFrameIndex    = 50
    local totalFrameCount  = 51
    local isLoop           = false

    nodeCardRoot:stopAllActions()
    nodeCardRoot:runAction(rebornCardEffect)
    rebornCardEffect:gotoFrameAndPlay(startFrameIndex, endFrameIndex, isLoop)

    local effectTimeStep   = rebornCardEffect:getTimeSpeed()
    local effectDuration   = rebornCardEffect:getDuration() * ( effectTimeStep / 60 )
    local effectFrameCount = endFrameIndex - startFrameIndex
    local totalDuration    = effectDuration * effectFrameCount / totalFrameCount
    return totalDuration          
end

local function resetNodeCardRootDeadState(self, nodeCardRoot)
    local rebornCardEffect = cc.CSLoader:createTimeline("res/ui/animation_node/ani_reborn.csb")
    local startFrameIndex  = 0
    local endFrameIndex    = 1
    nodeCardRoot:stopAllActions()
    nodeCardRoot:runAction(rebornCardEffect)
    rebornCardEffect:gotoFrameAndPlay(startFrameIndex, endFrameIndex, false)     
end

local function createPanelCardArea(self, projectNodeCard)
    local panelCard     = ccui.Layout:create()  
    local childrenList  = projectNodeCard:getChildren()
    for _, subNode in ipairs(childrenList) do  
        local subNodeClone = subNode:clone()
        panelCard:addChild(subNodeClone)
    end

    local cardPosX    = projectNodeCard:getPositionX()
    local cardPosY    = projectNodeCard:getPositionY()
    local cardScaleX  = projectNodeCard:getScaleX()
    local cardScaleY  = projectNodeCard:getScaleY()
    local cardTag     = projectNodeCard:getTag()
    local cardName    = projectNodeCard:getName()
    local cardZOrder  = projectNodeCard:getLocalZOrder()

    panelCard:setPosition(cardPosX, cardPosY)
    panelCard:setScaleX(cardScaleX)
    panelCard:setScaleY(cardScaleY)
    panelCard:setName(cardName)
    panelCard:setTag(cardTag)
    panelCard:setLocalZOrder(cardZOrder)

    local panelCardRoot      = panelCard:getChildByName("Panel_card_base")
    local panelCardMeda      = panelCard:getChildByName("Panel__card_meda")
    local panelCardType      = panelCard:getChildByName("Panel__card_type")
    local panelCardStars     = panelCard:getChildByName("Panel_13")
    local panelCardCharacter = panelCard:getChildByName("Panel_card_chara")
    panelCardRoot:setTouchEnabled(false)
    panelCardMeda:setTouchEnabled(false)
    panelCardType:setTouchEnabled(false)
    panelCardStars:setTouchEnabled(false)
    panelCardCharacter:setTouchEnabled(false)

    return panelCard
end

local function createPanelCardBase(self)
    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local scrollVeiwCard       = imageCommonBase:getChildByName("ScrollView_dead_card")
    local projectNodeCardRoot  = scrollVeiwCard:getChildByName("ProjectNode_card_1")

    local panelCardRoot = cc.CSLoader:createNode("res/ui/animation_node/ani_reborn.csb")

    local cardPosX    = projectNodeCardRoot:getPositionX()
    local cardPosY    = projectNodeCardRoot:getPositionY()
    local cardScaleX  = projectNodeCardRoot:getScaleX()
    local cardScaleY  = projectNodeCardRoot:getScaleY()
    local cardTag     = projectNodeCardRoot:getTag()
    local cardName    = projectNodeCardRoot:getName()
    local cardZOrder  = projectNodeCardRoot:getLocalZOrder()

    panelCardRoot:setPosition(cardPosX, cardPosY)
    panelCardRoot:setScaleX(cardScaleX)
    panelCardRoot:setScaleY(cardScaleY)
    panelCardRoot:setName(cardName)
    panelCardRoot:setTag(cardTag)
    panelCardRoot:setLocalZOrder(cardZOrder)

    return panelCardRoot
end

local function getPanelCardRootClone(self)
    return createPanelCardBase(self)
end

local function resetScrollInnerContainerSize(self, scrollControl, rowCount)
    local baseHeight          = self._panelCardSpanVertical
    local baseWidth           = self._scrollViewOriginalSize.width

    local realScrollContainerHeight = baseHeight * rowCount
    if realScrollContainerHeight < self._scrollViewOriginalSize.height then
        realScrollContainerHeight = self._scrollViewOriginalSize.height
    end
    scrollControl:setInnerContainerSize(cc.size(baseWidth, realScrollContainerHeight))
    return realScrollContainerHeight
end

local function selectDeadCard(self, cardID)
    if KUtil.getDeadCardById(cardID) ~= nil then
        self._parent:addNode("RebornMethod", {["cardID"] = cardID})
        self._isScrollViewDisplaying = false
    end
end

local function refreshNodeCardRoot(self, scrollViewCard, nodeCardRoot, cardID, isWidget)
    local oneCard = KUtil.getDeadCardById(cardID)

    local buttonCardBase = nodeCardRoot:getChildByName("Button_card_base")
    buttonCardBase:setSwallowTouches(false)
    local function onCardClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        local startPos   = sender:getTouchBeganPosition()
        local endPos     = sender:getTouchEndPosition()
        local dy         = endPos.y - startPos.y
        local moveLimit  = 5
        if dy * dy > moveLimit * moveLimit then
            return
        end
        cclog("-----> onCardClick~")
        selectDeadCard(self, cardID)
    end
    buttonCardBase:addTouchEventListener(onCardClick)

    local textLevel = buttonCardBase:getChildByName("Text_level")
    textLevel:setString(oneCard.nLevel)

    local projectCard = buttonCardBase:getChildByName("ProjectNode_card")
    KUtil.drawCardByConfigID(projectCard, oneCard.nTemplateID)

    nodeCardRoot:stopAllActions()
end

local function refreshCardRootWithInnerNode(self, scrollViewCard, projectNodeCardRoot, scrollInfoIndex)
    assert( scrollInfoIndex <= #self._scrollCardInfoList, "")
    --use the current project node card root which already existed in csd.
    local isWidget = false
    local cardID   = self._scrollCardInfoList[scrollInfoIndex].cardID
    projectNodeCardRoot:setVisible(true)
    refreshNodeCardRoot(self, scrollViewCard, projectNodeCardRoot, cardID, isWidget)
    return projectNodeCardRoot
end

local function refreshCardRootWithCloneNode(self, scrollViewCard, panelCardRoot, scrollInfoIndex)
    assert( scrollInfoIndex <= #self._scrollCardInfoList, "")
    local isWidget = true
    local cardID   = self._scrollCardInfoList[scrollInfoIndex].cardID    
    panelCardRoot:setVisible(true)
    refreshNodeCardRoot(self, scrollViewCard, panelCardRoot, cardID, isWidget)        
end

local function refreshScrollViewCardList(self)
    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local scrollViewCard       = imageCommonBase:getChildByName("ScrollView_dead_card")

    local originScrollHeight  = self._scrollViewOriginalSize.height
    local verticalSpan        = self._panelCardSpanVertical
    local horizontalSpan      = self._panelCardSpanHorizontal

    local firstNodeCardRoot   = scrollViewCard:getChildByName("ProjectNode_card_1")
    local leftShift  = firstNodeCardRoot:getPositionX()
    local topShift   = firstNodeCardRoot:getPositionY()    
    local rowCount   = getScrollViewRowCount(self) 

    local realContainerHeight = resetScrollInnerContainerSize(self, scrollViewCard, rowCount) 
    local topShift = realContainerHeight - originScrollHeight + topShift

    local nodeCardRootCount = scrollViewCard:getChildrenCount()
    for i = 1, nodeCardRootCount do
        local projectNodeCardRootName = "ProjectNode_card_" .. i
        local projectNodeCardRoot     = scrollViewCard:getChildByName(projectNodeCardRootName)
        projectNodeCardRoot:setVisible(false)
    end

    local scrollInfoCardList = self._scrollCardInfoList
    for i, scrollInfo in ipairs(scrollInfoCardList) do
        cclog("----------> start refresh scroll view panel card root: index = %d, cardID = %d", i, scrollInfo.cardID)
        local nodeCardRoot    = nil
        local isWidget        = false
        if i <= nodeCardRootCount then
            nodeCardRoot = scrollViewCard:getChildByName("ProjectNode_card_" .. i)
            refreshCardRootWithInnerNode(self, scrollViewCard, nodeCardRoot, i)
            isWidget   = false
        else
            nodeCardRoot = getPanelCardRootClone(self)
            nodeCardRoot:setName("ProjectNode_card_" .. i)
            scrollViewCard:addChild(nodeCardRoot)
            refreshCardRootWithCloneNode(self, scrollViewCard, nodeCardRoot, i)
            isWidget   = false
        end

        local colIndex = ( i - 1 ) % SCROLLVIEW_CARD_COLUMN_COUNT
        local rowIndex = math.ceil( i / SCROLLVIEW_CARD_COLUMN_COUNT ) - 1

        nodeCardRoot:setPosition(cc.p(leftShift + colIndex * horizontalSpan, topShift - rowIndex * verticalSpan))

        scrollInfo.uiNode   = nodeCardRoot
        scrollInfo.isWidget = isWidget 
    end
end

local function refreshBaseInfoArea(self)
    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local imageBase            = imageCommonBase:getChildByName("Image_xl_base")

    local textRebornTimes   = imageBase:getChildByName("Text_highspeed_repair_value")
    local rebornItemCount   = KUtil.getItemCount(REBORN_ITEM_TEMPLATE_ID)
    textRebornTimes:setString(rebornItemCount)  
end

local function checkUI(self)
    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local scrollViewCard       = imageCommonBase:getChildByName("ScrollView_dead_card")
    local projcetNodeCard      = scrollViewCard:getChildByName("ProjectNode_card_1")
    local containerSize        = self._scrollViewOiginalSize

    if containerSize == nil then
        containerSize = scrollViewCard:getInnerContainerSize()
        self._scrollViewOriginalSize = containerSize
    end

    local containerHeight = containerSize.height
    local bottomShift     = projcetNodeCard:getPositionY()
    local panelCardSpan   = containerHeight - bottomShift
    self._panelCardSpanVertical = panelCardSpan

    local leftShift       = projcetNodeCard:getPositionX()
    local containerWidth  = containerSize.width
    local panelCardSpan   = (containerWidth - leftShift) / SCROLLVIEW_CARD_COLUMN_COUNT
    self._panelCardSpanHorizontal = panelCardSpan
end

local function initDeadCardList(self)
    self._scrollCardInfoList = {}

    local oneCardDeathList  = getOneCardDeathList()
    local scrollInfoCardList    = self._scrollCardInfoList

    for _, v in ipairs(oneCardDeathList) do
        table.insert(scrollInfoCardList, {["cardID"] = v.nID})
    end
end

local function switchTabUI(self, fromNodeType, toNodeType)
    local parentNode    = self._parent
    local disappearTime = 0
    if fromNodeType ~= nil then
        disappearTime = parentNode:removeNode(fromNodeType)
    end
    
    local function addNode()
        parentNode:addNode(toNodeType)
    end

    delayExecute(self._parent, addNode, disappearTime)
end

local function refreshRedPoint(self)
    KUtil.refreshRepairRedPoint(self)
end

local function SyncDeadCount()    
    local deadList      = KPlayer.tCardData.tDeadList
    local deadListCount = #deadList
    local setting = require("src/logic/KSetting")
    setting.setInt(setting.Key.DEAD_COUND, deadListCount)
end

function KUIRepairRebornChoiceNode:refreshUI()
    checkUI(self)
    SyncDeadCount()    
    initDeadCardList(self)
    refreshBaseInfoArea(self)
    refreshScrollViewCardList(self)
    refreshRedPoint(self)
end

local function removeDeadCard(self, cardID)
    local scrollInfoIndex = getScrollInfoIndexByCardID(self, cardID)
    if scrollInfoIndex == nil then return end

    local scrollInfo = self._scrollCardInfoList[scrollInfoIndex]
    if self._isScrollViewDisplaying then
        table.remove(self._scrollCardInfoList, scrollInfoIndex)
        refreshScrollViewCardList(self)  
    else       
    --cause the reborn menthod view is displaying, so let refreshUI() excute by 
    --methond notifyReturnResult() after reborn menthod view has been removed        
    end
end

function KUIRepairRebornChoiceNode:notifyReturnResult(isReborn, rebornCardID)
    -- this menthod is invoked by KUIRepairRebornMethonNode,
    -- which to notify a dead card has been reborned.
    -- don't invoke this method by others
    self._isScrollViewDisplaying = true

    if isReborn then
        local scrollInfoIndex = getScrollInfoIndexByCardID(self, rebornCardID)
        local scrollInfo      = self._scrollCardInfoList[scrollInfoIndex]
        local cardRebornDelay = playRebornCardEffect(self, scrollInfo.uiNode)

        local function onAfterCardReborn()
            resetNodeCardRootDeadState(self, scrollInfo.uiNode)
            self:refreshUI()
        end
        delayExecute(self, onAfterCardReborn, cardRebornDelay)
    else
        self:refreshUI()
    end
end

function KUIRepairRebornChoiceNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local buttonHome        = mainNode:getChildByName("Button_home")
    local imageCommonBase   = mainNode:getChildByName("Image_common_base")
    local buttonClose       = imageCommonBase:getChildByName("Button_close")

    local function onHomeClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onHomeClick~")
        self._parent:returnOffice()
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local function onCloseClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onCloseClick~")
        self._parent:removeNode("RebornChoice")
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local panelLabelButton = imageCommonBase:getChildByName("Panel_label_button")
    local buttonSupply = panelLabelButton:getChildByName("Button_recharge")
    local function onSupplyClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onSupplyClick~")
        KSound.playEffect("click")
        switchTabUI(self, "RebornChoice", "Supply")
    end
    buttonSupply:addTouchEventListener(onSupplyClick)

    local buttonRepair = panelLabelButton:getChildByName("Button_repair")
    local function onRepairClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onClick~")
        KSound.playEffect("click")
        switchTabUI(self, "RebornChoice", "Repair")
    end
    buttonRepair:addTouchEventListener(onRepairClick)

    local buttonReborn = panelLabelButton:getChildByName("Button_resurrection")
    local function onRebornClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        cclog("-----> onRebornClick~")
        KSound.playEffect("click")
    end
    buttonReborn:addTouchEventListener(onRebornClick)
end

function KUIRepairRebornChoiceNode:registerAllCustomEvent()
    local eventDispatcher = require("src/logic/KEventDispatchCenter")

    local function onDeleteDeadCard(cardID)
        cclog("----------> onEvent onDeleteDeadCard")
        removeDeadCard(self, cardID)
    end
    self:addCustomEvent(eventDispatcher.EventType.NET_DELETE_DEAD_CARD, onDeleteDeadCard)

    local function onUpdateItem(itemID)
        cclog("----------> onEvent onAddCard")
        if itemID == REBORN_ITEM_TEMPLATE_ID then
            refreshBaseInfoArea(self)
        end
    end
    self:addCustomEvent(eventDispatcher.EventType.NET_ITEM_ADD, onUpdateItem)  

    --    -- new dead card doesn't add dynamic at present,
    --    -- so that new dead card would be showed after reopening this view
    --    local function onAddDeadCard(cardID)
    --        cclog("----------> onEvent onAddDeadCard")
    --        appendDeadCard(self, cardID)
    --        refreshScrollViewCardList(self)            
    --    end
    --    self:addCustomEvent(eventDispatcher.EventType.NET_DELETE_DEAD_CARD, onDeleteDeadCard)
end

function KUIRepairRebornChoiceNode:onNodeExit()
    if self._panelCardRootBase ~= nil then
        self._panelCardRootBase:release()
    end
    SyncDeadCount()
end

return KUIRepairRebornChoiceNode
