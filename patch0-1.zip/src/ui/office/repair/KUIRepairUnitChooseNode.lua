--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIRepairUnitChooseNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/3/18   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     : 
--  *********************************************************************


local SHOW_ROW_SIZE    = 4
local SHOW_COLUMN_SIZE = 7
local SHOW_ROW_OFF     = -5     -- 行偏移
local VALID_OFF        = 20
local KSetting = require("src/logic/KSetting")

local repairCostTimeFormula = "(nLevel * 1.2 + nRatio) * nPower * nHurtHP + 30"

local KUIRepairUnitChooseNode = class(
    "KUIRepairUnitChooseNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIRepairUnitChooseNode:ctor()
    self._mainLayout     = nil
    self._parent         = nil
    self._uiPath         = nil
    self._baseControl    = nil
    self._canClick       = true
    self._repairIndex    = nil
end

function KUIRepairUnitChooseNode.create(owner)
    local currentNode      = KUIRepairUnitChooseNode.new()

    currentNode._parent    = owner
    currentNode._uiPath    = "res/ui/layout_repair_unit_choose.csb"
    currentNode:init()
    return currentNode
end

local function playTopAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_top")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_unit_choose_top"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playContentAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode = imageCommon:getChildByName("ProjectNode_content")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_repair_unit_choose_content"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode    = self._mainLayout
    local imageCommon = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()

    local projectNode = imageCommon:getChildByName("ProjectNode_content")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playContentAnimation(self, false))
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "RepairUnitChoose", callBacks, isReturnOffice)
end

local function getShowItemList(cardList)
    local showList = {}

    local repairList = KPlayer.tCardData.tRepairingList
     
    for key, card in ipairs(cardList) do
        local nMaxHP         = KUtil.getCardMaxHp(card)
        local tOneRepairCard = HArray.FindFirst(repairList, "nCardID", card.nID)
        if (card.nCurrentHP < nMaxHP) and (not tOneRepairCard) then
            table.insert(showList, card)
        end
        
    end
    return showList
end

local function isExpedition(cardID)
    local teamID = KUtil.getEnterTeamId(cardID)
    if teamID == 0 then return false end

    local tExpeditionList = KPlayer.tExpeditionData.tExpeditionList
    for _, var in ipairs(tExpeditionList) do
        if teamID == var.nTeamID then return true end      
    end

    return false
end

function KUIRepairUnitChooseNode:repairCard(card)   
    local repairPosition = self._repairIndex
    cclog("----------------------->repairPosition: ".. repairPosition)
    
    local nMaxHP = KUtil.getCardMaxHp(card)
    --local nAddHP  = KConfig["cardInfo"][card.nTemplateID]["nAddHP"]
    local hurtHP = nMaxHP  - card.nCurrentHP
    
    if hurtHP <= 0 then 
        showNoticeByID("repaircard.fullhp")
        self._canClick = true
        return
    end  

    local repairList = KPlayer.tCardData.tRepairingList
    local tOneRepairCard = HArray.FindFirst(repairList, "nCardID", card.nID)
    if tOneRepairCard then
        showNoticeByID("repaircard.inrepair")
        self._canClick = true
        return
    end  

    local tOneRepairCard = HArray.FindFirst(repairList, "nRepairPosition", repairPosition)
    if tOneRepairCard then
        self._canClick = true
        return
    end  
    
    local nCarryOil     = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
    local nCostPeople   = math.ceil(nCarryOil * 0.2 * 0.35 * hurtHP)
    local nCostSteel    = math.ceil(nCarryOil * 0.2 * 0.25 * hurtHP)   
    
    if(KPlayer.people < nCostPeople or KPlayer.steel < nCostSteel ) then
        showNoticeByID("repaircard.cost")
        self._canClick = true
        return 
    end
     
    if isExpedition(card.nID) then
        showNoticeByID("repaircard.inExpedition")
        self._canClick = true
        return 
    end

    -- send protocol
    require("src/network/KC2SProtocolManager"):repairCard(card.nID, repairPosition)
    
    -- return to repair UI
    playPanelCloseAnimation(self, false)
end

local function refreshCardNumber(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local topProject       = imageCommon:getChildByName("ProjectNode_top")
    local panelTop         = topProject:getChildByName("Panel_1")
    local labelCardCount   = panelTop:getChildByName("Text_contant_quantity")

    local currentCount = #KPlayer.tCardData.tStoreHouse.tCardList
    labelCardCount:setString(currentCount .. "/" .. KPlayer.tCardData.tStoreHouse.nMaxSize)
end

local function getRepairCostTime(nCardID)
    local oneCard           = KUtil.getCardById(nCardID)
    if not oneCard then return 0 end

    local cardLevel         = oneCard.nLevel
    local maxHP             = KUtil.getCardMaxHp(oneCard)
    local hurtHP            = maxHP - oneCard.nCurrentHP

    local cardConfig        = KUtil.getCardConfig(oneCard.nTemplateID)
    assert(cardConfig)

    local powerInfo         = KUtil.getCardRepairPowerInfo(cardConfig.nTankType)
    assert(powerInfo)
    local power             = powerInfo.nPower

    local repairRation      = KUtil.getCardRepairRation(cardLevel)

    local strRepairCostTime = "local nLevel = select(1, ...) local nRatio = select(2, ...) local nPower = select(3, ...) local nHurtHP = select(4, ...) return ( " ..repairCostTimeFormula.. " )"
    local fnRepairCostTime  = assert(loadstring(strRepairCostTime))

    local repairCostTime    = fnRepairCostTime(cardLevel, repairRation, power, hurtHP)

    return math.ceil(repairCostTime)
end

local function updateScrollItemByCard(self, uiControl, card)
    uiControl:setName(tostring(card.nID))
    -- update card
    KUtil.updateCardBase(uiControl, card)

    local nMaxHP       = KUtil.getCardMaxHp(card)
    local hurtHP       = nMaxHP - card.nCurrentHP

    local nCarryOil     = KConfig["cardInfo"][card.nTemplateID]["nCarryOil"]
    local nCostPeople   = math.ceil(nCarryOil * 0.2 * 0.35 * hurtHP)
    local nCostSteel    = math.ceil(nCarryOil * 0.2 * 0.25 * hurtHP)   
     
    local panelResource = uiControl:getChildByName("Panel_resource_base")
    local textSteel = panelResource:getChildByName("Text_steel")
    textSteel:setString(nCostSteel)

    local textPeople   = panelResource:getChildByName("Text_sp_ammo")
    textPeople:setString(nCostPeople)

    local textSpTime     = panelResource:getChildByName("Text_sp_time")
    local repairCostTime = getRepairCostTime(card.nID)
    local hour  = math.floor(repairCostTime / (60 * 60))
    local min   = math.floor(repairCostTime / 60 % 60)
    local sec   = math.floor(repairCostTime % 60)
    
    local timeString = KUtil.getStringByKey("card.repair.costtime")
    timeString = string.format(timeString, hour, min, sec)

    textSpTime:setString(tostring(timeString))

    --Item Click Event
    local buttonCard = KUtil.getCardBaseActiveFrameButtom(uiControl, card.nID)
    local function onUnitClick(sender, type)
        if ccui.TouchEventType.ended == type then
            if self._canClick then
                self._canClick = false
                KSound.playEffect("click")
                self:repairCard(card)
            end
        end
    end
    buttonCard:addTouchEventListener(onUnitClick)
    buttonCard:setSwallowTouches(false)
end

local function addScrollPageView(self, isCutIn)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")

    local panelScroll    = projectContent:getChildByName("Panel_scroll")
    local slideControl   = panelScroll:getChildByName("Slider_scroll")
    local showList       = getShowItemList(KPlayer.tCardData.tStoreHouse.tCardList)
    local KSetting       = require("src/logic/KSetting")
    local sortType       = KSetting.getInt(KSetting.Key.BREAK_COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)

    showList = KUtil.getUnitSelectSortList(showList, sortType)

    local refreshCall = function(control, dataInfo)
        updateScrollItemByCard(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollControl,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        dataList    = showList,
        refreshCall = refreshCall,
        row         = SHOW_ROW_SIZE,
        column      = SHOW_COLUMN_SIZE,
        spanY       = SHOW_ROW_OFF,
        isCutIn     = isCutIn,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function initUI(self)
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local projectContent = imageCommon:getChildByName("ProjectNode_content")
    local panelContent   = projectContent:getChildByName("Panel_unit_choose_content")
    local scrollControl  = panelContent:getChildByName("ScrollView_tank_list")
    local buttonUnit      = scrollControl:getChildByName("Panel_unit")
    local buttonUnitBase1 = buttonUnit:getChildByName("Button_unit_base1")

    self._baseControl    = KUtil.getCardBaseNode(buttonUnitBase1)
    self._baseControl:retain()

    local panelResource = buttonUnitBase1:getChildByName("Panel_resource_base")
    -- switch node
    panelResource:retain()
    buttonUnitBase1:removeChild(panelResource)
    self._baseControl:addChild(panelResource)
    panelResource:release()

    scrollControl:removeAllChildren()
end

function KUIRepairUnitChooseNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    initUI(self)
end

function KUIRepairUnitChooseNode:refreshUI()
    -- update scroll view
    addScrollPageView(self)
    -- update card count in total
    refreshCardNumber(self)
end

function KUIRepairUnitChooseNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playTopAnimation(self, true)
    playContentAnimation(self, true)
end

function KUIRepairUnitChooseNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "dwxz_base")
end

function KUIRepairUnitChooseNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onErrorCode()
        self._canClick = true
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_ERROR_CODE, onErrorCode) 

    local function onResourceUpdate()
        cclog("----------> onEvent KUIRepairUnitChooseNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUIRepairUnitChooseNode:onCleanup()
    self._baseControl:release() 
end

function KUIRepairUnitChooseNode:setRepairIndex(index)
    self._repairIndex = index
end

return KUIRepairUnitChooseNode
    