--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIServiceActivityNode.lua
--  Creator     : ZhangChunQi
--  Date        : 2016/05/10   16:27
--  Contact     : zhangchunqi@kingsoft.com
--  Comment     :
--  *********************************************************************

local KUIServiceActivityNode = class(
    "KUIServiceActivityNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIServiceActivityNode:ctor()
    self._mainLayout    = nil
    self._parent        = nil
    self._uiPath        = nil
end

function KUIServiceActivityNode.create(owner, userData)
    local currentNode = KUIServiceActivityNode.new()

    currentNode._parent         = owner
    currentNode._uiPath         = "res/ui/layout_service_activity.csb"
   
    currentNode:init()

    return currentNode
end

local function playServiceActivityAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_1")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_service_activity"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_1")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playServiceActivityAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "ServiceActivity", callBacks, isReturnOffice)
end

function KUIServiceActivityNode:onInitUI()
    stopAllAnimation(self)
end

function KUIServiceActivityNode:onEnterActionFinished()
    playServiceActivityAnimation(self, true)
end

local function initData(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_1")
    local imageBase   = projectNode:getChildByName("Image_base")
    local scrollView  = imageBase:getChildByName("ScrollView_1")
    local imageUnit   = scrollView:getChildByName("Image_unit")
    self._baseImageUnit    = imageUnit:clone()
    self._baseImageUnit:retain()
end

local function initImageUnit(self, control, dataInfo)
    local panelIcon             = control:getChildByName("Panel_icon")
    local imageIcon             = panelIcon:getChildByName("Image_icon")
    local iconPath              = KUtil.getItemImagePathByID(dataInfo.nItemID)
    imageIcon:loadTexture(iconPath)

    local textName              = control:getChildByName("Text_name")
    textName:setString(dataInfo.szName)

    local imageNonSelling       = control:getChildByName("Image_non_selling")
    local labelOriginalPrice    = control:getChildByName("BitmapFontLabel_original_price")
    local imageOriginalDiamond  = control:getChildByName("Image_original_diamond")

    local isSelling = dataInfo.bSelling
    imageNonSelling:setVisible(not isSelling)
    labelOriginalPrice:setVisible(isSelling)
    imageOriginalDiamond:setVisible(isSelling)

    labelOriginalPrice:setString(dataInfo.nOriginalPrice)

    local labelPreferentialPrice = control:getChildByName("BitmapFontLabel_preferential_price")
    labelPreferentialPrice:setString(dataInfo.nPrice)

    local textDescrition1        = control:getChildByName("Text_descrition_1")
    textDescrition1:setString(dataInfo.szServiceActivityDescription)

    local textDescrition2        = control:getChildByName("Text_descrition_2")
    local descrition2Format      = KUtil.getStringByKey("serviceactivity.descrition2")
    local descrition2            = string.format(descrition2Format, dataInfo.nBuyCount)
    textDescrition2:setString(descrition2)
end

local function refreshScrollView(self)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")
    local scrollView        = imageBase:getChildByName("ScrollView_1")
    scrollView:removeAllChildren()
    
    local showListUI = {}
    local shopConfig = KConfig.shop
    for _,v in ipairs(shopConfig) do
        if v.bServiceActivity then
            local newImageUnit = self._baseImageUnit:clone()
            initImageUnit(self, newImageUnit, v)

            table.insert(showListUI, newImageUnit)
        end
    end

    KUtil.addScrollView(scrollView, showListUI, false, nil, false, true)

end

function KUIServiceActivityNode:refreshUI()
    initData(self)
    refreshScrollView(self)
end

function KUIServiceActivityNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_1")
    local imageBase         = projectNode:getChildByName("Image_base")

    local buttonClose = imageBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseClick~")
            KSound.playEffect("close")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    local buttonGotoShop    = imageBase:getChildByName("Button_goto_shop")
    local function onGotoShop(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onGotoShop~") 
            KSound.playEffect("click")
            self._parent:addNode("Shop")
        end
    end
    buttonGotoShop:addTouchEventListener(onGotoShop)
end

function KUIServiceActivityNode:registerAllCustomEvent()
end

return KUIServiceActivityNode