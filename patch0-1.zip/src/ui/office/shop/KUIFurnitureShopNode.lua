--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIFurnitureShopNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/20   10:00
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local TAB_INDEX      = 3
local m_tTabName     = {"Button_diamond_sheet", "Button_item_sheet", "Button_furniture_sheet", [5] = "Button_clothing_sheet",}
local m_tTabType     = {DIAMOND = 1, ITEM = 2, FURNITURE = 3, SKIN = 5}
local m_bOpenDiamaon = true
local m_bOpenSkin    = true

local m_tCoinTypeTexture = { 
    [ITEM_TYPE.CURRENCY] =
    {
        [CURRENCY_TYPE.COIN]       = "res/ui/ui_material/public/common_diamond.png",
        [CURRENCY_TYPE.FURNITURE]  = "res/ui/ui_material/public/common_furniture_currency.png",
    },
}

local m_tBuyTexture = {
    ["normal"]     = "res/ui/ui_material/public/button_currency_green.png",
    ["press"]      = "res/ui/ui_material/public/button_currency_green_active.png",
    ["disable"]    = "res/ui/ui_material/public/button_currency_disable.png",
}

local m_tLabelTexture = {
    ["highlight"] = "res/ui/ui_material/furniture/furniture_labeling.png",
    ["normal"]    = "res/ui/ui_material/furniture/furniture_labeling_2.png",
}

local KUIFurnitureShopNode = class(
    "KUIFurnitureShopNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIFurnitureShopNode:ctor()
    self._mainLayout   = nil
    self._parent       = nil
    self._uiPath       = nil
    self._baseControl  = nil
    self._showDataList = {}
    self._pageData     = {}

    self._selectTab    = 0
    self._selectItem   = 0
    self._closeEffect  = false
end

function KUIFurnitureShopNode.create(owner)
    local currentNode   = KUIFurnitureShopNode.new()

    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_shop_furniture.csb"
    currentNode:init()

    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("Image_sd_board")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_shop_bottom"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_left")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_shop_furniture_left"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRightAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_right")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_shop_furniture_right"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimationToFrame(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("Image_sd_board")
    local stopFrame       = 20
    local animationName   = "ani_shop_bottom"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    local projectNode     = mainNode:getChildByName("ProjectNode_left")
    local stopFrame       = 70
    local animationName   = "ani_shop_furniture_left"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    local projectNode     = mainNode:getChildByName("ProjectNode_right")
    local stopFrame       = 70
    local animationName   = "ani_shop_furniture_right"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    KUtil.stopCommonToFrame(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        if self._closeEffect and self._selectTab ~= 0 then
            table.insert(framesList, playLeftAnimation(self, false))
            table.insert(framesList, playRightAnimation(self, false))
        end
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "FurnitureShop", callBacks, isReturnOffice)
end

local function getSortListByType(type)
    local itemList = {}
    for _, itemInfo in pairs(KConfig.shop) do
        if itemInfo.nType == TAB_INDEX then
            local furniture = KConfig.furniture[itemInfo.nItemID]
            if furniture and furniture.nType == type then
                table.insert(itemList, itemInfo)
            end
        end
    end
    local function sortFunc(item1, item2)
        return item1.nIndex < item2.nIndex
    end
    table.sort(itemList, sortFunc)
    return itemList
end

local function haveFurnitrue(nTemplateID)
    for _, furniture in pairs(KPlayer.tFurnitureData.tFurnitureList) do
        if furniture.nTemplateID == nTemplateID then
            return true
        end
    end
end

local function handleRequest(nID)
    local config = KConfig.shop[nID]
    if not config then return end
    local number   = config.nItemCount
    local price    = config.nPrice
    local itemName = config.szName
    if config.nType == m_tTabType.FURNITURE then
        local function onConfirm()
            require("src/network/KC2SProtocolManager"):buyFurniture(nID)
        end
        local showString = KUtil.getStringByKey("shop.buyGoodTip")
        local szCoinName = KUtil.getItemName(config.nCoinType, config.nCoinID)
        showString = string.format(showString, price, szCoinName, number, itemName)
        showConfirmation(showString, onConfirm)
    end
end

local function showBuySuccessTip(nID)
    local config = KConfig.shop[nID]
    if not config then return end
    local number   = config.nItemCount
    local itemName = config.szName
    showNoticeByID("shop.buyGoodSuccess", number, itemName)
end

local function refreshDiableArea(self)
    local mainNode        = self._mainLayout
    local projectBottom   = mainNode:getChildByName("Image_sd_board")
    local panelShopBottom = projectBottom:getChildByName("Panel_shop_bottom")
    local imageBottomBase = panelShopBottom:getChildByName("Image_bottom_button_base")

    if not m_bOpenDiamaon then 
        local buttonDiamond   = imageBottomBase:getChildByName("Button_diamond_sheet")
        KUtil.setTouchEnabled(buttonDiamond, false)
    end

    if not m_bOpenSkin then 
        local buttonSkin   = imageBottomBase:getChildByName("Button_clothing_sheet")
        KUtil.setTouchEnabled(buttonSkin, false)
    end
end

local function refreshFurnitureCoin(self)
    local mainNode          = self._mainLayout
    local projectLeft       = mainNode:getChildByName("ProjectNode_left")
    local panelLeft         = projectLeft:getChildByName("Panel_shop_furniture_left")
    local imageMaterialBase = panelLeft:getChildByName("Image_material_base")
    local textFurnitureCoin = imageMaterialBase:getChildByName("Text_oil_value_text")

    textFurnitureCoin:setString(KPlayer.furnitureCoin)
end

local function changeFurnitureTabStatus(self, selectType)
    local mainNode = self._mainLayout
    local panelLabeling = mainNode:getChildByName("Panel_labeling")
    for nType = 1, MAX_FURNITURE_INDEX do
        local imageLabel = panelLabeling:getChildByName("Image_labeling_" .. nType)
        if nType == selectType then
            imageLabel:loadTexture(m_tLabelTexture.highlight)
        else
            imageLabel:loadTexture(m_tLabelTexture.normal)
        end
    end
end

local function changeFurnitureDetailStatus(self, isShow)
    playLeftAnimation(self, isShow)
    playRightAnimation(self, isShow)

    local mainNode        = self._mainLayout
    local resourceProject = mainNode:getChildByName("ProjectNode_resource_base")
    local resourcePanel   = resourceProject:getChildByName("Panel_1")
    local buttonClose     = resourcePanel:getChildByName("Button_close")
    local buttonReturn    = mainNode:getChildByName("Button_return")

    buttonClose:setVisible(not isShow)
    buttonReturn:setVisible(isShow)
    if not isShow then
        self._selectTab     = 0
        self._selectItem    = 0
    end
end

local function refreshItemSelect(self, lastID, currentID)
    -- reset touch enable
    local mainNode       = self._mainLayout
    local projectLeft    = mainNode:getChildByName("ProjectNode_left")
    local panelLeft      = projectLeft:getChildByName("Panel_shop_furniture_left")
    local panelFurniture = panelLeft:getChildByName("Panel_furniture_purchase")
    local imageLeft      = panelFurniture:getChildByName("Image_left")
    local scrollView     = imageLeft:getChildByName("ScrollView_list")

    local buttonDetail = ccui.Helper:seekWidgetByName(scrollView, tostring(lastID))
    if buttonDetail then
        buttonDetail:setBrightStyle(ccui.BrightStyle.normal)
        buttonDetail:setTouchEnabled(true)
    end
    local buttonDetail = ccui.Helper:seekWidgetByName(scrollView, tostring(currentID))
    if buttonDetail then
        buttonDetail:setBrightStyle(ccui.BrightStyle.highlight)
        buttonDetail:setTouchEnabled(false)
    end
end

local function refreshRightPanel(self, nShopID)
    local mainNode         = self._mainLayout
    local projectNode      = mainNode:getChildByName("ProjectNode_right")

    local panelDetail      = projectNode:getChildByName("Panel_furniture_purchase")
    local panelRight       = panelDetail:getChildByName("Image_information_base")
    local panelThemes      = panelRight:getChildByName("Panel_themes")
    local panelTitle       = panelRight:getChildByName("Panel_title")
    
    local imageIcon        = panelThemes:getChildByName("Image_themes")
    local textName         = panelRight:getChildByName("Text_name")
    local textIntroduction = panelRight:getChildByName("Text_introduction")
    local buttonBuy        = panelDetail:getChildByName("Button_buy")
    local haveItem         = (nShopID ~= 0)
    
    imageIcon:setVisible(haveItem)
    textName:setVisible(haveItem)
    textIntroduction:setVisible(haveItem)
    panelTitle:setVisible(haveItem)
    buttonBuy:setVisible(haveItem)
    if not haveItem then return end

    local shopConfig = KConfig.shop[nShopID]
    if not shopConfig then return end

    local nTemplateID = shopConfig.nItemID
    local furnitureInfo = KConfig.furniture[nTemplateID]
    if not furnitureInfo then return end

    local filePath = KUtil.getFurniturePath(nTemplateID)
    imageIcon:loadTexture(filePath)

    for nType = 1, MAX_FURNITURE_INDEX do
        local folderName = KUtil.getFurnitureFolderByType(nType)
        local uiName     = "Image_title_" .. folderName
        local imageTitle = panelTitle:getChildByName(uiName)
        if imageTitle then imageTitle:setVisible(nType == furnitureInfo.nType) end
    end

    textName:setString(furnitureInfo.szName)
    textIntroduction:setString(furnitureInfo.szDescribe)

    local imageCoin = buttonBuy:getChildByName("Image_common_currency")
    imageCoin:loadTexture(m_tCoinTypeTexture[shopConfig.nCoinType][shopConfig.nCoinID])

    local textCost = buttonBuy:getChildByName("Text_cost")
    textCost:setString(shopConfig.nPrice)

    local haveBuy  = haveFurnitrue(nTemplateID)
    if haveBuy then
        buttonBuy:loadTextures(m_tBuyTexture.disable, m_tBuyTexture.disable, m_tBuyTexture.disable)
        buttonBuy:setEnabled(false)
    else
        buttonBuy:loadTextures(m_tBuyTexture.normal, m_tBuyTexture.press, m_tBuyTexture.disable)
        buttonBuy:setEnabled(true)
    end
end

local function itemSelectChange(self, lastID, currentID)
    self._selectItem = currentID
    refreshItemSelect(self, lastID, self._selectItem)
    refreshRightPanel(self, self._selectItem)
end

local function updateItem(self, newControl, itemData, buyMap)
    newControl:setName(tostring(itemData.nID))
    local furnitureInfo = KConfig.furniture[itemData.nItemID]
    local panelclipping = newControl:getChildByName("Panel_icon")
    local imageIcon = panelclipping:getChildByName("Image_icon")
    local filePath = KUtil.getFurniturePath(itemData.nItemID)
    imageIcon:loadTexture(filePath)
    local filePath, scaleRatio  = KUtil.getRewardItemPathAndScale(ITEM_TYPE.FURNITURE, itemData.nItemID)
    imageIcon:setScale(scaleRatio * 1.3)

    local textTitle = newControl:getChildByName("Text_unit_title")
    textTitle:setString(furnitureInfo.szName)

    local textCoin = newControl:getChildByName("Text_unit_descrition")
    textCoin:setString(furnitureInfo.szDescribe)

    local imageCoin = newControl:getChildByName("Image_common_currency")
    imageCoin:loadTexture(m_tCoinTypeTexture[itemData.nCoinType][itemData.nCoinID])

    local textCoin = newControl:getChildByName("Text_money")
    textCoin:setString(tostring(itemData.nPrice))

    local imageIconBuy = newControl:getChildByName("Image_icon_buy")
    imageIconBuy:setVisible(true)
    if not buyMap[itemData.nItemID] then
        imageIconBuy:setVisible(false)
    end

    local nShopID = itemData.nID
    local function onDetail(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onDetail~")
            KSound.playEffect("click")
            itemSelectChange(self, self._selectItem, nShopID)
        end
    end
    newControl:setBrightStyle(ccui.BrightStyle.normal)
    newControl:setTouchEnabled(true)
    newControl:addTouchEventListener(onDetail)
end

local function refreshScrollView(self, selectType)
    local mainNode       = self._mainLayout
    local projectLeft    = mainNode:getChildByName("ProjectNode_left")
    local panelLeft      = projectLeft:getChildByName("Panel_shop_furniture_left")
    local panelFurniture = panelLeft:getChildByName("Panel_furniture_purchase")
    local imageLeft      = panelFurniture:getChildByName("Image_left")
    local scrollView     = imageLeft:getChildByName("ScrollView_list")

    self._showDataList   = getSortListByType(selectType)

    local buyMap = {}
    for _, furniture in pairs(KPlayer.tFurnitureData.tFurnitureList) do
        buyMap[furniture.nTemplateID] = true
    end

    local refreshCall = function(control, dataInfo)
        updateItem(self, control, dataInfo, buyMap)
    end

    local showRow    = 5
    local showColumn = 2
    local spanY      = 38
    local spanX      = 5
    local parameters = {
        scrollView  = scrollView,
        itemBase    = self._baseControl,
        dataList    = self._showDataList,
        refreshCall = refreshCall,
        row         = showRow,
        column      = showColumn,
        spanY       = spanY,
        spanX       = spanX,
    }

    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function refreshLeftPanel(self, nShopID)
    local mainNode       = self._mainLayout
    local projectLeft    = mainNode:getChildByName("ProjectNode_left")
    local panelLeft      = projectLeft:getChildByName("Panel_shop_furniture_left")
    local panelFurniture = panelLeft:getChildByName("Panel_furniture_purchase")
    local imageLeft      = panelFurniture:getChildByName("Image_left")
    local scrollView     = imageLeft:getChildByName("ScrollView_list")
    local newControl     = ccui.Helper:seekWidgetByName(scrollView, tostring(nShopID))
    if not newControl then return end

    local itemData = HArray.FindFirst(self._showDataList, "nID", nShopID)
    if not itemData then return end
    
    local buyMap = {}
    for _, furniture in pairs(KPlayer.tFurnitureData.tFurnitureList) do
        buyMap[furniture.nTemplateID] = true
    end
    updateItem(self, newControl, itemData, buyMap)
end

local function refreshTabChange(self, selectType)
    if self._selectTab == selectType then return end
    if self._selectTab ~= 0 then return end
    changeFurnitureTabStatus(self, selectType)
    changeFurnitureDetailStatus(self, true)
    refreshScrollView(self, selectType)
    self._selectTab  = selectType

    self._selectItem = 0
    if #self._showDataList > 0 then
        self._selectItem = self._showDataList[1].nID
    end
    itemSelectChange(self, 0, self._selectItem)
end

local function initUI(self)
    local mainNode       = self._mainLayout
    local projectLeft    = mainNode:getChildByName("ProjectNode_left")
    local panelLeft      = projectLeft:getChildByName("Panel_shop_furniture_left")
    local panelFurniture = panelLeft:getChildByName("Panel_furniture_purchase")
    local imageLeft      = panelFurniture:getChildByName("Image_left")
    local scrollView     = imageLeft:getChildByName("ScrollView_list")

    self._baseControl    = scrollView:getChildByName("Button_unit_base_1")
    self._baseControl:retain()

    scrollView:removeAllChildren()
end

function KUIFurnitureShopNode:getEnterAction()
end

function KUIFurnitureShopNode:getExitAction()
    if self._closeEffect then
        return require("src/ui/uibase/KUINodeBase").getExitAction(self)
    end
end

function KUIFurnitureShopNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimationToFrame(self)
    initUI(self)
end

function KUIFurnitureShopNode:refreshUI()
    refreshFurnitureCoin(self)
    refreshDiableArea(self)
end

function KUIFurnitureShopNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        self._closeEffect = true
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "sd_base")

    local mainNode              = self._mainLayout
    local panelFurniture        = mainNode:getChildByName("Panel_furniture_base")
    local imageCommonProject    = panelFurniture:getChildByName("ProjectNode_furniture_base")
    local imageCommonBackground = imageCommonProject:getChildByName("Panel__furniture_background")
    local panelLabeling         = mainNode:getChildByName("Panel_labeling")
    for nType = 1, MAX_FURNITURE_INDEX do
        local folderName = KUtil.getFurnitureFolderByType(nType)
        local uiName = "Image_" .. folderName
        local buttonFurniture = imageCommonBackground:getChildByName(uiName)
        buttonFurniture:setTouchEnabled(true)

        local selectType = nType
        local function onTabClick(sender, type)
            if type == ccui.TouchEventType.began then
                KUtil.setWidgetBright(buttonFurniture)
            elseif type == ccui.TouchEventType.ended then
                KUtil.setWidgetNormal(buttonFurniture)
                refreshTabChange(self, selectType)
            elseif type == ccui.TouchEventType.canceled then
                KUtil.setWidgetNormal(buttonFurniture)
            end
        end
        buttonFurniture:addTouchEventListener(onTabClick)

        local imageLabel = panelLabeling:getChildByName("Image_labeling_" .. nType)
        imageLabel:setTouchEnabled(true)
        imageLabel:addTouchEventListener(onTabClick)
    end

    local buttonFloor  = mainNode:getChildByName("Button_flood")
    local function onDetailClick(sender, type)
        local folderName      = KUtil.getFurnitureFolderByType(FURNITURE_TYPE.FLOOR)
        local uiName          = "Image_" .. folderName
        local buttonFurniture = imageCommonBackground:getChildByName(uiName)

        if type == ccui.TouchEventType.began then
            KUtil.setWidgetBright(buttonFurniture)
        elseif type == ccui.TouchEventType.ended then
            KUtil.setWidgetNormal(buttonFurniture)
            refreshTabChange(self, FURNITURE_TYPE.FLOOR)
        elseif type == ccui.TouchEventType.canceled then
            KUtil.setWidgetNormal(buttonFurniture)
        end
    end
    buttonFloor:addTouchEventListener(onDetailClick)

    local projectBottom   = mainNode:getChildByName("Image_sd_board")
    local panelShopBottom = projectBottom:getChildByName("Panel_shop_bottom")
    local imageBottomBase = panelShopBottom:getChildByName("Image_bottom_button_base")

    for type, buttonName in pairs(m_tTabName) do
        local buttonTab = imageBottomBase:getChildByName(buttonName)
        local tabType = type
        local function onTabClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                self._parent:removeNode("FurnitureShop")
                self._parent:addNode("Shop", {initTab = tabType})
            end
        end
        if m_tTabType.FURNITURE == tabType then
            buttonTab:setBrightStyle(ccui.BrightStyle.highlight)
            buttonTab:setTouchEnabled(false)
        end
        buttonTab:addTouchEventListener(onTabClick)
    end

    --Return Button
    local buttonReturn = mainNode:getChildByName("Button_return")
    local function onReturnClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onReturnClick~")
            KSound.playEffect("click")
            changeFurnitureDetailStatus(self, false)
            changeFurnitureTabStatus(self, 0)
        end
    end
    buttonReturn:addTouchEventListener(onReturnClick)
    buttonReturn:setVisible(false)

    --buy Button
    local projectNode      = mainNode:getChildByName("ProjectNode_right")
    local panelDetail      = projectNode:getChildByName("Panel_furniture_purchase")
    local buttonBuy        = panelDetail:getChildByName("Button_buy")
    local function onBuyClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onBuyClick~")
            KSound.playEffect("click")
            if self._selectItem == 0 then return end
            handleRequest(self._selectItem)
        end
    end
    buttonBuy:addTouchEventListener(onBuyClick)
end

function KUIFurnitureShopNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBuyFurnitureSuccess(goodID)
        cclog("----------> onEvent NET_BUY_FURNITURE %d", goodID)
        refreshFurnitureCoin(self)
        refreshRightPanel(self, goodID)
        refreshLeftPanel(self, goodID)
        showBuySuccessTip(goodID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_FURNITURE, onBuyFurnitureSuccess) 

    local function onUpdateTop()
        KUtil.updateResourceInfo(self)
        refreshFurnitureCoin(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_COIN, onUpdateTop) 
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FURNITURE_COIN, onUpdateTop) 
end

function KUIFurnitureShopNode:onCleanup()
    self._baseControl:release()  
end

return KUIFurnitureShopNode
