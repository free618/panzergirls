--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShopNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/20   10:00
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local m_nPageSize       = 12
local m_tGoodStatus     = {NORMAL = 1, RECOMMEND = 2, SALE = 3, DAYLIMIT = 4, WEEKLIMIT = 5, LIMIT = 6, DOUBLE = 7 }
local m_tTabName        = {"Button_diamond_sheet", "Button_item_sheet", "Button_furniture_sheet", [5] = "Button_clothing_sheet", }
local m_bOpenDiamaon    = true
local m_bOpenSkin       = true

local m_tCoinTexture = {
    [1] = "res/ui/ui_material/shop/sd_diamond_1.png",
    [2] = "res/ui/ui_material/shop/sd_diamond_1.png",
    [3] = "res/ui/ui_material/shop/sd_diamond_1.png",
    [4] = "res/ui/ui_material/shop/sd_diamond_2.png",
    [5] = "res/ui/ui_material/shop/sd_diamond_3.png",
    [6] = "res/ui/ui_material/shop/sd_diamond_4.png",
}

local KUIShopNode = class(
    "KUIShopNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShopNode:ctor()
    self._mainLayout = nil
    self._parent     = nil
    self._uiPath     = nil
    self._panelBase  = nil
    self._pageIndex  = 0
    self._pageCount  = 0
    self._tabType    = 0
    self._multiBuyCount = 1
end

function KUIShopNode.create(owner, nodeData)
    local currentNode = KUIShopNode.new()

    currentNode._parent   = owner
    currentNode._uiPath   = "res/ui/layout_shop.csb"
    currentNode._nodeData = nodeData
    currentNode:init()

    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("Image_sd_board")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_shop_bottom"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playContentAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_content")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_shop_content"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playSkinAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_clothing")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_shop_clothing"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playInputAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_input")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_shop_clothing_input"

    local delayFrame = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    if isOpen then
        projectNode:setVisible(isOpen)
    else
        delayExecute(mainNode, function ()
            projectNode:setVisible(isOpen)
        end, delayFrame / KUtil.FRAME_PER_SECOND)
    end

    return delayFrame
end

local function playSearchAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_search")
    local panelScreen     = projectNode:getChildByName("Panel_screen")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_shop_cloting_type_search"

    local delay = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    if isOpen then
        projectNode:setVisible(isOpen)
    else
        delayExecute(mainNode, function ()
            projectNode:setVisible(isOpen)
        end, delay)
    end

    panelScreen:setVisible(isOpen)

    return delay
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("Image_sd_board")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_content")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_clothing")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_input")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_search")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function stopAllAnimationToFrame(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("Image_sd_board")
    local stopFrame       = 20
    local animationName   = "ani_shop_bottom"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    local projectNode     = mainNode:getChildByName("ProjectNode_content")
    local stopFrame       = 30
    local animationName   = "ani_shop_content"
    KUtil.stopProjectToFrame(projectNode, animationName, stopFrame)

    local projectNode     = mainNode:getChildByName("ProjectNode_clothing")
    projectNode:stopAllActions()

    KUtil.stopCommonToFrame(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        table.insert(framesList, playContentAnimation(self, false))
        if self._tabType == KUtil.shopType.SKIN then
            table.insert(framesList, playSkinAnimation(self, false))
        end
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Shop", callBacks, isReturnOffice)
end

local function playShopMultiBuyAnimation(self, isOpen)
    local mainNode                  = self._mainLayout
    local shopMultiBuyNode          = mainNode:getChildByName("shopMultiBuyNode")
    if not shopMultiBuyNode then return 0 end
    local openEndFrame    = 15
    local closeStartFrame = 50
    local animationName   = "ani_shop_multi_buy"
    return KUtil.playPanelAnimation(shopMultiBuyNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function addShopMultiBuyCount(self, shopItemInfo, addBuyCount)
    local mainNode                  = self._mainLayout
    local shopMultiBuyNode          = mainNode:getChildByName("shopMultiBuyNode")
    if not shopMultiBuyNode then return end

    local imagePopupBase            = shopMultiBuyNode:getChildByName("Image_popup_base")
    local textNumber                = imagePopupBase:getChildByName("Text_number")
    local textTotalNumber           = imagePopupBase:getChildByName("Text_total_number")
        
    local buyCount                  = self._multiBuyCount
    buyCount                        = buyCount + addBuyCount
    buyCount                        = math.max(buyCount, 1)

    local shopItemID                = shopItemInfo.nID
    local shopConfig                = KConfig.shop[shopItemID]
    assert(shopConfig)

    local totalCoin                 = KPlayer.coin
    local itemPrice                 = shopConfig.nPrice
    local maxDiamondBuyCount        = math.floor(totalCoin / itemPrice)

    local canBuyLimitCount          = KUtil.canBuyLimitCount(shopItemID)
    local nMaxOnceBuyCount          = shopConfig.nMaxOnceBuyCount

    buyCount = math.min(buyCount, maxDiamondBuyCount)
    
    if canBuyLimitCount > 0 then
        buyCount = math.min(buyCount, canBuyLimitCount)
    end
    
    if nMaxOnceBuyCount > 0 then
        buyCount = math.min(buyCount, nMaxOnceBuyCount)
    end
    
    buyCount                = math.max(buyCount, 1)
    self._multiBuyCount     = buyCount
    local totalPrice        = buyCount * shopConfig.nPrice
    textNumber:setString(tostring(buyCount))
    textTotalNumber:setString(tostring(totalPrice))
end

local function initShopMultiBuy(self, shopItemInfo)
    local mainNode                  = self._mainLayout
    local shopMultiBuyNode          = mainNode:getChildByName("shopMultiBuyNode")
    if not shopMultiBuyNode then return end
    
    self._multiBuyCount             = 1
    addShopMultiBuyCount(self, shopItemInfo, 0)

    local imagePopupBase            = shopMultiBuyNode:getChildByName("Image_popup_base")    
    local textRemainNumberDes       = imagePopupBase:getChildByName("Text_remain_number_descrtion")
    local textRemainNumber          = imagePopupBase:getChildByName("Text_remain_number")
    
    local canBuyLimitCount          = KUtil.canBuyLimitCount(shopItemInfo.nID)
    local showRemain                = canBuyLimitCount > 0
    textRemainNumberDes:setVisible(showRemain)
    textRemainNumber:setVisible(showRemain)
    textRemainNumber:setString(tostring(canBuyLimitCount))

    local buttonMinus               = imagePopupBase:getChildByName("Button_minus")
    local function onMinusClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMinusClick~~")
            addShopMultiBuyCount(self, shopItemInfo, -1)
        end
    end
    buttonMinus:addTouchEventListener(onMinusClick)

    local buttonAdd                 = imagePopupBase:getChildByName("Button_add")
    local function onAddClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onAddClick~~")
            addShopMultiBuyCount(self, shopItemInfo, 1)
        end
    end
    buttonAdd:addTouchEventListener(onAddClick)

    local buttonMinusTen            = imagePopupBase:getChildByName("Button_minus_ten")
    local function onMinusTenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onMinusTenClick~~")
            addShopMultiBuyCount(self, shopItemInfo, -10)
        end
    end
    buttonMinusTen:addTouchEventListener(onMinusTenClick)

    local buttonAddTen              = imagePopupBase:getChildByName("Button_add_ten")
    local function onAddTenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onAddTenClick~~")
            addShopMultiBuyCount(self, shopItemInfo, 10)
        end
    end
    buttonAddTen:addTouchEventListener(onAddTenClick)

    local buttonClose               = imagePopupBase:getChildByName("Button_close")
    local function onCloseShopMultiBuy(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseShopMultiBuy~~")
            local function close()
                local shopMultiBuyNode  = mainNode:getChildByName("shopMultiBuyNode")
                if not shopMultiBuyNode then return end
                mainNode:removeChild(shopMultiBuyNode)
            end
            local delayFrame = playShopMultiBuyAnimation(self, false)
            local delayTime = math.max(delayFrame / KUtil.FRAME_PER_SECOND, 0)
            delayExecute(mainNode, close, delayTime)
        end
    end
    buttonClose:addTouchEventListener(onCloseShopMultiBuy)

    local buttonCancel              = imagePopupBase:getChildByName("Button_cancel")
    buttonCancel:addTouchEventListener(onCloseShopMultiBuy)

    local buttonConform             = imagePopupBase:getChildByName("Button_conform")
    local function onConformClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConformClick~~")
            local goodID = shopItemInfo.nID
            local buyCount = self._multiBuyCount
            require("src/network/KC2SProtocolManager"):buyGood(goodID, buyCount)
            onCloseShopMultiBuy(sender, type)
        end
    end
    buttonConform:addTouchEventListener(onConformClick)
end

local function showShopMultiBuy(self, shopItemInfo)
    local mainNode                  = self._mainLayout
    local shopMultiBuyNode          = mainNode:getChildByName("shopMultiBuyNode")
    if not shopMultiBuyNode then
        shopMultiBuyNode          = cc.CSLoader:createNode("res/ui/animation_node/ani_shop_multi_buy.csb")
        shopMultiBuyNode:setName("shopMultiBuyNode")
        mainNode:addChild(shopMultiBuyNode, 99)
    end

    shopMultiBuyNode:stopAllActions()
    initShopMultiBuy(self, shopItemInfo)
    playShopMultiBuyAnimation(self, true)    
end

local function refreshDiableArea(self)
    local mainNode        = self._mainLayout
    local projectBottom   = mainNode:getChildByName("Image_sd_board")
    local panelShopBottom = projectBottom:getChildByName("Panel_shop_bottom")
    local imageBottomBase = panelShopBottom:getChildByName("Image_bottom_button_base")

    if not m_bOpenDiamaon then 
        local buttonDiamond   = imageBottomBase:getChildByName("Button_diamond_sheet")
        KUtil.setTouchEnabled(buttonDiamond, false)
    end

    if not m_bOpenSkin then 
        local buttonSkin   = imageBottomBase:getChildByName("Button_clothing_sheet")
        KUtil.setTouchEnabled(buttonSkin, false)
    end
end

local function refreshDiamond(self)
    local mainNode          = self._mainLayout
    local projectContent    = mainNode:getChildByName("ProjectNode_content")
    local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
    local textDiamond       = panelShopContent:getChildByName("Text_dimond_data")
    textDiamond:setString(KPlayer.coin)

    local projectClothing    = mainNode:getChildByName("ProjectNode_clothing")
    local imageShopBase      = projectClothing:getChildByName("Image_shop_base")
    local textDiamond        = imageShopBase:getChildByName("BitmapFontLabel_diamand")
    textDiamond:setString(KPlayer.coin)
end

local function pageChange(self)
    local mainNode          = self._mainLayout
    local projectContent    = mainNode:getChildByName("ProjectNode_content")
    local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
    local panelPageViewBase = panelShopContent:getChildByName("Image_sd_showcase_base")
    local pageView          = panelPageViewBase:getChildByName("PageView_item_list")

    local pageCount   = self._pageCount
    local currentPage = pageView:getCurPageIndex()
    if self._pageIndex < 0 then 
        self._pageIndex = pageCount - 1
    elseif self._pageIndex > pageCount - 1 then 
        self._pageIndex = 0
    end
    pageView:scrollToPage(self._pageIndex) 
end

local function updateOneItem(self, itemUI, itemInfo, itemIndex)
    if not itemInfo then itemUI:setVisible(false) return end
    itemUI:setVisible(true)
    itemUI:setName(tostring(itemInfo.nID))

    local goodStatus = itemInfo.nStatus
    local tabType    = itemInfo.nType

    local imageRecommend = itemUI:getChildByName("Image_sd_recommend")
    imageRecommend:setVisible(m_tGoodStatus.RECOMMEND == goodStatus)

    local imageLimit = itemUI:getChildByName("Image_sd_limit")
    imageLimit:setVisible(m_tGoodStatus.LIMIT == goodStatus)

    local imageSale = itemUI:getChildByName("Image_sd_sale")
    imageSale:setVisible(m_tGoodStatus.SALE == goodStatus)

    local imageDailyLimit = itemUI:getChildByName("Image_sd_daily_limit")
    imageDailyLimit:setVisible(m_tGoodStatus.DAYLIMIT == goodStatus)

    local imageWeekLimit = itemUI:getChildByName("Image_sd_week_limit")
    imageWeekLimit:setVisible(m_tGoodStatus.WEEKLIMIT == goodStatus)

    local isShowDouble = KUtil.isShowDouble(itemInfo.nID)
    isShowDouble = isShowDouble and (m_tGoodStatus.DOUBLE == goodStatus)
    local imageDouble = itemUI:getChildByName("Image_sd_double")
    imageDouble:setVisible(isShowDouble)

    local textName = itemUI:getChildByName("Text_item_name")
    if KUtil.shopType.DIAMOND == tabType then
        local coinLocalizedName = KUtil.getCoinLocalizedName(itemInfo)
        cclog("----------> coinLocalizedName -> " .. coinLocalizedName)
        textName:setString(coinLocalizedName)
    else
        textName:setString(itemInfo.szName)
    end

    local textDescription = itemUI:getChildByName("Text_item_description")
    textDescription:setString(itemInfo.szDescription)
    
    local goodType, goodID, goodNum = itemInfo.nItemType, itemInfo.nItemID, itemInfo.nItemCount
    local imageGood = itemUI:getChildByName("Image_cost_diamond")
    
    if KUtil.shopType.DIAMOND == tabType then
        if itemIndex > #m_tCoinTexture then itemIndex = #m_tCoinTexture end
        local filePath = m_tCoinTexture[itemIndex]
        imageGood:loadTexture(filePath)
    else
        local filePath, scale = KUtil.getRewardItemPathAndScale(goodType, goodID)
        imageGood:loadTexture(filePath)
        imageGood:setScale(scale * 1.5)
    end
    local textNumber = itemUI:getChildByName("Text_item_number")
    textNumber:setString(tostring(goodNum))
    
    itemUI:setTouchEnabled(true)
    itemUI:setSwallowTouches(false)
    local goodID = itemInfo.nID
    local bBuy   = KUtil.isCanBuy(goodID)
    KUtil.setTouchEnabled(itemUI, bBuy)
    local function onClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("buy Good, goodID = :" .. goodID)
            if itemInfo.nType == KUtil.shopType.ITEM and itemInfo.nMaxOnceBuyCount > 1 then
                showShopMultiBuy(self, itemInfo)
            else
                KUtil.buyRequest(KUtil.shopType.DIAMOND, goodID)
            end
        end
    end
    itemUI:addTouchEventListener(onClick)

    local textCost = itemUI:getChildByName("Text_cost")
    textCost:setString(tostring(itemInfo.nPrice))
    
    local imageDiamond = itemUI:getChildByName("Image_good")
    imageDiamond:setVisible(KUtil.shopType.DIAMOND ~= tabType)

    local textMoney = itemUI:getChildByName("Text_cost_rmb")
    textMoney:setVisible(KUtil.shopType.DIAMOND == tabType)
end

local function refreshPageView(self)
    local mainNode          = self._mainLayout
    local projectContent    = mainNode:getChildByName("ProjectNode_content")
    local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
    local panelPageViewBase = panelShopContent:getChildByName("Image_sd_showcase_base")
    local pageView          = panelPageViewBase:getChildByName("PageView_item_list")

    pageView:removeAllPages()

    local row, column = 3, 4
    local itemListData = KUtil.getSortListByType(self._tabType)
    local count        = #itemListData
    local pageCount    = (count - 1)/m_nPageSize + 1
    local nodeList     = {}
    for pageIndex = 1, pageCount do
        local panelUI = self._panelBase:clone()
        pageView:addPage(panelUI)
        --update item ui
        for itemIndex = 1, m_nPageSize do
            local currentIndex   = (pageIndex - 1) * m_nPageSize + itemIndex
            local itemInfo       = itemListData[currentIndex]
            local itemUI         = panelUI:getChildByName(string.format("Item_Base%d", itemIndex))
            nodeList[#nodeList + 1] = itemUI
            updateOneItem(self, itemUI, itemInfo, #nodeList)
        end
    end
    --need delay one frame
    local func = function()
        pageView:scrollToPage(0)
        self._pageIndex = pageView:getCurPageIndex()
    end
    delayExecute(pageView, func, 0.0)
    KUtil.delayShowList(nodeList, row, column)
    self._pageCount = pageCount
end

local function changeTabButton(self, tabType)
    if tabType == KUtil.shopType.FURNITURE then
        self._parent:removeNode("Shop")
        self._parent:addNode("FurnitureShop")
        return
    end

    local mainNode        = self._mainLayout
    local projectBottom   = mainNode:getChildByName("Image_sd_board")
    local panelShopBottom = projectBottom:getChildByName("Panel_shop_bottom")
    local imageBottomBase = panelShopBottom:getChildByName("Image_bottom_button_base")

    for type, buttonName in pairs(m_tTabName) do
        local buttonTab = imageBottomBase:getChildByName(buttonName)
        if type == tabType then
            buttonTab:setBrightStyle(ccui.BrightStyle.highlight)
            buttonTab:setTouchEnabled(false)
        else
            buttonTab:setBrightStyle(ccui.BrightStyle.normal)
            buttonTab:setTouchEnabled(true)
        end
    end

    refreshDiableArea(self)
    if self._tabType == tabType then return end

    if self._tabType == KUtil.shopType.SKIN then
        playSkinAnimation(self, false)
        playContentAnimation(self, true)
    end

    self._tabType = tabType

    if tabType == KUtil.shopType.SKIN then
        self:showSkinByTime()
        playContentAnimation(self, false)
        playSkinAnimation(self, true)
        return
    end

    refreshPageView(self)
end

local function updateScrollSkin(self, newButtonSkin, shopConfig)
    local skinConfig = KConfig.skin[shopConfig.nItemID]
    assert(skinConfig, "skin config error, shopID:" .. shopConfig.nID)

    local skinList = KPlayer.tSkinData.tSkinList
    newButtonSkin:setName(skinConfig.nID)

    local panelIcon  = newButtonSkin:getChildByName("Panel_icon")
    local imageIcon  = panelIcon:getChildByName("Image_icon")

    local buttonUnit = newButtonSkin:getChildByName("Button_unit")
    local skinName   = buttonUnit:getChildByName("Text_name")
    local textPrice  = buttonUnit:getChildByName("Text_price")
    local imageOnw   = newButtonSkin:getChildByName("Image_haven_flag")

    local imagePath = KUtil.getSkinImagePathByID(skinConfig.nID, 0)
    imageIcon:loadTexture(imagePath)
    skinName:setString(shopConfig.szName)
    textPrice:setString(tostring(shopConfig.nPrice))

    local function onClickSkin(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("on select skin:" .. skinConfig.nID)

            local hasSkin = HArray.FindFirstByValue(skinList, skinConfig.nID)
            if hasSkin then
                showNoticeByID("errorCode257")
                return
            end

            self:showBuySkinComfirmation(shopConfig.nID)
        end
    end
    buttonUnit:addTouchEventListener(onClickSkin)

    local hasSkin = HArray.FindFirstByValue(skinList, skinConfig.nID)
    imageOnw:setVisible(hasSkin ~= nil)
end

local function initBuyConfirmNode(self)
    local buyConfirmNode            = cc.CSLoader:createNode("res/ui/animation_node/ani_shop_clothing_conform.csb")
    local projectNodePosition       = self._mainLayout:convertToWorldSpace(cc.p(0, 0))
    local posX, posY                = 0, 0
    self._mainLayout:addChild(buyConfirmNode, 100)
    buyConfirmNode:stopAllActions()
    buyConfirmNode:setPosition(cc.p(posX, posY))
    self._buySkinConfirmAnimation = KUtil.initAnimation(buyConfirmNode, "res/ui/animation_node/ani_shop_clothing_conform.csb")
    buyConfirmNode:setVisible(false)
    self._buyConfirmNode = buyConfirmNode
end

local function initUI(self)
    local mainNode          = self._mainLayout
    local projectContent    = mainNode:getChildByName("ProjectNode_content")
    local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
    local panelPageViewBase = panelShopContent:getChildByName("Image_sd_showcase_base")
    local pageView          = panelPageViewBase:getChildByName("PageView_item_list")
    self._panelBase         = pageView:getChildByName("Panel_Base")
    self._panelBase:retain()

    local projectClothing   = mainNode:getChildByName("ProjectNode_clothing")
    local imageShopBase     = projectClothing:getChildByName("Image_shop_base")
    local scrollView        = imageShopBase:getChildByName("ScrollView_1")
    self._skinPanelUnit     = scrollView:getChildByName("Panel_unit")
    self._skinPanelUnit:retain()

    local projectNode     = mainNode:getChildByName("ProjectNode_input")
    projectNode:setVisible(false)

    local projectNode     = mainNode:getChildByName("ProjectNode_search")
    local panelScreen     = projectNode:getChildByName("Panel_screen")
    panelScreen:setVisible(false)
    projectNode:setVisible(false)

    initBuyConfirmNode(self)
end

function KUIShopNode:getEnterAction()
    if self._nodeData then
        return
    end
    return require("src/ui/uibase/KUINodeBase").getEnterAction(self)
end

function KUIShopNode:getExitAction()
    if self._nodeData then
        return
    end
    return require("src/ui/uibase/KUINodeBase").getExitAction(self)
end

function KUIShopNode:onInitUI()
    KUtil.updateResourceInfo(self)
    initUI(self)
    if self._nodeData then
        stopAllAnimationToFrame(self)
    else
        stopAllAnimation(self)
    end
end

function KUIShopNode:refreshUI()
    refreshDiableArea(self)
    refreshDiamond(self)

    local initTab = KUtil.shopType.ITEM
    if m_bOpenDiamaon then
        initTab = KUtil.shopType.DIAMOND
    end
    if self._nodeData then initTab = self._nodeData.initTab end
    changeTabButton(self, initTab)
end

function KUIShopNode:onEnterActionFinished()
    if self._nodeData then return end
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playBottomAnimation(self, true)
    playContentAnimation(self, true)
end

function KUIShopNode:refreshSkinStatus(goodID)
    local mainNode          = self._mainLayout
    local projectClothing   = mainNode:getChildByName("ProjectNode_clothing")
    local imageShopBase     = projectClothing:getChildByName("Image_shop_base")
    local scrollView        = imageShopBase:getChildByName("ScrollView_1")
    local control           = scrollView:getChildByName(tostring(goodID))
    if control then
        local skinList   = KPlayer.tSkinData.tSkinList
        local goodConfig = KConfig.shop[goodID]
        local hasSkin = HArray.FindFirstByValue(skinList, goodConfig.nItemID)
        if hasSkin then
            local imageOnw   = control:getChildByName("Image_haven_flag")
            imageOnw:setVisible(true)
        end
    end
end

function KUIShopNode:setSkinScrollView(shopConfigList)
    local mainNode          = self._mainLayout
    local projectClothing   = mainNode:getChildByName("ProjectNode_clothing")
    local imageShopBase     = projectClothing:getChildByName("Image_shop_base")
    local scrollView        = imageShopBase:getChildByName("ScrollView_1")
    local slider            = imageShopBase:getChildByName("Slider_1")

    scrollView:removeAllChildren()

    local refreshCall = function(control, shopInfo)
        updateScrollSkin(self, control, shopInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = slider,
        itemBase    = self._skinPanelUnit,
        row         = 20,
        column      = 4,
        dataList    = shopConfigList,
        refreshCall = refreshCall,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

function KUIShopNode:showSkinByTime()
    local skinList   = {}
    for i = #KConfig.shop, 1, -1 do
        local shopConfig = KConfig.shop[i]
        if shopConfig.nItemType == ITEM_TYPE.SKIN and KUtil.isOpeningTime(KUtil.getCurrentServerTime(), shopConfig.otOpenTimes) then
            table.insert(skinList, shopConfig)
        end
    end
    self:setSkinScrollView(skinList)
end

function KUIShopNode:showSkinByType(tankType)
    local skinList   = {}
    for i = #KConfig.shop, 1, -1 do
        local shopConfig = KConfig.shop[i]
        if shopConfig.nItemType == ITEM_TYPE.SKIN and KUtil.isOpeningTime(KUtil.getCurrentServerTime(), shopConfig.otOpenTimes) then
            local skinConfig = KConfig.skin[shopConfig.nItemID]
            local cardIDList = string.split(skinConfig.szCardID, "|")
            for _, szCardID in ipairs(cardIDList) do
                local cardConfig = KConfig.cardInfo[tonumber(szCardID)]
                if cardConfig.nTankType == tankType then
                    table.insert(skinList, shopConfig)
                    break
                end
            end
        end
    end
    self:setSkinScrollView(skinList)
end

function KUIShopNode:searchSkinByKey(key)
    local skinList   = {}
    for i = #KConfig.shop, 1, -1 do
        local shopConfig = KConfig.shop[i]
        if shopConfig.nItemType == ITEM_TYPE.SKIN and KUtil.isOpeningTime(KUtil.getCurrentServerTime(), shopConfig.otOpenTimes) then
            if string.find(string.upper(shopConfig.szName), string.upper(key)) then
                table.insert(skinList, shopConfig)
            end
        end
    end
    self:setSkinScrollView(skinList)
end

function KUIShopNode:sortSkinByName()
    local skinList   = {}
    for i = #KConfig.shop, 1, -1 do
        local shopConfig = KConfig.shop[i]
        if shopConfig.nItemType == ITEM_TYPE.SKIN and KUtil.isOpeningTime(KUtil.getCurrentServerTime(), shopConfig.otOpenTimes) then
            table.insert(skinList, shopConfig)
        end
    end

    table.sort(skinList, function ( shopConfA, shopConfB )
        if shopConfA.szName ~= shopConfB.szName then
            return shopConfA.szName < shopConfB.szName
        end

        return shopConfA.nID < shopConfB.nID
    end)
    self:setSkinScrollView(skinList)
end

function KUIShopNode:showOwnSkin()
    local skinList   = {}
    local ownSkinList = KPlayer.tSkinData.tSkinList

    for i = #KConfig.shop, 1, -1 do
        local shopConfig = KConfig.shop[i]
        if shopConfig.nItemType == ITEM_TYPE.SKIN then
            local hasSkin = HArray.FindFirstByValue(ownSkinList, shopConfig.nItemID)
            if hasSkin then
                table.insert(skinList, shopConfig)
            end
            
        end
    end
    self:setSkinScrollView(skinList)
end

function KUIShopNode:showBuySkinComfirmation(goodID)
    local goodConfig = KConfig.shop[goodID]

    local buyConfirmNode   = self._buyConfirmNode
    local panel1           = buyConfirmNode:getChildByName("Panel_1")
    local panelIcon        = panel1:getChildByName("Panel_icon")
    local imageIcon        = panelIcon:getChildByName("Image_icon")
    local imagePath        = KUtil.getCardImagePathByConfigID(0, false, goodConfig.nItemID)
    imageIcon:loadTexture(imagePath)

    local imageSkinBase    = panel1:getChildByName("Image_skin_base")
    local skinName         = imageSkinBase:getChildByName("Text_character_name")
    skinName:setString(goodConfig.szName)

    local buttonCancel = buyConfirmNode:getChildByName("Button_cancel")
    local function onCancel(sender, type)
        if type ~= ccui.TouchEventType.ended then
            return
        end
        local delay = KUtil.playQuitAnimation(self._buySkinConfirmAnimation)
    end
    buttonCancel:addTouchEventListener(onCancel)

    local buttonConfirm = buyConfirmNode:getChildByName("Button_conform")
    local function onConfirm(sender, type)
        if type ~= ccui.TouchEventType.ended then
            return
        end
        local delay = KUtil.playQuitAnimation(self._buySkinConfirmAnimation)
        require("src/network/KC2SProtocolManager"):BuySkin(goodID)
    end
    buttonConfirm:addTouchEventListener(onConfirm)

    local diamondText = buttonConfirm:getChildByName("BitmapFontLabel_diamond")
    diamondText:setString(goodConfig.nPrice)

    buyConfirmNode:setVisible(true)
    KUtil.playEnterAnimation(self._buySkinConfirmAnimation, 0, 40)
end

function KUIShopNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "sd_base")

    local mainNode          = self._mainLayout
    local projectContent    = mainNode:getChildByName("ProjectNode_content")
    local projectClothing   = mainNode:getChildByName("ProjectNode_clothing")
    local projectSearch     = mainNode:getChildByName("ProjectNode_search")
    local projectInput      = mainNode:getChildByName("ProjectNode_input")
    local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
    local panelPageViewBase = panelShopContent:getChildByName("Image_sd_showcase_base")
    local pageView          = panelPageViewBase:getChildByName("PageView_item_list")

    --Page Right Button
    local buttonControl = panelPageViewBase:getChildByName("Button_right")
    local function onPageRightClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            cclog("click onPageRightButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex + 1
            pageChange(self)
        end
    end
    buttonControl:addTouchEventListener(onPageRightClick)

    --Page Left Button
    local buttonControl = panelPageViewBase:getChildByName("Button_left")
    local function onPageLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPageLeftButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex - 1
            pageChange(self)
        end
    end
    buttonControl:addTouchEventListener(onPageLeftClick)

    --set pageView touch feeling
    pageView:setCustomScrollThreshold(100)
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then 
            -- KSound.playEffect("slide")
            self._pageIndex = pageView:getCurPageIndex()
        end
    end
    pageView:addEventListener(onPageViewEvent)

    local mainNode        = self._mainLayout
    local projectBottom   = mainNode:getChildByName("Image_sd_board")
    local panelShopBottom = projectBottom:getChildByName("Panel_shop_bottom")
    local imageBottomBase = panelShopBottom:getChildByName("Image_bottom_button_base")

    for type, buttonName in pairs(m_tTabName) do
        local buttonTab = imageBottomBase:getChildByName(buttonName)
        local tabType = type
        local function onTabClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                changeTabButton(self, tabType)
            end
        end
        buttonTab:addTouchEventListener(onTabClick)
    end

    local buttonControl = panelPageViewBase:getChildByName("Button_left")
    local function onPageLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPageLeftButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex - 1
            pageChange(self)
        end
    end
    buttonControl:addTouchEventListener(onPageLeftClick)

    local imageShopBase       = projectClothing:getChildByName("Image_shop_base")
    local skinShopButtonList  = imageShopBase:getChildByName("Panel_button")
    local keySearchButton     = skinShopButtonList:getChildByName("Button_type_1")
    local function onKeySearchClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onKeySearchClick~")
            KSound.playEffect("click")
            playInputAnimation(self, true)
        end
    end
    keySearchButton:addTouchEventListener(onKeySearchClick)

    local typeSearchButton     = skinShopButtonList:getChildByName("Button_type_2")
    local function onTypeSearchClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onTypeSearchClick~")
            KSound.playEffect("click")
            playSearchAnimation(self, true)
        end
    end
    typeSearchButton:addTouchEventListener(onTypeSearchClick)

    local sortByNameButton     = skinShopButtonList:getChildByName("Button_type_3")
    local function onSortByNameClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSortByNameClick~")
            KSound.playEffect("click")
            self:sortSkinByName()
        end
    end
    sortByNameButton:addTouchEventListener(onSortByNameClick)

    local sortByTimeButton     = skinShopButtonList:getChildByName("Button_type_4")
    local function onSortByTimeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSortByTimeClick~")
            KSound.playEffect("click")
            self:showSkinByTime()
        end
    end
    sortByTimeButton:addTouchEventListener(onSortByTimeClick)

    local showOwnSkinButton     = skinShopButtonList:getChildByName("Button_type_5")
    local function onShowOwnSkinClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onShowOwnSkinClick~")
            KSound.playEffect("click")
            self:showOwnSkin()
        end
    end
    --showOwnSkinButton:addTouchEventListener(onShowOwnSkinClick)
    --temperory disabled
    showOwnSkinButton:setVisible(false)

    local imageSearchBase   = projectInput:getChildByName("Image_searche_base")
    local confirmButton     = imageSearchBase:getChildByName("Button_conform")
    local function onInputOK(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onInputOK~")
            KSound.playEffect("click")
            local text = imageSearchBase:getChildByName("TextField_input_text"):getString()
            self:searchSkinByKey(text)
        end
    end
    confirmButton:addTouchEventListener(onInputOK)

    local cancelButton     = imageSearchBase:getChildByName("Button_cancel")
    local function onInputCancel(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onInputCancel~")
            KSound.playEffect("click")
            playInputAnimation(self, false)
        end
    end
    cancelButton:addTouchEventListener(onInputCancel)

    local closeButton     = imageSearchBase:getChildByName("Button_close")
    closeButton:addTouchEventListener(onInputCancel)

    local imageTypeSearchBase = projectSearch:getChildByName("Image_type_search_base")
    for i = 1, 5 do
        local button = imageTypeSearchBase:getChildByName("Button_type_" .. i)
        if button then
            local function searchByType(sender, type)
                if type == ccui.TouchEventType.ended then
                    self:showSkinByType(i)
                end
            end

            button:addTouchEventListener(searchByType)
        end
    end

    local panelScreen = projectSearch:getChildByName("Panel_screen")
    local function onClickEmptyArea(sender, type)
        if type == ccui.TouchEventType.ended then
            playSearchAnimation(self, false)
        end
    end
    panelScreen:addTouchEventListener(onClickEmptyArea)
end

function KUIShopNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBuyGoodSuccess(goodID, nResult, nBuyCount)
        if nResult == BUY_RET.SUCCESS then
            cclog("----------> onEvent NET_BUY_GOOD_SUCCESS %d", goodID)
            refreshDiamond(self)
            self:refreshSkinStatus(goodID)
            KUtil.showBuySuccessTip(goodID, nBuyCount)
        elseif nResult == BUY_RET.OVERDUE then
            showNoticeByID("shop.goodsOverdue")
        elseif nResult == BUY_RET.COINNOTENOUGH then
            local tGoodsConfig = KConfig.shop[goodID]
            showNoticeByID("common.lessResource", KUtil.getItemName(tGoodsConfig.nCoinType, tGoodsConfig.nCoinID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_GOOD_SUCCESS, onBuyGoodSuccess) 

    local function onResourceUpdate()
        cclog("----------> onEvent KUITeamNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)

    local function onUpdateCoin()
        refreshDiamond(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_COIN, onUpdateCoin) 

    local function onUpdateBuyCount(nGoodsID)
        local config = KConfig.shop[nGoodsID]
        if config.nMaxAdditionalTimes > 0 then
            refreshPageView(self)
        end

        local mainNode          = self._mainLayout
        local projectContent    = mainNode:getChildByName("ProjectNode_content")
        local panelShopContent  = projectContent:getChildByName("Panel_shop_content")
        local panelPageViewBase = panelShopContent:getChildByName("Image_sd_showcase_base")
        local pageView          = panelPageViewBase:getChildByName("PageView_item_list")
        local imageGoods        = ccui.Helper:seekWidgetByName(pageView, tostring(nGoodsID))
        if imageGoods then
            KUtil.setTouchEnabled(imageGoods, KUtil.isCanBuy(nGoodsID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_COUNT, onUpdateBuyCount)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_DAY_BUY_COUNT, onUpdateBuyCount) 
    self:addCustomEvent(eventDispatchCenter.EventType.NET_WEEK_BUY_COUNT, onUpdateBuyCount) 
end

function KUIShopNode:onCleanup()
    self._panelBase:release()  
    self._skinPanelUnit:release()
end

return KUIShopNode
