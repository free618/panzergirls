--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIShopSpringNode.lua
--  Creator     : LiuLingLi
--  Date        : 2016/01/22   9:39
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local SPRING_EXCHANGE   = 39
local KUIShopSpringNode = class(
    "KUIShopSpringNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUIShopSpringNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._pageIndex             = nil
    self._panelBase             = nil
    self._pageCount             = 0
end

function KUIShopSpringNode.create(owner)
    local currentNode   = KUIShopSpringNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_spring_shop.csb"
    currentNode:init()

    return currentNode
end

local function refreshCoinArea(self)
    local mainNode    = self._mainLayout
    local textDimaond = mainNode:getChildByName("Text_dimond_data")
    textDimaond:setString(KPlayer.coin)

    local imageCion   = mainNode:getChildByName("Image_material_base1")
    local textCion    = imageCion:getChildByName("Text_oil_value_text")
    textCion:setString(KUtil.getItemCount(SPRING_EXCHANGE))
end

local function updateOneItem(self, itemUI, itemInfo)
    if not itemInfo then itemUI:setVisible(false) return end
    itemUI:setVisible(true)
    itemUI:setName(tostring(itemInfo.nID))

    local textName = itemUI:getChildByName("Text_spring_name")
    textName:setString(itemInfo.szName)

    local textDescription = itemUI:getChildByName("Text_gift_description")
    textDescription:setString(itemInfo.szDescription)
    
    local itemType, itemID, itemNum = itemInfo.nItemType, itemInfo.nItemID, itemInfo.nItemCount
    local panelGood = itemUI:getChildByName("Panel_icon")
    local imageGood = panelGood:getChildByName("Image_good")
    
    local filePath, scale = KUtil.getRewardItemPathAndScale(itemType, itemID)
    imageGood:loadTexture(filePath)
    imageGood:setScale(scale * 1.3)
    
    local buttonPurchase = itemUI:getChildByName("Button_exchange")
    local textCost = buttonPurchase:getChildByName("Text_cost")
    textCost:setString(tostring(itemInfo.nPrice))

    local goodID = itemInfo.nID
    local isBuy   = KUtil.isCanBuy(goodID)
    KUtil.setTouchEnabled(buttonPurchase, isBuy)
    local function onClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if not KUtil.isCanBuy(goodID) then return end
        cclog("buy Good, goodID = :" .. goodID)
        KUtil.buyRequest(KUtil.shopType.SPRING, goodID)
    end
    buttonPurchase:addTouchEventListener(onClick)
end

local function refreshPageView(self)
    local mainNode  = self._mainLayout
    local pageBase  = mainNode:getChildByName("Image_sd_showcase_base")
    local pageView  = pageBase:getChildByName("PageView_item_list")
    pageView:removeAllPages()

    local itemListData = KUtil.getSortListByType(KUtil.shopType.SPRING)
    local count        = #itemListData
    local pageCount    = (count - 1)/self._pageCount + 1
    local nodeList     = {}
    for pageIndex = 1, pageCount do
        local panelUI = self._panelBase:clone()
        pageView:addPage(panelUI)
        --update item ui
        for itemIndex = 1, self._pageCount do
            local currentIndex   = (pageIndex - 1) * self._pageCount + itemIndex
            local itemInfo       = itemListData[currentIndex]
            local itemUI         = panelUI:getChildByName(string.format("gift_Base_%d", itemIndex))
            updateOneItem(self, itemUI, itemInfo)
            nodeList[#nodeList + 1] = itemUI
        end
    end
    --need delay one frame
    local scrollToPage = function()
        pageView:scrollToPage(0)
        self._pageIndex = pageView:getCurPageIndex()
    end
    delayExecute(pageView, scrollToPage, 0.0)  
    self._pageCount = pageCount
end

local function pageChange(self)
    local mainNode  = self._mainLayout
    local pageBase  = mainNode:getChildByName("Image_sd_showcase_base")
    local pageView  = pageBase:getChildByName("PageView_item_list")
    local pageCount = self._pageCount

    if self._pageIndex < 0 then 
        self._pageIndex = pageCount - 1
    elseif self._pageIndex > pageCount - 1 then 
        self._pageIndex = 0
    end

    pageView:scrollToPage(self._pageIndex) 
end

function KUIShopSpringNode:refreshUI()
    local mainNode  = self._mainLayout
    local pageBase  = mainNode:getChildByName("Image_sd_showcase_base")
    local pageView  = pageBase:getChildByName("PageView_item_list")
    self._panelBase = pageView:getChildByName("Panel_Base")
    self._panelBase:retain()
    self._pageCount = #self._panelBase:getChildren()

    refreshCoinArea(self)
    refreshPageView(self)
end

function KUIShopSpringNode:registerAllTouchEvent()
    local mainNode = self._mainLayout
    --Close Button
    local buttonControl = mainNode:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            self._nodeData = nil   
            KSound.playEffect("close")
            self._parent:removeNode("ShopSpring")
        end
    end
    buttonControl:addTouchEventListener(onCloseClick)

    local pageBase  = mainNode:getChildByName("Image_sd_showcase_base")
    local pageView  = pageBase:getChildByName("PageView_item_list")
    --Page Right Button
    local buttonControl = pageBase:getChildByName("Button_right")
    local function onPageRightClick(sender, type)
        if type == ccui.TouchEventType.ended then 
            cclog("click onPageRightButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex + 1
            pageChange(self)
        end
    end
    buttonControl:addTouchEventListener(onPageRightClick)

    --Page Left Button
    local buttonControl = pageBase:getChildByName("Button_left")
    local function onPageLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onPageLeftButton~")
            KSound.playEffect("click")
            self._pageIndex = self._pageIndex - 1
            pageChange(self)
        end
    end
    buttonControl:addTouchEventListener(onPageLeftClick)

    --set pageView touch feeling
    pageView:setCustomScrollThreshold(100)
    local function onPageViewEvent(sender, type)
        if type == ccui.PageViewEventType.turning then 
            -- KSound.playEffect("slide")
            self._pageIndex = pageView:getCurPageIndex()
        end
    end
    pageView:addEventListener(onPageViewEvent)
end

function KUIShopSpringNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onBuyGoodSuccess(goodID, nResult, nBuyCount)
        if nResult == BUY_RET.SUCCESS then
            cclog("----------> onEvent NET_BUY_GOOD_SUCCESS %d", goodID)
            refreshCoinArea(self)
            KUtil.showBuySuccessTip(goodID, nBuyCount)
        elseif nResult == BUY_RET.OVERDUE then
            showNoticeByID("shop.goodsOverdue")
        elseif nResult == BUY_RET.COINNOTENOUGH then
            local tGoodsConfig = KConfig.shop[goodID]
            showNoticeByID("common.lessResource", KUtil.getItemName(tGoodsConfig.nCoinType, tGoodsConfig.nCoinID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_GOOD_SUCCESS, onBuyGoodSuccess) 

    local function onUpdateBuyCount(nGoodsID, nBuyCount)
        local mainNode = self._mainLayout
        local pageBase = mainNode:getChildByName("Image_sd_showcase_base")
        local pageView = pageBase:getChildByName("PageView_item_list")
        local imageGoods = ccui.Helper:seekWidgetByName(pageView, tostring(nGoodsID))
        if imageGoods then
            local buttonPurchase = imageGoods:getChildByName("Button_exchange")
            KUtil.setTouchEnabled(buttonPurchase, KUtil.isCanBuy(nGoodsID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_COUNT, onUpdateBuyCount) 
end

function KUIShopSpringNode:onCleanup()
    self._panelBase:release()  
end

return KUIShopSpringNode
