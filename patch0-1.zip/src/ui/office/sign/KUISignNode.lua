--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUISignNode.lua
--  Creator     : LiuLingLi
--  Date        : 2015/11/04   11:07
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUISignNode = class(
    "KUISignNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISignNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._baseBar               = nil
    self._pageData              = nil
end

function KUISignNode.create(owner)
    local currentNode   = KUISignNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_sign.csb"
    currentNode:init()

    return currentNode
end

local function playSignAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_sign")

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_sign"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_sign")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playSignAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Sign", callBacks, isReturnOffice)
end

local function cloneBar(self)
    local imageBar = self._baseBar:clone()
    return imageBar
end

local function initSignBar(self, imageBar, dataInfo)
    local tSignConfig = dataInfo.config

    local tSignData = dataInfo.data
    local bSign     = tSignData.nCount >= tSignConfig.nDay

    imageBar:setName(tostring(dataInfo.nID))
    local textDay  = imageBar:getChildByName("Text_day")
    textDay:setString(tSignConfig.szTitle)

    local imageSign = imageBar:getChildByName("Image_tick")
    imageSign:setVisible(bSign)

    local panelItem = imageBar:getChildByName("Panel_frame")
    local tItemList = KUtil.getRewardRandResult(tSignConfig.nRewardID)
    local count = 1
    while true do
        local panelFrame = panelItem:getChildByName("Panel_frame_" .. count)
        if not panelFrame then break end
        local tItem = tItemList[count]
        if tItem then
            panelFrame:setVisible(true)

            local panelIcon = panelFrame:getChildByName("Panel_icon")
            local imageItem = panelIcon:getChildByName("Image_icon")
            local filePath, scaleRatio = KUtil.getRewardItemPathAndScale(tItem.nType, tItem.nID)
            imageItem:loadTexture(filePath)
            imageItem:setScale(scaleRatio)

            local textCount  = panelFrame:getChildByName("Text_number")
            textCount:setString(tItem.nNum)
        else
            panelFrame:setVisible(false)
        end
        count = count + 1
    end
end

local function scrollToNotSign(self, scrollView, nSignDay)
    local contentSize        = scrollView:getContentSize()
    local innerContainerSize = scrollView:getInnerContainerSize()
    if innerContainerSize.height <= contentSize.height then return end

    local nPercent = (innerContainerSize.height - contentSize.height) / innerContainerSize.height
    nPercent       = nSignDay / #KConfig["sign"] / nPercent
    scrollView:scrollToPercentVertical(nPercent * 100, 0.5, false)

    if not self._pageData then return end

    self._pageData.refreshList()
end

local function refreshScrollView(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_sign")      
    local panelBase   = projectNode:getChildByName("Image_base")
    local imageBase   = panelBase:getChildByName("Image_sign_base")
    local scrollView  = imageBase:getChildByName("ScrollView_sign")
    scrollView:removeAllChildren()
    
    local tSignData   = KUtil.getSignData()
    local dataList   = {}
    for nDay, tSignConfig in ipairs(KConfig["sign"]) do
        local dataInfo = {nID = tSignConfig.nDay, config = tSignConfig, data = tSignData}
        table.insert(dataList, dataInfo)
    end

    local refreshCall = function(control, dataInfo)
        initSignBar(self, control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        itemBase    = self._baseBar,
        dataList    = dataList,
        refreshCall = refreshCall,
        row         = 10,
        column      = 1,
    }

    self._pageData    = KUtil.addDynamicScrollView(parameters)
    scrollToNotSign(self, scrollView, tSignData.nCount)
end

local function setSignButtonAndDay(self, nDay, bEnabled)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_sign")      
    local panelBase   = projectNode:getChildByName("Image_base")
    local imageBase   = panelBase:getChildByName("Image_sign_base")
    local textDay     = imageBase:getChildByName("Text_day_number")
    textDay:setString(nDay)

    local buttonSign = imageBase:getChildByName("Button_Sign")
    KUtil.setTouchEnabled(buttonSign, bEnabled)
end

local function refreshOther(self)
    local tSignData = KUtil.getSignData()
    local bEnabled  = false
    if not tSignData.bSign and KConfig:getLine("sign", tSignData.nCount + 1) then
        bEnabled = true
    end

    setSignButtonAndDay(self, tSignData.nCount, bEnabled)
end

local function setSign(self, nDay)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_sign")      
    local panelBase   = projectNode:getChildByName("Image_base")
    local imageBase   = panelBase:getChildByName("Image_sign_base")
    local scrollView  = imageBase:getChildByName("ScrollView_sign")
    local imageBar   = scrollView:getChildByName(tostring(nDay))
    if imageBar then
        local imageSign  = imageBar:getChildByName("Image_tick")
        imageSign:setVisible(true)
    end

    scrollToNotSign(self, scrollView, nDay)
    setSignButtonAndDay(self, nDay, false)
end

local function initData(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_sign")
    local panelBase   = projectNode:getChildByName("Image_base")
    local imageBase   = panelBase:getChildByName("Image_sign_base")
    local scrollView  = imageBase:getChildByName("ScrollView_sign")
    local imageBar   = scrollView:getChildByName("Button_sign_1")
    self._baseBar    = imageBar:clone()
    self._baseBar:retain()
end


local function getFrameAction(self, startFrame, endedFrame)
    local duration   = (endedFrame - startFrame) / 60

    local function callAnimation()
        local mainNode = self._mainLayout
        local projectNode = mainNode:getChildByName("ProjectNode_sign")
        local actionName = "ani_sign"
        KUtil.playAnimation(projectNode,  actionName, startFrame, endedFrame)
    end
    
    local callAction  = cc.CallFunc:create(callAnimation)
    local frameDelay  = cc.DelayTime:create(duration)
    local frameAction = cc.Sequence:create(callAction, frameDelay)

    return frameAction, duration
end

function KUISignNode:activate(nowTime)
    self._pageData.refreshList()
end


function KUISignNode:onInitUI()
    initData(self)
    stopAllAnimation(self)
end

function KUISignNode:getEnterAction()
    return
end

function KUISignNode:getExitAction()
    return
end

function KUISignNode:refreshUI()
    refreshScrollView(self)
    refreshOther(self)
end

function KUISignNode:onEnterActionFinished()
    playSignAnimation(self, true)

    local mainNode     = self._mainLayout
    local projectNode  = mainNode:getChildByName("ProjectNode_sign")
    local panelBase    = projectNode:getChildByName("Image_base")
    local imageBase    = panelBase:getChildByName("Image_sign_base")
    local spSignBase   = imageBase:getChildByName("Image_special_sign_base")
    local spSignButton = spSignBase:getChildByName("Button_special_sign")

    local config        = KConfig.spSign[1]
    local isSPSignOpen  = KUtil.isOpeningTime(KUtil.getCurrentServerTime(), config.otOpenTimes)
    spSignButton:setVisible(isSPSignOpen)
end

function KUISignNode:registerAllTouchEvent( )
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_sign")
    local panelBase   = projectNode:getChildByName("Image_base")
    local imageBase   = panelBase:getChildByName("Image_sign_base")

    --Close Button
    local buttonClose = imageBase:getChildByName("Button_close")
    local function onCloseClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseButton~")
            KSound.playEffect("close")
            playPanelCloseAnimation(self, false)
        end
    end
    buttonClose:addTouchEventListener(onCloseClick)

    --Sign Button
    local buttonSign = imageBase:getChildByName("Button_Sign")
    local function onSignClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSignButton~")
            local tSignData   = KUtil.getSignData()
            if tSignData.bSign then return end
            local nDay        = tSignData.nCount + 1
            local tSignConfig = KConfig:getLine("sign", nDay)
            assert(tSignConfig, nDay)
            local tItemList   = KUtil.getRewardRandResult(tSignConfig.nRewardID)
            local nTipID      = KUtil.CanSuperAddItems(tItemList)
            if nTipID then
                showNoticeByID(nTipID)
            else
                require("src/network/KC2SProtocolManager"):sign(nDay, KUtil.getCurrentServerTime())
                KUtil.setTouchEnabled(buttonSign, false)
            end
        end
    end
    buttonSign:addTouchEventListener(onSignClick)

    local spSignBase   = imageBase:getChildByName("Image_special_sign_base")
    local spSignButton = spSignBase:getChildByName("Button_special_sign")
    local function onSPSignClick(sender, type)
        if type == ccui.TouchEventType.ended then
            self._parent:addNode("SPSign")
            self._parent:removeNode("Sign")
        end
    end
    spSignButton:addTouchEventListener(onSPSignClick)
end

function KUISignNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onSign(nCurDay, nCount)
        cclog("onEvent ---------->onSign")
        setSign(self, nCount)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SIGN, onSign)
end

function KUISignNode:onCleanup()
    self._baseBar:release() 
end

return KUISignNode
