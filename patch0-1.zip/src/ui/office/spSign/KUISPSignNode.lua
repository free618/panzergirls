--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUISPSignNode.lua
--  Creator     : ChenJiaLiang
--  Date        : 2016/05/23   19:45
--  Contact     : chenjialiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local KSetting = require("src/logic/KSetting")

local KUISPSignNode = class(
    "KUISPSignNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUISPSignNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._animationList         = {}
    self._enterExitAnimation    = {}
end

function KUISPSignNode.create(owner)
    local currentNode   = KUISPSignNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_special_landing.csb"
    currentNode:init()

    return currentNode
end

local function initData(self)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_1")
    local imageBase   = projectNode:getChildByName("Image_special_landing_base")

    self._imageBase                 = imageBase

    self._animationList.projectNode = {ani = KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_special_landing.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    self._enterExitAnimation = {"projectNode"}
end

function KUISPSignNode:playAnimation(aniName, frameConfigName)
    local aniConfig = self._animationList[aniName]
    if not aniConfig then
        return
    end

    local frameConfig = aniConfig[frameConfigName]
    return KUtil.playAnimationByAnimation(aniConfig.ani, frameConfig[1], frameConfig[2])
end

function KUISPSignNode:activate(nowTime)
end

function KUISPSignNode:onInitUI()
    initData(self)
    self:initContent()
end

function KUISPSignNode:initContent()
    for day, config in ipairs(KConfig.spSign) do
        local button = self._imageBase:getChildByName("Button_sign_"..day)
        if not button then
            return
        end

        local spSignData    = KPlayer.tSPSignData
        local nameLabel     = button:getChildByName("Text_day")
        nameLabel:setString(config.szTitle)

        local rewardIcon    = button:getChildByName("Image_icon_box")
        
        if config.szResPath ~= "" then
            local resPath       = KUtil.getSPSignImagePath(day)
            rewardIcon:loadTexture(resPath)
        end

        local signImage     = button:getChildByName("Image_sign_tick")
        signImage:setVisible(day <= spSignData.nSignDay)

        button:setTouchEnabled(false)
    end
end

function KUISPSignNode:playSignAnimation(signDay)
    local button        = self._imageBase:getChildByName("Button_sign_" .. signDay)
    local signImage     = button:getChildByName("Image_sign_tick")
    local oldScale      = signImage:getScale()
    local scaleSecond   = 0.5
    local scaleTimes    = 4.2

    signImage:setScale(oldScale * scaleTimes)
    signImage:setVisible(true)
    signImage:runAction(cc.ScaleTo:create(scaleSecond, oldScale))
end

function KUISPSignNode:refreshUI()
end

function KUISPSignNode:registerAllTouchEvent()
    local buttonClose = self._imageBase:getChildByName("Button_close")
    local function onClose(sender, type)
        if type == ccui.TouchEventType.ended then
            self._parent:removeNode("SPSign")
        end
    end
    buttonClose:addTouchEventListener(onClose)
end

function KUISPSignNode:getEnterAction()
    return nil, nil
end

function KUISPSignNode:onEnterActionFinished()
    self:enterAnimation()

    local spSignData    = KPlayer.tSPSignData
    local lastSignIndex = GetDayIndex(spSignData.nLastSignTime)
    local nowTimeIndex  = GetDayIndex(KUtil.getServerTime(os.time()))
    local config        = KConfig.spSign[1]
    local isOpen        = KUtil.isOpeningTime(KUtil.getCurrentServerTime(), config.otOpenTimes)

    if isOpen and lastSignIndex ~= nowTimeIndex then
        require("src/network/KC2SProtocolManager"):SPSign()
    end
end

function KUISPSignNode:onNodeEnter()
    KSound.playMusic("base")
end

function KUISPSignNode:onNodeExit()
    KSound.playMusic("base")
end

function KUISPSignNode:enterAnimation()    
    for _, aniName in pairs(self._enterExitAnimation) do
        self:playAnimation(aniName, "enter")
    end
end

function KUISPSignNode:exitAnimation()
    local delayTime = 0
    for _, aniName in pairs(self._enterExitAnimation) do
        local aniTime = self:playAnimation(aniName, "exit")
        if aniTime > delayTime then
            delayTime = aniTime
        end
    end

    return delayTime
end

function KUISPSignNode:playPanelCloseAnimation(isReturnOffice)
    local delayTime = self:exitAnimation()
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "SPSign", callBacks, isReturnOffice)
end

function KUISPSignNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onSPSignResult(signDay, items)
        delayExecute(self._mainLayout, function (  )
            self:playSignAnimation(signDay)
        end, 0.5)

        delayExecute(self._mainLayout, function (  )
            KUtil.playGetItemAnimation(self._parent, items)
        end, 1.3)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SPSIGN_RESULT, onSPSignResult) 
end

return KUISPSignNode