--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUIStoryNode.lua
--  Creator     : ChenJiaLiang
--  Date        : 2016/06/22   13:45
--  Contact     : chenjialiang@kingsoft.com
--  Comment     :
--  *********************************************************************

local KSetting = require("src/logic/KSetting")

local TabType     = {MAIN_STORY = 1, EXTRA_STORY = 2, NAVIGATE = 3}
local FilterType  = {[0] = "all", [1] = "light", [2] = "middle",[3] = "heavy",  [4] = "fighter", [5] = "artillery", }
local OrderType   = {[1] = {name = "name"}, [2] = {name = "star"}, [3] = {name = "time"},}
local StoryPath   = "src/settings/story/"

local KUIStoryNode = class(
    "KUIStoryNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

local function initOrderFunc()
    OrderType[1].sortFunc = function (storyConfA, storyConfB)
        if storyConfA.szName ~= storyConfB.szName then
            return storyConfB.szName < storyConfB.szName
        end

        return storyConfA.nID < storyConfB.nID
    end

    OrderType[2].sortFunc = function (confA, confB)
        local cardA, cardB = KConfig.cardInfo[confA.nCardID], KConfig.cardInfo[confB.nCardID]
        if cardA.nQuality ~= cardB.nQuality then
            return cardA.nQuality > cardB.nQuality
        end

        return confA.nID < confB.nID
    end

    OrderType[3].sortFunc = function (storyConfA, storyConfB)
        return storyConfA.nID < storyConfB.nID
    end
end

function KUIStoryNode:ctor()
    self._mainLayout            = nil
    self._parent                = nil
    self._uiPath                = nil
    self._animationList         = {}
    self._enterExitAnimation    = {}
    initOrderFunc()
end

function KUIStoryNode.create(owner, storyInfo)
    local currentNode       = KUIStoryNode.new()
    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_studio_theatre.csb"
    currentNode._openStory  = storyInfo
    currentNode:init()

    return currentNode
end



local function initAnimation(self)
    local mainNode    = self._mainLayout
    local imageBase   = self._imageBase

    local title = imageBase:getChildByName("ProjectNode_title")
    self._animationList.title = {ani = KUtil.initAnimation(title, "res/ui/animation_node/ani_studio_theatre_title.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    local bottom = imageBase:getChildByName("ProjectNode_bottom")
    self._animationList.bottom = {ani = KUtil.initAnimation(bottom, "res/ui/animation_node/ani_studio_theatre_bottom.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    local home = mainNode:getChildByName("ProjectNode_home")
    self._animationList.home = {ani = KUtil.initAnimation(home, "res/ui/animation_node/ani_common_home.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    local left = imageBase:getChildByName("ProjectNode_left")
    self._animationList.left = {ani = KUtil.initAnimation(left, "res/ui/animation_node/ani_studio_theatre_left.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    local right = imageBase:getChildByName("ProjectNode_right")
    self._animationList.right = {ani = KUtil.initAnimation(right, "res/ui/animation_node/ani_studio_theatre_right.csb"),
                                        enter = {0, 30}, exit = {50, 65}, }

    self._enterExitAnimation = {"title", "home", "bottom", "left", "right", }
end

local function initData(self)
    local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_base")
    local leftProject   = imageBase:getChildByName("ProjectNode_left")
    local rightProject  = imageBase:getChildByName("ProjectNode_right")
    local title         = imageBase:getChildByName("ProjectNode_title")
    self._imageBase     = imageBase
    
    local panel1        = title:getChildByName("Panel_1")
    local buttonBack    = panel1:getChildByName("Button_back")
    local buttonClose   = panel1:getChildByName("Button_close")
    buttonBack:setVisible(self._openStory ~= nil)
    buttonClose:setVisible(self._openStory == nil)

    local panelScreen   = imageBase:getChildByName("Panel_screen")
    panelScreen:setVisible(false)

    local filterButton  = imageBase:getChildByName("Image_type_base")
    filterButton:setVisible(false)

    local orderButton   = imageBase:getChildByName("Image_name_base")
    orderButton:setVisible(false)

    local leftBase      = leftProject:getChildByName("Image_left_base")
    local chapterList   = leftBase:getChildByName("ScrollView_chapter_list")
    local cardList      = leftBase:getChildByName("ScrollView_card_list")
    local rightBase     = rightProject:getChildByName("Panel_1")
    local storyList     = rightBase:getChildByName("ScrollView_card")

    self._chapterUnit   = chapterList:getChildByName("Button_unit")
    self._chapterUnit:retain()
    self._chapterUnit:removeFromParent()

    self._cardUnit      = cardList:getChildByName("Panel_unit")
    self._cardUnit:retain()
    self._cardUnit:removeFromParent()

    self._storyUnit     = storyList:getChildByName("Panel_unit")
    self._storyUnit:retain()
    self._storyUnit:removeFromParent()

    initAnimation(self)

    self:setFilterButtonState(0)
    self:setOrderButtonState(1)

    if not self._openStory then    
        self:showNavigateStory()
    else
        local openInfo = self._openStory
        if openInfo.chapterID then
            local chapterConfig = KConfig.storyChapter[openInfo.chapterID]
            self:showChapterStory(chapterConfig.nType)
            self:jumpToChapter(openInfo.chapterID)
        elseif openInfo.cardID then
            self:showNavigateStory()
            self:jumpToCard(openInfo.cardID)
        end
    end
end

function KUIStoryNode:playAnimation(aniName, frameConfigName)
    local aniConfig = self._animationList[aniName]
    if not aniConfig then
        return
    end

    local frameConfig = aniConfig[frameConfigName]
    return KUtil.playAnimationByAnimation(aniConfig.ani, frameConfig[1], frameConfig[2])
end

function KUIStoryNode:playInputAnimation(isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = self._inputProjectNode
    local panelScreen     = self._imageBase:getChildByName("Panel_screen")

    if not projectNode then
        projectNode                 = cc.CSLoader:createNode("res/ui/animation_node/ani_shop_clothing_input.csb")
        local projectNodePosition   = self._mainLayout:convertToWorldSpace(cc.p(0, 0))
        self._mainLayout:addChild(projectNode, 100)
        projectNode:stopAllActions()
        projectNode:setPosition(projectNodePosition)
        self._inputProjectNode = projectNode

        local imageSearchBase   = projectNode:getChildByName("Image_searche_base")
        local confirmButton     = imageSearchBase:getChildByName("Button_conform")
        local function onInputOK(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onInputOK~")
                KSound.playEffect("click")
                self:playInputAnimation(false)
                local text = imageSearchBase:getChildByName("TextField_input_text"):getString()
                self:showNavigateStory(self._currentFilterType, self._currentOrderType, string.upper(text))
            end
        end
        confirmButton:addTouchEventListener(onInputOK)

        local cancelButton     = imageSearchBase:getChildByName("Button_cancel")
        local function onInputCancel(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onInputCancel~")
                KSound.playEffect("click")
                self:playInputAnimation(false)
            end
        end
        cancelButton:addTouchEventListener(onInputCancel)

        local closeButton     = imageSearchBase:getChildByName("Button_close")
        closeButton:addTouchEventListener(onInputCancel)
    end

    panelScreen:setVisible(isOpen)

    local openEndFrame    = 30
    local closeStartFrame = 50
    local animationName   = "ani_shop_clothing_input"

    local delayFrame = KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
    if isOpen then
        projectNode:setVisible(isOpen)
    else
        delayExecute(mainNode, function ()
            projectNode:setVisible(isOpen)
        end, delayFrame / KUtil.FRAME_PER_SECOND)
    end

    return delayFrame
end

function KUIStoryNode:activate(nowTime)
end

function KUIStoryNode:onInitUI()
    initData(self)
    self:initContent()
end

function KUIStoryNode:initContent()
    
end

function KUIStoryNode:refreshUI()
end

function KUIStoryNode:setFilterVisible(visible)
    local filterButtonList    = self._imageBase:getChildByName("Image_type_base")
    local panelScreen         = self._imageBase:getChildByName("Panel_screen")
    panelScreen:setVisible(visible)
    KUtil.showUiScale(filterButtonList, visible)
    self._openingFilter = visible
end

function KUIStoryNode:setFilterButtonState(filterType)
    local filterButtonList    = self._imageBase:getChildByName("Image_type_base")
    KUtil.showUiScale(filterButtonList, false)

    local bottom        = self._imageBase:getChildByName("ProjectNode_bottom")
    local panel1        = bottom:getChildByName("Panel_1")
    local bottomBase    = panel1:getChildByName("Image_bottom_base")
    local filterButton  = bottomBase:getChildByName("Button_type")
    for index, filterName in pairs(FilterType) do
        local textLabel = filterButton:getChildByName("Text_type_" .. filterName)
        textLabel:setVisible(index == filterType)
    end
end

function KUIStoryNode:setFilter(filterType)
    self:setFilterButtonState(filterType)
    self:showNavigateStory(filterType, self._currentOrderType)
    self._currentFilterType = filterType
end

function KUIStoryNode:setOrderVisible(visible)
    local orderButtonList    = self._imageBase:getChildByName("Image_name_base")
    local panelScreen        = self._imageBase:getChildByName("Panel_screen")
    panelScreen:setVisible(visible)
    KUtil.showUiScale(orderButtonList, visible)
    self._openingOrder = visible
end

function KUIStoryNode:setOrderButtonState(orderType)
    local orderButtonList    = self._imageBase:getChildByName("Image_name_base")
    KUtil.showUiScale(orderButtonList, false)

    local bottom        = self._imageBase:getChildByName("ProjectNode_bottom")
    local panel1        = bottom:getChildByName("Panel_1")
    local bottomBase    = panel1:getChildByName("Image_bottom_base")
    local orderButton   = bottomBase:getChildByName("Button_name")
    for index, orderConfig in pairs(OrderType) do
        local orderName = orderConfig.name
        local textLabel = orderButton:getChildByName("Text_" .. orderName)
        textLabel:setVisible(index == orderType)
    end
end

function KUIStoryNode:setOrder(orderType)
    self:setOrderButtonState(orderType)
    self:showNavigateStory(self._currentFilterType, orderType)
    self._currentOrderType = orderType
end

function KUIStoryNode:showChapterStory(chapterType)
    local leftProject   = self._imageBase:getChildByName("ProjectNode_left")
    local leftBase      = leftProject:getChildByName("Image_left_base")
    local chapterList   = leftBase:getChildByName("ScrollView_chapter_list")
    local cardList      = leftBase:getChildByName("ScrollView_card_list")
    local textTitle     = leftBase:getChildByName("Text_card")

    chapterList:setVisible(true)
    cardList:setVisible(false)
    textTitle:setString(KUtil.formatStringByKey("story.chapter"))

    local chapterList   = {}
    for chapterID, chapterConfig in pairs(KConfig.storyChapter) do
        if chapterConfig.nType == chapterType then
            table.insert(chapterList, chapterConfig)
        end
    end

    table.sort(chapterList, function (a, b)
        if a.nOrder ~= b.nOrder then
            return a.nOrder < b.nOrder
        end

        return a.nID < b.nID
    end)

    self:setChapterScrollView(chapterList)
    if #chapterList > 0 then
        self:showStoryByChapterID(chapterList[1].nID)
    else
        self:showStoryByChapterID(-1)
    end

    self._tabType = chapterType
    self:setTabState(self._tabType)
end

function KUIStoryNode:setChapterScrollView(configList)
    local leftProject   = self._imageBase:getChildByName("ProjectNode_left")
    local leftBase      = leftProject:getChildByName("Image_left_base")
    local scrollView    = leftBase:getChildByName("ScrollView_chapter_list")
    local slider        = leftBase:getChildByName("Slider_common")

    scrollView:removeAllChildren()

    local refreshCall = function(control, config)
        local textName   = control:getChildByName("Text_chapter_name")
        textName:setString(config.szTitle)

        local chapterNum = control:getChildByName("BitmapFontLabel_num")
        chapterNum:setString(tostring(config.nOrder))

        local function onChapterClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onChapterClick~")   
                KSound.playEffect("click")
                self:showStoryByChapterID(config.nID)
            end
        end
        control:addTouchEventListener(onChapterClick)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = slider,
        itemBase    = self._chapterUnit,
        row         = #configList,
        column      = 1,
        dataList    = configList,
        refreshCall = refreshCall,
    }
    self._leftScrollData = KUtil.addDynamicScrollView(parameters)
end

function KUIStoryNode:showNavigateStory(filterType, orderType, keyword)
    filterType = filterType or 0
    orderType  = orderType or 1
    keyword    = keyword or ""
    local leftProject   = self._imageBase:getChildByName("ProjectNode_left")
    local leftBase      = leftProject:getChildByName("Image_left_base")
    local chapterList   = leftBase:getChildByName("ScrollView_chapter_list")
    local cardList      = leftBase:getChildByName("ScrollView_card_list")
    local textTitle     = leftBase:getChildByName("Text_card")

    chapterList:setVisible(false)
    cardList:setVisible(true)
    textTitle:setString(KUtil.formatStringByKey("story.card"))

    local cardList   = {}
    local cardMap    = {}
    local countIndex = 1
    for storyID, storyConfig in pairs(KConfig.story) do
        if not cardMap[storyConfig.nCardID] then
            local cardConfig = KConfig.cardInfo[storyConfig.nCardID]
            if filterType == 0 or cardConfig.nTankType == filterType then 
                if keyword == "" or string.find(cardConfig.szName, keyword) then
                    table.insert(cardList, {nID = countIndex, nCardID = storyConfig.nCardID, szName = cardConfig.szName, nQuality = cardConfig.nQuality})
                    countIndex = countIndex + 1
                end
            end
            cardMap[storyConfig.nCardID] = true
        end
    end

    table.sort(cardList, OrderType[orderType].sortFunc)
    for index, info in ipairs(cardList) do
        info.nID = index
    end

    self:setCardScrollView(cardList)
    if countIndex > 1 then
        self:showStoryByCardID(cardList[1].nCardID)
    else
        self:setStoryScrollView({})
    end

    self._tabType = TabType.NAVIGATE
    self:setTabState(self._tabType)
end

function KUIStoryNode:setCardScrollView(configList)
    local leftProject   = self._imageBase:getChildByName("ProjectNode_left")
    local leftBase      = leftProject:getChildByName("Image_left_base")
    local scrollView    = leftBase:getChildByName("ScrollView_card_list")
    local slider        = leftBase:getChildByName("Slider_common")

    scrollView:removeAllChildren()

    local refreshCall = function(control, config)
        local buttonUnit     = control:getChildByName("Button_unit")
        local textName       = buttonUnit:getChildByName("Text_chara_name")

        local cardConfig     = KConfig.cardInfo[config.nCardID]
        textName:setString(cardConfig.szName)

        local indexLabel     = buttonUnit:getChildByName("BitmapFontLabel_num")
        indexLabel:setString(tostring(config.nID))

        local charaBg        = control:getChildByName("Image_chara")
        local backgroundPath = KUtil.getCardQualityBackgroundPath(cardConfig.nQuality)
        charaBg:loadTexture(backgroundPath)

        local charaHead     = control:getChildByName("Image_chara_head")
        local headPath      = KUtil.getCardHeadPathByConfigID(config.nCardID, false)
        charaHead:loadTexture(headPath)

        local cardMedal     = buttonUnit:getChildByName("Image_card_medal")
        local medalPath     = KUtil.getCardMedalPath(cardConfig.nID)
        cardMedal:loadTexture(medalPath)

        local cardType      = buttonUnit:getChildByName("Image_chara_type")
        local typePath      = KUtil.getCardBackGround(cardConfig.nTankType)
        cardType:loadTexture(typePath)

        local buttonUnit = control:getChildByName("Button_unit")
        local function onCardClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onCardClick~")   
                KSound.playEffect("click")
                self:showStoryByCardID(config.nCardID)
            end
        end
        buttonUnit:addTouchEventListener(onCardClick)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = slider,
        itemBase    = self._cardUnit,
        row         = #configList,
        column      = 1,
        dataList    = configList,
        refreshCall = refreshCall,
    }
    self._leftScrollData = KUtil.addDynamicScrollView(parameters)
end

function KUIStoryNode:showStoryByChapterID(chapterID)
    local storyList = {}
    for storyID, storyConfig in pairs(KConfig.story) do
        if storyConfig.nChapterID == chapterID then
            table.insert(storyList, storyConfig)
        end
    end

    table.sort(storyList, function (a, b)
        return a.nID < b.nID
    end)

    self:setStoryScrollView(storyList)
    delayExecute(self._mainLayout, function (  )
        self:highlightChapter(chapterID)
    end, 0.05)

    local title         = self._imageBase:getChildByName("ProjectNode_title")
    local panel         = title:getChildByName("Panel_1")
    local textTitle     = panel:getChildByName("Text_title")
    local chapterConfig = KConfig.storyChapter[chapterID]
    if chapterConfig then
        textTitle:setString(chapterConfig.szTitle)
    else
        textTitle:setString("")
    end
end

function KUIStoryNode:showStoryByCardID(cardID)
    local storyList = {}
    for storyID, storyConfig in pairs(KConfig.story) do
        if storyConfig.nCardID == cardID then
            table.insert(storyList, storyConfig)
        else
            local cardIDList = string.split(storyConfig.szRelatedCard, "|")
            for _, v in ipairs(cardIDList) do
                if tonumber(v) == cardID then
                    table.insert(storyList, storyConfig)
                    break
                end
            end
        end
    end

    table.sort(storyList, function (a, b)
        return a.nID < b.nID
    end)

    self:setStoryScrollView(storyList)
    delayExecute(self._mainLayout, function (  )
        self:highlightCard(cardID)
    end, 0.05)

    local title         = self._imageBase:getChildByName("ProjectNode_title")
    local panel         = title:getChildByName("Panel_1")
    local textTitle     = panel:getChildByName("Text_title")
    local cardConfig    = KConfig.cardInfo[cardID]
    if cardConfig then
        textTitle:setString(cardConfig.szName)
    else
        textTitle:setString("")
    end
end

function KUIStoryNode:setStoryScrollView(configList)
    local rightProject  = self._imageBase:getChildByName("ProjectNode_right")
    local rightBase     = rightProject:getChildByName("Panel_1")
    local scrollView    = rightBase:getChildByName("ScrollView_card")

    scrollView:removeAllChildren()

    local refreshCall = function(control, config)
        local textName   = control:getChildByName("Text_name")
        textName:setString(config.szName)

        local imageBg    = control:getChildByName("Image_studio_base")
        if #config.szBGResPath > 0 then
            imageBg:loadTexture(config.szBGResPath)
        end

        local charaPanel = control:getChildByName("Panel_chara")
        local charaImage = charaPanel:getChildByName("Image_studio_base_chara")
        local imagePath  = KUtil.getCardImagePathByConfigID(config.nCardID, false)
        charaImage:loadTexture(imagePath)

        local unlockTip  = control:getChildByName("Text_unlock_condition")
        unlockTip:setString("")

        local buttonUnit = control:getChildByName("Button_unit")
        local function onWatchStory(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onWatchStory~")   
                KSound.playEffect("click")
                self._playingStoryID = config.nID
                self._parent:addNode("StoryPlay", StoryPath .. config.szResPath)
            end
        end

        local hasGainReward = HArray.FindFirstByValue(KPlayer.tStoryData.tGainRewardList, config.nID)
        if KUtil.canGainStoryReward(config.nID) or hasGainReward then
            buttonUnit:addTouchEventListener(onWatchStory)
        else
            buttonUnit:setEnabled(false)
            buttonUnit:setBright(false)
            local destStr    = string.gsub(config.szConditionDesc, "|", "\n")
            unlockTip:setString(destStr)
        end
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = nil,
        itemBase    = self._storyUnit,
        row         = #configList / 2,
        column      = 2,
        dataList    = configList,
        refreshCall = refreshCall,
    }
    self._rightScrollData = KUtil.addDynamicScrollView(parameters)
end

function KUIStoryNode:setTabState(highlightIndex)
    local rightProject      = self._imageBase:getChildByName("ProjectNode_right")
    local rightPanel1       = rightProject:getChildByName("Panel_1")
    local panelButton       = rightPanel1:getChildByName("Panel_button")
    for _, tabType in pairs(TabType) do
        local buttonTab         = panelButton:getChildByName("Button_" .. tabType)
        if tabType == highlightIndex then
            buttonTab:setBrightStyle(ccui.BrightStyle.highlight)
            buttonTab:setTouchEnabled(false)
        else
            buttonTab:setBrightStyle(ccui.BrightStyle.normal)
            buttonTab:setTouchEnabled(true)
        end
    end

    if highlightIndex == TabType.NAVIGATE then
        if self._hidingBottom then
            self:playAnimation("bottom", "enter")
            self._hidingBottom = false
        end
    elseif not self._hidingBottom then
        self:playAnimation("bottom", "exit")
        self._hidingBottom   = true
        self._openingFilter  = false
        self._openingOrder   = false
    end
end

function KUIStoryNode:registerAllTouchEvent()
    local title       = self._imageBase:getChildByName("ProjectNode_title")
    local panel1      = title:getChildByName("Panel_1")
    local buttonClose = panel1:getChildByName("Button_close")
    local buttonBack  = panel1:getChildByName("Button_back")
    local function onClose(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")  
            self:playPanelCloseAnimation(false)
        end
    end
    buttonClose:addTouchEventListener(onClose)
    buttonBack:addTouchEventListener(onClose)

    local buttonProject = self._mainLayout:getChildByName("ProjectNode_home")
    local panelHome     = buttonProject:getChildByName("Panel_common_home")
    local buttonHome    = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")   
            KSound.playEffect("close")       
            self:playPanelCloseAnimation(true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    local rightProject      = self._imageBase:getChildByName("ProjectNode_right")
    local rightPanel1       = rightProject:getChildByName("Panel_1")
    local panelButton       = rightPanel1:getChildByName("Panel_button")
    local mainStoryButton   = panelButton:getChildByName("Button_1")
    local function onMainStory(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onMainStory~")   
            self:showChapterStory(TabType.MAIN_STORY)
        end
    end
    mainStoryButton:addTouchEventListener(onMainStory)

    local extraStoryButton  = panelButton:getChildByName("Button_2")
    local function onExtraStory(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onExtraStory~")   
            self:showChapterStory(TabType.EXTRA_STORY)
        end
    end
    extraStoryButton:addTouchEventListener(onExtraStory)

    local navigateButton    = panelButton:getChildByName("Button_3")
    local function onNavigate(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onNavigate~")   
            self:showNavigateStory()
        end
    end
    navigateButton:addTouchEventListener(onNavigate)

    local panelScreen   = self._imageBase:getChildByName("Panel_screen")
    local function onPanelScreen(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onPanelScreen ~")   
            if self._openingFilter then
                self:setFilterVisible(false)
            end

            if self._openingOrder then
                self:setOrderVisible(false)
            end
        end
    end
    panelScreen:addTouchEventListener(onPanelScreen)

    local bottom        = self._imageBase:getChildByName("ProjectNode_bottom")
    local panel1        = bottom:getChildByName("Panel_1")
    local bottomBase    = panel1:getChildByName("Image_bottom_base")
    local filterButton  = bottomBase:getChildByName("Button_type")
    local function onFilter(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onFilter ~")   
            self:setFilterVisible(not self._openingFilter)
        end
    end
    filterButton:addTouchEventListener(onFilter)

    local orderButton   = bottomBase:getChildByName("Button_name")
    local function onSort(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onSort ~")   
            self:setOrderVisible(not self._openingOrder)
        end
    end
    orderButton:addTouchEventListener(onSort)

    local searchButton   = bottomBase:getChildByName("Button_search")
    local function onSearch(sender, type)
        if type ~= ccui.TouchEventType.ended then
            cclog("click onSearch ~")   
            self:playInputAnimation(true)
        end
    end
    searchButton:addTouchEventListener(onSearch)

    local buttonTypeList = self._imageBase:getChildByName("Image_type_base")
    for filterType, filterName in pairs(FilterType) do
        local button = buttonTypeList:getChildByName("Button_" .. filterName)
        local function onTypeFilter(sender, type)
            if type ~= ccui.TouchEventType.ended then
                cclog("click onTypeFilter ~")   
                self:setFilterVisible(false)
                self:setFilter(filterType)
            end
        end
        button:addTouchEventListener(onTypeFilter)
    end

    local buttonSortList = self._imageBase:getChildByName("Image_name_base")
    for order, orderConfig in pairs(OrderType) do
        local orderName = orderConfig.name
        local button    = buttonSortList:getChildByName("Button_" .. orderName)
        local function onTypeSort(sender, type)
            if type ~= ccui.TouchEventType.ended then
                cclog("click onTypeSort ~")   
                self:setOrderVisible(false)
                self:setOrder(order)
            end
        end
        button:addTouchEventListener(onTypeSort)
    end
end

function KUIStoryNode:jumpToChapter(chapterID)
    if self._tabType ~= TabType.NAVIGATE then
        local scrollView  = self._leftScrollData.scrollView
        for index, chapterConfig in ipairs(self._leftScrollData.dataList) do
            local control = scrollView:getChildByName(tostring(chapterConfig.nID))
            if control then
                if chapterConfig.nID == chapterID then
                    scrollView:jumpToPercentVertical(index / #self._leftScrollData.dataList * 100)
                    self:showStoryByChapterID(chapterConfig.nID)
                end
            end
        end
    end
end

function KUIStoryNode:highlightChapter(chapterID)
    if self._tabType ~= TabType.NAVIGATE then
        local scrollView  = self._leftScrollData.scrollView
        for index, chapterConfig in ipairs(self._leftScrollData.dataList) do
            local control = scrollView:getChildByName(tostring(chapterConfig.nID))
            if control then
                control:setBrightStyle(ccui.BrightStyle.normal)
                if chapterConfig.nID == chapterID then
                    control:setBrightStyle(ccui.BrightStyle.highlight)
                end
            end
        end
    end
end

function KUIStoryNode:jumpToCard(cardID)
    if self._tabType == TabType.NAVIGATE then
        local scrollView  = self._leftScrollData.scrollView
        for index, config in ipairs(self._leftScrollData.dataList) do
            if config.nCardID == cardID then
                scrollView:jumpToPercentVertical(index / #self._leftScrollData.dataList * 100)
                self:showStoryByCardID(cardID)
                return
            end
        end
    end
end

function KUIStoryNode:highlightCard(cardID)
    if self._tabType == TabType.NAVIGATE then
        local controlList = self._leftScrollData.itemList
        local scrollView  = self._leftScrollData.scrollView
        for idx, v in ipairs(controlList) do 
            print(idx, v:getName())
        end
        for index, config in ipairs(self._leftScrollData.dataList) do
            local control = scrollView:getChildByName(tostring(config.nID))
            if control then
                local button  = control:getChildByName("Button_unit")
                button:setBrightStyle(ccui.BrightStyle.normal)
                if config.nCardID == cardID then
                    button:setBrightStyle(ccui.BrightStyle.highlight)
                end
            end
        end
    end
end

function KUIStoryNode:getEnterAction()
    return nil, nil
end

function KUIStoryNode:onEnterActionFinished()
    self:enterAnimation()
end

function KUIStoryNode:onNodeEnter()
end

function KUIStoryNode:onNodeExit()
end

function KUIStoryNode:enterAnimation()    
    for _, aniName in pairs(self._enterExitAnimation) do
        self:playAnimation(aniName, "enter")
    end
end

function KUIStoryNode:exitAnimation()
    local delayTime = 0
    for _, aniName in pairs(self._enterExitAnimation) do
        local aniTime = self:playAnimation(aniName, "exit")
        if aniTime > delayTime then
            delayTime = aniTime
        end
    end

    return delayTime
end

function KUIStoryNode:playPanelCloseAnimation(isReturnOffice)
    local delayTime = self:exitAnimation()
    delayExecute(self._mainLayout,function ()
        KUtil.closePanel(self, "Story", isReturnOffice)
    end, delayTime)
end

function KUIStoryNode:registerAllCustomEvent(parameters)
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onStoryReward(storyID, items)
        KUtil.playGetItemAnimation(self._parent, items)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_STORY_REWARD, onStoryReward) 

    local function onStoryPlayEnd()
        require("src/network/KC2SProtocolManager"):GainStoryReward(self._playingStoryID)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_STORY_PLAY_END, onStoryPlayEnd) 
end

function KUIStoryNode:onCleanup()
    self._chapterUnit:release()  
    self._cardUnit:release()
    self._storyUnit:release()
    if self._inputProjectNode then
        self._inputProjectNode:removeFromParent()
    end
end

return KUIStoryNode