--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamChangeSkillNode.lua
--  Creator     : lvsongxin
--  Date        : 2015/08/03   15:00
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************

local m_tLabelName  = {"Image_sort_name", "Image_sort_star", "Image_sort_level", "Image_sort_time", "Image_sort_type"}
local m_tSortType   = {NAME = 1, STAR = 2, LEVEL = 3, TIME = 4}
local m_tButtonName = {"Button_name", "Button_star", "Button_level", "Button_time"}
local EQUIP_TYPE_COUNT     = 6
local SHOW_LIST_SIZE       = 10
local CLICK_DELAY_FRAME    = 30
local MAX_CHECK_BOX        = 6
local SKILL_RESOURCE_INDEX = 5
local KSetting = require("src/logic/KSetting")
local m_tItemLevelPath  = "res/ui/ui_material/public/common_gear_level%d.png"

local m_tButtonTexture = 
{
    ["buttonNormalTexture"]   = "res/ui/ui_material/public/dj_unit_base.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/public/dj_unit_base_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/public/dj_unit_base.png",
}

local m_tBouttonTexture =
{
    ["normal"]   = "res/ui/ui_material/public/common_lock_open.png", 
    ["press"]    = "res/ui/ui_material/public/common_lock.png", 
    ["disable"]  = "res/ui/ui_material/public/common_lock_open.png",
}

local KUITeamChangeSkillNode = class(
    "KUITeamChangeSkillNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamChangeSkillNode:ctor()
    self._mainLayout      = nil
    self._parent          = nil
    self._uiPath          = nil
    self._chooseEquipID   = nil
    self._sortType        = KSetting.getInt(KSetting.Key.EQUIP_CHANGE_CHOOSE_COMMON, KUtil.CHOOSE_COMMON_TYPE.NAME)
    self._baseControl     = nil
    self._equipListData   = {}
    self._equipListUI     = {}
    self._pageData        = {}
    self._tStarlist       = {}
    self._animationList   = {}
    self._position        = nil
end

function KUITeamChangeSkillNode.create(owner, nodeData)
    local currentNode       = KUITeamChangeSkillNode.new()

    currentNode._parent     = owner
    currentNode._uiPath     = "res/ui/layout_gear_select.csb"
    currentNode._position   = nodeData.position
    currentNode:init()

    return currentNode
end

local function tryChangeCardEquip(self)
    if not self._chooseEquipID then
        showNoticeByID("team.selectEquip")
        return
    end
    local equipItem = KUtil.getEquipById(self._chooseEquipID)  
    if not equipItem then return end

    local oneSkill = KUtil.getSkillByIndex(self._position)
    if oneSkill then
        local equipItem   = KUtil.getEquipById(oneSkill.nEquipID)  
        local equipConfig = KConfig.equipInfo[equipItem.nTemplateID]
        local bIsFull = (oneSkill.nLeftTimes >= equipConfig.nUseTime)
        if not bIsFull then
            showNoticeByID("skill.isNotFull")
            return
        end
    end

    require("src/network/KC2SProtocolManager"):skillEnterRole(self._chooseEquipID, self._position)
end

function KUITeamChangeSkillNode:getShowListWithStar(showList)
    if not next(self._tStarlist) then
        return showList
    end

    local newShowList = {}
    for k,equip in pairs(showList) do
        local equipConfig = KConfig.equipInfo[equip.nTemplateID]
        if self._tStarlist[equipConfig.nGrade] then
            newShowList[#newShowList + 1] = equip
        end
    end

    return newShowList
end

function KUITeamChangeSkillNode:getSortListByKey()
    local onSort = function(equip1, equip2)
        local equipConfig1 = KConfig.equipInfo[equip1.nTemplateID]
        local equipConfig2 = KConfig.equipInfo[equip2.nTemplateID]
        if m_tSortType.LEVEL == self._sortType then
            return equipConfig1.nGrade > equipConfig2.nGrade
        elseif m_tSortType.STAR == self._sortType then
            return equipConfig1.nGrade > equipConfig2.nGrade
        elseif m_tSortType.TYPE == self._sortType then
            return equipConfig1.nEquipType > equipConfig2.nEquipType
        elseif m_tSortType.NAME == self._sortType then
            return equipConfig1.szName < equipConfig2.szName
        elseif m_tSortType.TIME == self._sortType then
            return equip1.nCreateTime > equip2.nCreateTime
        end
        return equip1.nID > equip2.nID
    end
    local showList = self:getShowListWithStar(self._equipListData)
    table.sort(showList,  onSort)
    return showList
end

local function refreshDisenableArea(self)
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")

    -- set gear unload button visible
    local projectNode           = imageCommon:getChildByName("ProjectNode_buttom")
    local panelNode             = projectNode:getChildByName("Panel_1")
    local buttonGearUnload      = panelNode:getChildByName("Button_gear_unload")
    buttonGearUnload:setVisible(false)
    buttonGearUnload:setTouchEnabled(false)
end

local function refreshLeftEquipDescription(self, panelGear, szTextName, nTemplateID)
    local tData = {}
    if nTemplateID then
        local strNowProp = KUtil.getSkillDescriptionList(nTemplateID)
        tData            = KUtil.skillAttributeListForamtValue(strNowProp, nTemplateID)
    end

    local textGearSkill = panelGear:getChildByName(szTextName..SKILL_RESOURCE_INDEX)
    local textGearFirst = panelGear:getChildByName(szTextName..1)
    if nTemplateID and KUtil.isSkillEquip(nTemplateID) then
        textGearFirst:setString("")
        textGearFirst = textGearSkill
    else
        textGearSkill:setString("") 
    end

    
    for i=1, 4 do
        local textBeforeGearData = panelGear:getChildByName(szTextName..i)
        if i == 1 then textBeforeGearData = textGearFirst end
        local szText = tData[i]
        if not szText then
            szText = ""
        else
            if szText[2] then
                szText = szText[1] .. szText[2]
            else
                szText = szText[1]
            end
        end
        textBeforeGearData:setString(szText)
    end
end

local function refreshDataArea(self, equipID)
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")
    local projectNode           = imageCommon:getChildByName("ProjectNode_gear_info")
    local panelGear             = projectNode:getChildByName("Panel_1")

    local beforeSkill           = KUtil.getSkillByIndex(self._position)
    local afterEquip            = KUtil.getEquipById(equipID)  

    if beforeSkill ~= nil then
        local beforeEquip           = KUtil.getEquipById(beforeSkill.nEquipID)  
        local equipConfig           = KConfig.equipInfo[beforeEquip.nTemplateID]

        local textBeforeGearTitle   = panelGear:getChildByName("Text_gear_before_title")
        local imageBeforeGearIcon   = panelGear:getChildByName("Image_gear_before_pic")
        local imageBeforeGearbase   = panelGear:getChildByName("Image_gear_before_base")
        local imageEquiped          = panelGear:getChildByName("Image_equiped")
        local textEquiped           = imageEquiped:getChildByName("Text_equiped")

        textBeforeGearTitle:setString(equipConfig.szName)
        refreshLeftEquipDescription(self, panelGear, "Text_gear_before_data_", beforeEquip.nTemplateID)
        local equipPath             = KUtil.getEquipImagePathByID(beforeEquip.nTemplateID)
        imageBeforeGearIcon:loadTexture(equipPath)

        imageBeforeGearbase:loadTexture(string.format(m_tItemLevelPath, equipConfig.nGrade))
        local stringConfig          = KConfig:getLine("string", "Equip.equiped")
        textEquiped:setString(stringConfig.szText)
        textEquiped:setColor(cc.c3b(0, 0, 0))
        imageBeforeGearIcon:setVisible(true)
    else
        local imageBeforeGearIcon   = panelGear:getChildByName("Image_gear_before_pic")
        local imageEquiped          = panelGear:getChildByName("Image_equiped")
        local textEquiped           = imageEquiped:getChildByName("Text_equiped")
        local stringConfig          = KConfig:getLine("string", "Equip.no.Equip")
        textEquiped:setString(stringConfig.szText)
        textEquiped:setColor(cc.c3b(179, 0, 0))
        imageBeforeGearIcon:setVisible(false)
    end

    if afterEquip ~= nil then
        local equipConfig           = KConfig.equipInfo[afterEquip.nTemplateID]
        local textAfterGearTitle    = panelGear:getChildByName("Text_gear_after_title")
        local imageAfterGearIcon    = panelGear:getChildByName("Image_gear_after_pic")
        local imageAfterGearbase    = panelGear:getChildByName("Image_gear_after_base")
        local imageSelected         = panelGear:getChildByName("Image_selected")

        textAfterGearTitle:setString(equipConfig.szName)
        refreshLeftEquipDescription(self, panelGear, "Text_gear_after_data_", afterEquip.nTemplateID)

        local equipPath = KUtil.getEquipImagePathByID(afterEquip.nTemplateID)
        imageAfterGearIcon:loadTexture(equipPath)

        imageAfterGearbase:loadTexture(string.format(m_tItemLevelPath, equipConfig.nGrade))

        imageAfterGearIcon:setVisible(true)
        imageSelected:setVisible(true)
    else
        local imageAfterGearIcon    = panelGear:getChildByName("Image_gear_after_pic")
        local imageSelected         = panelGear:getChildByName("Image_selected")
        imageAfterGearIcon:setVisible(false)
        imageSelected:setVisible(false)
    end
end

local function resetScrollButtonStatus(self)
    for _, unitControl in pairs(self._pageData.itemList) do
        unitControl:loadTextures(m_tButtonTexture.buttonNormalTexture, m_tButtonTexture.buttonPressTexture, m_tButtonTexture.buttonDisableTexture)
    end
end

local function refreshScrollButtonStatus(self, unitControl, equipID)
    if equipID == self._chooseEquipID then
        unitControl:loadTextures(m_tButtonTexture.buttonPressTexture, m_tButtonTexture.buttonPressTexture, m_tButtonTexture.buttonPressTexture)
    else
        unitControl:loadTextures(m_tButtonTexture.buttonNormalTexture, m_tButtonTexture.buttonPressTexture, m_tButtonTexture.buttonDisableTexture)
    end
end

local function refreshSortButton(self)
    local mainNode     = self._mainLayout
    local imageCommon  = mainNode:getChildByName("Image_common_base")
    local projectNode  = imageCommon:getChildByName("ProjectNode_buttom")
    local panelNode    = projectNode:getChildByName("Panel_1")
    local buttonSort   = panelNode:getChildByName("Button_zb_sort")
    
    for sortType, textName in ipairs(m_tLabelName) do
        local textSort = buttonSort:getChildByName(textName)
        textSort:setVisible(sortType == self._sortType)
    end
end

local function setLockButton(unitControl, isLock)
    local button = unitControl:getChildByName("Button_lock")
    if isLock then
        button:loadTextures(m_tBouttonTexture["press"], m_tBouttonTexture["normal"], m_tBouttonTexture["disable"])
    else
        button:loadTextures(m_tBouttonTexture["normal"], m_tBouttonTexture["press"], m_tBouttonTexture["disable"])
    end
    unitControl.bIsLock = isLock
    local imageDisable = unitControl:getChildByName("Image_zb_gear_disable")
    imageDisable:setVisible(false)
end

function KUITeamChangeSkillNode:updateScrollItemByEquip(unitControl, equip)
    assert(unitControl, "unitControl")
    assert(equip, "equip")

    unitControl:setName(tostring(equip.nID))
    -- update lock
    unitControl.bIsLock = equip.bLock
    setLockButton(unitControl, equip.bLock)
    -- update equip name 
    local equipConfig   = KConfig.equipInfo[equip.nTemplateID]
    assert(equipConfig, "equipConfig "..equip.nTemplateID)

    local panelGearName = unitControl:getChildByName("Panel_gear_name")
    local textGearName  = panelGearName:getChildByName("Text_gear_name")
    textGearName:setString(equipConfig.szName)

    -- update equip nature
    local PanelGear        = unitControl:getChildByName("Panel_gear_data")
    local tNatureText      = {}
    local equipTemplateID  = equip.nTemplateID
    if KUtil.isSkillEquip(equipTemplateID) then
        tNatureText = KUtil.getSkillDescriptionList(equipTemplateID)
        KUtil.skillAttributeListForamtValue(tNatureText, equipTemplateID)
    else
        tNatureText = KUtil.getEquipDescription(equipTemplateID)
    end

    local textGearName   = PanelGear:getChildByName("Text_gear_attribute5")
    for i=1, 4 do
        local textGearData   = PanelGear:getChildByName("Text_gear_attribute"..i)
        local textGearValue  = PanelGear:getChildByName("Text_gear_attribute_value"..i)
        if tNatureText[i] then
            textGearData:setString(tNatureText[i][1])
            textGearData:setVisible(true)
            if tNatureText[i][2] then
                textGearValue:setString(tNatureText[i][2])
                textGearValue:setVisible(true)
            else
                textGearValue:setVisible(false)
            end
        else
            textGearData:setVisible(false)
            textGearValue:setVisible(false)
        end
        if i == 1 then
            if KUtil.isSkillEquip(equipTemplateID) then
                textGearData:setVisible(false)
                textGearValue:setVisible(false)
                if tNatureText[i] then
                    textGearName:setString(tNatureText[i][1])
                    textGearName:setVisible(true)
                end
            else
                textGearName:setVisible(false)
            end
        end
    end
    -- update equip image
    local panelGearIcon    = unitControl:getChildByName("Panel_gear_icon")
    local imageGear        = panelGearIcon:getChildByName("Image_gear")
    local equipPath        = KUtil.getEquipImagePathByID(equip.nTemplateID)
    imageGear:loadTexture(equipPath)

    -- update equip is equiped image
    local imageEquipWord = panelGearIcon:getChildByName("Image_zb_equip_word")
    imageEquipWord:setVisible(false)

    local panelGearIcon = unitControl:getChildByName("Panel_gear_icon") 
   for equipType = 1, EQUIP_TYPE_COUNT do
        local labelNameString = string.format("Image_common_gear_level%d", equipType)
        local labelType = panelGearIcon:getChildByName(labelNameString)
        labelType:setVisible(equipType == equipConfig.nGrade)
    end

    --lock Click Event
    local buttonLock = unitControl:getChildByName("Button_lock")
    local function onLockClick(sender, type)
        if ccui.TouchEventType.ended == type then
            KSound.playEffect("click")
            setLockButton(unitControl, not unitControl.bIsLock)
            require("src/network/KC2SProtocolManager"):lockEquip(equip.nID, not equip.bLock)
        end
    end
    buttonLock:addTouchEventListener(onLockClick)

    local function onUnitClick(sender, type)
        if ccui.TouchEventType.ended == type then
            KSound.playEffect("click")
            refreshDataArea(self, equip.nID)
            self._chooseEquipID = equip.nID
            resetScrollButtonStatus(self)
            refreshScrollButtonStatus(self, unitControl, equip.nID)
        end
    end
    unitControl:addTouchEventListener(onUnitClick)

    refreshScrollButtonStatus(self, unitControl, equip.nID)
end

local function addScrollPageView(self, isCutIn)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_list")
    local panelNode         = projectNode:getChildByName("Panel_select_content")
    local scrollControl     = panelNode:getChildByName("ScrollView_gear_list")
    local slideControl      = panelNode:getChildByName("Slider_scroll_list")

    local showListData = self:getSortListByKey()

    local refreshCall = function(control, dataInfo)
        self:updateScrollItemByEquip(control, dataInfo)
    end

    local parameters = {
        scrollView  = scrollControl,
        slideView   = slideControl,
        itemBase    = self._baseControl,
        dataList    = showListData,
        refreshCall = refreshCall,
        column      = 3,
        row         = 6,
        isCutIn     = isCutIn,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function initUI(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local projectNode   = imageCommon:getChildByName("ProjectNode_gear_info")
    local panelGear     = projectNode:getChildByName("Panel_1")

    local textBeforeGearTitle =  panelGear:getChildByName("Text_gear_before_title")
    textBeforeGearTitle:setString("")

    local  textAfterGearTitle = panelGear:getChildByName("Text_gear_after_title")
    textAfterGearTitle:setString("")

    refreshLeftEquipDescription(self, panelGear, "Text_gear_before_data_")
    refreshLeftEquipDescription(self, panelGear, "Text_gear_after_data_")

    local projectNode   = imageCommon:getChildByName("ProjectNode_gear_list")
    local panelNode     = projectNode:getChildByName("Panel_select_content")
    local scrollControl = panelNode:getChildByName("ScrollView_gear_list")
    self._baseControl   = scrollControl:getChildByName("Button_gear_unit")

    local node = cc.Node:create()
    node:setVisible(false)
    mainNode:addChild(node)
    self._baseControl:removeFromParent(false)
    node:addChild(self._baseControl)

    -- get list data for sorting 
    self._equipListData = KUtil.getSelectSkillList(self._position)

    -- add equip to scroll
    addScrollPageView(self, false)
    -- update weapon count in total
    local projectNode   = imageCommon:getChildByName("ProjectNode_buttom")
    local panelNode     = projectNode:getChildByName("Panel_1")
    local imageContant  = panelNode:getChildByName("Image_contant_value")
    local textQuantity  = imageContant:getChildByName("Text_contant_quantity")
    local allCount      = KPlayer.tItemData.tEquipStoreHouse.nMaxSize
    local currentCount = #KPlayer.tItemData.tEquipStoreHouse.tEquipList
    textQuantity:setString("" .. currentCount .. "/" ..allCount)

    local screenTypeButtons = imageCommon:getChildByName("Image_screen_base_1")
    screenTypeButtons:setVisible(false)
    local screenSortButtons = imageCommon:getChildByName("Image_screen_base_2")
    screenSortButtons:setVisible(false)
end

function KUITeamChangeSkillNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
    end
end

function KUITeamChangeSkillNode:closeAnimation(fun)
    for name, animation in pairs(self._animationList) do
        if name == "home" then
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4], fun)
        else
            KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        end
    end
end

function KUITeamChangeSkillNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")

    local list              = self._animationList
    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_list")
    list.gearList           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_content.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_top")
    list.top                = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_top.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_info")
    list.gearInfo           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_left.csb"), {0, 30, 40, 65}}

    local projectNode       = imageCommon:getChildByName("ProjectNode_buttom")
    list.buttom             = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_gear_select_bottom.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_resource_base")
    list.resourceBase       = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_resource_base.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_button_home")
    list.home               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_home.csb"), {0, 30, 40, 65}}
end

function KUITeamChangeSkillNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUITeamChangeSkillNode:onInitUI()
    self:onInitAnimation()
end

function KUITeamChangeSkillNode:refreshUI()
    initUI(self)
    refreshDisenableArea(self)
    refreshSortButton(self)
    refreshDataArea(self, 0)
end

function KUITeamChangeSkillNode:chooseEquipByStar(star)
    self._tStarlist[star] = true
    addScrollPageView(self, false)
end

function KUITeamChangeSkillNode:unChooseEquipByStar(star)
    self._tStarlist[star] = nil
    addScrollPageView(self, false)
end

function KUITeamChangeSkillNode:registerAllTouchEvent()
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")

    --Home Button
    local nodeHome      = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome     = nodeHome:getChildByName("Panel_common_home")
    local buttonControl = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onHomeButton~")
            KSound.playEffect("close")
            self:closeAnimation(function()
                self._parent:returnOffice()
            end)
        end
    end
    buttonControl:addTouchEventListener(onHomeClick)

    KUtil.updateResourceInfo(self, "qhzb_base.png", function()
        self:closeAnimation(function()
            self._parent:removeNode("TeamChangeSkill")
        end)
    end)

    --confirm Button
    local projectNode       = imageCommon:getChildByName("ProjectNode_gear_info")
    local panelGear         = projectNode:getChildByName("Panel_1")
    local buttonControl     = panelGear:getChildByName("Button_gear_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmButton~")
            KSound.playEffect("addEquip")
            tryChangeCardEquip(self)
        end
    end
    buttonControl:addTouchEventListener(onConfirmClick)

    -- sort button
    local projectNode  = imageCommon:getChildByName("ProjectNode_buttom")
    local panelNode    = projectNode:getChildByName("Panel_1")
    local buttonSort   = panelNode:getChildByName("Button_zb_sort")
    --local screenTypeButtons = imageCommon:getChildByName("Image_screen_base_1")
    local screenSortButtons = imageCommon:getChildByName("Image_screen_base_2")
    local buttonsScreen = imageCommon:getChildByName("Button_screen")
    buttonsScreen:setSwallowTouches(false)
    buttonsScreen:setVisible(false)

    local function onSortClick(sender, type)
        if type == ccui.TouchEventType.ended then
            --KUtil.showUiScale(screenTypeButtons, false)
            local isVisible = not screenSortButtons:isVisible()
            KUtil.showUiScale(screenSortButtons, isVisible)
            buttonsScreen:setVisible(isVisible)

            KSound.playEffect("click")
            cclog("onSortClick~")
        end
    end
    buttonSort:addTouchEventListener(onSortClick)

    local function onScreenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            buttonsScreen:setVisible(false)
            KUtil.showUiScale(screenSortButtons, false)
        end
    end
    buttonsScreen:addTouchEventListener(onScreenClick)

    for type, button in pairs(m_tButtonName) do
        local tempButton = screenSortButtons:getChildByName(button)
        local function onSortItemClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                KUtil.showUiScale(screenSortButtons, false)
                KSound.playEffect("click")
                self._sortType = type
                KSetting.setInt(KSetting.Key.EQUIP_CHANGE_CHOOSE_COMMON, self._sortType)
                refreshSortButton(self)
                addScrollPageView(self, true)
                buttonsScreen:setVisible(false)
            end
        end
        tempButton:addTouchEventListener(onSortItemClick)
    end

    local projectNode    = imageCommon:getChildByName("ProjectNode_top")
    local panelSarts     = projectNode:getChildByName("Panel_check_stars")
    for i = 1, MAX_CHECK_BOX do
        local checkBox   = panelSarts:getChildByName("CheckBox_stars_" .. i)
        local panelClick = checkBox:getChildByName("Panel_click")

        local star       = i
        local function onPanelClick(inSender, inType)
            if inType == ccui.TouchEventType.ended then
                if checkBox:isSelected() then
                    checkBox:setSelected(false)
                    self:unChooseEquipByStar(star)
                else
                    checkBox:setSelected(true)
                    self:chooseEquipByStar(star)
                end
            end
        end
        panelClick:addTouchEventListener(onPanelClick)
    end
end

function KUITeamChangeSkillNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onSelectChange()
        cclog("onEvent ------------> onSelectChange")
        self._parent:removeNode("TeamChangeSkill")
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SKILL_CHANGE, onSelectChange)

    local function onEquipLock(equipID, isLock)
        local mainNode        = self._mainLayout
        local imageCommon     = mainNode:getChildByName("Image_common_base") 
        local projectNode     = imageCommon:getChildByName("ProjectNode_gear_list")
        local panelNode       = projectNode:getChildByName("Panel_select_content")
        local scrollControl   = panelNode:getChildByName("ScrollView_gear_list")
        local baseControl     = scrollControl:getChildByName(tostring(equipID))
        if not baseControl then return end
        setLockButton(baseControl, isLock)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_EQUIP_LOCK, onEquipLock)

    local function onResourceUpdate()
        cclog("----------> onEvent onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

function KUITeamChangeSkillNode:onCleanup()
    self._baseControl     = nil
    self._equipListData   = nil
    self._equipListUI     = nil
end

return KUITeamChangeSkillNode
