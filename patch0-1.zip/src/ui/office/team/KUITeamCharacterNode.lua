--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamCharacterNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/03/15   14:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local EQUIP_TYPE_COUNT  = 6
local MAX_EQUIP_COUNT   = 4
local SHOW_SIZE         = 7
local CARD_EMERGENCY_REPAIR_ITEM_ID = 11

local m_tRangeNameAndValue = 
{
    {name = "Image_sx_range__curved_fire"  , value = 0,}, 
    {name = "Image_sx_range_near"   ,        value = 1,}, 
    {name = "Image_sx_range_mid" ,           value = 2,}, 
    {name = "Image_sx_range_far"    ,        value = 3,}, 
    {name = "Image_sx_range_superfar"    ,   value = 4,}, 
}

local KUITeamCharacterNode = class(
    "KUITeamCharacterNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamCharacterNode:ctor()
    self._mainLayout      = nil
    self._parent          = nil
    self._uiPath          = nil
    self._cardID          = nil
    self._baseControl     = nil
    self._isOpenPanel     = false
    self._showCardList    = {}
end

function KUITeamCharacterNode.create(owner, nodeData)
    local currentNode = KUITeamCharacterNode.new()
    
    currentNode._parent    = owner
    currentNode._uiPath    = "res/ui/layout_character.csb"
    currentNode._cardID    = nodeData.cardID
    currentNode:init()

    return currentNode
end

local function playLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_card")

    local openEndFrame    = 40
    local closeStartFrame = 65
    local animationName   = "ani_cardbase_big"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRightAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_base_info")

    local openEndFrame    = 41
    local closeStartFrame = 50
    local animationName   = "ani_character_right"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playItemListAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_good_props")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_character_good_props"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playArrowAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_button_page")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_character_button_page"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playSkinAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_clothing")

    local openEndFrame    = 35
    local closeStartFrame = 50
    local animationName   = "ani_character_clothing"
    self._showingSkin = isOpen
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playSkinConfirmAnimation(self, isOpen)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_clothing_conform")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_character_clothing_conform"
    self._showingSkinConfirm = isOpen
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function setSkinConfirmText(self, name, text)
    local mainNode    = self._mainLayout
    local projectNode = mainNode:getChildByName("ProjectNode_clothing_conform")
    local popupBase   = projectNode:getChildByName("Image_popup_base")
    local skinName    = popupBase:getChildByName("Text_cloting_name")
    local tipsBase    = popupBase:getChildByName("Image_tips_base")
    local label       = tipsBase:getChildByName("Text_tips_content")

    skinName:setString(name)
    label:setString(text)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_card")
    projectNode:stopAllActions()

    local projectNode     = imageCommon:getChildByName("ProjectNode_base_info")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_button_page")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_good_props")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_clothing")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_clothing_conform")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playLeftAnimation(self, false))
        table.insert(framesList, playArrowAnimation(self, false))
        table.insert(framesList, playRightAnimation(self, false))
        if self._isOpenPanel then
            table.insert(framesList, playItemListAnimation(self, false))
        end

        if self._showingSkin then
            table.insert(framesList, playSkinAnimation(self, false))
        end

        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "TeamCharacter", callBacks, isReturnOffice)
end

local function getListData(itemType)
    local showListData = {}
    for _, itemInfo in pairs(KPlayer.tItemData.tStoreHouse.tItemList) do
        local itemConfig = KConfig.itemInfo[itemInfo.nTemplateID]
        if itemConfig.nType == itemType then
            table.insert(showListData, itemInfo)
        end
    end

    local function funSort(item1, item2)
        local itemConfig1 = KConfig.itemInfo[item1.nTemplateID]
        local itemConfig2 = KConfig.itemInfo[item2.nTemplateID]
        return itemConfig1.szName < itemConfig2.szName 
    end
    table.sort(showListData, funSort)

    return showListData
end

local function showAddFeelingTip(card)
    if card.nFeeling < KUtil.MAX_FEELING then
        showNoticeByID("common.itemUsedSuccess")
    else
        local cardInfo = KConfig.cardInfo[card.nTemplateID]
        local showString = string.format(KUtil.getStringByKey("marry.feelMax"), cardInfo.szName, KUtil.MAX_FEELING .. "%", KUtil.MAX_MARRY_CARD_LEVEL)
        showConfirmation(showString)
    end
end

local function updateScrollItem(self, newControl, itemInfo)
    newControl:setName(itemInfo.nID)

    local itemConfig = KConfig.itemInfo[itemInfo.nTemplateID]

    local imageItemBase   = newControl:getChildByName("Image_item_base")
    local imageIcon       = imageItemBase:getChildByName("Image_icon")
    -- update icon
    local itemPath = KUtil.getItemImagePathByID(itemInfo.nTemplateID)
    imageIcon:loadTexture(itemPath)
    --update name
    local textName        = newControl:getChildByName("Text_name")
    textName:setString(itemConfig.szName .. " X" .. itemInfo.nCount)

    local nTemplateID = itemInfo.nTemplateID
    local buttonUse = newControl:getChildByName("Button_use")
    local itemType = itemConfig.nType
    local function onUseItem(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local cardID = self._cardID
            local card   = KUtil.getCardById(cardID)
            if card.bRing then 
                showNoticeByID("marry.haveMarry")
                return 
            end
            require("src/network/KC2SProtocolManager"):addFeelingByItem(self._cardID, nTemplateID)
        end
    end
    buttonUse:addTouchEventListener(onUseItem)

    local description = ""
    if itemType == ITEM_SMALL_TYPE.FEELING then
        description = string.format(KUtil.getStringByKey("marry.description"), itemConfig.nNumber)
    else
        description = string.format(KUtil.getStringByKey("marry.levelLimit"), itemConfig.nUseLevel)
    end
    local textDescription = newControl:getChildByName("Text_good_props")
    textDescription:setString(description)
end

local function refreshScrollView(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_good_props")
    local panelGoodPro    = projectNode:getChildByName("Panel_good_props")
    local imageGoodPro    = panelGoodPro:getChildByName("Image_good_props")
    local slideView       = panelGoodPro:getChildByName("Slider_1")
    local scrollViewGood  = imageGoodPro:getChildByName("ScrollView_1")

    scrollViewGood:removeAllChildren()

    local listData   = getListData(ITEM_SMALL_TYPE.FEELING)
    local showListUI = {}
    for _, itemInfo in pairs(listData) do
        local newControl = self._baseControl:clone()
        updateScrollItem(self, newControl, itemInfo)
        table.insert(showListUI, newControl)
    end
    KUtil.addScrollView(scrollViewGood, showListUI, false, slideView)
end

local function setPanelVisible(self, isCutIn)
    if self._isOpenPanel == isCutIn then
        return
    end

    if isCutIn then
        refreshScrollView(self, false)
    end

    self._isOpenPanel  = isCutIn
    local mainNode     = self._mainLayout
    local projectNode  = mainNode:getChildByName("ProjectNode_good_props")
    playItemListAnimation(self, isCutIn)
end

local function handleMarryPanel(self)
    local cardID = self._cardID
    local card   = KUtil.getCardById(cardID)
    if card.bRing then 
        showNoticeByID("marry.haveMarry")
        return 
    end

    if card.nFeeling >= KUtil.MAX_FEELING then
        -- get ring
        KUtil.requestMarryCard(cardID)
    else
        local isOpenPanel = not self._isOpenPanel
        setPanelVisible(self, isOpenPanel)
    end
end

local function closeSelectPanel(self)
    if not self._isOpenPanel then return end
    local isOpenPanel = not self._isOpenPanel
    setPanelVisible(self, isOpenPanel)
end

local function refreshShowCardList(self)
    local expeditionList = KPlayer.tExpeditionData.tExpeditionList
    local teamList = KPlayer.tTeamData.tTeamList
    local cardInExpedition = {}
    local enterTeam = {}
    for i, oneExpedition in pairs(expeditionList) do
        enterTeam[oneExpedition.nTeamID] = true
    end
    for tTeamID, isTrue in pairs(enterTeam) do
        local oneTeam = HArray.FindFirst(teamList, "nIndex", tTeamID)
        if oneTeam then 
            for i, cardID in pairs(oneTeam.tCardIDList) do
               cardInExpedition[cardID] = true
            end
        end
    end
    self._showCardList = {}
    for i, oneCard in pairs(KPlayer.tCardData.tStoreHouse.tCardList) do
        if not cardInExpedition[oneCard.nID] then
            table.insert(self._showCardList, oneCard)
        end
    end

    local KSetting = require("src/logic/KSetting")
    local sortType = KSetting.getInt(KSetting.Key.COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    self._showCardList = KUtil.getUnitSelectSortList(self._showCardList, sortType)
end

local function getListCardIndex(self)
    for index, card in ipairs(self._showCardList) do
        if card.nID == self._cardID then
            return index
        end
    end
    return 0
end

-- delay refresh
local function previousOne(self)
    local cardIndex = getListCardIndex(self)
    assert(cardIndex, "card ID not found" .. self._cardID)
    cardIndex = cardIndex - 1
    if cardIndex <= 0 then cardIndex = #self._showCardList end
    local targetCard = self._showCardList[cardIndex]
    assert(targetCard, "targetCard is nil")

    self._cardID = targetCard.nID
    self:refreshUI()
end

local function nextOne(self)
    local cardIndex = getListCardIndex(self)
    assert(cardIndex, "card ID not found" .. self._cardID)
    cardIndex = cardIndex + 1
    if cardIndex > #self._showCardList then cardIndex = 1 end
    local targetCard = self._showCardList[cardIndex]
    assert(targetCard, "targetCard is nil")

    self._cardID = targetCard.nID
    self:refreshUI()
end

local function getSkinListData(cardTemplateID)
    local skinList = {{nID = 0,},}-- {nID = 1,},{nID = 2,},{nID = 3,},{nID = 4,},{nID = 5,},{nID = 6,}, {nID = 7,},}
    local cardConfig = KConfig.cardInfo[cardTemplateID]
    for skinID, skinInfo in pairs(KConfig.skin) do
        local cardIDList = string.split(skinInfo.szCardID, "|")
        for _, szCardID in ipairs(cardIDList) do
            if tonumber(szCardID) == cardTemplateID then
                table.insert(skinList, {nID = skinID})
                break
            end
        end
    end

    return skinList
end

local function refreshCardLeftArea(self)
    local mainNode      = self._mainLayout            
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local projectCard   = imageCommon:getChildByName("ProjectNode_card")
    
    local cardID        = self._cardID
    local cardData      = KUtil.getCardById(cardID)

    KUtil.updateCardBig(projectCard, cardData, true)
end

local function updateScrollSkin(self, newButtonSkin, skinInfo)
    local skinList = KPlayer.tSkinData.tSkinList
    newButtonSkin:setName(skinInfo.nID)

    local skinConfig = KConfig.skin[skinInfo.nID]
    local card       = KUtil.getCardById(self._cardID)
    local cardConfig = KConfig.cardInfo[card.nTemplateID]

    local panelIcon  = newButtonSkin:getChildByName("Panel_icon")
    local imageIcon  = panelIcon:getChildByName("Image_icon")

    local buttonUnit = newButtonSkin:getChildByName("Button_unit")
    local skinName   = buttonUnit:getChildByName("Text_clothing_name")

    local imagePath = KUtil.getSkinImagePathByID(skinInfo.nID, card.nTemplateID)
    imageIcon:loadTexture(imagePath)
    if skinConfig then
        skinName:setString(skinConfig.szName)
    else
        skinName:setString(KUtil.getStringByKey("skin.defaultName"))
    end

    local function onSelectSkin(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("on select skin:" .. skinInfo.nID)
            if self._showingSkinConfirm then
                return
            end

            local hasSkin = HArray.FindFirstByValue(skinList, skinInfo.nID)
            if skinInfo.nID > 0 and (not hasSkin) then
                local goodConfig = KUtil.getGoodConfigByItem(skinInfo.nID, 1, ITEM_TYPE.SKIN)
                if not goodConfig then
                    showNoticeByID("skin.notInShop")
                    return
                end

                local text = string.format(KUtil.getStringByKey("skin.buyTips"), goodConfig.nPrice)
                setSkinConfirmText(self, skinConfig.szName, text)
                playSkinConfirmAnimation(self, true)
                self._tryBuySkin = skinInfo.nID
                return
            end

            local cardID   = self._cardID
            local card     = KUtil.getCardById(cardID)
            card.nSkinTemplateID = skinInfo.nID
            refreshCardLeftArea(self)
        end
    end
    buttonUnit:addTouchEventListener(onSelectSkin)

    local hasSkin = HArray.FindFirstByValue(skinList, skinInfo.nID)
    if skinInfo.nID > 0 and (not hasSkin) then
        KUtil.setWidgetGray(imageIcon)
    end
end

local function refreshSkinScrollView(self)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local clothNode         = mainNode:getChildByName("ProjectNode_clothing")
    local panelClothingBase = clothNode:getChildByName("Panel_clothing_base")
    local scrollView        = panelClothingBase:getChildByName("ScrollView_1")
    local slider            = panelClothingBase:getChildByName("Slider_1")

    scrollView:removeAllChildren()

    local cardData   = KUtil.getCardById(self._cardID)
    local skinList   = getSkinListData(cardData.nTemplateID)
    local refreshCall = function(control, skinInfo)
        updateScrollSkin(self, control, skinInfo)
    end

    local parameters = {
        scrollView  = scrollView,
        slideView   = slider,
        itemBase    = self._skinButtonUnit,
        row         = 20,
        column      = 3,
        dataList    = skinList,
        refreshCall = refreshCall,
    }
    self._pageData = KUtil.addDynamicScrollView(parameters)
end

local function refreshCardRightArea(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local projectRight  = imageCommon:getChildByName("ProjectNode_base_info")

    local panelInformation = projectRight:getChildByName("Panel_frame_information_02")

    local cardID        = self._cardID
    local cardData      = KUtil.getCardById(cardID)
    assert(cardData, "cardData not exist,cardID is:" .. cardID)
    local cardConfig    = KConfig.cardInfo[cardData.nTemplateID]
    local attribute     = KUtil.getCurrentAttribute(cardData)
    local slotCount     = cardConfig.nEquipSlot
    local equipItem     = KUtil.getCardEquipByPosition(cardData, 1)
    local nameLenLimit  = 4

    -- main equip node
    local panelMainCommon      = panelInformation:getChildByName("Button_common_gear_main")
    local buttonMainChange     = panelMainCommon:getChildByName("Button_change")
    local buttonMainIconChange = panelMainCommon:getChildByName("Image_gear_main")
    local buttonMainAdd        = panelInformation:getChildByName("Button_add_1")
    local imageMainAdd         = panelInformation:getChildByName("Image_button_add_1")

    local showMainGear         = (equipItem ~= nil)
    panelMainCommon:setVisible(showMainGear)
    buttonMainChange:setTouchEnabled(showMainGear)
    buttonMainIconChange:setTouchEnabled(showMainGear)
    buttonMainAdd:setVisible(not showMainGear)
    buttonMainAdd:setTouchEnabled(not showMainGear)
    imageMainAdd:setVisible(false)

    if showMainGear then 
        local equipConfig      = KConfig.equipInfo[equipItem.nTemplateID]
        local textMainGearName = panelMainCommon:getChildByName("Text_gear_name_main") 
        local mainGearName     = KUtil.shortString(equipConfig.szName, nameLenLimit)
        textMainGearName:setString(mainGearName)

        for equipType = 1, EQUIP_TYPE_COUNT do
            local labelNameString = string.format("Image_gear_main_bg_level%d", equipType)
            local imageType       = panelMainCommon:getChildByName(labelNameString)
            imageType:setVisible(equipType == equipConfig.nGrade)
        end

        local imageMainGear = panelMainCommon:getChildByName("Image_gear_main")
        local equipPath     = KUtil.getEquipImagePathByID(equipItem.nTemplateID)
        imageMainGear:loadTexture(equipPath)
    end
    
    for equipIndex = 2, MAX_EQUIP_COUNT do 
        local panelLevelIndex     = equipIndex - 1
        local panelGearCommon     = panelInformation:getChildByName("Button_common_gear_sub_" .. panelLevelIndex)
        local buttonSubUnLoad     = panelGearCommon:getChildByName("Button_unload_" .. panelLevelIndex)
        local buttonSubIconChange = panelGearCommon:getChildByName("Image_gear_sub_" .. panelLevelIndex)
        local textGearName        = panelGearCommon:getChildByName("Text_gear_name_sub_" .. panelLevelIndex)
        local buttonSubAdd        = panelInformation:getChildByName("Button_add_" .. equipIndex)
        local imageSubAdd         = panelInformation:getChildByName("Image_button_add_" .. equipIndex)
        local tempEquip           = KUtil.getCardEquipByPosition(cardData, equipIndex) 

        local showSubGear     = (tempEquip ~= nil)
        panelGearCommon:setVisible(showSubGear)
        buttonSubUnLoad:setTouchEnabled(showSubGear)
        buttonSubIconChange:setTouchEnabled(showSubGear)
        buttonSubAdd:setVisible(not showSubGear)
        buttonSubAdd:setTouchEnabled(not showSubGear)    

        local isUnLockEquipPos = false
        if equipIndex <= slotCount then
            isUnLockEquipPos = true
        end
        imageSubAdd:setVisible(not isUnLockEquipPos) 
        if showSubGear then 
            local tempEquipConfig = KConfig.equipInfo[tempEquip.nTemplateID]
            local stringGearName  = KUtil.shortString(tempEquipConfig.szName, nameLenLimit)
            textGearName:setString(stringGearName)

            local equipPath = KUtil.getEquipImagePathByID(tempEquip.nTemplateID)
            buttonSubIconChange:loadTexture(equipPath)

            for equipType = 1, EQUIP_TYPE_COUNT do
                local labelNameString = string.format("Image_gear_sub_%d_bg_level%d", panelLevelIndex, equipType)
                local imageType       = panelGearCommon:getChildByName(labelNameString)
                imageType:setVisible(equipType == tempEquipConfig.nGrade)
            end
        else
            buttonSubAdd:setVisible(isUnLockEquipPos)
            buttonSubAdd:setTouchEnabled(isUnLockEquipPos) 
        end
     end
     
    local labelHP  = panelInformation:getChildByName("Text_naijiu_data")
    labelHP:setString(attribute[ATTRIBUTE.HP])
    
    local labelAttack   = panelInformation:getChildByName("Text_huoli_data")
    labelAttack:setString(attribute[ATTRIBUTE.ATTACK])
    
    local labelPenetrate = panelInformation:getChildByName("Text_chuantou_data")
    labelPenetrate:setString(attribute[ATTRIBUTE.PENETRATE])
    
    local labelFrontArmour = panelInformation:getChildByName("Text_qianjia_data")
    labelFrontArmour:setString(attribute[ATTRIBUTE.FRONTARMOUR])
    
    local labelRearArmor = panelInformation:getChildByName("Text_houjia_data")
    labelRearArmor:setString(attribute[ATTRIBUTE.REARARMOUR])
    
    local labelScout = panelInformation:getChildByName("Text_zhencha_data")
    labelScout:setString(attribute[ATTRIBUTE.SCOUT])
    
    local labelSpeedData = panelInformation:getChildByName("Text_sudu_data")
    labelSpeedData:setString(attribute[ATTRIBUTE.SPEED])
    
    local labelDodge = panelInformation:getChildByName("Text_huibi_data")
    labelDodge:setString(attribute[ATTRIBUTE.DODGE])
    
    local labelHide = panelInformation:getChildByName("Text_yinbi_data")
    labelHide:setString(attribute[ATTRIBUTE.HIDE])
    
    local labelNightFight = panelInformation:getChildByName("Text_yezhan_data")
    labelNightFight:setString(attribute[ATTRIBUTE.NIGHTBATTLE])

    local rangeValue = attribute[ATTRIBUTE.RANGE]
    for _, info in ipairs(m_tRangeNameAndValue) do
        panelInformation:getChildByName(info.name):setVisible(false)
    end

    for _, info in ipairs(m_tRangeNameAndValue) do
        if info.value >= rangeValue then
            panelInformation:getChildByName(info.name):setVisible(true)
            break
        end
    end

    if self._showingSkin then
        local card     = KUtil.getCardById(self._cardID)
        self._oldSkin  = card.nSkinTemplateID
        refreshSkinScrollView(self)
    end
end

function KUITeamCharacterNode:refreshCardSkill()
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_buff")
    local panelSkill      = projectNode:getChildByName("Panel_1")
    local cardID          = self._cardID
    local card            = KUtil.getCardById(cardID)

    local oneTraining     = HArray.FindFirst(KPlayer.tTrainingList, "nTemplateID", card.nTemplateID) or {}
    local trainingWarList = oneTraining.tWarList or {}
    local panelIndex = 0
    while true do
        panelIndex      = panelIndex + 1
        local warID     = trainingWarList[panelIndex]
        local panelName = string.format("Button_buff_%d", panelIndex)
        local imageButtonBuff = panelSkill:getChildByName(panelName)
        if not imageButtonBuff then break end

        if warID then
            imageButtonBuff:setVisible(true)

            local cardWarItem = KUtil.getCardWarItem(card.nTemplateID, warID)
            assert(cardWarItem, string.format("card=%d, warID=%d not found!", card.nTemplateID, warID))

            local skillConfig   = KConfig.trainingSkill[cardWarItem.nSkill]
            assert(skillConfig, "skillConfig not found! nSkill=:" .. cardWarItem.nSkill)

            local imageDescriptionBase = imageButtonBuff:getChildByName("Image_description_base")
            local textDescription      = imageDescriptionBase:getChildByName("Text_descrition_value")
            textDescription:setString(skillConfig.szDescribe1)

            local iconPath = string.format("res/ui/ui_material/icon_buff/%s.png", skillConfig.szIcon)
            imageButtonBuff:loadTextures(iconPath, iconPath, iconPath)
        else
            imageButtonBuff:setVisible(false)
        end
    end
end

local function initUI(self)
    if self._baseControl then return end
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_good_props")
    local panelGoodPro    = projectNode:getChildByName("Panel_good_props")
    local imageGoodPro    = panelGoodPro:getChildByName("Image_good_props")
    local scrollViewGood  = imageGoodPro:getChildByName("ScrollView_1")

    local mainNode          = self._mainLayout
    local clothNode         = mainNode:getChildByName("ProjectNode_clothing")
    local panelClothingBase = clothNode:getChildByName("Panel_clothing_base")
    local scrollViewSkin    = panelClothingBase:getChildByName("ScrollView_1")

    self._baseControl    = scrollViewGood:getChildByName("Image_prop_base")
    self._baseControl:retain()

    self._skinButtonUnit = scrollViewSkin:getChildByName("Panel_unit")
    self._skinButtonUnit:retain()

    scrollViewGood:removeAllChildren()
end

function KUITeamCharacterNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    refreshShowCardList(self)
    initUI(self)
end

function KUITeamCharacterNode:refreshUI()
    refreshCardLeftArea(self)
    refreshCardRightArea(self)
    self:refreshCardSkill()
end

function KUITeamCharacterNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playLeftAnimation(self, true)
    playRightAnimation(self, true)
    playArrowAnimation(self, true)
end

function KUITeamCharacterNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "dwxq_base")

    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local clothNode         = mainNode:getChildByName("ProjectNode_clothing")
    local clothConfirmNode  = mainNode:getChildByName("ProjectNode_clothing_conform")
    local projectRight      = imageCommon:getChildByName("ProjectNode_base_info")
    local panelInformation1 = projectRight:getChildByName("Panel_frame_information_01")

    --confirm Button
    local panelBottom   = panelInformation1:getChildByName("Image_sx_base2")
    local buttonConfirm = panelBottom:getChildByName("Button_confirm")
    local function onConfirmClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConfirmButton~")         
            KSound.playEffect("click")   
            playPanelCloseAnimation(self, false)
        end
    end
    buttonConfirm:addTouchEventListener(onConfirmClick)
   
    local buttonStrengthen = panelBottom:getChildByName("Button_strengthen")
    local function onStrengthenClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("strengthen")
            self._parent:addNode("Strengthen",self._cardID)
            cclog("click Strengthen~")
        end
    end
    buttonStrengthen:addTouchEventListener(onStrengthenClick)  
    
    local buttonConvert = panelBottom:getChildByName("Button_convert")
    local function onConvertClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("transform") 
            local cardID   = self._cardID
            local card     = KUtil.getCardById(cardID)
            if card then
                local nodeData = {card = card}
                self._parent:addNode("Convert", nodeData)
            else
                showNoticeByID("common.cardNotFound")
            end
        end
    end
    buttonConvert:addTouchEventListener(onConvertClick) 

    local buttonOpenSkin = panelBottom:getChildByName("Button_clothing")
    local function onSkinClick(sender, type)
        if type == ccui.TouchEventType.ended then
            local cardID   = self._cardID
            local card     = KUtil.getCardById(cardID)
            self._oldSkin  = card.nSkinTemplateID
            playSkinAnimation(self, true)
            refreshSkinScrollView(self)
            cclog("click skin~")
        end
    end
    buttonOpenSkin:addTouchEventListener(onSkinClick)

    local panelClothing     = clothNode:getChildByName("Panel_clothing")
    local clothingImageBase = panelClothing:getChildByName("Image_sx_base2")
    local skinButtonConfirm     = clothingImageBase:getChildByName("Button_confirm")
    local function onSkinConfirm(sender, type)
        if type == ccui.TouchEventType.ended then
            local cardID   = self._cardID
            local card     = KUtil.getCardById(cardID)
            playSkinAnimation(self, false)
            require("src/network/KC2SProtocolManager"):UseSkin(cardID, card.nSkinTemplateID)
            cclog("click onSkinConfirm~")
        end
    end
    skinButtonConfirm:addTouchEventListener(onSkinConfirm)

    local skinButtonCancel     = clothingImageBase:getChildByName("Button_cancel")
    local function onSkinCancel(sender, type)
        if type == ccui.TouchEventType.ended then
            local cardID   = self._cardID
            local card     = KUtil.getCardById(cardID)
            card.nSkinTemplateID = self._oldSkin
            refreshCardLeftArea(self)
            playSkinAnimation(self, false)
            cclog("click onSkinCancel~")
        end
    end
    skinButtonCancel:addTouchEventListener(onSkinCancel)

    local buySkinPopup         = clothConfirmNode:getChildByName("Image_popup_base")
    local skinBuyConfirmButton = buySkinPopup:getChildByName("Button_conform")
    local function onBuySkinConfirm(sender, type)
        if type == ccui.TouchEventType.ended then
            playSkinConfirmAnimation(self, false)
            cclog("click onBuySkinConfirm~")

            local goodConfig = KUtil.getGoodConfigByItem(self._tryBuySkin, 1, ITEM_TYPE.SKIN)
            require("src/network/KC2SProtocolManager"):BuySkin(goodConfig.nID)
        end
    end
    skinBuyConfirmButton:addTouchEventListener(onBuySkinConfirm)

    local skinBuyCancelButton     = buySkinPopup:getChildByName("Button_cancel")
    local function onBuySkinCancel(sender, type)
        if type == ccui.TouchEventType.ended then
            playSkinConfirmAnimation(self, false)
            cclog("click onSkinCancel~")
        end
    end
    skinBuyCancelButton:addTouchEventListener(onBuySkinCancel)

    local skinPopupCancelButton     = buySkinPopup:getChildByName("Button_close")
    skinPopupCancelButton:addTouchEventListener(onBuySkinCancel)
    
    local projectPageNode = mainNode:getChildByName("ProjectNode_button_page")
    local buttonPageLeft  = projectPageNode:getChildByName("Button_page_left")
    local function onLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            previousOne(self)
        end
    end
    buttonPageLeft:addTouchEventListener(onLeftClick) 

    local buttonPageRight = projectPageNode:getChildByName("Button_page_right")
    local function onRightClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            nextOne(self)
        end
    end
    buttonPageRight:addTouchEventListener(onRightClick) 
    -- equip button
    local panelInformation2    = projectRight:getChildByName("Panel_frame_information_02")
    local panelMainCommon      = panelInformation2:getChildByName("Button_common_gear_main")
    local buttonMainChange     = panelMainCommon:getChildByName("Button_change")
    local buttonMainIconChange = panelMainCommon:getChildByName("Image_gear_main")
    -- main change
    local buttonID = 1
    local function onGearMainClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local nodeData = {cardID = self._cardID, equipIndex = buttonID, equipType = CARD_EQUIP_TYPE.MAIN,}
            self._parent:addNode("TeamChangeEquip", nodeData)
            cclog("click onGearMainClick~ buttonID=:%d", buttonID)
        end
    end
    buttonMainChange:addTouchEventListener(onGearMainClick)
    buttonMainIconChange:addTouchEventListener(onGearMainClick)

    -- other change
    for equipIndex = 2, MAX_EQUIP_COUNT do
        local buttonID            = equipIndex - 1
        local panelGearCommon     = panelInformation2:getChildByName("Button_common_gear_sub_" .. buttonID)
        local buttonSubIconChange = panelGearCommon:getChildByName("Image_gear_sub_" .. buttonID)
        
        local function onGearClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                local nodeData = {cardID = self._cardID, equipIndex = equipIndex, equipType = CARD_EQUIP_TYPE.GENERAL,}
                self._parent:addNode("TeamChangeEquip", nodeData)
                cclog("click onGearClick~ card buttonID=:%d", buttonID)
            end
        end
        buttonSubIconChange:addTouchEventListener(onGearClick)
    end    
    
    -- add button event
    for buttonID = 1, MAX_EQUIP_COUNT do
        local buttonSubAdd    = panelInformation2:getChildByName("Button_add_" .. buttonID)
        local function onAddButtonClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                local nodeData = {cardID = self._cardID, equipIndex = buttonID, equipType = CARD_EQUIP_TYPE.GENERAL,}
                self._parent:addNode("TeamChangeEquip", nodeData)
                cclog("click onAddButtonClick~ card buttonID=:%d", buttonID)
            end
        end
        buttonSubAdd:addTouchEventListener(onAddButtonClick)
    end
    
    -- upload
    for equipIndex = 2, MAX_EQUIP_COUNT do
        local buttonID            = equipIndex - 1 
        local panelGearCommon     = panelInformation2:getChildByName("Button_common_gear_sub_" .. buttonID)
        local buttonSubUnLoad     = panelGearCommon:getChildByName("Button_unload_" .. buttonID)
        -- unload button
        local function onUnloadClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("disboard")
                local isTeamExpedition = KUtil.isCardInExpedition(self._cardID)
                if isTeamExpedition then
                    showNoticeByID("expedition.onExpedition")
                    return
                end
                require("src/network/KC2SProtocolManager"):unloadCardEquip(self._cardID, equipIndex)
           end
        end
        buttonSubUnLoad:addTouchEventListener(onUnloadClick)
     end

    local projectNode    = mainNode:getChildByName("ProjectNode_good_props")
    local panelGoodPro   = projectNode:getChildByName("Panel_good_props")
    local imageGoodPro   = panelGoodPro:getChildByName("Image_good_props")
    local slideControl   = imageGoodPro:getChildByName("Slider_1")
    local scrollControl  = imageGoodPro:getChildByName("ScrollView_1")

    local buttonClose   = imageGoodPro:getChildByName("Button_close")
    local function onPanelClose(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            closeSelectPanel(self)
        end
    end
    buttonClose:addTouchEventListener(onPanelClose)

    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)

    -- married nutton
    local projectCard   = imageCommon:getChildByName("ProjectNode_card")
    local panelMarried  = projectCard:getChildByName("Panel_friend_degree")
    local buttonMarried = panelMarried:getChildByName("Button_friend_degree")
    local function onMarryClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            handleMarryPanel(self)
        end
    end
    buttonMarried:addTouchEventListener(onMarryClick)

    --card emergency repair
    local panelMount = projectCard:getChildByName("Panel_mount")
    local panelUnload = panelMount:getChildByName("Panel_1")
    local panelAdd = panelMount:getChildByName("Panel_2")
    local buttonUnload = panelUnload:getChildByName("Button_unload")
    local buttonAdd = panelAdd:getChildByName("Button_add")

    local function onAddEmergencyRepairItem(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")

            local itemConfig = KUtil.getItemConfig(CARD_EMERGENCY_REPAIR_ITEM_ID)
            assert(itemConfig.nType == ITEM_SMALL_TYPE.MOUNT, " mount item type is not ITEM_SMALL_TYPE.MOUNT , item template id :"..CARD_EMERGENCY_REPAIR_ITEM_ID)

            local bCardInExpedition = KUtil.isCardInExpedition(self._cardID)
            if bCardInExpedition then
                showNoticeByID("expedition.onExpedition")
                return
            end

            local canMountItemCount = KUtil.getItemCountExceptCardMountItem(CARD_EMERGENCY_REPAIR_ITEM_ID)
            if canMountItemCount <= 0 then
                showNoticeByID("card.noRepairItem")
                return
            end

            require("src/network/KC2SProtocolManager"):addCardMountItem(self._cardID, CARD_EMERGENCY_REPAIR_ITEM_ID)
        end
    end
    buttonAdd:addTouchEventListener(onAddEmergencyRepairItem)

    local function onUnloadEmergencyRepairItem(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("click")
            local bCardInExpedition = KUtil.isCardInExpedition(self._cardID)
            if bCardInExpedition then
                showNoticeByID("expedition.onExpedition")
                return
            end

            require("src/network/KC2SProtocolManager"):unloadCardMountItem(self._cardID)
        end
    end
    buttonUnload:addTouchEventListener(onUnloadEmergencyRepairItem)


    local projectNode = mainNode:getChildByName("ProjectNode_buff")
    local panelSkill  = projectNode:getChildByName("Panel_1")
    local panelIndex  = 0
    
    while true do
        panelIndex      = panelIndex + 1
        local panelName = string.format("Button_buff_%d", panelIndex)
        local imageButtonBuff = panelSkill:getChildByName(panelName)
        if not imageButtonBuff then break end
        local imageDescriptionBase = imageButtonBuff:getChildByName("Image_description_base")
        imageDescriptionBase:setVisible(false)
        local function onButtonBuffDown(sender, type)
            if type == ccui.TouchEventType.began then
                imageDescriptionBase:setVisible(true)
            elseif type == ccui.TouchEventType.canceled then
                imageDescriptionBase:setVisible(false)
            elseif type == ccui.TouchEventType.ended then
                imageDescriptionBase:setVisible(false)
            end
        end
        imageButtonBuff:addTouchEventListener(onButtonBuffDown)
    end
end

function KUITeamCharacterNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onCardChange(oneCard)
        local card = KUtil.getCardById(self._cardID)
        if not card then
            self._cardID = oneCard.nID
        end
        self:refreshUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ONE_CARD_CHANGE, onCardChange)

    local function onMarried(tOneCard)
        if tOneCard.nID ~= self._cardID then
            return
        end
        refreshCardLeftArea(self)
        refreshCardRightArea(self)
        closeSelectPanel(self)
        KUtil.playMarryAnimation(tOneCard)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_MARRIAGE_RING, onMarried)

   local function onAddFeeling(tOne)
        refreshCardLeftArea(self)
        refreshScrollView(self, false)
        showAddFeelingTip(tOne)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FEELING, onAddFeeling)

    local function onConvertCard(nOldCardID, nCardID)   
        if nOldCardID == self._cardID then
            self._cardID = nCardID
            refreshShowCardList(self)
            self:refreshUI()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CONVERT_CARD, onConvertCard)

    local function onStrengthenFinish(cardID)
        cclog("----------> onEvent KUITeamChangeCardNode onStrengthenFinish")
        refreshShowCardList(self)
        self._cardID = cardID
        self:refreshUI()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_STRENGTHEN_FINISH, onStrengthenFinish)

    local function onUseSkin(cardID, nSkinTemplateID)
        cclog("----------> onEvent KUITeamChangeCardNode onUseSkin")
        refreshCardLeftArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_USE_SKIN, onUseSkin)

    local function onBuySkinSuccess(nGoodID)
        cclog("----------> onEvent KUITeamChangeCardNode onBuySkinSuccess")
        refreshSkinScrollView(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_BUY_SKIN_SUCCESS, onBuySkinSuccess)
    
    local function onStrengthen()
        local teamStrengthenNode = self._parent:getNode("Strengthen")
        if not teamStrengthenNode then
            refreshShowCardList(self)
            self:refreshUI()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_STRENGTHEN, onStrengthen)
end

function KUITeamCharacterNode:onCleanup()
    self._baseControl:release()
    self._skinButtonUnit:release()
end

return KUITeamCharacterNode
