--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamConvertNode.lua
--  Creator     : HuangZhiLong
--  Date        : 2015/8/18   9:17
--  Contact     : huangzhilong1@kingsoft.com
--  Comment     :
--  *********************************************************************


local MAX_TANK_TYPE_COUNT = 6
local FPS                 = 60
local originPoint         = cc.p(0,0)

local m_tResourceTypeName = {
    ammo  = "弹药",
    steel = "钢材"
}

local KUITeamConvertNode = class(
    "KUITeamConvertNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamConvertNode:ctor()
    self._mainLayout             = nil
    self._parent                 = nil
    self._uiPath                 = nil
    self._card                   = nil
    self._cardID                 = nil
    self._convertID              = nil
    self._isNewCard              = nil
    self._animationList          = {}
end

function KUITeamConvertNode.create(owner, nodeData)
    local currentNode = KUITeamConvertNode.new()

    currentNode._parent             = owner
    currentNode._uiPath             = "res/ui/layout_convert.csb"
    currentNode._card               = nodeData.card
    currentNode._cardID             = nodeData.card.nID
    currentNode:init()

    return currentNode
end

local function getCardImagePath(nTemplateID)
    local cardConfig  = KConfig.cardInfo[nTemplateID]
 
    local imageName = "/Normal"
    imageName = imageName.."Image.png"

    return "res/images/cards/"..cardConfig.szResPath..imageName
end

local function isExpedition(cardID)
    local teamID = KUtil.getEnterTeamId(cardID)
    if teamID == 0 then return false end

    local tExpeditionList = KPlayer.tExpeditionData.tExpeditionList
    for _, var in ipairs(tExpeditionList) do
        if teamID == var.nTeamID then return true end      
    end

    return false
end

local function isConvert(self)
    local card          = self._card
    local cardConfig    = KConfig.cardInfo[card.nTemplateID]
    self._convertID     = cardConfig.nConvertID
    
    local teamID = KUtil.getEnterTeamId(card.nID)
    if teamID > 0 then
        local cardList = KUtil.getOneTeamCardList(teamID)
        
        if teamID == 1 and #cardList == 1 then
            showNoticeByID("convert.isFirstTeam")
            return false
        end
        
        for _, oneCard in ipairs(cardList) do
            if self._convertID == oneCard.nTemplateID then
                local cardInfo = KConfig.cardInfo[oneCard.nTemplateID]
                showNoticeByID("convert.exsit", cardInfo.szName)
                return false
            end
        end
    end

    if self._convertID == 0 then
        showNoticeByID("convert.convertFailed")
        return false
    end

    if KUtil.isCardInRepairList(card.nID) then 
        showNoticeByID("repaircard.inrepair")
        return false
    end
    
    if isExpedition(card.nID) then
        showNoticeByID("repaircard.inExpedition")
        return false
    end
    
    if not KUtil.isEnoughEquipStore(1) then
        showNoticeByID("produce.EquipStoreNotEnough")
        return false
    end

    if card.nLevel < cardConfig.nConvertLevel then
        showNoticeByID("expedition.levelUp", cardConfig.nConvertLevel)
        return false
    end

    if cardConfig.nConvertAmmo > KPlayer.ammo then 
        showNoticeByID("expedition.materialNotNnough", m_tResourceTypeName.ammo)
        return false
    end

    if cardConfig.nConvertSteel > KPlayer.steel then 
        showNoticeByID("expedition.materialNotNnough", m_tResourceTypeName.steel)
        return false
    end

    return true
end

local function refreshCardData(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local imageBase     = imageCommon:getChildByName("Image_gz_base")
    local projectNode   = imageBase:getChildByName("ProjectNode_attribute")
    local imageBase     = projectNode:getChildByName("Image_gz_base")

    local card          = self._card
    local attribute     = KUtil.getCurrentAttribute(card)

    local textAttack = imageBase:getChildByName("Text_huoli_value")
    textAttack:setString(attribute[ATTRIBUTE.ATTACK])

    local labelPenetrate = imageBase:getChildByName("Text_chuantou_value")
    labelPenetrate:setString(attribute[ATTRIBUTE.PENETRATE])

    local labelFrontArmour = imageBase:getChildByName("Text_qianjia_value")
    labelFrontArmour:setString(attribute[ATTRIBUTE.FRONTARMOUR])

    local labelRearArmor = imageBase:getChildByName("Text_houjia_value")
    labelRearArmor:setString(attribute[ATTRIBUTE.REARARMOUR])

    local labelSpeedData = imageBase:getChildByName("Text_sudu_value")
    labelSpeedData:setString(attribute[ATTRIBUTE.SPEED])

    local labelSpeedData = imageBase:getChildByName("Text_zhencha_value")
    labelSpeedData:setString(attribute[ATTRIBUTE.SCOUT])

    local labelSpeedData = imageBase:getChildByName("Text_yinbi_value")
    labelSpeedData:setString(attribute[ATTRIBUTE.HIDE])

    local labelSpeedData = imageBase:getChildByName("Text_yezhan_value")
    labelSpeedData:setString(attribute[ATTRIBUTE.NIGHTBATTLE])
end

local function refreshConvertData(self)
    local mainNode      = self._mainLayout
    local imageCommon   = mainNode:getChildByName("Image_common_base")
    local imageBase     = imageCommon:getChildByName("Image_gz_base")
    local projectNode   = imageBase:getChildByName("ProjectNode_resource")
    local imageBase     = projectNode:getChildByName("Image_gz_base")

    local card          = self._card
    local cardConfig    = KConfig.cardInfo[card.nTemplateID]

    local textNeedAmmo = imageBase:getChildByName("Text_need_ammo")
    textNeedAmmo:setString(cardConfig.nConvertAmmo)

    local textAllAmmo = imageBase:getChildByName("Text_all_ammo")
    textAllAmmo:setString("  / "..KPlayer.ammo)

    local textNeedSteel = imageBase:getChildByName("Text_need_steel")
    textNeedSteel:setString(cardConfig.nConvertSteel)
    
    local textAllSteel = imageBase:getChildByName("Text_all_steel")
    textAllSteel:setString("  / "..KPlayer.steel)  
end

local function refreshNewCardUI(self)
    local mainNode          = self._mainLayout
    local imageControl      = mainNode:getChildByName("Image_common_base")
    local imageBase         = imageControl:getChildByName("Image_gz_base")
    local projectNode       = imageBase:getChildByName("ProjectNode_after")
    local imageBase         = projectNode:getChildByName("Image_gz_base")
    local buttonConvert     = imageBase:getChildByName("Button_start_convert")

    KUtil.setTouchEnabled(buttonConvert, true)

    local imageShadow       = imageBase:getChildByName("Image_gz_shadow")
    imageShadow:setVisible(false)

    local cardConfig        = KConfig.cardInfo[self._card.nTemplateID]
    local convertID         = cardConfig.nConvertID
    self:refreshUI()
    if convertID ~= 0 then
        imageShadow:setVisible(true)
    else
        local imageNeedLevel    = imageBase:getChildByName("Image_need_level")
        local labelNeedLevel    = imageBase:getChildByName("BitmapFontLabel_need_level")
        imageNeedLevel:setVisible(false)
        labelNeedLevel:setVisible(false)
    end
end

local function playConvertAnimation(self)
    local mainNode      = self._mainLayout

    local loaderPath    = "res/ui/animation_node/ani_convert_trans.csb"
    local convertNode   = cc.CSLoader:createNode(loaderPath)       
    convertNode:setPosition(originPoint)
    convertNode:setName("convertNode")
    mainNode:addChild(convertNode)
    
    local convertAnimation    = cc.CSLoader:createTimeline(loaderPath)
    local animationStartFrame = 0  
    local animationEndFrame   = 150 
    local animationTime       = animationEndFrame / FPS 
    
    convertAnimation:gotoFrameAndPlay(animationStartFrame, animationEndFrame, false)
    convertNode:runAction(convertAnimation)
    
    local function onClickEvent(self)
		if not self._mainLayout then return end

        local mainNode      = self._mainLayout
        local convertNode   = mainNode:getChildByName("convertNode")
        mainNode:removeChild(convertNode)
 
        refreshNewCardUI(self)
    end

    local cardID    = self._cardID
    local isNewcard = self._isNewCard
    local function playCardAnimation ()
        local newCard = HArray.FindFirst(KPlayer.tCardData.tStoreHouse.tCardList, "nID", cardID)
        local eventParam  = {}
        table.insert(eventParam, self)
        KUtil.playGetCardAnimation(cardID, isNewcard, onClickEvent, eventParam)
    end
    
    delayExecute(self, playCardAnimation, animationTime)
end

function KUITeamConvertNode:playStartAnimation()
    for name, animation in pairs(self._animationList) do
        if name == "nodeAfter" then
            KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2], function()
                local animationArrow = self._animationList.arrow
                animationArrow[1]:getTarget():setVisible(true)
                KUtil.playAnimationByAnimation(animationArrow[1], animationArrow[2][1], animationArrow[2][2])
            end)
        elseif name ~= "arrow" then
            KUtil.playAnimationByAnimation(animation[1], animation[2][1], animation[2][2])
        end
    end
end

function KUITeamConvertNode:closeAnimation(isReturnOffice)
    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local imageBase         = imageCommon:getChildByName("Image_gz_base")
    local projectNode       = imageBase:getChildByName("ProjectNode_arrow")
    projectNode:setVisible(false)

    local delayTime = 0
    for name, animation in pairs(self._animationList) do
        local delayTime1 = KUtil.playAnimationByAnimation(animation[1], animation[2][3], animation[2][4])
        delayTime = math.max(delayTime, delayTime1)
    end
    
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Convert", callBacks, isReturnOffice)
end

function KUITeamConvertNode:onEnterActionFinished()
    delayExecute(self._mainLayout, function()
        self:playStartAnimation()
    end, 0.1)
end

function KUITeamConvertNode:onInitAnimation()
    if next(self._animationList) then
        return
    end

    local mainNode          = self._mainLayout
    local imageCommon       = mainNode:getChildByName("Image_common_base")
    local imageBase         = imageCommon:getChildByName("Image_gz_base")

    local list              = self._animationList
    local projectNode       = imageBase:getChildByName("ProjectNode_card_before")
    list.cardBefore         = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_cardbase_big.csb"), {0, 40, 65, 80}}

    local projectNode       = imageBase:getChildByName("ProjectNode_after")
    list.nodeAfter          = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_convert_right.csb"), {0, 30, 40, 65}}

    local projectNode       = imageBase:getChildByName("ProjectNode_attribute")
    list.attribute          = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_convert_left_1.csb"), {0, 30, 40, 65}}

    local projectNode       = imageBase:getChildByName("ProjectNode_resource")
    list.resource           = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_convert_left_2.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_resource_base")
    list.resourceBase       = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_resource_base.csb"), {0, 30, 40, 65}}

    local projectNode       = mainNode:getChildByName("ProjectNode_button_home")
    list.home               = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_common_home.csb"), {0, 30, 40, 65}}

    local projectNode       = imageBase:getChildByName("ProjectNode_arrow")
    list.arrow              = {KUtil.initAnimation(projectNode, "res/ui/animation_node/ani_convert_arrow.csb"), {0, 10, 54, 55}}
end

function KUITeamConvertNode:onInitUI()
    self:onInitAnimation()
end

function KUITeamConvertNode:refreshAfterData()
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageCommon:getChildByName("Image_gz_base")

    local cardAfterNode  = imageBase:getChildByName("ProjectNode_after")
    local imageBaseAni   = cardAfterNode:getChildByName("Image_gz_base")
    local buttonConvert  = imageBaseAni:getChildByName("ProjectNode_card_after")
    
    local cardConfig     = KConfig.cardInfo[self._card.nTemplateID]
    local convertID      = cardConfig.nConvertID
    self._convertID      = convertID
    
    local imageNeedLevel    = imageBaseAni:getChildByName("Image_need_level")
    local labelNeedLevel    = imageBaseAni:getChildByName("BitmapFontLabel_need_level")

    if convertID == 0 then 
        buttonConvert:setVisible(false)
        imageNeedLevel:setVisible(false)
        labelNeedLevel:setVisible(false)
    else
        local szCardImagePath     = KUtil.getCardImagePathByConfigID(convertID, false, self._card.nSkinTemplateID)
        -- card image 
        local imageCharaCard    = buttonConvert:getChildByName("Image_card_after_chara")
        imageCharaCard:loadTexture(szCardImagePath)

        labelNeedLevel:setString(cardConfig.nConvertLevel)
        imageNeedLevel:setVisible(true)
        labelNeedLevel:setVisible(true)
    end
end

function KUITeamConvertNode:refreshUI()
    local mainNode       = self._mainLayout
    local imageCommon    = mainNode:getChildByName("Image_common_base")
    local imageBase      = imageCommon:getChildByName("Image_gz_base")
    local cardBeforeNode = imageBase:getChildByName("ProjectNode_card_before")
    KUtil.updateCardBig(cardBeforeNode, self._card, false)
    
    self:refreshAfterData()
    refreshCardData(self)
    refreshConvertData(self) 
end

function KUITeamConvertNode:registerAllTouchEvent()
    local mainNode   = self._mainLayout

    --Home Button
    local nodeHome   = mainNode:getChildByName("ProjectNode_button_home")
    local panelHome  = nodeHome:getChildByName("Panel_common_home")
    local buttonHome = panelHome:getChildByName("Button_home")
    local function onHomeClick(sender, type)
        if type == ccui.TouchEventType.ended then
            KSound.playEffect("close")
            buttonHome:setEnabled(false)
            self:closeAnimation(true)
        end
    end
    buttonHome:addTouchEventListener(onHomeClick)

    --Close Button
    KUtil.updateResourceInfo(self, "gz_base.png", function()
        self:closeAnimation(false)
    end )

    local imageControl  = mainNode:getChildByName("Image_common_base")
    local imageBase     = imageControl:getChildByName("Image_gz_base")
    local projectNode   = imageBase:getChildByName("ProjectNode_after")
    local imageBase     = projectNode:getChildByName("Image_gz_base")
    local buttonConvert = imageBase:getChildByName("Button_start_convert")
    local function onConvertClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onConvertClick~")
            KSound.playEffect("startTransform") 
            if not isConvert(self) then return end      
            KUtil.setTouchEnabled(buttonConvert, false)
            require("src/network/KC2SProtocolManager"):convertCard(self._card.nID)
        end
    end
    buttonConvert:addTouchEventListener(onConvertClick)
end

function KUITeamConvertNode:registerAllCustomEvent()
    local mainNode = self._mainLayout
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    local function onConvertCard(nOldCardID, nCardID, isNewCard)
        self._cardID = nCardID
        local card   = KUtil.getCardById(nCardID)
        self._card   = card
        self._isNewCard = isNewCard
        playConvertAnimation(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CONVERT_CARD, onConvertCard)

    local function onResourceUpdate()
        cclog("----------> onEvent onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)
end

return KUITeamConvertNode
