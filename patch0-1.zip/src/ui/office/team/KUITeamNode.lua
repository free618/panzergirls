--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/3/12   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local VALID_OFF = 20
local m_tButtonStateTexture = 
{
    ["buttonNormalTexture"]   = "res/ui/ui_material/public/common_team_button.png",
    ["buttonPressTexture"]    = "res/ui/ui_material/public/common_team_button_active.png",
    ["buttonDisableTexture"]  = "res/ui/ui_material/public/common_team_button_disable.png"
}

local m_tTeamButtonName = 
{
    [1] = "Button_team1", 
    [2] = "Button_team2",
    [3] = "Button_team3",
    [4] = "Button_team4"
}

local m_tTeamButtonNameOfTeamID = 
{
    [1] = "Button_team_sheet_1",
    [2] = "Button_team_sheet_2",
    [3] = "Button_team_sheet_3",
    [4] = "Button_team_sheet_4",
}

local KUITeamNode = class(
    "KUITeamNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamNode:ctor()
    self._mainLayout          = nil
    self._parent              = nil
    self._uiPath              = nil
    self._currentPage         = 1
    self._canEnterDetail      = false
    self._openTeamCount       = KPlayer.tTeamData.nOpenCount
    assert(self._openTeamCount > 0)
end

function KUITeamNode.create(owner, userData)
    local currentNode = KUITeamNode.new()

    if userData and userData.teamID then
        currentNode._currentPage = userData.teamID
    end
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_team.csb"
    currentNode:init()

    return currentNode
end

local function playBottomAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_skill")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_team_bottom"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTopAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_team_top"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playTeamCardEnterAnimation(self, isOpen)
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")
    local pageView              = imageCommon:getChildByName("PageView_team_list") 
    local panelTeamNode         = pageView:getChildByName("Panel_1") 
    local projectNode           = panelTeamNode:getChildByName("ProjectNode_bd_1")

    local openEndFrame    = 35
    local closeStartFrame = 50
    local animationName   = "ani_team_card"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRecordAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_record_button")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_team_record_button"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_top")
    projectNode:stopAllActions()

    local imageCommon     = mainNode:getChildByName("Image_common_base")
    local projectNode     = imageCommon:getChildByName("ProjectNode_skill")
    projectNode:stopAllActions()

    local pageView              = imageCommon:getChildByName("PageView_team_list") 
    local panelTeamNode         = pageView:getChildByName("Panel_1") 
    local projectNode           = panelTeamNode:getChildByName("ProjectNode_bd_1")
    projectNode:stopAllActions()

    KUtil.stopCommonAnimation(self)
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, KUtil.playHomeAnimation(self, false))
        table.insert(framesList, KUtil.playResourceAnimation(self, false))
        table.insert(framesList, playBottomAnimation(self, false))
        table.insert(framesList, playTopAnimation(self, false))
        table.insert(framesList, playTeamCardEnterAnimation(self, false))
        table.insert(framesList, playRecordAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Team", callBacks, isReturnOffice)
end

local function refreshDisableArena(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local skillProjectNode = imageCommon:getChildByName("ProjectNode_skill")
    local topProjectNode   = mainNode:getChildByName("ProjectNode_top")
    local panelButtonTeam  = topProjectNode:getChildByName("Panel_Button_team")
    local pageViewControl  = imageCommon:getChildByName("PageView_team_list")
    local teamID = MAX_TEAM_COUNT
    while teamID > self._openTeamCount do
        teamID = teamID - 1
        local buttonControl = panelButtonTeam:getChildByName("Button_team" .. (teamID + 1))
        local imageTeam     = buttonControl:getChildByName("Image_common_team" .. teamID + 1) 
        buttonControl:loadTextures(m_tButtonStateTexture.buttonDisableTexture, m_tButtonStateTexture.buttonDisableTexture, m_tButtonStateTexture.buttonDisableTexture)
        buttonControl:setEnabled(false)
        imageTeam:setVisible(false)
    end 
end

local function refreshSkillArea(self)
    local mainNode         = self._mainLayout
    local imageCommon      = mainNode:getChildByName("Image_common_base")
    local skillProjectNode = imageCommon:getChildByName("ProjectNode_skill")
    local panelTeam        = skillProjectNode:getChildByName("Panel_team_bottom")

    for i = 1, MAX_SKILL_COUNT do
        local equipPanel     = panelTeam:getChildByName("Image_skills_base_" .. i)
        local panelAdd       = panelTeam:getChildByName("Image_skill_add_" .. i)

        local skillData     = KUtil.getSkillByIndex(i)
        local isShowItem = (skillData ~= nil)
        equipPanel:setVisible(isShowItem)
        panelAdd:setVisible(not isShowItem)

        if skillData then
            local equipItem   = KUtil.getEquipById(skillData.nEquipID)  
            local equipConfig = KConfig.equipInfo[equipItem.nTemplateID]
            local skillConfig = KConfig.skill[equipConfig.nSkill]

            local textGearName      = equipPanel:getChildByName("Text_gear_name")
            textGearName:setString(skillConfig.szName)

            local textGearIntroduce = equipPanel:getChildByName("Text_gear_introduce")
            textGearIntroduce:setString(skillConfig.szDesc)
            -- resource
            local imageSteelWarning  = equipPanel:getChildByName("Image_ammo_warning")
            local imagePeopleWarning = equipPanel:getChildByName("Image_oil_warning")
            local needResource       = (skillData.nLeftTimes < equipConfig.nUseTime)
            imageSteelWarning:setVisible(needResource)
            imagePeopleWarning:setVisible(needResource)
            -- item
            local imageItemBase = equipPanel:getChildByName("Image_icon_base")
            local itemLevelPath = string.format("res/ui/ui_material/team/replace_base_%d.png", equipConfig.nGrade)
            imageItemBase:loadTexture(itemLevelPath)

            local buttonGearIcon = imageItemBase:getChildByName("Image_gear_icon")
            local itemPath       = KUtil.getEquipImagePathByID(equipItem.nTemplateID)
            buttonGearIcon:loadTexture(itemPath)

            local textNumber      = imageItemBase:getChildByName("Text_number")
            textNumber:setString(tostring(skillData.nLeftTimes))
        end
    end
end

local function refreshTeamButtonArea(self)
    local currentChooseTeamID = self._currentPage
    local mainNode            = self._mainLayout
    local topProjectNode      = mainNode:getChildByName("ProjectNode_top")
    local panelButtonTeam     = topProjectNode:getChildByName("Panel_Button_team")
    for teamID = 1 , self._openTeamCount do 
        local buttonName    = "Button_team" .. teamID
        local buttonControl = panelButtonTeam:getChildByName(buttonName) 
        if currentChooseTeamID == teamID then
            buttonControl:setTouchEnabled(false)
            buttonControl:loadTextures(m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonDisableTexture)
        else
            buttonControl:setTouchEnabled(true)
            buttonControl:loadTextures(m_tButtonStateTexture.buttonNormalTexture, m_tButtonStateTexture.buttonPressTexture, m_tButtonStateTexture.buttonDisableTexture)
        end
    end

    local panelTextTeam = topProjectNode:getChildByName("Panel_Text_team")
    local labelTeamName = panelTextTeam:getChildByName("Input_team_name")
    labelTeamName:setString(KUtil.getTeamName(currentChooseTeamID))
end

local function updateCardUnit(self, unitNode, card)
    -- empty card
    local imageUnitEmpty = unitNode:getChildByName("Image_bd_unit_empty")
    local buttonAdd      = imageUnitEmpty:getChildByName("Button_team_unit_add")
    local imageUnitBase  = unitNode:getChildByName("Image_bd_unit_bg") 
    if not card then
        imageUnitBase:setVisible(false)
        imageUnitEmpty:setVisible(true)
        return
    end
    imageUnitBase:setVisible(true) 
    imageUnitEmpty:setVisible(false)

    -- have card
    local panelCardBase = imageUnitBase:getChildByName("Node_bd_unit_bg")
    local baseNode      = panelCardBase:getChildByName("Panel_base")
    local panelFirendDegree      = baseNode:getChildByName("Panel_firend_degree")
    local loadingBarFriendDegree = panelFirendDegree:getChildByName("LoadingBar_friend_degree")
    local progressValue          = card.nFeeling / KUtil.MAX_FEELING * KUtil.PERCENT_BASE
    loadingBarFriendDegree:setPercent(progressValue)
    local bitmapFontLabelDegree  = panelFirendDegree:getChildByName("BitmapFontLabel_degree")
    bitmapFontLabelDegree:setString(card.nFeeling .. "%")

    KUtil.updateCardBase(baseNode, card, true, false, true, true)

    local panelExp   = imageUnitBase:getChildByName("Image_exp_base")
    local loadingBar = panelExp:getChildByName("LoadingBar_exp")
    local upLevelExp = KUtil.getCardMaxExp(card.nLevel)
    local currentExp = card.nCurrentExp
    loadingBar:setPercent(currentExp / upLevelExp * KUtil.PERCENT_BASE)

    local showIndex = 0
    local allAttribute = KUtil.getCurrentAttribute(card)
    for index, attribute in ipairs(KUtil.ATTIBUTE_NAME) do
        local value = allAttribute[attribute[1]]
        if value and value ~= 0 then
            showIndex = showIndex + 1
            local textAttributeName = imageUnitBase:getChildByName("Text_attribute" .. showIndex)
            local textAttributeValue = imageUnitBase:getChildByName("Text_attribute_value" .. showIndex)
            if not textAttributeName or not textAttributeValue then break end
            textAttributeName:setString(KUtil.getStringByKey(attribute[2]))
            textAttributeValue:setString(tostring(value))
        end
    end
end

local function refreshCardArea(self)
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")
    local pageView              = imageCommon:getChildByName("PageView_team_list") 
    local panelTeamNode         = pageView:getChildByName("Panel_1") 
    local projectNode           = panelTeamNode:getChildByName("ProjectNode_bd_1")

    local currentChooseTeamID   = self._currentPage
    local teamInfo              = KUtil.getOneTeamCardList(currentChooseTeamID)
    local teamSize              = #teamInfo
    local panelTeamCard         = projectNode:getChildByName("Panel_ani_team_card")
    for nodeNum = 1, MAX_TEAM_CARD_COUNT do 
        local unitControl     = panelTeamCard:getChildByName("Node_bd_unit_" .. nodeNum)
        local card            = teamInfo[nodeNum]
        updateCardUnit(self, unitControl, card)
    end
end

function KUITeamNode:registerCardUnitEvent()
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")
    local pageView              = imageCommon:getChildByName("PageView_team_list") 
    local panelTeamNode         = pageView:getChildByName("Panel_1") 
    local projectNode           = panelTeamNode:getChildByName("ProjectNode_bd_1")
    local panelTeamCard         = projectNode:getChildByName("Panel_ani_team_card")

    for nodeUnitID = 1, MAX_TEAM_CARD_COUNT do 
        local unitControl = panelTeamCard:getChildByName("Node_bd_unit_" .. nodeUnitID)
        --Unit Add Button
        local imageEmptyControl = unitControl:getChildByName("Image_bd_unit_empty")
        local buttonControl     = imageEmptyControl:getChildByName("Button_team_unit_add")
        local function onAddClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                local teamID = self._currentPage
                local nodeData = {teamID = teamID, nodeUnitID = nodeUnitID, panelType = CARD_SELECT_PANEL_TYPE.ADD,}
                self._parent:addNode("TeamChangeCard", nodeData)
                cclog("click onAddButton~ teamID:%d nodeUnitID:%d",teamID, nodeUnitID)
            end
        end
        buttonControl:addTouchEventListener(onAddClick)
        imageEmptyControl:setTouchEnabled(true)
        imageEmptyControl:addTouchEventListener(onAddClick)
    
        local detailBase      = unitControl:getChildByName("Image_bd_unit_bg") 
        local cardBaseProject = detailBase:getChildByName("Node_bd_unit_bg")
        local cardPanelBase   = cardBaseProject:getChildByName("Panel_base")

        local cardCountryNameList = KUtil.getCardCountryNameList()
        for i, countryName in ipairs(cardCountryNameList) do
            local frameButtomName = "Button_"..countryName.."_frame_buttom"
            local imageDetail     = cardPanelBase:getChildByName(frameButtomName)

            imageDetail:setTouchEnabled(true)
            imageDetail:setSwallowTouches(false)
            cardPanelBase:setSwallowTouches(false)
            --Detail Button
            local enterDetailFun = function()
                if self._canEnterDetail then
                    local teamID = self._currentPage
                    local cardID = KUtil.getCardInTeam(teamID, nodeUnitID)
                    local nodeData = {cardID = cardID,}
                    self._parent:addNode("TeamCharacter", nodeData)
                end
            end

            local startX    = 0
            local startY    = 0
            local startTime = 0
            local function onDetailClick(sender, type)
                if ccui.TouchEventType.began == type then
                    local startPos       = sender:getTouchBeganPosition()
                    startX               = startPos.x
                    startY               = startPos.y
                    startTime            = C_GetTickCount()
                    self._canEnterDetail = true
                    delayExecute(imageDetail, enterDetailFun, KUtil.KEEP_DOWN_SECOND)
                elseif ccui.TouchEventType.moved == type then
                    local endPos = sender:getTouchMovePosition()
                    local endX   = endPos.x
                    local endY   = endPos.y
                    if math.abs(startX - endX) > VALID_OFF or  math.abs(startY - endY) > VALID_OFF then 
                        if self._canEnterDetail then
                            self._canEnterDetail = false
                            imageDetail:stopAllActions()
                        end
                    end
                elseif ccui.TouchEventType.canceled == type then
                    self._canEnterDetail = false
                    imageDetail:stopAllActions()
                elseif ccui.TouchEventType.ended == type then
                    if not self._canEnterDetail then return end
                    self._canEnterDetail = false
                    imageDetail:stopAllActions()
                    local passTime    = C_GetTickCount() - startTime
                    local milliSecond = KUtil.KEEP_DOWN_SECOND * KUtil.MILLI_SECOND_RATE
                    if passTime < milliSecond then
                        KSound.playEffect("click")
                        local teamID   = self._currentPage
                        local nodeData = {teamID = teamID, nodeUnitID = nodeUnitID, panelType = CARD_SELECT_PANEL_TYPE.CHANGE}
                        self._parent:addNode("TeamChangeCard", nodeData)
                        cclog("click onChangeButton~ teamID:%d nodeUnitID:%d",teamID, nodeUnitID)
                    end
                end
            end
            imageDetail:addTouchEventListener(onDetailClick)
        end

        --Change Button
        local buttonChange  = detailBase:getChildByName("Button_team_change") 
        local function onChangeClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                local teamID   = self._currentPage
                local cardID = KUtil.getCardInTeam(teamID, nodeUnitID)
                local nodeData = {cardID = cardID,}
                self._parent:addNode("TeamCharacter", nodeData)
            end
        end
        buttonChange:addTouchEventListener(onChangeClick)
    end
end

local function refreshExpeditionTeam(self)
    local mainNode        = self._mainLayout
    local topProjectNode  = mainNode:getChildByName("ProjectNode_top")
    local panelButtonTeam = topProjectNode:getChildByName("Panel_Button_team")
    for teamID = 2, MAX_TEAM_COUNT do
        local buttonName      = m_tTeamButtonName[teamID]
        local buttonControl   = panelButtonTeam:getChildByName(buttonName)
        local projectNodeMark = buttonControl:getChildByName("ProjectNode_mark")
        local isExpedition    = KUtil.isTeamInExpedition(teamID)
        projectNodeMark:setVisible(isExpedition)
    end
end

function KUITeamNode:onInitUI()
    KUtil.updateResourceInfo(self)
    stopAllAnimation(self)
    refreshExpeditionTeam(self)
    refreshDisableArena(self)
end

function KUITeamNode:refreshUI()
    refreshCardArea(self)
    refreshTeamButtonArea(self)
    refreshSkillArea(self)
end

function KUITeamNode:onEnterActionFinished()
    KUtil.playHomeAnimation(self, true)
    KUtil.playResourceAnimation(self, true)
    playBottomAnimation(self, true)
    playTopAnimation(self, true)
    playTeamCardEnterAnimation(self, true)
    playRecordAnimation(self, true)
end

function KUITeamNode:registerAllTouchEvent()
    local function callBack(isReturnOffice)
        playPanelCloseAnimation(self, isReturnOffice)
    end
    KUtil.initPanelCommonNode(self, callBack, "bdzb_base")

    local mainNode        = self._mainLayout
    local imageControl    = mainNode:getChildByName("Image_common_base")
    local pageViewControl = imageControl:getChildByName("PageView_team_list")
    local topProjectNode  = mainNode:getChildByName("ProjectNode_top")
    local panelButtonTeam = topProjectNode:getChildByName("Panel_Button_team")
    for teamID = 1, MAX_TEAM_COUNT do
        local function onTeamClick(sender, type)
            if type == ccui.TouchEventType.ended then
                cclog("click onTeamButton~")
                KSound.playEffect("click")
                self._currentPage = teamID
                refreshTeamButtonArea(self)
                refreshCardArea(self)
            end
        end
        local buttonControl = panelButtonTeam:getChildByName("Button_team" .. teamID)
        buttonControl:addTouchEventListener(onTeamClick)
    end

    self:registerCardUnitEvent()
    -- textField
    local panelTextTeam = topProjectNode:getChildByName("Panel_Text_team")
    local inputTeamName = panelTextTeam:getChildByName("Input_team_name")
    local currentString = ""
    local function textFieldEvent(sender, eventType)
        if eventType == ccui.TextFiledEventType.attach_with_ime then
            currentString = inputTeamName:getString()
        elseif eventType == ccui.TextFiledEventType.detach_with_ime then
            --check same
            local inputString = inputTeamName:getString()
            if currentString == inputString then return end
            -- too short
            if string.len(inputString) <= 0 then 
                showNotice(KUtil.getStringByKey("common.inputError")) 
                return 
            end
            -- too long
            local shortString = KUtil.subString(inputString, 8)
            if shortString ~= inputString then 
                showNotice(KUtil.getStringByKey("common.inputLong")) 
                return 
            end
            -- sensitive word
            if KUtil.hasSensitiveWord(inputString) then 
                showNotice(KUtil.getStringByKey("common.hasSensitiveWord")) 
                return 
            end
            -- save
            require("src/network/KC2SProtocolManager"):teamRename(self._currentPage, inputString)
        end
    end
    inputTeamName:addEventListener(textFieldEvent)

    local function onOpenRecordClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onOpenRecordClick~")
            KSound.playEffect("click")
            self._parent:addNode("TeamRecord", self._currentPage)
        end
    end

    local projectRecord     = mainNode:getChildByName("ProjectNode_record_button")
    local recordControl     = projectRecord:getChildByName("Button_record")
    recordControl:addTouchEventListener(onOpenRecordClick)

    -- skill
    local skillProjectNode = imageControl:getChildByName("ProjectNode_skill")
    local panelTeam        = skillProjectNode:getChildByName("Panel_team_bottom")

     for i = 1, MAX_SKILL_COUNT do
        local position = i
        local equipPanel    = panelTeam:getChildByName("Image_skills_base_" .. i)
        local imageItemBase = equipPanel:getChildByName("Image_icon_base")

        local buttonGearIcon = imageItemBase:getChildByName("Image_gear_icon") 
        local buttonReplace = equipPanel:getChildByName("Button_replace")
        local panelAdd      = panelTeam:getChildByName("Image_skill_add_" .. i)
        local buttonAdd     = panelAdd:getChildByName("Button_add") 
        local function onOpenClick(sender, type)
            if type == ccui.TouchEventType.ended then
                KSound.playEffect("click")
                cclog("click onOpenPanel~ position:%d",position)
                local nodeData = {position = position}
                self._parent:addNode("TeamChangeSkill", nodeData)
            end
        end
        buttonGearIcon:setTouchEnabled(true)
        buttonReplace:addTouchEventListener(onOpenClick)
        buttonAdd:addTouchEventListener(onOpenClick)
        buttonGearIcon:addTouchEventListener(onOpenClick)
    end
end

function KUITeamNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onChooseCardFinish(cardID)
        cclog("onEvent ------------> onChooseCardFinish")
        if cardID and cardID > 0 then
            local card = KUtil.getCardById(cardID)
            if card then
                KSound.playTalk(KSound.TALK.ENROLL, card.nTemplateID)
            end
        end
        refreshCardArea(self)
        refreshTeamButtonArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CHOOSE_CARD_FINISH, onChooseCardFinish)

    local function onWearRing(tOneCard)
        cclog("onEvent ------------> onWearRing")
        refreshCardArea(self)
        KUtil.playMarryAnimation(tOneCard)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_MARRIAGE_RING, onWearRing)
    
    local function onFeeling()
        refreshCardArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FEELING, onFeeling)

    local function onCardChange()
        refreshCardArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ONE_CARD_CHANGE, onCardChange)
    
    local function onAddFeeling(tOne)
        cclog("onEvent ------------> onAddFeeling")
        if tOne.nFeeling >= KUtil.MAX_FEELING then
            refreshCardArea(self) 
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_FEELING, onAddFeeling)

    local function onResourceUpdate()
        cclog("----------> onEvent KUITeamNode onResourceUpdate")
        KUtil.updateResourceInfo(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_UPDATE_RESOURCE, onResourceUpdate)

    local function onUseSkin(cardID, nSkinTemplateID)
        cclog("----------> onEvent KUITeamChangeCardNode onUseSkin")
        refreshCardArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_USE_SKIN, onUseSkin)

     local function onChangeSkill()
        cclog("onEvent ------------> onChangeSkill")
        refreshSkillArea(self)
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_SKILL_CHANGE, onChangeSkill)
end

return KUITeamNode
