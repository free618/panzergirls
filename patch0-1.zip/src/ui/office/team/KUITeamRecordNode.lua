--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamRecordNode.lua
--  Creator     : lvsongxin
--  Date        : 2016/3/12   10:46
--  Contact     : lvsongxin@kingsoft.com
--  Comment     :
--  *********************************************************************


local KUITeamRecordNode = class(
    "KUITeamRecordNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamRecordNode:ctor()
    self._mainLayout          = nil
    self._parent              = nil
    self._uiPath              = nil
    self._teamIndex           = 1
    self._currentRecord       = 1
end

function KUITeamRecordNode.create(owner, teamIndex)
    local currentNode = KUITeamRecordNode.new()

    currentNode._teamIndex = teamIndex
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_team_record.csb"
    currentNode:init()

    return currentNode
end

local function playLeftAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_team")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_team_record"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function playRigthAnimation(self, isOpen)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_list")

    local openEndFrame    = 20
    local closeStartFrame = 50
    local animationName   = "ani_team_record_list"
    return KUtil.playPanelAnimation(projectNode, animationName, openEndFrame, closeStartFrame, isOpen)
end

local function stopAllAnimation(self)
    local mainNode        = self._mainLayout
    local projectNode     = mainNode:getChildByName("ProjectNode_team")
    projectNode:stopAllActions()

    local projectNode     = mainNode:getChildByName("ProjectNode_list")
    projectNode:stopAllActions()
end

local function playPanelCloseAnimation(self, isReturnOffice)
    local function animationFun1()
        local framesList = {}
        table.insert(framesList, playLeftAnimation(self, false))
        table.insert(framesList, playRigthAnimation(self, false))
        return framesList
    end

    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "TeamRecord", callBacks, isReturnOffice)
end

function KUITeamRecordNode:getEnterAction()
end

function KUITeamRecordNode:onInitUI()
    stopAllAnimation(self)
end

function KUITeamRecordNode:refreshUI()
    self:refreshRecordArea()
end

function KUITeamRecordNode:onEnterActionFinished()
    playLeftAnimation(self, true)
    playRigthAnimation(self, true)
end

function KUITeamRecordNode:refreshRecordCardArea(cards)
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_team")
    local panelRecord       = projectNode:getChildByName("Panel_record")
    local imageTeamBase     = panelRecord:getChildByName("Image_team_base")

    for i=1,MAX_TEAM_CARD_COUNT do
        local unitControl   = imageTeamBase:getChildByName("ProjectNode_card_" .. i)
        local card          = cards[i]
        if card then
            local baseNode      = unitControl:getChildByName("Panel_base")
            KUtil.updateCardBase(baseNode, card, true, false, true)
            unitControl:setVisible(true)
        else
            unitControl:setVisible(false)
        end
    end
end

function KUITeamRecordNode:refreshRecordTeamdArea()
    local mainNode              = self._mainLayout
    local projectNode           = mainNode:getChildByName("ProjectNode_list")
    local imageRecordBase       = projectNode:getChildByName("Image_record_base")

    for i=1,MAX_TEAM_RECORD_COUNT do
        local unitControl       = imageRecordBase:getChildByName("Button_record_" .. i)
        local teamName          = unitControl:getChildByName("Text_team_name")
        local teamLeader        = unitControl:getChildByName("Text_team_leader")
        
        local teamInfo          = KUtil.getRecordTeamCardList(i)
        if teamInfo[1] then
            teamName:setString(KUtil.getRecordTeamName(i))
            local cardConfig    = KUtil.getCardConfig(teamInfo[1].nTemplateID)
            teamLeader:setString(cardConfig.szName)
        else
            teamName:setString("")
            teamLeader:setString("")
        end
    end
end

function KUITeamRecordNode:refreshRecordArea()
    local teamInfo          = KUtil.getRecordTeamCardList(self._currentRecord)
    self:refreshRecordCardArea(teamInfo)
    self:refreshRecordTeamdArea()
end

local function canUseRecordTeam(recordId, useTeamID)
    local teamList = KPlayer.tTeamData.tRecordTeamList
    if not recordId then cclog("recordId is invalid") return false end
    local teamRecord = HArray.FindFirst(teamList, "nIndex", recordId)
    if not teamRecord then return false end
    if KUtil.isTeamInExpedition(useTeamID) then
        KUtil.showNoticeByErrorCode(ERROR_CODE.CARD_MOUNT_ITEM_EXPEDITION)
        return false
    end
    
    local tNeedRemoveTeam = {}

    for i,v in ipairs(teamRecord.tCardIDList) do
        local card = KUtil.getCardById(v)
        if not card then
            return false
        else
            if KUtil.isCardInExpedition(v) then
                KUtil.showNoticeByErrorCode(ERROR_CODE.TEAM_SELECTED_CARD_EXPEDITION)
                return false
            end

            local teamID = KUtil.getEnterTeamId(v)
            if teamID ~= 0 then
                if not tNeedRemoveTeam[teamID] then
                    tNeedRemoveTeam[teamID] = {}
                end

                table.insert(tNeedRemoveTeam[teamID], v)

                if useTeamID ~= 1 and teamID == 1 then
                    local teamInfo = KUtil.getOneTeamCardList(teamID)
                    if #teamInfo <= #tNeedRemoveTeam[teamID] then
                        KUtil.showNoticeByErrorCode(ERROR_CODE.TEAM_FIRST_LEADER)
                        return false
                    end
                end
            end
        end
    end

    return true
end

function KUITeamRecordNode:registerAllTouchEvent()
    local mainNode          = self._mainLayout
    local projectNode       = mainNode:getChildByName("ProjectNode_list")
    local imageRecordBase   = projectNode:getChildByName("Image_record_base")

    local function onCloseRecordClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onCloseRecordClick~")
            KSound.playEffect("click")
            playPanelCloseAnimation(self, false)
        end
    end
    local recordControl     = imageRecordBase:getChildByName("Button_record")
    recordControl:addTouchEventListener(onCloseRecordClick)

    local function onReadRecordClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onReadRecordClick~")
            KSound.playEffect("click")
            if canUseRecordTeam(self._currentRecord, self._teamIndex) then
                require("src/network/KC2SProtocolManager"):useRecordTeam(self._teamIndex, self._currentRecord)
            end
        end
    end
    local readControl       = imageRecordBase:getChildByName("Button_read")
    readControl:addTouchEventListener(onReadRecordClick)

    local function onSaveRecordClick(sender, type)
        if type == ccui.TouchEventType.ended then
            cclog("click onSaveRecordClick~")
            KSound.playEffect("click")
            require("src/network/KC2SProtocolManager"):saveRecordTeam(self._teamIndex, self._currentRecord)
        end
    end
    local saveControl       = imageRecordBase:getChildByName("Button_save")
    saveControl:addTouchEventListener(onSaveRecordClick)

    self.buttonRecord       = {}
    for i=1,MAX_TEAM_RECORD_COUNT do
        self.buttonRecord[i]   = imageRecordBase:getChildByName("Button_record_" .. i)
        local function onChooseRecordClick(sender, type)
            if type == ccui.TouchEventType.ended then
                print("click onChooseRecordClick~", i)
                KSound.playEffect("click")
                KUtil.setTouchEnabled(self.buttonRecord[self._currentRecord], true)
                self._currentRecord = i
                KUtil.setTouchEnabled(self.buttonRecord[self._currentRecord], false)

                local teamInfo          = KUtil.getRecordTeamCardList(self._currentRecord)
                if teamInfo[1] then
                    KUtil.setTouchEnabled(readControl, true)
                else
                    KUtil.setTouchEnabled(readControl, false)
                end
                
                local teamInfo          = KUtil.getRecordTeamCardList(self._currentRecord)
                self:refreshRecordCardArea(teamInfo)
            end
        end

        KUtil.setTouchEnabled(self.buttonRecord[i], self._currentRecord ~= i)
        self.buttonRecord[i]:addTouchEventListener(onChooseRecordClick)
    end
end

function KUITeamRecordNode:registerAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    local function onRecordChange()
        self:refreshRecordArea()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_SAVE_RECORD_TEAM, onRecordChange)
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_DEL_RECORD_TEAM, onRecordChange)
end

return KUITeamRecordNode
