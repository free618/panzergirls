--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUITeamStrengthenNode.lua
--  Creator     : liulingli
--  Date        : 2015/10/09   17:50
--  Contact     : liulingli@kingsoft.com
--  Comment     :
--  *********************************************************************


local BEFORE_COLOR           = cc.c4b(255,255,255,255)
local FULL_COLOR             = cc.c4b(255, 215, 0, 255)
local LIGHT_FRAME            = 15
local MOVE_FRAME             = 15
local EXP_REFRESH_SPEED      = 0.05
local m_AttributeName = {"attack", "penetrate", "speed", "frontArmour", "rearArmour", "scout",   "hide",  "nightBattle"}
local m_NodeName      = {"huoli",  "chuantou",  "sudu",  "qianjia",     "houjia",     "zhencha", "yinbi", "yezhan"}

local KUITeamStrengthenNode = class(
    "KUITeamStrengthenNode", function () return require("src/ui/uibase/KUINodeBase").create() end
)

function KUITeamStrengthenNode:ctor()
    self._mainLayout        = nil
    self._parent            = nil
    self._uiPath            = nil
    self._baseCardBar       = nil
    self._card              = nil
    self._showCardIDList      = nil
    self._cardIDList        = {}
    self._tMaxAtrribute     = nil
    self._levelValue        = nil
    self._oldLevel          = nil
    self._oldValue          = 0
    self._isInitEnd         = nil
    self._isStrengthen      = false
    -- self._retainList        = {}
    self._animationHome        = nil
    self._animationResource    = nil
    self._animationCard        = nil
    self._animationAttribute   = nil
    self._animationProgressBar = nil
    self._animationScrollview  = nil
    self._animationPageButton  = nil
end

function KUITeamStrengthenNode.create(owner, cardID)
    local currentNode   = KUITeamStrengthenNode.new()
    currentNode._parent = owner
    currentNode._uiPath = "res/ui/layout_strengthen.csb"
    local targetCard    = KUtil.getCardById(cardID)
    assert(targetCard)
    currentNode._card   = targetCard
    currentNode:init()

    return currentNode
end

function KUITeamStrengthenNode:initCardImage()
	local mainNode      = self._mainLayout
    local imageBase     = mainNode:getChildByName("Image_common_base")
    local nodeCard      = imageBase:getChildByName("Node_card")
    KUtil.updateCardBig(nodeCard, self._card, false)
end

function KUITeamStrengthenNode.getAddAttribute(tCardIDList)
    local tAttribute, tAddAttribute = {}, {}
    for _, nCardID in ipairs(tCardIDList) do
        local tOneCard = KUtil.getCardById(nCardID)
        if tOneCard then
            local tStrengthen = KConfig["cardstrengthen"][tOneCard.nTemplateID]
            if tStrengthen then
                tAddAttribute = table.add(tAddAttribute, tStrengthen)
            end
        end
    end
    tAttribute.attack      = tAddAttribute.nAddAttack
    tAttribute.penetrate   = tAddAttribute.nAddPenetrate
    tAttribute.speed       = tAddAttribute.nAddSpeed
    tAttribute.frontArmour = tAddAttribute.nAddFrontArmour
    tAttribute.rearArmour  = tAddAttribute.nAddRearArmour
    tAttribute.scout       = tAddAttribute.nAddScout
    tAttribute.hide        = tAddAttribute.nAddHide
    tAttribute.nightBattle = tAddAttribute.nAddNightBattle

    return tAttribute
end

function KUITeamStrengthenNode:beginStrengthen()
    if not self._isInitEnd then return end
    assert(#self._cardIDList, "#" .. #self._cardIDList)
    assert(self._cardIDList[1], "" .. self._cardIDList[1])
    require("src/network/KC2SProtocolManager"):strengthenCard(self._card.nID, self._cardIDList[1])
end

function KUITeamStrengthenNode:refreshOtherPanelUi()
    if not self._isStrengthen then return end
    self._isStrengthen = false
    local eventDispatch = require("src/logic/KEventDispatchCenter")
    eventDispatch:dispatchEvent(eventDispatch.EventType.UI_STRENGTHEN_FINISH, self._card.nID)
end

function KUITeamStrengthenNode:refreshAttribute()
    local imageCommonBase       = self._mainLayout:getChildByName("Image_common_base")
    local animationAttribute    = imageCommonBase:getChildByName("ProjectNode_info")
    local imageData             = animationAttribute:getChildByName("Image_qh_data")

    local tAtrribute    = KUtil.getCardAttribute(self._card)
    local tAddAtrribute = KUITeamStrengthenNode.getAddAttribute(self._cardIDList)

    for index, name in ipairs(m_AttributeName) do
        local szNodeName          = m_NodeName[index]
        local textAttributeBefore = imageData:getChildByName("Text_" .. szNodeName .. "_data")
        local textAttributeAfter  = imageData:getChildByName("Text_" .. szNodeName .. "_data_2")
        local imageArrow          = imageData:getChildByName("Image_qh_arrow_" .. szNodeName)
        textAttributeBefore:setString(tAtrribute[name])
        if tAddAtrribute[name] then
            textAttributeAfter:setVisible(true)
            local nValue = tAddAtrribute[name] + tAtrribute[name]
            if nValue >= self._tMaxAtrribute[name] then nValue = 'MAX' end
            textAttributeAfter:setString(nValue)
            imageArrow:setVisible(true)
            textAttributeBefore:setTextColor(textAttributeAfter:getTextColor())
        else
            textAttributeAfter:setVisible(false)
            imageArrow:setVisible(false)
            textAttributeBefore:setTextColor(BEFORE_COLOR)
        end
        if tAtrribute[name] >= self._tMaxAtrribute[name] then
            textAttributeBefore:setTextColor(FULL_COLOR)
        end
    end
end

function KUITeamStrengthenNode:refreshProgressBar()
    local mainNode              = self._mainLayout
    local imageCommon           = mainNode:getChildByName("Image_common_base")
    local animationProgressBar  = imageCommon:getChildByName("ProjectNode_levelup")
    local paneProgressBar       = animationProgressBar:getChildByName("Panel_strengthen_levelup")
    paneProgressBar:stopAllActions()
    local imageLevelBase        = paneProgressBar:getChildByName("Image_qh_upgrade_base")
    
    local tAddAtrribute         = KUtil.getCurrentAddtion(self._card)
    local nSumAddAtrribute      = table.sum(tAddAtrribute)
    local nNowLevel             = math.min(math.floor(nSumAddAtrribute / self._levelValue) + 1, STRENGTHEN_LEVEL_COUNT)
    local nNowValue             = nSumAddAtrribute - self._levelValue * ( nNowLevel - 1)
    local bSetLevel             = not self._oldLevel
    self._oldLevel              = self._oldLevel or nNowLevel

    local imageNowLevel         = paneProgressBar:getChildByName("Image_qh_before")
    local panelNextLevel        = paneProgressBar:getChildByName("Panel_qh_after")
    local imageHighLevel2       = panelNextLevel:getChildByName("Image_qh_level2")
    local upgradePositionX      = imageHighLevel2:getPositionX()
    local upgradePositionY      = imageHighLevel2:getPositionY()
    
    local function setLevel(node, expData)
        nLevel = expData.level
        for _, iamge in ipairs(imageNowLevel:getChildren()) do
            iamge:setVisible(tonumber(string.match(iamge:getName(), "(%d+)$")) == nLevel)
        end
        
        local nNextLevel        = nLevel + 1
        for _, iamge in ipairs(panelNextLevel:getChildren()) do
            local number = string.match(iamge:getName(), "^Image_qh_level(%d+)$")
            if number then iamge:setVisible(tonumber(number) == nNextLevel) end
        end
        
        if nLevel > self._oldLevel then
            self._oldLevel = nLevel
            local levelUpAnimation  = cc.CSLoader:createNode("res/ui/animation_node/ani_strengthen_upgrade_effert.csb")
            levelUpAnimation:setPosition(upgradePositionX, upgradePositionY)
            panelNextLevel:addChild(levelUpAnimation)
            local function removeAnimation()
                panelNextLevel:removeChild(levelUpAnimation)
            end
            delayExecute(panelNextLevel, removeAnimation, 0.3)
        end
    end
    
    local progressbarStrengthen = imageLevelBase:getChildByName("LoadingBar_qh_upgrade_bar")
    local progressbarTop        = panelNextLevel:getChildByName("LoadingBar_level_up")
    local imageBarTop           = progressbarStrengthen:getChildByName("Image_qh_bar_highlight")  
    local function setPercent(node, expData)
        nValue = expData.value
        local nPercent = nValue/self._levelValue 
        
        progressbarStrengthen:setPercent(nPercent * 100)
        progressbarTop:setPercent(nPercent * 100)

        if nPercent > 0 then
            imageBarTop:setVisible(true)
            local nBarHeight        = progressbarStrengthen:getContentSize().width
            local nTopHeight        = imageBarTop:getContentSize().height
            imageBarTop:setPosition(nBarHeight * nPercent, imageBarTop:getPositionY())
        else
            imageBarTop:setVisible(false)
        end
    end

    local sequence          = {}
    for nLevel = self._oldLevel, nNowLevel do
        if bSetLevel or nLevel > self._oldLevel then
            table.insert(sequence, cc.CallFunc:create(setLevel, {level = nLevel}))
        end
        local nMinValue = ((nLevel ~= self._oldLevel) and 0 or self._oldValue)
        local nMaxValue = ((nLevel ~= nNowLevel) and self._levelValue or nNowValue)
        local nValue    = nMinValue
        while true do
            table.insert(sequence,cc.CallFunc:create(setPercent, {value = nValue}))
            table.insert(sequence,cc.DelayTime:create(EXP_REFRESH_SPEED))
            if nValue == nMaxValue then break end
            nValue     = nValue + 1
            if nValue  > nMaxValue then 
                nValue = nMaxValue 
            end
        end
    end

    local cSequence = cc.Sequence:create(sequence)
    assert(cSequence, #sequence)
    assert(paneProgressBar)
    paneProgressBar:runAction(cSequence)
    self._oldValue = nNowValue
end

function KUITeamStrengthenNode:setStrengthenButton(bEnabled)
    local nodeMain            = self._mainLayout
    local imageCommonBase     = nodeMain:getChildByName("Image_common_base")
    local animationRight      = imageCommonBase:getChildByName("ProjectNode_right")
    local panelRight          = animationRight:getChildByName("Panel_bg")
    local imageStrengthenBase = panelRight:getChildByName("Image_qh_base2")
    local buttonStrengthen    = imageStrengthenBase:getChildByName("Button_start_strengthen")
    KUtil.setTouchEnabledAndDisable(buttonStrengthen, bEnabled)
end

function KUITeamStrengthenNode:removeBar(nID)
    local nodeMain             = self._mainLayout
    local imageCommonBase      = nodeMain:getChildByName("Image_common_base")
    local animationRight       = imageCommonBase:getChildByName("ProjectNode_right")
    local scrollView           = animationRight:getChildByName("Scrollview_qh_list") 
    local nIndex = KUtil.getBarIndexFromScrollViewByID(scrollView, nID)
    if nIndex then
        KUtil.removeBarFromScrollView(scrollView, nIndex)
        self:setStrengthenButton(#self._cardIDList > 0)
    end
end

function KUITeamStrengthenNode:initCardBar(imageBar, tOneCard)
    local cardConfig    = KUtil.getCardConfig(tOneCard.nTemplateID)
    local buttonAdd     = imageBar:getChildByName("Button_qh_add")
    buttonAdd:setVisible(false)

    local imageCardInfo = imageBar:getChildByName("Image_qh_unit_base")
    imageCardInfo:setVisible(true)
    
    local panelHead     = imageCardInfo:getChildByName("Panel_project_card")
    KUtil.updateCardHeadBase(panelHead, tOneCard)

    local maxHP         = KUtil.getCardMaxHp(tOneCard)
    local hpName        = {nil, nil, nil, nil, nil}
    local stateName     = {nil, "Image_common_damage_light", "Image_common_damage_middle", "Image_common_damage_heavy", nil}
    local hpPercent     = tOneCard.nCurrentHP * 100 / maxHP
    KUtil.drawCardState(nil, imageCardInfo, hpName, stateName, hpPercent)
    
    local maxExp        = KUtil.getCardMaxExp(tOneCard.nLevel)
    local barExpLoading = imageCardInfo:getChildByName("LoadingBar_exp")
    barExpLoading:setPercent(tOneCard.nCurrentExp / maxExp * 100)
    
    local labelLevel    = imageCardInfo:getChildByName("BitmapFontLabel_level_data")
    labelLevel:setString(tOneCard.nLevel)
    
    local labelName     = imageCardInfo:getChildByName("Text_tank_name")
    labelName:setString(cardConfig.szName)
    
    local tAttribute      = KUITeamStrengthenNode.getAddAttribute({tOneCard.nID})
    local nPanelIndex, nAttributeIndex = 1, 1
    
    while true do
        local panelAtrribute = imageCardInfo:getChildByName("Panel_property_" .. nPanelIndex)
        if not panelAtrribute then break end
        panelAtrribute:setVisible(false)
        nPanelIndex = nPanelIndex + 1
        for index = nAttributeIndex, #m_AttributeName do 
            local nValue = tAttribute[m_AttributeName[index]]
            if nValue and nValue > 0 then
                nAttributeIndex = index + 1
                panelAtrribute:setVisible(true)
                for i, szName in ipairs(m_NodeName) do
                    local imageAtrribute = panelAtrribute:getChildByName("Image_qh_" .. szName)
                    imageAtrribute:setVisible(i == index)
                end
                local fontCount = panelAtrribute:getChildByName("BitmapFontLabel_number")
                fontCount:setString(nValue)
                break
            end 
        end 
    end
    
    local buttonDelete  = imageCardInfo:getChildByName("Button_unit_unload")
    local function onDeleteClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._isStrengthen then return end
        local nID = tOneCard.nID
        if not HArray.FindFirstByValue(self._cardIDList, nID) then return end
        KSound.playEffect("click")
        local nIndex = HArray.FindFirstIndexByValue(self._cardIDList, nID)
        HArray.RemoveFirstByValue(self._cardIDList, nID)
        self:removeBar(nID)
        self:refreshAttribute()
    end
    buttonDelete:addTouchEventListener(onDeleteClick)
end

function KUITeamStrengthenNode:addCardChooseNode(tankType, sortType)
    self._parent:addNode("CardChoose", KUtil.getCanConsumeCardList(self._card.nID), self._cardIDList, tankType, sortType, 1)
end

function KUITeamStrengthenNode:initEmptyBar(imageBar)
    local buttonAdd     = imageBar:getChildByName("Button_qh_add")
    buttonAdd:setVisible(true)

    local imageCardInfo = imageBar:getChildByName("Image_qh_unit_base")
    imageCardInfo:setVisible(false)

    --Add Button
    local function onAddClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return end
        if self._isStrengthen then return end
        KSound.playEffect("addMember")
        self:addCardChooseNode()
    end
    buttonAdd:addTouchEventListener(onAddClick)
end

function KUITeamStrengthenNode:refreshScrollview(bCutIn)
    local nodeMain             = self._mainLayout
    local imageCommonBase      = nodeMain:getChildByName("Image_common_base")
    local animationRight       = imageCommonBase:getChildByName("ProjectNode_right")
    local scrollView           = animationRight:getChildByName("Scrollview_qh_list") 
    local panelRight           = animationRight:getChildByName("Panel_bg")
    local slideControl         = panelRight:getChildByName("Slider_scroll")

    local tCarList = {}
    for index, cardID in pairs(self._cardIDList) do
        local card = KUtil.getCardById(cardID)
        if card ~= nil then
            table.insert(tCarList, card)
        end
    end
    table.insert(tCarList, {nID = 0})

    local function funInit(bar, card)
        if card.nID == 0 then
            self:initEmptyBar(bar)
            return true
        end
        self:initCardBar(bar, card)
        return true
    end  

    local function funEnd()
        self._isInitEnd = true
        if self._isStrengthen and self._cardIDList[1] then
            self:beginStrengthen()
        end
    end

    self._isInitEnd = false
    local tParam      = {
        scrollView    = scrollView,
        barBase       = self._baseCardBar,
        dataList      = tCarList,
        funInit       = funInit,
        funEnd        = funEnd,
        oneBatchCount = 4,
        isCutIn       = bCutIn,
        slideControl  = slideControl}
    KUtil.batchAddScrollView(tParam)

    self:setStrengthenButton(#self._cardIDList > 0)
end

function KUITeamStrengthenNode:getShowCardList()
    tCardList = {}
    HArray.inserArray(tCardList, KPlayer.tCardData.tStoreHouse.tCardList)
    local KSetting = require("src/logic/KSetting")
    local sortType = KSetting.getInt(KSetting.Key.COMMON_CHOOSE_TYPE, KUtil.CHOOSE_COMMON_TYPE.NAME)
    tCardList = KUtil.getUnitSelectSortList(tCardList, sortType)
    self._showCardIDList = {}
    for _, card in ipairs(tCardList) do
        table.insert(self._showCardIDList, card.nID)
    end
end

function KUITeamStrengthenNode:getCardIndex()
    if not self._showCardIDList then
        self:getShowCardList()
    end
    for index, cardID in ipairs(self._showCardIDList) do
        if cardID == self._card.nID then
            return index
        end
    end
end

function KUITeamStrengthenNode:enterAnimation()
    KUtil.playEnterAnimation(self._animationHome)
    KUtil.playEnterAnimation(self._animationResource)
    KUtil.playEnterAnimation(self._animationCard, 0, 40)
    KUtil.playEnterAnimation(self._animationAttribute)
    KUtil.playEnterAnimation(self._animationScrollview, 0, 25)
    KUtil.playEnterAnimation(self._animationPageButton)

    local function delayPlayEnterProgressBar( ... )
        KUtil.playEnterAnimation(self._animationProgressBar)
    end
    delayExecute(self._mainLayout, delayPlayEnterProgressBar, 0.25)
end

function KUITeamStrengthenNode:quitAnimation(isReturnOffice)
    local delayTime1 = KUtil.playQuitAnimation(self._animationHome)
    local delayTime2 = KUtil.playQuitAnimation(self._animationResource)
    local delayTime3 = KUtil.playQuitAnimation(self._animationCard, 64, 80)
    local delayTime4 = KUtil.playQuitAnimation(self._animationAttribute)
    local delayTime5 = KUtil.playQuitAnimation(self._animationProgressBar, 55, 56)
    local delayTime6 = KUtil.playQuitAnimation(self._animationScrollview)
    local delayTime7 = KUtil.playQuitAnimation(self._animationPageButton)

    local delayTime  = math.max(delayTime1, delayTime2, delayTime3, delayTime4, delayTime5, delayTime6, delayTime7)

    local function animationFun1()
        local framesList = {}
        table.insert(framesList, delayTime * KUtil.FRAME_PER_SECOND)
        return framesList
    end
    local callBacks = {animationFun1}
    KUtil.delayClosePanel(self, "Strengthen", callBacks, isReturnOffice)
end

function KUITeamStrengthenNode:initData()
    local tBaseAtrribute     = KUtil.getBaseAttribute(self._card)
    self._tMaxAtrribute      = KUtil.getMaxAttribute(self._card)
    self._levelValue         = (table.sum(self._tMaxAtrribute) - table.sum(tBaseAtrribute)) / STRENGTHEN_LEVEL_COUNT

    self._oldLevel          = nil
    self._oldValue          = 0
end

function KUITeamStrengthenNode:initAnimation()
    local imageCommonBase     = self._mainLayout:getChildByName("Image_common_base")
    local animationRight      = imageCommonBase:getChildByName("ProjectNode_right")
    local scrollView          = animationRight:getChildByName("Scrollview_qh_list")
    local imageBar            = scrollView:getChildByName("Image_qh_unit_empty")
    self._baseCardBar         = imageBar:clone()
    self._baseCardBar:retain()

    local function closeCallBack(isReturnOffice)
        self:quitAnimation(isReturnOffice)
    end
    self._animationHome, self._animationResource = KUtil.initHomeAndResourceNode(self, closeCallBack, "qh_base")

    local nodeCardAnimation        = imageCommonBase:getChildByName("Node_card")
    self._animationCard            = KUtil.initAnimation(nodeCardAnimation, "res/ui/animation_node/ani_cardbase_big.csb")
    local nodeAttributeAnimation   = imageCommonBase:getChildByName("ProjectNode_info")
    self._animationAttribute       = KUtil.initAnimation(nodeAttributeAnimation, "res/ui/animation_node/ani_strengthen_info.csb")
    local nodeProgressBarAnimation = imageCommonBase:getChildByName("ProjectNode_levelup")
    self._animationProgressBar     = KUtil.initAnimation(nodeProgressBarAnimation, "res/ui/animation_node/ani_strengthen_levelup.csb")
    local nodeScrollviewAnimation  = imageCommonBase:getChildByName("ProjectNode_right")
    self._animationScrollview      = KUtil.initAnimation(nodeScrollviewAnimation, "res/ui/animation_node/ani_strengthen_right.csb")
    local nodePageButtonAnimation  = imageCommonBase:getChildByName("ProjectNode_button_page")
    self._animationPageButton      = KUtil.initAnimation(nodePageButtonAnimation, "res/ui/animation_node/ani_character_button_page.csb")   
end

function KUITeamStrengthenNode:changeCard(cardID)
    local oldCard = self._card
    self._card = KUtil.getCardById(cardID)
    assert(self._card, "targetCard is nil " .. cardID)
    if oldCard == self._card then return end
    self:initData()
    self:initCardImage()
    self:refreshAttribute()
    self:refreshProgressBar()
end

-- delay refresh
function KUITeamStrengthenNode:previousOne()
    local cardIndex = self:getCardIndex()
    assert(cardIndex)
    cardIndex = cardIndex - 1
    if cardIndex == 0 then cardIndex = #self._showCardIDList end

    local targetCardID
    local index = cardIndex
    while true do
        targetCardID = self._showCardIDList[index]
        if HArray.FindFirstByValue(self._cardIDList, targetCardID) == nil then
            break
        end
        index = index - 1
        if cardIndex == index then
            assert(false)
        elseif index == 0 then
            index = #self._showCardIDList
        end
    end
    assert(targetCardID)
    self:changeCard(targetCardID)
    self._cardIDList = {}
    self:refreshScrollview()
end

function KUITeamStrengthenNode:nextOne()
    local cardIndex = self:getCardIndex()
    assert(cardIndex)
    cardIndex = cardIndex + 1
    if cardIndex > #self._showCardIDList then cardIndex = 1 end

    local targetCardID
    local cardCount = #self._showCardIDList
    local index = cardIndex
    while true do
        targetCardID = self._showCardIDList[index]
        if HArray.FindFirstByValue(self._cardIDList, targetCardID) == nil then
            break
        end
        index = index + 1
        if cardIndex == index then
            assert(false)
        elseif index > cardCount then
            index = 1
        end
    end
    assert(targetCardID)
    self:changeCard(targetCardID)
    self._cardIDList = {}
    self:refreshScrollview()
end

function KUITeamStrengthenNode:onInitUI()
    self:initData()
    self:initAnimation()
end

function KUITeamStrengthenNode:onEnterActionFinished()
    self:enterAnimation()
end

function KUITeamStrengthenNode:refreshUI()
    self:initCardImage()
    self:refreshAttribute()
    self:refreshProgressBar()
    self:refreshScrollview(true)
end

function KUITeamStrengthenNode:registerAllTouchEvent()
    local nodeMain            = self._mainLayout
    local imageCommonBase     = nodeMain:getChildByName("Image_common_base")
    local animationRight      = imageCommonBase:getChildByName("ProjectNode_right")
    local panelRight          = animationRight:getChildByName("Panel_bg")

    local projectPageNode     = imageCommonBase:getChildByName("ProjectNode_button_page")
    local buttonPageLeft      = projectPageNode:getChildByName("Button_page_left")
    local function onLeftClick(sender, type)
        if type == ccui.TouchEventType.ended then return end
        if self._isStrengthen then return end
        KSound.playEffect("click")
        self:previousOne()
    end
    buttonPageLeft:addTouchEventListener(onLeftClick) 

    local buttonPageRight = projectPageNode:getChildByName("Button_page_right")
    local function onRightClick(sender, type)
        if type == ccui.TouchEventType.ended then return end
        if self._isStrengthen then return end
        KSound.playEffect("click")
        self:nextOne()
    end
    buttonPageRight:addTouchEventListener(onRightClick) 

    local imageStrengthenBase = panelRight:getChildByName("Image_qh_base2")
    local buttonStrengthen    = imageStrengthenBase:getChildByName("Button_start_strengthen")
    local function onStrengthenClick(sender, type)
        if type ~= ccui.TouchEventType.ended then return false end
        if #self._cardIDList == 0 then return false end
        cclog ("click onStrengthenButton~")
        KSound.playEffect("startStrengthen")      
        local card     = self._card 
        KSound.playTalk(KSound.TALK.STRENGTHEN, card.nTemplateID)
        self._isStrengthen = true
        self:beginStrengthen()
        KUtil.setTouchEnabledAndDisable(buttonStrengthen, false)
    end
    buttonStrengthen:addTouchEventListener(onStrengthenClick)

    local scrollControl       = animationRight:getChildByName("Scrollview_qh_list")  
    local slideControl        = panelRight:getChildByName("Slider_scroll")
    local function onSlideChange(sender, type)
        if type == ccui.SliderEventType.percentChanged then
            scrollControl:jumpToPercentVertical(slideControl:getPercent())
        end
    end
    slideControl:addEventListener(onSlideChange)

    local function onScrollChange(sender, type)
        local percent = KUtil.getScrollViewPercent(scrollControl)
        slideControl:setPercent(percent)
    end
    scrollControl:addEventListener(onScrollChange)
end

function KUITeamStrengthenNode:registerAllCustomEvent()
    local eventDispatchCenter  = require("src/logic/KEventDispatchCenter")

    local mainNode             = self._mainLayout
    local imageCommonBase      = mainNode:getChildByName("Image_common_base")
    local animationProgressBar = imageCommonBase:getChildByName("ProjectNode_levelup")
    local panelProgressBar     = animationProgressBar:getChildByName("Panel_strengthen_levelup")
    local imageLowLevel        = panelProgressBar:getChildByName("Image_qh_before") 
    local iamgeLowLevel1       = imageLowLevel:getChildByName("Image_qh_level1")  
    local starPositionX        = iamgeLowLevel1:getPositionX()
    local starPositionY        = iamgeLowLevel1:getPositionY()

    local animationScrollview  = imageCommonBase:getChildByName("ProjectNode_right")
    local scrollView           = animationScrollview:getChildByName("Scrollview_qh_list")
    local scrollViewInner      = scrollView:getInnerContainer()

    local function onStrengthen(bSuccess, nConsumeCardID) 
        local barCard          = KUtil.getBarFromScrollViewByID(scrollView, nConsumeCardID)
        if not barCard then return end
        local levelPosition    = imageLowLevel:convertToWorldSpace(cc.p(starPositionX, starPositionY))
        levelPosition          = mainNode:convertToNodeSpace(levelPosition)
        levelPosition.x = levelPosition.x - barCard:getContentSize().width / 2
        levelPosition.y = levelPosition.y - barCard:getContentSize().height / 2

        cclog("onstrengthen finish, %d", nConsumeCardID)
        HArray.RemoveFirstByValue(self._cardIDList, nConsumeCardID)
        if self._showCardIDList then
            HArray.RemoveFirstByValue(self._showCardIDList, nConsumeCardID)
        end
        scrollView:scrollToTop(1 / 60, false)
        
        
        local barX        = barCard:getPositionX()
        local barY        = barCard:getPositionY()
        local barPosition = scrollViewInner:convertToWorldSpace(cc.p(barX, barY))
        barPosition       = mainNode:convertToNodeSpace(barPosition)

        local nodeBase
        local strengthenAnimation
        local function playLight( ... )
            nodeBase                        = cc.Node:create()
            local nodeAnimationRemoveUnit   = cc.CSLoader:createNode(    "res/ui/animation_node/ani_strengthen_card_effert.csb")
            local strengthenAnimation       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_strengthen_card_effert.csb")
            nodeBase:addChild(nodeAnimationRemoveUnit)
            for _, node in ipairs(barCard:getChildren()) do
                node:setVisible(false)
            end
            barCard:addChild(nodeBase)
            nodeAnimationRemoveUnit:stopAllActions() 
            nodeAnimationRemoveUnit:runAction(strengthenAnimation)
            strengthenAnimation:gotoFrameAndPlay(0, LIGHT_FRAME, false)
        end

        local function playMove()
            self:removeBar(nConsumeCardID)
            nodeBase                        = cc.Node:create()
            local nodeAnimationRemoveUnit   = cc.CSLoader:createNode(    "res/ui/animation_node/ani_strengthen_card_effert.csb")
            local strengthenAnimation       = cc.CSLoader:createTimeline("res/ui/animation_node/ani_strengthen_card_effert.csb")
            nodeBase:addChild(nodeAnimationRemoveUnit)
            nodeBase:setPosition(barPosition)
            mainNode:addChild(nodeBase)
            nodeAnimationRemoveUnit:stopAllActions() 
            nodeAnimationRemoveUnit:runAction(strengthenAnimation)
            strengthenAnimation:gotoFrameAndPlay(LIGHT_FRAME, LIGHT_FRAME + MOVE_FRAME, false)
            nodeBase:runAction(cc.Sequence:create( cc.MoveTo:create(MOVE_FRAME / 60 , levelPosition)))
            
            self:refreshAttribute()
            self:refreshProgressBar()
        end

        local nodeAnimationLight
        local function playStar()
            nodeAnimationLight   = cc.CSLoader:createNode("res/ui/animation_node/ani_strengthen_get_effert.csb")
			local levelPosition    = imageLowLevel:convertToWorldSpace(cc.p(starPositionX, starPositionY))
			levelPosition          = imageCommonBase:convertToNodeSpace(levelPosition)
            nodeAnimationLight:setPosition(levelPosition)
            imageCommonBase:addChild(nodeAnimationLight)
        end

        local function sendMessage()
            if self._cardIDList[1] then
                if self._isInitEnd then
                    self:beginStrengthen()
                end
            else
                self:refreshOtherPanelUi()
            end
        end

        local function removeNode()
            mainNode:removeChild(nodeBase)
            imageCommonBase:removeChild(nodeAnimationLight)
        end
        
        if bSuccess then
            local sequence = {}
            table.insert(sequence,cc.CallFunc:create(playLight))
            table.insert(sequence,cc.DelayTime:create(LIGHT_FRAME / 60))
            table.insert(sequence,cc.CallFunc:create(playMove))
            table.insert(sequence,cc.DelayTime:create(MOVE_FRAME / 60))
            table.insert(sequence,cc.CallFunc:create(sendMessage))
            table.insert(sequence,cc.CallFunc:create(playStar))
            table.insert(sequence,cc.DelayTime:create(0.5))
            table.insert(sequence,cc.CallFunc:create(removeNode))
            self._mainLayout:runAction(cc.Sequence:create(sequence))
        else
            self:removeBar(nConsumeCardID)
            sendMessage()
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_STRENGTHEN, onStrengthen)
    
    local function onChooseFinish(cardIDList)
        self._cardIDList = {}
        for i, nCardID in ipairs(cardIDList) do
            if KUtil.getCardById(nCardID) then
                table.insert(self._cardIDList, nCardID)
            end
        end
        self:refreshScrollview(true)
        self:refreshAttribute()
    end
    self:addCustomEvent(eventDispatchCenter.EventType.UI_BREAK_CHOOSE_FINISH, onChooseFinish)

    local function syncCard(tOneCard)
        assert(self._card, "no _card when syncCard")
        if self._card.nID == tOneCard.nID then 
            self._card = tOneCard
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_ONE_CARD_CHANGE, syncCard)

    local function changeCard(nOldCardID, nCardID)
        assert(self._card, "no _card when changeCard")
        if self._card.nID == nOldCardID then 
            self._card = KUtil.getCardById(nCardID)
            assert(self._card, "no _card when getCardById " .. tostring(nCardID))
        end
    end
    self:addCustomEvent(eventDispatchCenter.EventType.NET_NOTIFY_CONVERT_CARD, changeCard)
end

function KUITeamStrengthenNode:onCleanup()
    self:refreshOtherPanelUi()
    self._baseCardBar:release() 
end

return KUITeamStrengthenNode
