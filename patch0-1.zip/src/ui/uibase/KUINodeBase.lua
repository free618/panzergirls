--  ********************************************************************
--  Copyright(c) KingSoft
--  FileName    : KUINodeBase.lua
--  Creator     : SunXun
--  Date        : 2015/04/05   20:00
--  Contact     : sunxun@kingsoft.com
--  Comment     : This is the base about all of Node.
--  *********************************************************************


local KUINodeBase = class(
    "KUINodeBase", function () return cc.Node:create() end
)

function KUINodeBase:ctor()
    self._parent        = nil
    self._mainLayout    = nil
    self._uiPath        = nil
    self._eventList     = {}
    self._isCovered     = true
end

function KUINodeBase.create()
    return KUINodeBase.new()
end

function KUINodeBase:getEnterAction()
    local actionTime   = 0.2
    local screenSize   = cc.Director:getInstance():getVisibleSize()
    local startX       = screenSize.width / 2
    local startY       = screenSize.height / 2
    local startScaleX  = 0.0
    local startScaleY  = 0.0
    local startOpacity = 0
    local startShadow  = 128
    local mainNode     = self._mainLayout
    local oldPosX      = mainNode:getPositionX()
    local oldPosY      = mainNode:getPositionY()
    local oldScaleX    = mainNode:getScaleX()
    local oldScaleY    = mainNode:getScaleY()
    local oldOpacity   = mainNode:getOpacity()
    
    mainNode:setPosition(cc.p(startX, startY))
    mainNode:setScale(startScaleX, startScaleY)
    mainNode:setOpacity(startOpacity)

    local action = cc.Sequence:create(
        cc.Spawn:create(
            cc.FadeTo:create(actionTime, oldOpacity),
            cc.Spawn:create(
                cc.ScaleTo:create(actionTime, oldScaleX, oldScaleY),
                cc.MoveTo:create(actionTime, cc.p(oldPosX, oldPosY))
            )
        )
    )

    return action, actionTime
end

function KUINodeBase:getExitAction()
    return nil, nil
end

function KUINodeBase:runEnterAction()
    cclog("KUINodeBase:runEnterAction")
    assert(self._mainLayout ~= nil)
    local enterAction, actionWasteTime = self:getEnterAction()
    if not enterAction then
        self:enterActionFinishedCallback()
        return 0
    end

    local mainLayout  = self._mainLayout
    local actionSequence = cc.Sequence:create(
        enterAction,
        cc.CallFunc:create(function()
            self:enterActionFinishedCallback()
        end)
    )
    mainLayout:runAction(actionSequence)
    return actionWasteTime
end

function KUINodeBase:runExitAction() -- please let scene call this and clean node
    cclog("KUINodeBase:runExitAction")
    local exitAction, actionWasteTime = self:getExitAction()
    if not exitAction then
        self:exitActionStartCallback()
        return 0
    end

    local mainLayout  = self._mainLayout
    local actionSequence = cc.Sequence:create(
        cc.CallFunc:create(function()
            self:exitActionStartCallback()
        end),
        exitAction
    )
    mainLayout:runAction(actionSequence)
    return actionWasteTime
end

function KUINodeBase:activate(nowTime)
-- activate per render frame
end

function KUINodeBase:refreshUI()
-- refresh UI Base State
end

function KUINodeBase:registerAllTouchEvent()
-- register all touch event here
end

function KUINodeBase:registerAllCustomEvent()
-- register all custom event here
-- and KUINodeBase auto clearn custom event when onExit
end

function KUINodeBase:addCustomEvent(eventType, callbackFunc)
    -- logic add custom event.
    -- this event is different from cocos2d::addCustomEventListener
    -- cocos2d::addCustomEventListener is base on scene
    -- but this custom event can live background.

    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")

    assert(eventDispatchCenter.EventType[eventType] ~= nil, "Add custom event but event is not exist in KEventDispatchCenter.EventType")
    table.insert(self._eventList, 
        {
            ["eventType"]       = eventType, 
            ["callbackFunc"]    = callbackFunc
        }
    )
    eventDispatchCenter:registerEvent(eventType, callbackFunc)
end

function KUINodeBase:unregisterAllCustomEvent()
    local eventDispatchCenter = require("src/logic/KEventDispatchCenter")
    for _, v in pairs(self._eventList) do
        eventDispatchCenter:unregisterEvent(v["eventType"], v["callbackFunc"])
    end
    self._eventList = {}
end

function KUINodeBase:autoHandler()
    -- work for :
    -- 1.make self care about onEnter/onExit Event
    -- 2.run onEnter / onExit Action
    -- 3.addChild node to myself
    -- 4.call self:refreshUI()
    -- 5.register all touch event
    -- we must register all touch event after refreshUI(), because we could add item dynamic for scrollview list.
    -- 6.register all custom event

    local function onNodeEvent(event)
        if "enter" == event then
            local KLogGather = require("src/logic/KLogGather")
            KLogGather.addLog("EventBug", self._uiPath, "node enter")
            self:onEnter()
        elseif "exit" == event then
            local KLogGather = require("src/logic/KLogGather")
            KLogGather.addLog("EventBug", self._uiPath, "node exit")
            self:onExit()
        elseif "cleanup" == event then
            self:unregisterScriptHandler()
            local KLogGather = require("src/logic/KLogGather")
            KLogGather.addLog("EventBug", self._uiPath, "node cleanup")

            if #self._eventList ~= 0 then
                KLogGather.addLog("EventBug", self._uiPath, "event count error", #self._eventList)
                KLogGather.sendLog("EventBug")
                self:unregisterAllCustomEvent()
            end

            self:onCleanup()
        end
    end

    assert(self._mainLayout)
    self._mainLayout:registerScriptHandler(onNodeEvent)

    self:onInitUI()
    self:refreshUI()
    self:registerAllTouchEvent()
    self:registerAllCustomEvent()

    self:addChild(self._mainLayout, 1)
end

function KUINodeBase:HideLoadUI()
    if self._sendingNode then
        self._sendingNode:removeFromParent()
        self._sendingNode = nil
    end
end

function KUINodeBase:ShowLoadUI()
    assert(not self._sendingNode)
    self._sendingNode = cc.CSLoader:createNode("res/ui/layout_mini_loading.csb")
    self:addChild(self._sendingNode, 200)
end

-- load csb file
function KUINodeBase:loadCsbFile()
    self._mainLayout = cc.CSLoader:createNode(self._uiPath)

    -- set autoHandler()
    self:autoHandler()

    self:HideLoadUI()
end

function KUINodeBase:init()
    local KLogGather = require("src/logic/KLogGather")
    KLogGather.addLog("EventBug", self._uiPath, "node init")
    assert(self._uiPath ~= nil, "uiResPath is not config~")

    if self._showLoading then
        self:ShowLoadUI()
        delayExecute(self, function()
            self:loadCsbFile()
        end, 0)
    else
        self:loadCsbFile()
    end
end

function KUINodeBase:onInitUI()
end

function KUINodeBase:onNodeEnter()
end

function KUINodeBase:onNodeExit()
end

function KUINodeBase:onEnter()
    --cclog("KUINodeBase:onEnter start")
    self:runEnterAction()
    require("src/logic/KMainLoop"):addActivateObject(self)
    --cclog("KUINodeBase:onEnter end")
    self:onNodeEnter()
end

function KUINodeBase:onExit()
    --cclog("KUINodeBase:onExit start")
    assert(self, "self")
    self:onNodeExit()
    assert(self, "self2")
    self:unregisterAllCustomEvent()
    assert(require("src/logic/KMainLoop"), "KMainLoop")
    require("src/logic/KMainLoop"):removeActivateObject(self)
    --cclog("KUINodeBase:onExit end")
end

function KUINodeBase:onCleanup()
end

function KUINodeBase:enterActionFinishedCallback()
    local parent = self._parent
    if parent then
        if parent.onNodeEnterActionFinished then
            parent:onNodeEnterActionFinished(self)
        end
    end

    self:onEnterActionFinished()
end

function KUINodeBase:exitActionStartCallback()
    local parent = self._parent
    if parent then
        if parent.onNodeExitActionStarted then 
            parent:onNodeExitActionStarted(self)
        end
    end

    self:onExitActionStart()
end

function KUINodeBase:onEnterActionFinished()
end

function KUINodeBase:onExitActionStart()
end

function KUINodeBase:isCovered()
    return self._isCovered
end

return KUINodeBase
