
local versionInfo = {
	versionNumber =  1,
}

return versionInfo
