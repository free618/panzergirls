
local versionInfo = {
	versionNumber =  0,
}

return versionInfo
